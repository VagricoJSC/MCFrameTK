package mcframe.clientFSBA.FSBAP0300;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_ScreenBookmarkForwardSetting"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_ScreenBookmarkForwardSetting_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0300";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	// [Cnd]ブロックの項目のField定義
	public MCLabel Cnd_to_screen_id_Label = null;
	/**
	 *  連携先画面ＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_to_screen_id = null;
	/**
	 *  連携先画面名.<p>
	 *
	 */
	public MCTextField Cnd_to_screen_nm = null;
	public MCLabel Cnd_from_screen_id_Label = null;
	/**
	 *  連携元画面ＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_from_screen_id = null;
	/**
	 *  連携元画面名.<p>
	 *
	 */
	public MCTextField Cnd_from_screen_nm = null;
	/**
	 *  識別キーを表示する.<p>
	 *
	 */
	public MCCheckBox Cnd_key_view = null;
	// [Dtl]ブロック関連のField定義
	public MCPanel DtlPanel = null;
	public MCScrollPane DtlScrollPane = null;
	public MCColumnGroupTable<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> DtlTable = null;
	// [Dtl]ブロックの項目のField定義
	/**
	 *  識別キー.<p>
	 *
	 */
	public MCColumnConfig columnDtl_to_key = null;
	/**
	 *  枠名・種類.<p>
	 *
	 */
	public MCColumnConfig columnDtl_to_panel = null;
	/**
	 *  名称.<p>
	 *
	 */
	public MCColumnConfig columnDtl_to_name = null;
	/**
	 *  枠名.<p>
	 *
	 */
	public MCColumnConfig columnDtl_from_panel = null;
	/**
	 *  名称.<p>
	 *
	 */
	public MCColumnConfig columnDtl_from_name = null;
	/**
	 *  識別キー.<p>
	 *
	 */
	public MCColumnConfig columnDtl_from_key = null;
	/**
	 *  テキスト.<p>
	 *
	 */
	public MCColumnConfig columnDtl_text = null;
	/**
	 *  チェックボックス.<p>
	 *
	 */
	public MCColumnConfig columnDtl_check = null;
	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public MCColumnConfig columnDtl_radio = null;
	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public MCColumnConfig columnDtl_radio_nm = null;
	/**
	 *  日付（今日）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_today_flg = null;
	/**
	 *  日付（月初）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_firstday_flg = null;
	/**
	 *  日付（月末）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_lastday_flg = null;
	/**
	 *  日付（固定値）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_date = null;
	/**
	 *  差分（月）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_month = null;
	/**
	 *  差分（週）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_week = null;
	/**
	 *  曜日.<p>
	 *
	 */
	public MCColumnConfig columnDtl_day_of_week_type = null;
	/**
	 *  曜日名.<p>
	 *
	 */
	public MCColumnConfig columnDtl_day_of_week_type_nm = null;
	/**
	 *  差分（日）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_day = null;
	/**
	 *  差分（時）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_hour = null;
	/**
	 *  差分（分）.<p>
	 *
	 */
	public MCColumnConfig columnDtl_minute = null;
	/**
	 *  数値.<p>
	 *
	 */
	public MCColumnConfig columnDtl_num = null;
	public MCColumnGroup cgDtl_to = null;
	public MCColumnGroup cgDtl_from = null;
	public MCColumnGroup cgDtl_from_fixed = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	public MCLabel Btn_act_Label = null;
	/**
	 *  表示時動作.<p>
	 *
	 */
	public MCTextComboBox Btn_act = null;
	/**
	 *  表示時動作識別キー.<p>
	 *
	 */
	public MCTextField Btn_act_key = null;
	public MCLabel Btn_srch_cnd_Label = null;
	/**
	 *  入力値設定.<p>
	 *
	 */
	public MCTextComboBox Btn_srch_cnd = null;
	/**
	 *  入力値設定情報キー.<p>
	 *
	 */
	public MCTextField Btn_srch_cnd_key = null;
	/**
	 *  入力値設定備考.<p>
	 *
	 */
	public MCTextField Btn_srch_cnd_remark = null;
	/**
	 *  決定する.<p>
	 *
	 */
	public MCButton Btn_upd = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [KEY]モードを表す定数 */
	public static final String KEY = "KEY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, KEY};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0300.CndR aCndR;
	/** [Dtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> aDtlL;
	/** [Btn]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0300.BtnR aBtnR;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFSBA.FSBAP0300.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0300.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0300.CndR createCndR() {
		return mcframe.clientFSBA.FSBAP0300.CndR.create();
	}

	/**
	 * コピーによってaDtlLを設定します。
	 *
	 * aDtlLのインスタンスは変更されません。
	 *
	 * @param dataset DtlL
	 */
	public void setDtlL(MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> aList) {
		if (getDtlL() != aList) {
			getDtlL().setAll(aList);
		}
	}

	/**
	 * [Dtl]ブロックのコンテナaDtlLを返します。
	 *
	 * @return DtlL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> getDtlL() {
		return aDtlL;
	}

	/**
	 * aDtlRを作成します。
	 *
	 * @return DtlR
	 */
	public mcframe.clientFXUC.FXUCP0040.OpenScreenParamR createDtlR() {
		return mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.create();
	}

	/**
	 * aDtlLを作成します。
	 *
	 * @return DtlL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> createDtlL() {
		return MCList.create(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.class);
	}

	/**
	 * DtlTableを初期化します。
	 */
	protected void createDtlTable(){
		if(DtlTable == null){
			DtlTable = beansFactory.createColumnGroupTable("Dtl.table");
		}
	}

	/**
	 * 項目コピーによってaBtnRを設定します。
	 *
	 * aBtnRのインスタンスは変更されません。
	 *
	 * @param row BtnR
	 */
	public void setBtnR(mcframe.clientFSBA.FSBAP0300.BtnR row) {
		if (row != null) {
			MCRow.copyall(getBtnR(), row);
		}
	}

	/**
	 * [Btn]ブロックのコンテナaBtnRを返します。
	 *
	 * @return BtnR
	 */
	public mcframe.clientFSBA.FSBAP0300.BtnR getBtnR() {
		return aBtnR;
	}

	/**
	 * aBtnRを作成します。
	 *
	 * @return BtnR
	 */
	public mcframe.clientFSBA.FSBAP0300.BtnR createBtnR() {
		return mcframe.clientFSBA.FSBAP0300.BtnR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getDtlL())) ret.add(getDtlL());
		if(!MCCollectionUtil.contains(ret, getBtnR())) ret.add(getBtnR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getDtlL()) return "Dtl";
		if(aCnt == getBtnR()) return "Btn";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("Dtl")) return getDtlL();
		if(bId.equals("Btn")) return getBtnR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(DtlPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ScreenBookmarkForwardSetting_FW_A() {
		aCndR = createCndR();
		aDtlL = createDtlL();
		aBtnR = createBtnR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ScreenBookmarkForwardSetting_FW_A(String name) {
		aCndR = createCndR();
		aDtlL = createDtlL();
		createDtlTable();
		DtlTable.setRowName(name);
		aBtnR = createBtnR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_ScreenBookmarkForwardSetting_FW.jbCreateCnd((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbCreateDtl((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbCreateBtn((FSBAP_ScreenBookmarkForwardSetting)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FSBAP_ScreenBookmarkForwardSetting p) {
	}

	/**
	 * [Dtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDtl(FSBAP_ScreenBookmarkForwardSetting p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP_ScreenBookmarkForwardSetting p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Dtl_from_name_ListPutter]の定義 */
	private MCListPutter Dtl_from_name_p = null;

	/**
	 * [Dtl_from_name_ListPutter]の取得
	 */
	protected MCListPutter getDtl_from_name_ListPutter() {
		if (Dtl_from_name_p == null) {
			Dtl_from_name_p = createDtl_from_name_ListPutter(columnDtl_from_name, "from_name", "from_panel","from_key");

		}
		return Dtl_from_name_p;
	}
	
	
	/** [Dtl_radio_ListPutter]の定義 */
	private MCListPutter Dtl_radio_p = null;

	/**
	 * [Dtl_radio_ListPutter]の取得
	 */
	protected MCListPutter getDtl_radio_ListPutter() {
		if (Dtl_radio_p == null) {
			Dtl_radio_p = createDtl_radio_ListPutter(columnDtl_radio, "radio", "radio_nm");

		}
		return Dtl_radio_p;
	}
	
	
	/** [Dtl_day_of_week_type_ListPutter]の定義 */
	private MCListPutter Dtl_day_of_week_type_p = null;

	/**
	 * [Dtl_day_of_week_type_ListPutter]の取得
	 */
	protected MCListPutter getDtl_day_of_week_type_ListPutter() {
		if (Dtl_day_of_week_type_p == null) {
			Dtl_day_of_week_type_p = createDtl_day_of_week_type_ListPutter(columnDtl_day_of_week_type, "day_of_week_type", "day_of_week_type_nm");

		}
		return Dtl_day_of_week_type_p;
	}
	
	
	/** [Btn_act_ListPutter]の定義 */
	private MCListPutter Btn_act_p = null;

	/**
	 * [Btn_act_ListPutter]の取得
	 */
	protected MCListPutter getBtn_act_ListPutter() {
		if (Btn_act_p == null) {
			Btn_act_p = createBtn_act_ListPutter(Btn_act, "act", "act_key");

		}
		return Btn_act_p;
	}
	
	
	/** [Btn_srch_cnd_ListPutter]の定義 */
	private MCListPutter Btn_srch_cnd_p = null;

	/**
	 * [Btn_srch_cnd_ListPutter]の取得
	 */
	protected MCListPutter getBtn_srch_cnd_ListPutter() {
		if (Btn_srch_cnd_p == null) {
			Btn_srch_cnd_p = createBtn_srch_cnd_ListPutter(Btn_srch_cnd, "srch_cnd", "srch_cnd_key","srch_cnd_remark");

		}
		return Btn_srch_cnd_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_ScreenBookmarkForwardSetting create(){
		FSBAP_ScreenBookmarkForwardSetting p = new FSBAP_ScreenBookmarkForwardSetting();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_ScreenBookmarkForwardSetting create(String name){
		FSBAP_ScreenBookmarkForwardSetting p = new FSBAP_ScreenBookmarkForwardSetting(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_ScreenBookmarkForwardSetting_FW.jbfInitCnd((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbfInitDtl((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbfInitBtn((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbInitCnd((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbInitDtl((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.jbInitBtn((FSBAP_ScreenBookmarkForwardSetting)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FSBAP_ScreenBookmarkForwardSetting p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		// ブロックの項目の初期化
		p.Cnd_to_screen_id_Label = p.beansFactory.createLabel("Cnd.to_screen_id_Label");
		p.Cnd_to_screen_id = p.beansFactory.createTextField("Cnd.to_screen_id");
		p.Cnd_to_screen_id.setLabel(p.Cnd_to_screen_id_Label);
		p.Cnd_to_screen_nm = p.beansFactory.createTextField("Cnd.to_screen_nm");
		p.Cnd_from_screen_id_Label = p.beansFactory.createLabel("Cnd.from_screen_id_Label");
		p.Cnd_from_screen_id = p.beansFactory.createTextField("Cnd.from_screen_id");
		p.Cnd_from_screen_id.setLabel(p.Cnd_from_screen_id_Label);
		p.Cnd_from_screen_nm = p.beansFactory.createTextField("Cnd.from_screen_nm");
		p.Cnd_key_view = p.beansFactory.createCheckBox("Cnd.key_view");
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDtl(FSBAP_ScreenBookmarkForwardSetting p) {
		// ブロック関連の初期化
		p.DtlPanel = p.beansFactory.createPanel("Dtl");
		p.DtlScrollPane = p.beansFactory.createScrollPane("Dtl.scroll");
		p.createDtlTable();
		// ブロックの項目の初期化
		p.columnDtl_to_key = p.beansFactory.createTableColumn("Dtl.to_key", MCColumnType.TEXT);
		p.columnDtl_to_panel = p.beansFactory.createTableColumn("Dtl.to_panel", MCColumnType.TEXT);
		p.columnDtl_to_name = p.beansFactory.createTableColumn("Dtl.to_name", MCColumnType.TEXT);
		p.columnDtl_from_panel = p.beansFactory.createTableColumn("Dtl.from_panel", MCColumnType.TEXT);
		p.columnDtl_from_name = p.beansFactory.createTableColumn("Dtl.from_name", MCColumnType.TEXT_COMBO);
		p.columnDtl_from_key = p.beansFactory.createTableColumn("Dtl.from_key", MCColumnType.TEXT);
		p.columnDtl_text = p.beansFactory.createTableColumn("Dtl.text", MCColumnType.TEXT);
		p.columnDtl_check = p.beansFactory.createTableColumn("Dtl.check", MCColumnType.CHECK);
		p.columnDtl_radio = p.beansFactory.createTableColumn("Dtl.radio", MCColumnType.TEXT_COMBO);
		p.columnDtl_radio_nm = p.beansFactory.createTableColumn("Dtl.radio_nm", MCColumnType.TEXT);
		p.columnDtl_today_flg = p.beansFactory.createTableColumn("Dtl.today_flg", MCColumnType.CHECK);
		p.columnDtl_firstday_flg = p.beansFactory.createTableColumn("Dtl.firstday_flg", MCColumnType.CHECK);
		p.columnDtl_lastday_flg = p.beansFactory.createTableColumn("Dtl.lastday_flg", MCColumnType.CHECK);
		p.columnDtl_date = p.beansFactory.createTableColumn("Dtl.date", MCColumnType.TIMESTAMP);
		p.columnDtl_month = p.beansFactory.createTableColumn("Dtl.month", MCColumnType.NUMBER);
		p.columnDtl_week = p.beansFactory.createTableColumn("Dtl.week", MCColumnType.NUMBER);
		p.columnDtl_day_of_week_type = p.beansFactory.createTableColumn("Dtl.day_of_week_type", MCColumnType.TEXT_COMBO);
		p.columnDtl_day_of_week_type_nm = p.beansFactory.createTableColumn("Dtl.day_of_week_type_nm", MCColumnType.TEXT);
		p.columnDtl_day = p.beansFactory.createTableColumn("Dtl.day", MCColumnType.NUMBER);
		p.columnDtl_hour = p.beansFactory.createTableColumn("Dtl.hour", MCColumnType.NUMBER);
		p.columnDtl_minute = p.beansFactory.createTableColumn("Dtl.minute", MCColumnType.NUMBER);
		p.columnDtl_num = p.beansFactory.createTableColumn("Dtl.num", MCColumnType.NUMBER);
		p.cgDtl_to = p.beansFactory.createColumnGroup("Dtl.to");
		p.cgDtl_from = p.beansFactory.createColumnGroup("Dtl.from");
		p.cgDtl_from_fixed = p.beansFactory.createColumnGroup("Dtl.from_fixed");
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP_ScreenBookmarkForwardSetting p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_act_Label = p.beansFactory.createLabel("Btn.act_Label");
		p.Btn_act = p.beansFactory.createTextComboBox("Btn.act");
		p.Btn_act.setLabel(p.Btn_act_Label);
		p.Btn_act_key = p.beansFactory.createTextField("Btn.act_key");
		p.Btn_srch_cnd_Label = p.beansFactory.createLabel("Btn.srch_cnd_Label");
		p.Btn_srch_cnd = p.beansFactory.createTextComboBox("Btn.srch_cnd");
		p.Btn_srch_cnd.setLabel(p.Btn_srch_cnd_Label);
		p.Btn_srch_cnd_key = p.beansFactory.createTextField("Btn.srch_cnd_key");
		p.Btn_srch_cnd_remark = p.beansFactory.createTextField("Btn.srch_cnd_remark");
		p.Btn_upd = p.beansFactory.createButton("Btn.upd", "upd");
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FSBAP_ScreenBookmarkForwardSetting p) {
		// ブロック関連の初期化
		p.add(p.CndPanel);
		p.setLastBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.DtlPanel);
		p.CndPanel.setValueCheck(false);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.CndPanel.add(p.Cnd_to_screen_id_Label);
		p.CndPanel.add(p.Cnd_to_screen_id);
		p.CndPanel.setLastBeans(p.Cnd_to_screen_id);
		p.Cnd_to_screen_id.setNextBeans(p.Cnd_to_screen_nm);
		p.Cnd_to_screen_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0300.CndR.to_screen_id_META);
		p.CndPanel.add(p.Cnd_to_screen_nm);
		p.Cnd_to_screen_nm.setNextBeans(p.Cnd_from_screen_id);
		p.Cnd_to_screen_nm.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0300.CndR.to_screen_nm_META);
		p.CndPanel.add(p.Cnd_from_screen_id_Label);
		p.CndPanel.add(p.Cnd_from_screen_id);
		p.Cnd_from_screen_id.setNextBeans(p.Cnd_from_screen_nm);
		p.Cnd_from_screen_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0300.CndR.from_screen_id_META);
		p.CndPanel.add(p.Cnd_from_screen_nm);
		p.Cnd_from_screen_nm.setNextBeans(p.Cnd_key_view);
		p.Cnd_from_screen_nm.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0300.CndR.from_screen_nm_META);
		p.CndPanel.add(p.Cnd_key_view);
		p.Cnd_key_view.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0300.CndR.key_view_META);
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDtl(FSBAP_ScreenBookmarkForwardSetting p) {
		// ブロック関連の初期化
		p.add(p.DtlPanel);
		p.DtlPanel.setNextBeans(p.BtnPanel);
		p.DtlPanel.add(p.DtlScrollPane);
		p.DtlPanel.setLastBeans(p.DtlTable);
		p.DtlScrollPane.setViewportView(p.DtlTable);
		p.DtlTable.setList(p.getDtlL());
		p.DtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP_ScreenBookmarkForwardSetting p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_act.setListType(MCListType.STRICT);
		p.Btn_act.setLinkBeans(p.Btn_act_key);
		p.BtnPanel.add(p.Btn_act_Label);
		p.BtnPanel.add(p.Btn_act);
		p.BtnPanel.setLastBeans(p.Btn_act);
		p.Btn_act.setNextBeans(p.Btn_act_key);
		p.Btn_act.setRow(p.getBtnR(), mcframe.clientFSBA.FSBAP0300.BtnR.act_META);
		p.BtnPanel.add(p.Btn_act_key);
		p.Btn_act_key.setNextBeans(p.Btn_srch_cnd);
		p.Btn_act_key.setRow(p.getBtnR(), mcframe.clientFSBA.FSBAP0300.BtnR.act_key_META);
		p.Btn_srch_cnd.setListType(MCListType.STRICT);
		p.Btn_srch_cnd.setLinkBeans(p.Btn_srch_cnd_key,p.Btn_srch_cnd_remark);
		p.BtnPanel.add(p.Btn_srch_cnd_Label);
		p.BtnPanel.add(p.Btn_srch_cnd);
		p.Btn_srch_cnd.setNextBeans(p.Btn_srch_cnd_key);
		p.Btn_srch_cnd.setRow(p.getBtnR(), mcframe.clientFSBA.FSBAP0300.BtnR.srch_cnd_META);
		p.BtnPanel.add(p.Btn_srch_cnd_key);
		p.Btn_srch_cnd_key.setNextBeans(p.Btn_srch_cnd_remark);
		p.Btn_srch_cnd_key.setRow(p.getBtnR(), mcframe.clientFSBA.FSBAP0300.BtnR.srch_cnd_key_META);
		p.BtnPanel.add(p.Btn_srch_cnd_remark);
		p.Btn_srch_cnd_remark.setNextBeans(p.Btn_upd);
		p.Btn_srch_cnd_remark.setRow(p.getBtnR(), mcframe.clientFSBA.FSBAP0300.BtnR.srch_cnd_remark_META);
		p.Btn_upd.setIcon("REGISTER");
		p.Btn_upd.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_ScreenBookmarkForwardSetting_FW.mcInitCnd((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.mcInitDtl((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.mcInitBtn((FSBAP_ScreenBookmarkForwardSetting)this);

		// [INIT]ステータスのモードの設定
		FSBAP_ScreenBookmarkForwardSetting_FW.statusInitINIT_Cnd((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.statusInitINIT_Dtl((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.statusInitINIT_Btn((FSBAP_ScreenBookmarkForwardSetting)this);

		// [KEY]ステータスのモードの設定
		FSBAP_ScreenBookmarkForwardSetting_FW.statusInitKEY_Cnd((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.statusInitKEY_Dtl((FSBAP_ScreenBookmarkForwardSetting)this);
		FSBAP_ScreenBookmarkForwardSetting_FW.statusInitKEY_Btn((FSBAP_ScreenBookmarkForwardSetting)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FSBAP_ScreenBookmarkForwardSetting p) {
		p.Cnd_to_screen_id.setListListener(p);
		p.Cnd_to_screen_id.addAllListener(p);
		p.Cnd_to_screen_nm.setListListener(p);
		p.Cnd_to_screen_nm.addAllListener(p);
		p.Cnd_from_screen_id.setListListener(p);
		p.Cnd_from_screen_id.addAllListener(p);
		p.Cnd_from_screen_nm.setListListener(p);
		p.Cnd_from_screen_nm.addAllListener(p);
		p.Cnd_key_view.addAllListener(p);
	}

	/**
	 *  [Dtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDtl(FSBAP_ScreenBookmarkForwardSetting p) {
		p.DtlTable.addAllListener(p);
		p.columnDtl_to_key.addAllListener(p);
		p.columnDtl_to_key.setListListener(p);
		p.columnDtl_to_panel.addAllListener(p);
		p.columnDtl_to_panel.setListListener(p);
		p.columnDtl_to_name.addAllListener(p);
		p.columnDtl_to_name.setListListener(p);
		p.columnDtl_from_panel.addAllListener(p);
		p.columnDtl_from_panel.setListListener(p);
		p.columnDtl_from_name.addAllListener(p);
		p.columnDtl_from_name.setListListener(p);
		p.columnDtl_from_key.addAllListener(p);
		p.columnDtl_from_key.setListListener(p);
		p.columnDtl_text.addAllListener(p);
		p.columnDtl_text.setListListener(p);
		p.columnDtl_check.addAllListener(p);
		p.columnDtl_radio.addAllListener(p);
		p.columnDtl_radio.setListListener(p);
		p.columnDtl_radio_nm.addAllListener(p);
		p.columnDtl_radio_nm.setListListener(p);
		p.columnDtl_today_flg.addAllListener(p);
		p.columnDtl_firstday_flg.addAllListener(p);
		p.columnDtl_lastday_flg.addAllListener(p);
		p.columnDtl_date.addAllListener(p);
		p.columnDtl_date.setListListener(p);
		p.columnDtl_month.addAllListener(p);
		p.columnDtl_month.setListListener(p);
		p.columnDtl_week.addAllListener(p);
		p.columnDtl_week.setListListener(p);
		p.columnDtl_day_of_week_type.addAllListener(p);
		p.columnDtl_day_of_week_type.setListListener(p);
		p.columnDtl_day_of_week_type_nm.addAllListener(p);
		p.columnDtl_day_of_week_type_nm.setListListener(p);
		p.columnDtl_day.addAllListener(p);
		p.columnDtl_day.setListListener(p);
		p.columnDtl_hour.addAllListener(p);
		p.columnDtl_hour.setListListener(p);
		p.columnDtl_minute.addAllListener(p);
		p.columnDtl_minute.setListListener(p);
		p.columnDtl_num.addAllListener(p);
		p.columnDtl_num.setListListener(p);
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP_ScreenBookmarkForwardSetting p) {
		p.Btn_act.setListListener(p);
		p.Btn_act.addAllListener(p);
		p.Btn_act_key.setListListener(p);
		p.Btn_act_key.addAllListener(p);
		p.Btn_srch_cnd.setListListener(p);
		p.Btn_srch_cnd.addAllListener(p);
		p.Btn_srch_cnd_key.setListListener(p);
		p.Btn_srch_cnd_key.addAllListener(p);
		p.Btn_srch_cnd_remark.setListListener(p);
		p.Btn_srch_cnd_remark.addAllListener(p);
		p.Btn_upd.addAllListener(p);
		p.Btn_upd.setAPMethodName("doBtn_upd");
	}

	/**
	 * [INIT]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Cnd(FSBAP_ScreenBookmarkForwardSetting p){
		p.Cnd_to_screen_id.putMode(p, INIT, MCMode.READ_ONLY);
		p.Cnd_to_screen_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.Cnd_from_screen_id.putMode(p, INIT, MCMode.READ_ONLY);
		p.Cnd_from_screen_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.Cnd_key_view.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dtl(FSBAP_ScreenBookmarkForwardSetting p){
		p.columnDtl_to_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnDtl_to_panel.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnDtl_to_name.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnDtl_from_panel.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnDtl_from_name.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_from_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnDtl_text.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_check.putMode(p, INIT, MCMode.REQUIRED);
		p.columnDtl_radio.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_radio_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnDtl_today_flg.putMode(p, INIT, MCMode.REQUIRED);
		p.columnDtl_firstday_flg.putMode(p, INIT, MCMode.REQUIRED);
		p.columnDtl_lastday_flg.putMode(p, INIT, MCMode.REQUIRED);
		p.columnDtl_date.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_month.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_week.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_day_of_week_type.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_day_of_week_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnDtl_day.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_hour.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_minute.putMode(p, INIT, MCMode.ENABLE);
		p.columnDtl_num.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP_ScreenBookmarkForwardSetting p){
		p.Btn_act.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_act_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_srch_cnd.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_srch_cnd_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_srch_cnd_remark.putMode(p, INIT, MCMode.READ_ONLY);
		p.Btn_upd.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [KEY]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitKEY_Cnd(FSBAP_ScreenBookmarkForwardSetting p){
		p.Cnd_to_screen_id.putMode(p, KEY, MCMode.READ_ONLY);
		p.Cnd_to_screen_nm.putMode(p, KEY, MCMode.READ_ONLY);
		p.Cnd_from_screen_id.putMode(p, KEY, MCMode.READ_ONLY);
		p.Cnd_from_screen_nm.putMode(p, KEY, MCMode.READ_ONLY);
		p.Cnd_key_view.putMode(p, KEY, MCMode.ENABLE);

	}

	/**
	 * [KEY]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitKEY_Dtl(FSBAP_ScreenBookmarkForwardSetting p){
		p.columnDtl_to_key.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_to_panel.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_to_name.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_from_panel.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_from_name.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_from_key.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_text.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_check.putMode(p, KEY, MCMode.REQUIRED);
		p.columnDtl_radio.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_radio_nm.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_today_flg.putMode(p, KEY, MCMode.REQUIRED);
		p.columnDtl_firstday_flg.putMode(p, KEY, MCMode.REQUIRED);
		p.columnDtl_lastday_flg.putMode(p, KEY, MCMode.REQUIRED);
		p.columnDtl_date.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_month.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_week.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_day_of_week_type.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_day_of_week_type_nm.putMode(p, KEY, MCMode.READ_ONLY);
		p.columnDtl_day.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_hour.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_minute.putMode(p, KEY, MCMode.ENABLE);
		p.columnDtl_num.putMode(p, KEY, MCMode.ENABLE);

	}

	/**
	 * [KEY]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitKEY_Btn(FSBAP_ScreenBookmarkForwardSetting p){
		p.Btn_act.putMode(p, KEY, MCMode.ENABLE);
		p.Btn_act_key.putMode(p, KEY, MCMode.READ_ONLY);
		p.Btn_srch_cnd.putMode(p, KEY, MCMode.ENABLE);
		p.Btn_srch_cnd_key.putMode(p, KEY, MCMode.INVISIBLE);
		p.Btn_srch_cnd_remark.putMode(p, KEY, MCMode.READ_ONLY);
		p.Btn_upd.putMode(p, KEY, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_ScreenBookmarkForwardSetting_FW.setTableConfigDtl((FSBAP_ScreenBookmarkForwardSetting)this);
	}

	/**
	 * [Dtl]ブロックのTableの設定
	 */
	protected static void setTableConfigDtl(FSBAP_ScreenBookmarkForwardSetting p) {
		p.columnDtl_to_key.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.to_key_META);
		p.DtlTable.addColumnConfig(p.columnDtl_to_key);
		p.columnDtl_to_panel.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.to_panel_META);
		p.DtlTable.addColumnConfig(p.columnDtl_to_panel);
		p.columnDtl_to_name.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.to_name_META);
		p.DtlTable.addColumnConfig(p.columnDtl_to_name);
		p.columnDtl_from_panel.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.from_panel_META);
		p.DtlTable.addColumnConfig(p.columnDtl_from_panel);
		p.columnDtl_from_name.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.from_name_META);
		p.columnDtl_from_name.addLinkBeans(p.columnDtl_from_panel,p.columnDtl_from_key);
		p.DtlTable.addColumnConfig(p.columnDtl_from_name);
		p.columnDtl_from_key.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.from_key_META);
		p.DtlTable.addColumnConfig(p.columnDtl_from_key);
		p.columnDtl_text.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.text_META);
		p.DtlTable.addColumnConfig(p.columnDtl_text);
		p.columnDtl_check.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.check_META);
		p.DtlTable.addColumnConfig(p.columnDtl_check);
		p.columnDtl_radio.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.radio_META);
		p.columnDtl_radio.addLinkBeans(p.columnDtl_radio_nm);
		p.DtlTable.addColumnConfig(p.columnDtl_radio);
		p.columnDtl_radio_nm.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.radio_nm_META);
		p.DtlTable.addColumnConfig(p.columnDtl_radio_nm);
		p.columnDtl_today_flg.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.today_flg_META);
		p.DtlTable.addColumnConfig(p.columnDtl_today_flg);
		p.columnDtl_firstday_flg.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.firstday_flg_META);
		p.DtlTable.addColumnConfig(p.columnDtl_firstday_flg);
		p.columnDtl_lastday_flg.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.lastday_flg_META);
		p.DtlTable.addColumnConfig(p.columnDtl_lastday_flg);
		p.columnDtl_date.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.date_META);
		p.columnDtl_date.setFormatID("YMDHMSS");
		p.DtlTable.addColumnConfig(p.columnDtl_date);
		p.columnDtl_month.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.month_META);
		p.DtlTable.addColumnConfig(p.columnDtl_month);
		p.columnDtl_week.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.week_META);
		p.DtlTable.addColumnConfig(p.columnDtl_week);
		p.columnDtl_day_of_week_type.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.day_of_week_type_META);
		p.columnDtl_day_of_week_type.addLinkBeans(p.columnDtl_day_of_week_type_nm);
		p.DtlTable.addColumnConfig(p.columnDtl_day_of_week_type);
		p.columnDtl_day_of_week_type_nm.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.day_of_week_type_nm_META);
		p.DtlTable.addColumnConfig(p.columnDtl_day_of_week_type_nm);
		p.columnDtl_day.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.day_META);
		p.DtlTable.addColumnConfig(p.columnDtl_day);
		p.columnDtl_hour.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.hour_META);
		p.DtlTable.addColumnConfig(p.columnDtl_hour);
		p.columnDtl_minute.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.minute_META);
		p.DtlTable.addColumnConfig(p.columnDtl_minute);
		p.columnDtl_num.setMeta(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.num_META);
		p.DtlTable.addColumnConfig(p.columnDtl_num);
		p.cgDtl_to.add(p.columnDtl_to_key);
		p.cgDtl_to.add(p.columnDtl_to_panel);
		p.cgDtl_to.add(p.columnDtl_to_name);
		p.DtlTable.addColumnGroup(p.cgDtl_to);
		p.cgDtl_from.add(p.columnDtl_from_panel);
		p.cgDtl_from.add(p.columnDtl_from_name);
		p.cgDtl_from.add(p.columnDtl_from_key);
		p.DtlTable.addColumnGroup(p.cgDtl_from);
		p.cgDtl_from_fixed.add(p.columnDtl_text);
		p.cgDtl_from_fixed.add(p.columnDtl_check);
		p.cgDtl_from_fixed.add(p.columnDtl_radio);
		p.cgDtl_from_fixed.add(p.columnDtl_radio_nm);
		p.cgDtl_from_fixed.add(p.columnDtl_today_flg);
		p.cgDtl_from_fixed.add(p.columnDtl_firstday_flg);
		p.cgDtl_from_fixed.add(p.columnDtl_lastday_flg);
		p.cgDtl_from_fixed.add(p.columnDtl_date);
		p.cgDtl_from_fixed.add(p.columnDtl_month);
		p.cgDtl_from_fixed.add(p.columnDtl_week);
		p.cgDtl_from_fixed.add(p.columnDtl_day_of_week_type);
		p.cgDtl_from_fixed.add(p.columnDtl_day_of_week_type_nm);
		p.cgDtl_from_fixed.add(p.columnDtl_day);
		p.cgDtl_from_fixed.add(p.columnDtl_hour);
		p.cgDtl_from_fixed.add(p.columnDtl_minute);
		p.cgDtl_from_fixed.add(p.columnDtl_num);
		p.DtlTable.addColumnGroup(p.cgDtl_from_fixed);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnDtl_from_name.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnDtl_from_name.getListConfig().setPutter(getDtl_from_name_ListPutter());
		columnDtl_radio.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnDtl_radio.getListConfig().setPutter(getDtl_radio_ListPutter());
		columnDtl_day_of_week_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnDtl_day_of_week_type.getListConfig().setPutter(getDtl_day_of_week_type_ListPutter());
		Btn_act.setListVisibleColumn(MCListLogic.getViewColumnName());
		Btn_act.getListConfig().setPutter(getBtn_act_ListPutter());
		Btn_srch_cnd.setListVisibleColumn(MCListLogic.getViewColumnName());
		Btn_srch_cnd.getListConfig().setPutter(getBtn_srch_cnd_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[KEY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setKEYStatus() {
		status = KEY;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (KEY.equals(status)) {
			setKEYStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Dtl_from_name_ListPutter]の作成
	 */
	protected MCListPutter createDtl_from_name_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Dtl_radio_ListPutter]の作成
	 */
	protected MCListPutter createDtl_radio_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Dtl_day_of_week_type_ListPutter]の作成
	 */
	protected MCListPutter createDtl_day_of_week_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.DayOfWeekType");
		return lp;
	}
	 
	/**
	 * [Btn_act_ListPutter]の作成
	 */
	protected MCListPutter createBtn_act_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Btn_srch_cnd_ListPutter]の作成
	 */
	protected MCListPutter createBtn_srch_cnd_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnDtl_from_name) return getDtl_from_name(row, info);
		if(combo == columnDtl_radio) return getDtl_radio(row, info);
		if(combo == columnDtl_day_of_week_type) return getDtl_day_of_week_type(row, info);
		if(combo == Btn_act) return getBtn_act(row, info);
		if(combo == Btn_srch_cnd) return getBtn_srch_cnd(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_upd) doBtn_upd(info);
	}

	/**
	 * [Btn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == DtlTable) return doDtl_VC(info);
		if (vc == Cnd_to_screen_id) return doCnd_to_screen_id_VC(info);
		if (vc == Cnd_to_screen_nm) return doCnd_to_screen_nm_VC(info);
		if (vc == Cnd_from_screen_id) return doCnd_from_screen_id_VC(info);
		if (vc == Cnd_from_screen_nm) return doCnd_from_screen_nm_VC(info);
		if (vc == Cnd_key_view) return doCnd_key_view_VC(info);
		if (vc == columnDtl_to_key) return doDtl_to_key_VC(info);
		if (vc == columnDtl_to_panel) return doDtl_to_panel_VC(info);
		if (vc == columnDtl_to_name) return doDtl_to_name_VC(info);
		if (vc == columnDtl_from_panel) return doDtl_from_panel_VC(info);
		if (vc == columnDtl_from_name) return doDtl_from_name_VC(info);
		if (vc == columnDtl_from_key) return doDtl_from_key_VC(info);
		if (vc == columnDtl_text) return doDtl_text_VC(info);
		if (vc == columnDtl_check) return doDtl_check_VC(info);
		if (vc == columnDtl_radio) return doDtl_radio_VC(info);
		if (vc == columnDtl_radio_nm) return doDtl_radio_nm_VC(info);
		if (vc == columnDtl_today_flg) return doDtl_today_flg_VC(info);
		if (vc == columnDtl_firstday_flg) return doDtl_firstday_flg_VC(info);
		if (vc == columnDtl_lastday_flg) return doDtl_lastday_flg_VC(info);
		if (vc == columnDtl_date) return doDtl_date_VC(info);
		if (vc == columnDtl_month) return doDtl_month_VC(info);
		if (vc == columnDtl_week) return doDtl_week_VC(info);
		if (vc == columnDtl_day_of_week_type) return doDtl_day_of_week_type_VC(info);
		if (vc == columnDtl_day_of_week_type_nm) return doDtl_day_of_week_type_nm_VC(info);
		if (vc == columnDtl_day) return doDtl_day_VC(info);
		if (vc == columnDtl_hour) return doDtl_hour_VC(info);
		if (vc == columnDtl_minute) return doDtl_minute_VC(info);
		if (vc == columnDtl_num) return doDtl_num_VC(info);
		if (vc == Btn_act) return doBtn_act_VC(info);
		if (vc == Btn_act_key) return doBtn_act_key_VC(info);
		if (vc == Btn_srch_cnd) return doBtn_srch_cnd_VC(info);
		if (vc == Btn_srch_cnd_key) return doBtn_srch_cnd_key_VC(info);
		if (vc == Btn_srch_cnd_remark) return doBtn_srch_cnd_remark_VC(info);
		return true;
	}

	/**
	 * [Dtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[to_screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_to_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[to_screen_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_to_screen_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[from_screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_from_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[from_screen_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_from_screen_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[key_view]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_key_view_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[to_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_to_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[to_panel]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_to_panel_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[to_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_to_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[from_panel]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_from_panel_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[from_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_from_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[from_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_from_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[text]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_text_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[check]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_check_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[radio]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_radio_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[radio_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_radio_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[today_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_today_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[firstday_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_firstday_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[lastday_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_lastday_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[date]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_date_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[month]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_month_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[week]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_week_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[day_of_week_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_day_of_week_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[day_of_week_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_day_of_week_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[day]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_day_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[hour]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_hour_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[minute]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_minute_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[num]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_num_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[act]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_act_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[act_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_act_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[srch_cnd]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_srch_cnd_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[srch_cnd_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_srch_cnd_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[srch_cnd_remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_srch_cnd_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == DtlTable) doDtl_NC(info);
		else if (nc == Cnd_to_screen_id) doCnd_to_screen_id_NC(info);
		else if (nc == Cnd_to_screen_nm) doCnd_to_screen_nm_NC(info);
		else if (nc == Cnd_from_screen_id) doCnd_from_screen_id_NC(info);
		else if (nc == Cnd_from_screen_nm) doCnd_from_screen_nm_NC(info);
		else if (nc == Cnd_key_view) doCnd_key_view_NC(info);
		else if (nc == columnDtl_to_key) doDtl_to_key_NC(info);
		else if (nc == columnDtl_to_panel) doDtl_to_panel_NC(info);
		else if (nc == columnDtl_to_name) doDtl_to_name_NC(info);
		else if (nc == columnDtl_from_panel) doDtl_from_panel_NC(info);
		else if (nc == columnDtl_from_name) doDtl_from_name_NC(info);
		else if (nc == columnDtl_from_key) doDtl_from_key_NC(info);
		else if (nc == columnDtl_text) doDtl_text_NC(info);
		else if (nc == columnDtl_check) doDtl_check_NC(info);
		else if (nc == columnDtl_radio) doDtl_radio_NC(info);
		else if (nc == columnDtl_radio_nm) doDtl_radio_nm_NC(info);
		else if (nc == columnDtl_today_flg) doDtl_today_flg_NC(info);
		else if (nc == columnDtl_firstday_flg) doDtl_firstday_flg_NC(info);
		else if (nc == columnDtl_lastday_flg) doDtl_lastday_flg_NC(info);
		else if (nc == columnDtl_date) doDtl_date_NC(info);
		else if (nc == columnDtl_month) doDtl_month_NC(info);
		else if (nc == columnDtl_week) doDtl_week_NC(info);
		else if (nc == columnDtl_day_of_week_type) doDtl_day_of_week_type_NC(info);
		else if (nc == columnDtl_day_of_week_type_nm) doDtl_day_of_week_type_nm_NC(info);
		else if (nc == columnDtl_day) doDtl_day_NC(info);
		else if (nc == columnDtl_hour) doDtl_hour_NC(info);
		else if (nc == columnDtl_minute) doDtl_minute_NC(info);
		else if (nc == columnDtl_num) doDtl_num_NC(info);
		else if (nc == Btn_act) doBtn_act_NC(info);
		else if (nc == Btn_act_key) doBtn_act_key_NC(info);
		else if (nc == Btn_srch_cnd) doBtn_srch_cnd_NC(info);
		else if (nc == Btn_srch_cnd_key) doBtn_srch_cnd_key_NC(info);
		else if (nc == Btn_srch_cnd_remark) doBtn_srch_cnd_remark_NC(info);
	}

	/**
	 * [Dtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_nm_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_nm_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[key_view]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_key_view_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_key_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_panel]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_panel_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_name_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_panel]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_panel_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_name_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_key_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[text]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_text_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[check]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_check_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_nm_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[today_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_today_flg_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[firstday_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_firstday_flg_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lastday_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lastday_flg_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[date]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_date_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[month]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_month_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[week]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_week_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[hour]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_hour_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[minute]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_minute_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[num]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_num_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_key_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_key_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_remark_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == DtlTable) doDtl_NE(info);
		else if (ne == Cnd_to_screen_id) doCnd_to_screen_id_NE(info);
		else if (ne == Cnd_to_screen_nm) doCnd_to_screen_nm_NE(info);
		else if (ne == Cnd_from_screen_id) doCnd_from_screen_id_NE(info);
		else if (ne == Cnd_from_screen_nm) doCnd_from_screen_nm_NE(info);
		else if (ne == Cnd_key_view) doCnd_key_view_NE(info);
		else if (ne == columnDtl_to_key) doDtl_to_key_NE(info);
		else if (ne == columnDtl_to_panel) doDtl_to_panel_NE(info);
		else if (ne == columnDtl_to_name) doDtl_to_name_NE(info);
		else if (ne == columnDtl_from_panel) doDtl_from_panel_NE(info);
		else if (ne == columnDtl_from_name) doDtl_from_name_NE(info);
		else if (ne == columnDtl_from_key) doDtl_from_key_NE(info);
		else if (ne == columnDtl_text) doDtl_text_NE(info);
		else if (ne == columnDtl_check) doDtl_check_NE(info);
		else if (ne == columnDtl_radio) doDtl_radio_NE(info);
		else if (ne == columnDtl_radio_nm) doDtl_radio_nm_NE(info);
		else if (ne == columnDtl_today_flg) doDtl_today_flg_NE(info);
		else if (ne == columnDtl_firstday_flg) doDtl_firstday_flg_NE(info);
		else if (ne == columnDtl_lastday_flg) doDtl_lastday_flg_NE(info);
		else if (ne == columnDtl_date) doDtl_date_NE(info);
		else if (ne == columnDtl_month) doDtl_month_NE(info);
		else if (ne == columnDtl_week) doDtl_week_NE(info);
		else if (ne == columnDtl_day_of_week_type) doDtl_day_of_week_type_NE(info);
		else if (ne == columnDtl_day_of_week_type_nm) doDtl_day_of_week_type_nm_NE(info);
		else if (ne == columnDtl_day) doDtl_day_NE(info);
		else if (ne == columnDtl_hour) doDtl_hour_NE(info);
		else if (ne == columnDtl_minute) doDtl_minute_NE(info);
		else if (ne == columnDtl_num) doDtl_num_NE(info);
		else if (ne == Btn_act) doBtn_act_NE(info);
		else if (ne == Btn_act_key) doBtn_act_key_NE(info);
		else if (ne == Btn_srch_cnd) doBtn_srch_cnd_NE(info);
		else if (ne == Btn_srch_cnd_key) doBtn_srch_cnd_key_NE(info);
		else if (ne == Btn_srch_cnd_remark) doBtn_srch_cnd_remark_NE(info);
	}

	/**
	 * [Dtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_nm_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_nm_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[key_view]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_key_view_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_key_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_panel]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_panel_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_name_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_panel]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_panel_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_name_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_key_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[text]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_text_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[check]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_check_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_nm_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[today_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_today_flg_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[firstday_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_firstday_flg_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lastday_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lastday_flg_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[date]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_date_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[month]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_month_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[week]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_week_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[hour]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_hour_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[minute]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_minute_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[num]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_num_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_key_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_key_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_remark_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == DtlTable) doDtl_NX(info);
		else if (nx == Cnd_to_screen_id) doCnd_to_screen_id_NX(info);
		else if (nx == Cnd_to_screen_nm) doCnd_to_screen_nm_NX(info);
		else if (nx == Cnd_from_screen_id) doCnd_from_screen_id_NX(info);
		else if (nx == Cnd_from_screen_nm) doCnd_from_screen_nm_NX(info);
		else if (nx == Cnd_key_view) doCnd_key_view_NX(info);
		else if (nx == columnDtl_to_key) doDtl_to_key_NX(info);
		else if (nx == columnDtl_to_panel) doDtl_to_panel_NX(info);
		else if (nx == columnDtl_to_name) doDtl_to_name_NX(info);
		else if (nx == columnDtl_from_panel) doDtl_from_panel_NX(info);
		else if (nx == columnDtl_from_name) doDtl_from_name_NX(info);
		else if (nx == columnDtl_from_key) doDtl_from_key_NX(info);
		else if (nx == columnDtl_text) doDtl_text_NX(info);
		else if (nx == columnDtl_check) doDtl_check_NX(info);
		else if (nx == columnDtl_radio) doDtl_radio_NX(info);
		else if (nx == columnDtl_radio_nm) doDtl_radio_nm_NX(info);
		else if (nx == columnDtl_today_flg) doDtl_today_flg_NX(info);
		else if (nx == columnDtl_firstday_flg) doDtl_firstday_flg_NX(info);
		else if (nx == columnDtl_lastday_flg) doDtl_lastday_flg_NX(info);
		else if (nx == columnDtl_date) doDtl_date_NX(info);
		else if (nx == columnDtl_month) doDtl_month_NX(info);
		else if (nx == columnDtl_week) doDtl_week_NX(info);
		else if (nx == columnDtl_day_of_week_type) doDtl_day_of_week_type_NX(info);
		else if (nx == columnDtl_day_of_week_type_nm) doDtl_day_of_week_type_nm_NX(info);
		else if (nx == columnDtl_day) doDtl_day_NX(info);
		else if (nx == columnDtl_hour) doDtl_hour_NX(info);
		else if (nx == columnDtl_minute) doDtl_minute_NX(info);
		else if (nx == columnDtl_num) doDtl_num_NX(info);
		else if (nx == Btn_act) doBtn_act_NX(info);
		else if (nx == Btn_act_key) doBtn_act_key_NX(info);
		else if (nx == Btn_srch_cnd) doBtn_srch_cnd_NX(info);
		else if (nx == Btn_srch_cnd_key) doBtn_srch_cnd_key_NX(info);
		else if (nx == Btn_srch_cnd_remark) doBtn_srch_cnd_remark_NX(info);
	}

	/**
	 * [Dtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_nm_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_nm_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[key_view]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_key_view_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_key_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_panel]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_panel_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_name_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_panel]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_panel_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_name_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_key_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[text]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_text_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[check]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_check_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_nm_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[today_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_today_flg_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[firstday_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_firstday_flg_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lastday_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lastday_flg_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[date]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_date_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[month]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_month_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[week]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_week_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[hour]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_hour_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[minute]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_minute_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[num]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_num_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_key_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_key_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_remark_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_to_screen_id) doCnd_to_screen_id_LC(info);
		else if (lc == Cnd_to_screen_nm) doCnd_to_screen_nm_LC(info);
		else if (lc == Cnd_from_screen_id) doCnd_from_screen_id_LC(info);
		else if (lc == Cnd_from_screen_nm) doCnd_from_screen_nm_LC(info);
		else if (lc == columnDtl_to_key) doDtl_to_key_LC(info);
		else if (lc == columnDtl_to_panel) doDtl_to_panel_LC(info);
		else if (lc == columnDtl_to_name) doDtl_to_name_LC(info);
		else if (lc == columnDtl_from_panel) doDtl_from_panel_LC(info);
		else if (lc == columnDtl_from_name) doDtl_from_name_LC(info);
		else if (lc == columnDtl_from_key) doDtl_from_key_LC(info);
		else if (lc == columnDtl_text) doDtl_text_LC(info);
		else if (lc == columnDtl_radio) doDtl_radio_LC(info);
		else if (lc == columnDtl_radio_nm) doDtl_radio_nm_LC(info);
		else if (lc == columnDtl_date) doDtl_date_LC(info);
		else if (lc == columnDtl_month) doDtl_month_LC(info);
		else if (lc == columnDtl_week) doDtl_week_LC(info);
		else if (lc == columnDtl_day_of_week_type) doDtl_day_of_week_type_LC(info);
		else if (lc == columnDtl_day_of_week_type_nm) doDtl_day_of_week_type_nm_LC(info);
		else if (lc == columnDtl_day) doDtl_day_LC(info);
		else if (lc == columnDtl_hour) doDtl_hour_LC(info);
		else if (lc == columnDtl_minute) doDtl_minute_LC(info);
		else if (lc == columnDtl_num) doDtl_num_LC(info);
		else if (lc == Btn_act) doBtn_act_LC(info);
		else if (lc == Btn_act_key) doBtn_act_key_LC(info);
		else if (lc == Btn_srch_cnd) doBtn_srch_cnd_LC(info);
		else if (lc == Btn_srch_cnd_key) doBtn_srch_cnd_key_LC(info);
		else if (lc == Btn_srch_cnd_remark) doBtn_srch_cnd_remark_LC(info);
	}

	/**
	 * [Cnd]パネルの[to_screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[to_screen_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_to_screen_nm_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[from_screen_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_from_screen_nm_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_key_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_panel]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_panel_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[to_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_to_name_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_panel]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_panel_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_name_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[from_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_from_key_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[text]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_text_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[radio_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_radio_nm_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[date]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_date_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[month]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_month_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[week]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_week_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day_of_week_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_of_week_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[day]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_day_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[hour]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_hour_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[minute]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_minute_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[num]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_num_LC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_LC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[act_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_act_key_LC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_LC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_key_LC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[srch_cnd_remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_srch_cnd_remark_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnDtl_from_name]の作成メソッド
	 */
	public MCList getDtl_from_name(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnDtl_radio]の作成メソッド
	 */
	public MCList getDtl_radio(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnDtl_day_of_week_type]の作成メソッド
	 */
	public MCList getDtl_day_of_week_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getDayOfWeekType(row, info);
	}

	/**
	 * コンボ／リストのリスト[Btn_act]の作成メソッド
	 */
	public MCList getBtn_act(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[Btn_srch_cnd]の作成メソッド
	 */
	public MCList getBtn_srch_cnd(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}