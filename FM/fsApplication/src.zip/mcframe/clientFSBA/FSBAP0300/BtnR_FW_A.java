package mcframe.clientFSBA.FSBAP0300;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Btn"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BtnR_FW_A extends MCConstRow {

	/**
	 *  表示時動作.<p>
	 *
	 */
	public static final String $act = "act";
	/**
	 *  表示時動作識別キー.<p>
	 *
	 */
	public static final String $act_key = "act_key";
	/**
	 *  入力値設定.<p>
	 *
	 */
	public static final String $srch_cnd = "srch_cnd";
	/**
	 *  入力値設定情報キー.<p>
	 *
	 */
	public static final String $srch_cnd_key = "srch_cnd_key";
	/**
	 *  入力値設定備考.<p>
	 *
	 */
	public static final String $srch_cnd_remark = "srch_cnd_remark";


	public static final MCMeta act_META = createStringMeta($act);
	public static final MCMeta act_key_META = createStringMeta($act_key);
	public static final MCMeta srch_cnd_META = createStringMeta($srch_cnd);
	public static final MCMeta srch_cnd_key_META = createStringMeta($srch_cnd_key);
	public static final MCMeta srch_cnd_remark_META = createStringMeta($srch_cnd_remark);

	protected static final ConstMetaList<BtnR> constMetas = new ConstMetaList<BtnR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			act_META,
			act_key_META,
			srch_cnd_META,
			srch_cnd_key_META,
			srch_cnd_remark_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BtnR_FW_A(ConstMetaList<? extends BtnR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtnR clone() {
		return (BtnR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtnR createInstance() {
		return (BtnR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtnR getValues(String... names) {
		return (BtnR) super.getValues(names);
	}



	/**
	 *  表示時動作.<p>
	 *
	 */
	public String act() {
		return getConstString(offset + 0, $act);
	}

	/**
	 *  表示時動作.<p>
	 *
	 */
	public void act(String value) {
		setConstString(offset + 0, $act, value);
	}


	/**
	 *  表示時動作識別キー.<p>
	 *
	 */
	public String act_key() {
		return getConstString(offset + 1, $act_key);
	}

	/**
	 *  表示時動作識別キー.<p>
	 *
	 */
	public void act_key(String value) {
		setConstString(offset + 1, $act_key, value);
	}


	/**
	 *  入力値設定.<p>
	 *
	 */
	public String srch_cnd() {
		return getConstString(offset + 2, $srch_cnd);
	}

	/**
	 *  入力値設定.<p>
	 *
	 */
	public void srch_cnd(String value) {
		setConstString(offset + 2, $srch_cnd, value);
	}


	/**
	 *  入力値設定情報キー.<p>
	 *
	 */
	public String srch_cnd_key() {
		return getConstString(offset + 3, $srch_cnd_key);
	}

	/**
	 *  入力値設定情報キー.<p>
	 *
	 */
	public void srch_cnd_key(String value) {
		setConstString(offset + 3, $srch_cnd_key, value);
	}


	/**
	 *  入力値設定備考.<p>
	 *
	 */
	public String srch_cnd_remark() {
		return getConstString(offset + 4, $srch_cnd_remark);
	}

	/**
	 *  入力値設定備考.<p>
	 *
	 */
	public void srch_cnd_remark(String value) {
		setConstString(offset + 4, $srch_cnd_remark, value);
	}


	public String getString(String name) {
		if ($act.equalsIgnoreCase(name)) {
			return act();
		}
		if ($act_key.equalsIgnoreCase(name)) {
			return act_key();
		}
		if ($srch_cnd.equalsIgnoreCase(name)) {
			return srch_cnd();
		}
		if ($srch_cnd_key.equalsIgnoreCase(name)) {
			return srch_cnd_key();
		}
		if ($srch_cnd_remark.equalsIgnoreCase(name)) {
			return srch_cnd_remark();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($act.equalsIgnoreCase(name)) {
			return act();
		}
		if ($act_key.equalsIgnoreCase(name)) {
			return act_key();
		}
		if ($srch_cnd.equalsIgnoreCase(name)) {
			return srch_cnd();
		}
		if ($srch_cnd_key.equalsIgnoreCase(name)) {
			return srch_cnd_key();
		}
		if ($srch_cnd_remark.equalsIgnoreCase(name)) {
			return srch_cnd_remark();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($act.equalsIgnoreCase(name)) {
			act(value);
			return;
		}
		if ($act_key.equalsIgnoreCase(name)) {
			act_key(value);
			return;
		}
		if ($srch_cnd.equalsIgnoreCase(name)) {
			srch_cnd(value);
			return;
		}
		if ($srch_cnd_key.equalsIgnoreCase(name)) {
			srch_cnd_key(value);
			return;
		}
		if ($srch_cnd_remark.equalsIgnoreCase(name)) {
			srch_cnd_remark(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($act.equalsIgnoreCase(name)) {
			act(value);
			return;
		}
		if ($act_key.equalsIgnoreCase(name)) {
			act_key(value);
			return;
		}
		if ($srch_cnd.equalsIgnoreCase(name)) {
			srch_cnd(value);
			return;
		}
		if ($srch_cnd_key.equalsIgnoreCase(name)) {
			srch_cnd_key(value);
			return;
		}
		if ($srch_cnd_remark.equalsIgnoreCase(name)) {
			srch_cnd_remark(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

