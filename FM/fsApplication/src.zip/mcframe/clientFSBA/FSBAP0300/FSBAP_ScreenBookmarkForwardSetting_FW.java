package mcframe.clientFSBA.FSBAP0300;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFXUC.FXUCP0040.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.HashMap;
import mcframe.commonCore.util.MCCollectionUtil;
import java.util.Map;
import mcframe.clientCore.beans.layout.MCHiresoManager;
import java.util.Optional;
import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.table.TableCellEditor;

import static mcframe.clientFXUC.FXUCP0040.FXUCP_ToolBarUtil.*;

import mcframe.clientCore.container.MCRowEvent;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListConfig;
import mcframe.clientCore.beans.popup.MCCustomPopup;
import mcframe.clientCore.beans.popup.MCCustomPopupPanel;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
import mcframe.clientCore.beans.text.MCCalendarPattern;
import mcframe.clientCore.beans.text.MCTimestampFormat;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0110.FXBAP_RowListener;
import mcframe.clientFXUC.FXUCP0040.OpenScreenParamR;
import mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.commonFS.constant.FSC_BOOKMARK_FW_ACT;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;

import mcframe.clientCore.resource.MCConst;
import mcframe.clientFXUC.FXUCP0070.SrchCndInfo;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_ScreenBookmarkForwardSetting"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_ScreenBookmarkForwardSetting_FW extends FSBAP_ScreenBookmarkForwardSetting_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 連携先の実行ボタンを表す定数です。
	 */
	protected final String ACTION_KEY = "$action$";

	/**
	 * 親画面（ブックマーク設定画面）です。
	 */
	protected mcframe.clientFSBA.FSBAP0290.FSBAP_ScreenBookmarkSetting parent;

	/**
	 * 連携パラメータを設定するブックマーク設定画面のRowです。
	 */
	protected mcframe.clientFSBA.FSBAP0290.DtlR target;

	
	/**
	 * 検索枠の GUI 部品のリストです。<p>
	 * String（Key）、MCRowBeans（GUI部品）
	 */
	protected Map<String, MCRowBeans> _to_compos = new HashMap<>();

	/**
	 *  連携先画面です。
	 */
	private MCRootPanel _to = null;

	/**
	 * 遷移元（固定値）から名称カラムを除いたカラムの配列です。
	 */
	MCColumnConfig[] _fr_fixed_col_expt_nm = null;
	
	/**
	 * バインド行のためのRowリスナを保持しているかどうかを表す項目です。
	 */
	private String _$has_row_lsnr = "_has_row_lsnr";
	
	/**
	 * ポップアップです。
	 */
	private MCCustomPopup _popup = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ScreenBookmarkForwardSetting_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ScreenBookmarkForwardSetting_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void doCnd_key_view_NC(MCEventInfo info) {
		if (getCndR().key_view()) {
			setKEYStatus();
		}
		else {
			setINITStatus();
		}
	}

	/**
	 * Panel[Btn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doBtn_upd(MCEventInfo info) {
		if (parent != null) {
			if (confirm(FXUCP0031) != MCMessageBox.YES_OPTION) {
				return;
			}

			MCList<OpenScreenParamR> paramList = getDtlL().createInstance();

			// 連携パラメータ
			for (OpenScreenParamR r : getDtlL()) {
				if (!isNotFrColInput(r)) {
					r = r.clone();
					// paramキーを項目とする
					r.base_param_key(r.from_key());
					r.open_param_key(r.to_key());
					paramList.add(r);
				}
			}

			// 実行ボタン
			BtnR btnR = getBtnR();
			if (btnR.act_key() != null) {
				OpenScreenParamR param = paramList.createRow();
				param.base_param_key(ACTION_KEY);
				param.open_param_key(btnR.act_key());
				paramList.add(param);
			}

			// 入力値設定
			if (!isNull(btnR.srch_cnd_key())) {
				OpenScreenParamR param = paramList.createRow();
				param.base_param_key(SRCH_CND_KEY);
				param.open_param_key(btnR.srch_cnd_key());
				paramList.add(param);
			}
			
			// 起動区分設定
			if (_to instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase fxto = (FXBAP_PanelBase)_to;
				String ot = fxto.getOpnScrOpenTyp();
				if (!isNull(ot)) {
					OpenScreenParamR param = paramList.createRow();
					param.base_param_key(OPN_TYP_KEY);
					param.open_param_key(ot);
					paramList.add(param);
				}
			}
			
			parent.setOpenParamList(target, paramList);
		}

		statusClear();
		requestCloseWindow();
	}
	
	@Override
	protected void tableInit() {
		// ソート不可
		DtlTable.setSortable(false);
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();

		// コンボリストの表示項目切替
		columnDtl_from_name.setListVisibleColumn(
						OpenScreenParamR.$from_panel, OpenScreenParamR.$from_name);
		Btn_act.setListVisibleColumn(BtnR.$act);

		Btn_srch_cnd.setListVisibleColumn(BtnR.$srch_cnd, BtnR.$srch_cnd_remark);
	}

	@Override
	public void setKEYStatus() {
		super.setKEYStatus();

		// コンボリストの表示項目切替
		columnDtl_from_name.setListVisibleColumn(
						OpenScreenParamR.$from_panel, OpenScreenParamR.$from_name, OpenScreenParamR.$from_key);
		Btn_act.setListVisibleColumn(BtnR.$act, BtnR.$act_key);

		Btn_srch_cnd.setListVisibleColumn(BtnR.$srch_cnd, BtnR.$srch_cnd_remark);
	}

	/**
	 * 他画面から呼び出された場合の初期化を実装します。
	 *
	 * <li>起動タイプ：T1 <br>
	 * バインド値 ＜必須 (mcframe.clientFSBA.FSBAP0290.DtlR)＞<br>
	 * その他の引数：
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>第１引数</td>
	 * <td>FXBAP_PanelBase</td>
	 * <td>連携元画面</td>
	 * </tr>
	 * </table></li>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他の引数
	 */
	@Override
	protected void initByScreenParam(
								String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1 == openTyp) {
			if (!(bind instanceof mcframe.clientFSBA.FSBAP0290.DtlR)) {
				// バインド値の型違い
				throw new MCAppException(msgUnknownOpenParam());
			}

			// 設定対象の親画面のRow
			this.target = (mcframe.clientFSBA.FSBAP0290.DtlR) bind;

			// 親画面
			MCRootPanel parent = getParentPanel();
			if (parent instanceof
						mcframe.clientFSBA.FSBAP0290.FSBAP_ScreenBookmarkSetting) {
				this.parent =
					(mcframe.clientFSBA.FSBAP0290.FSBAP_ScreenBookmarkSetting) parent;
			}

			CndR c = getCndR();
			c.to_module_id(target.module_id());
			c.to_screen_id(target.screen_id());
			c.to_screen_nm(
					MCBeansUtil.getResourceScreenName(
										c.to_module_id(), c.to_screen_id()));
			c.setting_unit_type(target.setting_unit_type());

			FXBAP_PanelBase from = (FXBAP_PanelBase) args[0];
			c.from_module_id(from.getModuleID());
			c.from_screen_id(from.getScreenID());
			c.from_screen_nm(from.getScreenName());

			// 連携元画面項目コンボリスト
			_dtl_from_name_comboL = createDtl_from_nameList(from);
			_dtl_from_name_comboL_idx =
								_dtl_from_name_comboL.createIndex(OpenScreenParamR.$type);

			valueInit();
		}
	}
	
	private void valueInitToPanel() {
		_to_compos.clear();

		String to_mid = getCndR().to_module_id();
		String to_sid = getCndR().to_screen_id();

		try {
			_to = createPanel(to_mid, to_sid, MCRootPanel.MODELESS);
		}
		catch (MCException e) {
			String id = e.getID();
			if (isSame(FCBAC0156, id)) {
				throw new MCAppException(FXBAP0085, to_mid, to_sid);
			}
			throw e;
		}
	}
	@Override
	public void valueInit() {
		super.valueInit();
		valueInitToPanel();
//		MCRootPanel to = createPanel(to_mid, to_sid, MCRootPanel.MODELESS);
		if (_to instanceof IfSrchCndBase) {
			
			//DtlTableに項目行を追加したりする。
			valueInitForDtlItm();

			// 連携先実行ボタンコンボリスト
			Btn_act_comboL = createBtn_actList((IfSrchCndBase) _to);

			// 入力値設定コンボリスト
			Btn_srch_cnd_comboL = createBtn_srch_cndList((IfSrchCndBase) _to);
			_srch_cnd_list = ((IfSrchCndBase)_to).getSrchCndInfoListWithoutBarcode();

			// バインド行追加のための設定
			valueInitForBinds();
			
			// 親画面からの初期値設定
			// ※コンボ連携のため、コンボリスト作成後に実行
			valueInitFromParent();

		}

		DtlTable.adjustWidth();
		DtlTable.selectLeftmostColumn(0);
	}
	
	/**
	 * 連携項目とDtlTableに追加します。
	 */
	private void valueInitForDtlItm() {
		IfSrchCndBase to = (IfSrchCndBase) _to;
		// 7.0.1 システム非表示対応
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(_to);

		// 空の枠名の識別子格納マップ
		Map<MCPanel, String> panelNameMap = createPanelNameMap(_to);
		// 検索条件枠にのみ連携可能
		MCList<OpenScreenParamR> list = getDtlL();
		MCRowBeans[] rbs = getSrchCndBeans((IfSrchCndBase) to);
		for (MCRowBeans rb : rbs) {
			// この判定はxAppsじゃないとできない
			if (rb instanceof MCModeBeans &&
					!(isVisibleInBaseAllStatuses((MCModeBeans) rb))) {
				// 活性化しないカラムには連携できない
				continue;
			}

			// 7.0.1 システム非表示対応
			if(rb instanceof Component) {
				boolean b1 = util.isVisibleComponent((Component)rb);
				if(b1 == false) {
					// システム非表示は一覧に出さない。
					continue;
				}
			}

			String key = MCScreenOpener.createGUIKey(rb);
			String name = FXUCP_SrchCndUtil.getMessageName(rb);

			OpenScreenParamR dtlR = list.createRow();
			dtlR.type(rb.getDataType().toString());
			dtlR.to_key(key);
			dtlR.to_name(name);
			dtlR.to_panel(getPanelName(rb, panelNameMap));

			list.add(dtlR);
			_to_compos.put(key, rb);
		}
	}
	
	/**
	 * バインド行のための設定をします。
	 */
	private void valueInitForBinds() {
		if (_to instanceof FXBAP_PanelBase) {
			FXBAP_PanelBase fxto = (FXBAP_PanelBase) _to;
			Optional.ofNullable(fxto.getOpnScrBindsChangeTriggers()).ifPresent(rs -> {
				BindsCndRowListener rlsnr = new BindsCndRowListener();
				rs.forEach(r -> {
					getDtlL().forEach(lr -> {
						if (MCScreenOpener.createGUIKey(r).equals(lr.to_key())) {
							lr.removeAllRowListener(OpenScreenParamR.$text);
							lr.addRowListener(OpenScreenParamR.$text, rlsnr);
							lr.setBooleanNE(_$has_row_lsnr, true);
						}
					});
				});
			});
			MCList<OpenScreenParamR> ab = fxto.getOpnScrBinds(null);
			if (!isNull(ab)) {
				ab.setBoolean(OpenScreenParamR.$is_bind, true);
				ab.setColumnValue(OpenScreenParamR.$open_param_key, OpenScreenParamR.$to_key);
				getDtlL().addAll(ab);
			};
		}
	}

	class BindsCndRowListener extends FXBAP_RowListener {
		
		Map<String, Comparable<?>> m = new HashMap<>();
		
//		このRowListenerが設定されているRowの固定値が変更された場合、以下の処理をする。
//		１）一覧からisbind=trueの行を削除する
//		２）連携先画面からバインド変数（DtlRの一覧）を取得しisbindをtrueに変更後、一覧に設定する
		@Override
		public void valueChanged(MCRowEvent event) {
			if (_to instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase fxto = (FXBAP_PanelBase) _to;

				MCList<OpenScreenParamR> list = getDtlL();
				list.removeIf(r -> r.is_bind());

				OpenScreenParamR sr = (OpenScreenParamR)event.getSourceRow();
				m.put(sr.to_key(), event.getNewValue());
				
				MCList<OpenScreenParamR> ab = fxto.getOpnScrBinds(m);
				if (!isNull(ab)) {
					ab.setBoolean(OpenScreenParamR.$is_bind, true);
					ab.setColumnValue(OpenScreenParamR.$open_param_key, OpenScreenParamR.$to_key);
					list.addAll(ab);
				}
			}
			
		}
	}
	/**
	 * 画面部品が配置されている枠名を返します。
	 *
	 * 枠やタブペインがネストしている場合は、枠名を" > "で連結します。
	 * 枠名が""(空文字列)の場合は、引数 panelNameMap から名称を取得します。
	 *
	 * @param b 画面部品
	 * @param panelNameMap 枠名マップ
	 * @return 枠名
	 */
	protected String getPanelName(MCBeans b, Map<MCPanel, String> panelNameMap) {
		StringBuilder sb = new StringBuilder();
		Component c = (b instanceof MCButtonGroup)
									? ((MCButtonGroup) b).getRadioButtons()[0]
									: (Component) b;
		Container p = null;
		MCPanel base = null;
		String sep = "";
		while ((p = c.getParent()) != null) {
			if (p instanceof MCPanel) {
				String s = ((MCPanel) p).getLabelByLocale();
				if (s != null && s.length() > 0) {
					sb.insert(0, sep);
					sb.insert(0, s);
					sep = " > ";
				}
				if (panelNameMap.containsKey((MCPanel) p)) {
					base = (MCPanel) p;
				}
			}
			else if (p instanceof MCTabbedPane) {
				MCTabbedPane tp = (MCTabbedPane) p;
				int tpcnt = tp.getTabCount();
				for (int j = 0; j < tpcnt; j++) {
					if (tp.getComponentAt(j) == c) {
						String s = tp.getTitleAt(j);
						if (s != null && s.length() > 0) {
							sb.insert(0, sep);
							sb.insert(0, s);
							sep = " > ";
						}
					}
				}
			}
			c = p;
		}
		return (sb.length() > 0) ? sb.toString() : panelNameMap.get(base);

	}

	

	/**
	 * 親画面からの初期値を設定します。
	 *
	 * コンボ連携を行うため、コンボリスト作成後に実行する必要があります。
	 */
	protected void valueInitFromParent() {
		if (parent == null || target == null) {
			return;
		}

		// 初期設定
		MCList<OpenScreenParamR> paramList = parent.getOpenParamList(target);
		if (paramList == null || paramList.size() <= 0) {
			// 初期設定なし
			return;
		}
		
		// 連携パラメータ（From)
		valueInitForDtlFrom(paramList);
				
		// 実行ボタン
		if (Btn_act_comboL != null) {
			OpenScreenParamR param = paramList.getFirst(
								OpenScreenParamR.$base_param_key, ACTION_KEY);
			if (param != null) {
				BtnR rec = Btn_act_comboL.getFirst(
									BtnR.$act_key, param.open_param_key());
				if (rec != null) {
					setValuesEx(Btn_act, rec);
				}
			}
		}

		// 入力値設定
		OpenScreenParamR param = paramList.getFirst(
				OpenScreenParamR.$base_param_key, SRCH_CND_KEY);
		if (param != null) {
			String pk = param.open_param_key();
			if (pk != null) {
				String k = pk;
				String[] va = MCConst.splitKey(pk);

				if (va.length == 2) {
					k = MCConst.createKey(va[0], getCndR().setting_unit_type(), va[1]);
				}

				BtnR rec = Btn_srch_cnd_comboL.getFirst(BtnR.$srch_cnd_key, k);
				if (rec != null) {
					setValuesEx(Btn_srch_cnd, rec);
				}
			}
		}
	}

	/**
	 * 連携先に対する連携パラメータをDtlTableに設定します。
	 * @param paramList パラメータ
	 */
	private void valueInitForDtlFrom(MCList<OpenScreenParamR> paramList) {
		// 連携パラメータ （そのままDtlTableに入れず、コンボにあるものだけにする。
		if (_dtl_from_name_comboL != null) {
			// 1回目は連携先項目にFromを設定する処理。ここでイベントでバインド行が追加される可能性がある。
			// 2回目はバインド行にFromを設定する処理。
			for (int x=0 ; x <=1 ; x++) {
				MCIndexKey paramIdx = paramList.createIndex(
						OpenScreenParamR.$open_param_key);
				MCIndexKey comboIdx =
						_dtl_from_name_comboL.createIndex(OpenScreenParamR.$from_key);
				MCList<OpenScreenParamR> list = getDtlL();
				int size = list.size();
				for (int i= 0; i < size; i++) {
					OpenScreenParamR param = paramList.getFirst(
												paramIdx, list.get(i).to_key());
					if (param != null) {
						param.to_key(param.open_param_key());
						param.from_key(param.base_param_key());
						// 連携元が項目の場合
						if (param.base_param_key() != null) {
							OpenScreenParamR rec = _dtl_from_name_comboL.getFirst(
													comboIdx, param.base_param_key());
							if (rec != null) {
								// 連携項目も含めた値を設定
								setValuesEx(columnDtl_from_name, i, rec);
							}
						}
						// 連携元が固定値の場合
						else {
							for (MCColumnConfig c : getFromFixedAllColumnExptNm()) {
								setValuesEx(c, i, param);
							}
						}
					}
				}
				_dtl_from_name_comboL.removeIndex(comboIdx);
				paramList.removeIndex(paramIdx);
			}
		}
	}
	/**
	 * 遷移元（固定値）のカラムから名称のいカラムを除いたカラムを取得します。
	 * @return カラム
	 */
	private MCColumnConfig[] getFromFixedAllColumnExptNm() {
		if (_fr_fixed_col_expt_nm == null) {
			MCColumnConfig[] removeValues = {columnDtl_radio_nm, columnDtl_day_of_week_type_nm};
			MCColumnConfig[] src = cgDtl_from_fixed.getAllColumnConfigs();
			_fr_fixed_col_expt_nm = MCCollectionUtil.remove(src, new MCColumnConfig[0], removeValues);			
		}
		return _fr_fixed_col_expt_nm;
	}
	
	/**
	 * 検索枠の GUI 部品のリストを返します。
	 *
	 * @param rp 入力値設定機能を利用する画面
	 * @return  GUI 部品のリスト
	 */
	protected MCRowBeans[] getSrchCndBeans(IfSrchCndBase rp) {
		List<Object[]> list = FXUCP_SrchCndUtil.getSrchCndBeans(rp, true);
		MCRowBeans[] rbs = new MCRowBeans[list.size()];
		for (int i = 0; i < rbs.length; i++) {
			Object[] objs = list.get(i);
			rbs[i] = (MCRowBeans) objs[1];
		}
		return rbs;
	}

	@Override
	public void setOpenFocus() {
		super.setOpenFocus();

		if (getDtlL().size() > 0) {
			DtlTable.selectRow(0);
		}
		else {
			Btn_act.mcRequestFocus();
		}
	}



	/**
	 * 連携先ボタンのコンボリストです。
	 */
	private MCList<BtnR> Btn_act_comboL;
	/**
	 * 連携先ボタンのコンボリストを作成します。
	 *
	 * @param rp 連携先画面
	 * @return 連携先ボタンのコンボリスト
	 */
	protected MCList<BtnR> createBtn_actList(IfSrchCndBase rp) {
		MCList<BtnR> list = MCList.create(BtnR.class);

		// 固定項目
		FSC_BOOKMARK_FW_ACT[] defitems = FSC_BOOKMARK_FW_ACT.array();
		for (FSC_BOOKMARK_FW_ACT defitem :defitems) {
			BtnR row = list.createRow();
			row.act(defitem.name());
			row.act_key(defitem.value());
			list.add(row);
		}

		return list;
	}

	@Override
	public MCList<?> getBtn_act(MCRow row, MCEventInfo info){
		return Btn_act_comboL;
	}

	@Override
	public boolean isValueChanged(
					MCRowBeans compo, Comparable<?> view, Comparable<?> row) {
		if (compo == Btn_act) {
			if (MCListConfig.LIST.equals(
									Btn_act.getListConfig().getOpeType())) {
				// コンボリストで選択された場合
				MCEventInfo event = Btn_act.getEventInfo();
				BtnR selrow = (BtnR) event.getNewListRow();
				if (selrow != null) {	// 選択されてない場合は null
					String key = selrow.act_key();
					if (key != null) {
						String old = getBtnR().act_key();
						return !isSame(key, old);
					}
				}
			}
		}
		return super.isValueChanged(compo, view, row);
	}

	/**
	 * 連携元名称のコンボリストです。
	 */
	private MCList<OpenScreenParamR> _dtl_from_name_comboL;

	/**
	 * 連携元名称のコンボリストのインデックスです。
	 */
	private MCIndexKey _dtl_from_name_comboL_idx;

	/**
	 * 連携元名称のコンボリストを作成します。
	 *
	 * @param rp 連携元画面
	 * @return コンボリスト
	 */
	protected MCList<OpenScreenParamR> createDtl_from_nameList(FXBAP_PanelBase rp) {
		MCList<OpenScreenParamR> list = MCList.create(OpenScreenParamR.class);

		// 空の枠名の識別子格納マップ
		Map<MCPanel, String> dummyIdMap = createPanelNameMap(rp);

		// システム非表示対応 7.0.1
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(rp);

		// 見出し
		MCRowBeans[] rbs = MCScreenOpener.getRowBeans(rp);
		for (MCRowBeans b : rbs) {
			// この判定はxAppsじゃないとできない
			if (b instanceof MCModeBeans && isVisibleInBaseAllStatuses((MCModeBeans) b)) {

				if (b instanceof Component) {
					boolean b1 = util.isVisibleComponent((Component) b);
					if (b1 == false) {
						// システム非表示はコンボの一覧に出さない。
						continue;
					}
				}

				String target = MCScreenOpener.createGUIKey(b);
				OpenScreenParamR row = list.createRow();
				row.type(b.getDataType().toString());
				row.from_panel(getPanelName(b, dummyIdMap));
				row.from_name(FXUCP_SrchCndUtil.getMessageName(b));
				row.from_key(target);
				list.add(row);
			}
		}

		// テーブル
		MCFixedColumnTable<?>[] tbls = MCBeansUtil.getAllComponents(MCFixedColumnTable.class, rp);
		for (MCFixedColumnTable<?> tbl : tbls) {
			String pname = getPanelName(tbl, dummyIdMap);
			MCColumnConfig[] cols = tbl.getColumnConfigs();
			for (MCColumnConfig col : cols) {
				if (isVisibleInBaseAllStatuses(col)) {
					String target = MCScreenOpener.createGUIKey(col);
					MCDataType type = col.getDataType();
					if (type == null) {
						continue;
					}
					boolean b2 = util.isVisibleColumn(tbl, col);
					if (b2 == false) {
						// システム非表示はコンボの一覧に出さない。
						continue;
					}
					OpenScreenParamR row = list.createRow();
					row.type(type.toString());
					row.from_panel(pname);
					row.from_name(col.getMessageByLocale());
					row.from_key(target);
					list.add(row);
				}
			}
		}
		return list;
	}

	@Override
	public MCList<?> getDtl_from_name(MCRow row, MCEventInfo info){
		// データ型が一致する項目のみリストに表示する
		OpenScreenParamR dtlR = DtlTable.getSelectedMCRow();
		return (dtlR != null && !isNull(dtlR.type()))
					? _dtl_from_name_comboL.subList(_dtl_from_name_comboL_idx, dtlR.type())
					: _dtl_from_name_comboL.subList(_dtl_from_name_comboL_idx);
	}

	@Override
	public boolean isValueChanged(int index, MCColumnConfig column,
									Comparable<?> view, Comparable<?> row) {
		if (column == columnDtl_from_name) {
			if (MCListConfig.LIST.equals(column.getListConfig().getOpeType())) {
				// コンボリストで選択された場合
				MCEventInfo event = column.getEventInfo();
				OpenScreenParamR selrow = (OpenScreenParamR) event.getNewListRow();
				if (selrow != null) {	// 選択されてない場合は null
					String key = selrow.from_key();
					if (key != null) {
						MCTable<?> tbl = column.getBaseTable();
						String old = (String) tbl.getValue(
													index, columnDtl_from_key);
						return !isSame(key, old);
					}
				}
			}
		}
		return super.isValueChanged(index, column, view, row);
	}

	@Override
	public void doBtn_act_LC(MCEventInfo info) {
		super.doBtn_act_LC(info);

		if (!isNull(getBtnR().act())) {
			setValueEx(Btn_srch_cnd, null);
		}
	}

	@Override
	public void doBtn_srch_cnd_LC(MCEventInfo info) {
		super.doBtn_srch_cnd_LC(info);

		if (!isNull(getBtnR().srch_cnd())) {
			setValueEx(Btn_act, null);
		}
	}

	/**
	 * 入力値設定のコンボリストです。
	 */
	protected MCList<BtnR> Btn_srch_cnd_comboL;

	/**
	 * 入力値設定のコンボリストを作成します。
	 *
	 * @param rp 連携先画面
	 * @return 入力値設定のコンボリスト
	 */
	protected MCList<BtnR> createBtn_srch_cndList(IfSrchCndBase rp) {
		MCList<BtnR> l = MCList.create(createBtnR());
		List<SrchCndInfo> sl = rp.getSrchCndInfoListWithoutBarcode();

		for (SrchCndInfo i : sl) {
			if (!isApplicable(i.getSettingUnitType())) {
				continue;
			}

			BtnR o = l.createRow();
			o.srch_cnd_key(MCConst.createKey("p_srch_cnd", i.getSettingUnitType(),
					i.getSettingInfoID()));
			o.srch_cnd(i.getSettingInfoUnitName());

			o.srch_cnd_remark(i.getRemark());
			l.add(o);
		}

		return l;
	}

	/**
	 * 設定単位CDの値をもとに、コンボリストに追加するかどうかを返します。</p>
	 * 
	 * 遷移元の設定単位と同じか、それより大きい設定単位の入力値設定の場合はtrueを返します。<br>
	 * ex) 遷移元から引きついだ引数の設定単位CDがEXT
	 * (設定単位：会社共通　の画面遷移設定に紐づく連携設定)の場合は、
	 * 引数の設定単位CDの値に応じて以下の値を返します。
	 * <ul>
	 * <li>SYS（システム共通）：true（追加する）</li>
	 * <li>EXT（会社共通）：true（追加する）</li>
	 * <li>USER（ユーザ）：false（追加しない）</li>
	 * </ul>
	 * 
	 * @param settingUnitType 設定単位CD
	 * @return コンボリストに追加するかどうか
	 */
	protected boolean isApplicable(String settingUnitType) {
		switch (getCndR().setting_unit_type()) {
			case "SYS":
				return FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(settingUnitType);
			case "EXT":
				return FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(settingUnitType)
						|| FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(settingUnitType);
			case "USER":
				return FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(settingUnitType)
						|| FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(settingUnitType)
						|| FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(settingUnitType);
			default:
		}
		return false;
	}
	
	@Override
	public MCList getBtn_srch_cnd(MCRow row, MCEventInfo info) {
		return Btn_srch_cnd_comboL;
	}

	protected List<SrchCndInfo> _srch_cnd_list;
		
	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		clearFromColumnOrFixed(nc, info);
		
	}
	
	/**
	 * イベント駆動元に応じて連携元と連携元（固定値）のいずれか一方を削除します。
	 * 
	 * @param lc イベント対象のGUI部品
	 * @param info　イベント情報
	 */
	private void clearFromColumnOrFixed(MCNCBeans nc, MCEventInfo info) {
		int i = info.getEventIndex();
		
		for (MCColumnConfig c : cgDtl_from_fixed.getAllColumnConfigs()) {
			if (nc == c) {
				OpenScreenParamR r = getDtlL().get(i);
				clearValues(r, cgDtl_from.getAllColumnConfigs());
				return;
			}
		}
		for (MCColumnConfig c : cgDtl_from.getAllColumnConfigs()) {
			if (nc == c) {
				OpenScreenParamR r = getDtlL().get(i);
				clearValues(r, cgDtl_from_fixed.getAllColumnConfigs());
				return;
			}
		}
	}
	
	/**
	 * 連携元、連携元（固定値）が未入力かどうかを判定します。
	 * @param r 対象行
	 * @return 未入力の場合true
	 */
	private boolean isNotFrColInput(OpenScreenParamR r) {
		return isNotInput(r, cgDtl_from.getAllColumnConfigs()) &&
				isNotInput(r, cgDtl_from_fixed.getAllColumnConfigs());
	}
		
	/**
	 * 対象カラムに対する項目が未指定かどうかを判定します。
	 * 
	 * @param r　対象のRow
	 * @param cs　対象のカラム
	 */
	private boolean isNotInput(OpenScreenParamR r, MCColumnConfig[] cs) {
		for (MCColumnConfig c : cs) {
			Comparable<?> v = r.getValue(c.getBaseRowColumnName());	
			boolean isnull = v == null || (v instanceof Boolean && !(Boolean)v);
			if (!isnull) {
				return false;
			}
		}
		return true;
	}
	
	
	/**
	 * カラムに対応するRowの値をクリアします。
	 * 
	 * @param r　クリア対象のRow
	 * @param cs　クリア対象のカラム
	 */
	private void clearValues(OpenScreenParamR r, MCColumnConfig[] cs) {
		for (MCColumnConfig c : cs) {
			r.clear(c.getBaseRowColumnName());			
		}
	}
	@Override
	public void doDtl_date_NC(MCEventInfo info) {
		super.doDtl_date_NC(info);

		int index = info.getEventIndex();
		if (!isNull(getDtlL().get(index).date())) {
			setValueEx(columnDtl_today_flg, index, false);
			setValueEx(columnDtl_firstday_flg, index, false);
			setValueEx(columnDtl_lastday_flg, index, false);
		}
	}
@Override
	public void doDtl_firstday_flg_NC(MCEventInfo info) {
		super.doDtl_firstday_flg_NC(info);

		int index = info.getEventIndex();
		if (getDtlL().get(index).firstday_flg()) {
			setValueEx(columnDtl_today_flg, index, false);
			setValueEx(columnDtl_date, index, null);
			setValueEx(columnDtl_lastday_flg, index, false);
		}
	}
@Override
	public void doDtl_lastday_flg_NC(MCEventInfo info) {
		super.doDtl_lastday_flg_NC(info);

		int index = info.getEventIndex();
		if (getDtlL().get(index).lastday_flg()) {
			setValueEx(columnDtl_today_flg, index, false);
			setValueEx(columnDtl_date, index, null);
			setValueEx(columnDtl_firstday_flg, index, false);
		}
	}
@Override
	public void doDtl_today_flg_NC(MCEventInfo info) {
		super.doDtl_today_flg_NC(info);

		int index = info.getEventIndex();
		if (getDtlL().get(index).today_flg()) {
			setValueEx(columnDtl_date, index, null);
			setValueEx(columnDtl_firstday_flg, index, false);
			setValueEx(columnDtl_lastday_flg, index, false);
		}
	}
@Override
	public void doDtl_week_NC(MCEventInfo info) {
		super.doDtl_week_NC(info);

		int i = info.getEventIndex();
		OpenScreenParamR o = getDtlL().get(i);
		if (isNull(o.week())) {
			setValueEx(columnDtl_day_of_week_type, i, null);
		}

	}
@Override
	protected void listInit() {
		super.listInit();

		columnDtl_radio.setListVisibleColumn(
				OpenScreenParamR.$radio, OpenScreenParamR.$radio_nm);
	}

	@Override
	public MCList<?> getDtl_radio(MCRow row, MCEventInfo info) {
		return getRadioList(row, info);
	}

	protected MCList<MCRow> getRadioList(MCRow row, MCEventInfo info) {
		int index = info.getEventIndex();
		if (getDtlL().size() <= index) {
			return null;
		}

		MCRowBeans c = getToRowBeans(getDtlL().get(index));
		if (!(c instanceof MCButtonGroup)) {
			return null;
		}

		MCList<MCRow> list = MCList.create(MCRow.class);
		for (MCRadioButton b : ((MCButtonGroup)c).getRadioButtons()) {
			MCModeInfo i = b.getModeInfo();
			if (i != null && i.getStatus() == MCMode.ENABLE_STATUS) {
				MCRow d = MCRow.create();
				d.addStringColumn(OpenScreenParamR.$radio, b.getActionCommand());
				d.addStringColumn(OpenScreenParamR.$radio_nm, getRadioButtonName(b));
				list.add(d);
			}
		}
		return list;
	}

	/**
	 * ラジオボタンのコンボリストに表示するラジオボタン名を返します。
	 *
	 * @param compo ラジオボタン
	 * @return ラジオボタン名
	 */
	protected String getRadioButtonName(MCRadioButton compo) {
		String n = compo.getLabelByLocale();
		if (!isNull(n)) {
			return n;
		}
		n = compo.getMessageByLocale();
		if (!isNull(n)) {
			return n;
		}
		return null;
	}
	
	/**
	 * 連携先項目のGUI部品を取得します。
	 * @param data 対象行
	 * @return GUI部品
	 */
	private MCRowBeans getToRowBeans(OpenScreenParamR data) {
		if (data == null) {
			return null;
		}
		return getToRowBeans(data.to_key());
	}
	private MCRowBeans getToRowBeans(String to_key) {
		return _to_compos.get(to_key);
	}
	@Override
	protected void setCellConfig() {
		super.setCellConfig();
		DtlTable.setCellConfig(createDtlCellConfig());
	}

	@Override
	public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
		if (compo == columnDtl_text) {
			MCCellEditorText ce = (MCCellEditorText)DtlTable.getCellEditor();
			MCTextField e = (MCTextField)ce.getComponent();;
			if (e != null && e.getBorder() instanceof mcframe.clientCore.beans.border.MCISFieldBorder) {
				OpenScreenParamR o = getDtlL().get(info.getEventIndex());
				if (o != null && o.getBooleanNE(_$has_row_lsnr)) {
					doPopupMenu(o, e, 0, e.getHeight());
				}
			}
		}
		
	}
	private void doPopupMenu(OpenScreenParamR o, MCRowBeans c, int x, int y) {
		if (_to_compos != null) {
			if (_popup == null) {
				_popup = createPopup(o, c);
			}
			if (_popup != null) {
				_popup.showPopup((Component)c, x, y);
			}
		}
	}
		
	/**
	 * ポップアップを作成します。
	 * @param o 対象行
	 * @param c 元項目
	 * @return ポップアップ
	 */
	private MCCustomPopup createPopup(OpenScreenParamR o, MCRowBeans c) {
		MCRowBeans b = _to_compos.get(o.to_key());
		MCCustomPopup popup = null;
		if (b instanceof MCLinkBeans) {
			popup = new MCCustomPopup(c, (MCLinkBeans)b);
			popup.setCustomPanel("FS", "FSBAP0890");
		}
		return popup;
	}
	
	protected JMenuItem createMenuItem(MCTextField c, Font font,
			String text,
			String value) {
		JMenuItem item = new JMenuItem(text);
		item.setFont(font);
		item.addActionListener(new java.awt.event.ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setValueEx(c, value);
			}
		});
		return item;
	}
	/**
	 * 検索条件テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 検索条件テーブルに設定するセルコンフィグ
	 */
	protected FXBAP_CellConfig createDtlCellConfig() {
		return new WBP_DtlCellConfig();
	}

	public class WBP_DtlCellConfig extends FXBAP_CellConfig {
		
		@Override
		public javax.swing.border.Border getPriorEditorBorder(int index,
				MCColumnConfig column,
				MCTable table) {
			if (column == columnDtl_text) { 
				OpenScreenParamR o = getDtlL().get(index);
				//入力補助アイコンの描画を有効にする
				if (o != null && o.getBooleanNE(_$has_row_lsnr)) {
					return new mcframe.clientCore.beans.border.MCISFieldBorder();
				}
			}
			
			return super.getPriorEditorBorder(index, column, table);
		}
		
		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}


			OpenScreenParamR o = getDtlL().get(index);

			MCRowBeans c = getToRowBeans(o);
			if(c == null) { //　640 一覧にない場合にエラーになる
				if (!o.is_bind()) {
					return MCMode.READ_ONLY;
				}
			}
			
			MCDataType t = null;
			if (c != null) {
				t = c.getDataType();
			}
			else {
				t = MCDataType.valueOf(o.type());
			}
			
			if (column == columnDtl_text) {
				if (MCDataType.STRING != t || (c instanceof MCButtonGroup)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnDtl_check) {
				if (MCDataType.BOOLEAN != t) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnDtl_radio) {
				if (!(c instanceof MCButtonGroup)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnDtl_today_flg) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("y") && !f.contains("M") && !f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnDtl_date) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnDtl_firstday_flg) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnDtl_lastday_flg) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnDtl_month) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("M")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnDtl_day || column == columnDtl_week) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnDtl_day_of_week_type) {
				if (isNull(o.week())) {
					return MCMode.READ_ONLY;
				}
			}

			else if (column == columnDtl_hour) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("h") && !f.contains("H") &&
							!f.contains("k") && !f.contains("K")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnDtl_minute) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("m")){
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnDtl_num) {
				if (MCDataType.NUMBER != t) {
					return MCMode.READ_ONLY;
				}
			}

			return super.getPriorMode(index, column, table);
		}
		
		String _date_fmt = null;
		String _ts_fmt = null;
		
		private String getFmt(MCDataType t) {
			if (MCDataType.DATE == t) {
				if (_date_fmt == null) {
					_date_fmt = MCConst.app.getString("FS.FSBAP0300.date_fmt");
				}
				return _date_fmt;
			}
			else if (MCDataType.TIMESTAMP == t) {
				if (_ts_fmt == null) {
					_ts_fmt = MCConst.app.getString("FS.FSBAP0300.ts_fmt");
				}
				return _ts_fmt;
			}
			return "YMD";
		}
		
		@Override
		protected MCTimestampFormat getCustomTimestampFormat(int index,
				MCColumnConfig column, MCTable table) {
			if (column == columnDtl_date) {
				MCTimestampFormat f = new MCTimestampFormat();

				MCRowBeans c = getToRowBeans(getDtlL().get(index));
				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					f.setCalendarPattern(cf.getCalendarFormat().getCalendarPattern());
					return f;
				}
				else if (c == null) {
					OpenScreenParamR o = getDtlL().get(index);
					if (o != null) {
						MCCalendarPattern p = MCCalendarPattern.create(
								getFmt(MCDataType.valueOf(o.type())));
						f.setCalendarPattern(p);
						return f;
					}
				}
			}
			return super.getCustomTimestampFormat(index, column, table);
		}
	}

}