package mcframe.clientFSBA.FSBAP0620;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0090.*;
import mcframe.clientFXUC.FXUCP0070.SrchCndR;
import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.resource.MCMenuItemModel;
import mcframe.clientCore.resource.MCMenuItemModel.MCMenuType;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_SrchCnd"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_SrchCnd_FW extends FSBAP_SrchCnd_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SrchCnd_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SrchCnd_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	protected void mcInit() {
		super.mcInit();

		ListBtn_upd_apply.putMode(this, INIT, MCMode.INVISIBLE);
		ListBtn_upd_apply.putMode(this, EDIT, MCMode.INVISIBLE);
		ListBtn_upd_apply.putMode(this, DISABLE, MCMode.INVISIBLE);
		SettingPanel.setVisible(false);
	}


	@Override
	protected void customTabOrder() {
		super.customTabOrder();
		setFirstBeans(SettingPanel.getNextBeans());
	}

	@Override
	public void afterOpen() {
		super.afterOpen();
		// 新規行を初期選択する。
		int find = -1;
		int idx = -1;
		for(mcframe.clientFSBA.FSBAP0030.ListDtlR r : getListDtlL()) {
			idx++;
			if(r.setting_info_nm() == null || r.setting_info_nm().length() == 0) {
				find = idx;
				break;
			}
		}
		if(find == -1) {
			getListDtlL().add(mcframe.clientFSBA.FSBAP0030.ListDtlR.create());
			find = getListDtlL().size() - 1;
		}
		ListDtlTable.selectRow(find);

		// set_flgをすべてチェックする。
		//setValueEx(columnInfoDtl_set_flg, true);
	}

	/**
	 * 登録ボタンの処理を実行します。
	 */
	@Override
	protected void doUpdAction() {
//		String info_nm = getListHdrR().setting_info_nm();
//		if(info_nm == null || info_nm.length() == 0) {
//			addBookmark();
//		} else {
			if (!execUpdComfirm() || !checkForUpd()) {
				return;
			}

			beforeUpd();
			doUpd();
			afterUpd();
			addBookmark();
		

		// 閉じるときの変更の警告を出さないようにする。
		//getInfoDtlL().clear();
		//getListDtlL().clear();

		showUpdEndMsg();

		// 登録後に閉じる。
		requestCloseWindow();
	}

	@Override
	protected boolean checkForUpd() {
		if (!super.checkForUpd2()) {
			return false;
		}

		// 設定なしはエラーにしない。
		MCList<SrchCndR> l = getInfoDtlL().subList(SrchCndR.$set_flg, true);
		if (l.size() == 0) {
			dialog(FSBAC0067);
			return false;
		}
	

		clearEmptyRowStatus(getInfoDtlL());

		return true;
	}

	protected void addBookmark() {

		String screenID = getTargetPanel().getScreenID();
		String moduleID = getTargetPanel().getModuleID();
		String info_nm = getListHdrR().setting_info_nm();
		if(info_nm == null) {
			info_nm = "";
		}

		MCMenuItemModel model = new MCMenuItemModel(null, MCMenuType.ITEM);
		model.setAttribute(MCMenuItemModel.ATT_MODULE, moduleID);
		model.setAttribute(MCMenuItemModel.ATT_SCREEN, screenID);
		model.setAttribute(MCMenuItemModel.ATT_METHOD, info_nm);
		model.enable(true);
		model.authority(true);

		// 既に同じ物がある場合は上書きする。
		List<MCMenuItemModel> list = mcframe.clientCore.resource.MCConst.menu.getBookmarkModel().childModels();
		for(MCMenuItemModel item : list) {
			String mid = item.moduleId();
			String sid = item.screenId();
			String method = item.methodName();
			if(method == null) {
				method = "";
			}
			if(mid.equals(moduleID)) {
				if(sid.equals(screenID)) {
					if(method.equals(info_nm)) {
						model.bookmarkID(item.bookmarkID());
						break;
					}
				}
			}
		}

		mcframe.clientCore.resource.MCConst.menu.addBookMark(model);
	}
}