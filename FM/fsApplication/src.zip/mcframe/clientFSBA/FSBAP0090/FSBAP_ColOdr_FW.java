package mcframe.clientFSBA.FSBAP0090;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0060.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.HashMap;
import java.util.Map;

import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

import mcframe.clientCore.beans.resource.MCColumnWidthData;
import mcframe.clientCore.beans.resource.MCColumnWidthInfo;
import mcframe.clientCore.beans.resource.MCColumnWidthResourceIO;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0670.FSBAP0670_FW;
import mcframe.clientFSUB.FSUBP0000.IfRowMoveBase;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_ColOdr"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_ColOdr_FW extends FSBAP_ColOdr_FW_A implements IfRowMoveBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * カラム情報設定対象のテーブルです。
	 */
	protected MCTable<?> _target_table = null;

	/**
	 * カラム情報設定対象のテーブルカラムの配列です。
	 */
	protected MCColumnConfig[] _target_column_configs = null;

	/**
	 * 画面表示時の親テーブルのカラム情報です。
	 */
	protected MCList<InfoDtlR> _init_table_list = null;

	/**
	 * 設定情報ＩＤのシーケンス番号のマップです。
	 */
	protected Map<String, Integer> _setting_info_no_map = null;

	/**
	 *  バーコード設定画面
	 */
	protected FSBAP0670_FW mainPanelForBarcode = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ColOdr_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ColOdr_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * mainPanelForBarcode
	 * @return FSBAP0670_FW
	 */
	public FSBAP0670_FW getMainPanelForBarcode() {
		return mainPanelForBarcode;
	}

	/**
	 * mainPanelForBarcode
	 * @param mainPanelForBarcode FSBAP0670_FW
	 */
	public void setMainPanelForBarcode(FSBAP0670_FW mainPanelForBarcode) {
		this.mainPanelForBarcode = mainPanelForBarcode;
	}


	/**
	 * カラム情報設定対象のテーブルを設定します。
	 *
	 * @param table カラム情報設定対象のテーブル
	 */
	// 640 publicに変更
	public void setTargetTable(MCTable<?> table) {
		_target_table = table;
	}

	/**
	 * カラム情報設定対象のテーブルを返します。<p>
	 * カラム情報設定対象のテーブルが設定されていない場合は null を返します。
	 *
	 * @return カラム情報設定対象のテーブル、または null
	 */
	protected MCTable<?> getTargetTable() {
		return _target_table;
	}

	/**
	 * カラム情報設定対象のテーブルカラムを配列にして返します。
	 *
	 * @return カラム情報設定対象のテーブルカラムの配列
	 */
	public MCColumnConfig[] getTargetColumnConfigs() {
		if (_target_column_configs != null) {
			return _target_column_configs;
		}
		_target_column_configs
				= getTargetTable().getPersonalizedTargetColumnConfigs(
						COLUMN_WIDTH_PANEL);

		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(getTargetTable().getRootPanel());

		List<MCColumnConfig> list = new ArrayList<MCColumnConfig>();
		for (MCColumnConfig c : _target_column_configs) {
			// システム非表示チェック 7.0.1
			if (util.isVisibleColumn(getTargetTable(), c)) {
				list.add(c);
			}
		}

		MCColumnConfig[] array = list.toArray(new MCColumnConfig[0]);
		_target_column_configs = array;

		return _target_column_configs;
	}

	/**
	 * カラム情報設定対象のテーブルカラムを返します。<p>
	 * テーブルカラムが見つからなかった場合は null を返します。
	 *
	 * @param name {@link MCColumnConfig#getBaseTableColumnName()}
	 * @return カラム情報設定対象のテーブルカラム、または null
	 */
	public MCColumnConfig getTargetColumnConfig(String name) {
		for (MCColumnConfig c : getTargetColumnConfigs()) {
			if (isSame(name, c.getBaseTableColumnName())) {
				return c;
			}
		}
		return null;
	}

	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);

		// 登録済みの行が選択された場合
		FSBAP_ColOdrInfo ci = getSettingInfo(data);
		if (ci != null) {
			setListHdrR(ci.getSettingInfo());
			MCList<InfoDtlR> c1 = ci.getColOdrList();
			MCList<InfoDtlR> ll = createInfoDtlL();
			for (InfoDtlR c : c1) {
				InfoDtlR nc = c.clone();
				ll.add(nc);
			}
			setInfoDtlL(ll);
			getInfoDtlL().setStatus(MCRow.NONE);

			InfoDtlTable.adjustWidth();

			return;
		}

		// 新規行が選択された場合
		getInfoDtlL().clear();
		getListHdrR().clearAll();
		doLoad();
		getInfoHdrR().clearAll();

		InfoDtlTable.adjustWidth();
	}

	@Override
	protected boolean isInfoDataChanged() {
		return !getInfoDtlL().isStatusNone();
	}

	@Override
	protected void removeResource(boolean doSave) {
		MCTable<?> t = getTargetTable();

		MCColumnWidthResourceIO cio = new MCColumnWidthResourceIO();

		String u = getSettingR().setting_unit();

		String pfx = t.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL, null);
		String pfx2 = t.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL,
				MCResourceLayerType.BARCODE);

		// バーコード対応
		if (mainPanelForBarcode != null) {
			u = setting_unit_barcode();
		}

		Map<String, Integer> m = cio.readSettingInfoNOMap(pfx, pfx2);

		if (mainPanelForBarcode != null) {
			MCColumnWidthResourceIO.removeNoSave(u, pfx2);
		}
		else {
			MCColumnWidthResourceIO.removeNoSave(u, pfx);
		}

		// 設定情報ＩＤのシーケンスを再設定する
		if (m.containsKey(u) && isRemainedAfterDel(u)) {
			Map<String, Integer> nm = new HashMap<String, Integer>();
			nm.put(u, m.get(u));
			if (mainPanelForBarcode != null) {
				cio.writeNoSave(pfx2, nm);
			}
			else {
				cio.writeNoSave(pfx, nm);
			}
		}
		if (doSave) {
			MCColumnWidthResourceIO.saveResource();
		}
		t._setColumnWidthInfo(null);
		clearColumnWidthInfoList();
	}

	protected void removeResourceById(boolean doSave, String setting_info_id) {
		MCTable<?> t = getTargetTable();
		if (setting_info_id != null) {
			MCColumnWidthResourceIO cio = new MCColumnWidthResourceIO();
	
			String u = getSettingR().setting_unit();
	
			String pfx = t.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL, null);
			String pfx2 = t.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL,
					MCResourceLayerType.BARCODE);
	
			// バーコード対応
			if (mainPanelForBarcode != null) {
				u = setting_unit_barcode();
			}
	
			Map<String, Integer> m = cio.readSettingInfoNOMap(pfx, pfx2);
	
			if (mainPanelForBarcode != null) {
				MCColumnWidthResourceIO.removeNoSaveById(u, pfx2, setting_info_id);

				// 初期設定のリソースが引数のIDと一致する場合は削除
				cio.removeInitResourceById(u, pfx2, setting_info_id);
			}
			else {
				MCColumnWidthResourceIO.removeNoSaveById(u, pfx, setting_info_id);

				// 初期設定のリソースが引数のIDと一致する場合は削除
				cio.removeInitResourceById(u, pfx, setting_info_id);
			}

			// 設定情報ＩＤのシーケンスを再設定する
			if (m.containsKey(u) && isRemainedAfterDel(u)) {
				Map<String, Integer> nm = new HashMap<String, Integer>();
				nm.put(u, m.get(u));
				if (mainPanelForBarcode != null) {
					cio.writeNoSave(pfx2, nm);
				}
				else {
					cio.writeNoSave(pfx, nm);
				}
			}
			if (doSave) {
				MCColumnWidthResourceIO.saveResource();
			}
		}
		t._setColumnWidthInfo(null);
		clearColumnWidthInfoList();
	}

	@Override
	protected void setInitData() {
		super.setInitData();

		getInfoDtlL().clear();
		getInfoHdrR().clearAll();

		MCTable<?> t = getTargetTable();
		List<MCColumnWidthInfo> l = new ArrayList<MCColumnWidthInfo>();

		List<MCColumnWidthInfo> sl = new ArrayList<MCColumnWidthInfo>();
		List<MCColumnWidthInfo> el = new ArrayList<MCColumnWidthInfo>();
		List<MCColumnWidthInfo> ul = new ArrayList<MCColumnWidthInfo>();
		List<MCColumnWidthInfo> bl = new ArrayList<MCColumnWidthInfo>();

		// バーコード対応
		if (mainPanelForBarcode != null) {
			for (MCColumnWidthInfo i : t.getBarcodeColumnWidthInfoList()) {
				String y = i.getSettingUnitType();
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_BARCODE(y)) {
					bl.add(i);
				}
			}
			l.addAll(0, bl);
		} else {
			String u = getSettingR().setting_unit();
			for (MCColumnWidthInfo i : t.getColumnWidthInfoList()) {
				String y = i.getSettingUnitType();
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
					sl.add(i);
				}
				else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
					el.add(i);
				}
				else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
					ul.add(i);
				}
				else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_BARCODE(y)) {
					bl.add(i);
				}
			}

			l.addAll(0, sl);
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
				l.addAll(0, el);
				if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
					l.addAll(0, ul);
				}
			}
		}

		MCTable<?> tbl = getTargetTable();

		// BARCODEの場合にpfxが異なる。
		String pfx = tbl.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL, null);
		String pfx2 = tbl.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL, MCResourceLayerType.BARCODE);
		_setting_info_no_map = new MCColumnWidthResourceIO().readSettingInfoNOMap(pfx, pfx2);

		//システム非表示対応

		MCRootPanel rp = t.getRootPanel();
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(rp);

		MCList<ListDtlR> ll = createListDtlL();
		int pi = 0;
		for (MCColumnWidthInfo i : l) {
			FSBAP_ColOdrInfo ci = new FSBAP_ColOdrInfo();

			ListDtlR lo = ll.createRow();
			lo.init_flg(i.getInitFlg());

			lo.setting_unit_type(i.getSettingUnitType());
			FXC_RESOURCE_SETTING_UNIT.putName(lo,
					ListDtlR.$setting_unit_type,
					ListDtlR.$setting_unit_type_nm);

			lo.setting_info_id(i.getSettingInfoID());
			lo.setting_info_nm(i.getSettingInfoName());
			if (isNull(lo.setting_info_nm())) {
				lo.setting_info_nm(
						getPreviousSettingNamePrefix() + String.valueOf(++pi));
			}
			lo.remark(i.getRemark());
			ll.add(lo);

			ci.setSettingInfo(lo.clone());

			MCList<InfoDtlR> cl = createInfoDtlL();

			for (MCColumnWidthData d : i.getColumnWidthList()) {
				MCColumnConfig c = getTargetColumnConfig(d.getColumnName());
				if (c == null) {
					continue;
				}

				// システム非表示対応
				if(util.isVisibleColumn(tbl, c) == false) {
					continue;
				}

				InfoDtlR o = getInitRowData(c, d);
				cl.add(o);
			}

			// システム非表示で復活させたた分を追加 7.0.1
			for (MCColumnConfig c : getTargetColumnConfigs()) {
				InfoDtlR r = getColumnData(c);
				boolean b = false;
				for(InfoDtlR r1 : cl) {
					if(r1.column_key().equals(r.column_key())) {
						b = true;
						break;
					}
				}
				if(b == false) {
					// システム非表示チェック 7.0.1
					if(util.isVisibleColumn(tbl, c)) {
						cl.add(r);
					}
				}
			}

			ci.setColOdrList(cl);

			getSettingInfoMap().put(MCConst.createKey(
					i.getSettingUnitType(), i.getSettingInfoID()), ci);
		}

		setListDtlL(ll);

		if (_init_table_list == null) {
			_init_table_list = createInfoDtlL();
			for (MCColumnConfig c : getTargetColumnConfigs()) {
				// システム非表示チェック 7.0.1
				if(util.isVisibleColumn(tbl, c)) {
					_init_table_list.add(getColumnData(c));
				}
			}
		}

		ListDtlTable.adjustWidth();
	}

	protected String setting_unit_barcode() {
		return "BARCODE";
	}


	protected InfoDtlR getColumnData(MCColumnConfig column) {
		MCTable<?> t = getTargetTable();

		InfoDtlR o = getInfoDtlL().createRow();

		o.column_key(column.getBaseTableColumnName());
		o.column_nm(column.getMessageByLocale());
		o.hide_flg(!column.isVisibleFromUser());

		if (column.getModeInfo().getStatus() != MCMode.INVISIBLE_STATUS) {
			o.visible_flg(true);
		}
		if (!o.hide_flg()) {
			int w = column.getColumnWidth();
			w = MCBeansUtil.adjust(w, t.getRatio(), 100);
			o.width(w);
		}
		else {
			o.width(0);
		}

		o.fixed_flg(column == t.getUnscrollColumn());
		o.adjust_flg(column.isAdjustWidth());

		// 7013-1209(【A1】【FM-10】一覧テーブルの機能強化)
		// この値はリソースの値になる。
		o.required_flg(column.isRequiredColumn());
		// 7013-1209 ここまで

		return o;
	}

	/**
	 * 初期値を設定します。<p>
	 * 指定されたテーブルカラムの初期値を設定した Row コンテナを返します。
	 *
	 * @param column テーブルカラム
	 * @return Row コンテナ
	 */
	protected InfoDtlR getInitRowData(
			MCColumnConfig column, MCColumnWidthData data) {
		MCTable<?> t = getTargetTable();

		InfoDtlR o = getInfoDtlL().createRow();

		o.column_key(data.getColumnName());
		o.column_nm(column.getMessageByLocale());

		Boolean v = data.getColumnVisible();
		if (v == null) {
			v = column.isVisibleFromUser();
		}
		o.hide_flg(!v);

		if (column.getModeInfo().getStatus() != MCMode.INVISIBLE_STATUS) {
			o.visible_flg(true);
		}
		if (!o.hide_flg()) {
			Integer w = data.getColumnWidth();
			if (w == null) {
				w = column.getColumnWidth();
				w = MCBeansUtil.adjust(w, t.getRatio(), 100);
			}
			o.width(w);
		}
		else {
			o.width(0);
		}

		Boolean f = data.getUnscrollColumn();
		if (f == null) {
			f = column == t.getUnscrollColumn();
		}
		o.fixed_flg(f);

		Boolean a = data.getColumnAdjustWidth();
		if (a == null) {
			a = column.isAdjustWidth();
		}
		o.adjust_flg(a);

		// 7013-1209(【A1】【FM-10】一覧テーブルの機能強化)
		Boolean rc = data.getRequiredColumn();
		if(rc == null) {
			rc = false;
		}
		o.required_flg(rc);
		// 7013-1209 ここまで

		return o;
	}


	@Override
	protected void setTargetPanelDefault() {
		MCTable<?> t = getTargetTable();
		Component e = t.getMCEditorComponent();

		// カラムの表示可否・幅
		setColumnPropertyDefault();
		// カラム順
		t.setColumnOrderDefault();
		// 固定カラム
		t.setUnscrollColumn(t.getDefaultUnscrollColumn());

		afterUpdateTable(e);

		// テーブルを同期する
		getTargetTable().doHSyncTable();

		getTargetTable()._setColumnWidthInfo(null);
		clearColumnWidthInfoList();
	}

	/**
	 * 親画面のカラムの情報をデフォルトに戻します。
	 */
	protected void setColumnPropertyDefault() {
		for (MCColumnConfig c : getTargetColumnConfigs()) {
			c.setDefault();
		}
	}

	/**
	 * 親画面のテーブルを更新した後に実行されます。
	 *
	 * @param table テーブル
	 * @param editor テーブルのエディタ
	 */
	protected void afterUpdateTable(Component editor) {
		MCTable<?> t = getTargetTable();
		int idx = -1;
		MCColumnConfig c = null;
		if (editor != null) {
			if (editor instanceof MCEditorBeans) {
				MCEditorBeans e = (MCEditorBeans)editor;
				idx = e.getRowIndex();
				c = e.getColumnConfig();
			}
		}
		else {
			Component o = MCBeansUtil.getFocusOwner(t);
			if (t.equalsIgnoreCase(o)) {
				idx = t.getMCSelectedRow();
				c = t.getSelectedColumnConfig();
			}
		}
		if (idx > -1 && c != null) {
			if (c.isVisible()) {
				t.focusCellAt(idx, c);
			}
			else {
				t.selectLeftmostColumn(idx);
			}
		}
	}

	@Override
	protected void updateTargetPanel() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		FSBAP_ColOdrInfo ci = getSettingInfo(s);
		updateTable(ci.getColOdrList());

		MCTable<?> t = getTargetTable();
		for (MCColumnWidthInfo i : t.getColumnWidthInfoList()) {
			if (isSame(s.setting_unit_type(), i.getSettingUnitType())
					&& isSame(s.setting_info_id(), i.getSettingInfoID())) {
				t._setColumnWidthInfo(i);
				break;
			}
		}
	}

	protected void updateTable(MCList<?> list) {
		if (list == null) {
			return;
		}
		MCTable<?> t = getTargetTable();
		Component e = t.getMCEditorComponent();
		// 更新処理
		execUpdateTable(list);
		// 更新後処理
		afterUpdateTable(e);
	}

	/**
	 * テーブルを画面の設定で更新します。
	 */
	protected void execUpdateTable(MCList<?> list) {
		MCTable<?> t = getTargetTable();

		// カラムの表示順
		Map<Integer, MCColumnConfig> m = new HashMap<Integer, MCColumnConfig>();

		for (int i = 0; i < list.size(); i++) {
			InfoDtlR o = (InfoDtlR) list.get(i);
			MCColumnConfig c = getTargetColumnConfig(o.column_key());
			MCNumber w = o.width();
			// カラム幅
			// カラムの表示可否
			// カラムの自動幅調整可否
			if (w != null) {
				// 表示可否→カラム幅の順番に設定する
				// 非表示→表示にしたときにカラム幅が変更されるため
				c.setVisibleFromUser(!o.hide_flg());
				((MCTableColumn)c).setColumnWidthFromUser(w.intValue());
				if (!c.isVisible()) {
					c.setColumnWidth(0);
				}
				c.setAdjustWidth(o.adjust_flg());

				// 7013-1209(【A1】【FM-10】一覧テーブルの機能強化)
				// 必須にする。
				c.setRequiredColumn(o.required_flg());
				// 7013-1209 ここまで
			}

			m.put(i, c);
		}

		// カラムの表示順
		t._setUserColumnOrder(m);

		// 固定カラム
		MCList<InfoDtlR> fl = getInfoDtlL().subList(InfoDtlR.$fixed_flg, true);
		int f_cnt = fl.size();
		switch (f_cnt) {
			case 0:
				t.setUnscrollColumn(null);
				break;
			case 1:
				MCColumnConfig c = getTargetColumnConfig(
						fl.get(0).column_key());
				t.setUnscrollColumn(c);
				break;
			default:
				break;
		}
	}


	@Override
	protected void writeResource() {
		// 既存データを削除する
//		removeResource(false);

		// 汎用テーブル編集以外の場合、既存データを削除する
		if (!isTargetGeneralTable()) {
			removeResource(false);
		}

		String u = getSettingR().setting_unit();
		if(mainPanelForBarcode != null) {
			u = setting_unit_barcode();
		}

		MCResourceLayerType type = MCColumnWidthResourceIO.toResourceLayerType(u);

		MCTable<?> tbl = getTargetTable();
		String pfx = tbl.getPersonalizedKeyPrefix(COLUMN_WIDTH_PANEL, type);

		MCColumnWidthResourceIO cio = new MCColumnWidthResourceIO();

		ListDtlR selectedDtlR = ListDtlTable.getSelectedMCRow();

		Integer no = _setting_info_no_map.get(u);
		if (no == null) {
			no = Math.max(getMaxSettingInfoNO(), 0);
		}
		for (ListDtlR o : getListDtlL()) {
			// 空またはステータスがDELETEで汎用テーブル編集以外の場合
			if (o.isEmpty() || (o.isStatusDelete() && !isTargetGeneralTable())) {
				continue;
			}

			ListDtlR c1;
			MCList<InfoDtlR> c2;

			String y = o.setting_unit_type();

			// 選択行ではない場合
			if (selectedDtlR != o) {
				if (!u.equals(y)) {
					continue;
				}

				FSBAP_ColOdrInfo ci = getSettingInfo(o);
				if (ci == null) {
					continue;
				}

				c1 = ci.getSettingInfo().clone();
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				c2 = ci.getColOdrList().clone();
			}
			// 選択行の場合
			else {
				if (isNull(y)) {
					o.setting_unit_type(u);
					FXC_RESOURCE_SETTING_UNIT.putNameNE(o,
							ListDtlR.$setting_unit_type,
							ListDtlR.$setting_unit_type_nm);
					y = o.setting_unit_type();
				}

				if (!u.equals(y)) {
					continue;
				}

				c1 = createListDtlR();
				c2 = createInfoDtlL();
				c1.setValues(ListDtlR.colnames(),
						getListHdrR(), ListDtlR.colnames());
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				for (InfoDtlR t : getInfoDtlL()) {
					if (t.isEmpty() || t.isStatusDelete()) {
						continue;
					}
					c2.add(t.clone());
				}

				// 汎用テーブル編集の場合
				if (isTargetGeneralTable()) {
					String id = c1.setting_info_id();
					// 新規の場合
					if (isNull(id)) {
						c1.setting_info_id(cio.createSettingInfoID(c1.setting_unit_type(), no++));
						removeResourceById(false, null);
					}
					// 更新または削除の場合、対象のIDのみを削除する
					else {
						removeResourceById(false, id);
					}
					// 削除の場合は追加しない
					if (!selectedDtlR.isStatusDelete()) {
						MCColumnWidthInfo ci = MCColumnWidthInfo.create();
						ci.setSettingInfoID(c1.setting_info_id());
						ci.setInitFlg(c1.init_flg());
						ci.setSettingUnitType(c1.setting_unit_type());
						ci.setSettingInfoName(c1.setting_info_nm());
						ci.setRemark(c1.remark());
	
						List<MCColumnWidthData> cl = new ArrayList<MCColumnWidthData>();
						for (int j=0;j<c2.size();j++) {
							MCColumnWidthData d = new MCColumnWidthData();
							MCColumnConfig c = getTargetColumnConfig(c2.get(j).column_key());
							setWriteResourceInfo(d, c, c2, j);
							cl.add(d);
						}
	
						ci.setColumnWidthList(cl);
						cio.addInfo(ci);
					}
				}
			}

			// 汎用テーブル編集以外の場合
			if (!isTargetGeneralTable()) {
				MCColumnWidthInfo ci = MCColumnWidthInfo.create();
	
				String id = c1.setting_info_id();
				if (isNull(id)) {
					c1.setting_info_id(cio.createSettingInfoID(c1.setting_unit_type(), no++));
				}
				ci.setSettingInfoID(c1.setting_info_id());
				ci.setInitFlg(c1.init_flg());
				ci.setSettingUnitType(c1.setting_unit_type());
				ci.setSettingInfoName(c1.setting_info_nm());
				ci.setRemark(c1.remark());
	
				List<MCColumnWidthData> cl = new ArrayList<MCColumnWidthData>();
				for (int j=0;j<c2.size();j++) {
					MCColumnWidthData d = new MCColumnWidthData();
					MCColumnConfig c = getTargetColumnConfig(c2.get(j).column_key());
					setWriteResourceInfo(d, c, c2, j);
					cl.add(d);
				}
	
				ci.setColumnWidthList(cl);
				cio.addInfo(ci);
			}
		}

		boolean isNotEmpty = cio.getInfoList().size() > 0 ? true : false;
		if (isNotEmpty) {
			Map<String, Integer> m = new HashMap<String, Integer>();
			m.put(u, no);
			cio.writeNoSave(pfx, m);
		}
		MCColumnWidthResourceIO.saveResource();
	}

	protected void setWriteResourceInfo(
			MCColumnWidthData data, MCColumnConfig column,
			MCList<?> list, int index) {
		InfoDtlR o = (InfoDtlR) list.get(index);
		data.setColumnName(o.column_key());
		data.setColumnOrder(index);
		data.setColumnWidth(isNull(o.width()) ? -1 : o.width().intValue());
		data.setColumnVisible(!o.hide_flg());
		data.setColumnAdjustWidth(o.adjust_flg());
		data.setUnscrollColumn(o.fixed_flg());

		// 7013-1209(【A1】【FM-10】一覧テーブルの機能強化)
		// リソースにはそのままの値で書き込み実行時に動的に必須計算をする。
		data.setRequiredColumn(o.required_flg());
		// 7013-1209 ここまで
	}

	@Override
	public MCTable<?> getRowMoveTable() {
		return InfoDtlTable;
	}

	@Override
	public boolean isStatusChange() {
		return true;
	}

	@Override
	protected boolean checkForLoad() {
		if (!super.checkForLoad()) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}

		return true;
	}

	@Override
	protected void doLoad() {
		super.doLoad();

		MCList<InfoDtlR> ol = _init_table_list;
		if (ol == null) {
			return;
		}

		MCList<InfoDtlR> nl = createInfoDtlL();
		// 既存行変更
		if (getInfoDtlL().size() == ol.size()) {
			MCList<InfoDtlR> tvl = createInfoDtlL();
			tvl.addAll(getInfoDtlL());

			ListDtlR s = ListDtlTable.getSelectedMCRow();
			boolean e = s != null && getSettingInfo(s) != null;

			for (int i = 0; i < ol.size(); i++) {
				InfoDtlR o = ol.get(i);
				MCList<InfoDtlR> sl = tvl.subList(
						InfoDtlR.$column_key, o.column_key());
				if (sl.size() != 1) {
					break;
				}
				InfoDtlR so = sl.get(0);
				InfoDtlR n = o.clone();
				nl.add(n);

				// 表示されている行と異なる場合は、変更ステータスとする
				if (!so.equals(n) || i != getInfoDtlL().indexOf(so)) {
					if (e) {
						n.setStatus(MCRow.MODIFY);
					}
					else {
						n.setStatus(MCRow.CREATE);
					}
				}
				// 表示されている行と同じ場合は、ステータスを変更しない
				else {
					n.setStatus(so.getStatus());
				}

				tvl.removeAll(sl);
			}

			if (nl.size() == ol.size()) {
				setInfoDtlL(nl);
				return;
			}

			nl.clear();
		}
		// 新規追加
		for (InfoDtlR o : ol) {
			InfoDtlR n = o.clone();
			nl.add(n);
			n.setStatus(MCRow.GUICREATE);
		}
		setInfoDtlL(nl);
	}

	@Override
	protected void afterCopyRow() {
		super.afterCopyRow();

		for (InfoDtlR o : getInfoDtlL()) {
			if (!o.isEmpty()) {
				o.setStatus(MCRow.CREATE);
			}
		}

		getListHdrR().init_flg(false);
		getListHdrR().setting_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		getListHdrR().setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(getListHdrR(),
				ListDtlR.$setting_unit_type,
				ListDtlR.$setting_unit_type_nm);
// 2017/01/05 登録名も複製する
//		getListHdrR().setting_info_nm(null);

		setStatus(EDIT);
	}

	@Override
	protected boolean checkForApply() {
		if (!super.checkForApply()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		MCList<InfoDtlR> l = exceptEmpty(getInfoDtlL());

		// カラム情報の必須項目をチェックする
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			ListDtlR o = ListDtlTable.getSelectedMCRow();
			setInitListData(o);
			setInitInfoData(o);
		}

		return true;

	}

	@Override
	protected void doApplyCloseAction() {
		doApplyAction();
	}

	@Override
	protected void afterApply() {
		super.afterApply();

		_init_table_list = null;

		requestCloseWindow();
	}

	@Override
	protected void afterDef() {
		super.afterDef();

		_init_table_list = null;
		clearColumnWidthInfoList();
	}

	@Override
	protected boolean checkForUpd() {
		if (!super.checkForUpd()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		// 固定カラムチェック
		if (!checkUnscrollColumn()) {
			return false;
		}

		return true;
	}

	// 640
	//サブクラスでcheckForUpdを上書きするためのメソッド
	protected boolean checkForUpd2() {
		if (!super.checkForUpd()) {
			return false;
		}
		return true;
	}

	/**
	 * 固定カラムの位置をチェックします。
	 * 登録処理の前に実行されます。
	 *
	 * @return 登録処理を実行できない場合は false
	 */
	protected boolean checkUnscrollColumn() {
		MCList<InfoDtlR> temp = getInfoDtlL();
		// 固定カラムチェック
		MCList<InfoDtlR> list = temp.subList(InfoDtlR.$fixed_flg, true);
		int count = list.size();
		switch (count) {
			case 0:
				break;
			case 1:
				// 一番下の行が固定カラムの場合はエラー
				InfoDtlR row = list.get(0);
				int index = temp.indexOf(row);
				if (index == temp.size() - 1) {
					MCTable<?> t = getTargetTable();
					MCColumnConfig[] a = t.getColumnConfigs();
					if (temp.size() == a.length) {
						dialog(FSBAC0006);
						return false;
					}
				}
				break;
			default:
				// ここは絶対に通過しないが念のためチェックする
				dialog(FSBAC0007);
				return false;
		}
		return true;
	}

	@Override
	protected void afterUpd() {
		super.afterUpd();

		clearColumnWidthInfoList();
	}

	@Override
	protected void afterDel() {
		super.afterDel();

		clearColumnWidthInfoList();
	}

	@Override
	protected FSBAP_ColOdrInfo getSettingInfo(ListDtlR data) {
		return (FSBAP_ColOdrInfo)super.getSettingInfo(data);
	}

	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * 設定対象のテーブルを指定してください。
	 * </li>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0048] 引数の指定に誤りがあった場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ]
	 * 起動タイプに {@link T1} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			Object o = args[0];
			if (o == null || !(o instanceof MCTable<?>)) {
				throw new MCAppException(FSBAC0049);
			}

			MCTable<?> t = (MCTable<?>)o;
			setTargetTable(t);
			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
	}



	@Override
	public void doInfoDtl_fixed_flg_NC(MCEventInfo info) {
		super.doInfoDtl_fixed_flg_NC(info);

		InfoDtlR s = getInfoDtlL().get(info.getEventIndex());
		if (s.fixed_flg()) {
			for (InfoDtlR o : getInfoDtlL()) {
				if (o == s) {
					continue;
				}
				setValueEx(columnInfoDtl_fixed_flg, o.getGUIIndex(), false);
			}
		}
	}

	@Override
	public void doInfoDtl_hide_flg_NC(MCEventInfo info) {
		super.doInfoDtl_hide_flg_NC(info);

		InfoDtlR o = getInfoDtlL().get(info.getEventIndex());
		// 表示に切り替えた場合
		// カラム幅が null または 0 以下の場合は初期値を設定する
		if (!o.hide_flg()) {
			MCNumber w = o.width();
			if (w == null || w.lte(0)) {
				o.width(getTargetColumnConfig(
						o.column_key()).getInitWidth());
			}
		}

	}

	@Override
	public void doInfoHdr_adjust_flg_NC(MCEventInfo info) {
		super.doInfoHdr_adjust_flg_NC(info);

		boolean v = getInfoHdrR().adjust_flg();

		for (InfoDtlR o : getInfoDtlL()) {
			if (o.adjust_flg() != v) {
				InfoDtlTable.setValue(
						v, o.getGUIIndex(), columnInfoDtl_adjust_flg);
			}
		}

	}

	@Override
	public boolean doInfoDtl_width_VC(MCEventInfo info) {
		if (!super.doInfoDtl_width_VC(info)) {
			return false;
		}

		MCNumber v = getInfoDtlL().get(info.getEventIndex()).width();
		if (v == null) {
			return true;
		}

		int x = getPgmSettingInt(this, "maxwidth");
		if (MCNumber.valueOf(x).lt(v)) {
			dialog(FSBAC0039, x);
			return false;
		}

		return true;

	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!super.doListDtl_VC(info)) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone() || !getListHdrR().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			setInitListData(ListDtlTable.getSelectedMCRow());

		}

		return true;
	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);

		ListDtlR o = ListDtlTable.getSelectedMCRow();
		// 行が選択されなかった場合
		if (o == null) {
			getInfoDtlL().clear();
			getListHdrR().clearAll();
			setStatus(INIT);
			return;
		}

		setInitListData(o);
		setInitInfoData(o);

		setStatus(EDIT);

	}

	@Override
	public void setEDITStatus() {
		super.setEDITStatus();

		setRowMoveButtonMode();
	}

	protected void setRowMoveButtonMode() {
		if (!getTargetTable().isReorderingAllowed()) {
			InfoBtn_row_move_p_PPanel.setDISABLEStatus();
		}
		else {
			InfoBtn_row_move_p_PPanel.setENABLEStatus();
		}
	}

	@Override
	protected boolean isSearchedProgram(String type, String pgmid) {
		return MCColumnWidthResourceIO.isSearchedProgram(type, pgmid);
	}

	@Override
	protected int getSettingInfoNO(ListDtlR data) {
		return MCColumnWidthResourceIO.getSettingInfoNO(data.setting_unit_type(), data.setting_info_id());
	}

	protected void clearColumnWidthInfoList() {
		if (mainPanelForBarcode == null) {
			getTargetTable()._setColumnWidthInfoList(null);
		}
		else {
			getTargetTable()._setBarcodeColumnWidthInfoList(null);
		}
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		InfoDtlTable.setCellConfig(createInfoDtlCellConfig());
	}

	/**
	 * カラム情報テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return カラム情報テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createInfoDtlCellConfig() {
		return new WBP_InfoDtlCellConfig();
	}

	/**
	 * 削除処理を実行します。
	 */
	@Override
	protected void doDel() {
		// 汎用テーブル編集の場合、ステータスをDELETEにする
		// リソース更新後にリストから対象行を削除する
		if (isTargetGeneralTable()) {
			// 選択中の行を取得
			ListDtlR s = ListDtlTable.getSelectedMCRow();

			s.setStatus(Status.DELETE);
			writeResource();
			getListDtlL().remove(s);
			clearSelection(ListDtlTable);
		}
		// 汎用テーブル編集以外の場合、親クラスのメソッドを呼び出す。
		else {
			super.doDel();
		}
	}

	/**
	 * 対象画面が汎用テーブル編集かどうかを返します。
	 * 
	 * @return 汎用テーブル編集の場合はtrue、それ以外の場合はfalse
	 */
	private boolean isTargetGeneralTable() {
		MCTable<?> t = getTargetTable();
		if (t != null) {
			MCRootPanel p = t.getBaseRootPanel();

			if (p != null && p.isGeneralTable()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * カラム情報テーブルに設定するセルコンフィグです。
	 */
	public class WBP_InfoDtlCellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			InfoDtlR o = getInfoDtlL().get(index);
			if (!o.visible_flg()) {
				// 自動調整は編集可能
				if (column != columnInfoDtl_adjust_flg) {
					return MCMode.DISABLE;
				}
			}
			return super.getPriorMode(index, column, table);
		}

	}

	/**
	 * 設定情報を格納します。
	 */
	public class FSBAP_ColOdrInfo extends WBP_PersonalizeInfo {

		/**
		 * カラム情報のリストです。
		 */
		protected MCList<InfoDtlR> _col_odr_list = null;

		/**
		 * コンストラクタです。
		 */
		public FSBAP_ColOdrInfo() {}

		/**
		 * カラム情報のリストを設定します。
		 *
		 * @param list カラム情報のリスト
		 */
		public void setColOdrList(MCList<InfoDtlR> list) {
			_col_odr_list = list;
		}

		/**
		 * カラム情報のリストを返します。
		 *
		 * @return カラム情報のリスト
		 */
		public MCList<InfoDtlR> getColOdrList() {
			return _col_odr_list;
		}
	}

}