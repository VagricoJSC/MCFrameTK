package mcframe.clientFSBA.FSBAP0090;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoDtlR_FW_A extends MCConstRow {

	/**
	 *  キー.<p>
	 *
	 */
	public static final String $column_key = "column_key";
	/**
	 *  カラム名.<p>
	 *
	 */
	public static final String $column_nm = "column_nm";
	/**
	 *  表示.<p>
	 *
	 */
	public static final String $visible_flg = "visible_flg";
	/**
	 *  非表示にする.<p>
	 *
	 */
	public static final String $hide_flg = "hide_flg";
	/**
	 *  必須にする.<p>
	 *
	 */
	public static final String $required_flg = "required_flg";
	/**
	 *  カラム幅.<p>
	 *
	 */
	public static final String $width = "width";
	/**
	 *  自動調整.<p>
	 *
	 */
	public static final String $adjust_flg = "adjust_flg";
	/**
	 *  固定カラム.<p>
	 *
	 */
	public static final String $fixed_flg = "fixed_flg";


	public static final MCMeta column_key_META = createStringMeta($column_key);
	public static final MCMeta column_nm_META = createCommonMeta($column_nm, mcframe.commonCore.meta.M_META.LABEL);
	public static final MCMeta visible_flg_META = createCommonMeta($visible_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta hide_flg_META = createCommonMeta($hide_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta required_flg_META = createCommonMeta($required_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta width_META = createNumberMeta($width, 100, 0, false);
	public static final MCMeta adjust_flg_META = createCommonMeta($adjust_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta fixed_flg_META = createCommonMeta($fixed_flg, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<InfoDtlR> constMetas = new ConstMetaList<InfoDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			column_key_META,
			column_nm_META,
			visible_flg_META,
			hide_flg_META,
			required_flg_META,
			width_META,
			adjust_flg_META,
			fixed_flg_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoDtlR_FW_A(ConstMetaList<? extends InfoDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR clone() {
		return (InfoDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR createInstance() {
		return (InfoDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR getValues(String... names) {
		return (InfoDtlR) super.getValues(names);
	}



	/**
	 *  キー.<p>
	 *
	 */
	public String column_key() {
		return getConstString(offset + 0, $column_key);
	}

	/**
	 *  キー.<p>
	 *
	 */
	public void column_key(String value) {
		setConstString(offset + 0, $column_key, value);
	}


	/**
	 *  カラム名.<p>
	 *
	 */
	public String column_nm() {
		return getConstString(offset + 1, $column_nm);
	}

	/**
	 *  カラム名.<p>
	 *
	 */
	public void column_nm(String value) {
		setConstString(offset + 1, $column_nm, value);
	}


	/**
	 *  表示.<p>
	 *
	 */
	public boolean visible_flg() {
		return getConstBoolean(offset + 2, $visible_flg);
	}

	/**
	 *  表示.<p>
	 *
	 */
	public void visible_flg(boolean value) {
		setConstBoolean(offset + 2, $visible_flg, value);
	}


	/**
	 *  非表示にする.<p>
	 *
	 */
	public boolean hide_flg() {
		return getConstBoolean(offset + 3, $hide_flg);
	}

	/**
	 *  非表示にする.<p>
	 *
	 */
	public void hide_flg(boolean value) {
		setConstBoolean(offset + 3, $hide_flg, value);
	}


	/**
	 *  必須にする.<p>
	 *
	 */
	public boolean required_flg() {
		return getConstBoolean(offset + 4, $required_flg);
	}

	/**
	 *  必須にする.<p>
	 *
	 */
	public void required_flg(boolean value) {
		setConstBoolean(offset + 4, $required_flg, value);
	}


	/**
	 *  カラム幅.<p>
	 *
	 */
	public MCNumber width() {
		return getConstNumber(offset + 5, $width);
	}

	/**
	 *  カラム幅.<p>
	 *
	 */
	public void width(MCNumber value) {
		setConstNumber(offset + 5, $width, value);
	}

	/**
	 *  カラム幅.<p>
	 *
	 */
	public void width(int value) {
		setConstNumber(offset + 5, $width, value);
	}

	/**
	 *  カラム幅.<p>
	 *
	 */
	public void width(long value) {
		setConstNumber(offset + 5, $width, value);
	}

	/**
	 *  カラム幅.<p>
	 *
	 */
	public void width(float value) {
		setConstNumber(offset + 5, $width, value);
	}

	/**
	 *  カラム幅.<p>
	 *
	 */
	public void width(double value) {
		setConstNumber(offset + 5, $width, value);
	}


	/**
	 *  自動調整.<p>
	 *
	 */
	public boolean adjust_flg() {
		return getConstBoolean(offset + 6, $adjust_flg);
	}

	/**
	 *  自動調整.<p>
	 *
	 */
	public void adjust_flg(boolean value) {
		setConstBoolean(offset + 6, $adjust_flg, value);
	}


	/**
	 *  固定カラム.<p>
	 *
	 */
	public boolean fixed_flg() {
		return getConstBoolean(offset + 7, $fixed_flg);
	}

	/**
	 *  固定カラム.<p>
	 *
	 */
	public void fixed_flg(boolean value) {
		setConstBoolean(offset + 7, $fixed_flg, value);
	}


	public String getString(String name) {
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($width.equalsIgnoreCase(name)) {
			return width();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			return visible_flg();
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			return hide_flg();
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			return required_flg();
		}
		if ($adjust_flg.equalsIgnoreCase(name)) {
			return adjust_flg();
		}
		if ($fixed_flg.equalsIgnoreCase(name)) {
			return fixed_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($width.equalsIgnoreCase(name)) {
			return width();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			return visible_flg();
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			return hide_flg();
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			return required_flg();
		}
		if ($adjust_flg.equalsIgnoreCase(name)) {
			return adjust_flg();
		}
		if ($fixed_flg.equalsIgnoreCase(name)) {
			return fixed_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			visible_flg(value);
			return;
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			hide_flg(value);
			return;
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			required_flg(value);
			return;
		}
		if ($adjust_flg.equalsIgnoreCase(name)) {
			adjust_flg(value);
			return;
		}
		if ($fixed_flg.equalsIgnoreCase(name)) {
			fixed_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($width.equalsIgnoreCase(name)) {
			width(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			visible_flg(value);
			return;
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			hide_flg(value);
			return;
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			required_flg(value);
			return;
		}
		if ($adjust_flg.equalsIgnoreCase(name)) {
			adjust_flg(value);
			return;
		}
		if ($fixed_flg.equalsIgnoreCase(name)) {
			fixed_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

