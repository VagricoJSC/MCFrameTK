package mcframe.clientFSBA.FSBAP0870;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0430.*;
import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.BoxLayout;

import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.clientCore.mining.MCMiningUtil;
import mcframe.clientFSBA.FSBAP0850.CondDtlR;
import mcframe.clientFSBA.FSBAP0850.MethodDtlR;
import mcframe.clientFSBA.FSBAP0850.ParamDtlR;
import mcframe.clientFSBA.FSBAP0850.TaskParamEditor;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0870"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0870_FW extends FSBAP0870_FW_A implements TaskParamEditor {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0870_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		super.layoutInit();

		Value_threshould_PPanel.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BoxLayout(ValuePanel, BoxLayout.Y_AXIS));

		ValuePanel.add(Value_threshould_PPanel);
// スペーサのサンプル
//		ValuePanel.add(Box.createRigidArea(new Dimension(5, 5)));
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return Value_threshould_PPanel.getModeCtrlBeans();
	}

	@Override
	public String getStatusFor(MCValueSupply...param) {
		return Value_threshould_PPanel.getStatusFor(param);
	}

	@Override
	public MCValueSupply[] getParam() {
		return Value_threshould_PPanel.getParam();
	}

	/**
	 * パラメータを設定します。
	 *
	 * @param param 設定パラメータの配列（項目、しきい値、比較方法）
	 */
	@Override
	public void setParam(MCValueSupply...param) {
		Value_threshould_PPanel.setParam(param);
	}

	@Override
	public void setValueList(MCList<ListR> listL) {
		Value_threshould_PPanel.setValueList(listL);
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		return Value_threshould_PPanel.checkRequiredValue();
	}

	@Override
	public void updateParam() {
		Value_threshould_PPanel.updateParam();
	}

	/**
	 * パラメータを生成します。
	 *
	 * @return 設定パラメータの配列（項目、しきい値、比較方法）
	 */
	@Override
	public MCValueSupply[] createParam() {
		// しきい値用ValueSupply 生成
		// 表示名称はガジェットと合わせる
		String name = MCDashboard.getGadgetAttrLabel(MCMiningUtil.KEY_THRESHOLD);
		// 7012-1327 運用日付は画面から渡す
		MCDate today = getToday();
		return new MCValueSupply[] {
				MCValueSupply.create(
						MCMiningUtil.KEY_THRESHOLD + ".col", name,
						MCMiningUtil.TYPE_STRING, true, true, today),
				MCValueSupply.create(
						MCMiningUtil.KEY_THRESHOLD + ".val", name,
						MCMiningUtil.TYPE_NUMBER, true, true, today),
				MCValueSupply.create(
						MCMiningUtil.KEY_THRESHOLD + ".rel", name,
						MCMiningUtil.TYPE_STRING, true, true, today),
		};
	}

	@Override
	public MCList<ListR> createComboList(
								MCValueSupply[] params,
								MCList<CondDtlR> condL,
								MCList<MethodDtlR> methodL,
								MCList<ParamDtlR> paramL
	) {
		// 項目
		// 集計情報のグラフ項目から作成
		MCList<ListR> list = MCList.create(ListR.class);
		for (MethodDtlR methodR : methodL) {
			// 集計用カラム名がキーになるようにする
			String colto = MCMiningUtil.createSumColumnId(
												methodR.col_id(),
												methodR.sumcond(),
												methodR.sum_info_typ());
			MCMiningUtil.addParamComboListRow(list, params[0],
												colto, methodR.col_nm());
		}
		return list;
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	public Dimension getMaximumSize() {
		// 幅は左詰めにするため最大値にする。
		return new Dimension(Short.MAX_VALUE,(int)super.getSize().getHeight());
	}

}