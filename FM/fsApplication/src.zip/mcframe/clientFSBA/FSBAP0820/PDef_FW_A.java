package mcframe.clientFSBA.FSBAP0820;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_MiningTask]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0820.Srch01.UP.BLOCK0")){
			return FS_FSBAL0820_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Srch01.DOWN.BLOCK0")){
			return FS_FSBAL0820_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Del01.UP.BLOCK0")){
			return FS_FSBAL0820_Del01_UP_BLOCK0();
		}
		else if (id.equals("EXEC.UP.BLOCK0")){
			return EXEC_UP_BLOCK0();
		}
		else if (id.equals("EXECSRCH.UP.BLOCK0")){
			return EXECSRCH_UP_BLOCK0();
		}
		else if (id.equals("EXECSRCH.DOWN.BLOCK0")){
			return EXECSRCH_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
				
	
	static final MCOperationInfo FS_FSBAL0820_Srch01_INFO = new MCOperationInfo("FS", "FSBAL0820", "Srch01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0820_Srch01_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch01",
			new MCItemDef[]{
				MCItemDef.IGNORE_ITEM("task_id"),
				MCItemDef.IGNORE_ITEM("mining_id"),
				MCItemDef.IGNORE_ITEM("user_id"),
				MCItemDef.create("co_cd", "co_cd")
			}
			,
			MCBlockDef.create("Cnd")
		);
	}


	public static MCContainerDef FS_FSBAL0820_Srch01_DOWN_BLOCK0() {
	/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("task_nm", "task_nm"),
				MCItemDef.create("task_type", "task_typ"),
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("user_nm", "user_nm"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("co_nm", "co_nm"),
				MCItemDef.create("inv_flg", "inv_flg"),
				MCItemDef.create("sche_dt", "sche_dt"),
				MCItemDef.create("start_dt", "start_dt"),
				MCItemDef.create("end_dt", "end_dt"),
				MCItemDef.create("msg_id", "msg_id"),
				MCItemDef.create("msg_bind", "msg_bind"),
				MCItemDef.create("msg_lv", "msg_lv"),
				MCItemDef.create("msg", "msg"),
				MCItemDef.create("srv_id", "srv_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Task")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0820_Del01_INFO = new MCOperationInfo("FS", "FSBAL0820", "Del01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0820_Del01_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Del01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id")
			}
			,
			MCBlockDef.create("Task")
		);
	}
	
	static final MCOperationInfo EXEC_INFO = new MCOperationInfo("EXEC", "FS", "FSBAL0820", "Upd02", "000000", new PDef());

	public static MCContainerDef EXEC_UP_BLOCK0() {
		/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Upd02",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id")
			}
			,
			MCBlockDef.create("ExecCnd")
		);
	}
	
	static final MCOperationInfo EXECSRCH_INFO = new MCOperationInfo("EXECSRCH", "FS", "FSBAL0820", "Srch01", "000000", new PDef());

	public static MCContainerDef EXECSRCH_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.IGNORE_ITEM("mining_id"),
				MCItemDef.IGNORE_ITEM("user_id"),
				MCItemDef.IGNORE_ITEM("co_cd")
			}
			,
			MCBlockDef.create("ExecCnd")
		);
	}


	public static MCContainerDef EXECSRCH_DOWN_BLOCK0() {
	/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("task_nm", "task_nm"),
				MCItemDef.create("task_type", "task_typ"),
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("user_nm", "user_nm"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("co_nm", "co_nm"),
				MCItemDef.create("inv_flg", "inv_flg"),
				MCItemDef.create("sche_dt", "sche_dt"),
				MCItemDef.create("start_dt", "start_dt"),
				MCItemDef.create("end_dt", "end_dt"),
				MCItemDef.create("msg_id", "msg_id"),
				MCItemDef.create("msg_bind", "msg_bind"),
				MCItemDef.create("msg_lv", "msg_lv"),
				MCItemDef.create("msg", "msg"),
				MCItemDef.create("srv_id", "srv_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Exec")
		);
	}
	//FMCB DEF_CLASSES END
}

