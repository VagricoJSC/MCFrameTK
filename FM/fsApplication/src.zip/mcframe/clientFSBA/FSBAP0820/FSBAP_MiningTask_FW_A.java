package mcframe.clientFSBA.FSBAP0820;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0820.FSBAP_MiningTask_FW.FS_FSBAL0820_Srch01Caller;
import mcframe.clientFSBA.FSBAP0820.FSBAP_MiningTask_FW.FS_FSBAL0820_Del01Caller;
import mcframe.clientFSBA.FSBAP0820.FSBAP_MiningTask_FW.EXECCaller;
import mcframe.clientFSBA.FSBAP0820.FSBAP_MiningTask_FW.EXECSRCHCaller;

/**
 * 画面"FSBAP_MiningTask"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_MiningTask_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0820";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	// [Cnd]ブロックの項目のField定義
	public MCLabel Cnd_co_cd_Label = null;
	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public MCTextComboBox Cnd_co_cd = null;
	/**
	 *  会社名.<p>
	 *
	 */
	public MCTextField Cnd_co_nm = null;
	/**
	 *  検索する.<p>
	 *
	 */
	public MCButton Cnd_srch = null;
	// [Task]ブロック関連のField定義
	public MCPanel TaskPanel = null;
	public MCScrollPane TaskScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0820.TaskR> TaskTable = null;
	// [Task]ブロックの項目のField定義
	/**
	 *  無効.<p>
	 *
	 */
	public MCColumnConfig columnTask_inv_flg = null;
	/**
	 *  タスク名.<p>
	 *
	 */
	public MCColumnConfig columnTask_task_nm = null;
	/**
	 *  タスク種別名.<p>
	 *
	 */
	public MCColumnConfig columnTask_task_type_nm = null;
	/**
	 *  マイニング名.<p>
	 *
	 */
	public MCColumnConfig columnTask_mining_nm = null;
	/**
	 *  会社名.<p>
	 *
	 */
	public MCColumnConfig columnTask_co_nm = null;
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnTask_user_id = null;
	/**
	 *  ユーザ名.<p>
	 *
	 */
	public MCColumnConfig columnTask_user_nm = null;
	/**
	 *  次回実行日時.<p>
	 *
	 */
	public MCColumnConfig columnTask_sche_dt = null;
	/**
	 *  実行日時.<p>
	 *
	 */
	public MCColumnConfig columnTask_start_dt = null;
	/**
	 *  終了日時.<p>
	 *
	 */
	public MCColumnConfig columnTask_end_dt = null;
	/**
	 *  実行結果レベル.<p>
	 *
	 */
	public MCColumnConfig columnTask_msg_lv = null;
	/**
	 *  実行結果ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnTask_msg_id = null;
	/**
	 *  実行結果.<p>
	 *
	 */
	public MCColumnConfig columnTask_msg = null;
	/**
	 *  実行サーバ.<p>
	 *
	 */
	public MCColumnConfig columnTask_srv_id = null;
	// [BtnWest]ブロック関連のField定義
	public MCPanel BtnWestPanel = null;
	// [BtnWest]ブロックの項目のField定義
	/**
	 *  追加.<p>
	 *
	 */
	public MCButton BtnWest_add = null;
	/**
	 *  コピー.<p>
	 *
	 */
	public MCButton BtnWest_cpy = null;
	/**
	 *  編集.<p>
	 *
	 */
	public MCButton BtnWest_mod = null;
	/**
	 *  実行する.<p>
	 *
	 */
	public MCButton BtnWest_run = null;
	// [BtnEast]ブロック関連のField定義
	public MCPanel BtnEastPanel = null;
	// [BtnEast]ブロックの項目のField定義
	/**
	 *  削除する.<p>
	 *
	 */
	public MCButton BtnEast_del = null;
	/** [ADMIN]モードを表す定数 */
	public static final String ADMIN = "ADMIN";
	/** [EXTADM]モードを表す定数 */
	public static final String EXTADM = "EXTADM";
	/** [USER]モードを表す定数 */
	public static final String USER = "USER";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ADMIN, EXTADM, USER};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0820_Srch01]のCallerの作成 */
	protected FSBAP_MiningTask_FW.FS_FSBAL0820_Srch01Caller createFS_FSBAL0820_Srch01() {
		FSBAP_MiningTask_FW.FS_FSBAL0820_Srch01Caller<FSBAP_MiningTask, FS_FSBAL0820_Srch01Bridge>
		caller = ((FSBAP_MiningTask_FW)this).new FS_FSBAL0820_Srch01Caller<FSBAP_MiningTask, FS_FSBAL0820_Srch01Bridge>(
					(FSBAP_MiningTask)this, new FS_FSBAL0820_Srch01Bridge());
		return caller;
	}
	/** [FS_FSBAL0820_Srch01]の呼び出し */
	protected void callFS_FSBAL0820_Srch01() {
		MCCaller caller = createFS_FSBAL0820_Srch01();
		caller.exec();
	}
	/** [FS_FSBAL0820_Del01]のCallerの作成 */
	protected FSBAP_MiningTask_FW.FS_FSBAL0820_Del01Caller createFS_FSBAL0820_Del01() {
		FSBAP_MiningTask_FW.FS_FSBAL0820_Del01Caller<FSBAP_MiningTask, FS_FSBAL0820_Del01Bridge>
		caller = ((FSBAP_MiningTask_FW)this).new FS_FSBAL0820_Del01Caller<FSBAP_MiningTask, FS_FSBAL0820_Del01Bridge>(
					(FSBAP_MiningTask)this, new FS_FSBAL0820_Del01Bridge());
		return caller;
	}
	/** [FS_FSBAL0820_Del01]の呼び出し */
	protected void callFS_FSBAL0820_Del01() {
		MCCaller caller = createFS_FSBAL0820_Del01();
		caller.exec();
	}
	/** [EXEC]のCallerの作成 */
	protected FSBAP_MiningTask_FW.EXECCaller createEXEC() {
		FSBAP_MiningTask_FW.EXECCaller<FSBAP_MiningTask, EXECBridge>
		caller = ((FSBAP_MiningTask_FW)this).new EXECCaller<FSBAP_MiningTask, EXECBridge>(
					(FSBAP_MiningTask)this, new EXECBridge());
		return caller;
	}
	/** [EXEC]の呼び出し */
	protected void callEXEC() {
		MCCaller caller = createEXEC();
		caller.exec();
	}
	/** [EXECSRCH]のCallerの作成 */
	protected FSBAP_MiningTask_FW.EXECSRCHCaller createEXECSRCH() {
		FSBAP_MiningTask_FW.EXECSRCHCaller<FSBAP_MiningTask, EXECSRCHBridge>
		caller = ((FSBAP_MiningTask_FW)this).new EXECSRCHCaller<FSBAP_MiningTask, EXECSRCHBridge>(
					(FSBAP_MiningTask)this, new EXECSRCHBridge());
		return caller;
	}
	/** [EXECSRCH]の呼び出し */
	protected void callEXECSRCH() {
		MCCaller caller = createEXECSRCH();
		caller.exec();
	}
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0820.CndR aCndR;
	/** [Task]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0820.TaskR> aTaskL;
	/** [ExecCnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0820.CndR aExecCndR;
	/** [Exec]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0820.TaskR> aExecL;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFSBA.FSBAP0820.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0820.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0820.CndR createCndR() {
		return mcframe.clientFSBA.FSBAP0820.CndR.create();
	}

	/**
	 * コピーによってaTaskLを設定します。
	 *
	 * aTaskLのインスタンスは変更されません。
	 *
	 * @param dataset TaskL
	 */
	public void setTaskL(MCList<mcframe.clientFSBA.FSBAP0820.TaskR> aList) {
		if (getTaskL() != aList) {
			getTaskL().setAll(aList);
		}
	}

	/**
	 * [Task]ブロックのコンテナaTaskLを返します。
	 *
	 * @return TaskL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0820.TaskR> getTaskL() {
		return aTaskL;
	}

	/**
	 * aTaskRを作成します。
	 *
	 * @return TaskR
	 */
	public mcframe.clientFSBA.FSBAP0820.TaskR createTaskR() {
		return mcframe.clientFSBA.FSBAP0820.TaskR.create();
	}

	/**
	 * aTaskLを作成します。
	 *
	 * @return TaskL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0820.TaskR> createTaskL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class);
	}

	/**
	 * TaskTableを初期化します。
	 */
	protected void createTaskTable(){
		if(TaskTable == null){
			TaskTable = beansFactory.createTable2("Task.table");
		}
	}

	/**
	 * 項目コピーによってaExecCndRを設定します。
	 *
	 * aExecCndRのインスタンスは変更されません。
	 *
	 * @param row ExecCndR
	 */
	public void setExecCndR(mcframe.clientFSBA.FSBAP0820.CndR row) {
		if (row != null) {
			MCRow.copyall(getExecCndR(), row);
		}
	}

	/**
	 * [ExecCnd]ブロックのコンテナaExecCndRを返します。
	 *
	 * @return ExecCndR
	 */
	public mcframe.clientFSBA.FSBAP0820.CndR getExecCndR() {
		return aExecCndR;
	}

	/**
	 * aExecCndRを作成します。
	 *
	 * @return ExecCndR
	 */
	public mcframe.clientFSBA.FSBAP0820.CndR createExecCndR() {
		return mcframe.clientFSBA.FSBAP0820.CndR.create();
	}

	/**
	 * コピーによってaExecLを設定します。
	 *
	 * aExecLのインスタンスは変更されません。
	 *
	 * @param dataset ExecL
	 */
	public void setExecL(MCList<mcframe.clientFSBA.FSBAP0820.TaskR> aList) {
		if (getExecL() != aList) {
			getExecL().setAll(aList);
		}
	}

	/**
	 * [Exec]ブロックのコンテナaExecLを返します。
	 *
	 * @return ExecL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0820.TaskR> getExecL() {
		return aExecL;
	}

	/**
	 * aExecRを作成します。
	 *
	 * @return ExecR
	 */
	public mcframe.clientFSBA.FSBAP0820.TaskR createExecR() {
		return mcframe.clientFSBA.FSBAP0820.TaskR.create();
	}

	/**
	 * aExecLを作成します。
	 *
	 * @return ExecL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0820.TaskR> createExecL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getTaskL())) ret.add(getTaskL());
		if(!MCCollectionUtil.contains(ret, getExecCndR())) ret.add(getExecCndR());
		if(!MCCollectionUtil.contains(ret, getExecL())) ret.add(getExecL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getTaskL()) return "Task";
		if(aCnt == getExecCndR()) return "ExecCnd";
		if(aCnt == getExecL()) return "Exec";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("Task")) return getTaskL();
		if(bId.equals("ExecCnd")) return getExecCndR();
		if(bId.equals("Exec")) return getExecL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(TaskPanel);
		ret.add(BtnWestPanel);
		ret.add(BtnEastPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTask_FW_A() {
		aCndR = createCndR();
		aTaskL = createTaskL();
		aExecCndR = createExecCndR();
		aExecL = createExecL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningTask_FW_A(String name) {
		aCndR = createCndR();
		aTaskL = createTaskL();
		createTaskTable();
		TaskTable.setRowName(name);
		aExecCndR = createExecCndR();
		aExecL = createExecL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_MiningTask_FW.jbCreateCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbCreateTask((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbCreateBtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbCreateBtnEast((FSBAP_MiningTask)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FSBAP_MiningTask p) {
	}

	/**
	 * [Task]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTask(FSBAP_MiningTask p) {
	}

	/**
	 * [BtnWest]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtnWest(FSBAP_MiningTask p) {
	}

	/**
	 * [BtnEast]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtnEast(FSBAP_MiningTask p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Cnd_co_cd_ListPutter]の定義 */
	private MCListPutter Cnd_co_cd_p = null;

	/**
	 * [Cnd_co_cd_ListPutter]の取得
	 */
	protected MCListPutter getCnd_co_cd_ListPutter() {
		if (Cnd_co_cd_p == null) {
			Cnd_co_cd_p = createCnd_co_cd_ListPutter(Cnd_co_cd, "co_cd", "co_nm");

		}
		return Cnd_co_cd_p;
	}
	
	
	/** [Task_mining_nm_ListPutter]の定義 */
	private MCListPutter Task_mining_nm_p = null;

	/**
	 * [Task_mining_nm_ListPutter]の取得
	 */
	protected MCListPutter getTask_mining_nm_ListPutter() {
		if (Task_mining_nm_p == null) {
			Task_mining_nm_p = createTask_mining_nm_ListPutter(columnTask_mining_nm, "mining_nm");

		}
		return Task_mining_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTask create(){
		FSBAP_MiningTask p = new FSBAP_MiningTask();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTask create(String name){
		FSBAP_MiningTask p = new FSBAP_MiningTask(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_MiningTask_FW.jbfInitCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbfInitTask((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbfInitBtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbfInitBtnEast((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbInitCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbInitTask((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbInitBtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.jbInitBtnEast((FSBAP_MiningTask)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		// ブロックの項目の初期化
		p.Cnd_co_cd_Label = p.beansFactory.createLabel("Cnd.co_cd_Label");
		p.Cnd_co_cd = p.beansFactory.createTextComboBox("Cnd.co_cd");
		p.Cnd_co_cd.setLabel(p.Cnd_co_cd_Label);
		p.Cnd_co_nm = p.beansFactory.createTextField("Cnd.co_nm");
		p.Cnd_srch = p.beansFactory.createButton("Cnd.srch", "srch");
	}

	/**
	 * [Task]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTask(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.TaskPanel = p.beansFactory.createPanel("Task");
		p.TaskScrollPane = p.beansFactory.createScrollPane("Task.scroll");
		p.createTaskTable();
		// ブロックの項目の初期化
		p.columnTask_inv_flg = p.beansFactory.createTableColumn("Task.inv_flg", MCColumnType.CHECK);
		p.columnTask_task_nm = p.beansFactory.createTableColumn("Task.task_nm", MCColumnType.TEXT);
		p.columnTask_task_type_nm = p.beansFactory.createTableColumn("Task.task_type_nm", MCColumnType.TEXT);
		p.columnTask_mining_nm = p.beansFactory.createTableColumn("Task.mining_nm", MCColumnType.TEXT_COMBO);
		p.columnTask_co_nm = p.beansFactory.createTableColumn("Task.co_nm", MCColumnType.TEXT);
		p.columnTask_user_id = p.beansFactory.createTableColumn("Task.user_id", MCColumnType.TEXT);
		p.columnTask_user_nm = p.beansFactory.createTableColumn("Task.user_nm", MCColumnType.TEXT);
		p.columnTask_sche_dt = p.beansFactory.createTableColumn("Task.sche_dt", MCColumnType.DATE);
		p.columnTask_start_dt = p.beansFactory.createTableColumn("Task.start_dt", MCColumnType.DATE);
		p.columnTask_end_dt = p.beansFactory.createTableColumn("Task.end_dt", MCColumnType.DATE);
		p.columnTask_msg_lv = p.beansFactory.createTableColumn("Task.msg_lv", MCColumnType.TEXT);
		p.columnTask_msg_id = p.beansFactory.createTableColumn("Task.msg_id", MCColumnType.TEXT);
		p.columnTask_msg = p.beansFactory.createTableColumn("Task.msg", MCColumnType.TEXT);
		p.columnTask_srv_id = p.beansFactory.createTableColumn("Task.srv_id", MCColumnType.TEXT);
	}

	/**
	 * [BtnWest]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtnWest(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.BtnWestPanel = p.beansFactory.createPanel("BtnWest");
		// ブロックの項目の初期化
		p.BtnWest_add = p.beansFactory.createButton("BtnWest.add");
		p.BtnWest_cpy = p.beansFactory.createButton("BtnWest.cpy");
		p.BtnWest_mod = p.beansFactory.createButton("BtnWest.mod");
		p.BtnWest_run = p.beansFactory.createButton("BtnWest.run", "upd");
	}

	/**
	 * [BtnEast]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtnEast(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.BtnEastPanel = p.beansFactory.createPanel("BtnEast");
		// ブロックの項目の初期化
		p.BtnEast_del = p.beansFactory.createButton("BtnEast.del", "del");
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.add(p.CndPanel);
		p.setLastBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.TaskPanel);
		p.CndPanel.setValueCheck(false);
		p.CndPanel.setExtValue(MCPanel.SRCH_CND_SETTING_PANEL, true);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.Cnd_co_cd.setListType(MCListType.STRICT);
		p.Cnd_co_cd.setLinkBeans(p.Cnd_co_nm);
		p.CndPanel.add(p.Cnd_co_cd_Label);
		p.CndPanel.add(p.Cnd_co_cd);
		p.CndPanel.setLastBeans(p.Cnd_co_cd);
		p.Cnd_co_cd.setNextBeans(p.Cnd_co_nm);
		p.Cnd_co_cd.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0820.CndR.co_cd_META);
		p.CndPanel.add(p.Cnd_co_nm);
		p.Cnd_co_nm.setNextBeans(p.Cnd_srch);
		p.Cnd_co_nm.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0820.CndR.co_nm_META);
		p.Cnd_srch.setIcon("SEARCH");
		p.Cnd_srch.setFunctionKey(MCFunctionKey.F1);
		p.CndPanel.add(p.Cnd_srch);
	}

	/**
	 * [Task]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTask(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.add(p.TaskPanel);
		p.TaskPanel.setNextBeans(p.BtnWestPanel);
		p.TaskPanel.add(p.TaskScrollPane);
		p.TaskPanel.setLastBeans(p.TaskTable);
		p.TaskScrollPane.setViewportView(p.TaskTable);
		p.TaskTable.setList(p.getTaskL());
		p.TaskTable.setStatusColumnVisible(false);
		p.TaskPanel.setValueCheck(false);
		p.TaskPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [BtnWest]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtnWest(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.add(p.BtnWestPanel);
		p.BtnWestPanel.setNextBeans(p.BtnEastPanel);
		p.BtnWestPanel.setValueCheck(false);
		p.BtnWestPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.BtnWest_add.setFunctionKey(MCFunctionKey.F5);
		p.BtnWestPanel.add(p.BtnWest_add);
		p.BtnWestPanel.setLastBeans(p.BtnWest_add);
		p.BtnWest_add.setNextBeans(p.BtnWest_cpy);
		p.BtnWest_cpy.setFunctionKey(MCFunctionKey.F17);
		p.BtnWestPanel.add(p.BtnWest_cpy);
		p.BtnWest_cpy.setNextBeans(p.BtnWest_mod);
		p.BtnWest_mod.setFunctionKey(MCFunctionKey.F4);
		p.BtnWestPanel.add(p.BtnWest_mod);
		p.BtnWest_mod.setNextBeans(p.BtnWest_run);
		p.BtnWest_run.setIcon("R_PLAY");
		p.BtnWest_run.setFunctionKey(MCFunctionKey.F8);
		p.BtnWestPanel.add(p.BtnWest_run);
	}

	/**
	 * [BtnEast]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtnEast(FSBAP_MiningTask p) {
		// ブロック関連の初期化
		p.add(p.BtnEastPanel);
		p.BtnEastPanel.setValueCheck(false);
		p.BtnEastPanel.setLayoutPosition("SE");
		// ブロックの項目の初期化
		p.BtnEast_del.setIcon("DELETE");
		p.BtnEast_del.setFunctionKey(MCFunctionKey.F12);
		p.BtnEastPanel.add(p.BtnEast_del);
		p.BtnEastPanel.setLastBeans(p.BtnEast_del);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_MiningTask_FW.mcInitCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.mcInitTask((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.mcInitBtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.mcInitBtnEast((FSBAP_MiningTask)this);

		// [ADMIN]ステータスのモードの設定
		FSBAP_MiningTask_FW.statusInitADMIN_Cnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitADMIN_Task((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitADMIN_BtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitADMIN_BtnEast((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitADMIN_ExecCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitADMIN_Exec((FSBAP_MiningTask)this);

		// [EXTADM]ステータスのモードの設定
		FSBAP_MiningTask_FW.statusInitEXTADM_Cnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitEXTADM_Task((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitEXTADM_BtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitEXTADM_BtnEast((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitEXTADM_ExecCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitEXTADM_Exec((FSBAP_MiningTask)this);

		// [USER]ステータスのモードの設定
		FSBAP_MiningTask_FW.statusInitUSER_Cnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitUSER_Task((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitUSER_BtnWest((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitUSER_BtnEast((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitUSER_ExecCnd((FSBAP_MiningTask)this);
		FSBAP_MiningTask_FW.statusInitUSER_Exec((FSBAP_MiningTask)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FSBAP_MiningTask p) {
		p.Cnd_co_cd.setListListener(p);
		p.Cnd_co_cd.addAllListener(p);
		p.Cnd_co_nm.setListListener(p);
		p.Cnd_co_nm.addAllListener(p);
		p.Cnd_srch.addAllListener(p);
		p.Cnd_srch.setAPMethodName("doCnd_srch");
	}

	/**
	 *  [Task]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTask(FSBAP_MiningTask p) {
		p.TaskTable.addAllListener(p);
		p.columnTask_inv_flg.addAllListener(p);
		p.columnTask_task_nm.addAllListener(p);
		p.columnTask_task_nm.setListListener(p);
		p.columnTask_task_type_nm.addAllListener(p);
		p.columnTask_task_type_nm.setListListener(p);
		p.columnTask_mining_nm.addAllListener(p);
		p.columnTask_mining_nm.setListListener(p);
		p.columnTask_co_nm.addAllListener(p);
		p.columnTask_co_nm.setListListener(p);
		p.columnTask_user_id.addAllListener(p);
		p.columnTask_user_id.setListListener(p);
		p.columnTask_user_nm.addAllListener(p);
		p.columnTask_user_nm.setListListener(p);
		p.columnTask_sche_dt.addAllListener(p);
		p.columnTask_sche_dt.setListListener(p);
		p.columnTask_start_dt.addAllListener(p);
		p.columnTask_start_dt.setListListener(p);
		p.columnTask_end_dt.addAllListener(p);
		p.columnTask_end_dt.setListListener(p);
		p.columnTask_msg_lv.addAllListener(p);
		p.columnTask_msg_lv.setListListener(p);
		p.columnTask_msg_id.addAllListener(p);
		p.columnTask_msg_id.setListListener(p);
		p.columnTask_msg.addAllListener(p);
		p.columnTask_msg.setListListener(p);
		p.columnTask_srv_id.addAllListener(p);
		p.columnTask_srv_id.setListListener(p);
	}

	/**
	 *  [BtnWest]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtnWest(FSBAP_MiningTask p) {
		p.BtnWest_add.addAllListener(p);
		p.BtnWest_add.setAPMethodName("doBtnWest_add");
		p.BtnWest_cpy.addAllListener(p);
		p.BtnWest_cpy.setAPMethodName("doBtnWest_cpy");
		p.BtnWest_mod.addAllListener(p);
		p.BtnWest_mod.setAPMethodName("doBtnWest_mod");
		p.BtnWest_run.addAllListener(p);
		p.BtnWest_run.setAPMethodName("doBtnWest_run");
	}

	/**
	 *  [BtnEast]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtnEast(FSBAP_MiningTask p) {
		p.BtnEast_del.addAllListener(p);
		p.BtnEast_del.setAPMethodName("doBtnEast_del");
	}

	/**
	 * [ADMIN]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitADMIN_Cnd(FSBAP_MiningTask p){
		p.Cnd_co_cd.putMode(p, ADMIN, MCMode.ENABLE);
		p.Cnd_co_nm.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.Cnd_srch.putMode(p, ADMIN, MCMode.ENABLE);

	}

	/**
	 * [ADMIN]ステータスの[Task]ブロックのモードの設定
	 */
	protected static void statusInitADMIN_Task(FSBAP_MiningTask p){
		p.columnTask_inv_flg.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_task_nm.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_task_type_nm.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_mining_nm.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_co_nm.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_user_id.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_user_nm.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_sche_dt.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_start_dt.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_end_dt.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_msg_lv.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_msg_id.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_msg.putMode(p, ADMIN, MCMode.READ_ONLY);
		p.columnTask_srv_id.putMode(p, ADMIN, MCMode.READ_ONLY);

	}

	/**
	 * [ADMIN]ステータスの[BtnWest]ブロックのモードの設定
	 */
	protected static void statusInitADMIN_BtnWest(FSBAP_MiningTask p){
		p.BtnWest_add.putMode(p, ADMIN, MCMode.ENABLE);
		p.BtnWest_cpy.putMode(p, ADMIN, MCMode.ENABLE);
		p.BtnWest_mod.putMode(p, ADMIN, MCMode.ENABLE);
		p.BtnWest_run.putMode(p, ADMIN, MCMode.ENABLE);

	}

	/**
	 * [ADMIN]ステータスの[BtnEast]ブロックのモードの設定
	 */
	protected static void statusInitADMIN_BtnEast(FSBAP_MiningTask p){
		p.BtnEast_del.putMode(p, ADMIN, MCMode.ENABLE);

	}

	/**
	 * [ADMIN]ステータスの[ExecCnd]ブロックのモードの設定
	 */
	protected static void statusInitADMIN_ExecCnd(FSBAP_MiningTask p){

	}

	/**
	 * [ADMIN]ステータスの[Exec]ブロックのモードの設定
	 */
	protected static void statusInitADMIN_Exec(FSBAP_MiningTask p){

	}

	/**
	 * [EXTADM]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitEXTADM_Cnd(FSBAP_MiningTask p){
		p.Cnd_co_cd.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.Cnd_co_nm.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.Cnd_srch.putMode(p, EXTADM, MCMode.ENABLE);

	}

	/**
	 * [EXTADM]ステータスの[Task]ブロックのモードの設定
	 */
	protected static void statusInitEXTADM_Task(FSBAP_MiningTask p){
		p.columnTask_inv_flg.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_task_nm.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_task_type_nm.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_mining_nm.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_co_nm.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_user_id.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_user_nm.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_sche_dt.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_start_dt.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_end_dt.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_msg_lv.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_msg_id.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_msg.putMode(p, EXTADM, MCMode.READ_ONLY);
		p.columnTask_srv_id.putMode(p, EXTADM, MCMode.READ_ONLY);

	}

	/**
	 * [EXTADM]ステータスの[BtnWest]ブロックのモードの設定
	 */
	protected static void statusInitEXTADM_BtnWest(FSBAP_MiningTask p){
		p.BtnWest_add.putMode(p, EXTADM, MCMode.ENABLE);
		p.BtnWest_cpy.putMode(p, EXTADM, MCMode.ENABLE);
		p.BtnWest_mod.putMode(p, EXTADM, MCMode.ENABLE);
		p.BtnWest_run.putMode(p, EXTADM, MCMode.ENABLE);

	}

	/**
	 * [EXTADM]ステータスの[BtnEast]ブロックのモードの設定
	 */
	protected static void statusInitEXTADM_BtnEast(FSBAP_MiningTask p){
		p.BtnEast_del.putMode(p, EXTADM, MCMode.ENABLE);

	}

	/**
	 * [EXTADM]ステータスの[ExecCnd]ブロックのモードの設定
	 */
	protected static void statusInitEXTADM_ExecCnd(FSBAP_MiningTask p){

	}

	/**
	 * [EXTADM]ステータスの[Exec]ブロックのモードの設定
	 */
	protected static void statusInitEXTADM_Exec(FSBAP_MiningTask p){

	}

	/**
	 * [USER]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitUSER_Cnd(FSBAP_MiningTask p){
		p.Cnd_co_cd.putMode(p, USER, MCMode.READ_ONLY);
		p.Cnd_co_nm.putMode(p, USER, MCMode.READ_ONLY);
		p.Cnd_srch.putMode(p, USER, MCMode.ENABLE);

	}

	/**
	 * [USER]ステータスの[Task]ブロックのモードの設定
	 */
	protected static void statusInitUSER_Task(FSBAP_MiningTask p){
		p.columnTask_inv_flg.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_task_nm.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_task_type_nm.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_mining_nm.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_co_nm.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_user_id.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_user_nm.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_sche_dt.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_start_dt.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_end_dt.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_msg_lv.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_msg_id.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_msg.putMode(p, USER, MCMode.READ_ONLY);
		p.columnTask_srv_id.putMode(p, USER, MCMode.READ_ONLY);

	}

	/**
	 * [USER]ステータスの[BtnWest]ブロックのモードの設定
	 */
	protected static void statusInitUSER_BtnWest(FSBAP_MiningTask p){
		p.BtnWest_add.putMode(p, USER, MCMode.DISABLE);
		p.BtnWest_cpy.putMode(p, USER, MCMode.DISABLE);
		p.BtnWest_mod.putMode(p, USER, MCMode.DISABLE);
		p.BtnWest_run.putMode(p, USER, MCMode.DISABLE);

	}

	/**
	 * [USER]ステータスの[BtnEast]ブロックのモードの設定
	 */
	protected static void statusInitUSER_BtnEast(FSBAP_MiningTask p){
		p.BtnEast_del.putMode(p, USER, MCMode.DISABLE);

	}

	/**
	 * [USER]ステータスの[ExecCnd]ブロックのモードの設定
	 */
	protected static void statusInitUSER_ExecCnd(FSBAP_MiningTask p){

	}

	/**
	 * [USER]ステータスの[Exec]ブロックのモードの設定
	 */
	protected static void statusInitUSER_Exec(FSBAP_MiningTask p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return ADMIN;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_MiningTask_FW.setTableConfigTask((FSBAP_MiningTask)this);
	}

	/**
	 * [Task]ブロックのTableの設定
	 */
	protected static void setTableConfigTask(FSBAP_MiningTask p) {
		p.columnTask_inv_flg.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.inv_flg_META);
		p.TaskTable.addColumnConfig(p.columnTask_inv_flg);
		p.columnTask_task_nm.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.task_nm_META);
		p.TaskTable.addColumnConfig(p.columnTask_task_nm);
		p.columnTask_task_type_nm.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.task_type_nm_META);
		p.TaskTable.addColumnConfig(p.columnTask_task_type_nm);
		p.columnTask_mining_nm.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.mining_nm_META);
		p.TaskTable.addColumnConfig(p.columnTask_mining_nm);
		p.columnTask_co_nm.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.co_nm_META);
		p.TaskTable.addColumnConfig(p.columnTask_co_nm);
		p.columnTask_user_id.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.user_id_META);
		p.TaskTable.addColumnConfig(p.columnTask_user_id);
		p.columnTask_user_nm.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.user_nm_META);
		p.TaskTable.addColumnConfig(p.columnTask_user_nm);
		p.columnTask_sche_dt.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.sche_dt_META);
		p.columnTask_sche_dt.setFormatID("YMDHM");
		p.TaskTable.addColumnConfig(p.columnTask_sche_dt);
		p.columnTask_start_dt.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.start_dt_META);
		p.columnTask_start_dt.setFormatID("YMDHM");
		p.TaskTable.addColumnConfig(p.columnTask_start_dt);
		p.columnTask_end_dt.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.end_dt_META);
		p.columnTask_end_dt.setFormatID("YMDHM");
		p.TaskTable.addColumnConfig(p.columnTask_end_dt);
		p.columnTask_msg_lv.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.msg_lv_META);
		p.TaskTable.addColumnConfig(p.columnTask_msg_lv);
		p.columnTask_msg_id.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.msg_id_META);
		p.TaskTable.addColumnConfig(p.columnTask_msg_id);
		p.columnTask_msg.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.msg_META);
		p.TaskTable.addColumnConfig(p.columnTask_msg);
		p.columnTask_srv_id.setMeta(mcframe.clientFSBA.FSBAP0820.TaskR.srv_id_META);
		p.TaskTable.addColumnConfig(p.columnTask_srv_id);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Cnd_co_cd.setListVisibleColumn(MCListLogic.getViewColumnName());
		Cnd_co_cd.getListConfig().setPutter(getCnd_co_cd_ListPutter());
		columnTask_mining_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnTask_mining_nm.getListConfig().setPutter(getTask_mining_nm_ListPutter());
	}

	/**
	 * この画面を[ADMIN]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setADMINStatus() {
		status = ADMIN;
		setAllStatus(status);
	}

	/**
	 * この画面を[EXTADM]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEXTADMStatus() {
		status = EXTADM;
		setAllStatus(status);
	}

	/**
	 * この画面を[USER]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setUSERStatus() {
		status = USER;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ADMIN.equals(status)) {
			setADMINStatus();
		}
		else if (EXTADM.equals(status)) {
			setEXTADMStatus();
		}
		else if (USER.equals(status)) {
			setUSERStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Cnd_co_cd_ListPutter]の作成
	 */
	protected MCListPutter createCnd_co_cd_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.Co");
		return lp;
	}
	 
	/**
	 * [Task_mining_nm_ListPutter]の作成
	 */
	protected MCListPutter createTask_mining_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Cnd_co_cd) return getCnd_co_cd(row, info);
		if(combo == columnTask_mining_nm) return getTask_mining_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Cnd_srch) doCnd_srch(info);
		else if (ap == BtnWest_add) doBtnWest_add(info);
		else if (ap == BtnWest_cpy) doBtnWest_cpy(info);
		else if (ap == BtnWest_mod) doBtnWest_mod(info);
		else if (ap == BtnWest_run) doBtnWest_run(info);
		else if (ap == BtnEast_del) doBtnEast_del(info);
	}

	/**
	 * [Cnd]パネルの[srch]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCnd_srch(MCEventInfo info);

	/**
	 * [BtnWest]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnWest_add(MCEventInfo info);

	/**
	 * [BtnWest]パネルの[cpy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnWest_cpy(MCEventInfo info);

	/**
	 * [BtnWest]パネルの[mod]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnWest_mod(MCEventInfo info);

	/**
	 * [BtnWest]パネルの[run]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnWest_run(MCEventInfo info);

	/**
	 * [BtnEast]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnEast_del(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == TaskTable) return doTask_VC(info);
		if (vc == Cnd_co_cd) return doCnd_co_cd_VC(info);
		if (vc == Cnd_co_nm) return doCnd_co_nm_VC(info);
		if (vc == columnTask_inv_flg) return doTask_inv_flg_VC(info);
		if (vc == columnTask_task_nm) return doTask_task_nm_VC(info);
		if (vc == columnTask_task_type_nm) return doTask_task_type_nm_VC(info);
		if (vc == columnTask_mining_nm) return doTask_mining_nm_VC(info);
		if (vc == columnTask_co_nm) return doTask_co_nm_VC(info);
		if (vc == columnTask_user_id) return doTask_user_id_VC(info);
		if (vc == columnTask_user_nm) return doTask_user_nm_VC(info);
		if (vc == columnTask_sche_dt) return doTask_sche_dt_VC(info);
		if (vc == columnTask_start_dt) return doTask_start_dt_VC(info);
		if (vc == columnTask_end_dt) return doTask_end_dt_VC(info);
		if (vc == columnTask_msg_lv) return doTask_msg_lv_VC(info);
		if (vc == columnTask_msg_id) return doTask_msg_id_VC(info);
		if (vc == columnTask_msg) return doTask_msg_VC(info);
		if (vc == columnTask_srv_id) return doTask_srv_id_VC(info);
		return true;
	}

	/**
	 * [Task]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[co_cd]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_co_cd_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[co_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_co_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[inv_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_inv_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[task_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_task_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[task_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_task_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[mining_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_mining_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[co_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_co_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[user_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_user_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[user_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_user_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[sche_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_sche_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[start_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_start_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[end_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_end_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[msg_lv]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_msg_lv_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[msg_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_msg_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[msg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_msg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Task]パネルの[srv_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTask_srv_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == TaskTable) doTask_NC(info);
		else if (nc == Cnd_co_cd) doCnd_co_cd_NC(info);
		else if (nc == Cnd_co_nm) doCnd_co_nm_NC(info);
		else if (nc == columnTask_inv_flg) doTask_inv_flg_NC(info);
		else if (nc == columnTask_task_nm) doTask_task_nm_NC(info);
		else if (nc == columnTask_task_type_nm) doTask_task_type_nm_NC(info);
		else if (nc == columnTask_mining_nm) doTask_mining_nm_NC(info);
		else if (nc == columnTask_co_nm) doTask_co_nm_NC(info);
		else if (nc == columnTask_user_id) doTask_user_id_NC(info);
		else if (nc == columnTask_user_nm) doTask_user_nm_NC(info);
		else if (nc == columnTask_sche_dt) doTask_sche_dt_NC(info);
		else if (nc == columnTask_start_dt) doTask_start_dt_NC(info);
		else if (nc == columnTask_end_dt) doTask_end_dt_NC(info);
		else if (nc == columnTask_msg_lv) doTask_msg_lv_NC(info);
		else if (nc == columnTask_msg_id) doTask_msg_id_NC(info);
		else if (nc == columnTask_msg) doTask_msg_NC(info);
		else if (nc == columnTask_srv_id) doTask_srv_id_NC(info);
	}

	/**
	 * [Task]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_cd]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_cd_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_nm_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[inv_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_inv_flg_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_nm_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[mining_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_mining_nm_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[co_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_co_nm_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_id_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_nm_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[sche_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_sche_dt_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[start_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_start_dt_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[end_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_end_dt_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_lv]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_lv_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_id_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_NC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[srv_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_srv_id_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == TaskTable) doTask_NE(info);
		else if (ne == Cnd_co_cd) doCnd_co_cd_NE(info);
		else if (ne == Cnd_co_nm) doCnd_co_nm_NE(info);
		else if (ne == columnTask_inv_flg) doTask_inv_flg_NE(info);
		else if (ne == columnTask_task_nm) doTask_task_nm_NE(info);
		else if (ne == columnTask_task_type_nm) doTask_task_type_nm_NE(info);
		else if (ne == columnTask_mining_nm) doTask_mining_nm_NE(info);
		else if (ne == columnTask_co_nm) doTask_co_nm_NE(info);
		else if (ne == columnTask_user_id) doTask_user_id_NE(info);
		else if (ne == columnTask_user_nm) doTask_user_nm_NE(info);
		else if (ne == columnTask_sche_dt) doTask_sche_dt_NE(info);
		else if (ne == columnTask_start_dt) doTask_start_dt_NE(info);
		else if (ne == columnTask_end_dt) doTask_end_dt_NE(info);
		else if (ne == columnTask_msg_lv) doTask_msg_lv_NE(info);
		else if (ne == columnTask_msg_id) doTask_msg_id_NE(info);
		else if (ne == columnTask_msg) doTask_msg_NE(info);
		else if (ne == columnTask_srv_id) doTask_srv_id_NE(info);
	}

	/**
	 * [Task]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_cd]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_cd_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_nm_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[inv_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_inv_flg_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_nm_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[mining_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_mining_nm_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[co_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_co_nm_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_id_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_nm_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[sche_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_sche_dt_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[start_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_start_dt_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[end_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_end_dt_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_lv]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_lv_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_id_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_NE(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[srv_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_srv_id_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == TaskTable) doTask_NX(info);
		else if (nx == Cnd_co_cd) doCnd_co_cd_NX(info);
		else if (nx == Cnd_co_nm) doCnd_co_nm_NX(info);
		else if (nx == columnTask_inv_flg) doTask_inv_flg_NX(info);
		else if (nx == columnTask_task_nm) doTask_task_nm_NX(info);
		else if (nx == columnTask_task_type_nm) doTask_task_type_nm_NX(info);
		else if (nx == columnTask_mining_nm) doTask_mining_nm_NX(info);
		else if (nx == columnTask_co_nm) doTask_co_nm_NX(info);
		else if (nx == columnTask_user_id) doTask_user_id_NX(info);
		else if (nx == columnTask_user_nm) doTask_user_nm_NX(info);
		else if (nx == columnTask_sche_dt) doTask_sche_dt_NX(info);
		else if (nx == columnTask_start_dt) doTask_start_dt_NX(info);
		else if (nx == columnTask_end_dt) doTask_end_dt_NX(info);
		else if (nx == columnTask_msg_lv) doTask_msg_lv_NX(info);
		else if (nx == columnTask_msg_id) doTask_msg_id_NX(info);
		else if (nx == columnTask_msg) doTask_msg_NX(info);
		else if (nx == columnTask_srv_id) doTask_srv_id_NX(info);
	}

	/**
	 * [Task]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_cd]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_cd_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_nm_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[inv_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_inv_flg_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_nm_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[mining_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_mining_nm_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[co_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_co_nm_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_id_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_nm_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[sche_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_sche_dt_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[start_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_start_dt_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[end_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_end_dt_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_lv]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_lv_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_id_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_NX(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[srv_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_srv_id_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_co_cd) doCnd_co_cd_LC(info);
		else if (lc == Cnd_co_nm) doCnd_co_nm_LC(info);
		else if (lc == columnTask_task_nm) doTask_task_nm_LC(info);
		else if (lc == columnTask_task_type_nm) doTask_task_type_nm_LC(info);
		else if (lc == columnTask_mining_nm) doTask_mining_nm_LC(info);
		else if (lc == columnTask_co_nm) doTask_co_nm_LC(info);
		else if (lc == columnTask_user_id) doTask_user_id_LC(info);
		else if (lc == columnTask_user_nm) doTask_user_nm_LC(info);
		else if (lc == columnTask_sche_dt) doTask_sche_dt_LC(info);
		else if (lc == columnTask_start_dt) doTask_start_dt_LC(info);
		else if (lc == columnTask_end_dt) doTask_end_dt_LC(info);
		else if (lc == columnTask_msg_lv) doTask_msg_lv_LC(info);
		else if (lc == columnTask_msg_id) doTask_msg_id_LC(info);
		else if (lc == columnTask_msg) doTask_msg_LC(info);
		else if (lc == columnTask_srv_id) doTask_srv_id_LC(info);
	}

	/**
	 * [Cnd]パネルの[co_cd]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_cd_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[co_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_co_nm_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_nm_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[task_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_task_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[mining_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_mining_nm_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[co_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_co_nm_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_id_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[user_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_user_nm_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[sche_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_sche_dt_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[start_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_start_dt_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[end_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_end_dt_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_lv]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_lv_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_id_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[msg]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_msg_LC(MCEventInfo info){
	}

	/**
	 * [Task]パネルの[srv_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTask_srv_id_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Cnd_co_cd]の作成メソッド
	 */
	public MCList getCnd_co_cd(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getCo(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnTask_mining_nm]の作成メソッド
	 */
	public MCList getTask_mining_nm(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0820.Srch01")) {
			return new FS_FSBAL0820_Srch01Bridge();
		}
		if (id.equals("FS.FSBAL0820.Del01")) {
			return new FS_FSBAL0820_Del01Bridge();
		}
		if (id.equals("EXEC")) {
			return new EXECBridge();
		}
		if (id.equals("EXECSRCH")) {
			return new EXECSRCHBridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0820_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Srch01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0820_Srch01;

		/** コンストラクタ */
		protected FS_FSBAL0820_Srch01Bridge() {
			p_FS_FSBAL0820_Srch01 = new MCParam(PDef.FS_FSBAL0820_Srch01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0820_Srch01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0820.CndR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class));

			p_FS_FSBAL0820_Srch01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0820_Srch01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0820_Srch01.addUpBlock(getCndR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0820_Srch01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0820_Srch01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0820.CndR up0() {
			return (mcframe.clientFSBA.FSBAP0820.CndR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0820.TaskR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0820.TaskR>)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0820_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0820_Srch01;
		}

		protected void show() {
			setTaskL((MCList<mcframe.clientFSBA.FSBAP0820.TaskR>)p_FS_FSBAL0820_Srch01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getTaskL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getCndR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getTaskL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0820_Del01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Del01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0820_Del01;

		/** コンストラクタ */
		protected FS_FSBAL0820_Del01Bridge() {
			p_FS_FSBAL0820_Del01 = new MCParam(PDef.FS_FSBAL0820_Del01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0820_Del01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class));
			// Down

			p_FS_FSBAL0820_Del01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0820_Del01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0820_Del01.addUpBlock(getTaskL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0820_Del01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0820_Del01.getContainerParam().getDownBlock(i);
		}
		
		protected MCList<mcframe.clientFSBA.FSBAP0820.TaskR> up0() {
			return (MCList<mcframe.clientFSBA.FSBAP0820.TaskR>)up(0);
		}


		protected void setupDownParam() {
		}
		protected MCParam param() {
			return p_FS_FSBAL0820_Del01;
		}

		protected void show() {
		}

		protected void clear() {
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getTaskL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			return result;
		}
	}
	/**
	 * [EXEC]の定型処理のInnerClass
	 */
	protected class EXECBridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_EXEC;

		/** コンストラクタ */
		protected EXECBridge() {
			p_EXEC = new MCParam(PDef.EXEC_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.EXEC_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0820.CndR.create());
			// Down

			p_EXEC = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_EXEC.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_EXEC.addUpBlock(getExecCndR());
		}

		protected MCContainer up(int i) {
			return p_EXEC.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_EXEC.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0820.CndR up0() {
			return (mcframe.clientFSBA.FSBAP0820.CndR)up(0);
		}


		protected void setupDownParam() {
		}
		protected MCParam param() {
			return p_EXEC;
		}

		protected void show() {
		}

		protected void clear() {
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getExecCndR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			return result;
		}
	}
	/**
	 * [EXECSRCH]の定型処理のInnerClass
	 */
	protected class EXECSRCHBridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_EXECSRCH;

		/** コンストラクタ */
		protected EXECSRCHBridge() {
			p_EXECSRCH = new MCParam(PDef.EXECSRCH_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.EXECSRCH_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0820.CndR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class));

			p_EXECSRCH = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_EXECSRCH.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_EXECSRCH.addUpBlock(getExecCndR());
		}

		protected MCContainer up(int i) {
			return p_EXECSRCH.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_EXECSRCH.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0820.CndR up0() {
			return (mcframe.clientFSBA.FSBAP0820.CndR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0820.TaskR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0820.TaskR>)down(0);
		}

		protected void setupDownParam() {
			p_EXECSRCH.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0820.TaskR.class));
		}
		protected MCParam param() {
			return p_EXECSRCH;
		}

		protected void show() {
			setExecL((MCList<mcframe.clientFSBA.FSBAP0820.TaskR>)p_EXECSRCH.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getExecL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getExecCndR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getExecL());
			return result;
		}
	}
}