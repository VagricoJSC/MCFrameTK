package mcframe.clientFSBA.FSBAP0820;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Task"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class TaskR_FW_A extends MCConstRow {

	/**
	 *  無効.<p>
	 *
	 */
	public static final String $inv_flg = "inv_flg";
	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public static final String $task_id = "task_id";
	/**
	 *  タスク名.<p>
	 *
	 */
	public static final String $task_nm = "task_nm";
	/**
	 *  タスク種別.<p>
	 *
	 */
	public static final String $task_type = "task_type";
	/**
	 *  タスク種別名.<p>
	 *
	 */
	public static final String $task_type_nm = "task_type_nm";
	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 *  マイニング名.<p>
	 *
	 */
	public static final String $mining_nm = "mining_nm";
	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public static final String $co_cd = "co_cd";
	/**
	 *  会社名.<p>
	 *
	 */
	public static final String $co_nm = "co_nm";
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $user_id = "user_id";
	/**
	 *  ユーザ名.<p>
	 *
	 */
	public static final String $user_nm = "user_nm";
	/**
	 *  次回実行日時.<p>
	 *
	 */
	public static final String $sche_dt = "sche_dt";
	/**
	 *  実行日時.<p>
	 *
	 */
	public static final String $start_dt = "start_dt";
	/**
	 *  終了日時.<p>
	 *
	 */
	public static final String $end_dt = "end_dt";
	/**
	 *  実行結果レベル.<p>
	 *
	 */
	public static final String $msg_lv = "msg_lv";
	/**
	 *  実行結果ＩＤ.<p>
	 *
	 */
	public static final String $msg_id = "msg_id";
	/**
	 *  メッセージバインド.<p>
	 *
	 */
	public static final String $msg_bind = "msg_bind";
	/**
	 *  実行結果.<p>
	 *
	 */
	public static final String $msg = "msg";
	/**
	 *  実行サーバ.<p>
	 *
	 */
	public static final String $srv_id = "srv_id";
	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public static final String $upd_cntr = "upd_cntr";


	public static final MCMeta inv_flg_META = createCommonMeta($inv_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta task_id_META = createCommonMeta($task_id, mcframe.commonCore.meta.M_META.MINING_TASK_ID);
	public static final MCMeta task_nm_META = createCommonMeta($task_nm, mcframe.commonCore.meta.M_META.MINING_TASK_NM);
	public static final MCMeta task_type_META = createCommonMeta($task_type, mcframe.commonCore.meta.M_META.MINING_TASK_TYP);
	public static final MCMeta task_type_nm_META = createStringMeta($task_type_nm);
	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta mining_nm_META = createCommonMeta($mining_nm, mcframe.commonCore.meta.M_META.MINING_NM);
	public static final MCMeta co_cd_META = createCommonMeta($co_cd, mcframe.commonCore.meta.M_META.CO_CD);
	public static final MCMeta co_nm_META = createCommonMeta($co_nm, mcframe.commonCore.meta.M_META.CO_NM);
	public static final MCMeta user_id_META = createCommonMeta($user_id, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta user_nm_META = createCommonMeta($user_nm, mcframe.commonCore.meta.M_META.USR_NM);
	public static final MCMeta sche_dt_META = createCommonMeta($sche_dt, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta start_dt_META = createCommonMeta($start_dt, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta end_dt_META = createCommonMeta($end_dt, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta msg_lv_META = createCommonMeta($msg_lv, mcframe.commonCore.meta.M_META.MSG_LVL);
	public static final MCMeta msg_id_META = createCommonMeta($msg_id, mcframe.commonCore.meta.M_META.MSG_ID);
	public static final MCMeta msg_bind_META = createCommonMeta($msg_bind, mcframe.commonCore.meta.M_META.MSG_BIND);
	public static final MCMeta msg_META = createCommonMeta($msg, mcframe.commonCore.meta.M_META.MSG);
	public static final MCMeta srv_id_META = createCommonMeta($srv_id, mcframe.commonCore.meta.M_META.MACHINE);
	public static final MCMeta upd_cntr_META = createCommonMeta($upd_cntr, mcframe.commonCore.meta.M_META.UPD_CNT);

	protected static final ConstMetaList<TaskR> constMetas = new ConstMetaList<TaskR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			inv_flg_META,
			task_id_META,
			task_nm_META,
			task_type_META,
			task_type_nm_META,
			mining_id_META,
			mining_nm_META,
			co_cd_META,
			co_nm_META,
			user_id_META,
			user_nm_META,
			sche_dt_META,
			start_dt_META,
			end_dt_META,
			msg_lv_META,
			msg_id_META,
			msg_bind_META,
			msg_META,
			srv_id_META,
			upd_cntr_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected TaskR_FW_A(ConstMetaList<? extends TaskR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TaskR clone() {
		return (TaskR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TaskR createInstance() {
		return (TaskR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TaskR getValues(String... names) {
		return (TaskR) super.getValues(names);
	}



	/**
	 *  無効.<p>
	 *
	 */
	public boolean inv_flg() {
		return getConstBoolean(offset + 0, $inv_flg);
	}

	/**
	 *  無効.<p>
	 *
	 */
	public void inv_flg(boolean value) {
		setConstBoolean(offset + 0, $inv_flg, value);
	}


	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public String task_id() {
		return getConstString(offset + 1, $task_id);
	}

	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public void task_id(String value) {
		setConstString(offset + 1, $task_id, value);
	}


	/**
	 *  タスク名.<p>
	 *
	 */
	public String task_nm() {
		return getConstString(offset + 2, $task_nm);
	}

	/**
	 *  タスク名.<p>
	 *
	 */
	public void task_nm(String value) {
		setConstString(offset + 2, $task_nm, value);
	}


	/**
	 *  タスク種別.<p>
	 *
	 */
	public String task_type() {
		return getConstString(offset + 3, $task_type);
	}

	/**
	 *  タスク種別.<p>
	 *
	 */
	public void task_type(String value) {
		setConstString(offset + 3, $task_type, value);
	}


	/**
	 *  タスク種別名.<p>
	 *
	 */
	public String task_type_nm() {
		return getConstString(offset + 4, $task_type_nm);
	}

	/**
	 *  タスク種別名.<p>
	 *
	 */
	public void task_type_nm(String value) {
		setConstString(offset + 4, $task_type_nm, value);
	}


	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 5, $mining_id);
	}

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 5, $mining_id, value);
	}


	/**
	 *  マイニング名.<p>
	 *
	 */
	public String mining_nm() {
		return getConstString(offset + 6, $mining_nm);
	}

	/**
	 *  マイニング名.<p>
	 *
	 */
	public void mining_nm(String value) {
		setConstString(offset + 6, $mining_nm, value);
	}


	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public String co_cd() {
		return getConstString(offset + 7, $co_cd);
	}

	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public void co_cd(String value) {
		setConstString(offset + 7, $co_cd, value);
	}


	/**
	 *  会社名.<p>
	 *
	 */
	public String co_nm() {
		return getConstString(offset + 8, $co_nm);
	}

	/**
	 *  会社名.<p>
	 *
	 */
	public void co_nm(String value) {
		setConstString(offset + 8, $co_nm, value);
	}


	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String user_id() {
		return getConstString(offset + 9, $user_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void user_id(String value) {
		setConstString(offset + 9, $user_id, value);
	}


	/**
	 *  ユーザ名.<p>
	 *
	 */
	public String user_nm() {
		return getConstString(offset + 10, $user_nm);
	}

	/**
	 *  ユーザ名.<p>
	 *
	 */
	public void user_nm(String value) {
		setConstString(offset + 10, $user_nm, value);
	}


	/**
	 *  次回実行日時.<p>
	 *
	 */
	public MCDate sche_dt() {
		return getConstDate(offset + 11, $sche_dt);
	}

	/**
	 *  次回実行日時.<p>
	 *
	 */
	public void sche_dt(MCDate value) {
		setConstDate(offset + 11, $sche_dt, value);
	}


	/**
	 *  実行日時.<p>
	 *
	 */
	public MCDate start_dt() {
		return getConstDate(offset + 12, $start_dt);
	}

	/**
	 *  実行日時.<p>
	 *
	 */
	public void start_dt(MCDate value) {
		setConstDate(offset + 12, $start_dt, value);
	}


	/**
	 *  終了日時.<p>
	 *
	 */
	public MCDate end_dt() {
		return getConstDate(offset + 13, $end_dt);
	}

	/**
	 *  終了日時.<p>
	 *
	 */
	public void end_dt(MCDate value) {
		setConstDate(offset + 13, $end_dt, value);
	}


	/**
	 *  実行結果レベル.<p>
	 *
	 */
	public String msg_lv() {
		return getConstString(offset + 14, $msg_lv);
	}

	/**
	 *  実行結果レベル.<p>
	 *
	 */
	public void msg_lv(String value) {
		setConstString(offset + 14, $msg_lv, value);
	}


	/**
	 *  実行結果ＩＤ.<p>
	 *
	 */
	public String msg_id() {
		return getConstString(offset + 15, $msg_id);
	}

	/**
	 *  実行結果ＩＤ.<p>
	 *
	 */
	public void msg_id(String value) {
		setConstString(offset + 15, $msg_id, value);
	}


	/**
	 *  メッセージバインド.<p>
	 *
	 */
	public String msg_bind() {
		return getConstString(offset + 16, $msg_bind);
	}

	/**
	 *  メッセージバインド.<p>
	 *
	 */
	public void msg_bind(String value) {
		setConstString(offset + 16, $msg_bind, value);
	}


	/**
	 *  実行結果.<p>
	 *
	 */
	public String msg() {
		return getConstString(offset + 17, $msg);
	}

	/**
	 *  実行結果.<p>
	 *
	 */
	public void msg(String value) {
		setConstString(offset + 17, $msg, value);
	}


	/**
	 *  実行サーバ.<p>
	 *
	 */
	public String srv_id() {
		return getConstString(offset + 18, $srv_id);
	}

	/**
	 *  実行サーバ.<p>
	 *
	 */
	public void srv_id(String value) {
		setConstString(offset + 18, $srv_id, value);
	}


	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public MCNumber upd_cntr() {
		return getConstNumber(offset + 19, $upd_cntr);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(MCNumber value) {
		setConstNumber(offset + 19, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(int value) {
		setConstNumber(offset + 19, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(long value) {
		setConstNumber(offset + 19, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(float value) {
		setConstNumber(offset + 19, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(double value) {
		setConstNumber(offset + 19, $upd_cntr, value);
	}


	public String getString(String name) {
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		if ($task_nm.equalsIgnoreCase(name)) {
			return task_nm();
		}
		if ($task_type.equalsIgnoreCase(name)) {
			return task_type();
		}
		if ($task_type_nm.equalsIgnoreCase(name)) {
			return task_type_nm();
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			return mining_nm();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			return co_nm();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		if ($user_nm.equalsIgnoreCase(name)) {
			return user_nm();
		}
		if ($msg_lv.equalsIgnoreCase(name)) {
			return msg_lv();
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			return msg_id();
		}
		if ($msg_bind.equalsIgnoreCase(name)) {
			return msg_bind();
		}
		if ($msg.equalsIgnoreCase(name)) {
			return msg();
		}
		if ($srv_id.equalsIgnoreCase(name)) {
			return srv_id();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			return upd_cntr();
		}
		return super.getNumber(name);
	}
	public MCDate getDate(String name) {
		if ($sche_dt.equalsIgnoreCase(name)) {
			return sche_dt();
		}
		if ($start_dt.equalsIgnoreCase(name)) {
			return start_dt();
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			return end_dt();
		}
		return super.getDate(name);
	}
	public boolean getBoolean(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		if ($task_nm.equalsIgnoreCase(name)) {
			return task_nm();
		}
		if ($task_type.equalsIgnoreCase(name)) {
			return task_type();
		}
		if ($task_type_nm.equalsIgnoreCase(name)) {
			return task_type_nm();
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			return mining_nm();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			return co_nm();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		if ($user_nm.equalsIgnoreCase(name)) {
			return user_nm();
		}
		if ($msg_lv.equalsIgnoreCase(name)) {
			return msg_lv();
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			return msg_id();
		}
		if ($msg_bind.equalsIgnoreCase(name)) {
			return msg_bind();
		}
		if ($msg.equalsIgnoreCase(name)) {
			return msg();
		}
		if ($srv_id.equalsIgnoreCase(name)) {
			return srv_id();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			return upd_cntr();
		}
		return super.getNumberNE(name);
	}
	public MCDate getDateNE(String name) {
		if ($sche_dt.equalsIgnoreCase(name)) {
			return sche_dt();
		}
		if ($start_dt.equalsIgnoreCase(name)) {
			return start_dt();
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			return end_dt();
		}
		return super.getDateNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		if ($task_nm.equalsIgnoreCase(name)) {
			task_nm(value);
			return;
		}
		if ($task_type.equalsIgnoreCase(name)) {
			task_type(value);
			return;
		}
		if ($task_type_nm.equalsIgnoreCase(name)) {
			task_type_nm(value);
			return;
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			mining_nm(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			co_nm(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		if ($user_nm.equalsIgnoreCase(name)) {
			user_nm(value);
			return;
		}
		if ($msg_lv.equalsIgnoreCase(name)) {
			msg_lv(value);
			return;
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			msg_id(value);
			return;
		}
		if ($msg_bind.equalsIgnoreCase(name)) {
			msg_bind(value);
			return;
		}
		if ($msg.equalsIgnoreCase(name)) {
			msg(value);
			return;
		}
		if ($srv_id.equalsIgnoreCase(name)) {
			srv_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setDate(String name, MCDate value) {
		if ($sche_dt.equalsIgnoreCase(name)) {
			sche_dt(value);
			return;
		}
		if ($start_dt.equalsIgnoreCase(name)) {
			start_dt(value);
			return;
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			end_dt(value);
			return;
		}
		super.setDate(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		if ($task_nm.equalsIgnoreCase(name)) {
			task_nm(value);
			return;
		}
		if ($task_type.equalsIgnoreCase(name)) {
			task_type(value);
			return;
		}
		if ($task_type_nm.equalsIgnoreCase(name)) {
			task_type_nm(value);
			return;
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			mining_nm(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			co_nm(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		if ($user_nm.equalsIgnoreCase(name)) {
			user_nm(value);
			return;
		}
		if ($msg_lv.equalsIgnoreCase(name)) {
			msg_lv(value);
			return;
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			msg_id(value);
			return;
		}
		if ($msg_bind.equalsIgnoreCase(name)) {
			msg_bind(value);
			return;
		}
		if ($msg.equalsIgnoreCase(name)) {
			msg(value);
			return;
		}
		if ($srv_id.equalsIgnoreCase(name)) {
			srv_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setDateNE(String name, MCDate value) {
		if ($sche_dt.equalsIgnoreCase(name)) {
			sche_dt(value);
			return;
		}
		if ($start_dt.equalsIgnoreCase(name)) {
			start_dt(value);
			return;
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			end_dt(value);
			return;
		}
		super.setDateNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

