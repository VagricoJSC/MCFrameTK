package mcframe.clientFSBA.FSBAP0820;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.sys.MCSys;

import mcframe.commonFS.constant.FSC_MINING_TASK_TYPE;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_MiningTask"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_MiningTask_FW extends FSBAP_MiningTask_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTask_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningTask_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FS_FSBAL0820_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Srch01Caller<P extends FSBAP_MiningTask, B extends FS_FSBAL0820_Srch01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FS_FSBAL0820_Srch01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void afterCall() {
			super.afterCall();

			// タスク
			bridge.down0().forEach(down0R -> {
				// 名称補完
				FSC_MINING_TASK_TYPE.putNameNE(down0R, TaskR.$task_type, TaskR.$task_type_nm);
			});
		}

		@Override
		protected void moveFocus() {
			super.moveFocus();
			if (getTaskL().size() > 0) {
				TaskTable.selectLeftmostColumn(0);
			}
			else {
				BtnWest_add.mcRequestFocus();
			}
		}

	}

	/**
	 * [FS_FSBAL0820_Del01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Del01Caller<P extends FSBAP_MiningTask, B extends FS_FSBAL0820_Del01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Deleter<P, B> {

		/**
		 * 通信対象の明細リスト。
		 */
		protected MCList<TaskR> taskLForCall;

		protected FS_FSBAL0820_Del01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();

			// 通信対象行を絞る
			taskLForCall = TaskTable.getSelectedMCRows();
		}

		@Override
		protected void setupParam() {
			super.setupParam();

			bridge.up0().setAll(taskLForCall);
		}

		@Override
		protected void call() {
			// 新規行の削除
			MCList<TaskR> newL = taskLForCall.subList(TaskR.$task_id, null);
			bridge.up0().removeAll(newL);

			// 既存行の削除
			if (bridge.up0().size() > 0) {
				super.call();
			}
		}

		@Override
		protected void show() {
			super.show();

			// 削除データのコンテナを削除
			taskLForCall.forEach(taskR -> {
				// タスク
				getTaskL().remove(taskR);
			});
		}

		@Override
		protected void moveFocus() {
			super.moveFocus();
			TaskTable.mcClearSelection();
			if (getTaskL().size() > 0) {
				TaskTable.selectLeftmostColumn(0);
			}
			else {
				BtnWest_add.mcRequestFocus();
			}
		}

	}

	/**
	 * [EXEC]の定型処理のInnerClass
	 */
	protected class EXECCaller<P extends FSBAP_MiningTask, B extends EXECBridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected EXECCaller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();
			setScreenAsync(false);// 画面同期・・・画面が裏側に移ってもバルーン通知しない
		}

		@Override
		protected MCMessage msgExecConfirm() {
			// タスク開始
			return new MCMessage(FSBAC0087);
		}

		@Override
		protected void checkForCallStack(MCMessageList msgList) {
			TaskR taskR = TaskTable.getSelectedMCRow();
			if (taskR == null) {
				// 未選択チェック
				msgList.add(new MCMessage(FXBAP0035));
			}
			else if (isNull(taskR.task_id())) {
				// 新規行チェック
				msgList.add(new MCMessage(FSBAC0089));
			}

			// データ更新はしないので、標準のチェックは不要
			//super.checkForCallStack(msgList);
		}

		@Override
		protected boolean isUpBlockStatusNone() {
			return false;
		}

		@Override
		protected void setupParam() {
			super.setupParam();

			TaskR taskR = TaskTable.getSelectedMCRow();
			getExecCndR().task_id(taskR.task_id());
		}

		@Override
		protected void moveFocus() {
			super.moveFocus();

			// 実行タスクを再検索
			callEXECSRCH();

			// フォーカス処理は再検索側で行う
		}

		@Override
		public MCMessage msgUpdated() {
			// タスク開始完了
			return new MCMessage(FSBAC0088);
		}
	}

	/**
	 * [EXECSRCH]の定型処理のInnerClass
	 */
	protected class EXECSRCHCaller<P extends FSBAP_MiningTask, B extends EXECSRCHBridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		// 選択行
		private int _idx = -1;

		protected EXECSRCHCaller(P p, B b) {
			super(p, b);
			_idx = TaskTable.getMCSelectedRow();
			TaskR taskR = TaskTable.getRow(_idx);
			getExecCndR().task_id(taskR.task_id());
			getExecL().clear();
		}

		@Override
		protected void initCaller() {
			super.initCaller();
			setScreenAsync(false);// 画面同期・・・画面が裏側に移ってもバルーン通知しない
		}

		@Override
		protected boolean checkForCall() {
			if (isNull(getExecCndR().task_id())){
				return false;// タスクID未指定
			}

			return super.checkForCall();
		}

		@Override
		protected void afterCall() {
			super.afterCall();

			// タスク
			bridge.down0().forEach(down0R -> {
				// 名称補完
				FSC_MINING_TASK_TYPE.putNameNE(down0R, TaskR.$task_type, TaskR.$task_type_nm);
			});
		}

		@Override
		protected void show() {
			super.show();

			// タスクID指定なので1 or 0件
			if (getExecL().size() == 1) {
				TaskR execR = getExecL().get(0);
				TaskR taskR = getTaskL().getFirst(TaskR.$task_id, execR.task_id());
				MCRow.copyvalue(taskR, execR);
			}
		}

		@Override
		protected void moveFocus() {
			super.moveFocus();

			TaskTable.selectLeftmostColumn(_idx);
		}
	}


	/**
	 * Panel[Cnd]のボタン[srch]の押下時の処理
	 */
	@Override
	public void doCnd_srch(MCEventInfo info) {
		callFS_FSBAL0820_Srch01();
	}
	/**
	 * Panel[BtnWest]のボタン[add]の押下時の処理
	 */
	@Override
	public void doBtnWest_add(MCEventInfo info) {
		TaskR taskR = insertRow(TaskTable);
		openTaskEditor(taskR);
	}
	/**
	 * Panel[BtnWest]のボタン[cpy]の押下時の処理
	 */
	@Override
	public void doBtnWest_cpy(MCEventInfo info) {
		TaskR taskR = TaskTable.getSelectedMCRow();
		if (taskR == null) {
			// 未選択チェック
			throw new MCAppException(FXBAP0035);
		}
		if (isNull(taskR.task_id())) {
			// 追加行はコピー不可（新規 or コピー）
			throw new MCAppException(FSBAC0090);
		}

		taskR = copyRow(TaskTable);
		taskR.setStatus(Status.CREATE);// コピーはCREATEステータスにする

		openTaskEditor(taskR);
	}
	/**
	 * Panel[BtnWest]のボタン[mod]の押下時の処理
	 */
	@Override
	public void doBtnWest_mod(MCEventInfo info) {
		TaskR taskR = TaskTable.getSelectedMCRow();
		if (taskR == null) {
			// 未選択チェック
			throw new MCAppException(FXBAP0035);
		}
		openTaskEditor(taskR);
	}
	/**
	 * Panel[BtnWest]のボタン[run]の押下時の処理
	 */
	@Override
	public void doBtnWest_run(MCEventInfo info) {
		callEXEC();
	}
	/**
	 * Panel[BtnEast]のボタン[del]の押下時の処理
	 */
	@Override
	public void doBtnEast_del(MCEventInfo info) {
		callFS_FSBAL0820_Del01();
	}

	/**
	 * タスク編集画面を開きます。
	 *
	 * @param taskR 編集するスケジュール
	 */
	protected void openTaskEditor(TaskR taskR) {
		MCRootPanel p = createPanel("FS", "FSBAP0850", MCRootPanel.SCREEN_MODAL,
				"T1", null, taskR, TaskTable,
				(isSame(getStatus(), EXTADM)) ? getCndR().co_cd() : null);
		showChildPanel(p, MCRootPanel.SCREEN_SINGLE);
	}


	@Override
	protected void setSortColumn() {
		super.setSortColumn();

		TaskTable.addSortColumn(columnTask_task_nm, MCList.SortType.ASC);
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return null;// 標準ポップアップ
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		TaskTable.adjustWidth();
	}

	@Override
	public void setStatus(String s) {
		super.setStatus(s);

		if (!MCSys.env.is3Tier()) {
			// ３層以外即時実行不可
			BtnWest_run.setMode(MCMode.DISABLE);
		}
	}

	@Override
	public void setEXTADMStatus() {
		super.setEXTADMStatus();

		// 会社固定検索
		setValueEx(Cnd_co_cd, MCSys.user.coCD());

		CndPanel.focusFirstComponent();
	}

	@Override
	public void setUSERStatus() {
		super.setUSERStatus();

		// 会社固定検索
		setValueEx(Cnd_co_cd, MCSys.user.coCD());

		CndPanel.focusFirstComponent();
	}

}