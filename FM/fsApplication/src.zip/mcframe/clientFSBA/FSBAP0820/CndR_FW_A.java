package mcframe.clientFSBA.FSBAP0820;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cnd"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CndR_FW_A extends MCConstRow {

	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public static final String $task_id = "task_id";
	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $user_id = "user_id";
	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public static final String $co_cd = "co_cd";
	/**
	 *  会社名.<p>
	 *
	 */
	public static final String $co_nm = "co_nm";


	public static final MCMeta task_id_META = createCommonMeta($task_id, mcframe.commonCore.meta.M_META.MINING_TASK_ID);
	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta user_id_META = createCommonMeta($user_id, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta co_cd_META = createCommonMeta($co_cd, mcframe.commonCore.meta.M_META.CO_CD);
	public static final MCMeta co_nm_META = createCommonMeta($co_nm, mcframe.commonCore.meta.M_META.CO_NM);

	protected static final ConstMetaList<CndR> constMetas = new ConstMetaList<CndR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			task_id_META,
			mining_id_META,
			user_id_META,
			co_cd_META,
			co_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CndR_FW_A(ConstMetaList<? extends CndR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR clone() {
		return (CndR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR createInstance() {
		return (CndR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR getValues(String... names) {
		return (CndR) super.getValues(names);
	}



	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public String task_id() {
		return getConstString(offset + 0, $task_id);
	}

	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public void task_id(String value) {
		setConstString(offset + 0, $task_id, value);
	}


	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 1, $mining_id);
	}

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 1, $mining_id, value);
	}


	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String user_id() {
		return getConstString(offset + 2, $user_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void user_id(String value) {
		setConstString(offset + 2, $user_id, value);
	}


	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public String co_cd() {
		return getConstString(offset + 3, $co_cd);
	}

	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public void co_cd(String value) {
		setConstString(offset + 3, $co_cd, value);
	}


	/**
	 *  会社名.<p>
	 *
	 */
	public String co_nm() {
		return getConstString(offset + 4, $co_nm);
	}

	/**
	 *  会社名.<p>
	 *
	 */
	public void co_nm(String value) {
		setConstString(offset + 4, $co_nm, value);
	}


	public String getString(String name) {
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			return co_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			return co_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			co_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($co_nm.equalsIgnoreCase(name)) {
			co_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

