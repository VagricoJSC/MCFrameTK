package mcframe.clientFSBA.FSBAP0780;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0120.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSUB.FSUBP0000.IfSumCondBase;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;

import mcframe.commonFS.constant.FSC_SUM_INFO_TYPE;
import mcframe.commonFS.constant.FSC_ROUNDING_MODE_TYPE;
import mcframe.commonFS.constant.FSC_SORT_TYPE;
import mcframe.commonFS.constant.FSC_GADGET_CHART_TYPE;

import mcframe.clientCore.beans.dashboard.MCDashboardUtil;
import mcframe.clientCore.beans.fxgraph.MCFXGraph;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.push.MCServerPushManager;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;

import mcframe.commonCore.mining.MCMiningUtil;
import mcframe.commonCore.requester.MCDownloadUtil;
import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.commonCore.util.MCImageUtil;

import java.io.File;

import javax.swing.ListSelectionModel;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_MiningDtl"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_MiningDtl_FW extends FSBAP_MiningDtl_FW_A implements IfSumCondBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 検索処理でデータがあった場合のモード
	 */
	protected String MODE_FS_FSBAL0760_Srch01 = null;
	/**
	 * 検索処理でデータがなかった場合のモード
	 */
	protected String MODE_NO_DATA_FS_FSBAL0760_Srch01 = null;
	/**
	 * 更新処理が正常終了した場合のモード
	 */
	protected String MODE_FS_FSBAL0760_Upd01 = null;
	/**
	 * 新規追加処理が正常終了した場合のモード
	 */
	protected String MODE_FS_FSBAL0760_Ins01 = null;
	/**
	 * コピー処理が正常終了した場合のモード
	 */
	protected String MODE_FS_FSBAL0760_Ins02 = null;

	/**
	 *  集計条件必須フラグ の項目名
	 */
	protected final String _req_sumcond = "_req_sumcond";
	/**
	 *  日付書式必須フラグ の項目名
	 */
	protected final String _req_date_fmt = "_req_date_fmt";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningDtl_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningDtl_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FS_FSBAL0760_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Srch01Caller<P extends FSBAP_MiningDtl, B extends FS_FSBAL0760_Srch01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FS_FSBAL0760_Srch01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected boolean execConfirm() {
			return true;
		}

		@Override
		protected void afterCall() {
			super.afterCall();

			// マイニング
			bridge.down0().forEach(down0R -> setDisplayData(down0R));

			// 検索条件
			bridge.down1().forEach(down1R -> {
				String val = down1R.init_val();
				switch (down1R.data_typ()) {
				case MCMiningUtil.TYPE_STRING:
					down1R.text(val);
					break;
				case MCMiningUtil.TYPE_NUMBER:
					down1R.num(MCNumber.valueOf(val));
					break;
				case MCMiningUtil.TYPE_BOOLEAN:
					down1R.check(MCBooleanUtil.dbStringToBoolean(val));
					break;
				case MCMiningUtil.TYPE_DATE:
				case MCMiningUtil.TYPE_TIMESTAMP:
					down1R.date(MCTimestamp.valueOf(val, MCTimestamp.TO_STRING_FORMAT));
					break;
				}
			});

			// 集計情報
			bridge.down2().forEach(down2R -> {
				// 名称補完
				FSC_SUM_INFO_TYPE.putNameNE(down2R, MethodR.$sum_info_type, MethodR.$sum_info_type_nm);
				FSC_ROUNDING_MODE_TYPE.putNameNE(down2R, MethodR.$rounding_mode_type, MethodR.$rounding_mode_type_nm);
				FSC_SORT_TYPE.putNameNE(down2R, MethodR.$sort_type, MethodR.$sort_type_nm);
				FSC_GADGET_CHART_TYPE.putNameNE(down2R, MethodR.$chart_type, MethodR.$chart_type_nm);

				// グラフ色
				MCNumber[] rgb = MCFXGraph.splitColorValue(down2R.chart_color());
				down2R.red(rgb[0]);
				down2R.green(rgb[1]);
				down2R.blue(rgb[2]);

				// 集計条件必須チェック
				down2R.addBooleanColumn(_req_sumcond, !isNull(down2R.sumcond()));
				// 日付書式必須チェック
				down2R.addBooleanColumn(_req_date_fmt, !isNull(down2R.date_fmt()));
			});
		}

		@Override
		protected void show() {
			super.show();

			// マイニング基本設定
			if (getMiningParamL().size() > 0) {
				MCRow.copyall(getMiningR(), getMiningParamL().get(0));
			}
			else {
				getMiningR().clear();
			}

			// オプション設定
			MethodOptR optR = getMethodOptR();
			optR.rank_type(null);
			optR.rank_size(null);
			optR.fill_dt_fm(null);
			optR.fill_dt_to(null);
			for (MethodR methodR : getMethodL()) {
				if (methodR.rank()) {
					optR.rank_type(methodR.rank_type());
					optR.rank_size(methodR.rank_size());
				}
				if (methodR.fill_dt()) {
					optR.fill_dt_fm(methodR.fill_dt_fm());
					optR.fill_dt_to(methodR.fill_dt_to());
				}
			}
			FSC_SORT_TYPE.putNameNE(optR, MethodOptR.$rank_type, MethodOptR.$rank_type_nm);
			optR.setStatus(Status.NONE);
		}

		@Override
		protected void setMode() {
			super.setMode();
			if (MODE_FS_FSBAL0760_Srch01 != null) {
				getBaseRootPanel().setStatus(MODE_FS_FSBAL0760_Srch01);
			}
		}

		@Override
		protected void setModeNoDown() {
			super.setModeNoDown();
			if (MODE_NO_DATA_FS_FSBAL0760_Srch01 != null) {
				getBaseRootPanel().setStatus(MODE_NO_DATA_FS_FSBAL0760_Srch01);
			}
		}

	}

	/**
	 * [FS_FSBAL0760_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Upd01Caller<P extends FSBAP_MiningDtl, B extends FS_FSBAL0760_Upd01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected FS_FSBAL0760_Upd01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();
			addUpContainer(getMethodOptR());
		}

		@Override
		protected void checkForCallStack(MCMessageList msgList) {
			super.checkForCallStack(msgList);

			int cnt_chart = 0;
			int cnt_color = 0;
			for (MethodR methodR : getMethodL()) {
				// グラフ色指定チェック
				if (!isNull(methodR.chart_type())) {
					cnt_chart++;

					String rgb = MCFXGraph.createColorValue(
							methodR.chart_color_p().red(),
							methodR.chart_color_p().green(),
							methodR.chart_color_p().blue()
						);
					methodR.chart_color(rgb);
					if (rgb != null) {
						cnt_color++;
					}
				}
			}
			if (cnt_color > 0 && cnt_color != cnt_chart) {
				// 色指定する場合はすべてのグラフに設定する
				msgList.add(new MCMessage(FSBAC0071));
			}
		}

		@Override
		protected void beforeCall() {
			super.beforeCall();

			// 登録前処理
			beforeUpdate();
		}

		@Override
		protected void statusClear() {
			super.statusClear();

			// 行ステータスクリア
			setAllRowStatus(Status.NONE);
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();

			// メニューガジェット一覧更新（２層用）
			updateMenuGadgetListFor2tier(getMiningR().mining_id());

			// 正常終了の代替え用に、ここで通知
			if (MODE_FS_FSBAL0760_Upd01 != null) {
				getBaseRootPanel().setStatus(MODE_FS_FSBAL0760_Upd01);
			}
		}
	}

	/**
	 * [FS_FSBAL0760_Ins01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Ins01Caller<P extends FSBAP_MiningDtl, B extends FS_FSBAL0760_Ins01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected FS_FSBAL0760_Ins01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();
			addUpContainer(getMethodOptR());
		}

		@Override
		protected boolean isUpBlockStatusNone() {
			return false;
		}

		@Override
		protected void beforeCall() {
			super.beforeCall();

			// 登録前処理
			beforeUpdate();
		}

		@Override
		protected void show() {
			super.show();

			// マイニングIDの反映
			String id = getMiningR().mining_id();
			getCondL().setString(CondR.$mining_id, id);
			getMethodL().setString(MethodR.$mining_id, id);
		}

		@Override
		protected void statusClear() {
			super.statusClear();

			// 行ステータスクリア
			setAllRowStatus(Status.NONE);
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();

			// メニューガジェット一覧更新（２層用）
			updateMenuGadgetListFor2tier(getMiningR().mining_id());

			// 正常終了の代替え用に、ここで通知
			if (MODE_FS_FSBAL0760_Ins01 != null) {
				getBaseRootPanel().setStatus(MODE_FS_FSBAL0760_Ins01);
			}
		}
	}

	/**
	 * [FS_FSBAL0760_Ins02]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Ins02Caller<P extends FSBAP_MiningDtl, B extends FS_FSBAL0760_Ins02Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected FS_FSBAL0760_Ins02Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();
			addUpContainer(getMethodOptR());
		}

		@Override
		protected void beforeCall() {
			super.beforeCall();

			// 登録前処理
			beforeUpdate();
		}

		@Override
		protected void show() {
			super.show();

			// マイニングIDの反映
			String id = getMiningR().mining_id();
			getCondL().setString(CondR.$mining_id, id);
			getMethodL().setString(MethodR.$mining_id, id);
		}

		@Override
		protected void statusClear() {
			super.statusClear();

			// 行ステータスクリア
			setAllRowStatus(Status.NONE);
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();

			// メニューガジェット一覧更新（２層用）
			updateMenuGadgetListFor2tier(getMiningR().mining_id());

			// 正常終了の代替え用に、ここで通知
			if (MODE_FS_FSBAL0760_Ins02 != null) {
				getBaseRootPanel().setStatus(MODE_FS_FSBAL0760_Ins02);
			}
		}
	}

	/**
	 * 表示用データを補完します。
	 *
	 * @param miningR マイニング情報
	 */
	protected void setDisplayData(MiningR miningR) {
		// 名称
		String ope_mid = miningR.module_id();
		String ope_lid = miningR.logic_id();
		String ope_oid = miningR.operation_id();
		String scr_mid = miningR.scr_module_id();
		String scr_sid = miningR.screen_id();
		miningR.operation(MCStringUtil.join(".", ope_mid, ope_lid, ope_oid));
		miningR.operation_nm(MCConst.lgclbl.getLabel(ope_mid, ope_lid, ope_oid));
		miningR.function(MCStringUtil.join(".", ope_mid, ope_lid));
		if (!isNull(scr_mid) && !isNull(scr_sid)) {
			miningR.screen(MCStringUtil.join(".", scr_mid, scr_sid));
			miningR.screen_nm(MCBeansUtil.getResourceScreenName(scr_mid, scr_sid));
		}
		// ガジェットサイズ
		int[] sizes = MCMiningUtil.getGadgetSize(miningR.gadget_size());
		miningR.gadget_w(sizes[0]);
		miningR.gadget_h(sizes[1]);
	}

	/**
	 * 登録処理時の事前処理です。
	 * 
	 * <p>
	 * データ補完を行います。
	 */
	protected void beforeUpdate() {
		// ガジェットサイズ更新
		updateGadgetSize();

		// 検索初期値の更新
		getCondL().forEach(condR -> setInitValueFromInput(condR));

		// オプションの設定
		MethodOptR optR = getMethodOptR();
		getMethodL().forEach(methodR -> {
			if (methodR.rank()) {
				methodR.rank_type(optR.rank_type());
				methodR.rank_size(optR.rank_size());
			}
			if (methodR.fill_dt()) {
				methodR.fill_dt_fm(optR.fill_dt_fm());
				methodR.fill_dt_to(optR.fill_dt_to());
			}
			methodR.setStatus(optR.getStatus());
		});
	}

	/**
	 * ガジェットサイズの入力値を格納用に変換します。
	 *
	 */
	protected void updateGadgetSize() {
		// ガジェットサイズを格納用に変換
		MiningR miningR = getMiningR();
		String size = MCMiningUtil.getGadgetSize(
						miningR.gadget_w().intValue(),
						miningR.gadget_h().intValue()
				);
		miningR.gadget_size(size);
		miningR.md_gadget_size(size);
	}

	/**
	 * 検索条件の入力値を初期値用データに変換します。
	 *
	 * @param condR 検索条件
	 */
	protected void setInitValueFromInput(CondR condR) {
		String val = null;
		if (!condR.editable_flg()) {
			// 編集不可の場合、固定値を設定
			String type = condR.data_typ();
			if (type == null) {
			}
			else switch (type) {
			case MCMiningUtil.TYPE_STRING:
				val = MCMiningUtil.toConditionInitValue(condR.text());
				break;
			case MCMiningUtil.TYPE_BOOLEAN:
				val = MCMiningUtil.toConditionInitValue(condR.check());
				break;
			case MCMiningUtil.TYPE_DATE:
			case MCMiningUtil.TYPE_TIMESTAMP:
				val = MCMiningUtil.toConditionInitValue(condR.date());
				break;
			case MCMiningUtil.TYPE_NUMBER:
				val = MCMiningUtil.toConditionInitValue(condR.num());
				break;
			default:
				break;
			}
		}
		condR.init_val(val);
	}

	/**
	 * 行ステータスを設定します。
	 *
	 * @param status 行ステータス
	 */
	public void setAllRowStatus(MCRow.Status status) {
		getMiningR().setStatus(status);
		getCondL().setStatus(status);
		getMethodL().setStatus(status);
		getMethodOptR().setStatus(status);
	}

	/**
	 * 新規追加定義の場合 true を返します。
	 *
	 * コピーも新規追加に含みます。
	 *
	 * @return 既存定義の場合 false
	 * @since 7.0.1
	 */
	protected boolean isNewEntry() {
		return isNull(getMiningR().mining_id());
	}

	/**
	 * 検索条件が全て編集不可の場合 true を返します。
	 *
	 * @return 編集可の検索条件がある場合 false
	 * @since 7.0.1
	 */
	protected boolean isStaticConditions() {
		return (getCondL().subList(CondR.$editable_flg, Boolean.TRUE)
				.size() <= 0);
	}


	/**
	 * 検索処理を実行します。
	 *
	 * <p>
	 * 検索条件には次の項目が使用されます。
	 * <ul>
	 * <li>mining_id</li>
	 * <li>user_id</li>
	 * <li>acl_co</li>
	 * <li>acl_sys</li>
	 * </ul>
	 *
	 * @param condR 検索条件を設定したコンテナ
	 */
	public void callSrch01(SrchR condR) {
		MCRow.copyvalue(getSrchR(), condR);
		callFS_FSBAL0760_Srch01();
	}
	/**
	 * 検索処理でデータがあった場合の土台画面のモードを設定します。
	 *
	 * @param mode モード。null の場合はモードを設定しない
	 */
	public void setModeForFS_FSBAL0760_Srch01(String mode) {
		MODE_FS_FSBAL0760_Srch01 = mode;
	}
	/**
	 * 検索処理でデータがなかった場合の土台画面のモードを設定します。
	 *
	 * @param mode モード。null の場合はモードを設定しない
	 */
	public void setModeNoDataForFS_FSBAL0760_Srch01(String mode) {
		MODE_NO_DATA_FS_FSBAL0760_Srch01 = mode;
	}

	/**
	 * 更新処理を実行します。
	 *
	 */
	public void callUpd01() {
		callFS_FSBAL0760_Upd01();
	}
	/**
	 * 更新処理が正常終了した場合の土台画面のモードを設定します。
	 *
	 * @param mode モード。null の場合はモードを設定しない
	 */
	public void setModeForFS_FSBAL0760_Upd01(String mode) {
		MODE_FS_FSBAL0760_Upd01 = mode;
	}

	/**
	 * 新規追加処理を実行します。
	 *
	 * 項目名には
	 * {@link MCMiningUtil#getIndexForDefID(mcframe.commonCore.param.MCContainerDef, String)}
	 * で取得したIDを使用する必要があります。
	 *
	 */
	public void callIns01() {
		callFS_FSBAL0760_Ins01();
	}
	/**
	 * 新規追加処理が正常終了した場合の土台画面のモードを設定します。
	 *
	 * @param mode モード。null の場合はモードを設定しない
	 */
	public void setModeForFS_FSBAL0760_Ins01(String mode) {
		MODE_FS_FSBAL0760_Ins01 = mode;
	}

	/**
	 * コピー処理を実行します。
	 *
	 * 項目名にはサーバ側の項目名を使用する必要があります。
	 *
	 */
	public void callIns02() {
		callFS_FSBAL0760_Ins02();
	}
	/**
	 * コピー処理が正常終了した場合の土台画面のモードを設定します。
	 *
	 * @param mode モード。null の場合はモードを設定しない
	 */
	public void setModeForFS_FSBAL0760_Ins02(String mode) {
		MODE_FS_FSBAL0760_Ins02 = mode;
	}

	/**
	 * ２層実行時にメニューガジェット一覧を更新します。
	 *
	 * ３層環境の場合は何もしません。
	 *
	 * @param ids 更新があったガジェットID
	 */
	public void updateMenuGadgetListFor2tier(String...ids) {
		if (!MCServerPushManager.getManager().canPush()) {
			// プッシュ不可＝２層の場合
			MCDashboardUtil.updateMenuGadgetList(ids);
		}
	}

	@Override
	public void doMining_gadget_icon_NC(MCEventInfo info) {
		MCBinary bin = getMiningR().gadget_icon();
		if (bin == null) {
			return;
		}
		if (!bin.isLocalFile()) {
			return;
		}

		// アイコンサイズに変換
		String format = "png";	// PNG固定
		String outfile = String.format("mining%1$h." + format, bin);
		String outdir = MCConfig.client.getString("net.download.dir",
												MCDownloadUtil.downloadPath());
		File out = new File(outdir, outfile);
		File in = bin.toFile();
		MCImageUtil.fitImage(in, out, 32, 32, format);
		MCBinary icon = MCBinary.valueOf(out);
		getMiningR().gadget_icon(icon);
	}

	@Override
	public boolean doMining_gadget_cache_flg_VC(MCEventInfo info) {
		if (!super.doMining_gadget_cache_flg_VC(info)) {
			return false;
		}

		String msgid = (getMiningR().gadget_cache_flg())
							// キャッシュON -> OFF
							? FSBAC0085
							// キャッシュOFF -> ON
							: (isNewEntry())
								// 新規追加 or コピー時
								? FSBAC0086
								// 修正時（編集可検索条件の評価はstatusで行う）
								: null;
		return (msgid == null)
				? true
				: (confirm(msgid) == MCMessageBox.YES_OPTION);
	}

	@Override
	public void doMining_gadget_cache_flg_NC(MCEventInfo info) {
		if (!getMiningR().gadget_cache_flg()) {
			return;
		}

		// ガジェットキャッシュモードの場合、検索条件は編集不可
		getCondL().setBoolean(CondR.$editable_flg, false);
	}

	@Override
	public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
		super.doDCEvent(compo, info);

		if (compo == columnMethod_sumcond) {
			doMethod_sumcond_DC(info);
		}
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のDoubleClickイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	protected void doMethod_sumcond_DC(MCEventInfo info) {
		doDCEventForIS(columnMethod_sumcond, info);
	}

	@Override
	public void openISPanel(MCLinkBeans compo, int eventIndex) {
		if (compo == columnMethod_sumcond) {
			openModalPanel("FS", "FSBAP0810", T2, null, this);// T2:修正モード
			return;
		}
		super.openISPanel(compo, eventIndex);
	}

	@Override
	public boolean doMethod_sumcond_VC(MCEventInfo info){
		// 計算式に影響するため、名称の変更はできない
		// 集計条件の編集は可能
		// 変更できない旨のダイアログを表示する
		dialog(FSBAC0081);

		return false;
	}

	@Override
	public String getSumCondName() {
		MethodR methodR = MethodTable.getSelectedMCRow();
		return methodR.sumcond();
	}

	@Override
	public List<MCRowFilter> getSumCondList() {
		MethodR methodR = MethodTable.getSelectedMCRow();
		return getSumCondList(methodR);
	}

	/**
	 * 集計情報の集計条件を格納するListをを返します。
	 * 
	 * <p>
	 * 引数のインスタンスがキーになっています。
	 * 同じ値を格納した別インスタンスでは取得できません。
	 * <p>
	 * 集計条件が設定されていない場合は null を返します。
	 *
	 * @param infoR 集計情報
	 * @return 集計条件を格納するList、または null
	 */
	public List<MCRowFilter> getSumCondList(MethodR methodR) {
		MCList<SumCondParamR> sumcondL = getSumCondParamL().subList(
									SumCondParamR.$sumcond, methodR.sumcond());
		List<MCRowFilter> list = new ArrayList<>();
		sumcondL.forEach(sumcondR -> {
			// 集計条件をRowFilterに変換
			MCRowFilter filter = new MCRowFilter();
			MCMiningUtil.setSumCondFilter(filter, 
					sumcondR.col_id(),
					sumcondR.cond_val(),
					MCMiningUtil.toDataType(sumcondR.data_typ()),
					sumcondR.relative_ope(),
					sumcondR.logic_ope(),
					sumcondR.inv_flg());
			list.add(filter);
		});
		return list;
	}

	@Override
	public void setSumCond(String name, List<MCRowFilter> list) {
		MethodR methodR = MethodTable.getSelectedMCRow();
		if (name == null || list == null || list.size() <= 0) {
			// 値がそろわない場合は変更しない
		}
		else {
			// 名称
			methodR.sumcond(name);
			// 詳細
			MCList<SumCondParamR> sumcondL = getSumCondParamL().subList(
												SumCondParamR.$sumcond, name);
			sumcondL.sort(SumCondParamR.$list_order);
			int cnt = Math.min(sumcondL.size(), list.size());
			for (int i = 0; i < cnt; i++) {
				MCRowFilter filter = list.get(i);

				SumCondParamR sumcondR = sumcondL.get(i);
				// キー部は更新しない
				sumcondR.col_id(filter.getColumnName());
				sumcondR.data_typ(MCMiningUtil.toDataTypeString(filter.getDataType()));
				sumcondR.cond_val(MCMiningUtil.toSumCondValue(filter));
				sumcondR.relative_ope(filter.getRelativeOperator());
				sumcondR.logic_ope(filter.getLogicOperator());
				sumcondR.inv_flg(filter.isDisable());
			}
		}
		if (methodR.isStatusNone()) {
			methodR.setStatus(Status.MODIFY);
		}

		MethodTable.adjustWidth();
	}

	/**
	 * 集計対象のテーブルを返します。
	 *
	 * @return 集計対象のテーブル
	 */
	@Override
	public MCTable<?> getTargetTable() {
		// 定義作成元画面がないので常に null
		return null;
	}

	@Override
	public void doMethod_rank_NC(MCEventInfo info) {
		int sel = info.getNewIndex();
		MCList<MethodR> list = getMethodL();
		for (int i = 0; i < list.size(); i++) {
			if (i != sel) {
				MethodR row = list.get(i);
				row.rank(false);
			}
		}

		if (!(Boolean) info.getNewValue()) {
			getMethodOptR().rank_type(null);
			getMethodOptR().rank_type_nm(null);
			getMethodOptR().rank_size(null);
			MethodOpt_rank_type_nm.setMode(MCMode.DISABLE);
			MethodOpt_rank_size.setMode(MCMode.DISABLE);
		}
		else {
			MethodOpt_rank_type_nm.setMode(MCMode.ENABLE);
			MethodOpt_rank_size.setMode(MCMode.ENABLE);
		}
	}

	@Override
	public void doMethod_fill_dt_NC(MCEventInfo info) {
		int sel = info.getNewIndex();
		MCList<MethodR> list = getMethodL();
		for (int i = 0; i < list.size(); i++) {
			if (i != sel) {
				MethodR row = list.get(i);
				row.fill_dt(false);
			}
		}

		if (!(Boolean) info.getNewValue()) {
			getMethodOptR().fill_dt_fm(null);
			getMethodOptR().fill_dt_to(null);
			MethodOpt_fill_dt_fm.setMode(MCMode.DISABLE);
			MethodOpt_fill_dt_to.setMode(MCMode.DISABLE);
		}
		else {
			MethodOpt_fill_dt_fm.setMode(MCMode.ENABLE);
			MethodOpt_fill_dt_to.setMode(MCMode.ENABLE);
		}
	}


	@Override
	public boolean isChanged(MCTable<?> tbl) {
		if (tbl == MethodTable) {
			MCList<?> list = tbl.getList();
			if (list == null) {
				return false;
			}
			return !list.isStatusNone();
		}
		return super.isChanged(tbl);
	}

	@Override
	protected void listInit() {
		super.listInit();

		columnMethod_column_nm.setListVisibleColumn(MethodR.$column_nm);
		columnMethod_date_fmt.setListVisibleColumn(MethodR.$date_fmt);

		getMethod_chart_type_nm_ListPutter().setColumns(
					FSC_GADGET_CHART_TYPE.$NAME,
					FSC_GADGET_CHART_TYPE.$VALUE
				);

		getMethodOpt_rank_type_nm_ListPutter().setColumns(
					FSC_SORT_TYPE.$NAME,
					FSC_SORT_TYPE.$VALUE
				);
	}

	@Override
	public MCList getMethod_date_fmt(MCRow row, MCEventInfo info){
		// FSBAP0360と同じ
		String[] fmts = MCConst.format.findPattern("date.*");

		MCList<MCRow> list = MCList.create(MCRow.class);
		for (String fmt : fmts) {
			MCRow w = MCRow.create();
			w.setStringNE(MethodR.$date_fmt, fmt.substring(5));// "date."を除く
			list.add(w);
		}
		return list;
	}

	@Override
	public MCList getMethod_column_nm(MCRow row, MCEventInfo info) {
// 2016/11/22 カラムを変更できるようにする場合有効にする（FSBAP0360がベース）
//		String s = getMethodL().get(info.getEventIndex()).sum_info_type();
//		if (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(s)) {
//			// 集計後計算の場合、リストは空にする
//			return MCList.create(MCRow.class);
//		}
//		return getColumnNameList(s);

		// 編集不可 > 空のリストを返す
		return MCList.create(MCRow.class);
	}

	@Override
	protected void valueInit() {
		// 土台利用時用

		super.valueInit();

		CondTable.adjustWidth();
		MethodTable.adjustWidth();
	}

	@Override
	protected void tableInit() {
		// 土台利用時用

		super.tableInit();

		// 単一行選択
		CondTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		MethodTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// ソート不可
		CondTable.setSortable(false);
		MethodTable.setSortable(false);
	}

	@Override
	public void setENABLEStatus() {
		super.setENABLEStatus();

		// キャッシュモード制御
		// 会社共通かシステム共通のみ有効
		String pub = getMiningR().public_lv();
		Mining_gadget_cache_flg.setMode(
				(isSame(MCGroupResource.EXT_ATTR_USER_ID, pub)
						|| isSame(MCGroupResource.SYSTEM_USER_ID, pub))
					// 共有
					? (isNewEntry() || isStaticConditions())
							// 新規追加 or コピー時
							// 修正 & 編集可能検索条件なし
							? MCMode.REQUIRED
							// 修正 & 編集可能検索条件あり
							: MCMode.READ_ONLY
					// ユーザ
					: MCMode.READ_ONLY
		);

		// 順位と日時補完の制御
		// 対象カラムが未設定の場合は入力不可
		boolean rank = false;
		boolean fill_dt = false;
		for (MethodR r : getMethodL()) {
			if (r.rank()) {
				rank = true;
				break;
			}
			if (r.fill_dt()) {
				fill_dt = true;
				break;
			}
		}
		if (!rank) {
			MethodOpt_rank_type_nm.setMode(MCMode.DISABLE);
			MethodOpt_rank_size.setMode(MCMode.DISABLE);
		}
		if (!fill_dt) {
			MethodOpt_fill_dt_fm.setMode(MCMode.DISABLE);
			MethodOpt_fill_dt_to.setMode(MCMode.DISABLE);
		}
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}


	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		CondTable.setCellConfig(createCondCellConfig());
		MethodTable.setCellConfig(createMethodCellConfig());
		
	}

	/**
	 * 検索条件テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 検索条件テーブルに設定するセルコンフィグ
	 */
	protected FXBAP_CellConfig createCondCellConfig() {
		return new FSBAP_Cond_CellConfig();
	}

	/**
	 * 集計情報テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 集計情報テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createMethodCellConfig() {
		return new FSBAP_Method_CellConfig();
	}

	/**
	 * 検索条件一覧のカラムコンフィグです。
	 *
	 */
	public class FSBAP_Cond_CellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			if (getStatus().equals(READ_ONLY)) {
				return super.getPriorMode(index, column, table);
			}

			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}

			CondR o = getCondL().get(index);
			String t = o.data_typ(); // データ型

			if (column == columnCond_require_flg) {
				if (!o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (MCMiningUtil.TYPE_BOOLEAN.equals(t)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnCond_editable_flg) {
				if (!isNewEntry()) {
					// 既存データは変更不可
					return MCMode.DISABLE;
				}
			}
			else if (column == columnCond_text) {
				if (o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (!MCMiningUtil.TYPE_STRING.equals(t)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnCond_check) {
				if (o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (!MCMiningUtil.TYPE_BOOLEAN.equals(t)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnCond_date) {
				if (o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (!MCMiningUtil.TYPE_DATE.equals(t)
						&& !MCMiningUtil.TYPE_TIMESTAMP.equals(t)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnCond_num) {
				if (o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (!MCMiningUtil.TYPE_NUMBER.equals(t)) {
					return MCMode.READ_ONLY;
				}
			}

			return super.getPriorMode(index, column, table);
		}
	}

	/**
	 * 集計方法一覧のカラムコンフィグです。
	 *
	 */
	public class FSBAP_Method_CellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			// 利用不可のカラムのモード
			final MCMode _LIMITED_MODE = MCMode.DISABLE;//READ_ONLY;

			if (getStatus().equals(READ_ONLY)) {
				return super.getPriorMode(index, column, table);
			}

			MethodR o = getMethodL().get(index);
			String y = o.sum_info_type();

			if (column == columnMethod_column_nm) {
				// 変更不可
			}
			else if (column == columnMethod_column_key) {
				// 変更不可
			}
			else if (column == columnMethod_sumcond) {
				if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)
						|| FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(y)
						|| !o.getBooleanNE(_req_sumcond)
				) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_rank) {
				if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_fill_dt) {
				// 検索時に日時書式に値があった場合は入力必須
				if (!FSC_SUM_INFO_TYPE.isTYPE_GROUP(y) || !o.getBooleanNE(_req_date_fmt)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_date_fmt) {
				// 検索時に日時書式に値があった場合は入力必須
				if (!FSC_SUM_INFO_TYPE.isTYPE_GROUP(y) || !o.getBooleanNE(_req_date_fmt)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_formula) {
				// 変更不可
			}
			else if (column == columnMethod_dec_place 
					|| column == columnMethod_rounding_mode_type_nm) {
				if (!FSC_SUM_INFO_TYPE.isTYPE_AVG(y) && isNull(o.formula())) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_null_zero) {
				if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)
						|| FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(y)
				) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_sort_order 
					|| column == columnMethod_sort_type) {
				if (!isNullAnd(o.sort_order(), o.sort_type())) {
					return MCMode.REQUIRED;
				}
			}
			else if (column == columnMethod_chart_type_nm) {
				if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == Method_chart_color_p_PPanel.columnColor_color) {
				if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(y) || isNull(o.chart_type())) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnMethod_row_label) {
				// 変更可
			}

			return super.getPriorMode(index, column, table);
		}
	}

}