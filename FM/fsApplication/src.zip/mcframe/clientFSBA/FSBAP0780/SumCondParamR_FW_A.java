package mcframe.clientFSBA.FSBAP0780;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"SumCondParam"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class SumCondParamR_FW_A extends MCConstRow {

	public static final String $mining_id = "mining_id";
	public static final String $sumcond = "sumcond";
	public static final String $list_order = "list_order";
	public static final String $col_id = "col_id";
	public static final String $data_typ = "data_typ";
	public static final String $cond_val = "cond_val";
	public static final String $relative_ope = "relative_ope";
	public static final String $logic_ope = "logic_ope";
	public static final String $inv_flg = "inv_flg";


	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta sumcond_META = createCommonMeta($sumcond, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta list_order_META = createCommonMeta($list_order, mcframe.commonCore.meta.M_META.SORT_ORDER);
	public static final MCMeta col_id_META = createCommonMeta($col_id, mcframe.commonCore.meta.M_META.RES_KEY);
	public static final MCMeta data_typ_META = createCommonMeta($data_typ, mcframe.commonCore.meta.M_META.DATA_TYPE_TYP);
	public static final MCMeta cond_val_META = createCommonMeta($cond_val, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta relative_ope_META = createCommonMeta($relative_ope, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta logic_ope_META = createCommonMeta($logic_ope, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta inv_flg_META = createCommonMeta($inv_flg, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<SumCondParamR> constMetas = new ConstMetaList<SumCondParamR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			mining_id_META,
			sumcond_META,
			list_order_META,
			col_id_META,
			data_typ_META,
			cond_val_META,
			relative_ope_META,
			logic_ope_META,
			inv_flg_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected SumCondParamR_FW_A(ConstMetaList<? extends SumCondParamR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SumCondParamR clone() {
		return (SumCondParamR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SumCondParamR createInstance() {
		return (SumCondParamR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SumCondParamR getValues(String... names) {
		return (SumCondParamR) super.getValues(names);
	}



	public String mining_id() {
		return getConstString(offset + 0, $mining_id);
	}

	public void mining_id(String value) {
		setConstString(offset + 0, $mining_id, value);
	}


	public String sumcond() {
		return getConstString(offset + 1, $sumcond);
	}

	public void sumcond(String value) {
		setConstString(offset + 1, $sumcond, value);
	}


	public MCNumber list_order() {
		return getConstNumber(offset + 2, $list_order);
	}

	public void list_order(MCNumber value) {
		setConstNumber(offset + 2, $list_order, value);
	}

	public void list_order(int value) {
		setConstNumber(offset + 2, $list_order, value);
	}

	public void list_order(long value) {
		setConstNumber(offset + 2, $list_order, value);
	}

	public void list_order(float value) {
		setConstNumber(offset + 2, $list_order, value);
	}

	public void list_order(double value) {
		setConstNumber(offset + 2, $list_order, value);
	}


	public String col_id() {
		return getConstString(offset + 3, $col_id);
	}

	public void col_id(String value) {
		setConstString(offset + 3, $col_id, value);
	}


	public String data_typ() {
		return getConstString(offset + 4, $data_typ);
	}

	public void data_typ(String value) {
		setConstString(offset + 4, $data_typ, value);
	}


	public String cond_val() {
		return getConstString(offset + 5, $cond_val);
	}

	public void cond_val(String value) {
		setConstString(offset + 5, $cond_val, value);
	}


	public String relative_ope() {
		return getConstString(offset + 6, $relative_ope);
	}

	public void relative_ope(String value) {
		setConstString(offset + 6, $relative_ope, value);
	}


	public String logic_ope() {
		return getConstString(offset + 7, $logic_ope);
	}

	public void logic_ope(String value) {
		setConstString(offset + 7, $logic_ope, value);
	}


	public boolean inv_flg() {
		return getConstBoolean(offset + 8, $inv_flg);
	}

	public void inv_flg(boolean value) {
		setConstBoolean(offset + 8, $inv_flg, value);
	}


	public String getString(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			return sumcond();
		}
		if ($col_id.equalsIgnoreCase(name)) {
			return col_id();
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			return data_typ();
		}
		if ($cond_val.equalsIgnoreCase(name)) {
			return cond_val();
		}
		if ($relative_ope.equalsIgnoreCase(name)) {
			return relative_ope();
		}
		if ($logic_ope.equalsIgnoreCase(name)) {
			return logic_ope();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			return sumcond();
		}
		if ($col_id.equalsIgnoreCase(name)) {
			return col_id();
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			return data_typ();
		}
		if ($cond_val.equalsIgnoreCase(name)) {
			return cond_val();
		}
		if ($relative_ope.equalsIgnoreCase(name)) {
			return relative_ope();
		}
		if ($logic_ope.equalsIgnoreCase(name)) {
			return logic_ope();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			sumcond(value);
			return;
		}
		if ($col_id.equalsIgnoreCase(name)) {
			col_id(value);
			return;
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			data_typ(value);
			return;
		}
		if ($cond_val.equalsIgnoreCase(name)) {
			cond_val(value);
			return;
		}
		if ($relative_ope.equalsIgnoreCase(name)) {
			relative_ope(value);
			return;
		}
		if ($logic_ope.equalsIgnoreCase(name)) {
			logic_ope(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			sumcond(value);
			return;
		}
		if ($col_id.equalsIgnoreCase(name)) {
			col_id(value);
			return;
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			data_typ(value);
			return;
		}
		if ($cond_val.equalsIgnoreCase(name)) {
			cond_val(value);
			return;
		}
		if ($relative_ope.equalsIgnoreCase(name)) {
			relative_ope(value);
			return;
		}
		if ($logic_ope.equalsIgnoreCase(name)) {
			logic_ope(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

