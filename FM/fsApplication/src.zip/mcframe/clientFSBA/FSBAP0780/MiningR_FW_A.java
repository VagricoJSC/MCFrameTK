package mcframe.clientFSBA.FSBAP0780;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Mining"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MiningR_FW_A extends MCConstRow {

	/**
	 *  選択.<p>
	 *
	 */
	public static final String $check = "check";
	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 *  マイニング名.<p>
	 *
	 */
	public static final String $mining_nm = "mining_nm";
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $user_id = "user_id";
	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public static final String $co_cd = "co_cd";
	/**
	 *  公開レベル.<p>
	 *
	 */
	public static final String $public_lv = "public_lv";
	/**
	 *  説明.<p>
	 *
	 */
	public static final String $description_text = "description_text";
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $module_id = "module_id";
	/**
	 *  ロジックＩＤ.<p>
	 *
	 */
	public static final String $logic_id = "logic_id";
	/**
	 *  オペレーションＩＤ.<p>
	 *
	 */
	public static final String $operation_id = "operation_id";
	/**
	 *  画面モジュールＩＤ.<p>
	 *
	 */
	public static final String $scr_module_id = "scr_module_id";
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public static final String $screen_id = "screen_id";
	/**
	 *  ガジェットサイズ.<p>
	 *
	 */
	public static final String $gadget_size = "gadget_size";
	/**
	 *  オペレーション.<p>
	 *
	 */
	public static final String $operation = "operation";
	/**
	 *  オペレーション名.<p>
	 *
	 */
	public static final String $operation_nm = "operation_nm";
	public static final String $function = "function";
	/**
	 *  機能種別.<p>
	 *
	 */
	public static final String $func_typ = "func_typ";
	/**
	 *  画面.<p>
	 *
	 */
	public static final String $screen = "screen";
	/**
	 *  画面名.<p>
	 *
	 */
	public static final String $screen_nm = "screen_nm";
	/**
	 *  ＭＤオプションモジュールＩＤ.<p>
	 *
	 */
	public static final String $md_module_id = "md_module_id";
	/**
	 *  ＭＤオプション画面ＩＤ.<p>
	 *
	 */
	public static final String $md_screen_id = "md_screen_id";
	/**
	 *  ＭＤオプションガジェットサイズ.<p>
	 *
	 */
	public static final String $md_gadget_size = "md_gadget_size";
	/**
	 *  ガジェットアイコン.<p>
	 *
	 */
	public static final String $gadget_icon = "gadget_icon";
	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public static final String $gadget_w = "gadget_w";
	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public static final String $gadget_h = "gadget_h";
	/**
	 *  キャッシュデータ利用.<p>
	 *
	 */
	public static final String $gadget_cache_flg = "gadget_cache_flg";
	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public static final String $upd_cntr = "upd_cntr";


	public static final MCMeta check_META = createCommonMeta($check, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta mining_nm_META = createCommonMeta($mining_nm, mcframe.commonCore.meta.M_META.MINING_NM);
	public static final MCMeta user_id_META = createCommonMeta($user_id, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta co_cd_META = createCommonMeta($co_cd, mcframe.commonCore.meta.M_META.CO_CD);
	public static final MCMeta public_lv_META = createCommonMeta($public_lv, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta description_text_META = createCommonMeta($description_text, mcframe.commonCore.meta.M_META.DESCRIPTION_TEXT);
	public static final MCMeta module_id_META = createCommonMeta($module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta logic_id_META = createCommonMeta($logic_id, mcframe.commonCore.meta.M_META.LOGIC_ID);
	public static final MCMeta operation_id_META = createCommonMeta($operation_id, mcframe.commonCore.meta.M_META.OPERATION_ID);
	public static final MCMeta scr_module_id_META = createCommonMeta($scr_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta screen_id_META = createCommonMeta($screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta gadget_size_META = createCommonMeta($gadget_size, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta operation_META = createCommonMeta($operation, mcframe.commonCore.meta.M_META.OPERATION_NM);
	public static final MCMeta operation_nm_META = createCommonMeta($operation_nm, mcframe.commonCore.meta.M_META.OPERATION_NM);
	public static final MCMeta function_META = createCommonMeta($function, mcframe.commonCore.meta.M_META.OPERATION_NM);
	public static final MCMeta func_typ_META = createCommonMeta($func_typ, mcframe.commonCore.meta.M_META.FUNC_TYP);
	public static final MCMeta screen_META = createCommonMeta($screen, mcframe.commonCore.meta.M_META.SCREEN_NM);
	public static final MCMeta screen_nm_META = createCommonMeta($screen_nm, mcframe.commonCore.meta.M_META.SCREEN_NM);
	public static final MCMeta md_module_id_META = createCommonMeta($md_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta md_screen_id_META = createCommonMeta($md_screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta md_gadget_size_META = createCommonMeta($md_gadget_size, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta gadget_icon_META = createCommonMeta($gadget_icon, mcframe.commonCore.meta.M_META.BIN);
	public static final MCMeta gadget_w_META = createNumberMeta($gadget_w, 1, 0, false);
	public static final MCMeta gadget_h_META = createNumberMeta($gadget_h, 1, 0, false);
	public static final MCMeta gadget_cache_flg_META = createBooleanMeta($gadget_cache_flg);
	public static final MCMeta upd_cntr_META = createCommonMeta($upd_cntr, mcframe.commonCore.meta.M_META.UPD_CNT);

	protected static final ConstMetaList<MiningR> constMetas = new ConstMetaList<MiningR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			check_META,
			mining_id_META,
			mining_nm_META,
			user_id_META,
			co_cd_META,
			public_lv_META,
			description_text_META,
			module_id_META,
			logic_id_META,
			operation_id_META,
			scr_module_id_META,
			screen_id_META,
			gadget_size_META,
			operation_META,
			operation_nm_META,
			function_META,
			func_typ_META,
			screen_META,
			screen_nm_META,
			md_module_id_META,
			md_screen_id_META,
			md_gadget_size_META,
			gadget_icon_META,
			gadget_w_META,
			gadget_h_META,
			gadget_cache_flg_META,
			upd_cntr_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MiningR_FW_A(ConstMetaList<? extends MiningR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MiningR clone() {
		return (MiningR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MiningR createInstance() {
		return (MiningR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MiningR getValues(String... names) {
		return (MiningR) super.getValues(names);
	}



	/**
	 *  選択.<p>
	 *
	 */
	public boolean check() {
		return getConstBoolean(offset + 0, $check);
	}

	/**
	 *  選択.<p>
	 *
	 */
	public void check(boolean value) {
		setConstBoolean(offset + 0, $check, value);
	}


	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 1, $mining_id);
	}

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 1, $mining_id, value);
	}


	/**
	 *  マイニング名.<p>
	 *
	 */
	public String mining_nm() {
		return getConstString(offset + 2, $mining_nm);
	}

	/**
	 *  マイニング名.<p>
	 *
	 */
	public void mining_nm(String value) {
		setConstString(offset + 2, $mining_nm, value);
	}


	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String user_id() {
		return getConstString(offset + 3, $user_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void user_id(String value) {
		setConstString(offset + 3, $user_id, value);
	}


	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public String co_cd() {
		return getConstString(offset + 4, $co_cd);
	}

	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public void co_cd(String value) {
		setConstString(offset + 4, $co_cd, value);
	}


	/**
	 *  公開レベル.<p>
	 *
	 */
	public String public_lv() {
		return getConstString(offset + 5, $public_lv);
	}

	/**
	 *  公開レベル.<p>
	 *
	 */
	public void public_lv(String value) {
		setConstString(offset + 5, $public_lv, value);
	}


	/**
	 *  説明.<p>
	 *
	 */
	public String description_text() {
		return getConstString(offset + 6, $description_text);
	}

	/**
	 *  説明.<p>
	 *
	 */
	public void description_text(String value) {
		setConstString(offset + 6, $description_text, value);
	}


	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String module_id() {
		return getConstString(offset + 7, $module_id);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void module_id(String value) {
		setConstString(offset + 7, $module_id, value);
	}


	/**
	 *  ロジックＩＤ.<p>
	 *
	 */
	public String logic_id() {
		return getConstString(offset + 8, $logic_id);
	}

	/**
	 *  ロジックＩＤ.<p>
	 *
	 */
	public void logic_id(String value) {
		setConstString(offset + 8, $logic_id, value);
	}


	/**
	 *  オペレーションＩＤ.<p>
	 *
	 */
	public String operation_id() {
		return getConstString(offset + 9, $operation_id);
	}

	/**
	 *  オペレーションＩＤ.<p>
	 *
	 */
	public void operation_id(String value) {
		setConstString(offset + 9, $operation_id, value);
	}


	/**
	 *  画面モジュールＩＤ.<p>
	 *
	 */
	public String scr_module_id() {
		return getConstString(offset + 10, $scr_module_id);
	}

	/**
	 *  画面モジュールＩＤ.<p>
	 *
	 */
	public void scr_module_id(String value) {
		setConstString(offset + 10, $scr_module_id, value);
	}


	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public String screen_id() {
		return getConstString(offset + 11, $screen_id);
	}

	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public void screen_id(String value) {
		setConstString(offset + 11, $screen_id, value);
	}


	/**
	 *  ガジェットサイズ.<p>
	 *
	 */
	public String gadget_size() {
		return getConstString(offset + 12, $gadget_size);
	}

	/**
	 *  ガジェットサイズ.<p>
	 *
	 */
	public void gadget_size(String value) {
		setConstString(offset + 12, $gadget_size, value);
	}


	/**
	 *  オペレーション.<p>
	 *
	 */
	public String operation() {
		return getConstString(offset + 13, $operation);
	}

	/**
	 *  オペレーション.<p>
	 *
	 */
	public void operation(String value) {
		setConstString(offset + 13, $operation, value);
	}


	/**
	 *  オペレーション名.<p>
	 *
	 */
	public String operation_nm() {
		return getConstString(offset + 14, $operation_nm);
	}

	/**
	 *  オペレーション名.<p>
	 *
	 */
	public void operation_nm(String value) {
		setConstString(offset + 14, $operation_nm, value);
	}


	public String function() {
		return getConstString(offset + 15, $function);
	}

	public void function(String value) {
		setConstString(offset + 15, $function, value);
	}


	/**
	 *  機能種別.<p>
	 *
	 */
	public String func_typ() {
		return getConstString(offset + 16, $func_typ);
	}

	/**
	 *  機能種別.<p>
	 *
	 */
	public void func_typ(String value) {
		setConstString(offset + 16, $func_typ, value);
	}


	/**
	 *  画面.<p>
	 *
	 */
	public String screen() {
		return getConstString(offset + 17, $screen);
	}

	/**
	 *  画面.<p>
	 *
	 */
	public void screen(String value) {
		setConstString(offset + 17, $screen, value);
	}


	/**
	 *  画面名.<p>
	 *
	 */
	public String screen_nm() {
		return getConstString(offset + 18, $screen_nm);
	}

	/**
	 *  画面名.<p>
	 *
	 */
	public void screen_nm(String value) {
		setConstString(offset + 18, $screen_nm, value);
	}


	/**
	 *  ＭＤオプションモジュールＩＤ.<p>
	 *
	 */
	public String md_module_id() {
		return getConstString(offset + 19, $md_module_id);
	}

	/**
	 *  ＭＤオプションモジュールＩＤ.<p>
	 *
	 */
	public void md_module_id(String value) {
		setConstString(offset + 19, $md_module_id, value);
	}


	/**
	 *  ＭＤオプション画面ＩＤ.<p>
	 *
	 */
	public String md_screen_id() {
		return getConstString(offset + 20, $md_screen_id);
	}

	/**
	 *  ＭＤオプション画面ＩＤ.<p>
	 *
	 */
	public void md_screen_id(String value) {
		setConstString(offset + 20, $md_screen_id, value);
	}


	/**
	 *  ＭＤオプションガジェットサイズ.<p>
	 *
	 */
	public String md_gadget_size() {
		return getConstString(offset + 21, $md_gadget_size);
	}

	/**
	 *  ＭＤオプションガジェットサイズ.<p>
	 *
	 */
	public void md_gadget_size(String value) {
		setConstString(offset + 21, $md_gadget_size, value);
	}


	/**
	 *  ガジェットアイコン.<p>
	 *
	 */
	public MCBinary gadget_icon() {
		return getConstBinary(offset + 22, $gadget_icon);
	}

	/**
	 *  ガジェットアイコン.<p>
	 *
	 */
	public void gadget_icon(MCBinary value) {
		setConstBinary(offset + 22, $gadget_icon, value);
	}


	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public MCNumber gadget_w() {
		return getConstNumber(offset + 23, $gadget_w);
	}

	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public void gadget_w(MCNumber value) {
		setConstNumber(offset + 23, $gadget_w, value);
	}

	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public void gadget_w(int value) {
		setConstNumber(offset + 23, $gadget_w, value);
	}

	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public void gadget_w(long value) {
		setConstNumber(offset + 23, $gadget_w, value);
	}

	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public void gadget_w(float value) {
		setConstNumber(offset + 23, $gadget_w, value);
	}

	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public void gadget_w(double value) {
		setConstNumber(offset + 23, $gadget_w, value);
	}


	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public MCNumber gadget_h() {
		return getConstNumber(offset + 24, $gadget_h);
	}

	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public void gadget_h(MCNumber value) {
		setConstNumber(offset + 24, $gadget_h, value);
	}

	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public void gadget_h(int value) {
		setConstNumber(offset + 24, $gadget_h, value);
	}

	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public void gadget_h(long value) {
		setConstNumber(offset + 24, $gadget_h, value);
	}

	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public void gadget_h(float value) {
		setConstNumber(offset + 24, $gadget_h, value);
	}

	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public void gadget_h(double value) {
		setConstNumber(offset + 24, $gadget_h, value);
	}


	/**
	 *  キャッシュデータ利用.<p>
	 *
	 */
	public boolean gadget_cache_flg() {
		return getConstBoolean(offset + 25, $gadget_cache_flg);
	}

	/**
	 *  キャッシュデータ利用.<p>
	 *
	 */
	public void gadget_cache_flg(boolean value) {
		setConstBoolean(offset + 25, $gadget_cache_flg, value);
	}


	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public MCNumber upd_cntr() {
		return getConstNumber(offset + 26, $upd_cntr);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(MCNumber value) {
		setConstNumber(offset + 26, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(int value) {
		setConstNumber(offset + 26, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(long value) {
		setConstNumber(offset + 26, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(float value) {
		setConstNumber(offset + 26, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(double value) {
		setConstNumber(offset + 26, $upd_cntr, value);
	}


	public String getString(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			return mining_nm();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($public_lv.equalsIgnoreCase(name)) {
			return public_lv();
		}
		if ($description_text.equalsIgnoreCase(name)) {
			return description_text();
		}
		if ($module_id.equalsIgnoreCase(name)) {
			return module_id();
		}
		if ($logic_id.equalsIgnoreCase(name)) {
			return logic_id();
		}
		if ($operation_id.equalsIgnoreCase(name)) {
			return operation_id();
		}
		if ($scr_module_id.equalsIgnoreCase(name)) {
			return scr_module_id();
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			return screen_id();
		}
		if ($gadget_size.equalsIgnoreCase(name)) {
			return gadget_size();
		}
		if ($operation.equalsIgnoreCase(name)) {
			return operation();
		}
		if ($operation_nm.equalsIgnoreCase(name)) {
			return operation_nm();
		}
		if ($function.equalsIgnoreCase(name)) {
			return function();
		}
		if ($func_typ.equalsIgnoreCase(name)) {
			return func_typ();
		}
		if ($screen.equalsIgnoreCase(name)) {
			return screen();
		}
		if ($screen_nm.equalsIgnoreCase(name)) {
			return screen_nm();
		}
		if ($md_module_id.equalsIgnoreCase(name)) {
			return md_module_id();
		}
		if ($md_screen_id.equalsIgnoreCase(name)) {
			return md_screen_id();
		}
		if ($md_gadget_size.equalsIgnoreCase(name)) {
			return md_gadget_size();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			return gadget_w();
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			return gadget_h();
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			return upd_cntr();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		if ($gadget_cache_flg.equalsIgnoreCase(name)) {
			return gadget_cache_flg();
		}
		return super.getBoolean(name);
	}
	public MCBinary getBinary(String name) {
		if ($gadget_icon.equalsIgnoreCase(name)) {
			return gadget_icon();
		}
		return super.getBinary(name);
	}

	public String getStringNE(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			return mining_nm();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($public_lv.equalsIgnoreCase(name)) {
			return public_lv();
		}
		if ($description_text.equalsIgnoreCase(name)) {
			return description_text();
		}
		if ($module_id.equalsIgnoreCase(name)) {
			return module_id();
		}
		if ($logic_id.equalsIgnoreCase(name)) {
			return logic_id();
		}
		if ($operation_id.equalsIgnoreCase(name)) {
			return operation_id();
		}
		if ($scr_module_id.equalsIgnoreCase(name)) {
			return scr_module_id();
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			return screen_id();
		}
		if ($gadget_size.equalsIgnoreCase(name)) {
			return gadget_size();
		}
		if ($operation.equalsIgnoreCase(name)) {
			return operation();
		}
		if ($operation_nm.equalsIgnoreCase(name)) {
			return operation_nm();
		}
		if ($function.equalsIgnoreCase(name)) {
			return function();
		}
		if ($func_typ.equalsIgnoreCase(name)) {
			return func_typ();
		}
		if ($screen.equalsIgnoreCase(name)) {
			return screen();
		}
		if ($screen_nm.equalsIgnoreCase(name)) {
			return screen_nm();
		}
		if ($md_module_id.equalsIgnoreCase(name)) {
			return md_module_id();
		}
		if ($md_screen_id.equalsIgnoreCase(name)) {
			return md_screen_id();
		}
		if ($md_gadget_size.equalsIgnoreCase(name)) {
			return md_gadget_size();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			return gadget_w();
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			return gadget_h();
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			return upd_cntr();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		if ($gadget_cache_flg.equalsIgnoreCase(name)) {
			return gadget_cache_flg();
		}
		return super.getBooleanNE(name);
	}
	public MCBinary getBinaryNE(String name) {
		if ($gadget_icon.equalsIgnoreCase(name)) {
			return gadget_icon();
		}
		return super.getBinaryNE(name);
	}

	public void setString(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			mining_nm(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($public_lv.equalsIgnoreCase(name)) {
			public_lv(value);
			return;
		}
		if ($description_text.equalsIgnoreCase(name)) {
			description_text(value);
			return;
		}
		if ($module_id.equalsIgnoreCase(name)) {
			module_id(value);
			return;
		}
		if ($logic_id.equalsIgnoreCase(name)) {
			logic_id(value);
			return;
		}
		if ($operation_id.equalsIgnoreCase(name)) {
			operation_id(value);
			return;
		}
		if ($scr_module_id.equalsIgnoreCase(name)) {
			scr_module_id(value);
			return;
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			screen_id(value);
			return;
		}
		if ($gadget_size.equalsIgnoreCase(name)) {
			gadget_size(value);
			return;
		}
		if ($operation.equalsIgnoreCase(name)) {
			operation(value);
			return;
		}
		if ($operation_nm.equalsIgnoreCase(name)) {
			operation_nm(value);
			return;
		}
		if ($function.equalsIgnoreCase(name)) {
			function(value);
			return;
		}
		if ($func_typ.equalsIgnoreCase(name)) {
			func_typ(value);
			return;
		}
		if ($screen.equalsIgnoreCase(name)) {
			screen(value);
			return;
		}
		if ($screen_nm.equalsIgnoreCase(name)) {
			screen_nm(value);
			return;
		}
		if ($md_module_id.equalsIgnoreCase(name)) {
			md_module_id(value);
			return;
		}
		if ($md_screen_id.equalsIgnoreCase(name)) {
			md_screen_id(value);
			return;
		}
		if ($md_gadget_size.equalsIgnoreCase(name)) {
			md_gadget_size(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		if ($gadget_cache_flg.equalsIgnoreCase(name)) {
			gadget_cache_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}
	public void setBinary(String name, MCBinary value) {
		if ($gadget_icon.equalsIgnoreCase(name)) {
			gadget_icon(value);
			return;
		}
		super.setBinary(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($mining_nm.equalsIgnoreCase(name)) {
			mining_nm(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($public_lv.equalsIgnoreCase(name)) {
			public_lv(value);
			return;
		}
		if ($description_text.equalsIgnoreCase(name)) {
			description_text(value);
			return;
		}
		if ($module_id.equalsIgnoreCase(name)) {
			module_id(value);
			return;
		}
		if ($logic_id.equalsIgnoreCase(name)) {
			logic_id(value);
			return;
		}
		if ($operation_id.equalsIgnoreCase(name)) {
			operation_id(value);
			return;
		}
		if ($scr_module_id.equalsIgnoreCase(name)) {
			scr_module_id(value);
			return;
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			screen_id(value);
			return;
		}
		if ($gadget_size.equalsIgnoreCase(name)) {
			gadget_size(value);
			return;
		}
		if ($operation.equalsIgnoreCase(name)) {
			operation(value);
			return;
		}
		if ($operation_nm.equalsIgnoreCase(name)) {
			operation_nm(value);
			return;
		}
		if ($function.equalsIgnoreCase(name)) {
			function(value);
			return;
		}
		if ($func_typ.equalsIgnoreCase(name)) {
			func_typ(value);
			return;
		}
		if ($screen.equalsIgnoreCase(name)) {
			screen(value);
			return;
		}
		if ($screen_nm.equalsIgnoreCase(name)) {
			screen_nm(value);
			return;
		}
		if ($md_module_id.equalsIgnoreCase(name)) {
			md_module_id(value);
			return;
		}
		if ($md_screen_id.equalsIgnoreCase(name)) {
			md_screen_id(value);
			return;
		}
		if ($md_gadget_size.equalsIgnoreCase(name)) {
			md_gadget_size(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($gadget_w.equalsIgnoreCase(name)) {
			gadget_w(value);
			return;
		}
		if ($gadget_h.equalsIgnoreCase(name)) {
			gadget_h(value);
			return;
		}
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		if ($gadget_cache_flg.equalsIgnoreCase(name)) {
			gadget_cache_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}
	public void setBinaryNE(String name, MCBinary value) {
		if ($gadget_icon.equalsIgnoreCase(name)) {
			gadget_icon(value);
			return;
		}
		super.setBinaryNE(name, value);
	}



}

