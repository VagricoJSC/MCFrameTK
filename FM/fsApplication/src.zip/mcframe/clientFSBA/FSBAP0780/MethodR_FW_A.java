package mcframe.clientFSBA.FSBAP0780;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Method"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MethodR_FW_A extends mcframe.clientFSBA.FSBAP0360.InfoDtlR {

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 *  表示順.<p>
	 *
	 */
	public static final String $list_order = "list_order";

	public static final String $red = $chart_color_p + ".red";
	public static final String $green = $chart_color_p + ".green";
	public static final String $blue = $chart_color_p + ".blue";
	public static final String $color = $chart_color_p + ".color";

	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta list_order_META = createCommonMeta($list_order, mcframe.commonCore.meta.M_META.SORT_ORDER);

	protected static final ConstMetaList<MethodR> constMetas = new ConstMetaList<MethodR>(
		mcframe.clientFSBA.FSBAP0360.InfoDtlR.constMetas,
		new MCMeta[]{
			mining_id_META,
			list_order_META,
		},
		new String[][]{
			{
				"red",
				"green",
				"blue",
			},
			{
				$red,
				$green,
				$blue,
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		mcframe.clientFSBA.FSBAP0360.InfoDtlR.KEYS,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		mcframe.clientFSBA.FSBAP0360.InfoDtlR.EXTMAP
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MethodR_FW_A(ConstMetaList<? extends MethodR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MethodR clone() {
		return (MethodR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MethodR createInstance() {
		return (MethodR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MethodR getValues(String... names) {
		return (MethodR) super.getValues(names);
	}



	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 0, $mining_id);
	}

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 0, $mining_id, value);
	}


	/**
	 *  表示順.<p>
	 *
	 */
	public MCNumber list_order() {
		return getConstNumber(offset + 1, $list_order);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(MCNumber value) {
		setConstNumber(offset + 1, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(int value) {
		setConstNumber(offset + 1, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(long value) {
		setConstNumber(offset + 1, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(float value) {
		setConstNumber(offset + 1, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(double value) {
		setConstNumber(offset + 1, $list_order, value);
	}


	public String getString(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		super.setBooleanNE(name, value);
	}

	public MCRow getInnerRow(String name) {
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		super.setInnerRow(name, value);
	}


	public MCNumber red() {
		return chart_color_p().red();
	}

	public void red(MCNumber value) {
		chart_color_p().red(value);
	}

	public void red(int value) {
		chart_color_p().red(value);
	}

	public void red(long value) {
		chart_color_p().red(value);
	}

	public void red(float value) {
		chart_color_p().red(value);
	}

	public void red(double value) {
		chart_color_p().red(value);
	}

	public MCNumber green() {
		return chart_color_p().green();
	}

	public void green(MCNumber value) {
		chart_color_p().green(value);
	}

	public void green(int value) {
		chart_color_p().green(value);
	}

	public void green(long value) {
		chart_color_p().green(value);
	}

	public void green(float value) {
		chart_color_p().green(value);
	}

	public void green(double value) {
		chart_color_p().green(value);
	}

	public MCNumber blue() {
		return chart_color_p().blue();
	}

	public void blue(MCNumber value) {
		chart_color_p().blue(value);
	}

	public void blue(int value) {
		chart_color_p().blue(value);
	}

	public void blue(long value) {
		chart_color_p().blue(value);
	}

	public void blue(float value) {
		chart_color_p().blue(value);
	}

	public void blue(double value) {
		chart_color_p().blue(value);
	}

}

