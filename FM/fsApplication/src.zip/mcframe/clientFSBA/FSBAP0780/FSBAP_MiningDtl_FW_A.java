package mcframe.clientFSBA.FSBAP0780;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl_FW.FS_FSBAL0760_Srch01Caller;
import mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl_FW.FS_FSBAL0760_Upd01Caller;
import mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl_FW.FS_FSBAL0760_Ins01Caller;
import mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl_FW.FS_FSBAL0760_Ins02Caller;

/**
 * 画面"FSBAP_MiningDtl"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_MiningDtl_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0780";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Mining]ブロック関連のField定義
	public MCPanel MiningPanel = null;
	// [Mining]ブロックの項目のField定義
	public MCLabel Mining_mining_nm_Label = null;
	/**
	 *  マイニング名.<p>
	 *
	 */
	public MCTextField Mining_mining_nm = null;
	public MCLabel Mining_description_text_Label = null;
	public MCScrollPane Mining_description_textScrollPane = null;
	/**
	 *  説明.<p>
	 *
	 */
	public MCTextArea Mining_description_text = null;
	public MCLabel Mining_operation_Label = null;
	/**
	 *  オペレーション.<p>
	 *
	 */
	public MCTextField Mining_operation = null;
	/**
	 *  オペレーション名.<p>
	 *
	 */
	public MCTextField Mining_operation_nm = null;
	public MCLabel Mining_function_Label = null;
	public MCTextField Mining_function = null;
	public MCLabel Mining_func_typ_Label = null;
	/**
	 *  機能種別.<p>
	 *
	 */
	public MCTextField Mining_func_typ = null;
	public MCLabel Mining_screen_Label = null;
	/**
	 *  画面.<p>
	 *
	 */
	public MCTextField Mining_screen = null;
	/**
	 *  画面名.<p>
	 *
	 */
	public MCTextField Mining_screen_nm = null;
	public MCLabel Mining_md_module_id_Label = null;
	/**
	 *  ＭＤオプションモジュールＩＤ.<p>
	 *
	 */
	public MCTextField Mining_md_module_id = null;
	/**
	 *  ＭＤオプション画面ＩＤ.<p>
	 *
	 */
	public MCTextField Mining_md_screen_id = null;
	public MCLabel Mining_gadget_icon_Label = null;
	/**
	 *  ガジェットアイコン.<p>
	 *
	 */
	public MCImageView Mining_gadget_icon = null;
	public MCLabel Mining_gadget_w_Label = null;
	/**
	 *  ガジェット幅.<p>
	 *
	 */
	public MCNumberField Mining_gadget_w = null;
	public MCLabel Mining_gadget_h_Label = null;
	/**
	 *  ガジェット高さ.<p>
	 *
	 */
	public MCNumberField Mining_gadget_h = null;
	/**
	 *  キャッシュデータ利用.<p>
	 *
	 */
	public MCCheckBox Mining_gadget_cache_flg = null;
	// [Gadget]ブロック関連のField定義
	public MCPanel GadgetPanel = null;
	public MCTitledBorder GadgetTitledBorder = null;
	// [Gadget]ブロックの項目のField定義
	// [MiningDesc]ブロック関連のField定義
	public MCPanel MiningDescPanel = null;
	// [MiningDesc]ブロックの項目のField定義
	// [Cond]ブロック関連のField定義
	public MCPanel CondPanel = null;
	public MCTitledBorder CondTitledBorder = null;
	public MCScrollPane CondScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0780.CondR> CondTable = null;
	// [Cond]ブロックの項目のField定義
	/**
	 *  表示名称.<p>
	 *
	 */
	public MCColumnConfig columnCond_col_nm = null;
	/**
	 *  編集可ＦＬＧ.<p>
	 *
	 */
	public MCColumnConfig columnCond_editable_flg = null;
	/**
	 *  必須ＦＬＧ.<p>
	 *
	 */
	public MCColumnConfig columnCond_require_flg = null;
	/**
	 *  テキスト.<p>
	 *
	 */
	public MCColumnConfig columnCond_text = null;
	/**
	 *  数値.<p>
	 *
	 */
	public MCColumnConfig columnCond_num = null;
	/**
	 *  チェックボックス.<p>
	 *
	 */
	public MCColumnConfig columnCond_check = null;
	/**
	 *  日付.<p>
	 *
	 */
	public MCColumnConfig columnCond_date = null;
	// [Method]ブロック関連のField定義
	public MCPanel MethodPanel = null;
	public MCTitledBorder MethodTitledBorder = null;
	public MCScrollPane MethodScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0780.MethodR> MethodTable = null;
	// [Method]ブロックの項目のField定義
	/**
	 *  無効.<p>
	 *
	 */
	public MCColumnConfig columnMethod_disable = null;
	public MCColumnConfig columnMethod_sum_info_type = null;
	/**
	 *  集計区分名.<p>
	 *
	 */
	public MCColumnConfig columnMethod_sum_info_type_nm = null;
	/**
	 *  カラム名.<p>
	 *
	 */
	public MCColumnConfig columnMethod_column_nm = null;
	/**
	 *  カラムＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnMethod_column_key = null;
	/**
	 *  集計条件名.<p>
	 *
	 */
	public MCColumnConfig columnMethod_sumcond = null;
	/**
	 *  順位対象.<p>
	 *
	 */
	public MCColumnConfig columnMethod_rank = null;
	/**
	 *  日時補完.<p>
	 *
	 */
	public MCColumnConfig columnMethod_fill_dt = null;
	/**
	 *  日時書式.<p>
	 *
	 */
	public MCColumnConfig columnMethod_date_fmt = null;
	/**
	 *  計算式.<p>
	 *
	 */
	public MCColumnConfig columnMethod_formula = null;
	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public MCColumnConfig columnMethod_dec_place = null;
	public MCColumnConfig columnMethod_rounding_mode_type = null;
	/**
	 *  端数処理区分名.<p>
	 *
	 */
	public MCColumnConfig columnMethod_rounding_mode_type_nm = null;
	/**
	 *  null集計0変換.<p>
	 *
	 */
	public MCColumnConfig columnMethod_null_zero = null;
	/**
	 *  ソート順.<p>
	 *
	 */
	public MCColumnConfig columnMethod_sort_order = null;
	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public MCColumnConfig columnMethod_sort_type = null;
	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public MCColumnConfig columnMethod_sort_type_nm = null;
	public MCColumnConfig columnMethod_chart_type = null;
	/**
	 *  グラフ名.<p>
	 *
	 */
	public MCColumnConfig columnMethod_chart_type_nm = null;
	/**
	 *  グラフ色.<p>
	 *
	 */
	public MCColumnConfig columnMethod_chart_color = null;
	public mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D Method_chart_color_p_PPanel;
	public MCColumnConfig columnMethod_red;// [Method]の[chart_color_p.red]を[columnMethod_red]としてエイリアス定義。
	public MCColumnConfig columnMethod_green;// [Method]の[chart_color_p.green]を[columnMethod_green]としてエイリアス定義。
	public MCColumnConfig columnMethod_blue;// [Method]の[chart_color_p.blue]を[columnMethod_blue]としてエイリアス定義。
	public MCColumnConfig columnMethod_color;// [Method]の[chart_color_p.color]を[columnMethod_color]としてエイリアス定義。
	/**
	 *  行ラベル（チャート）.<p>
	 *
	 */
	public MCColumnConfig columnMethod_row_label = null;
	// [MethodOpt]ブロック関連のField定義
	public MCPanel MethodOptPanel = null;
	// [MethodOpt]ブロックの項目のField定義
	public MCTextField MethodOpt_rank_type = null;
	public MCLabel MethodOpt_rank_type_nm_Label = null;
	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public MCTextComboBox MethodOpt_rank_type_nm = null;
	public MCLabel MethodOpt_rank_size_Label = null;
	/**
	 *  有効順位.<p>
	 *
	 */
	public MCNumberField MethodOpt_rank_size = null;
	public MCLabel MethodOpt_fill_dt_fm_Label = null;
	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public MCTimestampField MethodOpt_fill_dt_fm = null;
	public MCLabel MethodOpt_fill_dt_to_Label = null;
	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public MCTimestampField MethodOpt_fill_dt_to = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, READ_ONLY};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0760_Srch01]のCallerの作成 */
	protected FSBAP_MiningDtl_FW.FS_FSBAL0760_Srch01Caller createFS_FSBAL0760_Srch01() {
		FSBAP_MiningDtl_FW.FS_FSBAL0760_Srch01Caller<FSBAP_MiningDtl, FS_FSBAL0760_Srch01Bridge>
		caller = ((FSBAP_MiningDtl_FW)this).new FS_FSBAL0760_Srch01Caller<FSBAP_MiningDtl, FS_FSBAL0760_Srch01Bridge>(
					(FSBAP_MiningDtl)this, new FS_FSBAL0760_Srch01Bridge());
		return caller;
	}
	/** [FS_FSBAL0760_Srch01]の呼び出し */
	protected void callFS_FSBAL0760_Srch01() {
		MCCaller caller = createFS_FSBAL0760_Srch01();
		caller.exec();
	}
	/** [FS_FSBAL0760_Upd01]のCallerの作成 */
	protected FSBAP_MiningDtl_FW.FS_FSBAL0760_Upd01Caller createFS_FSBAL0760_Upd01() {
		FSBAP_MiningDtl_FW.FS_FSBAL0760_Upd01Caller<FSBAP_MiningDtl, FS_FSBAL0760_Upd01Bridge>
		caller = ((FSBAP_MiningDtl_FW)this).new FS_FSBAL0760_Upd01Caller<FSBAP_MiningDtl, FS_FSBAL0760_Upd01Bridge>(
					(FSBAP_MiningDtl)this, new FS_FSBAL0760_Upd01Bridge());
		return caller;
	}
	/** [FS_FSBAL0760_Upd01]の呼び出し */
	protected void callFS_FSBAL0760_Upd01() {
		MCCaller caller = createFS_FSBAL0760_Upd01();
		caller.exec();
	}
	/** [FS_FSBAL0760_Ins01]のCallerの作成 */
	protected FSBAP_MiningDtl_FW.FS_FSBAL0760_Ins01Caller createFS_FSBAL0760_Ins01() {
		FSBAP_MiningDtl_FW.FS_FSBAL0760_Ins01Caller<FSBAP_MiningDtl, FS_FSBAL0760_Ins01Bridge>
		caller = ((FSBAP_MiningDtl_FW)this).new FS_FSBAL0760_Ins01Caller<FSBAP_MiningDtl, FS_FSBAL0760_Ins01Bridge>(
					(FSBAP_MiningDtl)this, new FS_FSBAL0760_Ins01Bridge());
		return caller;
	}
	/** [FS_FSBAL0760_Ins01]の呼び出し */
	protected void callFS_FSBAL0760_Ins01() {
		MCCaller caller = createFS_FSBAL0760_Ins01();
		caller.exec();
	}
	/** [FS_FSBAL0760_Ins02]のCallerの作成 */
	protected FSBAP_MiningDtl_FW.FS_FSBAL0760_Ins02Caller createFS_FSBAL0760_Ins02() {
		FSBAP_MiningDtl_FW.FS_FSBAL0760_Ins02Caller<FSBAP_MiningDtl, FS_FSBAL0760_Ins02Bridge>
		caller = ((FSBAP_MiningDtl_FW)this).new FS_FSBAL0760_Ins02Caller<FSBAP_MiningDtl, FS_FSBAL0760_Ins02Bridge>(
					(FSBAP_MiningDtl)this, new FS_FSBAL0760_Ins02Bridge());
		return caller;
	}
	/** [FS_FSBAL0760_Ins02]の呼び出し */
	protected void callFS_FSBAL0760_Ins02() {
		MCCaller caller = createFS_FSBAL0760_Ins02();
		caller.exec();
	}
	/** [Srch]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0780.SrchR aSrchR;
	/** [Mining]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0780.MiningR aMiningR;
	/** [Cond]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.CondR> aCondL;
	/** [Method]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.MethodR> aMethodL;
	/** [MethodOpt]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0780.MethodOptR aMethodOptR;
	/** [MiningParam]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.MiningR> aMiningParamL;
	/** [SumCondParam]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> aSumCondParamL;

	/**
	 * 項目コピーによってaSrchRを設定します。
	 *
	 * aSrchRのインスタンスは変更されません。
	 *
	 * @param row SrchR
	 */
	public void setSrchR(mcframe.clientFSBA.FSBAP0780.SrchR row) {
		if (row != null) {
			MCRow.copyall(getSrchR(), row);
		}
	}

	/**
	 * [Srch]ブロックのコンテナaSrchRを返します。
	 *
	 * @return SrchR
	 */
	public mcframe.clientFSBA.FSBAP0780.SrchR getSrchR() {
		return aSrchR;
	}

	/**
	 * aSrchRを作成します。
	 *
	 * @return SrchR
	 */
	public mcframe.clientFSBA.FSBAP0780.SrchR createSrchR() {
		return mcframe.clientFSBA.FSBAP0780.SrchR.create();
	}

	/**
	 * 項目コピーによってaMiningRを設定します。
	 *
	 * aMiningRのインスタンスは変更されません。
	 *
	 * @param row MiningR
	 */
	public void setMiningR(mcframe.clientFSBA.FSBAP0780.MiningR row) {
		if (row != null) {
			MCRow.copyall(getMiningR(), row);
		}
	}

	/**
	 * [Mining]ブロックのコンテナaMiningRを返します。
	 *
	 * @return MiningR
	 */
	public mcframe.clientFSBA.FSBAP0780.MiningR getMiningR() {
		return aMiningR;
	}

	/**
	 * aMiningRを作成します。
	 *
	 * @return MiningR
	 */
	public mcframe.clientFSBA.FSBAP0780.MiningR createMiningR() {
		return mcframe.clientFSBA.FSBAP0780.MiningR.create();
	}

	/**
	 * コピーによってaCondLを設定します。
	 *
	 * aCondLのインスタンスは変更されません。
	 *
	 * @param dataset CondL
	 */
	public void setCondL(MCList<mcframe.clientFSBA.FSBAP0780.CondR> aList) {
		if (getCondL() != aList) {
			getCondL().setAll(aList);
		}
	}

	/**
	 * [Cond]ブロックのコンテナaCondLを返します。
	 *
	 * @return CondL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.CondR> getCondL() {
		return aCondL;
	}

	/**
	 * aCondRを作成します。
	 *
	 * @return CondR
	 */
	public mcframe.clientFSBA.FSBAP0780.CondR createCondR() {
		return mcframe.clientFSBA.FSBAP0780.CondR.create();
	}

	/**
	 * aCondLを作成します。
	 *
	 * @return CondL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.CondR> createCondL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class);
	}

	/**
	 * CondTableを初期化します。
	 */
	protected void createCondTable(){
		if(CondTable == null){
			CondTable = beansFactory.createTable2("Cond.table");
		}
	}

	/**
	 * コピーによってaMethodLを設定します。
	 *
	 * aMethodLのインスタンスは変更されません。
	 *
	 * @param dataset MethodL
	 */
	public void setMethodL(MCList<mcframe.clientFSBA.FSBAP0780.MethodR> aList) {
		if (getMethodL() != aList) {
			getMethodL().setAll(aList);
		}
	}

	/**
	 * [Method]ブロックのコンテナaMethodLを返します。
	 *
	 * @return MethodL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MethodR> getMethodL() {
		return aMethodL;
	}

	/**
	 * aMethodRを作成します。
	 *
	 * @return MethodR
	 */
	public mcframe.clientFSBA.FSBAP0780.MethodR createMethodR() {
		return mcframe.clientFSBA.FSBAP0780.MethodR.create();
	}

	/**
	 * aMethodLを作成します。
	 *
	 * @return MethodL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MethodR> createMethodL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class);
	}

	/**
	 * MethodTableを初期化します。
	 */
	protected void createMethodTable(){
		if(MethodTable == null){
			MethodTable = beansFactory.createTable2("Method.table");
		}
	}

	/**
	 * 項目コピーによってaMethodOptRを設定します。
	 *
	 * aMethodOptRのインスタンスは変更されません。
	 *
	 * @param row MethodOptR
	 */
	public void setMethodOptR(mcframe.clientFSBA.FSBAP0780.MethodOptR row) {
		if (row != null) {
			MCRow.copyall(getMethodOptR(), row);
		}
	}

	/**
	 * [MethodOpt]ブロックのコンテナaMethodOptRを返します。
	 *
	 * @return MethodOptR
	 */
	public mcframe.clientFSBA.FSBAP0780.MethodOptR getMethodOptR() {
		return aMethodOptR;
	}

	/**
	 * aMethodOptRを作成します。
	 *
	 * @return MethodOptR
	 */
	public mcframe.clientFSBA.FSBAP0780.MethodOptR createMethodOptR() {
		return mcframe.clientFSBA.FSBAP0780.MethodOptR.create();
	}

	/**
	 * コピーによってaMiningParamLを設定します。
	 *
	 * aMiningParamLのインスタンスは変更されません。
	 *
	 * @param dataset MiningParamL
	 */
	public void setMiningParamL(MCList<mcframe.clientFSBA.FSBAP0780.MiningR> aList) {
		if (getMiningParamL() != aList) {
			getMiningParamL().setAll(aList);
		}
	}

	/**
	 * [MiningParam]ブロックのコンテナaMiningParamLを返します。
	 *
	 * @return MiningParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MiningR> getMiningParamL() {
		return aMiningParamL;
	}

	/**
	 * aMiningParamRを作成します。
	 *
	 * @return MiningParamR
	 */
	public mcframe.clientFSBA.FSBAP0780.MiningR createMiningParamR() {
		return mcframe.clientFSBA.FSBAP0780.MiningR.create();
	}

	/**
	 * aMiningParamLを作成します。
	 *
	 * @return MiningParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MiningR> createMiningParamL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class);
	}

	/**
	 * コピーによってaSumCondParamLを設定します。
	 *
	 * aSumCondParamLのインスタンスは変更されません。
	 *
	 * @param dataset SumCondParamL
	 */
	public void setSumCondParamL(MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> aList) {
		if (getSumCondParamL() != aList) {
			getSumCondParamL().setAll(aList);
		}
	}

	/**
	 * [SumCondParam]ブロックのコンテナaSumCondParamLを返します。
	 *
	 * @return SumCondParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> getSumCondParamL() {
		return aSumCondParamL;
	}

	/**
	 * aSumCondParamRを作成します。
	 *
	 * @return SumCondParamR
	 */
	public mcframe.clientFSBA.FSBAP0780.SumCondParamR createSumCondParamR() {
		return mcframe.clientFSBA.FSBAP0780.SumCondParamR.create();
	}

	/**
	 * aSumCondParamLを作成します。
	 *
	 * @return SumCondParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> createSumCondParamL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getSrchR())) ret.add(getSrchR());
		if(!MCCollectionUtil.contains(ret, getMiningR())) ret.add(getMiningR());
		if(!MCCollectionUtil.contains(ret, getCondL())) ret.add(getCondL());
		if(!MCCollectionUtil.contains(ret, getMethodL())) ret.add(getMethodL());
		if(!MCCollectionUtil.contains(ret, getMethodOptR())) ret.add(getMethodOptR());
		if(!MCCollectionUtil.contains(ret, getMiningParamL())) ret.add(getMiningParamL());
		if(!MCCollectionUtil.contains(ret, getSumCondParamL())) ret.add(getSumCondParamL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getSrchR()) return "Srch";
		if(aCnt == getMiningR()) return "Mining";
		if(aCnt == getCondL()) return "Cond";
		if(aCnt == getMethodL()) return "Method";
		if(aCnt == getMethodOptR()) return "MethodOpt";
		if(aCnt == getMiningParamL()) return "MiningParam";
		if(aCnt == getSumCondParamL()) return "SumCondParam";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Srch")) return getSrchR();
		if(bId.equals("Mining")) return getMiningR();
		if(bId.equals("Cond")) return getCondL();
		if(bId.equals("Method")) return getMethodL();
		if(bId.equals("MethodOpt")) return getMethodOptR();
		if(bId.equals("MiningParam")) return getMiningParamL();
		if(bId.equals("SumCondParam")) return getSumCondParamL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(MiningPanel);
		ret.add(GadgetPanel);
		ret.add(MiningDescPanel);
		ret.add(CondPanel);
		ret.add(MethodPanel);
		ret.add(MethodOptPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningDtl_FW_A() {
		aSrchR = createSrchR();
		aMiningR = createMiningR();
		aCondL = createCondL();
		aMethodL = createMethodL();
		aMethodOptR = createMethodOptR();
		aMiningParamL = createMiningParamL();
		aSumCondParamL = createSumCondParamL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningDtl_FW_A(String name) {
		aSrchR = createSrchR();
		aMiningR = createMiningR();
		aCondL = createCondL();
		createCondTable();
		CondTable.setRowName(name);
		aMethodL = createMethodL();
		createMethodTable();
		MethodTable.setRowName(name);
		aMethodOptR = createMethodOptR();
		aMiningParamL = createMiningParamL();
		aSumCondParamL = createSumCondParamL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_MiningDtl_FW.jbCreateMining((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbCreateGadget((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbCreateMiningDesc((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbCreateCond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbCreateMethod((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbCreateMethodOpt((FSBAP_MiningDtl)this);
	}

	/**
	 * [Mining]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMining(FSBAP_MiningDtl p) {
	}

	/**
	 * [Gadget]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateGadget(FSBAP_MiningDtl p) {
	}

	/**
	 * [MiningDesc]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMiningDesc(FSBAP_MiningDtl p) {
	}

	/**
	 * [Cond]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCond(FSBAP_MiningDtl p) {
	}

	/**
	 * [Method]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMethod(FSBAP_MiningDtl p) {
		p.Method_chart_color_p_PPanel = mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.create(mcframe.clientFSBA.FSBAP0780.MethodR.$chart_color_p);
		p.Method_chart_color_p_PPanel.setName("Method.chart_color_p");
		p.columnMethod_red = p.Method_chart_color_p_PPanel.columnColor_red;
		p.columnMethod_red.addAliasName("Method.red", p);
		p.columnMethod_green = p.Method_chart_color_p_PPanel.columnColor_green;
		p.columnMethod_green.addAliasName("Method.green", p);
		p.columnMethod_blue = p.Method_chart_color_p_PPanel.columnColor_blue;
		p.columnMethod_blue.addAliasName("Method.blue", p);
		p.columnMethod_color = p.Method_chart_color_p_PPanel.columnColor_color;
		p.columnMethod_color.addAliasName("Method.color", p);
	}

	/**
	 * [MethodOpt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMethodOpt(FSBAP_MiningDtl p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Method_sum_info_type_nm_ListPutter]の定義 */
	private MCListPutter Method_sum_info_type_nm_p = null;

	/**
	 * [Method_sum_info_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getMethod_sum_info_type_nm_ListPutter() {
		if (Method_sum_info_type_nm_p == null) {
			Method_sum_info_type_nm_p = createMethod_sum_info_type_nm_ListPutter(columnMethod_sum_info_type_nm, "sum_info_type_nm", "sum_info_type");

		}
		return Method_sum_info_type_nm_p;
	}
	
	
	/** [Method_column_nm_ListPutter]の定義 */
	private MCListPutter Method_column_nm_p = null;

	/**
	 * [Method_column_nm_ListPutter]の取得
	 */
	protected MCListPutter getMethod_column_nm_ListPutter() {
		if (Method_column_nm_p == null) {
			Method_column_nm_p = createMethod_column_nm_ListPutter(columnMethod_column_nm, "column_nm", "column_key");

		}
		return Method_column_nm_p;
	}
	
	
	/** [Method_date_fmt_ListPutter]の定義 */
	private MCListPutter Method_date_fmt_p = null;

	/**
	 * [Method_date_fmt_ListPutter]の取得
	 */
	protected MCListPutter getMethod_date_fmt_ListPutter() {
		if (Method_date_fmt_p == null) {
			Method_date_fmt_p = createMethod_date_fmt_ListPutter(columnMethod_date_fmt, "date_fmt");

		}
		return Method_date_fmt_p;
	}
	
	
	/** [Method_rounding_mode_type_nm_ListPutter]の定義 */
	private MCListPutter Method_rounding_mode_type_nm_p = null;

	/**
	 * [Method_rounding_mode_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getMethod_rounding_mode_type_nm_ListPutter() {
		if (Method_rounding_mode_type_nm_p == null) {
			Method_rounding_mode_type_nm_p = createMethod_rounding_mode_type_nm_ListPutter(columnMethod_rounding_mode_type_nm, "rounding_mode_type_nm", "rounding_mode_type");

		}
		return Method_rounding_mode_type_nm_p;
	}
	
	
	/** [Method_sort_type_ListPutter]の定義 */
	private MCListPutter Method_sort_type_p = null;

	/**
	 * [Method_sort_type_ListPutter]の取得
	 */
	protected MCListPutter getMethod_sort_type_ListPutter() {
		if (Method_sort_type_p == null) {
			Method_sort_type_p = createMethod_sort_type_ListPutter(columnMethod_sort_type, "sort_type", "sort_type_nm");

		}
		return Method_sort_type_p;
	}
	
	
	/** [Method_chart_type_nm_ListPutter]の定義 */
	private MCListPutter Method_chart_type_nm_p = null;

	/**
	 * [Method_chart_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getMethod_chart_type_nm_ListPutter() {
		if (Method_chart_type_nm_p == null) {
			Method_chart_type_nm_p = createMethod_chart_type_nm_ListPutter(columnMethod_chart_type_nm, "chart_type_nm", "chart_type");

		}
		return Method_chart_type_nm_p;
	}
	
	
	/** [MethodOpt_rank_type_nm_ListPutter]の定義 */
	private MCListPutter MethodOpt_rank_type_nm_p = null;

	/**
	 * [MethodOpt_rank_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getMethodOpt_rank_type_nm_ListPutter() {
		if (MethodOpt_rank_type_nm_p == null) {
			MethodOpt_rank_type_nm_p = createMethodOpt_rank_type_nm_ListPutter(MethodOpt_rank_type_nm, "rank_type_nm", "rank_type");

		}
		return MethodOpt_rank_type_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningDtl create(){
		FSBAP_MiningDtl p = new FSBAP_MiningDtl();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningDtl create(String name){
		FSBAP_MiningDtl p = new FSBAP_MiningDtl(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_MiningDtl_FW.jbfInitMining((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbfInitGadget((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbfInitMiningDesc((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbfInitCond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbfInitMethod((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbfInitMethodOpt((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbInitMining((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbInitGadget((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbInitMiningDesc((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbInitCond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbInitMethod((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.jbInitMethodOpt((FSBAP_MiningDtl)this);
	}

	/**
	 * [Mining]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMining(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.MiningPanel = p.beansFactory.createPanel("Mining");
		// ブロックの項目の初期化
		p.Mining_mining_nm_Label = p.beansFactory.createLabel("Mining.mining_nm_Label");
		p.Mining_mining_nm = p.beansFactory.createTextField("Mining.mining_nm");
		p.Mining_mining_nm.setLabel(p.Mining_mining_nm_Label);
		p.Mining_description_text_Label = p.beansFactory.createLabel("Mining.description_text_Label");
		p.Mining_description_textScrollPane = p.beansFactory.createScrollPane("Mining.description_textscroll");
		p.Mining_description_text = p.beansFactory.createTextArea("Mining.description_text");
		p.Mining_description_text.setLabel(p.Mining_description_text_Label);
		p.Mining_operation_Label = p.beansFactory.createLabel("Mining.operation_Label");
		p.Mining_operation = p.beansFactory.createTextField("Mining.operation");
		p.Mining_operation.setLabel(p.Mining_operation_Label);
		p.Mining_operation_nm = p.beansFactory.createTextField("Mining.operation_nm");
		p.Mining_function_Label = p.beansFactory.createLabel("Mining.function_Label");
		p.Mining_function = p.beansFactory.createTextField("Mining.function");
		p.Mining_function.setLabel(p.Mining_function_Label);
		p.Mining_func_typ_Label = p.beansFactory.createLabel("Mining.func_typ_Label");
		p.Mining_func_typ = p.beansFactory.createTextField("Mining.func_typ");
		p.Mining_func_typ.setLabel(p.Mining_func_typ_Label);
		p.Mining_screen_Label = p.beansFactory.createLabel("Mining.screen_Label");
		p.Mining_screen = p.beansFactory.createTextField("Mining.screen");
		p.Mining_screen.setLabel(p.Mining_screen_Label);
		p.Mining_screen_nm = p.beansFactory.createTextField("Mining.screen_nm");
		p.Mining_md_module_id_Label = p.beansFactory.createLabel("Mining.md_module_id_Label");
		p.Mining_md_module_id = p.beansFactory.createTextField("Mining.md_module_id");
		p.Mining_md_module_id.setLabel(p.Mining_md_module_id_Label);
		p.Mining_md_screen_id = p.beansFactory.createTextField("Mining.md_screen_id");
		p.Mining_gadget_icon_Label = p.beansFactory.createLabel("Mining.gadget_icon_Label");
		p.Mining_gadget_icon = p.beansFactory.createImageView("Mining.gadget_icon");
		p.Mining_gadget_icon.setLabel(p.Mining_gadget_icon_Label);
		p.Mining_gadget_w_Label = p.beansFactory.createLabel("Mining.gadget_w_Label");
		p.Mining_gadget_w = p.beansFactory.createNumberField("Mining.gadget_w");
		p.Mining_gadget_w.setLabel(p.Mining_gadget_w_Label);
		p.Mining_gadget_h_Label = p.beansFactory.createLabel("Mining.gadget_h_Label");
		p.Mining_gadget_h = p.beansFactory.createNumberField("Mining.gadget_h");
		p.Mining_gadget_h.setLabel(p.Mining_gadget_h_Label);
		p.Mining_gadget_cache_flg = p.beansFactory.createCheckBox("Mining.gadget_cache_flg");
	}

	/**
	 * [Gadget]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitGadget(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.GadgetPanel = p.beansFactory.createPanel("Gadget");
		p.GadgetTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [MiningDesc]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMiningDesc(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.MiningDescPanel = p.beansFactory.createPanel("MiningDesc");
		// ブロックの項目の初期化
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCond(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.CondPanel = p.beansFactory.createPanel("Cond");
		p.CondTitledBorder = p.beansFactory.createTitledBorder();
		p.CondScrollPane = p.beansFactory.createScrollPane("Cond.scroll");
		p.createCondTable();
		// ブロックの項目の初期化
		p.columnCond_col_nm = p.beansFactory.createTableColumn("Cond.col_nm", MCColumnType.TEXT);
		p.columnCond_editable_flg = p.beansFactory.createTableColumn("Cond.editable_flg", MCColumnType.CHECK);
		p.columnCond_require_flg = p.beansFactory.createTableColumn("Cond.require_flg", MCColumnType.CHECK);
		p.columnCond_text = p.beansFactory.createTableColumn("Cond.text", MCColumnType.TEXT);
		p.columnCond_num = p.beansFactory.createTableColumn("Cond.num", MCColumnType.NUMBER);
		p.columnCond_check = p.beansFactory.createTableColumn("Cond.check", MCColumnType.CHECK);
		p.columnCond_date = p.beansFactory.createTableColumn("Cond.date", MCColumnType.TIMESTAMP);
	}

	/**
	 * [Method]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMethod(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.MethodPanel = p.beansFactory.createPanel("Method");
		p.MethodTitledBorder = p.beansFactory.createTitledBorder();
		p.MethodScrollPane = p.beansFactory.createScrollPane("Method.scroll");
		p.createMethodTable();
		// ブロックの項目の初期化
		p.columnMethod_disable = p.beansFactory.createTableColumn("Method.disable", MCColumnType.CHECK);
		p.columnMethod_sum_info_type = p.beansFactory.createTableColumn("Method.sum_info_type", MCColumnType.TEXT);
		p.columnMethod_sum_info_type_nm = p.beansFactory.createTableColumn("Method.sum_info_type_nm", MCColumnType.TEXT_COMBO);
		p.columnMethod_column_nm = p.beansFactory.createTableColumn("Method.column_nm", MCColumnType.TEXT_COMBO);
		p.columnMethod_column_key = p.beansFactory.createTableColumn("Method.column_key", MCColumnType.TEXT);
		p.columnMethod_sumcond = p.beansFactory.createTableColumn("Method.sumcond", MCColumnType.TEXT);
		p.columnMethod_rank = p.beansFactory.createTableColumn("Method.rank", MCColumnType.CHECK);
		p.columnMethod_fill_dt = p.beansFactory.createTableColumn("Method.fill_dt", MCColumnType.CHECK);
		p.columnMethod_date_fmt = p.beansFactory.createTableColumn("Method.date_fmt", MCColumnType.TEXT_COMBO);
		p.columnMethod_formula = p.beansFactory.createTableColumn("Method.formula", MCColumnType.TEXT);
		p.columnMethod_dec_place = p.beansFactory.createTableColumn("Method.dec_place", MCColumnType.NUMBER);
		p.columnMethod_rounding_mode_type = p.beansFactory.createTableColumn("Method.rounding_mode_type", MCColumnType.TEXT);
		p.columnMethod_rounding_mode_type_nm = p.beansFactory.createTableColumn("Method.rounding_mode_type_nm", MCColumnType.TEXT_COMBO);
		p.columnMethod_null_zero = p.beansFactory.createTableColumn("Method.null_zero", MCColumnType.CHECK);
		p.columnMethod_sort_order = p.beansFactory.createTableColumn("Method.sort_order", MCColumnType.NUMBER);
		p.columnMethod_sort_type = p.beansFactory.createTableColumn("Method.sort_type", MCColumnType.TEXT_COMBO);
		p.columnMethod_sort_type_nm = p.beansFactory.createTableColumn("Method.sort_type_nm", MCColumnType.TEXT);
		p.columnMethod_chart_type = p.beansFactory.createTableColumn("Method.chart_type", MCColumnType.NUMBER);
		p.columnMethod_chart_type_nm = p.beansFactory.createTableColumn("Method.chart_type_nm", MCColumnType.TEXT_COMBO);
		p.columnMethod_chart_color = p.beansFactory.createTableColumn("Method.chart_color", MCColumnType.TEXT);
		p.columnMethod_row_label = p.beansFactory.createTableColumn("Method.row_label", MCColumnType.CHECK);
	}

	/**
	 * [MethodOpt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMethodOpt(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.MethodOptPanel = p.beansFactory.createPanel("MethodOpt");
		// ブロックの項目の初期化
		p.MethodOpt_rank_type = p.beansFactory.createTextField("MethodOpt.rank_type");
		p.MethodOpt_rank_type_nm_Label = p.beansFactory.createLabel("MethodOpt.rank_type_nm_Label");
		p.MethodOpt_rank_type_nm = p.beansFactory.createTextComboBox("MethodOpt.rank_type_nm");
		p.MethodOpt_rank_type_nm.setLabel(p.MethodOpt_rank_type_nm_Label);
		p.MethodOpt_rank_size_Label = p.beansFactory.createLabel("MethodOpt.rank_size_Label");
		p.MethodOpt_rank_size = p.beansFactory.createNumberField("MethodOpt.rank_size");
		p.MethodOpt_rank_size.setLabel(p.MethodOpt_rank_size_Label);
		p.MethodOpt_fill_dt_fm_Label = p.beansFactory.createLabel("MethodOpt.fill_dt_fm_Label");
		p.MethodOpt_fill_dt_fm = p.beansFactory.createTimestampField("MethodOpt.fill_dt_fm");
		p.MethodOpt_fill_dt_fm.setLabel(p.MethodOpt_fill_dt_fm_Label);
		p.MethodOpt_fill_dt_to_Label = p.beansFactory.createLabel("MethodOpt.fill_dt_to_Label");
		p.MethodOpt_fill_dt_to = p.beansFactory.createTimestampField("MethodOpt.fill_dt_to");
		p.MethodOpt_fill_dt_to.setLabel(p.MethodOpt_fill_dt_to_Label);
	}

	/**
	 * [Mining]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMining(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.add(p.MiningPanel);
		p.setLastBeans(p.MiningPanel);
		p.MiningPanel.setNextBeans(p.GadgetPanel);
		p.MiningPanel.setLayoutPosition("NWN");
		// ブロックの項目の初期化
		p.MiningPanel.add(p.Mining_mining_nm_Label);
		p.MiningPanel.add(p.Mining_mining_nm);
		p.MiningPanel.setLastBeans(p.Mining_mining_nm);
		p.Mining_mining_nm.setNextBeans(p.Mining_operation);
		p.Mining_mining_nm.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.mining_nm_META);
		p.MiningDescPanel.add(p.Mining_description_text_Label);
		p.Mining_description_textScrollPane.getViewport().add(p.Mining_description_text);
		p.MiningDescPanel.add(p.Mining_description_textScrollPane);
		p.MiningDescPanel.setLastBeans(p.Mining_description_text);
		p.Mining_description_text.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.description_text_META);
		p.MiningPanel.add(p.Mining_operation_Label);
		p.MiningPanel.add(p.Mining_operation);
		p.Mining_operation.setNextBeans(p.Mining_operation_nm);
		p.Mining_operation.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.operation_META);
		p.MiningPanel.add(p.Mining_operation_nm);
		p.Mining_operation_nm.setNextBeans(p.Mining_function);
		p.Mining_operation_nm.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.operation_nm_META);
		p.MiningPanel.add(p.Mining_function_Label);
		p.MiningPanel.add(p.Mining_function);
		p.Mining_function.setNextBeans(p.Mining_func_typ);
		p.Mining_function.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.function_META);
		p.MiningPanel.add(p.Mining_func_typ_Label);
		p.MiningPanel.add(p.Mining_func_typ);
		p.Mining_func_typ.setNextBeans(p.Mining_screen);
		p.Mining_func_typ.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.func_typ_META);
		p.MiningPanel.add(p.Mining_screen_Label);
		p.MiningPanel.add(p.Mining_screen);
		p.Mining_screen.setNextBeans(p.Mining_screen_nm);
		p.Mining_screen.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.screen_META);
		p.MiningPanel.add(p.Mining_screen_nm);
		p.Mining_screen_nm.setNextBeans(p.Mining_md_module_id);
		p.Mining_screen_nm.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.screen_nm_META);
		p.MiningPanel.add(p.Mining_md_module_id_Label);
		p.MiningPanel.add(p.Mining_md_module_id);
		p.Mining_md_module_id.setNextBeans(p.Mining_md_screen_id);
		p.Mining_md_module_id.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.md_module_id_META);
		p.MiningPanel.add(p.Mining_md_screen_id);
		p.Mining_md_screen_id.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.md_screen_id_META);
		p.GadgetPanel.add(p.Mining_gadget_icon_Label);
		p.GadgetPanel.add(p.Mining_gadget_icon);
		p.GadgetPanel.setLastBeans(p.Mining_gadget_icon);
		p.Mining_gadget_icon.setNextBeans(p.Mining_gadget_w);
		p.Mining_gadget_icon.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.gadget_icon_META);
		p.GadgetPanel.add(p.Mining_gadget_w_Label);
		p.GadgetPanel.add(p.Mining_gadget_w);
		p.Mining_gadget_w.setNextBeans(p.Mining_gadget_h);
		p.Mining_gadget_w.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.gadget_w_META);
		p.GadgetPanel.add(p.Mining_gadget_h_Label);
		p.GadgetPanel.add(p.Mining_gadget_h);
		p.Mining_gadget_h.setNextBeans(p.Mining_gadget_cache_flg);
		p.Mining_gadget_h.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.gadget_h_META);
		p.GadgetPanel.add(p.Mining_gadget_cache_flg);
		p.Mining_gadget_cache_flg.setRow(p.getMiningR(), mcframe.clientFSBA.FSBAP0780.MiningR.gadget_cache_flg_META);
	}

	/**
	 * [Gadget]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitGadget(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.GadgetPanel.setBorder(p.GadgetTitledBorder);
		p.add(p.GadgetPanel);
		p.GadgetPanel.setNextBeans(p.MiningDescPanel);
		p.GadgetPanel.setLayoutPosition("NWS");
		// ブロックの項目の初期化
	}

	/**
	 * [MiningDesc]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMiningDesc(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.add(p.MiningDescPanel);
		p.MiningDescPanel.setNextBeans(p.CondPanel);
		p.MiningDescPanel.setLayoutPosition("NC");
		// ブロックの項目の初期化
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCond(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.CondPanel.setBorder(p.CondTitledBorder);
		p.add(p.CondPanel);
		p.CondPanel.setNextBeans(p.MethodPanel);
		p.CondPanel.add(p.CondScrollPane);
		p.CondPanel.setLastBeans(p.CondTable);
		p.CondScrollPane.setViewportView(p.CondTable);
		p.CondTable.setList(p.getCondL());
		p.CondPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [Method]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMethod(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.MethodPanel.setBorder(p.MethodTitledBorder);
		p.add(p.MethodPanel);
		p.MethodPanel.setNextBeans(p.MethodOptPanel);
		p.MethodPanel.add(p.MethodScrollPane);
		p.MethodPanel.setLastBeans(p.MethodTable);
		p.MethodScrollPane.setViewportView(p.MethodTable);
		p.MethodTable.setList(p.getMethodL());
		p.MethodPanel.setLayoutPosition("CBC");
		// ブロックの項目の初期化
	}

	/**
	 * [MethodOpt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMethodOpt(FSBAP_MiningDtl p) {
		// ブロック関連の初期化
		p.add(p.MethodOptPanel);
		p.MethodOptPanel.setLayoutPosition("CBS");
		// ブロックの項目の初期化
		p.MethodOptPanel.add(p.MethodOpt_rank_type);
		p.MethodOptPanel.setLastBeans(p.MethodOpt_rank_type);
		p.MethodOpt_rank_type.setNextBeans(p.MethodOpt_rank_type_nm);
		p.MethodOpt_rank_type.setRow(p.getMethodOptR(), mcframe.clientFSBA.FSBAP0780.MethodOptR.rank_type_META);
		p.MethodOpt_rank_type_nm.setListType(MCListType.STRICT);
		p.MethodOpt_rank_type_nm.setLinkBeans(p.MethodOpt_rank_type);
		p.MethodOptPanel.add(p.MethodOpt_rank_type_nm_Label);
		p.MethodOptPanel.add(p.MethodOpt_rank_type_nm);
		p.MethodOpt_rank_type_nm.setNextBeans(p.MethodOpt_rank_size);
		p.MethodOpt_rank_type_nm.setRow(p.getMethodOptR(), mcframe.clientFSBA.FSBAP0780.MethodOptR.rank_type_nm_META);
		p.MethodOptPanel.add(p.MethodOpt_rank_size_Label);
		p.MethodOptPanel.add(p.MethodOpt_rank_size);
		p.MethodOpt_rank_size.setNextBeans(p.MethodOpt_fill_dt_fm);
		p.MethodOpt_rank_size.setRow(p.getMethodOptR(), mcframe.clientFSBA.FSBAP0780.MethodOptR.rank_size_META);
		p.MethodOptPanel.add(p.MethodOpt_fill_dt_fm_Label);
		p.MethodOptPanel.add(p.MethodOpt_fill_dt_fm);
		p.MethodOpt_fill_dt_fm.setNextBeans(p.MethodOpt_fill_dt_to);
		p.MethodOpt_fill_dt_fm.setRow(p.getMethodOptR(), mcframe.clientFSBA.FSBAP0780.MethodOptR.fill_dt_fm_META);
		p.MethodOpt_fill_dt_fm.setFormatID("YMDHMSS");
		p.MethodOptPanel.add(p.MethodOpt_fill_dt_to_Label);
		p.MethodOptPanel.add(p.MethodOpt_fill_dt_to);
		p.MethodOpt_fill_dt_to.setRow(p.getMethodOptR(), mcframe.clientFSBA.FSBAP0780.MethodOptR.fill_dt_to_META);
		p.MethodOpt_fill_dt_to.setFormatID("YMDHMSS");
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_MiningDtl_FW.mcInitMining((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.mcInitGadget((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.mcInitMiningDesc((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.mcInitCond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.mcInitMethod((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.mcInitMethodOpt((FSBAP_MiningDtl)this);

		// [ENABLE]ステータスのモードの設定
		FSBAP_MiningDtl_FW.statusInitENABLE_Srch((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_Mining((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_Gadget((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_MiningDesc((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_Cond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_Method((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_MethodOpt((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_MiningParam((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitENABLE_SumCondParam((FSBAP_MiningDtl)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_Srch((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_Mining((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_Gadget((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_MiningDesc((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_Cond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_Method((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_MethodOpt((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_MiningParam((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.statusInitREAD__ONLY_SumCondParam((FSBAP_MiningDtl)this);

	}

	/**
	 *  [Mining]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMining(FSBAP_MiningDtl p) {
		p.Mining_mining_nm.setListListener(p);
		p.Mining_mining_nm.addAllListener(p);
		p.Mining_description_text.addAllListener(p);
		p.Mining_operation.setListListener(p);
		p.Mining_operation.addAllListener(p);
		p.Mining_operation_nm.setListListener(p);
		p.Mining_operation_nm.addAllListener(p);
		p.Mining_function.setListListener(p);
		p.Mining_function.addAllListener(p);
		p.Mining_func_typ.setListListener(p);
		p.Mining_func_typ.addAllListener(p);
		p.Mining_screen.setListListener(p);
		p.Mining_screen.addAllListener(p);
		p.Mining_screen_nm.setListListener(p);
		p.Mining_screen_nm.addAllListener(p);
		p.Mining_md_module_id.setListListener(p);
		p.Mining_md_module_id.addAllListener(p);
		p.Mining_md_screen_id.setListListener(p);
		p.Mining_md_screen_id.addAllListener(p);
		p.Mining_gadget_icon.addAllListener(p);
		p.Mining_gadget_w.setListListener(p);
		p.Mining_gadget_w.addAllListener(p);
		p.Mining_gadget_h.setListListener(p);
		p.Mining_gadget_h.addAllListener(p);
		p.Mining_gadget_cache_flg.addAllListener(p);
	}

	/**
	 *  [Gadget]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitGadget(FSBAP_MiningDtl p) {
	}

	/**
	 *  [MiningDesc]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMiningDesc(FSBAP_MiningDtl p) {
	}

	/**
	 *  [Cond]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCond(FSBAP_MiningDtl p) {
		p.CondTable.addAllListener(p);
		p.columnCond_col_nm.addAllListener(p);
		p.columnCond_col_nm.setListListener(p);
		p.columnCond_editable_flg.addAllListener(p);
		p.columnCond_require_flg.addAllListener(p);
		p.columnCond_text.addAllListener(p);
		p.columnCond_text.setListListener(p);
		p.columnCond_num.addAllListener(p);
		p.columnCond_num.setListListener(p);
		p.columnCond_check.addAllListener(p);
		p.columnCond_date.addAllListener(p);
		p.columnCond_date.setListListener(p);
	}

	/**
	 *  [Method]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMethod(FSBAP_MiningDtl p) {
		p.MethodTable.addAllListener(p);
		p.columnMethod_disable.addAllListener(p);
		p.columnMethod_sum_info_type.addAllListener(p);
		p.columnMethod_sum_info_type.setListListener(p);
		p.columnMethod_sum_info_type_nm.addAllListener(p);
		p.columnMethod_sum_info_type_nm.setListListener(p);
		p.columnMethod_column_nm.addAllListener(p);
		p.columnMethod_column_nm.setListListener(p);
		p.columnMethod_column_key.addAllListener(p);
		p.columnMethod_column_key.setListListener(p);
		p.columnMethod_sumcond.addAllListener(p);
		p.columnMethod_sumcond.setListListener(p);
		p.columnMethod_rank.addAllListener(p);
		p.columnMethod_fill_dt.addAllListener(p);
		p.columnMethod_date_fmt.addAllListener(p);
		p.columnMethod_date_fmt.setListListener(p);
		p.columnMethod_formula.addAllListener(p);
		p.columnMethod_formula.setListListener(p);
		p.columnMethod_dec_place.addAllListener(p);
		p.columnMethod_dec_place.setListListener(p);
		p.columnMethod_rounding_mode_type.addAllListener(p);
		p.columnMethod_rounding_mode_type.setListListener(p);
		p.columnMethod_rounding_mode_type_nm.addAllListener(p);
		p.columnMethod_rounding_mode_type_nm.setListListener(p);
		p.columnMethod_null_zero.addAllListener(p);
		p.columnMethod_sort_order.addAllListener(p);
		p.columnMethod_sort_order.setListListener(p);
		p.columnMethod_sort_type.addAllListener(p);
		p.columnMethod_sort_type.setListListener(p);
		p.columnMethod_sort_type_nm.addAllListener(p);
		p.columnMethod_sort_type_nm.setListListener(p);
		p.columnMethod_chart_type.addAllListener(p);
		p.columnMethod_chart_type.setListListener(p);
		p.columnMethod_chart_type_nm.addAllListener(p);
		p.columnMethod_chart_type_nm.setListListener(p);
		p.columnMethod_chart_color.addAllListener(p);
		p.columnMethod_chart_color.setListListener(p);
		p.columnMethod_row_label.addAllListener(p);
	}

	/**
	 *  [MethodOpt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMethodOpt(FSBAP_MiningDtl p) {
		p.MethodOpt_rank_type.setListListener(p);
		p.MethodOpt_rank_type.addAllListener(p);
		p.MethodOpt_rank_type_nm.setListListener(p);
		p.MethodOpt_rank_type_nm.addAllListener(p);
		p.MethodOpt_rank_size.setListListener(p);
		p.MethodOpt_rank_size.addAllListener(p);
		p.MethodOpt_fill_dt_fm.setListListener(p);
		p.MethodOpt_fill_dt_fm.addAllListener(p);
		p.MethodOpt_fill_dt_to.setListListener(p);
		p.MethodOpt_fill_dt_to.addAllListener(p);
	}

	/**
	 * [ENABLE]ステータスの[Srch]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Srch(FSBAP_MiningDtl p){

	}

	/**
	 * [ENABLE]ステータスの[Mining]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Mining(FSBAP_MiningDtl p){
		p.Mining_mining_nm.putMode(p, ENABLE, MCMode.REQUIRED);
		p.Mining_description_text.putMode(p, ENABLE, MCMode.ENABLE);
		p.Mining_operation.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Mining_operation_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Mining_function.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Mining_func_typ.putMode(p, ENABLE, MCMode.ENABLE);
		p.Mining_screen.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Mining_screen_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Mining_md_module_id.putMode(p, ENABLE, MCMode.ENABLE);
		p.Mining_md_screen_id.putMode(p, ENABLE, MCMode.ENABLE);
		p.Mining_gadget_icon.putMode(p, ENABLE, MCMode.ENABLE);
		p.Mining_gadget_w.putMode(p, ENABLE, MCMode.REQUIRED);
		p.Mining_gadget_h.putMode(p, ENABLE, MCMode.REQUIRED);
		p.Mining_gadget_cache_flg.putMode(p, ENABLE, MCMode.REQUIRED);

	}

	/**
	 * [ENABLE]ステータスの[Gadget]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Gadget(FSBAP_MiningDtl p){

	}

	/**
	 * [ENABLE]ステータスの[MiningDesc]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_MiningDesc(FSBAP_MiningDtl p){

	}

	/**
	 * [ENABLE]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Cond(FSBAP_MiningDtl p){
		p.columnCond_col_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnCond_editable_flg.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnCond_require_flg.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnCond_text.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnCond_num.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnCond_check.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnCond_date.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[Method]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Method(FSBAP_MiningDtl p){
		p.columnMethod_disable.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_sum_info_type.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.columnMethod_sum_info_type_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnMethod_column_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnMethod_column_key.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnMethod_sumcond.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_rank.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_fill_dt.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_date_fmt.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_formula.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnMethod_dec_place.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_rounding_mode_type.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.columnMethod_rounding_mode_type_nm.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_null_zero.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnMethod_sort_order.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnMethod_sort_type.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnMethod_sort_type_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnMethod_chart_type.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.columnMethod_chart_type_nm.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnMethod_chart_color.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.Method_chart_color_p_PPanel.putStatus(ENABLE, mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.ENABLE);
		p.Method_chart_color_p_PPanel.columnColor_red.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.Method_chart_color_p_PPanel.columnColor_green.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.Method_chart_color_p_PPanel.columnColor_blue.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.columnMethod_row_label.putMode(p, ENABLE, MCMode.REQUIRED);

	}

	/**
	 * [ENABLE]ステータスの[MethodOpt]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_MethodOpt(FSBAP_MiningDtl p){
		p.MethodOpt_rank_type.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.MethodOpt_rank_type_nm.putMode(p, ENABLE, MCMode.ENABLE);
		p.MethodOpt_rank_size.putMode(p, ENABLE, MCMode.ENABLE);
		p.MethodOpt_fill_dt_fm.putMode(p, ENABLE, MCMode.ENABLE);
		p.MethodOpt_fill_dt_to.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[MiningParam]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_MiningParam(FSBAP_MiningDtl p){

	}

	/**
	 * [ENABLE]ステータスの[SumCondParam]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_SumCondParam(FSBAP_MiningDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Srch]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Srch(FSBAP_MiningDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Mining]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Mining(FSBAP_MiningDtl p){
		p.Mining_mining_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_description_text.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_operation.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_operation_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_function.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_func_typ.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_screen.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_screen_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_md_module_id.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_md_screen_id.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_gadget_icon.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_gadget_w.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_gadget_h.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Mining_gadget_cache_flg.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[Gadget]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Gadget(FSBAP_MiningDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[MiningDesc]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MiningDesc(FSBAP_MiningDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Cond(FSBAP_MiningDtl p){
		p.columnCond_col_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnCond_editable_flg.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnCond_require_flg.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnCond_text.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnCond_num.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnCond_check.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnCond_date.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[Method]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Method(FSBAP_MiningDtl p){
		p.columnMethod_disable.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_sum_info_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.columnMethod_sum_info_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_column_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_column_key.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_sumcond.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_rank.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_fill_dt.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_date_fmt.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_formula.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_dec_place.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_rounding_mode_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.columnMethod_rounding_mode_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_null_zero.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_sort_order.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_sort_type.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_sort_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_chart_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.columnMethod_chart_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnMethod_chart_color.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Method_chart_color_p_PPanel.putStatus(READ_ONLY, mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.READ_ONLY);
		p.Method_chart_color_p_PPanel.columnColor_red.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Method_chart_color_p_PPanel.columnColor_green.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Method_chart_color_p_PPanel.columnColor_blue.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.columnMethod_row_label.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[MethodOpt]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MethodOpt(FSBAP_MiningDtl p){
		p.MethodOpt_rank_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.MethodOpt_rank_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.MethodOpt_rank_size.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.MethodOpt_fill_dt_fm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.MethodOpt_fill_dt_to.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[MiningParam]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MiningParam(FSBAP_MiningDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[SumCondParam]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_SumCondParam(FSBAP_MiningDtl p){

	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_MiningDtl_FW.setTableConfigCond((FSBAP_MiningDtl)this);
		FSBAP_MiningDtl_FW.setTableConfigMethod((FSBAP_MiningDtl)this);
	}

	/**
	 * [Cond]ブロックのTableの設定
	 */
	protected static void setTableConfigCond(FSBAP_MiningDtl p) {
		p.columnCond_col_nm.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.col_nm_META);
		p.CondTable.addColumnConfig(p.columnCond_col_nm);
		p.columnCond_editable_flg.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.editable_flg_META);
		p.CondTable.addColumnConfig(p.columnCond_editable_flg);
		p.columnCond_require_flg.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.require_flg_META);
		p.CondTable.addColumnConfig(p.columnCond_require_flg);
		p.columnCond_text.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.text_META);
		p.CondTable.addColumnConfig(p.columnCond_text);
		p.columnCond_num.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.num_META);
		p.CondTable.addColumnConfig(p.columnCond_num);
		p.columnCond_check.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.check_META);
		p.CondTable.addColumnConfig(p.columnCond_check);
		p.columnCond_date.setMeta(mcframe.clientFSBA.FSBAP0780.CondR.date_META);
		p.columnCond_date.setFormatID("YMDHMSS");
		p.CondTable.addColumnConfig(p.columnCond_date);
		// スクロール固定カラムの指定
		p.CondTable.setUnscrollColumn(p.columnCond_col_nm);
	}

	/**
	 * [Method]ブロックのTableの設定
	 */
	protected static void setTableConfigMethod(FSBAP_MiningDtl p) {
		p.columnMethod_disable.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.disable_META);
		p.MethodTable.addColumnConfig(p.columnMethod_disable);
		p.columnMethod_sum_info_type.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.sum_info_type_META);
		p.MethodTable.addColumnConfig(p.columnMethod_sum_info_type);
		p.columnMethod_sum_info_type_nm.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.sum_info_type_nm_META);
		p.columnMethod_sum_info_type_nm.addLinkBeans(p.columnMethod_sum_info_type);
		p.MethodTable.addColumnConfig(p.columnMethod_sum_info_type_nm);
		p.columnMethod_column_nm.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.column_nm_META);
		p.columnMethod_column_nm.addLinkBeans(p.columnMethod_column_key);
		p.MethodTable.addColumnConfig(p.columnMethod_column_nm);
		p.columnMethod_column_key.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.column_key_META);
		p.MethodTable.addColumnConfig(p.columnMethod_column_key);
		p.columnMethod_sumcond.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.sumcond_META);
		p.MethodTable.addColumnConfig(p.columnMethod_sumcond);
		p.columnMethod_rank.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.rank_META);
		p.MethodTable.addColumnConfig(p.columnMethod_rank);
		p.columnMethod_fill_dt.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.fill_dt_META);
		p.MethodTable.addColumnConfig(p.columnMethod_fill_dt);
		p.columnMethod_date_fmt.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.date_fmt_META);
		p.MethodTable.addColumnConfig(p.columnMethod_date_fmt);
		p.columnMethod_formula.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.formula_META);
		p.MethodTable.addColumnConfig(p.columnMethod_formula);
		p.columnMethod_dec_place.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.dec_place_META);
		p.MethodTable.addColumnConfig(p.columnMethod_dec_place);
		p.columnMethod_rounding_mode_type.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.rounding_mode_type_META);
		p.MethodTable.addColumnConfig(p.columnMethod_rounding_mode_type);
		p.columnMethod_rounding_mode_type_nm.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.rounding_mode_type_nm_META);
		p.columnMethod_rounding_mode_type_nm.addLinkBeans(p.columnMethod_rounding_mode_type);
		p.MethodTable.addColumnConfig(p.columnMethod_rounding_mode_type_nm);
		p.columnMethod_null_zero.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.null_zero_META);
		p.MethodTable.addColumnConfig(p.columnMethod_null_zero);
		p.columnMethod_sort_order.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.sort_order_META);
		p.MethodTable.addColumnConfig(p.columnMethod_sort_order);
		p.columnMethod_sort_type.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.sort_type_META);
		p.columnMethod_sort_type.addLinkBeans(p.columnMethod_sort_type_nm);
		p.MethodTable.addColumnConfig(p.columnMethod_sort_type);
		p.columnMethod_sort_type_nm.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.sort_type_nm_META);
		p.MethodTable.addColumnConfig(p.columnMethod_sort_type_nm);
		p.columnMethod_chart_type.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.chart_type_META);
		p.MethodTable.addColumnConfig(p.columnMethod_chart_type);
		p.columnMethod_chart_type_nm.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.chart_type_nm_META);
		p.columnMethod_chart_type_nm.addLinkBeans(p.columnMethod_chart_type);
		p.MethodTable.addColumnConfig(p.columnMethod_chart_type_nm);
		p.columnMethod_chart_color.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.chart_color_META);
		p.MethodTable.addColumnConfig(p.columnMethod_chart_color);
		p.MethodTable.addTable(p.Method_chart_color_p_PPanel.ColorTable);
		p.columnMethod_row_label.setMeta(mcframe.clientFSBA.FSBAP0780.MethodR.row_label_META);
		p.MethodTable.addColumnConfig(p.columnMethod_row_label);
		// スクロール固定カラムの指定
		p.MethodTable.setUnscrollColumn(p.columnMethod_sumcond);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnMethod_sum_info_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMethod_sum_info_type_nm.getListConfig().setPutter(getMethod_sum_info_type_nm_ListPutter());
		columnMethod_column_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMethod_column_nm.getListConfig().setPutter(getMethod_column_nm_ListPutter());
		columnMethod_date_fmt.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMethod_date_fmt.getListConfig().setPutter(getMethod_date_fmt_ListPutter());
		columnMethod_rounding_mode_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMethod_rounding_mode_type_nm.getListConfig().setPutter(getMethod_rounding_mode_type_nm_ListPutter());
		columnMethod_sort_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMethod_sort_type.getListConfig().setPutter(getMethod_sort_type_ListPutter());
		columnMethod_chart_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMethod_chart_type_nm.getListConfig().setPutter(getMethod_chart_type_nm_ListPutter());
		MethodOpt_rank_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		MethodOpt_rank_type_nm.getListConfig().setPutter(getMethodOpt_rank_type_nm_ListPutter());
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[READ_ONLY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setREAD_ONLYStatus() {
		status = READ_ONLY;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (READ_ONLY.equals(status)) {
			setREAD_ONLYStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Method_sum_info_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createMethod_sum_info_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SumInfoType");
		return lp;
	}
	 
	/**
	 * [Method_column_nm_ListPutter]の作成
	 */
	protected MCListPutter createMethod_column_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Method_date_fmt_ListPutter]の作成
	 */
	protected MCListPutter createMethod_date_fmt_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Method_rounding_mode_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createMethod_rounding_mode_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.RoundingModeType");
		return lp;
	}
	 
	/**
	 * [Method_sort_type_ListPutter]の作成
	 */
	protected MCListPutter createMethod_sort_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SortType");
		return lp;
	}
	 
	/**
	 * [Method_chart_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createMethod_chart_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.GadgetChartType");
		return lp;
	}
	 
	/**
	 * [MethodOpt_rank_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createMethodOpt_rank_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SortType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnMethod_sum_info_type_nm) return getMethod_sum_info_type_nm(row, info);
		if(combo == columnMethod_column_nm) return getMethod_column_nm(row, info);
		if(combo == columnMethod_date_fmt) return getMethod_date_fmt(row, info);
		if(combo == columnMethod_rounding_mode_type_nm) return getMethod_rounding_mode_type_nm(row, info);
		if(combo == columnMethod_sort_type) return getMethod_sort_type(row, info);
		if(combo == columnMethod_chart_type_nm) return getMethod_chart_type_nm(row, info);
		if(combo == MethodOpt_rank_type_nm) return getMethodOpt_rank_type_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == CondTable) return doCond_VC(info);
		if (vc == MethodTable) return doMethod_VC(info);
		if (vc == Mining_mining_nm) return doMining_mining_nm_VC(info);
		if (vc == Mining_description_text) return doMining_description_text_VC(info);
		if (vc == Mining_operation) return doMining_operation_VC(info);
		if (vc == Mining_operation_nm) return doMining_operation_nm_VC(info);
		if (vc == Mining_function) return doMining_function_VC(info);
		if (vc == Mining_func_typ) return doMining_func_typ_VC(info);
		if (vc == Mining_screen) return doMining_screen_VC(info);
		if (vc == Mining_screen_nm) return doMining_screen_nm_VC(info);
		if (vc == Mining_md_module_id) return doMining_md_module_id_VC(info);
		if (vc == Mining_md_screen_id) return doMining_md_screen_id_VC(info);
		if (vc == Mining_gadget_icon) return doMining_gadget_icon_VC(info);
		if (vc == Mining_gadget_w) return doMining_gadget_w_VC(info);
		if (vc == Mining_gadget_h) return doMining_gadget_h_VC(info);
		if (vc == Mining_gadget_cache_flg) return doMining_gadget_cache_flg_VC(info);
		if (vc == columnCond_col_nm) return doCond_col_nm_VC(info);
		if (vc == columnCond_editable_flg) return doCond_editable_flg_VC(info);
		if (vc == columnCond_require_flg) return doCond_require_flg_VC(info);
		if (vc == columnCond_text) return doCond_text_VC(info);
		if (vc == columnCond_num) return doCond_num_VC(info);
		if (vc == columnCond_check) return doCond_check_VC(info);
		if (vc == columnCond_date) return doCond_date_VC(info);
		if (vc == columnMethod_disable) return doMethod_disable_VC(info);
		if (vc == columnMethod_sum_info_type) return doMethod_sum_info_type_VC(info);
		if (vc == columnMethod_sum_info_type_nm) return doMethod_sum_info_type_nm_VC(info);
		if (vc == columnMethod_column_nm) return doMethod_column_nm_VC(info);
		if (vc == columnMethod_column_key) return doMethod_column_key_VC(info);
		if (vc == columnMethod_sumcond) return doMethod_sumcond_VC(info);
		if (vc == columnMethod_rank) return doMethod_rank_VC(info);
		if (vc == columnMethod_fill_dt) return doMethod_fill_dt_VC(info);
		if (vc == columnMethod_date_fmt) return doMethod_date_fmt_VC(info);
		if (vc == columnMethod_formula) return doMethod_formula_VC(info);
		if (vc == columnMethod_dec_place) return doMethod_dec_place_VC(info);
		if (vc == columnMethod_rounding_mode_type) return doMethod_rounding_mode_type_VC(info);
		if (vc == columnMethod_rounding_mode_type_nm) return doMethod_rounding_mode_type_nm_VC(info);
		if (vc == columnMethod_null_zero) return doMethod_null_zero_VC(info);
		if (vc == columnMethod_sort_order) return doMethod_sort_order_VC(info);
		if (vc == columnMethod_sort_type) return doMethod_sort_type_VC(info);
		if (vc == columnMethod_sort_type_nm) return doMethod_sort_type_nm_VC(info);
		if (vc == columnMethod_chart_type) return doMethod_chart_type_VC(info);
		if (vc == columnMethod_chart_type_nm) return doMethod_chart_type_nm_VC(info);
		if (vc == columnMethod_chart_color) return doMethod_chart_color_VC(info);
		if (vc == columnMethod_row_label) return doMethod_row_label_VC(info);
		if (vc == MethodOpt_rank_type) return doMethodOpt_rank_type_VC(info);
		if (vc == MethodOpt_rank_type_nm) return doMethodOpt_rank_type_nm_VC(info);
		if (vc == MethodOpt_rank_size) return doMethodOpt_rank_size_VC(info);
		if (vc == MethodOpt_fill_dt_fm) return doMethodOpt_fill_dt_fm_VC(info);
		if (vc == MethodOpt_fill_dt_to) return doMethodOpt_fill_dt_to_VC(info);
		return true;
	}

	/**
	 * [Cond]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[mining_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_mining_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[description_text]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_description_text_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[operation]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_operation_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[operation_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_operation_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[function]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_function_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[func_typ]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_func_typ_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[screen]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_screen_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[screen_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_screen_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[md_module_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_md_module_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[md_screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_md_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[gadget_icon]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_gadget_icon_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[gadget_w]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_gadget_w_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[gadget_h]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_gadget_h_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Mining]パネルの[gadget_cache_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMining_gadget_cache_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[col_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_col_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[editable_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_editable_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[require_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_require_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[text]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_text_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[num]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_num_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[check]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_check_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[date]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_date_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[disable]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_disable_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[sum_info_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_sum_info_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[sum_info_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_sum_info_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[column_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_column_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[column_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_column_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[sumcond]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_sumcond_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[rank]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_rank_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[fill_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_fill_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[date_fmt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_date_fmt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[formula]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_formula_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[dec_place]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_dec_place_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[rounding_mode_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_rounding_mode_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[rounding_mode_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_rounding_mode_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[null_zero]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_null_zero_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[sort_order]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_sort_order_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[sort_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_sort_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[sort_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_sort_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[chart_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_chart_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[chart_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_chart_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[chart_color]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_chart_color_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Method]パネルの[row_label]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethod_row_label_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MethodOpt]パネルの[rank_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethodOpt_rank_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MethodOpt]パネルの[rank_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethodOpt_rank_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MethodOpt]パネルの[rank_size]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethodOpt_rank_size_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_fm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethodOpt_fill_dt_fm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_to]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMethodOpt_fill_dt_to_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == CondTable) doCond_NC(info);
		else if (nc == MethodTable) doMethod_NC(info);
		else if (nc == Mining_mining_nm) doMining_mining_nm_NC(info);
		else if (nc == Mining_description_text) doMining_description_text_NC(info);
		else if (nc == Mining_operation) doMining_operation_NC(info);
		else if (nc == Mining_operation_nm) doMining_operation_nm_NC(info);
		else if (nc == Mining_function) doMining_function_NC(info);
		else if (nc == Mining_func_typ) doMining_func_typ_NC(info);
		else if (nc == Mining_screen) doMining_screen_NC(info);
		else if (nc == Mining_screen_nm) doMining_screen_nm_NC(info);
		else if (nc == Mining_md_module_id) doMining_md_module_id_NC(info);
		else if (nc == Mining_md_screen_id) doMining_md_screen_id_NC(info);
		else if (nc == Mining_gadget_icon) doMining_gadget_icon_NC(info);
		else if (nc == Mining_gadget_w) doMining_gadget_w_NC(info);
		else if (nc == Mining_gadget_h) doMining_gadget_h_NC(info);
		else if (nc == Mining_gadget_cache_flg) doMining_gadget_cache_flg_NC(info);
		else if (nc == columnCond_col_nm) doCond_col_nm_NC(info);
		else if (nc == columnCond_editable_flg) doCond_editable_flg_NC(info);
		else if (nc == columnCond_require_flg) doCond_require_flg_NC(info);
		else if (nc == columnCond_text) doCond_text_NC(info);
		else if (nc == columnCond_num) doCond_num_NC(info);
		else if (nc == columnCond_check) doCond_check_NC(info);
		else if (nc == columnCond_date) doCond_date_NC(info);
		else if (nc == columnMethod_disable) doMethod_disable_NC(info);
		else if (nc == columnMethod_sum_info_type) doMethod_sum_info_type_NC(info);
		else if (nc == columnMethod_sum_info_type_nm) doMethod_sum_info_type_nm_NC(info);
		else if (nc == columnMethod_column_nm) doMethod_column_nm_NC(info);
		else if (nc == columnMethod_column_key) doMethod_column_key_NC(info);
		else if (nc == columnMethod_sumcond) doMethod_sumcond_NC(info);
		else if (nc == columnMethod_rank) doMethod_rank_NC(info);
		else if (nc == columnMethod_fill_dt) doMethod_fill_dt_NC(info);
		else if (nc == columnMethod_date_fmt) doMethod_date_fmt_NC(info);
		else if (nc == columnMethod_formula) doMethod_formula_NC(info);
		else if (nc == columnMethod_dec_place) doMethod_dec_place_NC(info);
		else if (nc == columnMethod_rounding_mode_type) doMethod_rounding_mode_type_NC(info);
		else if (nc == columnMethod_rounding_mode_type_nm) doMethod_rounding_mode_type_nm_NC(info);
		else if (nc == columnMethod_null_zero) doMethod_null_zero_NC(info);
		else if (nc == columnMethod_sort_order) doMethod_sort_order_NC(info);
		else if (nc == columnMethod_sort_type) doMethod_sort_type_NC(info);
		else if (nc == columnMethod_sort_type_nm) doMethod_sort_type_nm_NC(info);
		else if (nc == columnMethod_chart_type) doMethod_chart_type_NC(info);
		else if (nc == columnMethod_chart_type_nm) doMethod_chart_type_nm_NC(info);
		else if (nc == columnMethod_chart_color) doMethod_chart_color_NC(info);
		else if (nc == columnMethod_row_label) doMethod_row_label_NC(info);
		else if (nc == MethodOpt_rank_type) doMethodOpt_rank_type_NC(info);
		else if (nc == MethodOpt_rank_type_nm) doMethodOpt_rank_type_nm_NC(info);
		else if (nc == MethodOpt_rank_size) doMethodOpt_rank_size_NC(info);
		else if (nc == MethodOpt_fill_dt_fm) doMethodOpt_fill_dt_fm_NC(info);
		else if (nc == MethodOpt_fill_dt_to) doMethodOpt_fill_dt_to_NC(info);
	}

	/**
	 * [Cond]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_NC(MCEventInfo info){
	}

	/**
	 * [Method]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[mining_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_mining_nm_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[description_text]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_description_text_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_nm_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[function]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_function_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[func_typ]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_func_typ_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_nm_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_module_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_module_id_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_icon]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_icon_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_w]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_w_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_h]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_h_NC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_cache_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_cache_flg_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[col_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_col_nm_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[editable_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_editable_flg_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[require_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_require_flg_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[text]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_text_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[num]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_num_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[check]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_check_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[date]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_date_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[disable]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_disable_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_nm_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_key_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sumcond]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sumcond_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rank]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rank_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[fill_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_fill_dt_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[date_fmt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_date_fmt_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[formula]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_formula_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[dec_place]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_dec_place_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[null_zero]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_null_zero_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_order]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_order_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_color]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_color_NC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[row_label]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_row_label_NC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_NC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_size]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_size_NC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_fm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_fm_NC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_to]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_to_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == CondTable) doCond_NE(info);
		else if (ne == MethodTable) doMethod_NE(info);
		else if (ne == Mining_mining_nm) doMining_mining_nm_NE(info);
		else if (ne == Mining_description_text) doMining_description_text_NE(info);
		else if (ne == Mining_operation) doMining_operation_NE(info);
		else if (ne == Mining_operation_nm) doMining_operation_nm_NE(info);
		else if (ne == Mining_function) doMining_function_NE(info);
		else if (ne == Mining_func_typ) doMining_func_typ_NE(info);
		else if (ne == Mining_screen) doMining_screen_NE(info);
		else if (ne == Mining_screen_nm) doMining_screen_nm_NE(info);
		else if (ne == Mining_md_module_id) doMining_md_module_id_NE(info);
		else if (ne == Mining_md_screen_id) doMining_md_screen_id_NE(info);
		else if (ne == Mining_gadget_icon) doMining_gadget_icon_NE(info);
		else if (ne == Mining_gadget_w) doMining_gadget_w_NE(info);
		else if (ne == Mining_gadget_h) doMining_gadget_h_NE(info);
		else if (ne == Mining_gadget_cache_flg) doMining_gadget_cache_flg_NE(info);
		else if (ne == columnCond_col_nm) doCond_col_nm_NE(info);
		else if (ne == columnCond_editable_flg) doCond_editable_flg_NE(info);
		else if (ne == columnCond_require_flg) doCond_require_flg_NE(info);
		else if (ne == columnCond_text) doCond_text_NE(info);
		else if (ne == columnCond_num) doCond_num_NE(info);
		else if (ne == columnCond_check) doCond_check_NE(info);
		else if (ne == columnCond_date) doCond_date_NE(info);
		else if (ne == columnMethod_disable) doMethod_disable_NE(info);
		else if (ne == columnMethod_sum_info_type) doMethod_sum_info_type_NE(info);
		else if (ne == columnMethod_sum_info_type_nm) doMethod_sum_info_type_nm_NE(info);
		else if (ne == columnMethod_column_nm) doMethod_column_nm_NE(info);
		else if (ne == columnMethod_column_key) doMethod_column_key_NE(info);
		else if (ne == columnMethod_sumcond) doMethod_sumcond_NE(info);
		else if (ne == columnMethod_rank) doMethod_rank_NE(info);
		else if (ne == columnMethod_fill_dt) doMethod_fill_dt_NE(info);
		else if (ne == columnMethod_date_fmt) doMethod_date_fmt_NE(info);
		else if (ne == columnMethod_formula) doMethod_formula_NE(info);
		else if (ne == columnMethod_dec_place) doMethod_dec_place_NE(info);
		else if (ne == columnMethod_rounding_mode_type) doMethod_rounding_mode_type_NE(info);
		else if (ne == columnMethod_rounding_mode_type_nm) doMethod_rounding_mode_type_nm_NE(info);
		else if (ne == columnMethod_null_zero) doMethod_null_zero_NE(info);
		else if (ne == columnMethod_sort_order) doMethod_sort_order_NE(info);
		else if (ne == columnMethod_sort_type) doMethod_sort_type_NE(info);
		else if (ne == columnMethod_sort_type_nm) doMethod_sort_type_nm_NE(info);
		else if (ne == columnMethod_chart_type) doMethod_chart_type_NE(info);
		else if (ne == columnMethod_chart_type_nm) doMethod_chart_type_nm_NE(info);
		else if (ne == columnMethod_chart_color) doMethod_chart_color_NE(info);
		else if (ne == columnMethod_row_label) doMethod_row_label_NE(info);
		else if (ne == MethodOpt_rank_type) doMethodOpt_rank_type_NE(info);
		else if (ne == MethodOpt_rank_type_nm) doMethodOpt_rank_type_nm_NE(info);
		else if (ne == MethodOpt_rank_size) doMethodOpt_rank_size_NE(info);
		else if (ne == MethodOpt_fill_dt_fm) doMethodOpt_fill_dt_fm_NE(info);
		else if (ne == MethodOpt_fill_dt_to) doMethodOpt_fill_dt_to_NE(info);
	}

	/**
	 * [Cond]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_NE(MCEventInfo info){
	}

	/**
	 * [Method]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[mining_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_mining_nm_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[description_text]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_description_text_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_nm_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[function]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_function_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[func_typ]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_func_typ_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_nm_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_module_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_module_id_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_icon]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_icon_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_w]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_w_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_h]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_h_NE(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_cache_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_cache_flg_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[col_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_col_nm_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[editable_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_editable_flg_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[require_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_require_flg_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[text]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_text_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[num]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_num_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[check]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_check_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[date]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_date_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[disable]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_disable_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_nm_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_key_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sumcond]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sumcond_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rank]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rank_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[fill_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_fill_dt_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[date_fmt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_date_fmt_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[formula]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_formula_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[dec_place]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_dec_place_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[null_zero]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_null_zero_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_order]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_order_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_color]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_color_NE(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[row_label]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_row_label_NE(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_NE(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_size]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_size_NE(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_fm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_fm_NE(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_to]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_to_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == CondTable) doCond_NX(info);
		else if (nx == MethodTable) doMethod_NX(info);
		else if (nx == Mining_mining_nm) doMining_mining_nm_NX(info);
		else if (nx == Mining_description_text) doMining_description_text_NX(info);
		else if (nx == Mining_operation) doMining_operation_NX(info);
		else if (nx == Mining_operation_nm) doMining_operation_nm_NX(info);
		else if (nx == Mining_function) doMining_function_NX(info);
		else if (nx == Mining_func_typ) doMining_func_typ_NX(info);
		else if (nx == Mining_screen) doMining_screen_NX(info);
		else if (nx == Mining_screen_nm) doMining_screen_nm_NX(info);
		else if (nx == Mining_md_module_id) doMining_md_module_id_NX(info);
		else if (nx == Mining_md_screen_id) doMining_md_screen_id_NX(info);
		else if (nx == Mining_gadget_icon) doMining_gadget_icon_NX(info);
		else if (nx == Mining_gadget_w) doMining_gadget_w_NX(info);
		else if (nx == Mining_gadget_h) doMining_gadget_h_NX(info);
		else if (nx == Mining_gadget_cache_flg) doMining_gadget_cache_flg_NX(info);
		else if (nx == columnCond_col_nm) doCond_col_nm_NX(info);
		else if (nx == columnCond_editable_flg) doCond_editable_flg_NX(info);
		else if (nx == columnCond_require_flg) doCond_require_flg_NX(info);
		else if (nx == columnCond_text) doCond_text_NX(info);
		else if (nx == columnCond_num) doCond_num_NX(info);
		else if (nx == columnCond_check) doCond_check_NX(info);
		else if (nx == columnCond_date) doCond_date_NX(info);
		else if (nx == columnMethod_disable) doMethod_disable_NX(info);
		else if (nx == columnMethod_sum_info_type) doMethod_sum_info_type_NX(info);
		else if (nx == columnMethod_sum_info_type_nm) doMethod_sum_info_type_nm_NX(info);
		else if (nx == columnMethod_column_nm) doMethod_column_nm_NX(info);
		else if (nx == columnMethod_column_key) doMethod_column_key_NX(info);
		else if (nx == columnMethod_sumcond) doMethod_sumcond_NX(info);
		else if (nx == columnMethod_rank) doMethod_rank_NX(info);
		else if (nx == columnMethod_fill_dt) doMethod_fill_dt_NX(info);
		else if (nx == columnMethod_date_fmt) doMethod_date_fmt_NX(info);
		else if (nx == columnMethod_formula) doMethod_formula_NX(info);
		else if (nx == columnMethod_dec_place) doMethod_dec_place_NX(info);
		else if (nx == columnMethod_rounding_mode_type) doMethod_rounding_mode_type_NX(info);
		else if (nx == columnMethod_rounding_mode_type_nm) doMethod_rounding_mode_type_nm_NX(info);
		else if (nx == columnMethod_null_zero) doMethod_null_zero_NX(info);
		else if (nx == columnMethod_sort_order) doMethod_sort_order_NX(info);
		else if (nx == columnMethod_sort_type) doMethod_sort_type_NX(info);
		else if (nx == columnMethod_sort_type_nm) doMethod_sort_type_nm_NX(info);
		else if (nx == columnMethod_chart_type) doMethod_chart_type_NX(info);
		else if (nx == columnMethod_chart_type_nm) doMethod_chart_type_nm_NX(info);
		else if (nx == columnMethod_chart_color) doMethod_chart_color_NX(info);
		else if (nx == columnMethod_row_label) doMethod_row_label_NX(info);
		else if (nx == MethodOpt_rank_type) doMethodOpt_rank_type_NX(info);
		else if (nx == MethodOpt_rank_type_nm) doMethodOpt_rank_type_nm_NX(info);
		else if (nx == MethodOpt_rank_size) doMethodOpt_rank_size_NX(info);
		else if (nx == MethodOpt_fill_dt_fm) doMethodOpt_fill_dt_fm_NX(info);
		else if (nx == MethodOpt_fill_dt_to) doMethodOpt_fill_dt_to_NX(info);
	}

	/**
	 * [Cond]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_NX(MCEventInfo info){
	}

	/**
	 * [Method]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[mining_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_mining_nm_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[description_text]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_description_text_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_nm_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[function]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_function_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[func_typ]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_func_typ_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_nm_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_module_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_module_id_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_icon]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_icon_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_w]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_w_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_h]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_h_NX(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_cache_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_cache_flg_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[col_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_col_nm_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[editable_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_editable_flg_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[require_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_require_flg_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[text]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_text_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[num]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_num_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[check]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_check_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[date]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_date_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[disable]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_disable_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_nm_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_key_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sumcond]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sumcond_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rank]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rank_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[fill_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_fill_dt_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[date_fmt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_date_fmt_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[formula]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_formula_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[dec_place]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_dec_place_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[null_zero]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_null_zero_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_order]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_order_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_color]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_color_NX(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[row_label]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_row_label_NX(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_NX(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_size]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_size_NX(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_fm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_fm_NX(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_to]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_to_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Mining_mining_nm) doMining_mining_nm_LC(info);
		else if (lc == Mining_operation) doMining_operation_LC(info);
		else if (lc == Mining_operation_nm) doMining_operation_nm_LC(info);
		else if (lc == Mining_function) doMining_function_LC(info);
		else if (lc == Mining_func_typ) doMining_func_typ_LC(info);
		else if (lc == Mining_screen) doMining_screen_LC(info);
		else if (lc == Mining_screen_nm) doMining_screen_nm_LC(info);
		else if (lc == Mining_md_module_id) doMining_md_module_id_LC(info);
		else if (lc == Mining_md_screen_id) doMining_md_screen_id_LC(info);
		else if (lc == Mining_gadget_w) doMining_gadget_w_LC(info);
		else if (lc == Mining_gadget_h) doMining_gadget_h_LC(info);
		else if (lc == columnCond_col_nm) doCond_col_nm_LC(info);
		else if (lc == columnCond_text) doCond_text_LC(info);
		else if (lc == columnCond_num) doCond_num_LC(info);
		else if (lc == columnCond_date) doCond_date_LC(info);
		else if (lc == columnMethod_sum_info_type) doMethod_sum_info_type_LC(info);
		else if (lc == columnMethod_sum_info_type_nm) doMethod_sum_info_type_nm_LC(info);
		else if (lc == columnMethod_column_nm) doMethod_column_nm_LC(info);
		else if (lc == columnMethod_column_key) doMethod_column_key_LC(info);
		else if (lc == columnMethod_sumcond) doMethod_sumcond_LC(info);
		else if (lc == columnMethod_date_fmt) doMethod_date_fmt_LC(info);
		else if (lc == columnMethod_formula) doMethod_formula_LC(info);
		else if (lc == columnMethod_dec_place) doMethod_dec_place_LC(info);
		else if (lc == columnMethod_rounding_mode_type) doMethod_rounding_mode_type_LC(info);
		else if (lc == columnMethod_rounding_mode_type_nm) doMethod_rounding_mode_type_nm_LC(info);
		else if (lc == columnMethod_sort_order) doMethod_sort_order_LC(info);
		else if (lc == columnMethod_sort_type) doMethod_sort_type_LC(info);
		else if (lc == columnMethod_sort_type_nm) doMethod_sort_type_nm_LC(info);
		else if (lc == columnMethod_chart_type) doMethod_chart_type_LC(info);
		else if (lc == columnMethod_chart_type_nm) doMethod_chart_type_nm_LC(info);
		else if (lc == columnMethod_chart_color) doMethod_chart_color_LC(info);
		else if (lc == MethodOpt_rank_type) doMethodOpt_rank_type_LC(info);
		else if (lc == MethodOpt_rank_type_nm) doMethodOpt_rank_type_nm_LC(info);
		else if (lc == MethodOpt_rank_size) doMethodOpt_rank_size_LC(info);
		else if (lc == MethodOpt_fill_dt_fm) doMethodOpt_fill_dt_fm_LC(info);
		else if (lc == MethodOpt_fill_dt_to) doMethodOpt_fill_dt_to_LC(info);
	}

	/**
	 * [Mining]パネルの[mining_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_mining_nm_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[operation_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_operation_nm_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[function]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_function_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[func_typ]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_func_typ_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[screen_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_screen_nm_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_module_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_module_id_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[md_screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_md_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_w]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_w_LC(MCEventInfo info){
	}

	/**
	 * [Mining]パネルの[gadget_h]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMining_gadget_h_LC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[col_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_col_nm_LC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[text]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_text_LC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[num]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_num_LC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[date]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_date_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sum_info_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sum_info_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_nm_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[column_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_column_key_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sumcond]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sumcond_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[date_fmt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_date_fmt_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[formula]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_formula_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[dec_place]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_dec_place_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[rounding_mode_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_rounding_mode_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_order]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_order_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[sort_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_sort_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Method]パネルの[chart_color]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethod_chart_color_LC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_LC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[rank_size]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_rank_size_LC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_fm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_fm_LC(MCEventInfo info){
	}

	/**
	 * [MethodOpt]パネルの[fill_dt_to]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMethodOpt_fill_dt_to_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnMethod_sum_info_type_nm]の作成メソッド
	 */
	public MCList getMethod_sum_info_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSumInfoType(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnMethod_column_nm]の作成メソッド
	 */
	public MCList getMethod_column_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnMethod_date_fmt]の作成メソッド
	 */
	public MCList getMethod_date_fmt(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnMethod_rounding_mode_type_nm]の作成メソッド
	 */
	public MCList getMethod_rounding_mode_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getRoundingModeType(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnMethod_sort_type]の作成メソッド
	 */
	public MCList getMethod_sort_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSortType(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnMethod_chart_type_nm]の作成メソッド
	 */
	public MCList getMethod_chart_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getGadgetChartType(row, info);
	}

	/**
	 * コンボ／リストのリスト[MethodOpt_rank_type_nm]の作成メソッド
	 */
	public MCList getMethodOpt_rank_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSortType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0760.Srch01")) {
			return new FS_FSBAL0760_Srch01Bridge();
		}
		if (id.equals("FS.FSBAL0760.Upd01")) {
			return new FS_FSBAL0760_Upd01Bridge();
		}
		if (id.equals("FS.FSBAL0760.Ins01")) {
			return new FS_FSBAL0760_Ins01Bridge();
		}
		if (id.equals("FS.FSBAL0760.Ins02")) {
			return new FS_FSBAL0760_Ins02Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0760_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Srch01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0760_Srch01;

		/** コンストラクタ */
		protected FS_FSBAL0760_Srch01Bridge() {
			p_FS_FSBAL0760_Srch01 = new MCParam(PDef.FS_FSBAL0760_Srch01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0760_Srch01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0780.SrchR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));

			p_FS_FSBAL0760_Srch01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0760_Srch01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0760_Srch01.addUpBlock(getSrchR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0760_Srch01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0780.SrchR up0() {
			return (mcframe.clientFSBA.FSBAP0780.SrchR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0780.MiningR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MiningR>)down(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.CondR> down1() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.CondR>)down(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.MethodR> down2() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)down(2);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> down3() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)down(3);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class));
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0760_Srch01;
		}

		protected void show() {
			setMiningParamL((MCList<mcframe.clientFSBA.FSBAP0780.MiningR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(0));
			setCondL((MCList<mcframe.clientFSBA.FSBAP0780.CondR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(1));
			setMethodL((MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(2));
			setSumCondParamL((MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(3));
		}

		protected void clear() {
			getMiningParamL().clear();
			getCondL().clear();
			getMethodL().clear();
			getSumCondParamL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getSrchR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningParamL());
			result.add(getCondL());
			result.add(getMethodL());
			result.add(getSumCondParamL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0760_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Upd01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0760_Upd01;

		/** コンストラクタ */
		protected FS_FSBAL0760_Upd01Bridge() {
			p_FS_FSBAL0760_Upd01 = new MCParam(PDef.FS_FSBAL0760_Upd01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0760_Upd01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));
			// Down
			param.addDownBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());

			p_FS_FSBAL0760_Upd01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0760_Upd01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0760_Upd01.addUpBlock(getMiningR());
			p_FS_FSBAL0760_Upd01.addUpBlock(getCondL().shallowClone());
			p_FS_FSBAL0760_Upd01.addUpBlock(getMethodL().shallowClone());
			p_FS_FSBAL0760_Upd01.addUpBlock(getSumCondParamL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0760_Upd01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0760_Upd01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0780.MiningR up0() {
			return (mcframe.clientFSBA.FSBAP0780.MiningR)up(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.CondR> up1() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.CondR>)up(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.MethodR> up2() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)up(2);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> up3() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)up(3);
		}

		protected mcframe.clientFSBA.FSBAP0780.MiningR down0() {
			return (mcframe.clientFSBA.FSBAP0780.MiningR)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0760_Upd01.addDownBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());
		}
		protected MCParam param() {
			return p_FS_FSBAL0760_Upd01;
		}

		protected void show() {
			setMiningR((mcframe.clientFSBA.FSBAP0780.MiningR)p_FS_FSBAL0760_Upd01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMiningR().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningR());
			result.add(getCondL());
			result.add(getMethodL());
			result.add(getSumCondParamL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningR());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0760_Ins01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Ins01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0760_Ins01;

		/** コンストラクタ */
		protected FS_FSBAL0760_Ins01Bridge() {
			p_FS_FSBAL0760_Ins01 = new MCParam(PDef.FS_FSBAL0760_Ins01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0760_Ins01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));
			// Down
			param.addDownBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());

			p_FS_FSBAL0760_Ins01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0760_Ins01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0760_Ins01.addUpBlock(getMiningR());
			p_FS_FSBAL0760_Ins01.addUpBlock(getCondL().shallowClone());
			p_FS_FSBAL0760_Ins01.addUpBlock(getMethodL().shallowClone());
			p_FS_FSBAL0760_Ins01.addUpBlock(getSumCondParamL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0760_Ins01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0760_Ins01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0780.MiningR up0() {
			return (mcframe.clientFSBA.FSBAP0780.MiningR)up(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.CondR> up1() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.CondR>)up(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.MethodR> up2() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)up(2);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> up3() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)up(3);
		}

		protected mcframe.clientFSBA.FSBAP0780.MiningR down0() {
			return (mcframe.clientFSBA.FSBAP0780.MiningR)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0760_Ins01.addDownBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());
		}
		protected MCParam param() {
			return p_FS_FSBAL0760_Ins01;
		}

		protected void show() {
			setMiningR((mcframe.clientFSBA.FSBAP0780.MiningR)p_FS_FSBAL0760_Ins01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMiningR().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningR());
			result.add(getCondL());
			result.add(getMethodL());
			result.add(getSumCondParamL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningR());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0760_Ins02]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Ins02Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0760_Ins02;

		/** コンストラクタ */
		protected FS_FSBAL0760_Ins02Bridge() {
			p_FS_FSBAL0760_Ins02 = new MCParam(PDef.FS_FSBAL0760_Ins02_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0760_Ins02_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));
			// Down
			param.addDownBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());

			p_FS_FSBAL0760_Ins02 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0760_Ins02.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0760_Ins02.addUpBlock(getMiningR());
			p_FS_FSBAL0760_Ins02.addUpBlock(getCondL().shallowClone());
			p_FS_FSBAL0760_Ins02.addUpBlock(getMethodL().shallowClone());
			p_FS_FSBAL0760_Ins02.addUpBlock(getSumCondParamL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0760_Ins02.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0760_Ins02.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0780.MiningR up0() {
			return (mcframe.clientFSBA.FSBAP0780.MiningR)up(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.CondR> up1() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.CondR>)up(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.MethodR> up2() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)up(2);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> up3() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)up(3);
		}

		protected mcframe.clientFSBA.FSBAP0780.MiningR down0() {
			return (mcframe.clientFSBA.FSBAP0780.MiningR)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0760_Ins02.addDownBlock(mcframe.clientFSBA.FSBAP0780.MiningR.create());
		}
		protected MCParam param() {
			return p_FS_FSBAL0760_Ins02;
		}

		protected void show() {
			setMiningR((mcframe.clientFSBA.FSBAP0780.MiningR)p_FS_FSBAL0760_Ins02.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMiningR().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningR());
			result.add(getCondL());
			result.add(getMethodL());
			result.add(getSumCondParamL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningR());
			return result;
		}
	}
}