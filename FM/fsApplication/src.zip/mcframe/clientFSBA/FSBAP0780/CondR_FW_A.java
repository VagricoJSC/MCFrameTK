package mcframe.clientFSBA.FSBAP0780;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cond"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CondR_FW_A extends MCConstRow {

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 *  項目名.<p>
	 *
	 */
	public static final String $col_id = "col_id";
	/**
	 *  表示名称.<p>
	 *
	 */
	public static final String $col_nm = "col_nm";
	/**
	 *  表示順.<p>
	 *
	 */
	public static final String $list_order = "list_order";
	/**
	 *  画面項目名.<p>
	 *
	 */
	public static final String $scr_itm_id = "scr_itm_id";
	/**
	 *  ＭＤオプション画面項目名.<p>
	 *
	 */
	public static final String $md_itm_id = "md_itm_id";
	/**
	 *  データ型区分.<p>
	 *
	 */
	public static final String $data_typ = "data_typ";
	/**
	 *  編集可ＦＬＧ.<p>
	 *
	 */
	public static final String $editable_flg = "editable_flg";
	/**
	 *  必須ＦＬＧ.<p>
	 *
	 */
	public static final String $require_flg = "require_flg";
	/**
	 *  初期値.<p>
	 *
	 */
	public static final String $init_val = "init_val";
	/**
	 *  テキスト.<p>
	 *
	 */
	public static final String $text = "text";
	/**
	 *  数値.<p>
	 *
	 */
	public static final String $num = "num";
	/**
	 *  チェックボックス.<p>
	 *
	 */
	public static final String $check = "check";
	/**
	 *  日付.<p>
	 *
	 */
	public static final String $date = "date";


	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta col_id_META = createCommonMeta($col_id, mcframe.commonCore.meta.M_META.RES_KEY);
	public static final MCMeta col_nm_META = createCommonMeta($col_nm, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta list_order_META = createCommonMeta($list_order, mcframe.commonCore.meta.M_META.SORT_ORDER);
	public static final MCMeta scr_itm_id_META = createCommonMeta($scr_itm_id, mcframe.commonCore.meta.M_META.COLUMN_ID);
	public static final MCMeta md_itm_id_META = createCommonMeta($md_itm_id, mcframe.commonCore.meta.M_META.COLUMN_ID);
	public static final MCMeta data_typ_META = createCommonMeta($data_typ, mcframe.commonCore.meta.M_META.DATA_TYPE_TYP);
	public static final MCMeta editable_flg_META = createCommonMeta($editable_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta require_flg_META = createCommonMeta($require_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta init_val_META = createCommonMeta($init_val, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta text_META = createStringMeta($text, 900);
	public static final MCMeta num_META = createNumberMeta($num);
	public static final MCMeta check_META = createBooleanMeta($check);
	public static final MCMeta date_META = createTimestampMeta($date);

	protected static final ConstMetaList<CondR> constMetas = new ConstMetaList<CondR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			mining_id_META,
			col_id_META,
			col_nm_META,
			list_order_META,
			scr_itm_id_META,
			md_itm_id_META,
			data_typ_META,
			editable_flg_META,
			require_flg_META,
			init_val_META,
			text_META,
			num_META,
			check_META,
			date_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CondR_FW_A(ConstMetaList<? extends CondR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CondR clone() {
		return (CondR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CondR createInstance() {
		return (CondR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CondR getValues(String... names) {
		return (CondR) super.getValues(names);
	}



	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 0, $mining_id);
	}

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 0, $mining_id, value);
	}


	/**
	 *  項目名.<p>
	 *
	 */
	public String col_id() {
		return getConstString(offset + 1, $col_id);
	}

	/**
	 *  項目名.<p>
	 *
	 */
	public void col_id(String value) {
		setConstString(offset + 1, $col_id, value);
	}


	/**
	 *  表示名称.<p>
	 *
	 */
	public String col_nm() {
		return getConstString(offset + 2, $col_nm);
	}

	/**
	 *  表示名称.<p>
	 *
	 */
	public void col_nm(String value) {
		setConstString(offset + 2, $col_nm, value);
	}


	/**
	 *  表示順.<p>
	 *
	 */
	public MCNumber list_order() {
		return getConstNumber(offset + 3, $list_order);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(MCNumber value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(int value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(long value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(float value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 *  表示順.<p>
	 *
	 */
	public void list_order(double value) {
		setConstNumber(offset + 3, $list_order, value);
	}


	/**
	 *  画面項目名.<p>
	 *
	 */
	public String scr_itm_id() {
		return getConstString(offset + 4, $scr_itm_id);
	}

	/**
	 *  画面項目名.<p>
	 *
	 */
	public void scr_itm_id(String value) {
		setConstString(offset + 4, $scr_itm_id, value);
	}


	/**
	 *  ＭＤオプション画面項目名.<p>
	 *
	 */
	public String md_itm_id() {
		return getConstString(offset + 5, $md_itm_id);
	}

	/**
	 *  ＭＤオプション画面項目名.<p>
	 *
	 */
	public void md_itm_id(String value) {
		setConstString(offset + 5, $md_itm_id, value);
	}


	/**
	 *  データ型区分.<p>
	 *
	 */
	public String data_typ() {
		return getConstString(offset + 6, $data_typ);
	}

	/**
	 *  データ型区分.<p>
	 *
	 */
	public void data_typ(String value) {
		setConstString(offset + 6, $data_typ, value);
	}


	/**
	 *  編集可ＦＬＧ.<p>
	 *
	 */
	public boolean editable_flg() {
		return getConstBoolean(offset + 7, $editable_flg);
	}

	/**
	 *  編集可ＦＬＧ.<p>
	 *
	 */
	public void editable_flg(boolean value) {
		setConstBoolean(offset + 7, $editable_flg, value);
	}


	/**
	 *  必須ＦＬＧ.<p>
	 *
	 */
	public boolean require_flg() {
		return getConstBoolean(offset + 8, $require_flg);
	}

	/**
	 *  必須ＦＬＧ.<p>
	 *
	 */
	public void require_flg(boolean value) {
		setConstBoolean(offset + 8, $require_flg, value);
	}


	/**
	 *  初期値.<p>
	 *
	 */
	public String init_val() {
		return getConstString(offset + 9, $init_val);
	}

	/**
	 *  初期値.<p>
	 *
	 */
	public void init_val(String value) {
		setConstString(offset + 9, $init_val, value);
	}


	/**
	 *  テキスト.<p>
	 *
	 */
	public String text() {
		return getConstString(offset + 10, $text);
	}

	/**
	 *  テキスト.<p>
	 *
	 */
	public void text(String value) {
		setConstString(offset + 10, $text, value);
	}


	/**
	 *  数値.<p>
	 *
	 */
	public MCNumber num() {
		return getConstNumber(offset + 11, $num);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(MCNumber value) {
		setConstNumber(offset + 11, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(int value) {
		setConstNumber(offset + 11, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(long value) {
		setConstNumber(offset + 11, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(float value) {
		setConstNumber(offset + 11, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(double value) {
		setConstNumber(offset + 11, $num, value);
	}


	/**
	 *  チェックボックス.<p>
	 *
	 */
	public boolean check() {
		return getConstBoolean(offset + 12, $check);
	}

	/**
	 *  チェックボックス.<p>
	 *
	 */
	public void check(boolean value) {
		setConstBoolean(offset + 12, $check, value);
	}


	/**
	 *  日付.<p>
	 *
	 */
	public MCTimestamp date() {
		return getConstTimestamp(offset + 13, $date);
	}

	/**
	 *  日付.<p>
	 *
	 */
	public void date(MCTimestamp value) {
		setConstTimestamp(offset + 13, $date, value);
	}


	public String getString(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($col_id.equalsIgnoreCase(name)) {
			return col_id();
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			return col_nm();
		}
		if ($scr_itm_id.equalsIgnoreCase(name)) {
			return scr_itm_id();
		}
		if ($md_itm_id.equalsIgnoreCase(name)) {
			return md_itm_id();
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			return data_typ();
		}
		if ($init_val.equalsIgnoreCase(name)) {
			return init_val();
		}
		if ($text.equalsIgnoreCase(name)) {
			return text();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		if ($editable_flg.equalsIgnoreCase(name)) {
			return editable_flg();
		}
		if ($require_flg.equalsIgnoreCase(name)) {
			return require_flg();
		}
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($col_id.equalsIgnoreCase(name)) {
			return col_id();
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			return col_nm();
		}
		if ($scr_itm_id.equalsIgnoreCase(name)) {
			return scr_itm_id();
		}
		if ($md_itm_id.equalsIgnoreCase(name)) {
			return md_itm_id();
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			return data_typ();
		}
		if ($init_val.equalsIgnoreCase(name)) {
			return init_val();
		}
		if ($text.equalsIgnoreCase(name)) {
			return text();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($editable_flg.equalsIgnoreCase(name)) {
			return editable_flg();
		}
		if ($require_flg.equalsIgnoreCase(name)) {
			return require_flg();
		}
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($col_id.equalsIgnoreCase(name)) {
			col_id(value);
			return;
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			col_nm(value);
			return;
		}
		if ($scr_itm_id.equalsIgnoreCase(name)) {
			scr_itm_id(value);
			return;
		}
		if ($md_itm_id.equalsIgnoreCase(name)) {
			md_itm_id(value);
			return;
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			data_typ(value);
			return;
		}
		if ($init_val.equalsIgnoreCase(name)) {
			init_val(value);
			return;
		}
		if ($text.equalsIgnoreCase(name)) {
			text(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($editable_flg.equalsIgnoreCase(name)) {
			editable_flg(value);
			return;
		}
		if ($require_flg.equalsIgnoreCase(name)) {
			require_flg(value);
			return;
		}
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($col_id.equalsIgnoreCase(name)) {
			col_id(value);
			return;
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			col_nm(value);
			return;
		}
		if ($scr_itm_id.equalsIgnoreCase(name)) {
			scr_itm_id(value);
			return;
		}
		if ($md_itm_id.equalsIgnoreCase(name)) {
			md_itm_id(value);
			return;
		}
		if ($data_typ.equalsIgnoreCase(name)) {
			data_typ(value);
			return;
		}
		if ($init_val.equalsIgnoreCase(name)) {
			init_val(value);
			return;
		}
		if ($text.equalsIgnoreCase(name)) {
			text(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($editable_flg.equalsIgnoreCase(name)) {
			editable_flg(value);
			return;
		}
		if ($require_flg.equalsIgnoreCase(name)) {
			require_flg(value);
			return;
		}
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

