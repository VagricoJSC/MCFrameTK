package mcframe.clientFSBA.FSBAP0780;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Srch"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class SrchR_FW_A extends MCConstRow {

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $user_id = "user_id";
	/**
	 *  会社レベル権限制御.<p>
	 *
	 */
	public static final String $acl_co = "acl_co";
	/**
	 *  システムレベル権限制御.<p>
	 *
	 */
	public static final String $acl_sys = "acl_sys";


	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta user_id_META = createCommonMeta($user_id, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta acl_co_META = createCommonMeta($acl_co, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta acl_sys_META = createCommonMeta($acl_sys, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<SrchR> constMetas = new ConstMetaList<SrchR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			mining_id_META,
			user_id_META,
			acl_co_META,
			acl_sys_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected SrchR_FW_A(ConstMetaList<? extends SrchR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SrchR clone() {
		return (SrchR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SrchR createInstance() {
		return (SrchR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SrchR getValues(String... names) {
		return (SrchR) super.getValues(names);
	}



	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 0, $mining_id);
	}

	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 0, $mining_id, value);
	}


	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String user_id() {
		return getConstString(offset + 1, $user_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void user_id(String value) {
		setConstString(offset + 1, $user_id, value);
	}


	/**
	 *  会社レベル権限制御.<p>
	 *
	 */
	public boolean acl_co() {
		return getConstBoolean(offset + 2, $acl_co);
	}

	/**
	 *  会社レベル権限制御.<p>
	 *
	 */
	public void acl_co(boolean value) {
		setConstBoolean(offset + 2, $acl_co, value);
	}


	/**
	 *  システムレベル権限制御.<p>
	 *
	 */
	public boolean acl_sys() {
		return getConstBoolean(offset + 3, $acl_sys);
	}

	/**
	 *  システムレベル権限制御.<p>
	 *
	 */
	public void acl_sys(boolean value) {
		setConstBoolean(offset + 3, $acl_sys, value);
	}


	public String getString(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($acl_co.equalsIgnoreCase(name)) {
			return acl_co();
		}
		if ($acl_sys.equalsIgnoreCase(name)) {
			return acl_sys();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($user_id.equalsIgnoreCase(name)) {
			return user_id();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($acl_co.equalsIgnoreCase(name)) {
			return acl_co();
		}
		if ($acl_sys.equalsIgnoreCase(name)) {
			return acl_sys();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($acl_co.equalsIgnoreCase(name)) {
			acl_co(value);
			return;
		}
		if ($acl_sys.equalsIgnoreCase(name)) {
			acl_sys(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($user_id.equalsIgnoreCase(name)) {
			user_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($acl_co.equalsIgnoreCase(name)) {
			acl_co(value);
			return;
		}
		if ($acl_sys.equalsIgnoreCase(name)) {
			acl_sys(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

