package mcframe.clientFSBA.FSBAP0780;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_MiningDtl]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0760.Srch01.UP.BLOCK0")){
			return FS_FSBAL0760_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK0")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK1")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK2")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK3")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK3();
		}
		else if (id.equals("FS.FSBAL0760.Upd01.UP.BLOCK0")){
			return FS_FSBAL0760_Upd01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Upd01.UP.BLOCK1")){
			return FS_FSBAL0760_Upd01_UP_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0760.Upd01.UP.BLOCK2")){
			return FS_FSBAL0760_Upd01_UP_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0760.Upd01.UP.BLOCK3")){
			return FS_FSBAL0760_Upd01_UP_BLOCK3();
		}
		else if (id.equals("FS.FSBAL0760.Upd01.DOWN.BLOCK0")){
			return FS_FSBAL0760_Upd01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Ins01.UP.BLOCK0")){
			return FS_FSBAL0760_Ins01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Ins01.UP.BLOCK1")){
			return FS_FSBAL0760_Ins01_UP_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0760.Ins01.UP.BLOCK2")){
			return FS_FSBAL0760_Ins01_UP_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0760.Ins01.UP.BLOCK3")){
			return FS_FSBAL0760_Ins01_UP_BLOCK3();
		}
		else if (id.equals("FS.FSBAL0760.Ins01.DOWN.BLOCK0")){
			return FS_FSBAL0760_Ins01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Ins02.UP.BLOCK0")){
			return FS_FSBAL0760_Ins02_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Ins02.UP.BLOCK1")){
			return FS_FSBAL0760_Ins02_UP_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0760.Ins02.UP.BLOCK2")){
			return FS_FSBAL0760_Ins02_UP_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0760.Ins02.UP.BLOCK3")){
			return FS_FSBAL0760_Ins02_UP_BLOCK3();
		}
		else if (id.equals("FS.FSBAL0760.Ins02.DOWN.BLOCK0")){
			return FS_FSBAL0760_Ins02_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
				
	
	static final MCOperationInfo FS_FSBAL0760_Srch01_INFO = new MCOperationInfo("FS", "FSBAL0760", "Srch01", "000001", new PDef());

	public static MCContainerDef FS_FSBAL0760_Srch01_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("acl_co", "acl_co"),
				MCItemDef.create("acl_sys", "acl_sys")
			}
			,
			MCBlockDef.create("Srch")
		);
	}


	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK0() {
	/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("public_lv", "public_lv"),
				MCItemDef.create("description_text", "description_text"),
				MCItemDef.create("module_id", "module_id"),
				MCItemDef.create("logic_id", "logic_id"),
				MCItemDef.create("operation_id", "operation_id"),
				MCItemDef.create("func_typ", "func_typ"),
				MCItemDef.create("scr_module_id", "scr_module_id"),
				MCItemDef.create("screen_id", "screen_id"),
				MCItemDef.create("gadget_size", "gadget_size"),
				MCItemDef.create("gadget_icon", "gadget_icon"),
				MCItemDef.create("gadget_cache_flg", "gadget_cache_flg"),
				MCItemDef.create("md_module_id", "md_module_id"),
				MCItemDef.create("md_screen_id", "md_screen_id"),
				MCItemDef.create("md_gadget_size", "md_gadget_size"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("MiningParam")
		);
	}
	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK1() {
	/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("col_nm", "col_nm"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("scr_itm_id", "scr_itm_id"),
				MCItemDef.create("md_itm_id", "md_itm_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("require_flg", "require_flg"),
				MCItemDef.create("init_val", "init_val"),
				MCItemDef.create("editable_flg", "editable_flg")
			}
			,
			MCBlockDef.create("Cond")
		);
	}
	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK2() {
	/** Ope.のBlock [Method] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("column_key", "col_id"),
				MCItemDef.create("column_nm", "col_nm"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("sum_info_type", "sum_info_typ"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("rank", "rank_flg"),
				MCItemDef.create("rank_type", "rank_typ"),
				MCItemDef.create("rank_size", "rank_size"),
				MCItemDef.create("date_fmt", "date_fmt"),
				MCItemDef.create("fill_dt", "fill_dt_flg"),
				MCItemDef.create("fill_dt_fm", "fill_dt_fm"),
				MCItemDef.create("fill_dt_to", "fill_dt_to"),
				MCItemDef.create("formula", "formula"),
				MCItemDef.create("dec_place", "dec_place"),
				MCItemDef.create("rounding_mode_type", "round_mode_typ"),
				MCItemDef.create("null_zero", "null_zero"),
				MCItemDef.create("sort_order", "sort_order"),
				MCItemDef.create("sort_type", "sort_typ"),
				MCItemDef.create("chart_type", "graph_typ"),
				MCItemDef.create("row_label", "graph_label_flg"),
				MCItemDef.create("chart_color", "graph_color"),
				MCItemDef.create("disable", "inv_flg")
			}
			,
			MCBlockDef.create("Method")
		);
	}
	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK3() {
	/** Ope.のBlock [SumCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("cond_val", "cond_val"),
				MCItemDef.create("relative_ope", "relative_ope"),
				MCItemDef.create("logic_ope", "logic_ope"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("SumCondParam")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0760_Upd01_INFO = new MCOperationInfo("FS", "FSBAL0760", "Upd01", "000001", new PDef());

	public static MCContainerDef FS_FSBAL0760_Upd01_UP_BLOCK0() {
		/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("public_lv", "public_lv"),
				MCItemDef.create("description_text", "description_text"),
				MCItemDef.create("module_id", "module_id"),
				MCItemDef.create("logic_id", "logic_id"),
				MCItemDef.create("operation_id", "operation_id"),
				MCItemDef.create("func_typ", "func_typ"),
				MCItemDef.create("scr_module_id", "scr_module_id"),
				MCItemDef.create("screen_id", "screen_id"),
				MCItemDef.create("gadget_size", "gadget_size"),
				MCItemDef.create("gadget_icon", "gadget_icon"),
				MCItemDef.create("gadget_cache_flg", "gadget_cache_flg"),
				MCItemDef.create("md_module_id", "md_module_id"),
				MCItemDef.create("md_screen_id", "md_screen_id"),
				MCItemDef.create("md_gadget_size", "md_gadget_size"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Mining")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Upd01_UP_BLOCK1() {
		/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("col_nm", "col_nm"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("scr_itm_id", "scr_itm_id"),
				MCItemDef.create("md_itm_id", "md_itm_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("require_flg", "require_flg"),
				MCItemDef.create("init_val", "init_val"),
				MCItemDef.create("editable_flg", "editable_flg")
			}
			,
			MCBlockDef.create("Cond")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Upd01_UP_BLOCK2() {
		/** Ope.のBlock [Method] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("column_key", "col_id"),
				MCItemDef.create("column_nm", "col_nm"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("sum_info_type", "sum_info_typ"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("rank", "rank_flg"),
				MCItemDef.create("rank_type", "rank_typ"),
				MCItemDef.create("rank_size", "rank_size"),
				MCItemDef.create("date_fmt", "date_fmt"),
				MCItemDef.create("fill_dt", "fill_dt_flg"),
				MCItemDef.create("fill_dt_fm", "fill_dt_fm"),
				MCItemDef.create("fill_dt_to", "fill_dt_to"),
				MCItemDef.create("formula", "formula"),
				MCItemDef.create("dec_place", "dec_place"),
				MCItemDef.create("rounding_mode_type", "round_mode_typ"),
				MCItemDef.create("null_zero", "null_zero"),
				MCItemDef.create("sort_order", "sort_order"),
				MCItemDef.create("sort_type", "sort_typ"),
				MCItemDef.create("chart_type", "graph_typ"),
				MCItemDef.create("row_label", "graph_label_flg"),
				MCItemDef.create("chart_color", "graph_color"),
				MCItemDef.create("disable", "inv_flg")
			}
			,
			MCBlockDef.create("Method")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Upd01_UP_BLOCK3() {
		/** Ope.のBlock [SumCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("cond_val", "cond_val"),
				MCItemDef.create("relative_ope", "relative_ope"),
				MCItemDef.create("logic_ope", "logic_ope"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("SumCondParam")
		);
	}


	public static MCContainerDef FS_FSBAL0760_Upd01_DOWN_BLOCK0() {
	/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Mining")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0760_Ins01_INFO = new MCOperationInfo("FS", "FSBAL0760", "Ins01", "000001", new PDef());

	public static MCContainerDef FS_FSBAL0760_Ins01_UP_BLOCK0() {
		/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("public_lv", "public_lv"),
				MCItemDef.create("description_text", "description_text"),
				MCItemDef.create("module_id", "module_id"),
				MCItemDef.create("logic_id", "logic_id"),
				MCItemDef.create("operation_id", "operation_id"),
				MCItemDef.create("func_typ", "func_typ"),
				MCItemDef.create("scr_module_id", "scr_module_id"),
				MCItemDef.create("screen_id", "screen_id"),
				MCItemDef.create("gadget_size", "gadget_size"),
				MCItemDef.create("gadget_icon", "gadget_icon"),
				MCItemDef.create("gadget_cache_flg", "gadget_cache_flg"),
				MCItemDef.create("md_module_id", "md_module_id"),
				MCItemDef.create("md_screen_id", "md_screen_id"),
				MCItemDef.create("md_gadget_size", "md_gadget_size")
			}
			,
			MCBlockDef.create("Mining")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Ins01_UP_BLOCK1() {
		/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("col_nm", "col_nm"),
				MCItemDef.create("scr_itm_id", "scr_itm_id"),
				MCItemDef.create("md_itm_id", "md_itm_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("require_flg", "require_flg"),
				MCItemDef.create("init_val", "init_val"),
				MCItemDef.create("editable_flg", "editable_flg")
			}
			,
			MCBlockDef.create("Cond")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Ins01_UP_BLOCK2() {
		/** Ope.のBlock [Method] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("column_key", "col_id"),
				MCItemDef.create("column_nm", "col_nm"),
				MCItemDef.create("sum_info_type", "sum_info_typ"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("rank", "rank_flg"),
				MCItemDef.create("rank_type", "rank_typ"),
				MCItemDef.create("rank_size", "rank_size"),
				MCItemDef.create("date_fmt", "date_fmt"),
				MCItemDef.create("fill_dt", "fill_dt_flg"),
				MCItemDef.create("fill_dt_fm", "fill_dt_fm"),
				MCItemDef.create("fill_dt_to", "fill_dt_to"),
				MCItemDef.create("formula", "formula"),
				MCItemDef.create("dec_place", "dec_place"),
				MCItemDef.create("rounding_mode_type", "round_mode_typ"),
				MCItemDef.create("null_zero", "null_zero"),
				MCItemDef.create("sort_order", "sort_order"),
				MCItemDef.create("sort_type", "sort_typ"),
				MCItemDef.create("chart_type", "graph_typ"),
				MCItemDef.create("row_label", "graph_label_flg"),
				MCItemDef.create("chart_color", "graph_color"),
				MCItemDef.create("disable", "inv_flg")
			}
			,
			MCBlockDef.create("Method")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Ins01_UP_BLOCK3() {
		/** Ope.のBlock [SumCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("cond_val", "cond_val"),
				MCItemDef.create("relative_ope", "relative_ope"),
				MCItemDef.create("logic_ope", "logic_ope"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("SumCondParam")
		);
	}


	public static MCContainerDef FS_FSBAL0760_Ins01_DOWN_BLOCK0() {
	/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Mining")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0760_Ins02_INFO = new MCOperationInfo("FS", "FSBAL0760", "Ins02", "000001", new PDef());

	public static MCContainerDef FS_FSBAL0760_Ins02_UP_BLOCK0() {
		/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins02",
			new MCItemDef[]{
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("public_lv", "public_lv"),
				MCItemDef.create("description_text", "description_text"),
				MCItemDef.create("module_id", "module_id"),
				MCItemDef.create("logic_id", "logic_id"),
				MCItemDef.create("operation_id", "operation_id"),
				MCItemDef.create("func_typ", "func_typ"),
				MCItemDef.create("scr_module_id", "scr_module_id"),
				MCItemDef.create("screen_id", "screen_id"),
				MCItemDef.create("gadget_size", "gadget_size"),
				MCItemDef.create("gadget_icon", "gadget_icon"),
				MCItemDef.create("gadget_cache_flg", "gadget_cache_flg"),
				MCItemDef.create("md_module_id", "md_module_id"),
				MCItemDef.create("md_screen_id", "md_screen_id"),
				MCItemDef.create("md_gadget_size", "md_gadget_size")
			}
			,
			MCBlockDef.create("Mining")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Ins02_UP_BLOCK1() {
		/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins02",
			new MCItemDef[]{
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("col_nm", "col_nm"),
				MCItemDef.create("scr_itm_id", "scr_itm_id"),
				MCItemDef.create("md_itm_id", "md_itm_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("require_flg", "require_flg"),
				MCItemDef.create("init_val", "init_val"),
				MCItemDef.create("editable_flg", "editable_flg")
			}
			,
			MCBlockDef.create("Cond")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Ins02_UP_BLOCK2() {
		/** Ope.のBlock [Method] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins02",
			new MCItemDef[]{
				MCItemDef.create("column_key", "col_id"),
				MCItemDef.create("column_nm", "col_nm"),
				MCItemDef.create("sum_info_type", "sum_info_typ"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("rank", "rank_flg"),
				MCItemDef.create("rank_type", "rank_typ"),
				MCItemDef.create("rank_size", "rank_size"),
				MCItemDef.create("date_fmt", "date_fmt"),
				MCItemDef.create("fill_dt", "fill_dt_flg"),
				MCItemDef.create("fill_dt_fm", "fill_dt_fm"),
				MCItemDef.create("fill_dt_to", "fill_dt_to"),
				MCItemDef.create("formula", "formula"),
				MCItemDef.create("dec_place", "dec_place"),
				MCItemDef.create("rounding_mode_type", "round_mode_typ"),
				MCItemDef.create("null_zero", "null_zero"),
				MCItemDef.create("sort_order", "sort_order"),
				MCItemDef.create("sort_type", "sort_typ"),
				MCItemDef.create("chart_type", "graph_typ"),
				MCItemDef.create("row_label", "graph_label_flg"),
				MCItemDef.create("chart_color", "graph_color"),
				MCItemDef.create("disable", "inv_flg")
			}
			,
			MCBlockDef.create("Method")
		);
	}

	public static MCContainerDef FS_FSBAL0760_Ins02_UP_BLOCK3() {
		/** Ope.のBlock [SumCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins02",
			new MCItemDef[]{
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("cond_val", "cond_val"),
				MCItemDef.create("relative_ope", "relative_ope"),
				MCItemDef.create("logic_ope", "logic_ope"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("SumCondParam")
		);
	}


	public static MCContainerDef FS_FSBAL0760_Ins02_DOWN_BLOCK0() {
	/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Ins02",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Mining")
		);
	}
	//FMCB DEF_CLASSES END
}

