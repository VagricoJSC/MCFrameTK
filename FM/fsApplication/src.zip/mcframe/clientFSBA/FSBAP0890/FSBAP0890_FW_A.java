package mcframe.clientFSBA.FSBAP0890;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0890"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0890_FW_A extends MCRootPanel{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0890";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	// [Cnd]ブロックの項目のField定義
	public MCTextField Cnd_label = null;
	// [List]ブロック関連のField定義
	public MCPanel ListPanel = null;
	public MCScrollPane ListScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0890.ListR> ListTable = null;
	// [List]ブロックの項目のField定義
	public MCColumnConfig columnList_label = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0890.CndR aCndR;
	/** [List]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0890.ListR> aListL;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFSBA.FSBAP0890.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0890.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0890.CndR createCndR() {
		return mcframe.clientFSBA.FSBAP0890.CndR.create();
	}

	/**
	 * コピーによってaListLを設定します。
	 *
	 * aListLのインスタンスは変更されません。
	 *
	 * @param dataset ListL
	 */
	public void setListL(MCList<mcframe.clientFSBA.FSBAP0890.ListR> aList) {
		if (getListL() != aList) {
			getListL().setAll(aList);
		}
	}

	/**
	 * [List]ブロックのコンテナaListLを返します。
	 *
	 * @return ListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0890.ListR> getListL() {
		return aListL;
	}

	/**
	 * aListRを作成します。
	 *
	 * @return ListR
	 */
	public mcframe.clientFSBA.FSBAP0890.ListR createListR() {
		return mcframe.clientFSBA.FSBAP0890.ListR.create();
	}

	/**
	 * aListLを作成します。
	 *
	 * @return ListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0890.ListR> createListL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0890.ListR.class);
	}

	/**
	 * ListTableを初期化します。
	 */
	protected void createListTable(){
		if(ListTable == null){
			ListTable = beansFactory.createTable2("List.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getListL())) ret.add(getListL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getListL()) return "List";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("List")) return getListL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(ListPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0890_FW_A() {
		aCndR = createCndR();
		aListL = createListL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0890_FW_A(String name) {
		aCndR = createCndR();
		aListL = createListL();
		createListTable();
		ListTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0890_FW.jbCreateCnd((FSBAP0890)this);
		FSBAP0890_FW.jbCreateList((FSBAP0890)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FSBAP0890 p) {
	}

	/**
	 * [List]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateList(FSBAP0890 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0890 create(){
		FSBAP0890 p = new FSBAP0890();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0890 create(String name){
		FSBAP0890 p = new FSBAP0890(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0890_FW.jbfInitCnd((FSBAP0890)this);
		FSBAP0890_FW.jbfInitList((FSBAP0890)this);
		FSBAP0890_FW.jbInitCnd((FSBAP0890)this);
		FSBAP0890_FW.jbInitList((FSBAP0890)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FSBAP0890 p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		// ブロックの項目の初期化
		p.Cnd_label = p.beansFactory.createTextField("Cnd.label");
	}

	/**
	 * [List]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitList(FSBAP0890 p) {
		// ブロック関連の初期化
		p.ListPanel = p.beansFactory.createPanel("List");
		p.ListScrollPane = p.beansFactory.createScrollPane("List.scroll");
		p.createListTable();
		// ブロックの項目の初期化
		p.columnList_label = p.beansFactory.createTableColumn("List.label", MCColumnType.TEXT);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FSBAP0890 p) {
		// ブロック関連の初期化
		p.add(p.CndPanel);
		p.setFirstBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.ListPanel);
		p.CndPanel.setValueCheck(false);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.CndPanel.add(p.Cnd_label);
		p.CndPanel.setFirstBeans(p.Cnd_label);
		p.Cnd_label.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0890.CndR.label_META);
	}

	/**
	 * [List]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitList(FSBAP0890 p) {
		// ブロック関連の初期化
		p.add(p.ListPanel);
		p.ListPanel.add(p.ListScrollPane);
		p.ListPanel.setFirstBeans(p.ListTable);
		p.ListScrollPane.setViewportView(p.ListTable);
		p.ListTable.setList(p.getListL());
		p.ListPanel.setValueCheck(false);
		p.ListPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0890_FW.mcInitCnd((FSBAP0890)this);
		FSBAP0890_FW.mcInitList((FSBAP0890)this);

		// [INIT]ステータスのモードの設定
		FSBAP0890_FW.statusInitINIT_Cnd((FSBAP0890)this);
		FSBAP0890_FW.statusInitINIT_List((FSBAP0890)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FSBAP0890 p) {
		p.Cnd_label.setListListener(p);
		p.Cnd_label.addAllListener(p);
	}

	/**
	 *  [List]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitList(FSBAP0890 p) {
		p.ListTable.addAllListener(p);
		p.columnList_label.addAllListener(p);
		p.columnList_label.setListListener(p);
	}

	/**
	 * [INIT]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Cnd(FSBAP0890 p){
		p.Cnd_label.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitINIT_List(FSBAP0890 p){
		p.columnList_label.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0890_FW.setTableConfigList((FSBAP0890)this);
	}

	/**
	 * [List]ブロックのTableの設定
	 */
	protected static void setTableConfigList(FSBAP0890 p) {
		p.columnList_label.setMeta(mcframe.clientFSBA.FSBAP0890.ListR.label_META);
		p.ListTable.addColumnConfig(p.columnList_label);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListTable) return doList_VC(info);
		if (vc == Cnd_label) return doCnd_label_VC(info);
		if (vc == columnList_label) return doList_label_VC(info);
		return true;
	}

	/**
	 * [List]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[label]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_label_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[label]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_label_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListTable) doList_NC(info);
		else if (nc == Cnd_label) doCnd_label_NC(info);
		else if (nc == columnList_label) doList_label_NC(info);
	}

	/**
	 * [List]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[label]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_label_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[label]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_label_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListTable) doList_NE(info);
		else if (ne == Cnd_label) doCnd_label_NE(info);
		else if (ne == columnList_label) doList_label_NE(info);
	}

	/**
	 * [List]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[label]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_label_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[label]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_label_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListTable) doList_NX(info);
		else if (nx == Cnd_label) doCnd_label_NX(info);
		else if (nx == columnList_label) doList_label_NX(info);
	}

	/**
	 * [List]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[label]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_label_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[label]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_label_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_label) doCnd_label_LC(info);
		else if (lc == columnList_label) doList_label_LC(info);
	}

	/**
	 * [Cnd]パネルの[label]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_label_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[label]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_label_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}