package mcframe.clientFSBA.FSBAP0890;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListConfig;
import mcframe.clientCore.beans.popup.MCPopupConfig;
import mcframe.clientCore.beans.popup.MCCustomPopup;
import mcframe.clientCore.beans.popup.MCCustomPopupPanel;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0890"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0890_FW extends FSBAP0890_FW_A implements MCCustomPopupPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * ポップアップです。
	 */
	private MCCustomPopup _popup;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0890_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0890_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void requestCloseWindow() {
		Component c = (Component)getCustomPopup().getCustomBeans();
		getCustomPopup().setVisible(false);
		c.requestFocus();
	}
	
	@Override
	protected void customInit() {
		super.customInit();
	
		MCPopupConfig c = new MCPopupConfig();
		c.ignorePanelPopup(true);
		setPopupConfig(c);
	}
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	/**
	 * MCLayouterの指定文字列を返します。
	 */
	@Override
	public String getLayoutKey() {
		return "S";
	}
	
	/**
	 * 初期化します。
	 * 
	 * @param popup ポップアップ
	 */
	@Override
	public void afterInit(MCCustomPopup popup) {
		
		_popup = popup;
		MCLinkBeans t = popup.getLinkBean();
		
		if (t != null) {
			MCList<MCRow> tl = t.doListEvent(MCListConfig.LIST);
			MCListConfig cc = null;
			if (tl == null) {
				return ;
			}
			cc = t.getListConfig();
			if (cc == null) {
				return ;
			}
			String[] listlogiccols = cc.getPutter().getColumns();
			
			if (listlogiccols != null && listlogiccols.length > 0) {
				String[] viewcols = null;
				if (t instanceof AbsMCComboBox) {
					AbsMCComboBox cb = (AbsMCComboBox)t;
					viewcols = cb.getListVisibleColumn();
				}
				MCList<ListR> l = getListL();
				l.clear();
				for (MCRow r : tl) {
					ListR lr = l.createRow();
					String view = null;
					if (r.contains(MCListLogic.getViewColumnName())) {
						view = r.getStringNE(MCListLogic.getViewColumnName());
					}
					if (view == null) {
						view = (String)cc.format((MCLinkBeans)t, r, viewcols);
					}
					lr.label(view);
					lr.key(r.getStringNE(listlogiccols[0]));
					l.add(lr);
				}
			}
		}
	}
	
	@Override
	public boolean beforeOpen() {
		if (super.beforeOpen()) {

			//MCGeneralLayoutのrelayoutで推奨サイズとして最小サイズが設定されるため調整する。
			setPreferredSize(null);
			
			customizeTableView();
			customizeCndLabelKey();
			customizeTableKey();
			return true;
		}
		return false;
	}
	
	@Override
	public void afterOpen() {
		super.afterOpen();

		if (getListL().size() > 0) {
			ListTable.selectRowNoFocus(0);
			ListTable.setPreferredSize(null);
			columnList_label.adjustWidth();
			ListTable.setPreferredSize(new Dimension(columnList_label.getAdjustedWidth(), ListTable.getRowHeight() * getListL().size()));
		}
		Cnd_label.setAutoFocus(false);
	}
	
	/**
	 * テーブルの表示を調整します。
	 */
	private void customizeTableView() {
		ListTable.setTableHeader(null);
		ListTable.setRowNumberColumnVisible(false);
		ListTable.setStatusColumnVisible(false);
	}
	
	private void customizeCndLabelKey() {
		KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0); 
		for (int i : new int[] {
				JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT, JComponent.WHEN_FOCUSED
		}) {
			InputMap tim = Cnd_label.getInputMap(i);
			tim.put(enter, "none");
		}
		Cnd_label.setFocusTraversalKeysEnabled(false);
		Cnd_label.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(java.awt.event.KeyEvent e) {
				super.keyPressed(e);
				switch(e.getKeyCode()) {
					case java.awt.event.KeyEvent.VK_ENTER:
					case java.awt.event.KeyEvent.VK_TAB:
						Cnd_label.transferFocus();
						javax.swing.SwingUtilities.invokeLater(() -> {String label = getCndR().label();
						if (isNull(label)) {
							return;
						}
						// 一覧の1行目のフォーカス移動の後にフォーカス移動する
						javax.swing.SwingUtilities.invokeLater(() -> {
							for(ListR r : getListL()){
								if (r.label().startsWith(label)) {
									javax.swing.SwingUtilities.invokeLater(() -> {
										ListTable.selectRow(r.getGUIIndex());
									});
									return;
								}
							}
						});
						});
						break;
					default:
				}
			}
		});
	} 
	
	/**
	 * テーブルのキーイベントを調整します。
	 */
	private void customizeTableKey() {
		KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0); 
		KeyStroke tab = KeyStroke.getKeyStroke(KeyEvent.VK_TAB, 0); 
		KeyStroke stab = KeyStroke.getKeyStroke(KeyEvent.VK_TAB, java.awt.event.InputEvent.SHIFT_DOWN_MASK); 
		for (int i : new int[] {
				JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT, JComponent.WHEN_FOCUSED
		}) {
			InputMap tim = ListTable.getInputMap(i);
			tim.put(enter, "none");
			tim.put(tab, "none");
			tim.put(stab, "none");
		}
		ListTable.setFocusTraversalKeysEnabled(false);
		ListTable.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(java.awt.event.KeyEvent e) {
				super.keyPressed(e);
				switch(e.getKeyCode()) {
					case java.awt.event.KeyEvent.VK_ENTER:
						javax.swing.SwingUtilities.invokeLater(() -> {
							doEnterEvent(ListTable.getMCSelectedRow());
						});
						break;
					case java.awt.event.KeyEvent.VK_TAB:
						Cnd_label.mcRequestFocus();
					default:
				}
			}
		});
	}
	
	@Override
	public void doDCEvent(mcframe.clientCore.event.MCDCBeans compo,
			mcframe.clientCore.event.MCEventInfo info) {
		super.doDCEvent(compo, info);
		doEnterEvent(info.getEventIndex());
	}
	
	public MCCustomPopup getCustomPopup() {
		return _popup;
	}
	
	private void doEnterEvent(int index) {
		if (index >= 0) {
			ListR r = getListL().get(index);
			_popup.setViewValue(r.key());
			requestCloseWindow();
		}
	}

}