package mcframe.clientFSBA.FSBAP0750;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0170.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSUB.FSUBP0000.IfCompCondBase;
import mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D_FW.FSUBP_InfoDtlCellConfig;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;

import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.table.MCRowSignal;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_RowSignalParts"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_RowSignalParts_FW extends FSBAP_RowSignalParts_FW_A
		implements IfCompCondBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 設定対象のテーブルです。
	 */
	protected MCTable<?> _target_table = null;

	/**
	 * 設定対象のシグナルです。
	 */
	protected int _target_signal = MCRowSignal.NONE;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_RowSignalParts_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_RowSignalParts_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[InfoBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_radd(MCEventInfo info) {
		insertRow(InfoDtlTable);
	}

	/**
	 * Panel[InfoBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doInfoBtn_rdel(MCEventInfo info) {
		deleteRow(InfoDtlTable);
	}

	/**
	 * Panel[InfoBtn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_select_all(MCEventInfo info) {
		InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(false);
		try {
			setValueEx(columnInfoDtl_disable, true);
		}
		finally {
			InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(true);
			InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
		}
	}

	/**
	 * Panel[InfoBtn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_deselect_all(MCEventInfo info) {
		InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(false);
		try {
			setValueEx(columnInfoDtl_disable, false);
		}
		finally {
			InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(true);
			InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
		}
	}

	/**
	 * Panel[InfoBtn]のボタン[rcopy]の押下時の処理
	 */
	@Override
	public void doInfoBtn_rcopy(MCEventInfo info) {
		InfoDtlR o = copyRow(InfoDtlTable);
		if (isNull(o)) {
			return;
		}
		int i = o.getGUIIndex();
		for (MCColumnConfig c : InfoDtl_cond_p_PPanel.getConditionValueColumnConfigs()) {
			setValueEx(c, i, null);
		}
	}

	/**
	 * 登録処理の実行可否を判断します。<p>
	 * 登録処理を続行する場合は true を返します。
	 * 
	 * @return 登録処理を中断する場合は false
	 */
	public MCMessageList checkForUpd() {
		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		// フィルタ情報の必須項目をチェックする
		MCMessageList m = new MCMessageList();
		MCRowFilter cond = getTargetTable().getRowSignal().createCondition();

		MCList<InfoDtlR> dtlL = exceptEmpty(getInfoDtlL());
		for (InfoDtlR dtlR : dtlL) {
			if (dtlR.isEmpty() || dtlR.isStatusDelete()) {
				continue;
			}
			
			// 必須入力チェック
			MCMessageList chk = checkReq(InfoDtlTable, dtlR);
			if (chk.size() > 0) {
				m.addAll(chk);
				continue;
			}

			// 判断条件チェック
			chk = InfoDtl_cond_p_PPanel.checkCondition(cond, dtlR.cond_p());
			if (chk.size() > 0) {
				m.addAll(chk);
			}
		}
		return m;
	}

	/**
	 * 適用処理の実行可否を判断します。<p>
	 * 適用処理を続行する場合は true を返します。
	 *
	 * @return 適用処理を中断する場合は false
	 */
	public boolean checkForApply() {

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		MCList<InfoDtlR> l = exceptEmpty(getInfoDtlL());

		// シグナルの必須項目をチェックする
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		return true;

	}

	/**
	 * 空行のステータスをクリアします。
	 * 
	 * @param lists リスト
	 */
	protected void clearEmptyRowStatus(MCList<?>... lists) {
		for (MCList<?> l : lists) {
			for (MCRow o : l) {
				if (o.isEmpty()) {
					o.clearAll();
					o.setStatus(MCRow.GUICREATE);
				}
			}
		}
	}

	@Override
	public void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
	}

	@Override
	public void fillSpaceForOpen() {
		super.fillSpaceForOpen();

		InfoDtlTable.fillSpace();
		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}

	/**
	 * この画面の情報を初期化します。
	 */
	public void setInitData() {
		MCList<InfoDtlR> dtlL = getInfoDtlL();

		// 最初にデータをクリア
		dtlL.clear();

		// シグナル情報を追加
		MCRowSignal signal = getTargetTable().getRowSignal();
		List<MCRowFilter> conds = signal.getConditionList(_target_signal);
		addConditionRow(dtlL, conds);

		if (dtlL.size() <= 0) {
			// ユーザ設定がない場合、デフォルトのシグナル情報を追加
			// ※とりあえずデフォルトはやらない
		}

		// 最後にカラム幅を調整
		InfoDtlTable.adjustWidth();
	}

	/**
	 * 設定情報をリソースに保存します。
	 *
	 * @param rs 保存するRowSignal
	 */
	public void writeResource(MCRowSignal rs) {
		for (InfoDtlR d : getInfoDtlL()) {
			if (d.isEmpty() || d.isStatusDelete()) {
				continue;
			}

			int signal = getTargetSignal();
			Comparable<?> v = InfoDtl_cond_p_PPanel.getConditionValue(d.cond_p());

			MCRowFilter cond = new MCRowFilter();
			cond.setDisable(d.disable());
			if (cond.setCondition(d.column_key(), MCDataType.valueOf(d.data_type()), v,
					d.relative_type(), d.logic_type())) {
				rs.addCondition(signal, cond);
			}
		}
	}

	/**
	 * テーブルのシグナル条件から、リストに行を追加します。
	 *
	 * @param dtlL 追加するリスト
	 * @param conds シグナルの条件
	 */
	public void addConditionRow(MCList<InfoDtlR> dtlL, List<MCRowFilter> conds) {
		conds.forEach(cond -> {
			InfoDtlR dtlR = dtlL.createRow();
			InfoDtl_cond_p_PPanel.addConditionRow(dtlR.cond_p(), cond);
			dtlL.add(dtlR);
		});
	}

	/**
	 * 設定対象のテーブルとシグナルを設定します。
	 * 
	 * @param table テーブル
	 * @param signal シグナル
	 */
	public void setTargetTable(MCTable<?> table, int signal) {
		_target_table = table;
		_target_signal = signal;

		// 計算式の初期化
		InfoDtl_cond_p_PPanel.initExpressionBuilder();
	}

	/**
	 * 設定対象のテーブルを返します。<p>
	 * 対象が設定されていない場合は null を返します。
	 *
	 * @return 設定対象のテーブル、または null
	 */
	@Override
	public MCTable<?> getTargetTable() {
		return _target_table;
	}

	@Override
	public String getPersonalizedType() {
		return ROW_SIGNAL_PANEL;
	}

	/**
	 * 設定対象のシグナルを返します。
	 * 対象が設定されていない場合は MCRowSignal.NONE を返します。
	 * 
	 * @return 設定対象のシグナル
	 */
	public int getTargetSignal() {
		return _target_signal;
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		InfoDtlTable.setCellConfig(createInfoDtlCellConfig());
	}

	/**
	 * 情報テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 情報テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createInfoDtlCellConfig() {
		return new FSBAP_InfoDtlCellConfig();
	}

	/**
	 * 情報テーブルに設定するセルコンフィグです。
	 */
	public class FSBAP_InfoDtlCellConfig extends FSUBP_InfoDtlCellConfig {
		FSBAP_InfoDtlCellConfig() {
			super(InfoDtl_cond_p_PPanel);
		}
	}

	/**
	 *　条件値に変更があるかを判断します。<p>
	 *　条件値に変更がある場合はtrueを返します。
	 * @return 変更がない場合はfalseを返します。
	 */
	public boolean infoDataChanged() {
		return !getInfoDtlL().isStatusNone();
	}

	/**
	 * 条件値を返します。
	 *
	 * 日時項目の条件値は保存用の文字列が返ることに注意してください。
	 *
	 * @param infoDtlR 条件のRow
	 * @return 条件値
	 */
	public Comparable<?> getConditionValue(
			mcframe.clientFSUB.FSUBP0170.InfoDtlR infoDtlR) {
		Comparable<?> v = null;

		MCDataType dy = MCDataType.valueOf(infoDtlR.data_type());
		if (dy.isDateType()) {
			// 日時
			v = MCRowFilter.getDateSaveValue(infoDtlR.date_diff_key(),
					infoDtlR.date_field_type(), infoDtlR.date_diff(), infoDtlR.date());
		}
		else {
			// 日時以外
			List<MCColumnConfig> clist = getConditionValueColumnConfig(dy);
			v = infoDtlR.getValue(clist.get(0).getRowColumnName());
		}
		return v;
	}

	/**
	 * 条件値を入力するテーブルカラムを返します。
	 * 指定されたデータ型の値を入力するためのテーブルカラムを返します。<p>
	 * テーブルカラムが見つからなかった場合は null を返します。
	 *
	 * @param type データ型
	 * @return テーブルカラム、または null
	 */
	public List<MCColumnConfig> getConditionValueColumnConfig(MCDataType type) {
		List<MCColumnConfig> l = new ArrayList<MCColumnConfig>();
		if (type == null) {
		}
		else switch (type) {
			case STRING:
				l.add(columnInfoDtl_text);
				break;
			case NUMBER:
				l.add(columnInfoDtl_number);
				break;
			case DATE:
			case TIMESTAMP:
				l.add(columnInfoDtl_date_diff_nm);
				l.add(columnInfoDtl_date_field_type_nm);
				l.add(columnInfoDtl_date_diff);
				l.add(columnInfoDtl_date);
				break;
			case BOOLEAN:
				l.add(columnInfoDtl_check);
				break;
			default:
				break;
		}
		return l;
	}
}