package mcframe.clientFSBA.FSBAP0750;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_RowSignalParts"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_RowSignalParts_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0750";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [InfoDtl]ブロック関連のField定義
	public MCPanel InfoDtlPanel = null;
	public MCScrollPane InfoDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0750.InfoDtlR> InfoDtlTable = null;
	// [InfoDtl]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D InfoDtl_cond_p_PPanel;
	public MCColumnConfig columnInfoDtl_disable;// [InfoDtl]の[cond_p.disable]を[columnInfoDtl_disable]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_logic_type_nm;// [InfoDtl]の[cond_p.logic_type_nm]を[columnInfoDtl_logic_type_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_logic_type;// [InfoDtl]の[cond_p.logic_type]を[columnInfoDtl_logic_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_column_nm;// [InfoDtl]の[cond_p.column_nm]を[columnInfoDtl_column_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_column_key;// [InfoDtl]の[cond_p.column_key]を[columnInfoDtl_column_key]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_data_type;// [InfoDtl]の[cond_p.data_type]を[columnInfoDtl_data_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_diff_nm;// [InfoDtl]の[cond_p.date_diff_nm]を[columnInfoDtl_date_diff_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_diff_key;// [InfoDtl]の[cond_p.date_diff_key]を[columnInfoDtl_date_diff_key]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_relative_type_nm;// [InfoDtl]の[cond_p.relative_type_nm]を[columnInfoDtl_relative_type_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_relative_type;// [InfoDtl]の[cond_p.relative_type]を[columnInfoDtl_relative_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_number;// [InfoDtl]の[cond_p.number]を[columnInfoDtl_number]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_field_type_nm;// [InfoDtl]の[cond_p.date_field_type_nm]を[columnInfoDtl_date_field_type_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_field_type;// [InfoDtl]の[cond_p.date_field_type]を[columnInfoDtl_date_field_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_diff;// [InfoDtl]の[cond_p.date_diff]を[columnInfoDtl_date_diff]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date;// [InfoDtl]の[cond_p.date]を[columnInfoDtl_date]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_text;// [InfoDtl]の[cond_p.text]を[columnInfoDtl_text]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_check;// [InfoDtl]の[cond_p.check]を[columnInfoDtl_check]としてエイリアス定義。
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton InfoBtn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton InfoBtn_rdel = null;
	/**
	 *  全選択.<p>
	 *
	 */
	public MCButton InfoBtn_select_all = null;
	/**
	 *  全解除.<p>
	 *
	 */
	public MCButton InfoBtn_deselect_all = null;
	/**
	 *  行コピー.<p>
	 *
	 */
	public MCButton InfoBtn_rcopy = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> aInfoDtlL;

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0750.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0750.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0750.InfoDtlR.class);
	}

	/**
	 * InfoDtlTableを初期化します。
	 */
	protected void createInfoDtlTable(){
		if(InfoDtlTable == null){
			InfoDtlTable = beansFactory.createTable2("InfoDtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(InfoDtlPanel);
		ret.add(InfoBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_RowSignalParts_FW_A() {
		aInfoDtlL = createInfoDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_RowSignalParts_FW_A(String name) {
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_RowSignalParts_FW.jbCreateInfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.jbCreateInfoBtn((FSBAP_RowSignalParts)this);
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP_RowSignalParts p) {
		p.InfoDtl_cond_p_PPanel = mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.create(mcframe.clientFSBA.FSBAP0750.InfoDtlR.$cond_p);
		p.InfoDtl_cond_p_PPanel.setName("InfoDtl.cond_p");
		p.columnInfoDtl_disable = p.InfoDtl_cond_p_PPanel.columnInfoDtl_disable;
		p.columnInfoDtl_disable.addAliasName("InfoDtl.disable", p);
		p.columnInfoDtl_logic_type_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type_nm;
		p.columnInfoDtl_logic_type_nm.addAliasName("InfoDtl.logic_type_nm", p);
		p.columnInfoDtl_logic_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type;
		p.columnInfoDtl_logic_type.addAliasName("InfoDtl.logic_type", p);
		p.columnInfoDtl_column_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_nm;
		p.columnInfoDtl_column_nm.addAliasName("InfoDtl.column_nm", p);
		p.columnInfoDtl_column_key = p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_key;
		p.columnInfoDtl_column_key.addAliasName("InfoDtl.column_key", p);
		p.columnInfoDtl_data_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_data_type;
		p.columnInfoDtl_data_type.addAliasName("InfoDtl.data_type", p);
		p.columnInfoDtl_date_diff_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm;
		p.columnInfoDtl_date_diff_nm.addAliasName("InfoDtl.date_diff_nm", p);
		p.columnInfoDtl_date_diff_key = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_key;
		p.columnInfoDtl_date_diff_key.addAliasName("InfoDtl.date_diff_key", p);
		p.columnInfoDtl_relative_type_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_relative_type_nm;
		p.columnInfoDtl_relative_type_nm.addAliasName("InfoDtl.relative_type_nm", p);
		p.columnInfoDtl_relative_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_relative_type;
		p.columnInfoDtl_relative_type.addAliasName("InfoDtl.relative_type", p);
		p.columnInfoDtl_number = p.InfoDtl_cond_p_PPanel.columnInfoDtl_number;
		p.columnInfoDtl_number.addAliasName("InfoDtl.number", p);
		p.columnInfoDtl_date_field_type_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_field_type_nm;
		p.columnInfoDtl_date_field_type_nm.addAliasName("InfoDtl.date_field_type_nm", p);
		p.columnInfoDtl_date_field_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_field_type;
		p.columnInfoDtl_date_field_type.addAliasName("InfoDtl.date_field_type", p);
		p.columnInfoDtl_date_diff = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff;
		p.columnInfoDtl_date_diff.addAliasName("InfoDtl.date_diff", p);
		p.columnInfoDtl_date = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date;
		p.columnInfoDtl_date.addAliasName("InfoDtl.date", p);
		p.columnInfoDtl_text = p.InfoDtl_cond_p_PPanel.columnInfoDtl_text;
		p.columnInfoDtl_text.addAliasName("InfoDtl.text", p);
		p.columnInfoDtl_check = p.InfoDtl_cond_p_PPanel.columnInfoDtl_check;
		p.columnInfoDtl_check.addAliasName("InfoDtl.check", p);
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP_RowSignalParts p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_RowSignalParts create(){
		FSBAP_RowSignalParts p = new FSBAP_RowSignalParts();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_RowSignalParts create(String name){
		FSBAP_RowSignalParts p = new FSBAP_RowSignalParts(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_RowSignalParts_FW.jbfInitInfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.jbfInitInfoBtn((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.jbInitInfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.jbInitInfoBtn((FSBAP_RowSignalParts)this);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP_RowSignalParts p) {
		// ブロック関連の初期化
		p.InfoDtlPanel = p.beansFactory.createPanel("InfoDtl");
		p.InfoDtlScrollPane = p.beansFactory.createScrollPane("InfoDtl.scroll");
		p.createInfoDtlTable();
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP_RowSignalParts p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_radd = p.beansFactory.createButton("InfoBtn.radd", "no_border");
		p.InfoBtn_rdel = p.beansFactory.createButton("InfoBtn.rdel", "no_border");
		p.InfoBtn_select_all = p.beansFactory.createButton("InfoBtn.select_all", "no_border");
		p.InfoBtn_deselect_all = p.beansFactory.createButton("InfoBtn.deselect_all", "no_border");
		p.InfoBtn_rcopy = p.beansFactory.createButton("InfoBtn.rcopy", "no_border");
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP_RowSignalParts p) {
		// ブロック関連の初期化
		p.add(p.InfoDtlPanel);
		p.setLastBeans(p.InfoDtlPanel);
		p.InfoDtlPanel.setNextBeans(p.InfoBtnPanel);
		p.InfoDtlPanel.add(p.InfoDtlScrollPane);
		p.InfoDtlPanel.setLastBeans(p.InfoDtlTable);
		p.InfoDtlScrollPane.setViewportView(p.InfoDtlTable);
		p.InfoDtlTable.setList(p.getInfoDtlL());
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP_RowSignalParts p) {
		// ブロック関連の初期化
		p.add(p.InfoBtnPanel);
		p.InfoBtnPanel.setValueCheck(false);
		p.InfoBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoBtn_radd.setIcon("INSERT_RECORD");
		p.InfoBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.InfoBtnPanel.add(p.InfoBtn_radd);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_radd);
		p.InfoBtn_radd.setNextBeans(p.InfoBtn_rdel);
		p.InfoBtn_rdel.setIcon("DELETE_RECORD");
		p.InfoBtn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.InfoBtnPanel.add(p.InfoBtn_rdel);
		p.InfoBtn_rdel.setNextBeans(p.InfoBtn_select_all);
		p.InfoBtn_select_all.setIcon("SELECT_ALL");
		p.InfoBtn_select_all.setFunctionKey(MCFunctionKey.F13);
		p.InfoBtnPanel.add(p.InfoBtn_select_all);
		p.InfoBtn_select_all.setNextBeans(p.InfoBtn_deselect_all);
		p.InfoBtn_deselect_all.setIcon("DESELECT_ALL");
		p.InfoBtn_deselect_all.setFunctionKey(MCFunctionKey.F14);
		p.InfoBtnPanel.add(p.InfoBtn_deselect_all);
		p.InfoBtn_deselect_all.setNextBeans(p.InfoBtn_rcopy);
		p.InfoBtn_rcopy.setIcon("COPY_RECORD");
		p.InfoBtn_rcopy.setFunctionKey(MCFunctionKey.F17);
		p.InfoBtnPanel.add(p.InfoBtn_rcopy);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_RowSignalParts_FW.mcInitInfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.mcInitInfoBtn((FSBAP_RowSignalParts)this);

		// [INIT]ステータスのモードの設定
		FSBAP_RowSignalParts_FW.statusInitINIT_InfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.statusInitINIT_InfoBtn((FSBAP_RowSignalParts)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_RowSignalParts_FW.statusInitEDIT_InfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.statusInitEDIT_InfoBtn((FSBAP_RowSignalParts)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_RowSignalParts_FW.statusInitDISABLE_InfoDtl((FSBAP_RowSignalParts)this);
		FSBAP_RowSignalParts_FW.statusInitDISABLE_InfoBtn((FSBAP_RowSignalParts)this);

	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP_RowSignalParts p) {
		p.InfoDtlTable.addAllListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP_RowSignalParts p) {
		p.InfoBtn_radd.addAllListener(p);
		p.InfoBtn_radd.setAPMethodName("doInfoBtn_radd");
		p.InfoBtn_rdel.addAllListener(p);
		p.InfoBtn_rdel.setAPMethodName("doInfoBtn_rdel");
		p.InfoBtn_select_all.addAllListener(p);
		p.InfoBtn_select_all.setAPMethodName("doInfoBtn_select_all");
		p.InfoBtn_deselect_all.addAllListener(p);
		p.InfoBtn_deselect_all.setAPMethodName("doInfoBtn_deselect_all");
		p.InfoBtn_rcopy.addAllListener(p);
		p.InfoBtn_rcopy.setAPMethodName("doInfoBtn_rcopy");
	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP_RowSignalParts p){
		p.InfoDtl_cond_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.DISABLE);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP_RowSignalParts p){
		p.InfoBtn_radd.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_select_all.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_deselect_all.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_rcopy.putMode(p, INIT, MCMode.DISABLE);

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP_RowSignalParts p){
		p.InfoDtl_cond_p_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.EDIT);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, EDIT, MCMode.INVISIBLE);

	}

	/**
	 * [EDIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoBtn(FSBAP_RowSignalParts p){
		p.InfoBtn_radd.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_rdel.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_select_all.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_deselect_all.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_rcopy.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP_RowSignalParts p){
		p.InfoDtl_cond_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.DISABLE);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, DISABLE, MCMode.INVISIBLE);

	}

	/**
	 * [DISABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoBtn(FSBAP_RowSignalParts p){
		p.InfoBtn_radd.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_select_all.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_deselect_all.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_rcopy.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_RowSignalParts_FW.setTableConfigInfoDtl((FSBAP_RowSignalParts)this);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP_RowSignalParts p) {
		p.InfoDtlTable.addTable(p.InfoDtl_cond_p_PPanel.InfoDtlTable);
		// スクロール固定カラムの指定
		p.InfoDtlTable.setUnscrollColumn(p.columnInfoDtl_relative_type);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == InfoBtn_radd) doInfoBtn_radd(info);
		else if (ap == InfoBtn_rdel) doInfoBtn_rdel(info);
		else if (ap == InfoBtn_select_all) doInfoBtn_select_all(info);
		else if (ap == InfoBtn_deselect_all) doInfoBtn_deselect_all(info);
		else if (ap == InfoBtn_rcopy) doInfoBtn_rcopy(info);
	}

	/**
	 * [InfoBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_radd(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_rdel(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[select_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_select_all(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[deselect_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_deselect_all(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[rcopy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_rcopy(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == InfoDtlTable) return doInfoDtl_VC(info);
		return true;
	}

	/**
	 * [InfoDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == InfoDtlTable) doInfoDtl_NC(info);
	}

	/**
	 * [InfoDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == InfoDtlTable) doInfoDtl_NE(info);
	}

	/**
	 * [InfoDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == InfoDtlTable) doInfoDtl_NX(info);
	}

	/**
	 * [InfoDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}