package mcframe.clientFSBA.FSBAP0880;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_MiningTaskDtlDest"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_MiningTaskDtlDest_FW_A extends mcframe.clientFSUC.FSUCP0100.FSUCP_ConditionSettingBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0880";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Dtl]ブロック関連のField定義
	public MCPanel DtlPanel = null;
	public MCScrollPane DtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0880.DtlR> DtlTable = null;
	// [Dtl]ブロックの項目のField定義
	/**
	 *  ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnDtl_id = null;
	/**
	 *  名称.<p>
	 *
	 */
	public MCColumnConfig columnDtl_name = null;
	// [Ctrl]ブロック関連のField定義
	public MCPanel CtrlPanel = null;
	// [Ctrl]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton Ctrl_add = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton Ctrl_del = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [ENTRY]モードを表す定数 */
	public static final String ENTRY = "ENTRY";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, ENTRY, READ_ONLY};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Dtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0880.DtlR> aDtlL;

	/**
	 * コピーによってaDtlLを設定します。
	 *
	 * aDtlLのインスタンスは変更されません。
	 *
	 * @param dataset DtlL
	 */
	public void setDtlL(MCList<mcframe.clientFSBA.FSBAP0880.DtlR> aList) {
		if (getDtlL() != aList) {
			getDtlL().setAll(aList);
		}
	}

	/**
	 * [Dtl]ブロックのコンテナaDtlLを返します。
	 *
	 * @return DtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0880.DtlR> getDtlL() {
		return aDtlL;
	}

	/**
	 * aDtlRを作成します。
	 *
	 * @return DtlR
	 */
	public mcframe.clientFSBA.FSBAP0880.DtlR createDtlR() {
		return mcframe.clientFSBA.FSBAP0880.DtlR.create();
	}

	/**
	 * aDtlLを作成します。
	 *
	 * @return DtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0880.DtlR> createDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0880.DtlR.class);
	}

	/**
	 * DtlTableを初期化します。
	 */
	protected void createDtlTable(){
		if(DtlTable == null){
			DtlTable = beansFactory.createTable2("Dtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getDtlL())) ret.add(getDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getDtlL()) return "Dtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Dtl")) return getDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(DtlPanel);
		ret.add(CtrlPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTaskDtlDest_FW_A() {
		aDtlL = createDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningTaskDtlDest_FW_A(String name) {
		aDtlL = createDtlL();
		createDtlTable();
		DtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_MiningTaskDtlDest_FW.jbCreateDtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.jbCreateCtrl((FSBAP_MiningTaskDtlDest)this);
	}

	/**
	 * [Dtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDtl(FSBAP_MiningTaskDtlDest p) {
	}

	/**
	 * [Ctrl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCtrl(FSBAP_MiningTaskDtlDest p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Dtl_id_ListPutter]の定義 */
	private MCListPutter Dtl_id_p = null;

	/**
	 * [Dtl_id_ListPutter]の取得
	 */
	protected MCListPutter getDtl_id_ListPutter() {
		if (Dtl_id_p == null) {
			Dtl_id_p = createDtl_id_ListPutter(columnDtl_id, "id", "name");

		}
		return Dtl_id_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTaskDtlDest create(){
		FSBAP_MiningTaskDtlDest p = new FSBAP_MiningTaskDtlDest();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTaskDtlDest create(String name){
		FSBAP_MiningTaskDtlDest p = new FSBAP_MiningTaskDtlDest(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_MiningTaskDtlDest_FW.jbfInitDtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.jbfInitCtrl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.jbInitDtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.jbInitCtrl((FSBAP_MiningTaskDtlDest)this);
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDtl(FSBAP_MiningTaskDtlDest p) {
		// ブロック関連の初期化
		p.DtlPanel = p.beansFactory.createPanel("Dtl");
		p.DtlScrollPane = p.beansFactory.createScrollPane("Dtl.scroll");
		p.createDtlTable();
		// ブロックの項目の初期化
		p.columnDtl_id = p.beansFactory.createTableColumn("Dtl.id", MCColumnType.TEXT_COMBO);
		p.columnDtl_name = p.beansFactory.createTableColumn("Dtl.name", MCColumnType.TEXT);
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCtrl(FSBAP_MiningTaskDtlDest p) {
		// ブロック関連の初期化
		p.CtrlPanel = p.beansFactory.createPanel("Ctrl");
		// ブロックの項目の初期化
		p.Ctrl_add = p.beansFactory.createButton("Ctrl.add", "no_border");
		p.Ctrl_del = p.beansFactory.createButton("Ctrl.del", "no_border");
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDtl(FSBAP_MiningTaskDtlDest p) {
		// ブロック関連の初期化
		p.add(p.DtlPanel);
		p.setLastBeans(p.DtlPanel);
		p.DtlPanel.setNextBeans(p.CtrlPanel);
		p.DtlPanel.add(p.DtlScrollPane);
		p.DtlPanel.setLastBeans(p.DtlTable);
		p.DtlScrollPane.setViewportView(p.DtlTable);
		p.DtlTable.setList(p.getDtlL());
		p.DtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCtrl(FSBAP_MiningTaskDtlDest p) {
		// ブロック関連の初期化
		p.add(p.CtrlPanel);
		p.CtrlPanel.setValueCheck(false);
		p.CtrlPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Ctrl_add.setIcon("INSERT_RECORD");
		p.Ctrl_add.setFunctionKey(MCFunctionKey.F5);
		p.CtrlPanel.add(p.Ctrl_add);
		p.CtrlPanel.setLastBeans(p.Ctrl_add);
		p.Ctrl_add.setNextBeans(p.Ctrl_del);
		p.Ctrl_del.setIcon("DELETE_RECORD");
		p.Ctrl_del.setFunctionKey(MCFunctionKey.F17);
		p.CtrlPanel.add(p.Ctrl_del);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_MiningTaskDtlDest_FW.mcInitDtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.mcInitCtrl((FSBAP_MiningTaskDtlDest)this);

		// [ENABLE]ステータスのモードの設定
		FSBAP_MiningTaskDtlDest_FW.statusInitENABLE_Dtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.statusInitENABLE_Ctrl((FSBAP_MiningTaskDtlDest)this);

		// [ENTRY]ステータスのモードの設定
		FSBAP_MiningTaskDtlDest_FW.statusInitENTRY_Dtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.statusInitENTRY_Ctrl((FSBAP_MiningTaskDtlDest)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP_MiningTaskDtlDest_FW.statusInitREAD__ONLY_Dtl((FSBAP_MiningTaskDtlDest)this);
		FSBAP_MiningTaskDtlDest_FW.statusInitREAD__ONLY_Ctrl((FSBAP_MiningTaskDtlDest)this);

	}

	/**
	 *  [Dtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDtl(FSBAP_MiningTaskDtlDest p) {
		p.DtlTable.addAllListener(p);
		p.columnDtl_id.addAllListener(p);
		p.columnDtl_id.setListListener(p);
		p.columnDtl_name.addAllListener(p);
		p.columnDtl_name.setListListener(p);
	}

	/**
	 *  [Ctrl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCtrl(FSBAP_MiningTaskDtlDest p) {
		p.Ctrl_add.addAllListener(p);
		p.Ctrl_add.setAPMethodName("doCtrl_add");
		p.Ctrl_del.addAllListener(p);
		p.Ctrl_del.setAPMethodName("doCtrl_del");
	}

	/**
	 * [ENABLE]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Dtl(FSBAP_MiningTaskDtlDest p){
		p.columnDtl_id.putMode(p, ENABLE, MCMode.REQUIRED);
		p.columnDtl_name.putMode(p, ENABLE, MCMode.READ_ONLY);

	}

	/**
	 * [ENABLE]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Ctrl(FSBAP_MiningTaskDtlDest p){
		p.Ctrl_add.putMode(p, ENABLE, MCMode.ENABLE);
		p.Ctrl_del.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENTRY]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Dtl(FSBAP_MiningTaskDtlDest p){
		p.columnDtl_id.putMode(p, ENTRY, MCMode.REQUIRED);
		p.columnDtl_name.putMode(p, ENTRY, MCMode.READ_ONLY);

	}

	/**
	 * [ENTRY]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Ctrl(FSBAP_MiningTaskDtlDest p){
		p.Ctrl_add.putMode(p, ENTRY, MCMode.ENABLE);
		p.Ctrl_del.putMode(p, ENTRY, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Dtl(FSBAP_MiningTaskDtlDest p){
		p.columnDtl_id.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnDtl_name.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Ctrl(FSBAP_MiningTaskDtlDest p){
		p.Ctrl_add.putMode(p, READ_ONLY, MCMode.DISABLE);
		p.Ctrl_del.putMode(p, READ_ONLY, MCMode.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return READ_ONLY;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_MiningTaskDtlDest_FW.setTableConfigDtl((FSBAP_MiningTaskDtlDest)this);
	}

	/**
	 * [Dtl]ブロックのTableの設定
	 */
	protected static void setTableConfigDtl(FSBAP_MiningTaskDtlDest p) {
		p.columnDtl_id.setMeta(mcframe.clientFSBA.FSBAP0880.DtlR.id_META);
		p.columnDtl_id.addLinkBeans(p.columnDtl_name);
		p.DtlTable.addColumnConfig(p.columnDtl_id);
		p.columnDtl_name.setMeta(mcframe.clientFSBA.FSBAP0880.DtlR.name_META);
		p.DtlTable.addColumnConfig(p.columnDtl_name);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnDtl_id.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnDtl_id.getListConfig().setPutter(getDtl_id_ListPutter());
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[ENTRY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENTRYStatus() {
		status = ENTRY;
		setAllStatus(status);
	}

	/**
	 * この画面を[READ_ONLY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setREAD_ONLYStatus() {
		status = READ_ONLY;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (ENTRY.equals(status)) {
			setENTRYStatus();
		}
		else if (READ_ONLY.equals(status)) {
			setREAD_ONLYStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Dtl_id_ListPutter]の作成
	 */
	protected MCListPutter createDtl_id_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnDtl_id) return getDtl_id(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Ctrl_add) doCtrl_add(info);
		else if (ap == Ctrl_del) doCtrl_del(info);
	}

	/**
	 * [Ctrl]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCtrl_add(MCEventInfo info);

	/**
	 * [Ctrl]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCtrl_del(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == DtlTable) return doDtl_VC(info);
		if (vc == columnDtl_id) return doDtl_id_VC(info);
		if (vc == columnDtl_name) return doDtl_name_VC(info);
		return true;
	}

	/**
	 * [Dtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == DtlTable) doDtl_NC(info);
		else if (nc == columnDtl_id) doDtl_id_NC(info);
		else if (nc == columnDtl_name) doDtl_name_NC(info);
	}

	/**
	 * [Dtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_id_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_name_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == DtlTable) doDtl_NE(info);
		else if (ne == columnDtl_id) doDtl_id_NE(info);
		else if (ne == columnDtl_name) doDtl_name_NE(info);
	}

	/**
	 * [Dtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_id_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_name_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == DtlTable) doDtl_NX(info);
		else if (nx == columnDtl_id) doDtl_id_NX(info);
		else if (nx == columnDtl_name) doDtl_name_NX(info);
	}

	/**
	 * [Dtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_id_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_name_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnDtl_id) doDtl_id_LC(info);
		else if (lc == columnDtl_name) doDtl_name_LC(info);
	}

	/**
	 * [Dtl]パネルの[id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_id_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_name_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnDtl_id]の作成メソッド
	 */
	public MCList getDtl_id(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}