package mcframe.clientFSBA.FSBAP0880;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.beans.list.MCListPutter;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.sys.MCFactory;

import mcframe.commonFS.constant.FSC_SEARCH_TYPE;
import mcframe.clientFSBA.FSBAP0850.ParamDtlR;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_MiningTaskDtlDest"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_MiningTaskDtlDest_FW extends FSBAP_MiningTaskDtlDest_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * タスクの会社コード
	 */
	protected String _co_cd = null;
	/**
	 * 通知先種別
	 * 通常、リソースキー中の通知先種別になります。
	 */
	protected String _type = null;
	/**
	 * 通知先リストロジック
	 */
	protected MCListLogic _listLogic = null;
	/**
	 * 通知先リストロジックメソッド
	 */
	protected String _listMethod = null;
	/**
	 * 通知先リストロジック使用カラム
	 * インデックス0：IDカラム
	 * インデックス1：名称カラム
	 */
	protected String[] _listCols = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTaskDtlDest_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningTaskDtlDest_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Ctrl]のボタン[add]の押下時の処理
	 */
	@Override
	public void doCtrl_add(MCEventInfo info) {
		insertRow(DtlTable);
	}
	/**
	 * Panel[Ctrl]のボタン[del]の押下時の処理
	 */
	@Override
	public void doCtrl_del(MCEventInfo info) {
		deleteRow(DtlTable);
	}

	@Override
	public MCList getDtl_id(MCRow row, MCEventInfo info) {
		if (_listLogic == null || _listMethod == null) {
			return MCList.create(MCRow.class);
		}

		// 会社コードは常に条件に設定
		row.setStringNE("co_cd", _co_cd);
		row.setStringNE("search_type", FSC_SEARCH_TYPE.EXT_ATTR_EQ.value());

		return (MCList) MCFactory.invoke(
						_listLogic, _listMethod,
						new Class<?>[] { MCRow.class, MCEventInfo.class },
						new Object[] { row, info }
		);
	}


	/**
	 * パラメータキーのベース部を返します。
	 *
	 * @return パラメータキーのベース部
	 */
	protected String getParamBase() {
		return MCConst.createKey("push.dest", _type);
	}

	/**
	 * リソースキーのベース部を返します。
	 *
	 * @return リソースキーのベース部
	 */
	protected String getResourceBase() {
		return MCConst.createKey("mining", getParamBase());
	}

	/**
	 * ラベル文字列を返します。
	 *
	 * @param key リソースキーのベース部に続く文字列
	 * @return
	 */
	protected String getLabelText(String key) {
		return MCConst.label.getLabel(
								MCConst.createKey(getResourceBase(), key));
	}

	/**
	 * この部品用のタブのラベル文字列を返します。
	 *
	 * @return タブのラベル文字列
	 */
	public String getTabLabelText() {
		return getLabelText("tab.label");
	}

	/**
	 * この部品を初期化します。
	 *
	 * @param type 通知先種別
	 */
	public void initDestParts(String type) {
		_type = type;
		if (_type == null) {
			return;
		}

		// リソースキーのベース
		String base = getResourceBase();

		// ラベル
		String idLabel = getLabelText("id.label");
		columnDtl_id.setHeaderName(idLabel);
		columnDtl_id.setMessageName(idLabel);
		String nameLabel = getLabelText("name.label");
		columnDtl_name.setHeaderName(nameLabel);
		columnDtl_name.setMessageName(nameLabel);

		// コンボリスト
		String listmethod = MCConst.plugin.getString(
								MCConst.createKey(base, "list.logic"), null);
		if (listmethod != null) {
			int ext = listmethod.lastIndexOf('.');
			_listMethod = listmethod.substring(ext + 1);

			String clazz = listmethod.substring(0, ext);
			_listLogic = (MCListLogic) MCFactory.invokeStatic(
					MCListLogic.class, "create",
					new Class<?>[] { String.class, MCRootPanel.class },
					new Object[] { clazz, this }
			);
		}

		// リストプッター
		_listCols = MCConst.plugin.getStringArray(
								MCConst.createKey(base, "list.cols"), null);
		if (_listCols != null && _listCols.length < 2) {
			_listCols = null;
		}
		columnDtl_id.setListVisibleColumn(MCListLogic.getViewColumnName());
		if (_listCols != null) {
			columnDtl_id.getListConfig().setPutter(
						new MCListPutter(columnDtl_id, _listCols[0], _listCols[1]));
		}
	}

	/**
	 * この部品で編集する通知先パラメータを設定します。
	 *
	 * @param co_cd タスクの会社コード
	 * @param paramL パラメータ
	 * @param paramIdx パラメータ用インデックス
	 */
	public void setDestList(String co_cd, MCList<ParamDtlR> paramL, MCIndexKey paramIdx) {
		_co_cd = co_cd;
		String base = getParamBase();

		// 名称付加用のリスト
		MCList<MCRow> list = getDtl_id(MCRow.create(), null);
		MCIndexKey listIdx = (list.size() > 0 && _listCols != null)
										? list.createIndex(_listCols[0])
										: null;

		MCList<DtlR> dtlL = getDtlL();
		dtlL.clear();

		ParamDtlR paramR;
		int cnt = 0;
		while ((paramR = paramL.getFirst(paramIdx,
						MCConst.createKey(base, String.valueOf(cnt)))) != null) {
			String id = paramR.value();
			DtlR dtlR = dtlL.add();
			dtlR.id(id);
			if (listIdx != null) {
				MCRow row = list.getFirst(listIdx, id);
				if (row != null) {
					dtlR.name(row.getString(_listCols[1]));
				}
			}
			cnt++;
		}
	}

	/**
	 * 設定値をチェックし、登録可能な通知先をパラメータで返します。
	 *
	 * <p>
	 * チェックに引っかかった場合は、メッセージを表示し null を返します。
	 *
	 * @param taskid タスクID
	 * @return 通知先のパラメータ。登録不可の場合 null
	 */
	public MCList<ParamDtlR> checkPushDest(String taskid) {
		// 手順は FSBAP0360 集計情報表示 を参考
		MCList<DtlR> list = getDtlL();

		// 空行のステータスをクリア
		for (DtlR row : list) {
			if (row.isEmpty()) {
				row.clearAll();
				row.setStatus(MCRow.GUICREATE);
			}
		}
		
		// 空行を取り除いたリストを取得
		list = exceptEmpty(list);
		list.sort(DtlR.$id);
		
		// 必須入力項目チェック
		// 入力がIDのみなので不要
		MCMessageList m = checkReq(list);
		if (!m.isEmpty()) {
			message(m);
			return null;
		}
		
		// 重複チェック
		// 呼び出し元で行う
		checkDuplicate(m, list, DtlTable, DtlR.$id);
		if (!m.isEmpty()) {
			message(m);
			return null;
		}

		// パラメータに変換
		MCList<ParamDtlR> paramL = MCList.create(ParamDtlR.class);

		String base = getParamBase();
		int cnt = 0;
		for (DtlR row : list) {
			Status status = row.getStatus();
			ParamDtlR paramR = paramL.add();
			paramR.task_id(taskid);
			paramR.key(MCConst.createKey(base, String.valueOf(cnt)));
			paramR.value(row.id());
			paramR.setStatus(status);
			if (status != Status.DELETE) {
				// 削除行以外はカウントアップ
				// 削除行もカウントアップすると最終的なインデックスがズレてしまう
				// 削除行を入れないと削除のみ行ったときに変更を検知できない
				// 削除行はオペレーションで除外される
				cnt++;
			}
		}

		return paramL;
	}

}