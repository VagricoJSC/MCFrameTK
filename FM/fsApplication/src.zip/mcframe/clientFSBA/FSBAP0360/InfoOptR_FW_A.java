package mcframe.clientFSBA.FSBAP0360;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoOpt"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoOptR_FW_A extends MCConstRow {

	public static final String $rank_type = "rank_type";
	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public static final String $rank_type_nm = "rank_type_nm";
	/**
	 *  有効順位.<p>
	 *
	 */
	public static final String $rank_size = "rank_size";
	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public static final String $fill_dt_fm = "fill_dt_fm";
	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public static final String $fill_dt_to = "fill_dt_to";


	public static final MCMeta rank_type_META = createStringMeta($rank_type);
	public static final MCMeta rank_type_nm_META = createStringMeta($rank_type_nm);
	public static final MCMeta rank_size_META = createNumberMeta($rank_size, 10, 0, false);
	public static final MCMeta fill_dt_fm_META = createCommonMeta($fill_dt_fm, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta fill_dt_to_META = createCommonMeta($fill_dt_to, mcframe.commonCore.meta.M_META.TS);

	protected static final ConstMetaList<InfoOptR> constMetas = new ConstMetaList<InfoOptR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			rank_type_META,
			rank_type_nm_META,
			rank_size_META,
			fill_dt_fm_META,
			fill_dt_to_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoOptR_FW_A(ConstMetaList<? extends InfoOptR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoOptR clone() {
		return (InfoOptR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoOptR createInstance() {
		return (InfoOptR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoOptR getValues(String... names) {
		return (InfoOptR) super.getValues(names);
	}



	public String rank_type() {
		return getConstString(offset + 0, $rank_type);
	}

	public void rank_type(String value) {
		setConstString(offset + 0, $rank_type, value);
	}


	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public String rank_type_nm() {
		return getConstString(offset + 1, $rank_type_nm);
	}

	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public void rank_type_nm(String value) {
		setConstString(offset + 1, $rank_type_nm, value);
	}


	/**
	 *  有効順位.<p>
	 *
	 */
	public MCNumber rank_size() {
		return getConstNumber(offset + 2, $rank_size);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(MCNumber value) {
		setConstNumber(offset + 2, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(int value) {
		setConstNumber(offset + 2, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(long value) {
		setConstNumber(offset + 2, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(float value) {
		setConstNumber(offset + 2, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(double value) {
		setConstNumber(offset + 2, $rank_size, value);
	}


	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public MCTimestamp fill_dt_fm() {
		return getConstTimestamp(offset + 3, $fill_dt_fm);
	}

	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public void fill_dt_fm(MCTimestamp value) {
		setConstTimestamp(offset + 3, $fill_dt_fm, value);
	}


	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public MCTimestamp fill_dt_to() {
		return getConstTimestamp(offset + 4, $fill_dt_to);
	}

	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public void fill_dt_to(MCTimestamp value) {
		setConstTimestamp(offset + 4, $fill_dt_to, value);
	}


	public String getString(String name) {
		if ($rank_type.equalsIgnoreCase(name)) {
			return rank_type();
		}
		if ($rank_type_nm.equalsIgnoreCase(name)) {
			return rank_type_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($rank_size.equalsIgnoreCase(name)) {
			return rank_size();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			return fill_dt_fm();
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			return fill_dt_to();
		}
		return super.getTimestamp(name);
	}

	public String getStringNE(String name) {
		if ($rank_type.equalsIgnoreCase(name)) {
			return rank_type();
		}
		if ($rank_type_nm.equalsIgnoreCase(name)) {
			return rank_type_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($rank_size.equalsIgnoreCase(name)) {
			return rank_size();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			return fill_dt_fm();
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			return fill_dt_to();
		}
		return super.getTimestampNE(name);
	}

	public void setString(String name, String value) {
		if ($rank_type.equalsIgnoreCase(name)) {
			rank_type(value);
			return;
		}
		if ($rank_type_nm.equalsIgnoreCase(name)) {
			rank_type_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			fill_dt_fm(value);
			return;
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			fill_dt_to(value);
			return;
		}
		super.setTimestamp(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($rank_type.equalsIgnoreCase(name)) {
			rank_type(value);
			return;
		}
		if ($rank_type_nm.equalsIgnoreCase(name)) {
			rank_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			fill_dt_fm(value);
			return;
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			fill_dt_to(value);
			return;
		}
		super.setTimestampNE(name, value);
	}



}

