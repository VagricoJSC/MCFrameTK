package mcframe.clientFSBA.FSBAP0360;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_SumInfo"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_SumInfo_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0360";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Setting]ブロック関連のField定義
	public MCPanel SettingPanel = null;
	// [Setting]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H Setting_setting_PPanel;
	// [InfoPnl]ブロック関連のField定義
	public MCPanel InfoPnlPanel = null;
	// [InfoPnl]ブロックの項目のField定義
	// [List]ブロック関連のField定義
	public MCPanel ListPanel = null;
	// [List]ブロックの項目のField定義
	// [ListDtl]ブロック関連のField定義
	public MCPanel ListDtlPanel = null;
	public MCScrollPane ListDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0360.ListDtlR> ListDtlTable = null;
	// [ListDtl]ブロックの項目のField定義
	/**
	 *  初期集計.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_flg = null;
	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_setting_unit_type = null;
	/**
	 *  設定単位名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_setting_unit_type_nm = null;
	/**
	 *  集計情報ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_sum_info_id = null;
	/**
	 *  集計情報名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_sum_info_nm = null;
	/**
	 *  備考.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_remark = null;
	// [ListBtn]ブロック関連のField定義
	public MCPanel ListBtnPanel = null;
	// [ListBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton ListBtn_radd = null;
	/**
	 *  行コピー.<p>
	 *
	 */
	public MCButton ListBtn_rcopy = null;
	/**
	 *  集計する.<p>
	 *
	 */
	public MCButton ListBtn_sum = null;
	/**
	 *  削除する.<p>
	 *
	 */
	public MCButton ListBtn_del = null;
	// [ListEastBtn]ブロック関連のField定義
	public MCPanel ListEastBtnPanel = null;
	// [ListEastBtn]ブロックの項目のField定義
	// [Info]ブロック関連のField定義
	public MCPanel InfoPanel = null;
	public MCTitledBorder InfoTitledBorder = null;
	// [Info]ブロックの項目のField定義
	// [InfoDtl]ブロック関連のField定義
	public MCPanel InfoDtlPanel = null;
	public MCScrollPane InfoDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0360.InfoDtlR> InfoDtlTable = null;
	// [InfoDtl]ブロックの項目のField定義
	/**
	 *  無効.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_disable = null;
	public MCColumnConfig columnInfoDtl_sum_info_type = null;
	/**
	 *  集計区分名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sum_info_type_nm = null;
	public MCColumnConfig columnInfoDtl_column_key = null;
	/**
	 *  カラム名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_column_nm = null;
	/**
	 *  集計条件名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sumcond = null;
	/**
	 *  順位対象.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_rank = null;
	/**
	 *  日時補完.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_fill_dt = null;
	/**
	 *  日付書式.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_date_fmt = null;
	/**
	 *  計算式.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_formula = null;
	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_dec_place = null;
	public MCColumnConfig columnInfoDtl_rounding_mode_type = null;
	/**
	 *  端数処理区分名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_rounding_mode_type_nm = null;
	/**
	 *  null集計0変換.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_null_zero = null;
	/**
	 *  ソート順.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sort_order = null;
	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sort_type = null;
	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sort_type_nm = null;
	public MCColumnConfig columnInfoDtl_chart_type = null;
	/**
	 *  グラフ名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_chart_type_nm = null;
	public MCColumnConfig columnInfoDtl_chart_color = null;
	public mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D InfoDtl_chart_color_p_PPanel;
	public MCColumnConfig columnInfoDtl_red;// [InfoDtl]の[chart_color_p.red]を[columnInfoDtl_red]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_green;// [InfoDtl]の[chart_color_p.green]を[columnInfoDtl_green]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_blue;// [InfoDtl]の[chart_color_p.blue]を[columnInfoDtl_blue]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_color;// [InfoDtl]の[chart_color_p.color]を[columnInfoDtl_color]としてエイリアス定義。
	/**
	 *  行ラベル（チャート）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_row_label = null;
	// [InfoOpt]ブロック関連のField定義
	public MCPanel InfoOptPanel = null;
	// [InfoOpt]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton InfoOpt_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton InfoOpt_rdel = null;
	/**
	 *  全選択.<p>
	 *
	 */
	public MCButton InfoOpt_select_all = null;
	/**
	 *  全解除.<p>
	 *
	 */
	public MCButton InfoOpt_deselect_all = null;
	public mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H InfoOpt_row_move_p_PPanel;
	/**
	 *  グループ化可能なカラムをすべて追加.<p>
	 *
	 */
	public MCButton InfoOpt_grp_all_col = null;
	public MCTextField InfoOpt_rank_type = null;
	public MCLabel InfoOpt_rank_type_nm_Label = null;
	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public MCTextComboBox InfoOpt_rank_type_nm = null;
	public MCLabel InfoOpt_rank_size_Label = null;
	/**
	 *  有効順位.<p>
	 *
	 */
	public MCNumberField InfoOpt_rank_size = null;
	public MCLabel InfoOpt_fill_dt_fm_Label = null;
	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public MCTimestampField InfoOpt_fill_dt_fm = null;
	public MCLabel InfoOpt_fill_dt_to_Label = null;
	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public MCTimestampField InfoOpt_fill_dt_to = null;
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	public MCLabel InfoBtn_sum_info_nm_Label = null;
	/**
	 *  集計情報名.<p>
	 *
	 */
	public MCTextField InfoBtn_sum_info_nm = null;
	public MCLabel InfoBtn_remark_Label = null;
	/**
	 *  備考.<p>
	 *
	 */
	public MCTextField InfoBtn_remark = null;
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton InfoBtn_upd = null;
	/**
	 *  更新する（会社共通）.<p>
	 *
	 */
	public MCButton InfoBtn_upd_ext = null;
	/**
	 *  更新する（システム共通）.<p>
	 *
	 */
	public MCButton InfoBtn_upd_sys = null;
	/**
	 *  見える化.<p>
	 *
	 */
	public MCButton InfoBtn_mining = null;
	// [View]ブロック関連のField定義
	public MCPanel ViewPanel = null;
	public MCTabbedPane ViewTab = null;
	// [View]ブロックの項目のField定義
	// [Rslt]ブロック関連のField定義
	public MCPanel RsltPanel = null;
	public MCScrollPane RsltScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0360.RsltR> RsltTable = null;
	// [Rslt]ブロックの項目のField定義
	// [Chart]ブロック関連のField定義
	public MCPanel ChartPanel = null;
	// [Chart]ブロックの項目のField定義
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [ListDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0360.ListDtlR> aListDtlL;
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0360.InfoDtlR> aInfoDtlL;
	/** [InfoOpt]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0360.InfoOptR aInfoOptR;
	/** [InfoBtn]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0360.ListDtlR aInfoBtnR;
	/** [Rslt]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0360.RsltR> aRsltL;

	/**
	 * コピーによってaListDtlLを設定します。
	 *
	 * aListDtlLのインスタンスは変更されません。
	 *
	 * @param dataset ListDtlL
	 */
	public void setListDtlL(MCList<mcframe.clientFSBA.FSBAP0360.ListDtlR> aList) {
		if (getListDtlL() != aList) {
			getListDtlL().setAll(aList);
		}
	}

	/**
	 * [ListDtl]ブロックのコンテナaListDtlLを返します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0360.ListDtlR> getListDtlL() {
		return aListDtlL;
	}

	/**
	 * aListDtlRを作成します。
	 *
	 * @return ListDtlR
	 */
	public mcframe.clientFSBA.FSBAP0360.ListDtlR createListDtlR() {
		return mcframe.clientFSBA.FSBAP0360.ListDtlR.create();
	}

	/**
	 * aListDtlLを作成します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0360.ListDtlR> createListDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0360.ListDtlR.class);
	}

	/**
	 * ListDtlTableを初期化します。
	 */
	protected void createListDtlTable(){
		if(ListDtlTable == null){
			ListDtlTable = beansFactory.createTable2("ListDtl.table");
		}
	}

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFSBA.FSBAP0360.InfoDtlR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0360.InfoDtlR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0360.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0360.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0360.InfoDtlR> createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0360.InfoDtlR.class);
	}

	/**
	 * InfoDtlTableを初期化します。
	 */
	protected void createInfoDtlTable(){
		if(InfoDtlTable == null){
			InfoDtlTable = beansFactory.createTable2("InfoDtl.table");
		}
	}

	/**
	 * 項目コピーによってaInfoOptRを設定します。
	 *
	 * aInfoOptRのインスタンスは変更されません。
	 *
	 * @param row InfoOptR
	 */
	public void setInfoOptR(mcframe.clientFSBA.FSBAP0360.InfoOptR row) {
		if (row != null) {
			MCRow.copyall(getInfoOptR(), row);
		}
	}

	/**
	 * [InfoOpt]ブロックのコンテナaInfoOptRを返します。
	 *
	 * @return InfoOptR
	 */
	public mcframe.clientFSBA.FSBAP0360.InfoOptR getInfoOptR() {
		return aInfoOptR;
	}

	/**
	 * aInfoOptRを作成します。
	 *
	 * @return InfoOptR
	 */
	public mcframe.clientFSBA.FSBAP0360.InfoOptR createInfoOptR() {
		return mcframe.clientFSBA.FSBAP0360.InfoOptR.create();
	}

	/**
	 * 項目コピーによってaInfoBtnRを設定します。
	 *
	 * aInfoBtnRのインスタンスは変更されません。
	 *
	 * @param row InfoBtnR
	 */
	public void setInfoBtnR(mcframe.clientFSBA.FSBAP0360.ListDtlR row) {
		if (row != null) {
			MCRow.copyall(getInfoBtnR(), row);
		}
	}

	/**
	 * [InfoBtn]ブロックのコンテナaInfoBtnRを返します。
	 *
	 * @return InfoBtnR
	 */
	public mcframe.clientFSBA.FSBAP0360.ListDtlR getInfoBtnR() {
		return aInfoBtnR;
	}

	/**
	 * aInfoBtnRを作成します。
	 *
	 * @return InfoBtnR
	 */
	public mcframe.clientFSBA.FSBAP0360.ListDtlR createInfoBtnR() {
		return mcframe.clientFSBA.FSBAP0360.ListDtlR.create();
	}

	/**
	 * コピーによってaRsltLを設定します。
	 *
	 * aRsltLのインスタンスは変更されません。
	 *
	 * @param dataset RsltL
	 */
	public void setRsltL(MCList<mcframe.clientFSBA.FSBAP0360.RsltR> aList) {
		if (getRsltL() != aList) {
			getRsltL().setAll(aList);
		}
	}

	/**
	 * [Rslt]ブロックのコンテナaRsltLを返します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0360.RsltR> getRsltL() {
		return aRsltL;
	}

	/**
	 * aRsltRを作成します。
	 *
	 * @return RsltR
	 */
	public mcframe.clientFSBA.FSBAP0360.RsltR createRsltR() {
		return mcframe.clientFSBA.FSBAP0360.RsltR.create();
	}

	/**
	 * aRsltLを作成します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0360.RsltR> createRsltL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0360.RsltR.class);
	}

	/**
	 * RsltTableを初期化します。
	 */
	protected void createRsltTable(){
		if(RsltTable == null){
			RsltTable = beansFactory.createTable2("Rslt.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getListDtlL())) ret.add(getListDtlL());
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		if(!MCCollectionUtil.contains(ret, getInfoOptR())) ret.add(getInfoOptR());
		if(!MCCollectionUtil.contains(ret, getInfoBtnR())) ret.add(getInfoBtnR());
		if(!MCCollectionUtil.contains(ret, getRsltL())) ret.add(getRsltL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getListDtlL()) return "ListDtl";
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		if(aCnt == getInfoOptR()) return "InfoOpt";
		if(aCnt == getInfoBtnR()) return "InfoBtn";
		if(aCnt == getRsltL()) return "Rslt";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("ListDtl")) return getListDtlL();
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		if(bId.equals("InfoOpt")) return getInfoOptR();
		if(bId.equals("InfoBtn")) return getInfoBtnR();
		if(bId.equals("Rslt")) return getRsltL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(SettingPanel);
		ret.add(InfoPnlPanel);
		ret.add(ListPanel);
		ret.add(ListDtlPanel);
		ret.add(ListBtnPanel);
		ret.add(ListEastBtnPanel);
		ret.add(InfoPanel);
		ret.add(InfoDtlPanel);
		ret.add(InfoOptPanel);
		ret.add(InfoBtnPanel);
		ret.add(ViewPanel);
		ret.add(RsltPanel);
		ret.add(ChartPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SumInfo_FW_A() {
		aListDtlL = createListDtlL();
		aInfoDtlL = createInfoDtlL();
		aInfoOptR = createInfoOptR();
		aInfoBtnR = createInfoBtnR();
		aRsltL = createRsltL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SumInfo_FW_A(String name) {
		aListDtlL = createListDtlL();
		createListDtlTable();
		ListDtlTable.setRowName(name);
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
		aInfoOptR = createInfoOptR();
		aInfoBtnR = createInfoBtnR();
		aRsltL = createRsltL();
		createRsltTable();
		RsltTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_SumInfo_FW.jbCreateSetting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateInfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateList((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateInfo((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateInfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateInfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateInfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateView((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateRslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbCreateChart((FSBAP_SumInfo)this);
	}

	/**
	 * [Setting]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSetting(FSBAP_SumInfo p) {
		p.Setting_setting_PPanel = mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.create();
		p.Setting_setting_PPanel.setName("Setting.setting");
	}

	/**
	 * [InfoPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoPnl(FSBAP_SumInfo p) {
	}

	/**
	 * [List]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateList(FSBAP_SumInfo p) {
	}

	/**
	 * [ListDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtl(FSBAP_SumInfo p) {
	}

	/**
	 * [ListBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListBtn(FSBAP_SumInfo p) {
	}

	/**
	 * [ListEastBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListEastBtn(FSBAP_SumInfo p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP_SumInfo p) {
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP_SumInfo p) {
		p.InfoDtl_chart_color_p_PPanel = mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.create(mcframe.clientFSBA.FSBAP0360.InfoDtlR.$chart_color_p);
		p.InfoDtl_chart_color_p_PPanel.setName("InfoDtl.chart_color_p");
		p.columnInfoDtl_red = p.InfoDtl_chart_color_p_PPanel.columnColor_red;
		p.columnInfoDtl_red.addAliasName("InfoDtl.red", p);
		p.columnInfoDtl_green = p.InfoDtl_chart_color_p_PPanel.columnColor_green;
		p.columnInfoDtl_green.addAliasName("InfoDtl.green", p);
		p.columnInfoDtl_blue = p.InfoDtl_chart_color_p_PPanel.columnColor_blue;
		p.columnInfoDtl_blue.addAliasName("InfoDtl.blue", p);
		p.columnInfoDtl_color = p.InfoDtl_chart_color_p_PPanel.columnColor_color;
		p.columnInfoDtl_color.addAliasName("InfoDtl.color", p);
	}

	/**
	 * [InfoOpt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoOpt(FSBAP_SumInfo p) {
		p.InfoOpt_row_move_p_PPanel = mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.create();
		p.InfoOpt_row_move_p_PPanel.setName("InfoOpt.row_move_p");
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP_SumInfo p) {
	}

	/**
	 * [View]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateView(FSBAP_SumInfo p) {
	}

	/**
	 * [Rslt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateRslt(FSBAP_SumInfo p) {
	}

	/**
	 * [Chart]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateChart(FSBAP_SumInfo p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [InfoDtl_sum_info_type_nm_ListPutter]の定義 */
	private MCListPutter InfoDtl_sum_info_type_nm_p = null;

	/**
	 * [InfoDtl_sum_info_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_sum_info_type_nm_ListPutter() {
		if (InfoDtl_sum_info_type_nm_p == null) {
			InfoDtl_sum_info_type_nm_p = createInfoDtl_sum_info_type_nm_ListPutter(columnInfoDtl_sum_info_type_nm, "sum_info_type_nm", "sum_info_type");

		}
		return InfoDtl_sum_info_type_nm_p;
	}
	
	
	/** [InfoDtl_column_nm_ListPutter]の定義 */
	private MCListPutter InfoDtl_column_nm_p = null;

	/**
	 * [InfoDtl_column_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_column_nm_ListPutter() {
		if (InfoDtl_column_nm_p == null) {
			InfoDtl_column_nm_p = createInfoDtl_column_nm_ListPutter(columnInfoDtl_column_nm, "column_nm", "column_key");

		}
		return InfoDtl_column_nm_p;
	}
	
	
	/** [InfoDtl_date_fmt_ListPutter]の定義 */
	private MCListPutter InfoDtl_date_fmt_p = null;

	/**
	 * [InfoDtl_date_fmt_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_date_fmt_ListPutter() {
		if (InfoDtl_date_fmt_p == null) {
			InfoDtl_date_fmt_p = createInfoDtl_date_fmt_ListPutter(columnInfoDtl_date_fmt, "date_fmt");

		}
		return InfoDtl_date_fmt_p;
	}
	
	
	/** [InfoDtl_rounding_mode_type_nm_ListPutter]の定義 */
	private MCListPutter InfoDtl_rounding_mode_type_nm_p = null;

	/**
	 * [InfoDtl_rounding_mode_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_rounding_mode_type_nm_ListPutter() {
		if (InfoDtl_rounding_mode_type_nm_p == null) {
			InfoDtl_rounding_mode_type_nm_p = createInfoDtl_rounding_mode_type_nm_ListPutter(columnInfoDtl_rounding_mode_type_nm, "rounding_mode_type_nm", "rounding_mode_type");

		}
		return InfoDtl_rounding_mode_type_nm_p;
	}
	
	
	/** [InfoDtl_sort_type_ListPutter]の定義 */
	private MCListPutter InfoDtl_sort_type_p = null;

	/**
	 * [InfoDtl_sort_type_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_sort_type_ListPutter() {
		if (InfoDtl_sort_type_p == null) {
			InfoDtl_sort_type_p = createInfoDtl_sort_type_ListPutter(columnInfoDtl_sort_type, "sort_type", "sort_type_nm");

		}
		return InfoDtl_sort_type_p;
	}
	
	
	/** [InfoDtl_chart_type_nm_ListPutter]の定義 */
	private MCListPutter InfoDtl_chart_type_nm_p = null;

	/**
	 * [InfoDtl_chart_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_chart_type_nm_ListPutter() {
		if (InfoDtl_chart_type_nm_p == null) {
			InfoDtl_chart_type_nm_p = createInfoDtl_chart_type_nm_ListPutter(columnInfoDtl_chart_type_nm, "chart_type_nm", "chart_type");

		}
		return InfoDtl_chart_type_nm_p;
	}
	
	
	/** [InfoOpt_rank_type_nm_ListPutter]の定義 */
	private MCListPutter InfoOpt_rank_type_nm_p = null;

	/**
	 * [InfoOpt_rank_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoOpt_rank_type_nm_ListPutter() {
		if (InfoOpt_rank_type_nm_p == null) {
			InfoOpt_rank_type_nm_p = createInfoOpt_rank_type_nm_ListPutter(InfoOpt_rank_type_nm, "rank_type_nm", "rank_type");

		}
		return InfoOpt_rank_type_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SumInfo create(){
		FSBAP_SumInfo p = new FSBAP_SumInfo();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SumInfo create(String name){
		FSBAP_SumInfo p = new FSBAP_SumInfo(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_SumInfo_FW.jbfInitSetting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitInfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitList((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitInfo((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitInfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitInfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitInfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitView((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitRslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbfInitChart((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitSetting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitInfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitList((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitInfo((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitInfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitInfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitInfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitView((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitRslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.jbInitChart((FSBAP_SumInfo)this);
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSetting(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.SettingPanel = p.beansFactory.createPanel("Setting");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoPnl(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoPnlPanel = p.beansFactory.createPanel("InfoPnl");
		// ブロックの項目の初期化
	}

	/**
	 * [List]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitList(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListPanel = p.beansFactory.createPanel("List");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtl(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListDtlPanel = p.beansFactory.createPanel("ListDtl");
		p.ListDtlScrollPane = p.beansFactory.createScrollPane("ListDtl.scroll");
		p.createListDtlTable();
		// ブロックの項目の初期化
		p.columnListDtl_init_flg = p.beansFactory.createTableColumn("ListDtl.init_flg", MCColumnType.CHECK);
		p.columnListDtl_setting_unit_type = p.beansFactory.createTableColumn("ListDtl.setting_unit_type", MCColumnType.TEXT);
		p.columnListDtl_setting_unit_type_nm = p.beansFactory.createTableColumn("ListDtl.setting_unit_type_nm", MCColumnType.TEXT);
		p.columnListDtl_sum_info_id = p.beansFactory.createTableColumn("ListDtl.sum_info_id", MCColumnType.TEXT);
		p.columnListDtl_sum_info_nm = p.beansFactory.createTableColumn("ListDtl.sum_info_nm", MCColumnType.TEXT);
		p.columnListDtl_remark = p.beansFactory.createTableColumn("ListDtl.remark", MCColumnType.TEXT);
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListBtn(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListBtnPanel = p.beansFactory.createPanel("ListBtn");
		// ブロックの項目の初期化
		p.ListBtn_radd = p.beansFactory.createButton("ListBtn.radd", "no_border");
		p.ListBtn_rcopy = p.beansFactory.createButton("ListBtn.rcopy", "no_border");
		p.ListBtn_sum = p.beansFactory.createButton("ListBtn.sum");
		p.ListBtn_del = p.beansFactory.createButton("ListBtn.del", "del");
	}

	/**
	 * [ListEastBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListEastBtn(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListEastBtnPanel = p.beansFactory.createPanel("ListEastBtn");
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoPanel = p.beansFactory.createPanel("Info");
		p.InfoTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoDtlPanel = p.beansFactory.createPanel("InfoDtl");
		p.InfoDtlScrollPane = p.beansFactory.createScrollPane("InfoDtl.scroll");
		p.createInfoDtlTable();
		// ブロックの項目の初期化
		p.columnInfoDtl_disable = p.beansFactory.createTableColumn("InfoDtl.disable", MCColumnType.CHECK);
		p.columnInfoDtl_sum_info_type = p.beansFactory.createTableColumn("InfoDtl.sum_info_type", MCColumnType.TEXT);
		p.columnInfoDtl_sum_info_type_nm = p.beansFactory.createTableColumn("InfoDtl.sum_info_type_nm", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_column_key = p.beansFactory.createTableColumn("InfoDtl.column_key", MCColumnType.TEXT);
		p.columnInfoDtl_column_nm = p.beansFactory.createTableColumn("InfoDtl.column_nm", MCColumnType.TEXT_COMBO_FREE);
		p.columnInfoDtl_sumcond = p.beansFactory.createTableColumn("InfoDtl.sumcond", MCColumnType.TEXT);
		p.columnInfoDtl_rank = p.beansFactory.createTableColumn("InfoDtl.rank", MCColumnType.CHECK);
		p.columnInfoDtl_fill_dt = p.beansFactory.createTableColumn("InfoDtl.fill_dt", MCColumnType.CHECK);
		p.columnInfoDtl_date_fmt = p.beansFactory.createTableColumn("InfoDtl.date_fmt", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_formula = p.beansFactory.createTableColumn("InfoDtl.formula", MCColumnType.TEXT);
		p.columnInfoDtl_dec_place = p.beansFactory.createTableColumn("InfoDtl.dec_place", MCColumnType.NUMBER);
		p.columnInfoDtl_rounding_mode_type = p.beansFactory.createTableColumn("InfoDtl.rounding_mode_type", MCColumnType.TEXT);
		p.columnInfoDtl_rounding_mode_type_nm = p.beansFactory.createTableColumn("InfoDtl.rounding_mode_type_nm", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_null_zero = p.beansFactory.createTableColumn("InfoDtl.null_zero", MCColumnType.CHECK);
		p.columnInfoDtl_sort_order = p.beansFactory.createTableColumn("InfoDtl.sort_order", MCColumnType.NUMBER);
		p.columnInfoDtl_sort_type = p.beansFactory.createTableColumn("InfoDtl.sort_type", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_sort_type_nm = p.beansFactory.createTableColumn("InfoDtl.sort_type_nm", MCColumnType.TEXT);
		p.columnInfoDtl_chart_type = p.beansFactory.createTableColumn("InfoDtl.chart_type", MCColumnType.NUMBER);
		p.columnInfoDtl_chart_type_nm = p.beansFactory.createTableColumn("InfoDtl.chart_type_nm", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_chart_color = p.beansFactory.createTableColumn("InfoDtl.chart_color", MCColumnType.TEXT);
		p.columnInfoDtl_row_label = p.beansFactory.createTableColumn("InfoDtl.row_label", MCColumnType.CHECK);
	}

	/**
	 * [InfoOpt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoOpt(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoOptPanel = p.beansFactory.createPanel("InfoOpt");
		// ブロックの項目の初期化
		p.InfoOpt_radd = p.beansFactory.createButton("InfoOpt.radd", "no_border");
		p.InfoOpt_rdel = p.beansFactory.createButton("InfoOpt.rdel", "no_border");
		p.InfoOpt_select_all = p.beansFactory.createButton("InfoOpt.select_all", "no_border");
		p.InfoOpt_deselect_all = p.beansFactory.createButton("InfoOpt.deselect_all", "no_border");
		p.InfoOpt_grp_all_col = p.beansFactory.createButton("InfoOpt.grp_all_col");
		p.InfoOpt_rank_type = p.beansFactory.createTextField("InfoOpt.rank_type");
		p.InfoOpt_rank_type_nm_Label = p.beansFactory.createLabel("InfoOpt.rank_type_nm_Label");
		p.InfoOpt_rank_type_nm = p.beansFactory.createTextComboBox("InfoOpt.rank_type_nm");
		p.InfoOpt_rank_type_nm.setLabel(p.InfoOpt_rank_type_nm_Label);
		p.InfoOpt_rank_size_Label = p.beansFactory.createLabel("InfoOpt.rank_size_Label");
		p.InfoOpt_rank_size = p.beansFactory.createNumberField("InfoOpt.rank_size");
		p.InfoOpt_rank_size.setLabel(p.InfoOpt_rank_size_Label);
		p.InfoOpt_fill_dt_fm_Label = p.beansFactory.createLabel("InfoOpt.fill_dt_fm_Label");
		p.InfoOpt_fill_dt_fm = p.beansFactory.createTimestampField("InfoOpt.fill_dt_fm");
		p.InfoOpt_fill_dt_fm.setLabel(p.InfoOpt_fill_dt_fm_Label);
		p.InfoOpt_fill_dt_to_Label = p.beansFactory.createLabel("InfoOpt.fill_dt_to_Label");
		p.InfoOpt_fill_dt_to = p.beansFactory.createTimestampField("InfoOpt.fill_dt_to");
		p.InfoOpt_fill_dt_to.setLabel(p.InfoOpt_fill_dt_to_Label);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_sum_info_nm_Label = p.beansFactory.createLabel("InfoBtn.sum_info_nm_Label");
		p.InfoBtn_sum_info_nm = p.beansFactory.createTextField("InfoBtn.sum_info_nm");
		p.InfoBtn_sum_info_nm.setLabel(p.InfoBtn_sum_info_nm_Label);
		p.InfoBtn_remark_Label = p.beansFactory.createLabel("InfoBtn.remark_Label");
		p.InfoBtn_remark = p.beansFactory.createTextField("InfoBtn.remark");
		p.InfoBtn_remark.setLabel(p.InfoBtn_remark_Label);
		p.InfoBtn_upd = p.beansFactory.createButton("InfoBtn.upd", "upd");
		p.InfoBtn_upd_ext = p.beansFactory.createButton("InfoBtn.upd_ext");
		p.InfoBtn_upd_sys = p.beansFactory.createButton("InfoBtn.upd_sys");
		p.InfoBtn_mining = p.beansFactory.createButton("InfoBtn.mining", "mining");
	}

	/**
	 * [View]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitView(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ViewPanel = p.beansFactory.createPanel("View");
		p.ViewTab = p.beansFactory.createTabbedPane("View.tab");
		// ブロックの項目の初期化
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitRslt(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.RsltPanel = p.beansFactory.createPanel("Rslt");
		p.RsltScrollPane = p.beansFactory.createScrollPane("Rslt.scroll");
		p.createRsltTable();
		// ブロックの項目の初期化
	}

	/**
	 * [Chart]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitChart(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ChartPanel = p.beansFactory.createPanel("Chart");
		// ブロックの項目の初期化
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSetting(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.add(p.SettingPanel);
		p.setLastBeans(p.SettingPanel);
		p.SettingPanel.setNextBeans(p.InfoPnlPanel);
		p.SettingPanel.setValueCheck(false);
		p.SettingPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.SettingPanel.add(p.Setting_setting_PPanel);
		p.SettingPanel.setLastBeans(p.Setting_setting_PPanel);
	}

	/**
	 * [InfoPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoPnl(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.add(p.InfoPnlPanel);
		p.InfoPnlPanel.setNextBeans(p.ViewPanel);
		p.InfoPnlPanel.setLayoutPosition("CTC+");
		// ブロックの項目の初期化
		p.InfoPnlPanel.add(p.ListPanel, null);
		p.InfoPnlPanel.setLastBeans(p.ListPanel);
		p.ListPanel.setNextBeans(p.InfoPanel);
		p.InfoPnlPanel.add(p.InfoPanel, null);
	}

	/**
	 * [List]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitList(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListPanel.setLayoutPosition("CLC+");
		// ブロックの項目の初期化
		p.ListPanel.add(p.ListDtlPanel, null);
		p.ListPanel.setLastBeans(p.ListDtlPanel);
		p.ListDtlPanel.setNextBeans(p.ListBtnPanel);
		p.ListPanel.add(p.ListBtnPanel, null);
		p.ListBtnPanel.setNextBeans(p.ListEastBtnPanel);
		p.ListPanel.add(p.ListEastBtnPanel, null);
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtl(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListDtlPanel.add(p.ListDtlScrollPane);
		p.ListDtlPanel.setLastBeans(p.ListDtlTable);
		p.ListDtlScrollPane.setViewportView(p.ListDtlTable);
		p.ListDtlTable.setList(p.getListDtlL());
		p.ListDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListBtn(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListBtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.ListBtn_radd.setIcon("INSERT_RECORD");
		p.ListBtn_radd.setFunctionKey(MCFunctionKey.F11);
		p.ListBtnPanel.add(p.ListBtn_radd);
		p.ListBtnPanel.setLastBeans(p.ListBtn_radd);
		p.ListBtn_radd.setNextBeans(p.ListBtn_rcopy);
		p.ListBtn_rcopy.setIcon("COPY_RECORD");
		p.ListBtn_rcopy.setFunctionKey(MCFunctionKey.F15);
		p.ListBtnPanel.add(p.ListBtn_rcopy);
		p.ListBtn_rcopy.setNextBeans(p.ListBtn_sum);
		p.ListBtn_sum.setFunctionKey(MCFunctionKey.F8);
		p.ListBtnPanel.add(p.ListBtn_sum);
		p.ListBtn_del.setIcon("DELETE");
		p.ListBtn_del.setFunctionKey(MCFunctionKey.F12);
		p.ListEastBtnPanel.setLastBeans(p.ListBtn_del);
		p.ListEastBtnPanel.add(p.ListBtn_del);
	}

	/**
	 * [ListEastBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListEastBtn(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ListEastBtnPanel.setLayoutPosition("SE");
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoPanel.setBorder(p.InfoTitledBorder);
		p.InfoPanel.setLayoutPosition("CRC+");
		// ブロックの項目の初期化
		p.InfoPanel.add(p.InfoDtlPanel, null);
		p.InfoPanel.setLastBeans(p.InfoDtlPanel);
		p.InfoDtlPanel.setNextBeans(p.InfoOptPanel);
		p.InfoPanel.add(p.InfoOptPanel, null);
		p.InfoOptPanel.setNextBeans(p.InfoBtnPanel);
		p.InfoPanel.add(p.InfoBtnPanel, null);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoDtlPanel.add(p.InfoDtlScrollPane);
		p.InfoDtlPanel.setLastBeans(p.InfoDtlTable);
		p.InfoDtlScrollPane.setViewportView(p.InfoDtlTable);
		p.InfoDtlTable.setList(p.getInfoDtlL());
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoOpt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoOpt(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoOptPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoOpt_radd.setIcon("INSERT_RECORD");
		p.InfoOpt_radd.setFunctionKey(MCFunctionKey.F5);
		p.InfoOptPanel.add(p.InfoOpt_radd);
		p.InfoOptPanel.setLastBeans(p.InfoOpt_radd);
		p.InfoOpt_radd.setNextBeans(p.InfoOpt_rdel);
		p.InfoOpt_rdel.setIcon("DELETE_RECORD");
		p.InfoOpt_rdel.setFunctionKey(MCFunctionKey.F6);
		p.InfoOptPanel.add(p.InfoOpt_rdel);
		p.InfoOpt_rdel.setNextBeans(p.InfoOpt_select_all);
		p.InfoOpt_select_all.setIcon("SELECT_ALL");
		p.InfoOpt_select_all.setFunctionKey(MCFunctionKey.F13);
		p.InfoOptPanel.add(p.InfoOpt_select_all);
		p.InfoOpt_select_all.setNextBeans(p.InfoOpt_deselect_all);
		p.InfoOpt_deselect_all.setIcon("DESELECT_ALL");
		p.InfoOpt_deselect_all.setFunctionKey(MCFunctionKey.F14);
		p.InfoOptPanel.add(p.InfoOpt_deselect_all);
		p.InfoOpt_deselect_all.setNextBeans(p.InfoOpt_row_move_p_PPanel);
		p.InfoOptPanel.add(p.InfoOpt_row_move_p_PPanel);
		p.InfoOpt_row_move_p_PPanel.setNextBeans(p.InfoOpt_grp_all_col);
		p.InfoOpt_grp_all_col.setFunctionKey(MCFunctionKey.F23);
		p.InfoOptPanel.add(p.InfoOpt_grp_all_col);
		p.InfoOpt_grp_all_col.setNextBeans(p.InfoOpt_rank_type);
		p.InfoOptPanel.add(p.InfoOpt_rank_type);
		p.InfoOpt_rank_type.setNextBeans(p.InfoOpt_rank_type_nm);
		p.InfoOpt_rank_type.setRow(p.getInfoOptR(), mcframe.clientFSBA.FSBAP0360.InfoOptR.rank_type_META);
		p.InfoOpt_rank_type_nm.setListType(MCListType.STRICT);
		p.InfoOpt_rank_type_nm.setLinkBeans(p.InfoOpt_rank_type);
		p.InfoOptPanel.add(p.InfoOpt_rank_type_nm_Label);
		p.InfoOptPanel.add(p.InfoOpt_rank_type_nm);
		p.InfoOpt_rank_type_nm.setNextBeans(p.InfoOpt_rank_size);
		p.InfoOpt_rank_type_nm.setRow(p.getInfoOptR(), mcframe.clientFSBA.FSBAP0360.InfoOptR.rank_type_nm_META);
		p.InfoOptPanel.add(p.InfoOpt_rank_size_Label);
		p.InfoOptPanel.add(p.InfoOpt_rank_size);
		p.InfoOpt_rank_size.setNextBeans(p.InfoOpt_fill_dt_fm);
		p.InfoOpt_rank_size.setRow(p.getInfoOptR(), mcframe.clientFSBA.FSBAP0360.InfoOptR.rank_size_META);
		p.InfoOptPanel.add(p.InfoOpt_fill_dt_fm_Label);
		p.InfoOptPanel.add(p.InfoOpt_fill_dt_fm);
		p.InfoOpt_fill_dt_fm.setNextBeans(p.InfoOpt_fill_dt_to);
		p.InfoOpt_fill_dt_fm.setRow(p.getInfoOptR(), mcframe.clientFSBA.FSBAP0360.InfoOptR.fill_dt_fm_META);
		p.InfoOpt_fill_dt_fm.setFormatID("YMDHMSS");
		p.InfoOptPanel.add(p.InfoOpt_fill_dt_to_Label);
		p.InfoOptPanel.add(p.InfoOpt_fill_dt_to);
		p.InfoOpt_fill_dt_to.setRow(p.getInfoOptR(), mcframe.clientFSBA.FSBAP0360.InfoOptR.fill_dt_to_META);
		p.InfoOpt_fill_dt_to.setFormatID("YMDHMSS");
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.InfoBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoBtnPanel.add(p.InfoBtn_sum_info_nm_Label);
		p.InfoBtnPanel.add(p.InfoBtn_sum_info_nm);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_sum_info_nm);
		p.InfoBtn_sum_info_nm.setNextBeans(p.InfoBtn_remark);
		p.InfoBtn_sum_info_nm.setRow(p.getInfoBtnR(), mcframe.clientFSBA.FSBAP0360.ListDtlR.sum_info_nm_META);
		p.InfoBtnPanel.add(p.InfoBtn_remark_Label);
		p.InfoBtnPanel.add(p.InfoBtn_remark);
		p.InfoBtn_remark.setNextBeans(p.InfoBtn_upd);
		p.InfoBtn_remark.setRow(p.getInfoBtnR(), mcframe.clientFSBA.FSBAP0360.ListDtlR.remark_META);
		p.InfoBtn_upd.setIcon("REGISTER");
		p.InfoBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd);
		p.InfoBtn_upd.setNextBeans(p.InfoBtn_upd_ext);
		p.InfoBtn_upd_ext.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd_ext);
		p.InfoBtn_upd_ext.setNextBeans(p.InfoBtn_upd_sys);
		p.InfoBtn_upd_sys.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd_sys);
		p.InfoBtn_upd_sys.setNextBeans(p.InfoBtn_mining);
		p.InfoBtnPanel.add(p.InfoBtn_mining);
	}

	/**
	 * [View]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitView(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.add(p.ViewPanel);
		p.ViewPanel.add(p.ViewTab);
		p.ViewPanel.setLastBeans(p.ViewTab);
		p.ViewPanel.setLayoutPosition("CBC");
		// ブロックの項目の初期化
		p.ViewTab.add(p.RsltPanel, "View.rslt");
		p.ViewTab.setLastBeans(p.RsltPanel);
		p.RsltPanel.setNextBeans(p.ChartPanel);
		p.ViewTab.add(p.ChartPanel, "View.chart");
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitRslt(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.RsltPanel.setNextBeans(p.ChartPanel);
		p.RsltPanel.add(p.RsltScrollPane);
		p.RsltPanel.setLastBeans(p.RsltTable);
		p.RsltScrollPane.setViewportView(p.RsltTable);
		p.RsltTable.setList(p.getRsltL());
		p.RsltPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Chart]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitChart(FSBAP_SumInfo p) {
		// ブロック関連の初期化
		p.ChartPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_SumInfo_FW.mcInitSetting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitInfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitList((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitInfo((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitInfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitInfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitInfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitView((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitRslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.mcInitChart((FSBAP_SumInfo)this);

		// [INIT]ステータスのモードの設定
		FSBAP_SumInfo_FW.statusInitINIT_Setting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_InfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_List((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_ListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_ListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_ListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_Info((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_InfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_InfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_InfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_View((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_Rslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitINIT_Chart((FSBAP_SumInfo)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_SumInfo_FW.statusInitEDIT_Setting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_InfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_List((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_ListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_ListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_ListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_Info((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_InfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_InfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_InfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_View((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_Rslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitEDIT_Chart((FSBAP_SumInfo)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_SumInfo_FW.statusInitDISABLE_Setting((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_InfoPnl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_List((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_ListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_ListBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_ListEastBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_Info((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_InfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_InfoOpt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_InfoBtn((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_View((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_Rslt((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.statusInitDISABLE_Chart((FSBAP_SumInfo)this);

	}

	/**
	 *  [Setting]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSetting(FSBAP_SumInfo p) {
	}

	/**
	 *  [InfoPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoPnl(FSBAP_SumInfo p) {
	}

	/**
	 *  [List]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitList(FSBAP_SumInfo p) {
	}

	/**
	 *  [ListDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtl(FSBAP_SumInfo p) {
		p.ListDtlTable.addAllListener(p);
		p.columnListDtl_init_flg.addAllListener(p);
		p.columnListDtl_setting_unit_type.addAllListener(p);
		p.columnListDtl_setting_unit_type.setListListener(p);
		p.columnListDtl_setting_unit_type_nm.addAllListener(p);
		p.columnListDtl_setting_unit_type_nm.setListListener(p);
		p.columnListDtl_sum_info_id.addAllListener(p);
		p.columnListDtl_sum_info_id.setListListener(p);
		p.columnListDtl_sum_info_nm.addAllListener(p);
		p.columnListDtl_sum_info_nm.setListListener(p);
		p.columnListDtl_remark.addAllListener(p);
		p.columnListDtl_remark.setListListener(p);
	}

	/**
	 *  [ListBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListBtn(FSBAP_SumInfo p) {
		p.ListBtn_radd.addAllListener(p);
		p.ListBtn_radd.setAPMethodName("doListBtn_radd");
		p.ListBtn_rcopy.addAllListener(p);
		p.ListBtn_rcopy.setAPMethodName("doListBtn_rcopy");
		p.ListBtn_sum.addAllListener(p);
		p.ListBtn_sum.setAPMethodName("doListBtn_sum");
		p.ListBtn_del.addAllListener(p);
		p.ListBtn_del.setAPMethodName("doListBtn_del");
	}

	/**
	 *  [ListEastBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListEastBtn(FSBAP_SumInfo p) {
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP_SumInfo p) {
	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP_SumInfo p) {
		p.InfoDtlTable.addAllListener(p);
		p.columnInfoDtl_disable.addAllListener(p);
		p.columnInfoDtl_sum_info_type.addAllListener(p);
		p.columnInfoDtl_sum_info_type.setListListener(p);
		p.columnInfoDtl_sum_info_type_nm.addAllListener(p);
		p.columnInfoDtl_sum_info_type_nm.setListListener(p);
		p.columnInfoDtl_column_key.addAllListener(p);
		p.columnInfoDtl_column_key.setListListener(p);
		p.columnInfoDtl_column_nm.addAllListener(p);
		p.columnInfoDtl_column_nm.setListListener(p);
		p.columnInfoDtl_sumcond.addAllListener(p);
		p.columnInfoDtl_sumcond.setListListener(p);
		p.columnInfoDtl_rank.addAllListener(p);
		p.columnInfoDtl_fill_dt.addAllListener(p);
		p.columnInfoDtl_date_fmt.addAllListener(p);
		p.columnInfoDtl_date_fmt.setListListener(p);
		p.columnInfoDtl_formula.addAllListener(p);
		p.columnInfoDtl_formula.setListListener(p);
		p.columnInfoDtl_dec_place.addAllListener(p);
		p.columnInfoDtl_dec_place.setListListener(p);
		p.columnInfoDtl_rounding_mode_type.addAllListener(p);
		p.columnInfoDtl_rounding_mode_type.setListListener(p);
		p.columnInfoDtl_rounding_mode_type_nm.addAllListener(p);
		p.columnInfoDtl_rounding_mode_type_nm.setListListener(p);
		p.columnInfoDtl_null_zero.addAllListener(p);
		p.columnInfoDtl_sort_order.addAllListener(p);
		p.columnInfoDtl_sort_order.setListListener(p);
		p.columnInfoDtl_sort_type.addAllListener(p);
		p.columnInfoDtl_sort_type.setListListener(p);
		p.columnInfoDtl_sort_type_nm.addAllListener(p);
		p.columnInfoDtl_sort_type_nm.setListListener(p);
		p.columnInfoDtl_chart_type.addAllListener(p);
		p.columnInfoDtl_chart_type.setListListener(p);
		p.columnInfoDtl_chart_type_nm.addAllListener(p);
		p.columnInfoDtl_chart_type_nm.setListListener(p);
		p.columnInfoDtl_chart_color.addAllListener(p);
		p.columnInfoDtl_chart_color.setListListener(p);
		p.columnInfoDtl_row_label.addAllListener(p);
	}

	/**
	 *  [InfoOpt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoOpt(FSBAP_SumInfo p) {
		p.InfoOpt_radd.addAllListener(p);
		p.InfoOpt_radd.setAPMethodName("doInfoOpt_radd");
		p.InfoOpt_rdel.addAllListener(p);
		p.InfoOpt_rdel.setAPMethodName("doInfoOpt_rdel");
		p.InfoOpt_select_all.addAllListener(p);
		p.InfoOpt_select_all.setAPMethodName("doInfoOpt_select_all");
		p.InfoOpt_deselect_all.addAllListener(p);
		p.InfoOpt_deselect_all.setAPMethodName("doInfoOpt_deselect_all");
		p.InfoOpt_grp_all_col.addAllListener(p);
		p.InfoOpt_grp_all_col.setAPMethodName("doInfoOpt_grp_all_col");
		p.InfoOpt_rank_type.setListListener(p);
		p.InfoOpt_rank_type.addAllListener(p);
		p.InfoOpt_rank_type_nm.setListListener(p);
		p.InfoOpt_rank_type_nm.addAllListener(p);
		p.InfoOpt_rank_size.setListListener(p);
		p.InfoOpt_rank_size.addAllListener(p);
		p.InfoOpt_fill_dt_fm.setListListener(p);
		p.InfoOpt_fill_dt_fm.addAllListener(p);
		p.InfoOpt_fill_dt_to.setListListener(p);
		p.InfoOpt_fill_dt_to.addAllListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP_SumInfo p) {
		p.InfoBtn_sum_info_nm.setListListener(p);
		p.InfoBtn_sum_info_nm.addAllListener(p);
		p.InfoBtn_remark.setListListener(p);
		p.InfoBtn_remark.addAllListener(p);
		p.InfoBtn_upd.addAllListener(p);
		p.InfoBtn_upd.setAPMethodName("doInfoBtn_upd");
		p.InfoBtn_upd_ext.addAllListener(p);
		p.InfoBtn_upd_ext.setAPMethodName("doInfoBtn_upd_ext");
		p.InfoBtn_upd_sys.addAllListener(p);
		p.InfoBtn_upd_sys.setAPMethodName("doInfoBtn_upd_sys");
		p.InfoBtn_mining.addAllListener(p);
		p.InfoBtn_mining.setAPMethodName("doInfoBtn_mining");
	}

	/**
	 *  [View]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitView(FSBAP_SumInfo p) {
		p.ViewTab.addAllListener(p);
	}

	/**
	 *  [Rslt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitRslt(FSBAP_SumInfo p) {
		p.RsltTable.addAllListener(p);
	}

	/**
	 *  [Chart]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitChart(FSBAP_SumInfo p) {
	}

	/**
	 * [INIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Setting(FSBAP_SumInfo p){
		p.Setting_setting_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[InfoPnl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoPnl(FSBAP_SumInfo p){

	}

	/**
	 * [INIT]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitINIT_List(FSBAP_SumInfo p){

	}

	/**
	 * [INIT]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListDtl(FSBAP_SumInfo p){
		p.columnListDtl_init_flg.putMode(p, INIT, MCMode.REQUIRED);
		p.columnListDtl_setting_unit_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnListDtl_setting_unit_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnListDtl_sum_info_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnListDtl_sum_info_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnListDtl_remark.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListBtn(FSBAP_SumInfo p){
		p.ListBtn_radd.putMode(p, INIT, MCMode.ENABLE);
		p.ListBtn_rcopy.putMode(p, INIT, MCMode.DISABLE);
		p.ListBtn_sum.putMode(p, INIT, MCMode.DISABLE);
		p.ListBtn_del.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListEastBtn(FSBAP_SumInfo p){

	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP_SumInfo p){

	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP_SumInfo p){
		p.columnInfoDtl_disable.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sum_info_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnInfoDtl_sum_info_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_column_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnInfoDtl_column_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sumcond.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_rank.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_fill_dt.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_date_fmt.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_formula.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_dec_place.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_rounding_mode_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnInfoDtl_rounding_mode_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_null_zero.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_order.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_chart_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnInfoDtl_chart_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_chart_color.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.READ_ONLY);
		p.InfoDtl_chart_color_p_PPanel.columnColor_red.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_green.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_blue.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnInfoDtl_row_label.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoOpt]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoOpt(FSBAP_SumInfo p){
		p.InfoOpt_radd.putMode(p, INIT, MCMode.DISABLE);
		p.InfoOpt_rdel.putMode(p, INIT, MCMode.DISABLE);
		p.InfoOpt_select_all.putMode(p, INIT, MCMode.DISABLE);
		p.InfoOpt_deselect_all.putMode(p, INIT, MCMode.DISABLE);
		p.InfoOpt_row_move_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.DISABLE);
		p.InfoOpt_grp_all_col.putMode(p, INIT, MCMode.DISABLE);
		p.InfoOpt_rank_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoOpt_rank_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoOpt_rank_size.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoOpt_fill_dt_fm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoOpt_fill_dt_to.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP_SumInfo p){
		p.InfoBtn_sum_info_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoBtn_remark.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoBtn_upd.putMode(p, INIT, MCMode.ENABLE);
		p.InfoBtn_upd_ext.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoBtn_upd_sys.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoBtn_mining.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[View]ブロックのモードの設定
	 */
	protected static void statusInitINIT_View(FSBAP_SumInfo p){

	}

	/**
	 * [INIT]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Rslt(FSBAP_SumInfo p){

	}

	/**
	 * [INIT]ステータスの[Chart]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Chart(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Setting(FSBAP_SumInfo p){
		p.Setting_setting_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [EDIT]ステータスの[InfoPnl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoPnl(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_List(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListDtl(FSBAP_SumInfo p){
		p.columnListDtl_init_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnListDtl_setting_unit_type.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnListDtl_setting_unit_type_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnListDtl_sum_info_id.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnListDtl_sum_info_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnListDtl_remark.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListBtn(FSBAP_SumInfo p){
		p.ListBtn_radd.putMode(p, EDIT, MCMode.ENABLE);
		p.ListBtn_rcopy.putMode(p, EDIT, MCMode.ENABLE);
		p.ListBtn_sum.putMode(p, EDIT, MCMode.ENABLE);
		p.ListBtn_del.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListEastBtn(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Info(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP_SumInfo p){
		p.columnInfoDtl_disable.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_sum_info_type.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnInfoDtl_sum_info_type_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_column_key.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnInfoDtl_column_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_sumcond.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_rank.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_fill_dt.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_date_fmt.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_formula.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_dec_place.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_rounding_mode_type.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnInfoDtl_rounding_mode_type_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_null_zero.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_sort_order.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_sort_type.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_sort_type_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfoDtl_chart_type.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnInfoDtl_chart_type_nm.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_chart_color.putMode(p, EDIT, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.ENABLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_red.putMode(p, EDIT, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_green.putMode(p, EDIT, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_blue.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnInfoDtl_row_label.putMode(p, EDIT, MCMode.REQUIRED);

	}

	/**
	 * [EDIT]ステータスの[InfoOpt]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoOpt(FSBAP_SumInfo p){
		p.InfoOpt_radd.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_rdel.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_select_all.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_deselect_all.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_row_move_p_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.ENABLE);
		p.InfoOpt_grp_all_col.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_rank_type.putMode(p, EDIT, MCMode.INVISIBLE);
		p.InfoOpt_rank_type_nm.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_rank_size.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_fill_dt_fm.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoOpt_fill_dt_to.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoBtn(FSBAP_SumInfo p){
		p.InfoBtn_sum_info_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.InfoBtn_remark.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_upd.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_upd_ext.putMode(p, EDIT, MCMode.INVISIBLE);
		p.InfoBtn_upd_sys.putMode(p, EDIT, MCMode.INVISIBLE);
		p.InfoBtn_mining.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[View]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_View(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Rslt(FSBAP_SumInfo p){

	}

	/**
	 * [EDIT]ステータスの[Chart]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Chart(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Setting(FSBAP_SumInfo p){
		p.Setting_setting_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [DISABLE]ステータスの[InfoPnl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoPnl(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_List(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListDtl(FSBAP_SumInfo p){
		p.columnListDtl_init_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnListDtl_setting_unit_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnListDtl_setting_unit_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnListDtl_sum_info_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnListDtl_sum_info_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnListDtl_remark.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListBtn(FSBAP_SumInfo p){
		p.ListBtn_radd.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListBtn_rcopy.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListBtn_sum.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListBtn_del.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListEastBtn(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Info(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP_SumInfo p){
		p.columnInfoDtl_disable.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sum_info_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnInfoDtl_sum_info_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_column_key.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnInfoDtl_column_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sumcond.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_rank.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_fill_dt.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_date_fmt.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_formula.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_dec_place.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_rounding_mode_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnInfoDtl_rounding_mode_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_null_zero.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_order.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_chart_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnInfoDtl_chart_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_chart_color.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.DISABLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_red.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_green.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoDtl_chart_color_p_PPanel.columnColor_blue.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnInfoDtl_row_label.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoOpt]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoOpt(FSBAP_SumInfo p){
		p.InfoOpt_radd.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoOpt_rdel.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoOpt_select_all.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoOpt_deselect_all.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoOpt_row_move_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.DISABLE);
		p.InfoOpt_grp_all_col.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoOpt_rank_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoOpt_rank_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoOpt_rank_size.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoOpt_fill_dt_fm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoOpt_fill_dt_to.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoBtn(FSBAP_SumInfo p){
		p.InfoBtn_sum_info_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoBtn_remark.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoBtn_upd.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_upd_ext.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoBtn_upd_sys.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoBtn_mining.putMode(p, DISABLE, MCMode.INVISIBLE);

	}

	/**
	 * [DISABLE]ステータスの[View]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_View(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Rslt(FSBAP_SumInfo p){

	}

	/**
	 * [DISABLE]ステータスの[Chart]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Chart(FSBAP_SumInfo p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_SumInfo_FW.setTableConfigListDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.setTableConfigInfoDtl((FSBAP_SumInfo)this);
		FSBAP_SumInfo_FW.setTableConfigRslt((FSBAP_SumInfo)this);
	}

	/**
	 * [ListDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigListDtl(FSBAP_SumInfo p) {
		p.columnListDtl_init_flg.setMeta(mcframe.clientFSBA.FSBAP0360.ListDtlR.init_flg_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_flg);
		p.columnListDtl_setting_unit_type.setMeta(mcframe.clientFSBA.FSBAP0360.ListDtlR.setting_unit_type_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_setting_unit_type);
		p.columnListDtl_setting_unit_type_nm.setMeta(mcframe.clientFSBA.FSBAP0360.ListDtlR.setting_unit_type_nm_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_setting_unit_type_nm);
		p.columnListDtl_sum_info_id.setMeta(mcframe.clientFSBA.FSBAP0360.ListDtlR.sum_info_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_sum_info_id);
		p.columnListDtl_sum_info_nm.setMeta(mcframe.clientFSBA.FSBAP0360.ListDtlR.sum_info_nm_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_sum_info_nm);
		p.columnListDtl_remark.setMeta(mcframe.clientFSBA.FSBAP0360.ListDtlR.remark_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_remark);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP_SumInfo p) {
		p.columnInfoDtl_disable.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.disable_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_disable);
		p.columnInfoDtl_sum_info_type.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.sum_info_type_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sum_info_type);
		p.columnInfoDtl_sum_info_type_nm.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.sum_info_type_nm_META);
		p.columnInfoDtl_sum_info_type_nm.addLinkBeans(p.columnInfoDtl_sum_info_type);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sum_info_type_nm);
		p.columnInfoDtl_column_key.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.column_key_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_column_key);
		p.columnInfoDtl_column_nm.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.column_nm_META);
		p.columnInfoDtl_column_nm.addLinkBeans(p.columnInfoDtl_column_key);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_column_nm);
		p.columnInfoDtl_sumcond.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.sumcond_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sumcond);
		p.columnInfoDtl_rank.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.rank_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_rank);
		p.columnInfoDtl_fill_dt.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.fill_dt_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_fill_dt);
		p.columnInfoDtl_date_fmt.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.date_fmt_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_date_fmt);
		p.columnInfoDtl_formula.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.formula_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_formula);
		p.columnInfoDtl_dec_place.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.dec_place_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_dec_place);
		p.columnInfoDtl_rounding_mode_type.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.rounding_mode_type_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_rounding_mode_type);
		p.columnInfoDtl_rounding_mode_type_nm.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.rounding_mode_type_nm_META);
		p.columnInfoDtl_rounding_mode_type_nm.addLinkBeans(p.columnInfoDtl_rounding_mode_type);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_rounding_mode_type_nm);
		p.columnInfoDtl_null_zero.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.null_zero_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_null_zero);
		p.columnInfoDtl_sort_order.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.sort_order_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sort_order);
		p.columnInfoDtl_sort_type.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.sort_type_META);
		p.columnInfoDtl_sort_type.addLinkBeans(p.columnInfoDtl_sort_type_nm);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sort_type);
		p.columnInfoDtl_sort_type_nm.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.sort_type_nm_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sort_type_nm);
		p.columnInfoDtl_chart_type.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.chart_type_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_chart_type);
		p.columnInfoDtl_chart_type_nm.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.chart_type_nm_META);
		p.columnInfoDtl_chart_type_nm.addLinkBeans(p.columnInfoDtl_chart_type);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_chart_type_nm);
		p.columnInfoDtl_chart_color.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.chart_color_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_chart_color);
		p.InfoDtlTable.addTable(p.InfoDtl_chart_color_p_PPanel.ColorTable);
		p.columnInfoDtl_row_label.setMeta(mcframe.clientFSBA.FSBAP0360.InfoDtlR.row_label_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_row_label);
	}

	/**
	 * [Rslt]ブロックのTableの設定
	 */
	protected static void setTableConfigRslt(FSBAP_SumInfo p) {
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnInfoDtl_sum_info_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_sum_info_type_nm.getListConfig().setPutter(getInfoDtl_sum_info_type_nm_ListPutter());
		columnInfoDtl_column_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_column_nm.getListConfig().setPutter(getInfoDtl_column_nm_ListPutter());
		columnInfoDtl_date_fmt.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_date_fmt.getListConfig().setPutter(getInfoDtl_date_fmt_ListPutter());
		columnInfoDtl_rounding_mode_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_rounding_mode_type_nm.getListConfig().setPutter(getInfoDtl_rounding_mode_type_nm_ListPutter());
		columnInfoDtl_sort_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_sort_type.getListConfig().setPutter(getInfoDtl_sort_type_ListPutter());
		columnInfoDtl_chart_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_chart_type_nm.getListConfig().setPutter(getInfoDtl_chart_type_nm_ListPutter());
		InfoOpt_rank_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		InfoOpt_rank_type_nm.getListConfig().setPutter(getInfoOpt_rank_type_nm_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [InfoDtl_sum_info_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_sum_info_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SumInfoType");
		return lp;
	}
	 
	/**
	 * [InfoDtl_column_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_column_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [InfoDtl_date_fmt_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_date_fmt_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [InfoDtl_rounding_mode_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_rounding_mode_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.RoundingModeType");
		return lp;
	}
	 
	/**
	 * [InfoDtl_sort_type_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_sort_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SortType");
		return lp;
	}
	 
	/**
	 * [InfoDtl_chart_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_chart_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.GadgetChartType");
		return lp;
	}
	 
	/**
	 * [InfoOpt_rank_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoOpt_rank_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SortType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnInfoDtl_sum_info_type_nm) return getInfoDtl_sum_info_type_nm(row, info);
		if(combo == columnInfoDtl_column_nm) return getInfoDtl_column_nm(row, info);
		if(combo == columnInfoDtl_date_fmt) return getInfoDtl_date_fmt(row, info);
		if(combo == columnInfoDtl_rounding_mode_type_nm) return getInfoDtl_rounding_mode_type_nm(row, info);
		if(combo == columnInfoDtl_sort_type) return getInfoDtl_sort_type(row, info);
		if(combo == columnInfoDtl_chart_type_nm) return getInfoDtl_chart_type_nm(row, info);
		if(combo == InfoOpt_rank_type_nm) return getInfoOpt_rank_type_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == ListBtn_radd) doListBtn_radd(info);
		else if (ap == ListBtn_rcopy) doListBtn_rcopy(info);
		else if (ap == ListBtn_sum) doListBtn_sum(info);
		else if (ap == ListBtn_del) doListBtn_del(info);
		else if (ap == InfoOpt_radd) doInfoOpt_radd(info);
		else if (ap == InfoOpt_rdel) doInfoOpt_rdel(info);
		else if (ap == InfoOpt_select_all) doInfoOpt_select_all(info);
		else if (ap == InfoOpt_deselect_all) doInfoOpt_deselect_all(info);
		else if (ap == InfoOpt_grp_all_col) doInfoOpt_grp_all_col(info);
		else if (ap == InfoBtn_upd) doInfoBtn_upd(info);
		else if (ap == InfoBtn_upd_ext) doInfoBtn_upd_ext(info);
		else if (ap == InfoBtn_upd_sys) doInfoBtn_upd_sys(info);
		else if (ap == InfoBtn_mining) doInfoBtn_mining(info);
	}

	/**
	 * [ListBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_radd(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[rcopy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_rcopy(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[sum]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_sum(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_del(MCEventInfo info);

	/**
	 * [InfoOpt]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoOpt_radd(MCEventInfo info);

	/**
	 * [InfoOpt]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoOpt_rdel(MCEventInfo info);

	/**
	 * [InfoOpt]パネルの[select_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoOpt_select_all(MCEventInfo info);

	/**
	 * [InfoOpt]パネルの[deselect_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoOpt_deselect_all(MCEventInfo info);

	/**
	 * [InfoOpt]パネルの[grp_all_col]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoOpt_grp_all_col(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd_ext(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd_sys(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[mining]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_mining(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListDtlTable) return doListDtl_VC(info);
		if (vc == InfoDtlTable) return doInfoDtl_VC(info);
		if (vc == ViewTab) return doView_VC(info);
		if (vc == RsltTable) return doRslt_VC(info);
		if (vc == columnListDtl_init_flg) return doListDtl_init_flg_VC(info);
		if (vc == columnListDtl_setting_unit_type) return doListDtl_setting_unit_type_VC(info);
		if (vc == columnListDtl_setting_unit_type_nm) return doListDtl_setting_unit_type_nm_VC(info);
		if (vc == columnListDtl_sum_info_id) return doListDtl_sum_info_id_VC(info);
		if (vc == columnListDtl_sum_info_nm) return doListDtl_sum_info_nm_VC(info);
		if (vc == columnListDtl_remark) return doListDtl_remark_VC(info);
		if (vc == columnInfoDtl_disable) return doInfoDtl_disable_VC(info);
		if (vc == columnInfoDtl_sum_info_type) return doInfoDtl_sum_info_type_VC(info);
		if (vc == columnInfoDtl_sum_info_type_nm) return doInfoDtl_sum_info_type_nm_VC(info);
		if (vc == columnInfoDtl_column_key) return doInfoDtl_column_key_VC(info);
		if (vc == columnInfoDtl_column_nm) return doInfoDtl_column_nm_VC(info);
		if (vc == columnInfoDtl_sumcond) return doInfoDtl_sumcond_VC(info);
		if (vc == columnInfoDtl_rank) return doInfoDtl_rank_VC(info);
		if (vc == columnInfoDtl_fill_dt) return doInfoDtl_fill_dt_VC(info);
		if (vc == columnInfoDtl_date_fmt) return doInfoDtl_date_fmt_VC(info);
		if (vc == columnInfoDtl_formula) return doInfoDtl_formula_VC(info);
		if (vc == columnInfoDtl_dec_place) return doInfoDtl_dec_place_VC(info);
		if (vc == columnInfoDtl_rounding_mode_type) return doInfoDtl_rounding_mode_type_VC(info);
		if (vc == columnInfoDtl_rounding_mode_type_nm) return doInfoDtl_rounding_mode_type_nm_VC(info);
		if (vc == columnInfoDtl_null_zero) return doInfoDtl_null_zero_VC(info);
		if (vc == columnInfoDtl_sort_order) return doInfoDtl_sort_order_VC(info);
		if (vc == columnInfoDtl_sort_type) return doInfoDtl_sort_type_VC(info);
		if (vc == columnInfoDtl_sort_type_nm) return doInfoDtl_sort_type_nm_VC(info);
		if (vc == columnInfoDtl_chart_type) return doInfoDtl_chart_type_VC(info);
		if (vc == columnInfoDtl_chart_type_nm) return doInfoDtl_chart_type_nm_VC(info);
		if (vc == columnInfoDtl_chart_color) return doInfoDtl_chart_color_VC(info);
		if (vc == columnInfoDtl_row_label) return doInfoDtl_row_label_VC(info);
		if (vc == InfoOpt_rank_type) return doInfoOpt_rank_type_VC(info);
		if (vc == InfoOpt_rank_type_nm) return doInfoOpt_rank_type_nm_VC(info);
		if (vc == InfoOpt_rank_size) return doInfoOpt_rank_size_VC(info);
		if (vc == InfoOpt_fill_dt_fm) return doInfoOpt_fill_dt_fm_VC(info);
		if (vc == InfoOpt_fill_dt_to) return doInfoOpt_fill_dt_to_VC(info);
		if (vc == InfoBtn_sum_info_nm) return doInfoBtn_sum_info_nm_VC(info);
		if (vc == InfoBtn_remark) return doInfoBtn_remark_VC(info);
		return true;
	}

	/**
	 * [ListDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]Tabの選択Tabが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_setting_unit_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_setting_unit_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[sum_info_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_sum_info_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[sum_info_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_sum_info_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[disable]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_disable_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sum_info_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sum_info_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[column_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_column_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_column_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sumcond_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[rank]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_rank_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[fill_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_fill_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[date_fmt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_date_fmt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[formula]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_formula_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[dec_place]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_dec_place_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_rounding_mode_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_rounding_mode_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[null_zero]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_null_zero_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sort_order]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sort_order_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sort_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sort_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[chart_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_chart_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[chart_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_chart_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[chart_color]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_chart_color_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[row_label]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_row_label_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoOpt]パネルの[rank_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoOpt_rank_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoOpt]パネルの[rank_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoOpt_rank_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoOpt]パネルの[rank_size]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoOpt_rank_size_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_fm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoOpt_fill_dt_fm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_to]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoOpt_fill_dt_to_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoBtn]パネルの[sum_info_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoBtn_sum_info_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoBtn]パネルの[remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoBtn_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListDtlTable) doListDtl_NC(info);
		else if (nc == InfoDtlTable) doInfoDtl_NC(info);
		else if (nc == ViewTab) doView_NC(info);
		else if (nc == RsltTable) doRslt_NC(info);
		else if (nc == columnListDtl_init_flg) doListDtl_init_flg_NC(info);
		else if (nc == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_NC(info);
		else if (nc == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_NC(info);
		else if (nc == columnListDtl_sum_info_id) doListDtl_sum_info_id_NC(info);
		else if (nc == columnListDtl_sum_info_nm) doListDtl_sum_info_nm_NC(info);
		else if (nc == columnListDtl_remark) doListDtl_remark_NC(info);
		else if (nc == columnInfoDtl_disable) doInfoDtl_disable_NC(info);
		else if (nc == columnInfoDtl_sum_info_type) doInfoDtl_sum_info_type_NC(info);
		else if (nc == columnInfoDtl_sum_info_type_nm) doInfoDtl_sum_info_type_nm_NC(info);
		else if (nc == columnInfoDtl_column_key) doInfoDtl_column_key_NC(info);
		else if (nc == columnInfoDtl_column_nm) doInfoDtl_column_nm_NC(info);
		else if (nc == columnInfoDtl_sumcond) doInfoDtl_sumcond_NC(info);
		else if (nc == columnInfoDtl_rank) doInfoDtl_rank_NC(info);
		else if (nc == columnInfoDtl_fill_dt) doInfoDtl_fill_dt_NC(info);
		else if (nc == columnInfoDtl_date_fmt) doInfoDtl_date_fmt_NC(info);
		else if (nc == columnInfoDtl_formula) doInfoDtl_formula_NC(info);
		else if (nc == columnInfoDtl_dec_place) doInfoDtl_dec_place_NC(info);
		else if (nc == columnInfoDtl_rounding_mode_type) doInfoDtl_rounding_mode_type_NC(info);
		else if (nc == columnInfoDtl_rounding_mode_type_nm) doInfoDtl_rounding_mode_type_nm_NC(info);
		else if (nc == columnInfoDtl_null_zero) doInfoDtl_null_zero_NC(info);
		else if (nc == columnInfoDtl_sort_order) doInfoDtl_sort_order_NC(info);
		else if (nc == columnInfoDtl_sort_type) doInfoDtl_sort_type_NC(info);
		else if (nc == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_NC(info);
		else if (nc == columnInfoDtl_chart_type) doInfoDtl_chart_type_NC(info);
		else if (nc == columnInfoDtl_chart_type_nm) doInfoDtl_chart_type_nm_NC(info);
		else if (nc == columnInfoDtl_chart_color) doInfoDtl_chart_color_NC(info);
		else if (nc == columnInfoDtl_row_label) doInfoDtl_row_label_NC(info);
		else if (nc == InfoOpt_rank_type) doInfoOpt_rank_type_NC(info);
		else if (nc == InfoOpt_rank_type_nm) doInfoOpt_rank_type_nm_NC(info);
		else if (nc == InfoOpt_rank_size) doInfoOpt_rank_size_NC(info);
		else if (nc == InfoOpt_fill_dt_fm) doInfoOpt_fill_dt_fm_NC(info);
		else if (nc == InfoOpt_fill_dt_to) doInfoOpt_fill_dt_to_NC(info);
		else if (nc == InfoBtn_sum_info_nm) doInfoBtn_sum_info_nm_NC(info);
		else if (nc == InfoBtn_remark) doInfoBtn_remark_NC(info);
	}

	/**
	 * [ListDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NC(MCEventInfo info){
	}

	/**
	 * [View]Tabの選択Tabが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_flg_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[disable]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_disable_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sumcond_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rank]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rank_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[fill_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_fill_dt_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date_fmt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_fmt_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[formula]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_formula_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[dec_place]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_dec_place_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[null_zero]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_null_zero_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_order]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_order_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_color]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_color_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[row_label]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_row_label_NC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_size]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_size_NC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_fm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_fm_NC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_to]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_to_NC(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[sum_info_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_sum_info_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_remark_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListDtlTable) doListDtl_NE(info);
		else if (ne == InfoDtlTable) doInfoDtl_NE(info);
		else if (ne == ViewTab) doView_NE(info);
		else if (ne == RsltTable) doRslt_NE(info);
		else if (ne == columnListDtl_init_flg) doListDtl_init_flg_NE(info);
		else if (ne == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_NE(info);
		else if (ne == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_NE(info);
		else if (ne == columnListDtl_sum_info_id) doListDtl_sum_info_id_NE(info);
		else if (ne == columnListDtl_sum_info_nm) doListDtl_sum_info_nm_NE(info);
		else if (ne == columnListDtl_remark) doListDtl_remark_NE(info);
		else if (ne == columnInfoDtl_disable) doInfoDtl_disable_NE(info);
		else if (ne == columnInfoDtl_sum_info_type) doInfoDtl_sum_info_type_NE(info);
		else if (ne == columnInfoDtl_sum_info_type_nm) doInfoDtl_sum_info_type_nm_NE(info);
		else if (ne == columnInfoDtl_column_key) doInfoDtl_column_key_NE(info);
		else if (ne == columnInfoDtl_column_nm) doInfoDtl_column_nm_NE(info);
		else if (ne == columnInfoDtl_sumcond) doInfoDtl_sumcond_NE(info);
		else if (ne == columnInfoDtl_rank) doInfoDtl_rank_NE(info);
		else if (ne == columnInfoDtl_fill_dt) doInfoDtl_fill_dt_NE(info);
		else if (ne == columnInfoDtl_date_fmt) doInfoDtl_date_fmt_NE(info);
		else if (ne == columnInfoDtl_formula) doInfoDtl_formula_NE(info);
		else if (ne == columnInfoDtl_dec_place) doInfoDtl_dec_place_NE(info);
		else if (ne == columnInfoDtl_rounding_mode_type) doInfoDtl_rounding_mode_type_NE(info);
		else if (ne == columnInfoDtl_rounding_mode_type_nm) doInfoDtl_rounding_mode_type_nm_NE(info);
		else if (ne == columnInfoDtl_null_zero) doInfoDtl_null_zero_NE(info);
		else if (ne == columnInfoDtl_sort_order) doInfoDtl_sort_order_NE(info);
		else if (ne == columnInfoDtl_sort_type) doInfoDtl_sort_type_NE(info);
		else if (ne == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_NE(info);
		else if (ne == columnInfoDtl_chart_type) doInfoDtl_chart_type_NE(info);
		else if (ne == columnInfoDtl_chart_type_nm) doInfoDtl_chart_type_nm_NE(info);
		else if (ne == columnInfoDtl_chart_color) doInfoDtl_chart_color_NE(info);
		else if (ne == columnInfoDtl_row_label) doInfoDtl_row_label_NE(info);
		else if (ne == InfoOpt_rank_type) doInfoOpt_rank_type_NE(info);
		else if (ne == InfoOpt_rank_type_nm) doInfoOpt_rank_type_nm_NE(info);
		else if (ne == InfoOpt_rank_size) doInfoOpt_rank_size_NE(info);
		else if (ne == InfoOpt_fill_dt_fm) doInfoOpt_fill_dt_fm_NE(info);
		else if (ne == InfoOpt_fill_dt_to) doInfoOpt_fill_dt_to_NE(info);
		else if (ne == InfoBtn_sum_info_nm) doInfoBtn_sum_info_nm_NE(info);
		else if (ne == InfoBtn_remark) doInfoBtn_remark_NE(info);
	}

	/**
	 * [ListDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NE(MCEventInfo info){
	}

	/**
	 * [View]TabのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_flg_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[disable]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_disable_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sumcond_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rank]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rank_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[fill_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_fill_dt_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date_fmt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_fmt_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[formula]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_formula_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[dec_place]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_dec_place_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[null_zero]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_null_zero_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_order]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_order_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_color]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_color_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[row_label]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_row_label_NE(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_size]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_size_NE(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_fm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_fm_NE(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_to]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_to_NE(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[sum_info_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_sum_info_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_remark_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListDtlTable) doListDtl_NX(info);
		else if (nx == InfoDtlTable) doInfoDtl_NX(info);
		else if (nx == ViewTab) doView_NX(info);
		else if (nx == RsltTable) doRslt_NX(info);
		else if (nx == columnListDtl_init_flg) doListDtl_init_flg_NX(info);
		else if (nx == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_NX(info);
		else if (nx == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_NX(info);
		else if (nx == columnListDtl_sum_info_id) doListDtl_sum_info_id_NX(info);
		else if (nx == columnListDtl_sum_info_nm) doListDtl_sum_info_nm_NX(info);
		else if (nx == columnListDtl_remark) doListDtl_remark_NX(info);
		else if (nx == columnInfoDtl_disable) doInfoDtl_disable_NX(info);
		else if (nx == columnInfoDtl_sum_info_type) doInfoDtl_sum_info_type_NX(info);
		else if (nx == columnInfoDtl_sum_info_type_nm) doInfoDtl_sum_info_type_nm_NX(info);
		else if (nx == columnInfoDtl_column_key) doInfoDtl_column_key_NX(info);
		else if (nx == columnInfoDtl_column_nm) doInfoDtl_column_nm_NX(info);
		else if (nx == columnInfoDtl_sumcond) doInfoDtl_sumcond_NX(info);
		else if (nx == columnInfoDtl_rank) doInfoDtl_rank_NX(info);
		else if (nx == columnInfoDtl_fill_dt) doInfoDtl_fill_dt_NX(info);
		else if (nx == columnInfoDtl_date_fmt) doInfoDtl_date_fmt_NX(info);
		else if (nx == columnInfoDtl_formula) doInfoDtl_formula_NX(info);
		else if (nx == columnInfoDtl_dec_place) doInfoDtl_dec_place_NX(info);
		else if (nx == columnInfoDtl_rounding_mode_type) doInfoDtl_rounding_mode_type_NX(info);
		else if (nx == columnInfoDtl_rounding_mode_type_nm) doInfoDtl_rounding_mode_type_nm_NX(info);
		else if (nx == columnInfoDtl_null_zero) doInfoDtl_null_zero_NX(info);
		else if (nx == columnInfoDtl_sort_order) doInfoDtl_sort_order_NX(info);
		else if (nx == columnInfoDtl_sort_type) doInfoDtl_sort_type_NX(info);
		else if (nx == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_NX(info);
		else if (nx == columnInfoDtl_chart_type) doInfoDtl_chart_type_NX(info);
		else if (nx == columnInfoDtl_chart_type_nm) doInfoDtl_chart_type_nm_NX(info);
		else if (nx == columnInfoDtl_chart_color) doInfoDtl_chart_color_NX(info);
		else if (nx == columnInfoDtl_row_label) doInfoDtl_row_label_NX(info);
		else if (nx == InfoOpt_rank_type) doInfoOpt_rank_type_NX(info);
		else if (nx == InfoOpt_rank_type_nm) doInfoOpt_rank_type_nm_NX(info);
		else if (nx == InfoOpt_rank_size) doInfoOpt_rank_size_NX(info);
		else if (nx == InfoOpt_fill_dt_fm) doInfoOpt_fill_dt_fm_NX(info);
		else if (nx == InfoOpt_fill_dt_to) doInfoOpt_fill_dt_to_NX(info);
		else if (nx == InfoBtn_sum_info_nm) doInfoBtn_sum_info_nm_NX(info);
		else if (nx == InfoBtn_remark) doInfoBtn_remark_NX(info);
	}

	/**
	 * [ListDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NX(MCEventInfo info){
	}

	/**
	 * [View]TabのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_flg_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[disable]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_disable_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sumcond_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rank]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rank_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[fill_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_fill_dt_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date_fmt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_fmt_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[formula]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_formula_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[dec_place]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_dec_place_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[null_zero]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_null_zero_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_order]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_order_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_color]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_color_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[row_label]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_row_label_NX(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_size]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_size_NX(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_fm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_fm_NX(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_to]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_to_NX(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[sum_info_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_sum_info_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_remark_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_LC(info);
		else if (lc == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_LC(info);
		else if (lc == columnListDtl_sum_info_id) doListDtl_sum_info_id_LC(info);
		else if (lc == columnListDtl_sum_info_nm) doListDtl_sum_info_nm_LC(info);
		else if (lc == columnListDtl_remark) doListDtl_remark_LC(info);
		else if (lc == columnInfoDtl_sum_info_type) doInfoDtl_sum_info_type_LC(info);
		else if (lc == columnInfoDtl_sum_info_type_nm) doInfoDtl_sum_info_type_nm_LC(info);
		else if (lc == columnInfoDtl_column_key) doInfoDtl_column_key_LC(info);
		else if (lc == columnInfoDtl_column_nm) doInfoDtl_column_nm_LC(info);
		else if (lc == columnInfoDtl_sumcond) doInfoDtl_sumcond_LC(info);
		else if (lc == columnInfoDtl_date_fmt) doInfoDtl_date_fmt_LC(info);
		else if (lc == columnInfoDtl_formula) doInfoDtl_formula_LC(info);
		else if (lc == columnInfoDtl_dec_place) doInfoDtl_dec_place_LC(info);
		else if (lc == columnInfoDtl_rounding_mode_type) doInfoDtl_rounding_mode_type_LC(info);
		else if (lc == columnInfoDtl_rounding_mode_type_nm) doInfoDtl_rounding_mode_type_nm_LC(info);
		else if (lc == columnInfoDtl_sort_order) doInfoDtl_sort_order_LC(info);
		else if (lc == columnInfoDtl_sort_type) doInfoDtl_sort_type_LC(info);
		else if (lc == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_LC(info);
		else if (lc == columnInfoDtl_chart_type) doInfoDtl_chart_type_LC(info);
		else if (lc == columnInfoDtl_chart_type_nm) doInfoDtl_chart_type_nm_LC(info);
		else if (lc == columnInfoDtl_chart_color) doInfoDtl_chart_color_LC(info);
		else if (lc == InfoOpt_rank_type) doInfoOpt_rank_type_LC(info);
		else if (lc == InfoOpt_rank_type_nm) doInfoOpt_rank_type_nm_LC(info);
		else if (lc == InfoOpt_rank_size) doInfoOpt_rank_size_LC(info);
		else if (lc == InfoOpt_fill_dt_fm) doInfoOpt_fill_dt_fm_LC(info);
		else if (lc == InfoOpt_fill_dt_to) doInfoOpt_fill_dt_to_LC(info);
		else if (lc == InfoBtn_sum_info_nm) doInfoBtn_sum_info_nm_LC(info);
		else if (lc == InfoBtn_remark) doInfoBtn_remark_LC(info);
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[sum_info_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_sum_info_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sum_info_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sum_info_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sumcond_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date_fmt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_fmt_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[formula]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_formula_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[dec_place]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_dec_place_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[rounding_mode_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_rounding_mode_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_order]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_order_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[chart_color]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_chart_color_LC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[rank_size]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_rank_size_LC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_fm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_fm_LC(MCEventInfo info){
	}

	/**
	 * [InfoOpt]パネルの[fill_dt_to]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoOpt_fill_dt_to_LC(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[sum_info_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_sum_info_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_remark_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_sum_info_type_nm]の作成メソッド
	 */
	public MCList getInfoDtl_sum_info_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSumInfoType(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_column_nm]の作成メソッド
	 */
	public MCList getInfoDtl_column_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_date_fmt]の作成メソッド
	 */
	public MCList getInfoDtl_date_fmt(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_rounding_mode_type_nm]の作成メソッド
	 */
	public MCList getInfoDtl_rounding_mode_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getRoundingModeType(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_sort_type]の作成メソッド
	 */
	public MCList getInfoDtl_sort_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSortType(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_chart_type_nm]の作成メソッド
	 */
	public MCList getInfoDtl_chart_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getGadgetChartType(row, info);
	}

	/**
	 * コンボ／リストのリスト[InfoOpt_rank_type_nm]の作成メソッド
	 */
	public MCList getInfoOpt_rank_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSortType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}