package mcframe.clientFSBA.FSBAP0360;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoDtlR_FW_A extends MCConstRow {

	/**
	 *  無効.<p>
	 *
	 */
	public static final String $disable = "disable";
	public static final String $sum_info_type = "sum_info_type";
	/**
	 *  集計区分名.<p>
	 *
	 */
	public static final String $sum_info_type_nm = "sum_info_type_nm";
	public static final String $column_key = "column_key";
	/**
	 *  カラム名.<p>
	 *
	 */
	public static final String $column_nm = "column_nm";
	/**
	 *  集計条件名.<p>
	 *
	 */
	public static final String $sumcond = "sumcond";
	/**
	 *  順位対象.<p>
	 *
	 */
	public static final String $rank = "rank";
	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public static final String $rank_type = "rank_type";
	/**
	 *  有効順位.<p>
	 *
	 */
	public static final String $rank_size = "rank_size";
	/**
	 *  日時補完.<p>
	 *
	 */
	public static final String $fill_dt = "fill_dt";
	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public static final String $fill_dt_fm = "fill_dt_fm";
	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public static final String $fill_dt_to = "fill_dt_to";
	/**
	 *  日付書式.<p>
	 *
	 */
	public static final String $date_fmt = "date_fmt";
	/**
	 *  計算式_ID.<p>
	 *
	 */
	public static final String $formula_calc = "formula_calc";
	/**
	 *  計算式.<p>
	 *
	 */
	public static final String $formula = "formula";
	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public static final String $dec_place = "dec_place";
	public static final String $rounding_mode_type = "rounding_mode_type";
	/**
	 *  端数処理区分名.<p>
	 *
	 */
	public static final String $rounding_mode_type_nm = "rounding_mode_type_nm";
	/**
	 *  null集計0変換.<p>
	 *
	 */
	public static final String $null_zero = "null_zero";
	/**
	 *  ソート順.<p>
	 *
	 */
	public static final String $sort_order = "sort_order";
	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public static final String $sort_type = "sort_type";
	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public static final String $sort_type_nm = "sort_type_nm";
	public static final String $chart_type = "chart_type";
	/**
	 *  グラフ名.<p>
	 *
	 */
	public static final String $chart_type_nm = "chart_type_nm";
	public static final String $chart_color = "chart_color";
	public static final String $chart_color_p = "chart_color_p";
	/**
	 *  行ラベル（チャート）.<p>
	 *
	 */
	public static final String $row_label = "row_label";

	public static final String $red = $chart_color_p + ".red";
	public static final String $green = $chart_color_p + ".green";
	public static final String $blue = $chart_color_p + ".blue";
	public static final String $color = $chart_color_p + ".color";

	public static final MCMeta disable_META = createCommonMeta($disable, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta sum_info_type_META = createStringMeta($sum_info_type);
	public static final MCMeta sum_info_type_nm_META = createStringMeta($sum_info_type_nm);
	public static final MCMeta column_key_META = createStringMeta($column_key);
	public static final MCMeta column_nm_META = createCommonMeta($column_nm, mcframe.commonCore.meta.M_META.LABEL);
	public static final MCMeta sumcond_META = createStringMeta($sumcond);
	public static final MCMeta rank_META = createCommonMeta($rank, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta rank_type_META = createStringMeta($rank_type);
	public static final MCMeta rank_size_META = createNumberMeta($rank_size);
	public static final MCMeta fill_dt_META = createCommonMeta($fill_dt, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta fill_dt_fm_META = createCommonMeta($fill_dt_fm, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta fill_dt_to_META = createCommonMeta($fill_dt_to, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta date_fmt_META = createStringMeta($date_fmt);
	public static final MCMeta formula_calc_META = createCommonMeta($formula_calc, mcframe.commonCore.meta.M_META.FORMULA);
	public static final MCMeta formula_META = createCommonMeta($formula, mcframe.commonCore.meta.M_META.FORMULA);
	public static final MCMeta dec_place_META = createNumberMeta($dec_place, 2, 0, false);
	public static final MCMeta rounding_mode_type_META = createStringMeta($rounding_mode_type);
	public static final MCMeta rounding_mode_type_nm_META = createStringMeta($rounding_mode_type_nm);
	public static final MCMeta null_zero_META = createCommonMeta($null_zero, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta sort_order_META = createNumberMeta($sort_order);
	public static final MCMeta sort_type_META = createStringMeta($sort_type);
	public static final MCMeta sort_type_nm_META = createStringMeta($sort_type_nm);
	public static final MCMeta chart_type_META = createNumberMeta($chart_type);
	public static final MCMeta chart_type_nm_META = createStringMeta($chart_type_nm);
	public static final MCMeta chart_color_META = createCommonMeta($chart_color, mcframe.commonCore.meta.M_META.COLOR);
	public static final MCMeta chart_color_p_META = createInnerRowMeta($chart_color_p, mcframe.clientFSUB.FSUBP0050.ColorR.class);
	public static final MCMeta row_label_META = createCommonMeta($row_label, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<InfoDtlR> constMetas = new ConstMetaList<InfoDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			disable_META,
			sum_info_type_META,
			sum_info_type_nm_META,
			column_key_META,
			column_nm_META,
			sumcond_META,
			rank_META,
			rank_type_META,
			rank_size_META,
			fill_dt_META,
			fill_dt_fm_META,
			fill_dt_to_META,
			date_fmt_META,
			formula_calc_META,
			formula_META,
			dec_place_META,
			rounding_mode_type_META,
			rounding_mode_type_nm_META,
			null_zero_META,
			sort_order_META,
			sort_type_META,
			sort_type_nm_META,
			chart_type_META,
			chart_type_nm_META,
			chart_color_META,
			chart_color_p_META,
			row_label_META
		},
		new String[][]{
			{
				"red",
				"green",
				"blue",
			},
			{
				$red,
				$green,
				$blue,
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoDtlR_FW_A(ConstMetaList<? extends InfoDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR clone() {
		return (InfoDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR createInstance() {
		return (InfoDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR getValues(String... names) {
		return (InfoDtlR) super.getValues(names);
	}



	/**
	 *  無効.<p>
	 *
	 */
	public boolean disable() {
		return getConstBoolean(offset + 0, $disable);
	}

	/**
	 *  無効.<p>
	 *
	 */
	public void disable(boolean value) {
		setConstBoolean(offset + 0, $disable, value);
	}


	public String sum_info_type() {
		return getConstString(offset + 1, $sum_info_type);
	}

	public void sum_info_type(String value) {
		setConstString(offset + 1, $sum_info_type, value);
	}


	/**
	 *  集計区分名.<p>
	 *
	 */
	public String sum_info_type_nm() {
		return getConstString(offset + 2, $sum_info_type_nm);
	}

	/**
	 *  集計区分名.<p>
	 *
	 */
	public void sum_info_type_nm(String value) {
		setConstString(offset + 2, $sum_info_type_nm, value);
	}


	public String column_key() {
		return getConstString(offset + 3, $column_key);
	}

	public void column_key(String value) {
		setConstString(offset + 3, $column_key, value);
	}


	/**
	 *  カラム名.<p>
	 *
	 */
	public String column_nm() {
		return getConstString(offset + 4, $column_nm);
	}

	/**
	 *  カラム名.<p>
	 *
	 */
	public void column_nm(String value) {
		setConstString(offset + 4, $column_nm, value);
	}


	/**
	 *  集計条件名.<p>
	 *
	 */
	public String sumcond() {
		return getConstString(offset + 5, $sumcond);
	}

	/**
	 *  集計条件名.<p>
	 *
	 */
	public void sumcond(String value) {
		setConstString(offset + 5, $sumcond, value);
	}


	/**
	 *  順位対象.<p>
	 *
	 */
	public boolean rank() {
		return getConstBoolean(offset + 6, $rank);
	}

	/**
	 *  順位対象.<p>
	 *
	 */
	public void rank(boolean value) {
		setConstBoolean(offset + 6, $rank, value);
	}


	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public String rank_type() {
		return getConstString(offset + 7, $rank_type);
	}

	/**
	 *  順位ソートタイプ.<p>
	 *
	 */
	public void rank_type(String value) {
		setConstString(offset + 7, $rank_type, value);
	}


	/**
	 *  有効順位.<p>
	 *
	 */
	public MCNumber rank_size() {
		return getConstNumber(offset + 8, $rank_size);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(MCNumber value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(int value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(long value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(float value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 *  有効順位.<p>
	 *
	 */
	public void rank_size(double value) {
		setConstNumber(offset + 8, $rank_size, value);
	}


	/**
	 *  日時補完.<p>
	 *
	 */
	public boolean fill_dt() {
		return getConstBoolean(offset + 9, $fill_dt);
	}

	/**
	 *  日時補完.<p>
	 *
	 */
	public void fill_dt(boolean value) {
		setConstBoolean(offset + 9, $fill_dt, value);
	}


	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public MCTimestamp fill_dt_fm() {
		return getConstTimestamp(offset + 10, $fill_dt_fm);
	}

	/**
	 *  日時補完開始日時.<p>
	 *
	 */
	public void fill_dt_fm(MCTimestamp value) {
		setConstTimestamp(offset + 10, $fill_dt_fm, value);
	}


	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public MCTimestamp fill_dt_to() {
		return getConstTimestamp(offset + 11, $fill_dt_to);
	}

	/**
	 *  日時補完終了日時.<p>
	 *
	 */
	public void fill_dt_to(MCTimestamp value) {
		setConstTimestamp(offset + 11, $fill_dt_to, value);
	}


	/**
	 *  日付書式.<p>
	 *
	 */
	public String date_fmt() {
		return getConstString(offset + 12, $date_fmt);
	}

	/**
	 *  日付書式.<p>
	 *
	 */
	public void date_fmt(String value) {
		setConstString(offset + 12, $date_fmt, value);
	}


	/**
	 *  計算式_ID.<p>
	 *
	 */
	public String formula_calc() {
		return getConstString(offset + 13, $formula_calc);
	}

	/**
	 *  計算式_ID.<p>
	 *
	 */
	public void formula_calc(String value) {
		setConstString(offset + 13, $formula_calc, value);
	}


	/**
	 *  計算式.<p>
	 *
	 */
	public String formula() {
		return getConstString(offset + 14, $formula);
	}

	/**
	 *  計算式.<p>
	 *
	 */
	public void formula(String value) {
		setConstString(offset + 14, $formula, value);
	}


	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public MCNumber dec_place() {
		return getConstNumber(offset + 15, $dec_place);
	}

	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public void dec_place(MCNumber value) {
		setConstNumber(offset + 15, $dec_place, value);
	}

	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public void dec_place(int value) {
		setConstNumber(offset + 15, $dec_place, value);
	}

	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public void dec_place(long value) {
		setConstNumber(offset + 15, $dec_place, value);
	}

	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public void dec_place(float value) {
		setConstNumber(offset + 15, $dec_place, value);
	}

	/**
	 *  小数部有効桁数.<p>
	 *
	 */
	public void dec_place(double value) {
		setConstNumber(offset + 15, $dec_place, value);
	}


	public String rounding_mode_type() {
		return getConstString(offset + 16, $rounding_mode_type);
	}

	public void rounding_mode_type(String value) {
		setConstString(offset + 16, $rounding_mode_type, value);
	}


	/**
	 *  端数処理区分名.<p>
	 *
	 */
	public String rounding_mode_type_nm() {
		return getConstString(offset + 17, $rounding_mode_type_nm);
	}

	/**
	 *  端数処理区分名.<p>
	 *
	 */
	public void rounding_mode_type_nm(String value) {
		setConstString(offset + 17, $rounding_mode_type_nm, value);
	}


	/**
	 *  null集計0変換.<p>
	 *
	 */
	public boolean null_zero() {
		return getConstBoolean(offset + 18, $null_zero);
	}

	/**
	 *  null集計0変換.<p>
	 *
	 */
	public void null_zero(boolean value) {
		setConstBoolean(offset + 18, $null_zero, value);
	}


	/**
	 *  ソート順.<p>
	 *
	 */
	public MCNumber sort_order() {
		return getConstNumber(offset + 19, $sort_order);
	}

	/**
	 *  ソート順.<p>
	 *
	 */
	public void sort_order(MCNumber value) {
		setConstNumber(offset + 19, $sort_order, value);
	}

	/**
	 *  ソート順.<p>
	 *
	 */
	public void sort_order(int value) {
		setConstNumber(offset + 19, $sort_order, value);
	}

	/**
	 *  ソート順.<p>
	 *
	 */
	public void sort_order(long value) {
		setConstNumber(offset + 19, $sort_order, value);
	}

	/**
	 *  ソート順.<p>
	 *
	 */
	public void sort_order(float value) {
		setConstNumber(offset + 19, $sort_order, value);
	}

	/**
	 *  ソート順.<p>
	 *
	 */
	public void sort_order(double value) {
		setConstNumber(offset + 19, $sort_order, value);
	}


	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public String sort_type() {
		return getConstString(offset + 20, $sort_type);
	}

	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public void sort_type(String value) {
		setConstString(offset + 20, $sort_type, value);
	}


	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public String sort_type_nm() {
		return getConstString(offset + 21, $sort_type_nm);
	}

	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public void sort_type_nm(String value) {
		setConstString(offset + 21, $sort_type_nm, value);
	}


	public MCNumber chart_type() {
		return getConstNumber(offset + 22, $chart_type);
	}

	public void chart_type(MCNumber value) {
		setConstNumber(offset + 22, $chart_type, value);
	}

	public void chart_type(int value) {
		setConstNumber(offset + 22, $chart_type, value);
	}

	public void chart_type(long value) {
		setConstNumber(offset + 22, $chart_type, value);
	}

	public void chart_type(float value) {
		setConstNumber(offset + 22, $chart_type, value);
	}

	public void chart_type(double value) {
		setConstNumber(offset + 22, $chart_type, value);
	}


	/**
	 *  グラフ名.<p>
	 *
	 */
	public String chart_type_nm() {
		return getConstString(offset + 23, $chart_type_nm);
	}

	/**
	 *  グラフ名.<p>
	 *
	 */
	public void chart_type_nm(String value) {
		setConstString(offset + 23, $chart_type_nm, value);
	}


	public String chart_color() {
		return getConstString(offset + 24, $chart_color);
	}

	public void chart_color(String value) {
		setConstString(offset + 24, $chart_color, value);
	}


	public mcframe.clientFSUB.FSUBP0050.ColorR chart_color_p(){
		return (mcframe.clientFSUB.FSUBP0050.ColorR) getConstInnerRow(offset + 25, $chart_color_p);
	}
	
	public void chart_color_p(mcframe.clientFSUB.FSUBP0050.ColorR row){
		setConstInnerRow(offset + 25, $chart_color_p, row);
	}


	/**
	 *  行ラベル（チャート）.<p>
	 *
	 */
	public boolean row_label() {
		return getConstBoolean(offset + 26, $row_label);
	}

	/**
	 *  行ラベル（チャート）.<p>
	 *
	 */
	public void row_label(boolean value) {
		setConstBoolean(offset + 26, $row_label, value);
	}


	public String getString(String name) {
		if ($sum_info_type.equalsIgnoreCase(name)) {
			return sum_info_type();
		}
		if ($sum_info_type_nm.equalsIgnoreCase(name)) {
			return sum_info_type_nm();
		}
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			return sumcond();
		}
		if ($rank_type.equalsIgnoreCase(name)) {
			return rank_type();
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			return date_fmt();
		}
		if ($formula_calc.equalsIgnoreCase(name)) {
			return formula_calc();
		}
		if ($formula.equalsIgnoreCase(name)) {
			return formula();
		}
		if ($rounding_mode_type.equalsIgnoreCase(name)) {
			return rounding_mode_type();
		}
		if ($rounding_mode_type_nm.equalsIgnoreCase(name)) {
			return rounding_mode_type_nm();
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			return sort_type();
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			return sort_type_nm();
		}
		if ($chart_type_nm.equalsIgnoreCase(name)) {
			return chart_type_nm();
		}
		if ($chart_color.equalsIgnoreCase(name)) {
			return chart_color();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($rank_size.equalsIgnoreCase(name)) {
			return rank_size();
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			return dec_place();
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			return sort_order();
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			return chart_type();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			return fill_dt_fm();
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			return fill_dt_to();
		}
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		if ($disable.equalsIgnoreCase(name)) {
			return disable();
		}
		if ($rank.equalsIgnoreCase(name)) {
			return rank();
		}
		if ($fill_dt.equalsIgnoreCase(name)) {
			return fill_dt();
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			return null_zero();
		}
		if ($row_label.equalsIgnoreCase(name)) {
			return row_label();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($sum_info_type.equalsIgnoreCase(name)) {
			return sum_info_type();
		}
		if ($sum_info_type_nm.equalsIgnoreCase(name)) {
			return sum_info_type_nm();
		}
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			return sumcond();
		}
		if ($rank_type.equalsIgnoreCase(name)) {
			return rank_type();
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			return date_fmt();
		}
		if ($formula_calc.equalsIgnoreCase(name)) {
			return formula_calc();
		}
		if ($formula.equalsIgnoreCase(name)) {
			return formula();
		}
		if ($rounding_mode_type.equalsIgnoreCase(name)) {
			return rounding_mode_type();
		}
		if ($rounding_mode_type_nm.equalsIgnoreCase(name)) {
			return rounding_mode_type_nm();
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			return sort_type();
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			return sort_type_nm();
		}
		if ($chart_type_nm.equalsIgnoreCase(name)) {
			return chart_type_nm();
		}
		if ($chart_color.equalsIgnoreCase(name)) {
			return chart_color();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($rank_size.equalsIgnoreCase(name)) {
			return rank_size();
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			return dec_place();
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			return sort_order();
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			return chart_type();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			return fill_dt_fm();
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			return fill_dt_to();
		}
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($disable.equalsIgnoreCase(name)) {
			return disable();
		}
		if ($rank.equalsIgnoreCase(name)) {
			return rank();
		}
		if ($fill_dt.equalsIgnoreCase(name)) {
			return fill_dt();
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			return null_zero();
		}
		if ($row_label.equalsIgnoreCase(name)) {
			return row_label();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($sum_info_type.equalsIgnoreCase(name)) {
			sum_info_type(value);
			return;
		}
		if ($sum_info_type_nm.equalsIgnoreCase(name)) {
			sum_info_type_nm(value);
			return;
		}
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			sumcond(value);
			return;
		}
		if ($rank_type.equalsIgnoreCase(name)) {
			rank_type(value);
			return;
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			date_fmt(value);
			return;
		}
		if ($formula_calc.equalsIgnoreCase(name)) {
			formula_calc(value);
			return;
		}
		if ($formula.equalsIgnoreCase(name)) {
			formula(value);
			return;
		}
		if ($rounding_mode_type.equalsIgnoreCase(name)) {
			rounding_mode_type(value);
			return;
		}
		if ($rounding_mode_type_nm.equalsIgnoreCase(name)) {
			rounding_mode_type_nm(value);
			return;
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			sort_type(value);
			return;
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			sort_type_nm(value);
			return;
		}
		if ($chart_type_nm.equalsIgnoreCase(name)) {
			chart_type_nm(value);
			return;
		}
		if ($chart_color.equalsIgnoreCase(name)) {
			chart_color(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			fill_dt_fm(value);
			return;
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			fill_dt_to(value);
			return;
		}
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($disable.equalsIgnoreCase(name)) {
			disable(value);
			return;
		}
		if ($rank.equalsIgnoreCase(name)) {
			rank(value);
			return;
		}
		if ($fill_dt.equalsIgnoreCase(name)) {
			fill_dt(value);
			return;
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			null_zero(value);
			return;
		}
		if ($row_label.equalsIgnoreCase(name)) {
			row_label(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($sum_info_type.equalsIgnoreCase(name)) {
			sum_info_type(value);
			return;
		}
		if ($sum_info_type_nm.equalsIgnoreCase(name)) {
			sum_info_type_nm(value);
			return;
		}
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			sumcond(value);
			return;
		}
		if ($rank_type.equalsIgnoreCase(name)) {
			rank_type(value);
			return;
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			date_fmt(value);
			return;
		}
		if ($formula_calc.equalsIgnoreCase(name)) {
			formula_calc(value);
			return;
		}
		if ($formula.equalsIgnoreCase(name)) {
			formula(value);
			return;
		}
		if ($rounding_mode_type.equalsIgnoreCase(name)) {
			rounding_mode_type(value);
			return;
		}
		if ($rounding_mode_type_nm.equalsIgnoreCase(name)) {
			rounding_mode_type_nm(value);
			return;
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			sort_type(value);
			return;
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			sort_type_nm(value);
			return;
		}
		if ($chart_type_nm.equalsIgnoreCase(name)) {
			chart_type_nm(value);
			return;
		}
		if ($chart_color.equalsIgnoreCase(name)) {
			chart_color(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($chart_type.equalsIgnoreCase(name)) {
			chart_type(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			fill_dt_fm(value);
			return;
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			fill_dt_to(value);
			return;
		}
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($disable.equalsIgnoreCase(name)) {
			disable(value);
			return;
		}
		if ($rank.equalsIgnoreCase(name)) {
			rank(value);
			return;
		}
		if ($fill_dt.equalsIgnoreCase(name)) {
			fill_dt(value);
			return;
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			null_zero(value);
			return;
		}
		if ($row_label.equalsIgnoreCase(name)) {
			row_label(value);
			return;
		}
		super.setBooleanNE(name, value);
	}

	public MCRow getInnerRow(String name) {
		if ($chart_color_p.equalsIgnoreCase(name)) {
			return chart_color_p();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($chart_color_p.equalsIgnoreCase(name)) {
			chart_color_p(
				((MCContainerMeta) chart_color_p_META).castInnerRow(mcframe.clientFSUB.FSUBP0050.ColorR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public MCNumber red() {
		return chart_color_p().red();
	}

	public void red(MCNumber value) {
		chart_color_p().red(value);
	}

	public void red(int value) {
		chart_color_p().red(value);
	}

	public void red(long value) {
		chart_color_p().red(value);
	}

	public void red(float value) {
		chart_color_p().red(value);
	}

	public void red(double value) {
		chart_color_p().red(value);
	}

	public MCNumber green() {
		return chart_color_p().green();
	}

	public void green(MCNumber value) {
		chart_color_p().green(value);
	}

	public void green(int value) {
		chart_color_p().green(value);
	}

	public void green(long value) {
		chart_color_p().green(value);
	}

	public void green(float value) {
		chart_color_p().green(value);
	}

	public void green(double value) {
		chart_color_p().green(value);
	}

	public MCNumber blue() {
		return chart_color_p().blue();
	}

	public void blue(MCNumber value) {
		chart_color_p().blue(value);
	}

	public void blue(int value) {
		chart_color_p().blue(value);
	}

	public void blue(long value) {
		chart_color_p().blue(value);
	}

	public void blue(float value) {
		chart_color_p().blue(value);
	}

	public void blue(double value) {
		chart_color_p().blue(value);
	}

}

