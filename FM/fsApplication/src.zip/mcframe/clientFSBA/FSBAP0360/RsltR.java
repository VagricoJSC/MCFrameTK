package mcframe.clientFSBA.FSBAP0360;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.annotation.EI;

/**
 * ブロック"Rslt"コンテナRowクラスです。<p>
 *
 * <br>
 *
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class RsltR extends RsltR_FW_A {

	/**
	 * 新しいRowを生成します。
	 *
	 * @return 新しいインスタンス
	 */
	public static RsltR create() {
		RsltR row = new RsltR(constMetas);
		return row;
	}

	/**
	 * 新しいRowを生成し別のRowの内容を設定します。
	 *
	 * @param proto 設定するRow
	 * @return 内容を設定した新しいインスタンス
	 */
	public static <T extends MCRow> RsltR createByName(T proto) {
		RsltR row = RsltR.create();
		copyByName(row, proto);
		return row;
	}

	/**
	 * コンストラクタです。
	 */
	public RsltR(ConstMetaList<? extends RsltR> metas) {
		super(metas);
	}
}