package mcframe.clientFSBA.FSBAP0360;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0060.*;
import mcframe.clientFSUB.FSUBP0090.*;
import mcframe.clientFSUB.FSUBP0120.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;

import mcframe.clientCore.beans.dashboard.MCDashboardUtil;
import mcframe.clientCore.beans.fxgraph.MCFXGraph;
import mcframe.clientCore.beans.fxgraph.MCFXGraphCore;
import mcframe.clientCore.beans.fxgraph.MCFXGraphDelegate;
import mcframe.clientCore.beans.fxgraph.MCFXGraphDetailsTooltip;
import mcframe.clientCore.beans.fxgraph.MCFXGraphDetailsTooltipPie;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.resource.MCPersonalizeResourceIO;
import mcframe.clientCore.beans.resource.MCRowFilterData;
import mcframe.clientCore.beans.resource.MCSumInfoData;
import mcframe.clientCore.beans.resource.MCSumInfoInfo;
import mcframe.clientCore.beans.resource.MCSumInfoResourceIO;
import mcframe.commonCore.expression.MCAggregateFunctions;
import mcframe.clientCore.expression.MCExpressionBuilder;
import mcframe.clientCore.mining.IfMCMiningBase;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.resource.MCFormatConst.MCZeroType;
import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.mining.MCMiningUtil;
import mcframe.clientFSUB.FSUBP0000.IfRowMoveBase;
import mcframe.clientFSUB.FSUBP0000.IfSumCondBase;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.commonFS.constant.FSC_GADGET_CHART_TYPE;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.commonFS.constant.FSC_ROUNDING_MODE_TYPE;
import mcframe.commonFS.constant.FSC_SORT_TYPE;
import mcframe.commonFS.constant.FSC_SUM_INFO_TYPE;

import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_SumInfo"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_SumInfo_FW extends FSBAP_SumInfo_FW_A implements IfRowMoveBase, IfSumCondBase, MCFXGraphDelegate {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 集計対象のテーブルです。
	 */
	protected MCTable<?> _table = null;

	/**
	 * 集計情報ＩＤと集計情報のマップです。
	 */
	protected Map<String, MCContainer[]> _sum_info_map = new HashMap<>();

	/**
	 * 集計情報Rowと集計条件のマップです。
	 */
	protected Map<InfoDtlR, List<MCRowFilter>> _sum_cond_map = new IdentityHashMap<>();

	/**
	 * 選択中の集計情報の集計条件のマップです。
	 */
	protected Map<InfoDtlR, List<MCRowFilter>> _sel_cond_map = new IdentityHashMap<>();

	/**
	 * 集計情報の接頭語です。
	 */
	protected static final String SUM_INFO_PREFIX = "user_";

	/**
	 * 順番の接頭語です。
	 */
	protected static final String ORDER_PREFIX = "order_";

	/**
	 * 計算項目の接頭語です。
	 */
	protected static final String CALC_PREFIX = "_calc_";

	/**
	 * グループ件数用の件数項目のカラム名です。
	 */
	protected static final String COUNT_GROUP = MCMiningUtil.COUNT_GROUP;

	/**
	 * 集計カラムの名称に集計区分を付加する位置：先頭
	 */
	protected static final String POSITION_HEAD = "head";

	/**
	 * 集計カラムの名称に集計区分を付加する位置：末尾
	 */
	protected static final String POSITION_TAIL = "tail";

	/**
	 * 最後の集計で作成した集計結果カラム上のリストです。
	 */
	protected List<WBP_ColumnInfo> _column_info_list;

	/**
	 * 設定情報ＩＤのシーケンス番号のマップです。
	 */
	protected Map<String, Integer> _setting_info_no_map = null;

	/**
	 * FXグラフです。
	 */
	protected MCFXGraph _graph;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SumInfo_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SumInfo_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[ListBtn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doListBtn_del(MCEventInfo info) {
		doDelAction();
	}

	/**
	 * 削除ボタンの処理を実行します。
	 */
	protected void doDelAction() {
		if (!execDelComfirm() || !checkForDel()) {
			return;
		}

		beforeDel();
		doDel();
		afterDel();

		showDelEndMsg();
	}

	/**
	 * 削除処理の実行確認メッセージを表示します。<p>
	 * 削除処理を続行する場合は true を返します。
	 *
	 * @return 削除処理を中断する場合は false
	 */
	protected boolean execDelComfirm() {
		if (!getInfoBtnR().isStatusNone() || !getInfoDtlL().isStatusNone()) {
			if (confirm(FXBAP0034) != MCMessageBox.YES_OPTION) {
				return false;
			}
			ListDtlR s = ListDtlTable.getSelectedMCRow();
			setInitListData(s);
			setInitInfoData(s);
		}

		MCMessage m = new MCMessage(FSBAC0068,
				FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
				getInfoBtnR().sum_info_nm());
		return confirm(MCDialogButton.NO, m) == MCMessageBox.YES_OPTION;
	}

	/**
	 * 削除処理の実行可否を判断します。
	 * 削除処理を続行する場合は true を返します。
	 *
	 * @return 削除処理を中断する場合は false
	 */
	protected boolean checkForDel() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s == null) {
			dialog(FXBAP0035);
			return false;
		}
		return true;
	}

	/**
	 * 削除処理の前処理を実行します。
	 */
	protected void beforeDel() {

	}

	/**
	 * 削除処理を実行します。
	 */
	protected void doDel() {
		// 削除対象行を削除する
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		getListDtlL().remove(s);

		clearSelection(ListDtlTable);

		writeResource();
	}

	/**
	 * 削除処理の後処理を実行します。
	 */
	protected void afterDel() {
		// コンテナのステータスをクリアする
		statusClear();

		screenClear();
	}

	/**
	 * 削除完了メッセージを表示します。
	 */
	protected void showDelEndMsg() {
		dialog(FXBAP0022);
	}

	/**
	 * Panel[ListBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doListBtn_radd(MCEventInfo info) {
		insertRow(ListDtlTable);
	}
	/**
	 * Panel[ListBtn]のボタン[rcopy]の押下時の処理
	 */
	@Override
	public void doListBtn_rcopy(MCEventInfo info) {
		doCopyRowAction();
	}

	/**
	 * 行コピーボタンの処理を実行します。
	 */
	protected void doCopyRowAction() {
		if (!checkForCopyRow()) {
			return;
		}

		beforeCopyRow();
		doCopyRow();
		afterCopyRow();
	}

	/**
	 * 行コピーの処理の実行可否を判断します。<p>
	 * 行コピーの処理を続行する場合は true を返します。
	 *
	 * @return 行コピーの処理を中断する場合は false
	 */
	protected boolean checkForCopyRow() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s == null || s.isEmpty()) {
			return false;
		}
		if (!getInfoBtnR().isStatusNone() || !getInfoDtlL().isStatusNone()) {
			return false;
		}
		return true;
	}

	/**
	 * 行コピーの処理の前処理を実行します。
	 */
	protected void beforeCopyRow() {

	}

	/**
	 * 行コピーの処理を実行します。
	 */
	protected void doCopyRow() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		ListDtlR n = s.clone();

		ListDtlTable.insertRow(s.getGUIIndex() + 1, n);

		n.init_flg(false);
		n.sum_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		n.setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(n, 
				ListDtlR.$setting_unit_type, 
				ListDtlR.$setting_unit_type_nm);
// 2017/01/05 登録名も複製する
//		n.sum_info_nm(null);
		n.setStatus(MCRow.CREATE);
	}

	/**
	 * 行コピーの処理の後処理を実行します。
	 */
	protected void afterCopyRow() {
		for (InfoDtlR o : getInfoDtlL()) {
			if (!o.isEmpty()) {
				o.setStatus(MCRow.CREATE);
			}
		}

		getInfoBtnR().init_flg(false);
		getInfoBtnR().sum_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		getInfoBtnR().setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(getInfoBtnR(), 
				ListDtlR.$setting_unit_type, 
				ListDtlR.$setting_unit_type_nm);
		// 2017/01/05 登録名も複製する
//		getInfoBtnR().sum_info_nm(null);

		setStatus(EDIT);
	}

	/**
	 * Panel[ListBtn]のボタン[sum]の押下時の処理
	 */
	@Override
	public void doListBtn_sum(MCEventInfo info) {
		if (checkForSum()) {
			doSum();
		}
	}

	/**
	 * 集計処理のためのチェックを行います。
	 */
	protected boolean checkForSum() {
		MCList<InfoDtlR> l = exceptDeleteAndEmpty(getInfoDtlL());
		InfoOptR opt = getInfoOptR();

		// 必須入力項目をチェックする
		MCMessageList m = checkReq(l);
		if (!m.isEmpty()) {
			message(m);
			return false;
		}

		// データの重複がないかどうかチェックする
		checkDuplicate(m, l, InfoDtlTable,
				getCheckDuplicateInfoDtlColumnNames());
		if (!m.isEmpty()) {
			message(m);
			return false;
		}

		// 有効なデータがあるかどうかチェックする
		int cnt_chart = 0;
		int cnt_color = 0;
		int cnt_grpcol = 0;
		boolean rank = false;
		boolean fill_dt = false;
		MCMessageList ml = new MCMessageList(); 
		MCList<InfoDtlR> v = createInfoDtlL();
		for (InfoDtlR o : l) {
			if (o.disable()) {
				continue;
			}

			// グループ化カラムチェック
			if (!FSC_SUM_INFO_TYPE.isTYPE_GROUP(o.sum_info_type())) {
				v.add(o);
			}
			else {
				cnt_grpcol++;
			}

			// 順位カラムチェック
			if (o.rank()) {
				rank = true;
				o.rank_type(opt.rank_type());
				o.rank_size(opt.rank_size());
			}

			// 日時補完カラムチェック
			if (o.fill_dt()) {
				fill_dt = true;
				o.fill_dt_fm(opt.fill_dt_fm());
				o.fill_dt_to(opt.fill_dt_to());
			}

			
			// IDに変換済みの計算式のチェック
			checkFormulaCalc(o, ml);

			// グラフ色指定チェック
			if (!isNull(o.chart_type())) {
				cnt_chart++;

				String rgb = MCFXGraph.createColorValue(
						o.chart_color_p().red(),
						o.chart_color_p().green(),
						o.chart_color_p().blue()
					);
				o.chart_color(rgb);
				if (rgb != null) {
					cnt_color++;
				}
			}
		}

		// 集計情報がない
		if (v.size() == 0) {
			dialog(FSBAC0053);
			return false;
		}
		
		// IDに変換済みの計算式が不正
		if (!ml.isEmpty()) {
			message(ml);
			return false;
		}

		// 順位を使用する場合、順位ソートタイプと有効順位の設定が必要
		if (rank && (isNull(opt.rank_type()) || isNull(opt.rank_size()))) {
			dialog(FSBAC0077);
			return false;
		}
		// 順位対象がないのに設定の入力がある
		if (!rank && (!isNull(opt.rank_type()) || !isNull(opt.rank_size()))) {
			dialog(FSBAC0078);
			return false;
		}

		// 日時補完する場合、グループ化項目は１つまで
		if (fill_dt && cnt_grpcol > 1) {
			dialog(FSBAC0079);
			return false;
		}
		// 日時補完対象がないのに期間の入力がある
		if (!fill_dt && (!isNull(opt.fill_dt_fm()) || !isNull(opt.fill_dt_to()))) {
			dialog(FSBAC0080);
			return false;
		}
		// 期間の from to の関係がおかしい
		m = checkBeforeAfter(InfoOpt_fill_dt_fm, InfoOpt_fill_dt_fm);
		if (!m.isEmpty()) {
			message(m);
			return false;
		}

		// 色指定する場合はすべてのグラフに設定する
		if (cnt_color > 0 && cnt_color != cnt_chart) {
			dialog(FSBAC0071);
			return false;
		}

		return true;
	}

	/**
	 * 集計処理を実行します。
	 */
	@SuppressWarnings("unchecked")
	protected void doSum() {
		// 集計結果をクリアする
		getRsltL().clear();

		MCTable<?> t = getTargetTable();				// 親画面のテーブル
		MCList pl = t.getViewRows();					// 親画面のリスト
		MCRow to = t.getList().createRow();				// 親画面のリストのロウ
		String[] pca = to.getConstColumnPathArray();	// 親画面のリストの固定カラム
		String[] pta = to.getTempNameArray();			// 親画面のリストの一時カラム
		MCList tl = (pta.length > 0)					// 集計処理用のリスト
						? t.getList().shallowClone()
						: t.getList().createInstance();
		tl.clear();
		MCList<RsltR> result = getRsltL();				// 集計結果（画面表示用）
		MCList<RsltR> rl = createRsltL();				// 集計結果（一時格納用）


		// カラムを全削除する
		for (MCColumnConfig c : RsltTable.getColumnConfigs()) {
			RsltTable.removeColumnConfig(c);
		}

		// 集計結果カラムとカラム情報の生成
		_column_info_list = new ArrayList<WBP_ColumnInfo>();
		List<WBP_ColumnInfo> cil = _column_info_list;
		for (InfoDtlR o : getInfoDtlL()) {
			if (o.isEmpty() || o.isStatusDelete() || o.disable()) {
				continue;
			}

			WBP_ColumnInfo ci = createColumnInfo(o);
			if (ci == null || ci.getColumnType() == null) {
				continue;
			}

			addValueColumn(ci.getColumnName(), ci.getMeta().type(),
					tl, result, rl);

			RsltTable.addColumnConfig(createColumnConfig(ci));

			cil.add(ci);
		}

		RsltTable.updateResource();
		RsltTable.initialized();

		if (cil.size() == 0) {
			return;
		}

		// 親画面のリストから集計処理用のリストに行をコピーする
		if (pta.length > 0) {
			for (MCRow o : pl.toArray()) {
				MCRow w = tl.createRow();
				w.setValues(pca, o, o.getConstColumnPathArray());
				String[] a = o.getTempNameArray();
				if (Arrays.equals(pta, a)) {
					w.setValues(pta, o, a);
				}
				tl.add(w);
			}
		}
		else {
			for (MCRow o : pl.toArray()) {
				MCRow w = tl.createRow();
				w.setValues(w.getConstColumnPathArray(),
						o, o.getConstColumnPathArray());
				tl.add(w);
			}
		}

		// 集計結果用のカラムに値を設定
		setValueBeforeSum(tl, cil);

		// 集計処理
		tl = doSumMain(tl, cil);

		// 集計後計算
		tl = calcAfterSum(tl, cil);

		// 順位
		tl = rankAfterSum(tl, cil);

		// 日時補完
		tl = fillDateAfterSum(tl, cil);

		// 集計結果表示
		setRsltTableAfterSum(rl, tl, cil);

		// グラフ表示
		updateGraph();
	}

	/**
	 * 集計処理用に、集計用カラムに値を設定します。
	 *
	 * @param tl 集計処理用リスト
	 * @param cil 集計結果情報のリスト
	 */
	@SuppressWarnings("unchecked")
	protected void setValueBeforeSum(MCList tl, List<WBP_ColumnInfo> cil) {
		// 集計前計算の変数変換マッピングリストの取得（数値項目ならSUM以外でも可）
		List<String>[] beforelists = getVariableMapList(FSC_SUM_INFO_TYPE.TYPE_SUM);

		// 集計結果用のカラムに値を設定
		for (WBP_ColumnInfo i : cil) {
			InfoDtlR o = i.getInfoDtlR();

			// 集計後計算以外の計算結果を設定
			if (!FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(o.sum_info_type())) {
				String formula = o.formula_calc();
				if (!isNull(formula)) {
					MCExpressionBuilder eb = createExpressionBuilder();
					if (!isNull(o.dec_place())) {
						eb.setDivideScale(o.dec_place().intValue());
					}
					if (!isNull(o.rounding_mode_type())) {
						RoundingMode m = FSC_ROUNDING_MODE_TYPE.toRoundingMode(
															o.rounding_mode_type());
						eb.setDivideRoundMode(m);
					}
					Set<String> colSet = new HashSet<>(beforelists[0]);
					eb.evaluate(formula, i.getColumnName(), tl, colSet);
				}
			}

			// 集計対象のカラムの値を設定
			MCColumnConfig tc = i.getTargetColumnConfig();
			if (tc == null) {
				// 画面にないカラム
				continue;
			}
			String pn = tc.getBaseRowColumnName();
			String cn = i.getColumnName();
			if (!isNullOr(pn, cn) && !isSame(pn, cn)) {
				tl.setColumnValue(cn, pn);
			}

			// 日時型の場合、書式に合わせて値を調整する
			switch (tc.getDataType()) {
			case DATE:
				tl.forEach(tr -> {
					MCRow row = (MCRow) tr;
					MCDate val = row.getDate(cn);
					if (val != null) {
						String fmtdt =
								MCConst.format.getDateOutputPattern(i.getFormatID());
						val = MCDate.valueOf(val.toString(fmtdt), fmtdt);
					}
					row.setDate(cn, val);
				});
				break;
			case TIMESTAMP:
				tl.forEach(tr -> {
					MCRow row = (MCRow) tr;
					MCTimestamp val = row.getTimestamp(cn);
					if (val != null) {
						String fmtdt =
								MCConst.format.getDateOutputPattern(i.getFormatID());
						val = MCTimestamp.valueOf(val.toString(fmtdt), fmtdt);
					}
					row.setTimestamp(cn, val);
				});
				break;
			default:
				break;
			}
		}
	}

	/**
	 * 集計処理を行います。
	 *
	 * @param tl 集計処理用リスト
	 * @param cil 集計結果情報のリスト
	 * @return 結果のリスト
	 */
	protected MCList doSumMain(MCList tl, List<WBP_ColumnInfo> cil) {
		MCGroupByPolicy gp = new MCGroupByPolicy(getGroupByColumnName(
				FSC_SUM_INFO_TYPE.TYPE_GROUP, cil));
		List<String> n2z_cols = new ArrayList<>();// null/0変換カラム
		for (WBP_ColumnInfo i : cil) {
			String col = i.getColumnName();
			InfoDtlR o = i.getInfoDtlR();
			FSC_SUM_INFO_TYPE type =  FSC_SUM_INFO_TYPE.getNE(o.sum_info_type());
			MCRowFilterList<MCRowFilter> matcher = null;
			List<MCRowFilter> conds = _sel_cond_map.get(o);
			if (conds != null && !conds.isEmpty()) {
				// 集計条件がある場合
				matcher = new MCRowFilterList<>(conds);
				matcher.setCoDate(getToday());
				matcher.setAggregateList(tl);
			}

			// null/0変換カラム
			if (o.null_zero()) {
				n2z_cols.add(col);
			}

			if (type == FSC_SUM_INFO_TYPE.TYPE_AVG) {
				MCNumber s = o.dec_place();
				if (isNull(s)) {
					// 小数桁数未設定の場合は画面の定義を使用
					s = getTargetColumnDecPlace(o.column_key());
				}
				RoundingMode m = FSC_ROUNDING_MODE_TYPE.toRoundingMode(
						o.rounding_mode_type());
				if (!isNull(s)) {
					gp.avg(col, col, matcher, s.intValue(), m);
				}
				else {
					gp.avg(col, col, matcher, m);
				}
			}
			else if (type == FSC_SUM_INFO_TYPE.TYPE_SUM) {
				gp.sum(col, col, matcher);
			}
			else if (type == FSC_SUM_INFO_TYPE.TYPE_MAX) {
				gp.max(col, col, matcher);
			}
			else if (type == FSC_SUM_INFO_TYPE.TYPE_MIN) {
				gp.min(col, col, matcher);
			}
			else if (type == FSC_SUM_INFO_TYPE.TYPE_COUNT) {
				gp.count(col, matcher);
			}
		}

		// 集計
		MCList<?> l = tl.groupBy(gp);
		l.forEach(r -> {
			// 集計結果 null/0変換
			MCRow row = r;
			for (String col : n2z_cols) {
				if (row.getNumber(col) == null) {
					row.setNumber(col, 0);
				}
			}
		});
		return l;
	}

	/**
	 * 集計対象のテーブルカラムに設定されている小数点以下の桁数を返します。
	 *
	 * @param col カラム名
	 * @return 小数点以下の桁数
	 */
	public MCNumber getTargetColumnDecPlace(String col) {
		MCNumber num = null;
		MCColumnConfig tc = getTargetColumnConfig(col);
		if (tc != null) {
			int vs = tc.getScale();
			if (vs < Integer.MAX_VALUE / 2) {
				num = MCNumber.valueOf(vs);
			}
		}
		return num;
	}

	/**
	 * 集計処理用に、集計処理後計算を行います。
	 *
	 * @param tl 集計処理結果のリスト
	 * @param cil 集計結果情報のリスト
	 * @return 結果のリスト
	 */
	protected MCList calcAfterSum(MCList tl, List<WBP_ColumnInfo> cil) {
		List<String>[] lists = getVariableMapList(FSC_SUM_INFO_TYPE.TYPE_AFTER_CALC);
		for (WBP_ColumnInfo i : cil) {
			InfoDtlR o = i.getInfoDtlR();
			FSC_SUM_INFO_TYPE type = FSC_SUM_INFO_TYPE.getNE(o.sum_info_type());
			if (!FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type)) {
				// 集計後計算以外はスルー
				continue;
			}

			String formula = o.formula_calc();
			if (isNull(formula)) {
				continue;
			}

			// 計算
			MCExpressionBuilder eb = createExpressionBuilder(tl);
			if (!isNull(o.dec_place())) {
				eb.setDivideScale(o.dec_place().intValue());
			}
			if (!isNull(o.rounding_mode_type())) {
				RoundingMode m = FSC_ROUNDING_MODE_TYPE.toRoundingMode(
													o.rounding_mode_type());
				eb.setDivideRoundMode(m);
			}
			Set<String> colSet = new HashSet<>(lists[0]);
			eb.evaluate(formula, i.getColumnName(), tl, colSet);
		}
		return tl;
	}

	/**
	 * 集計処理用に、集計結果の順位付け処理を行います。
	 *
	 * @param tl 集計処理結果のリスト
	 * @param cil 集計結果情報のリスト
	 * @return 結果のリスト
	 */
	protected MCList rankAfterSum(MCList tl, List<WBP_ColumnInfo> cil) {
		for (WBP_ColumnInfo i : cil) {
			InfoDtlR o = i.getInfoDtlR();
			if (!o.rank()) {
				// フラグが立っているもののみ処理
				continue;
			}
			// 順位
			tl = MCMiningUtil.rankList((MCList<MCRow>) tl,
							i.getColumnName(), o.rank_type(), o.rank_size());
			break;
		}
		return tl;
	}

	/**
	 * 集計処理用に、集計結果に日時補完処理を行います。
	 *
	 * @param tl 集計処理結果のリスト
	 * @param cil 集計結果情報のリスト
	 * @return 結果のリスト
	 */
	protected MCList fillDateAfterSum(MCList tl, List<WBP_ColumnInfo> cil) {
		for (WBP_ColumnInfo i : cil) {
			InfoDtlR o = i.getInfoDtlR();
			if (!o.fill_dt()) {
				// フラグが立っているもののみ処理
				continue;
			}
			// 日時補完
			tl = MCMiningUtil.fillDateRow((MCList<MCRow>) tl,
										i.getColumnName(), i.getFormatID(),
										o.fill_dt_fm(), o.fill_dt_to());
			break;
		}
		return tl;
	}

	/**
	 * 日時の補完データを追加します。
	 *
	 * @param ts 補完開始日時（含む）
	 * @param limit 補完終了日時（含まない）
	 * @param field 日時の精度
	 * @param list 補完するリスト
	 * @param col 日付カラム
	 * @param type データ型（DATE or TIMESTAMP）
	 * @return 次の補完開始日時（通常、補完終了日時と同じ）
	 */
	protected MCTimestamp fillDate(MCTimestamp ts, MCCalendarDate<?> limit,
				MCDateFieldType field, MCList list, String col, MCDataType type) {
		while (ts.compareToLeft(limit, field) < 0) {
			MCRow add = list.createRow();
			add.setValue(col, (type == MCDataType.DATE) ? MCDate.valueOf(ts) : ts);
			list.add(add);
			ts = incrementDate(ts, field);
		}
		return ts;
	}

	/**
	 * 精度を１つ進めた日時を返します。
	 *
	 * @param ts 日時
	 * @param field 精度
	 * @return １つ進めた日時
	 */
	protected MCTimestamp incrementDate(MCTimestamp ts, MCDateFieldType field) {
		if (field == null) {
		}
		else switch (field) {
		case YEAR:
			return ts.addYear(1);
		case MONTH:
			return ts.addMonth(1);
		case DAY:
			return ts.addDay(1);
		case HOUR:
			return ts.addHour(1);
		case MINUTE:
			return ts.addMinute(1);
		case SECOND:
			return ts.addSecond(1);
		case MILLISECOND:
			return ts.addMilliSecond(1);
		}
		return ts;
	}

	/**
	 * 集計処理結果を画面に設定します。
	 *
	 * @param rl 画面表示用のリスト
	 * @param tl 集計処理結果のリスト
	 * @param cil 集計結果情報のリスト
	 */
	protected void setRsltTableAfterSum(MCList<RsltR> rl, MCList tl, List<WBP_ColumnInfo> cil) {
		// 集計結果を表示用リストに格納する
		for (MCRow o : tl.toArray()) {
			RsltR w = rl.createRow();
			w.setValuesByName(o);
			rl.add(w);
		}
		setRsltL(rl);

		// 集計結果テーブルをソートする
		MCList<InfoDtlR> sil = createInfoDtlL();
		for (WBP_ColumnInfo i : cil) {
			InfoDtlR o = i.getInfoDtlR();
			if (!isNullOr(o.sort_order(), o.sort_type())) {
				sil.add(o);
			}
		}
		if (sil.size() > 0) {
			sil.sort(InfoDtlR.$sort_order);

			MCSortPolicy sp = new MCSortPolicy();
			for (InfoDtlR s : sil) {
				for (WBP_ColumnInfo i : cil) {
					if (s == i.getInfoDtlR()) {
						sp.add(FSC_SORT_TYPE.toSortType(
								s.sort_type()), i.getColumnName());
						break;
					}
				}
			}
			sort(RsltTable, sp);
		}

		// 現在のステータスを設定
		setStatus(getStatus());

		// 表示テーブル調整
		RsltTable.adjustWidth();
	}

	/**
	 * 現在の集計結果でグラフを更新します。
	 *
	 */
	protected void updateGraph() {
		final String label_sep = " / ";
// 2016/10/25 改行すると表示域が狭くなりラベルが間引かれてしまう
//		final String label_sep = " \n ";

		ChartPanel.setLayout(new BorderLayout());
		MCList<RsltR> graphL = getRsltL();

		// 作成
		if(_graph != null) {
			// 現在のグラフを破棄
			_graph.removePanel();
			_graph = null;
		}
		_graph = new MCFXGraph();
		_graph.setGraphDelegate(this);
		_graph.setUseThresholdRect(false); // 閾値枠（使わない）

		// 設定値バッファ
		String title = "";
		String valueTitle = "";
		String labelTitle = "";
		List<String> colorList = new ArrayList<>();
		List<Integer> typeList = new ArrayList<>();
		List<String> labelColumnsList = new ArrayList<>();
		List<String> valueColumnsList = new ArrayList<>();
		List<String> valueColumnsNameList = new ArrayList<>();
		List<String> labelTitleList = new ArrayList<>();
		List<WBP_ColumnInfo> grpInfoList = new ArrayList<>();


		for (WBP_ColumnInfo ci : _column_info_list) {
			InfoDtlR infoR = ci.getInfoDtlR();
			if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(infoR.sum_info_type())) {
				// グループ化ラベル
				grpInfoList.add(ci);
			}
			else {
				MCNumber chart = infoR.chart_type();
				if (!isNull(chart)) {
					// 値
					typeList.add(chart.intValue());
					// カラム名、ラベル
					valueColumnsList.add(ci.getColumnName());
					valueColumnsNameList.add(ci.getLabelName());
					// 色
					colorList.add(infoR.chart_color());
				}
			}
			if (infoR.row_label()) {
				// 行ラベル
				labelTitleList.add(ci.getLabelName());
			}
		}

		// ラベル
		if (grpInfoList.size() > 0) {
			final String tempcol = "$graph_label$";
			labelColumnsList.add(tempcol);
			graphL.addStringColumn(tempcol);
			graphL.forEach(graphR -> {
				StringBuilder sb = new StringBuilder();
				grpInfoList.forEach(ci -> {
					sb.append(getGraphLabel(graphR, ci));
					sb.append(label_sep);
				});
				sb.setLength(sb.length() - 3);
				graphR.setString(tempcol, sb.toString());
			});
		}

		// タイトル
		if (labelTitleList.size() > 0) {
			labelTitle = MCStringUtil.join(label_sep, labelTitleList.toArray(new String[0]));
		}

		// グラフ設定
		_graph.initInnerGraphControl(
				ChartPanel
				,title
				,typeList
				,colorList
				,graphL
				,labelColumnsList
				,labelTitle
				,valueColumnsList
				,valueColumnsNameList
				,valueTitle
			);
	}

	/**
	 * グラフのラベル用文字列を返します。
	 *
	 * @param rsltR データ
	 * @param ci 集計カラム情報
	 * @return 文字列
	 */
	protected String getGraphLabel(RsltR rsltR, WBP_ColumnInfo ci) {
		MCColumnConfig tc = ci.getTargetColumnConfig();
		String col = ci.getColumnName();
		String fmt = ci.getFormatID();
		return (tc == null)
					? MCDashboardUtil.graphLabel(null, null, null, null)// null文字列
					: MCDashboardUtil.graphLabel(rsltR, col, tc.getDataType(), fmt);
	}

	/**
	 * 集計結果のカラムを作成するための情報を作成します。
	 *
	 * @param info 集計情報
	 * @return 集計結果のカラムを作成するための情報
	 */
	protected WBP_ColumnInfo createColumnInfo(InfoDtlR info) {
		FSC_SUM_INFO_TYPE y = FSC_SUM_INFO_TYPE.getNE(info.sum_info_type());
		if (y == null) {
			return null;
		}

		WBP_ColumnInfo i = new WBP_ColumnInfo();

		if (!isNull(info.formula_calc())) {
			// 計算式
			i.setInfoDtlR(info);
			i.setColumnName(createRsltColumnName(
					info.column_key(), info.sumcond(), y));

			i.setMeta(MCMeta.createNumberMeta(
					i.getColumnName(), i.getColumnName(), true));
			i.setColumnType(MCColumnType.NUMBER);

			String ln = createNameWithSumType(info.column_nm(), info.sumcond(),
									getLabelName(y), getLabelPosition(y));
			i.setLabelName(ln);
			String mn = createNameWithSumType(info.column_nm(), info.sumcond(),
									getMessageName(y), getMessagePosition(y));
			i.setMessageName(mn);
			i.setCalcName(createRsltCalcLabel(info.column_nm(), info.sumcond(), y));
		}
		else if (FSC_SUM_INFO_TYPE.isTYPE_COUNT(y)) {
			// 件数
			i.setInfoDtlR(info);
			i.setColumnName(createRsltColumnName(
					COUNT_GROUP, info.sumcond(), y));

			i.setMeta(MCMeta.createNumberMeta(
					i.getColumnName(), i.getColumnName(), true));
			i.setColumnType(MCColumnType.NUMBER);

			String ln = createNameWithSumCond(getLabelName(y), info.sumcond());
			i.setLabelName(ln);
			String mn = createNameWithSumCond(getMessageName(y), info.sumcond());
			i.setMessageName(mn);
			i.setCalcName(createSumCondCalcLabel(y.name(), info.sumcond()));
		}
		else {
			// 計算式と件数以外
			MCColumnConfig tc = getTargetColumnConfig(info.column_key());
			if (tc == null) {
				return null;
			}
			i.setTargetColumnConfig(tc);

			i.setInfoDtlR(info);
			i.setColumnName(createRsltColumnName(
					tc.getBaseRowColumnName(), info.sumcond(), y));

			switch (tc.getDataType()) {
				case STRING:
					i.setMeta(MCMeta.createStringMeta(
							tc.getMeta().ID(), i.getColumnName()));
					i.setColumnType(MCColumnType.TEXT);
					break;
				case NUMBER:
					i.setMeta(MCMeta.createNumberMeta(
							tc.getMeta().ID(), i.getColumnName(), true));
					i.setColumnType(MCColumnType.NUMBER);
					i.setFormatID(tc.getNumberFormat().getID());
					break;
				case DATE:
					i.setMeta(MCMeta.createDateMeta(
							tc.getMeta().ID(), i.getColumnName()));
					i.setColumnType(MCColumnType.DATE);
					String fmtdt = info.date_fmt();
					i.setFormatID((fmtdt != null) ? fmtdt : tc.getDateFormat().getID());
					break;
				case TIMESTAMP:
					i.setMeta(MCMeta.createTimestampMeta(
							tc.getMeta().ID(), i.getColumnName()));
					i.setColumnType(MCColumnType.TIMESTAMP);
					String fmtts = info.date_fmt();
					i.setFormatID((fmtts != null) ? fmtts : tc.getTimestampFormat().getID());
					break;
				case BOOLEAN:
					i.setMeta(MCMeta.createBooleanMeta(
							tc.getMeta().ID(), i.getColumnName()));
					i.setColumnType(MCColumnType.CHECK);
					break;
				default:
					break;
			}

			String ln = createNameWithSumType(tc.getLabelByLocale(), info.sumcond(),
									getLabelName(y), getLabelPosition(y));
			i.setLabelName(ln);
			String mn = createNameWithSumType(tc.getMessageByLocale(), info.sumcond(),
									getMessageName(y), getMessagePosition(y));
			i.setMessageName(mn);
			// 7012-3088 miyake 
			// 計算式の項目名にはメッセージ用名称を使用（getColumnNameList()の名称取得と合わせる）
			i.setCalcName(createRsltCalcLabel(tc.getMessageByLocale(), info.sumcond(), y));
		}

		return i;
	}

	/**
	 * 集計区分付き名称を返します
	 *
	 * @param name 名称
	 * @param sumcond 集計条件名
	 * @param type 集計区分
	 * @param position 集計区分を付加する位置
	 * @return 生成した名称
	 */
	protected String createNameWithSumType(String name, String sumcond, String type, String position) {
		String n = createNameWithSumCond(name, sumcond);

		return (POSITION_HEAD.equals(position))
									? MCStringUtil.join(null, type, n)
									: MCStringUtil.join(null, n, type);
	}

	/**
	 * 集計結果のカラム名を作成します。
	 *
	 * @param name カラム名
	 * @param sumcond 集計条件名
	 * @param type 集計区分
	 * @return 集計結果のカラム名
	 */
	public String createRsltColumnName(String name, String sumcond, FSC_SUM_INFO_TYPE type) {
		String n = createSumCondColumnName(name, sumcond);

		StringBuilder sb = new StringBuilder();
		for (char c : n.toCharArray()) {
			if (c != '.') {
				sb.append(c);
			}
			else {
				sb.append('_');
			}
		}
		n = sb.toString();

		// グループ化の場合は親画面のカラム名を使用する
		// InnerRowを考慮して[.]を[_]に置換する
		// それ以外の場合は、親画面のカラム名と重複しないようにカラム名を作成する
		if (FSC_SUM_INFO_TYPE.isTYPE_GROUP(type)) {
			return n;
		}

		do {
			n = MCStringUtil.join(null, n, type.column_nm());
		}
		while (getTargetColumnConfig(n) != null);

		return n;
	}

	/**
	 * 集計結果の計算式用名称を作成します。
	 *
	 * @param label 集計項目の表示名称
	 * @param sumcond 集計条件名
	 * @param type 集計区分
	 * @return 名称
	 */
	public String createRsltCalcLabel(String label, String sumcond, FSC_SUM_INFO_TYPE type) {
		String l = createSumCondCalcLabel(label, sumcond);
		return MCStringUtil.join("_", l, type.name());
	}

	/**
	 * 集計条件名付き名称を返します。
	 *
	 * @param name 元になる名称
	 * @param sumcond 集計条件名
	 * @return 名称
	 */
	protected String createNameWithSumCond(String name, String sumcond) {
		String n = name != null ? name : "";
		return (sumcond != null) ? n + ":" + sumcond : n;
	}

	/**
	 * 集計条件使用時のカラム名を作成します。
	 *
	 * @param name 元になるカラム名
	 * @param sumcond 集計条件名
	 * @return カラム名
	 */
	protected String createSumCondColumnName(String name, String sumcond) {
		String n = name != null ? name : "";
		return (sumcond != null) ? n + "_" + sumcond : n;
	}

	/**
	 * 集計条件使用時の計算式用名称を返します。
	 *
	 * @param label 集計項目の表示名称
	 * @param sumcond 集計条件名
	 * @return 名称
	 */
	public String createSumCondCalcLabel(String label, String sumcond) {
		String l = label != null ? label : "";
		return (sumcond != null) ? l + "_" + sumcond : l;
	}

	/**
	 * グループ化対象のカラム名の配列を返します。
	 *
	 * @param type 集計区分
	 * @param list 集計結果のカラム情報のリスト
	 * @return グループ化対象のカラム名の配列
	 */
	protected String[] getGroupByColumnName(
			FSC_SUM_INFO_TYPE type, List<WBP_ColumnInfo> list) {
		List<String> l = new ArrayList<String>();
		for (WBP_ColumnInfo i : list) {
			String y = i.getInfoDtlR().sum_info_type();
			if (type == FSC_SUM_INFO_TYPE.getNE(y)) {
				l.add(i.getColumnName());
			}
		}
		return l.toArray(new String[l.size()]);
	}

	/**
	 * 集計結果のカラムを作成します。
	 *
	 * @param info 集計結果のカラムを作成するための情報
	 * @return 集計結果のカラム
	 */
	protected MCColumnConfig createColumnConfig(WBP_ColumnInfo info) {
		MCColumnConfig c = beansFactory.createTableColumn(
				info.getColumnName(), info.getColumnType());
		c.setHeaderName(info.getLabelName());
		c.setMessageName(info.getMessageName());
		c.setMeta(info.getMeta());
		if (!isNull(info.getFormatID())) {
			c.setFormatID(info.getFormatID());
		}
		c.addAllListener(this);
		for (String t : getStatusSet()) {
			c.putMode(this, t, MCMode.READ_ONLY);
		}
		return c;
	}

	/**
	 * 指定されたリストに一時カラムを追加します。
	 *
	 * @param name カラム名
	 * @param type データ型
	 * @param lists リスト
	 */
	protected void addValueColumn(
			String name, MCDataType type, MCList<?>... lists) {
		switch (type) {
			case STRING:
				for (MCList<?> l : lists) {
					if (!MCCollectionUtil.contains(
							name, l.getColumnPathArray())) {
						l.addStringColumn(name);
					}
				}
				break;
			case NUMBER:
				for (MCList<?> l : lists) {
					if (!MCCollectionUtil.contains(
							name, l.getColumnPathArray())) {
						l.addNumberColumn(name);
					}
				}
				break;
			case DATE:
				for (MCList<?> l : lists) {
					if (!MCCollectionUtil.contains(
							name, l.getColumnPathArray())) {
						l.addDateColumn(name);
					}
				}
				break;
			case TIMESTAMP:
				for (MCList<?> l : lists) {
					if (!MCCollectionUtil.contains(
							name, l.getColumnPathArray())) {
						l.addTimestampColumn(name);
					}
				}
				break;
			case BOOLEAN:
				for (MCList<?> l : lists) {
					if (!MCCollectionUtil.contains(
							name, l.getColumnPathArray())) {
						l.addBooleanColumn(name);
					}
				}
				break;
			default:
				break;
		}
	}

	/**
	 * Panel[InfoOpt]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doInfoOpt_radd(MCEventInfo info) {
		insertRow(InfoDtlTable);
	}
	/**
	 * Panel[InfoOpt]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doInfoOpt_rdel(MCEventInfo info) {
		deleteRow(InfoDtlTable);
	}
	/**
	 * Panel[InfoOpt]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doInfoOpt_select_all(MCEventInfo info) {
		setValueEx(columnInfoDtl_disable, true);
	}
	/**
	 * Panel[InfoOpt]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doInfoOpt_deselect_all(MCEventInfo info) {
		setValueEx(columnInfoDtl_disable, false);
	}
	/**
	 * Panel[InfoOpt]のボタン[grp_all_col]の押下時の処理
	 */
	@Override
	public void doInfoOpt_grp_all_col(MCEventInfo info) {
		if (!getInfoDtlL().isStatusNone()) {
			if (confirm(FXBAP0034) != MCMessageBox.YES_OPTION) {
				return;
			}
		}

		MCList<InfoDtlR> il = createInfoDtlL();
		MCList<MCRow> cl = getColumnNameList(FSC_SUM_INFO_TYPE.TYPE_GROUP);
		for (MCRow o : cl) {
			InfoDtlR i = createInfoDtlR();
			i.sum_info_type(FSC_SUM_INFO_TYPE.TYPE_GROUP.value());
			i.column_key(o.getString(InfoDtlR.$column_key));
			i.column_nm(o.getString(InfoDtlR.$column_nm));
			i.setStatus(MCRow.CREATE);
			il.add(i);
		}

		FSC_SUM_INFO_TYPE.putName(
				il, InfoDtlR.$sum_info_type, InfoDtlR.$sum_info_type_nm);

		setInfoDtlL(il);
	}

	/**
	 * Panel[InfoBtn]のボタン[mining]の押下時の処理
	 */
	@Override
	public void doInfoBtn_mining(MCEventInfo info) {
		if (checkForSum()) {
			MCRootPanel p = createPanel("FS", "FSBAP0770", MCRootPanel.SCREEN_MODAL,
					"T1", null, this);
			showChildPanel(p, MCRootPanel.SCREEN_SINGLE);
		}
	}
	/**
	 * Panel[InfoBtn]のボタン[upd_ext]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd_ext(MCEventInfo info) {
		// 権限確認用のダミーボタン
	}
	/**
	 * Panel[InfoBtn]のボタン[upd_sys]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd_sys(MCEventInfo info) {
		// 権限確認用のダミーボタン
	}
	/**
	 * Panel[Btn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd(MCEventInfo info) {
		if (!execUpdComfirm() || !checkForUpd()) {
			return;
		}

		beforeUpd();
		doUpd();
		afterUpd();
		showUpdEndMsg();

		String n = getInfoBtnR().sum_info_nm();

		setInitData();
		fillSpaceForOpen();

		MCList<ListDtlR> l = getListDtlL().subList(ListDtlR.$sum_info_nm, n);
		if (l.size() > 0) {
			ListDtlTable.selectLeftmostColumn(l.get(0).getGUIIndex());
		}

		doSum();
	}

	/**
	 * 登録処理のためのチェックを行います。
	 * 登録処理を継続する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	protected boolean checkForUpd() {
		// 空行のステータスをクリアする
		clearEmptyRowStatus(getListDtlL(), getInfoDtlL());

		MCMessageList ml = new MCMessageList();

		// 設定情報の必須項目をチェックする
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if ((s != null && !s.isEmpty()) || !getInfoDtlL().isStatusNone()) {
			ml = checkReq(getInfoBtnR());
			if (ml.size() > 0) {
				message(ml);
				return false;
			}
		}

		// 有効な設定情報
		MCList<ListDtlR> eil = exceptEmpty(getListDtlL());
		eil = eil.subList(ListDtlR.$setting_unit_type, getSettingR().setting_unit());

		if (eil.size() == 0) {
			dialog(FSBAC0053);
			return false;
		}

		// 初期ＦＬＧをチェックする
		MCList<ListDtlR> iil = eil.subList(ListDtlR.$init_flg, true);
		if (iil.size() > 1) {
			dialog(FSBAC0054);
			return false;
		}

		// 設定情報名の重複をチェックする
		MCList<ListDtlR> dl = eil.subList(
				ListDtlR.$sum_info_nm, getInfoBtnR().sum_info_nm());
		dl.remove(ListDtlTable.getSelectedMCRow());
		if (dl.size() > 0) {
			MCMessage m = new MCMessage(FSBAC0055,
					FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
					getInfoBtnR().sum_info_nm());
			m.setCauseRow(getInfoBtnR(), ListDtlR.$sum_info_nm);
			dialog(m);
			return false;
		}

		// 集計可能かチェックする
		if (!checkForSum()) {
			return false;
		}

		return true;
	}

	/**
	 * 設定情報の重複を評価するカラム名を返します。
	 *
	 * @return カラム名の配列
	 */
	protected String[] getCheckDuplicateInfoDtlColumnNames() {
		// ※注意
		// 評価カラムを変更した場合、FCM_MINING_METHODのユニークキーも変更すること
		return new String[] {
				InfoDtlR.$disable,
				InfoDtlR.$sum_info_type_nm,
				InfoDtlR.$column_nm,
				InfoDtlR.$sumcond,
				InfoDtlR.$dec_place,
				InfoDtlR.$rounding_mode_type_nm
		};
	}

	/**
	 * 空行の属性値をクリアします。
	 *
	 * @param lists リスト
	 */
	protected void clearEmptyRowStatus(MCList<?>... lists) {
		for (MCList<?> l : lists) {
			for (MCRow o : l) {
				if (o.isEmpty()) {
					o.clearAll();
					o.setStatus(MCRow.GUICREATE);
				}
			}
		}
	}

	/**
	 * 登録確認メッセージを表示します。
	 * 登録処理を続行する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	protected boolean execUpdComfirm() {
		return confirm(FSBAC0069,
				FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
				getInfoBtnR().sum_info_nm()) == MCMessageBox.YES_OPTION;
	}

	/**
	 * 登録処理の前処理を実行します。
	 */
	protected void beforeUpd() {

	}

	/**
	 * 登録処理を実行します。
	 */
	protected void doUpd() {
		writeResource();
	}

	/**
	 * 集計情報をリソースに保存します。
	 */
	protected void writeResource() {
		// メモリ上の関連リソースを削除
		removeResource(false);

		//
		String u = getSettingR().setting_unit();
		Integer no = _setting_info_no_map.get(u);
		if (no == null) {
			no = Math.max(getMaxSettingInfoNO(), 0);
		}

		// リソースI/Oオブジェクトに保存データを格納
		MCSumInfoResourceIO sio = new MCSumInfoResourceIO();

		ListDtlR s = ListDtlTable.getSelectedMCRow();
		for (ListDtlR o : getListDtlL()) {
			if (o.isEmpty() || o.isStatusDelete()) {
				continue;
			}

			// 保存用バッファ
			ListDtlR c1; // 集計情報ヘッダ
			MCList<InfoDtlR> c2; // 集計情報詳細
			Map<InfoDtlR, List<MCRowFilter>> c3 = new IdentityHashMap<>(); // 集計条件

			String y = o.setting_unit_type();
			String k = MCConst.createKey(o.setting_unit_type(), o.sum_info_id());

			// 保存用バッファにデータを設定
			if (s != o) {
				// 選択中データではない場合：キャッシュのデータを設定

				// 設定単位チェック
				if (!u.equals(y)) {
					continue;
				}

				if (_sum_info_map.containsKey(k)) {
					MCContainer[] ca = _sum_info_map.get(k);
					// 集計情報ヘッダ
					c1 = ((ListDtlR) ca[0]).clone();
					c1.init_flg(o.init_flg());
					// 集計情報詳細
					c2 = ((MCList<InfoDtlR>) ca[1]).clone();
					// 集計条件
					for (int i = 0; i < c2.size(); i++) {
						InfoDtlR f = ((MCList<InfoDtlR>) ca[1]).get(i);
						List<MCRowFilter> conds = _sum_cond_map.get(f);
						if (conds != null) {
							InfoDtlR c = c2.get(i);
							c3.put(c, conds);
						}
					}
				}
				else {
					continue;
				}
			}
			else {
				// 選択中データの場合：画面の情報を設定

				// 設定単位チェック
				if (isNull(y)) {
					o.setting_unit_type(u);
					FXC_RESOURCE_SETTING_UNIT.putNameNE(o,
							ListDtlR.$setting_unit_type,
							ListDtlR.$setting_unit_type_nm);
					y = o.setting_unit_type();
				}
				if (!u.equals(y)) {
					continue;
				}

				// 集計情報ヘッダ
				c1 = createListDtlR();
				c1.setValues(ListDtlR.colnames(),
						getInfoBtnR(), ListDtlR.colnames());
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());

				// 集計情報詳細
				c2 = createInfoDtlL();
				for (InfoDtlR f : getInfoDtlL()) {
					if (f.isEmpty() || f.isStatusDelete()) {
						continue;
					}

					InfoDtlR d = c2.createRow();
					d.setValues(InfoDtlR.colnames(), f, InfoDtlR.colnames());
					c2.add(d);

					// 集計条件
					List<MCRowFilter> conds = _sel_cond_map.get(f);
					if (conds != null) {
						c3.put(d, conds);
					}
				}
			}

			// 保存用バッファのデータを専用クラスに設定
			MCSumInfoInfo si = MCSumInfoInfo.create();

			String id = c1.sum_info_id();
			if (isNull(id)) {
				c1.sum_info_id(sio.createSettingInfoID(c1.setting_unit_type(), no++));
			}
			si.setInitFlg(c1.init_flg());
			si.setSettingUnitType(c1.setting_unit_type());
			si.setSettingInfoID(c1.sum_info_id());
			si.setSettingInfoName(c1.sum_info_nm());
			si.setRemark(c1.remark());

			List<MCSumInfoData> dl = new ArrayList<MCSumInfoData>();

			for (InfoDtlR f : c2) {
				if (f.isEmpty() || f.isStatusDelete()) {
					continue;
				}

				MCSumInfoData d = new MCSumInfoData();
				d.setColumnName(f.column_key());
				d.setSumInfoType(f.sum_info_type());
				d.setDecPlace(f.dec_place());
				d.setRoundingModeType(f.rounding_mode_type());
				d.setDisable(f.disable());
				d.setSortOrder(f.sort_order());
				d.setSortType(f.sort_type());
				d.setRowLabel(f.row_label());
				d.setChartType(f.chart_type());
				d.setChartColor(f.chart_color());
				d.setDateFormat(f.date_fmt());
				d.setFormula(f.formula_calc());
				d.setSumCondName(f.sumcond());
				d.setRank(f.rank());
				d.setRankType(f.rank_type());
				d.setRankSize(f.rank_size());
				d.setFillDate(f.fill_dt());
				d.setFillDateFrom(f.fill_dt_fm());
				d.setFillDateTo(f.fill_dt_to());
				d.setNullToZero(f.null_zero());

				// 集計条件
				writeSumCondData(d, c3.get(f));

				dl.add(d);
			}

			si.setSumInfoList(dl);

			sio.addInfo(si);
		}

		// 保存
		boolean isNotEmpty = sio.getInfoList().size() > 0 ? true : false;
		if (isNotEmpty) {
			String pfx = getTargetTable().getPersonalizedKeyPrefix(SUM_INFO_PANEL);
			Map<String, Integer> m = new HashMap<String, Integer>();
			m.put(u, no);
			sio.writeNoSave(pfx, m);
		}
		MCPersonalizeResourceIO.saveResource();

	}

	/**
	 * 集計条件をリソースに保存します。
	 *
	 * @param data 集計情報
	 * @param flist 集計条件
	 */
	protected void writeSumCondData(MCSumInfoData data, List<MCRowFilter> flist) {
		List<MCRowFilterData> dlist = new ArrayList<>();
		if (flist != null) {
			flist.forEach(f -> dlist.add(getTargetTable().toRowFilterData(f)));
		}
		data.setSumCondList(dlist);
	}

	protected int getMaxSettingInfoNO() {
		int n = -1;
		for (ListDtlR o : getListDtlL()) {
			n = Math.max(
					MCSumInfoResourceIO.getSettingInfoNO(o.setting_unit_type(), o.sum_info_id()), n);
		}
		return n;
	}

	protected void removeResource(boolean doSave) {
		MCSumInfoResourceIO sio = new MCSumInfoResourceIO();

		String pfx = getTargetTable().getPersonalizedKeyPrefix(SUM_INFO_PANEL);
		String u = getSettingR().setting_unit();

		Map<String, Integer> m = sio.readSettingInfoNOMap(pfx);

		// リソースを削除する
		MCSumInfoResourceIO.removeNoSave(u, pfx);

		// 集計情報ＩＤのシーケンスを再設定する
		if (m.containsKey(u) && isRemainedAfterDel(u)) {
			Map<String, Integer> nm = new HashMap<String, Integer>();
			nm.put(u, m.get(u));
			sio.writeNoSave(pfx, nm);
		}
		if (doSave) {
			MCSumInfoResourceIO.saveResource();
		}
	}

	/**
	 * @see {@link mcframe.clientFSBA.FSBAP0030.FSBAP_PersonalizeBase_FW#isRemainedAfterDel(boolean)}
	 */
	protected boolean isRemainedAfterDel(String settingUnitType) {
		ListDtlR r = getListDtlL().getFirst(ListDtlR.$setting_unit_type, settingUnitType);
		return r != null;
	}

	/**
	 * 登録処理の後処理を実行します。
	 */
	protected void afterUpd() {
		getInfoDtlL().statusChangedList().setStatus(MCRow.NONE);
		getInfoBtnR().setStatus(MCRow.NONE);
	}

	/**
	 * 登録完了メッセージを表示します。
	 */
	protected void showUpdEndMsg() {
		dialog(FXBAP0021);
	}

	@Override
	public MCTable<?> getRowMoveTable() {
		return InfoDtlTable;
	}

	@Override
	public boolean isStatusChange() {
		return true;
	}

	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * 設定対象のテーブルを指定してください。
	 * </li>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0052] 引数の指定に誤りがあった場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ]
	 * 起動タイプに {@link T1} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			Object o = args[0];
			if (o == null || !(o instanceof MCTable<?>)) {
				throw new MCAppException(FSBAC0052);
			}

			setTargetTable((MCTable<?>)o);
			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	protected void afterOpenByInitParam(String openTyp, MCRow bind,
			Object... args) {
		super.afterOpenByInitParam(openTyp, bind, args);

		ListDtlR u = null;
		ListDtlR e = null;
		ListDtlR s = null;
		for (ListDtlR o : getListDtlL()) {
			if (o.init_flg()) {
				String y = o.setting_unit_type();
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
					u = o;
					break;
				}
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
					e = o;
				}
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
					s = o;
				}
			}
		}

		ListDtlR o = u != null ? u : (e != null ? e : s);
		if (o != null) {
			ListDtlTable.selectLeftmostColumn(o.getGUIIndex());

			if (checkForSum()) {
				doSum();
			}
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		setInitData();
	}

	/**
	 * この画面の情報を初期化します。
	 */
	protected void setInitData() {
		// 現状をクリアする
		// データ
		getListDtlL().clear();
		getInfoDtlL().clear();
		getInfoOptR().clearAll();
		getInfoBtnR().clearAll();
		// 集計結果テーブル
		getRsltL().clear();
		for (MCColumnConfig c : RsltTable.getColumnConfigs()) {
			RsltTable.removeColumnConfig(c);
		}
		// 集計条件キャッシュ
		_sum_cond_map.clear();


		// リソースの読み込み
		String pfx = getTargetTable().getPersonalizedKeyPrefix(SUM_INFO_PANEL);
		MCSumInfoResourceIO sio = new MCSumInfoResourceIO();
		sio.read(pfx);
		//
		_setting_info_no_map = sio.readSettingInfoNOMap(pfx);

		// 集計情報を設定単位に分割
		List<MCSumInfoInfo> l = new ArrayList<MCSumInfoInfo>();	// 現在の設定単位で利用可能
		List<MCSumInfoInfo> sl = new ArrayList<MCSumInfoInfo>();// システム共通
		List<MCSumInfoInfo> el = new ArrayList<MCSumInfoInfo>();// 会社共通
		List<MCSumInfoInfo> ul = new ArrayList<MCSumInfoInfo>();// ユーザ

		for (MCSumInfoInfo i : sio.getInfoList()) {
			String y = i.getSettingUnitType();
			if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
				sl.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
				el.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
				ul.add(i);
			}
		}

		String u = getSettingR().setting_unit();
		l.addAll(0, sl);
		if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
			l.addAll(0, el);
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
				l.addAll(0, ul);
			}
		}


		MCList<ListDtlR> il = MCList.create(createListDtlR());

		for (MCSumInfoInfo i : l) {
			// 0:集計情報ヘッダ 1:集計情報詳細
			MCContainer[] ca = new MCContainer[2];

			// 集計情報ヘッダ
			ListDtlR c0 = createListDtlR();

			c0.setting_unit_type(i.getSettingUnitType());
			FXC_RESOURCE_SETTING_UNIT.putName(c0,
					ListDtlR.$setting_unit_type,
					ListDtlR.$setting_unit_type_nm);

			c0.sum_info_id(i.getSettingInfoID());
			c0.sum_info_nm(i.getSettingInfoName());
			c0.remark(i.getRemark());
			c0.init_flg(i.getInitFlg());
			ca[0] = c0;
			il.add(c0.clone());

			// 集計情報詳細
			MCList<InfoDtlR> c1 = createInfoDtlL();

			List<MCSumInfoData> dl = i.getSumInfoList();
			for (MCSumInfoData d : dl) {
				InfoDtlR o = c1.createRow();

				o.disable(d.isDisable());

				String siy = d.getSumInfoType();
				if (!FSC_SUM_INFO_TYPE.contains(siy)) {
					continue;
				}
				o.sum_info_type(siy);
				FSC_SUM_INFO_TYPE.putName(
						o, InfoDtlR.$sum_info_type, InfoDtlR.$sum_info_type_nm);

				if (!isNull(d.getFormula())) {
					// 計算項目
					o.column_key(d.getColumnName());
					o.column_nm(d.getColumnName().substring(CALC_PREFIX.length()));
				}
				else if (FSC_SUM_INFO_TYPE.isTYPE_COUNT(siy)) {
					// 件数
					o.column_key(COUNT_GROUP);
					o.column_nm(getLabelName(FSC_SUM_INFO_TYPE.TYPE_COUNT));
				}
				else {
					// 上記以外は、親画面に対象となるカラムが存在する
					String n = d.getColumnName();
					MCColumnConfig c = getTargetColumnConfig(n);
					if (c == null) {
						continue;
					}
					o.column_key(n);
					o.column_nm(c.getMessageByLocale());
				}

				o.sumcond(d.getSumCondName());

				// 順位
				o.rank(d.isRank());
				o.rank_type(d.getRankType());
				o.rank_size(d.getRankSize());

				// 日時補完
				o.fill_dt(d.isFillDate());
				o.fill_dt_fm(d.getFillDateFrom());
				o.fill_dt_to(d.getFillDateTo());

				// オプション設定
				setInitOptData(o);

				// 日付書式
				o.date_fmt(d.getDateFormat());

				// 計算式
				// 集計後計算の都合上、表示時に計算式の変数を変換する
				o.formula_calc(d.getFormula());

				// 小数点有効桁数、端数処理区分
				// 平均と計算式ありの場合に評価する
				if (FSC_SUM_INFO_TYPE.isTYPE_AVG(siy) || !isNull(o.formula_calc())) {
					o.dec_place(d.getDecPlace());

					String y = d.getRoundingModeType();
					if (!FSC_ROUNDING_MODE_TYPE.contains(y)) {
						continue;
					}
					o.rounding_mode_type(y);
					FSC_ROUNDING_MODE_TYPE.putName(o,
							InfoDtlR.$rounding_mode_type,
							InfoDtlR.$rounding_mode_type_nm);
				}

				// null/0変換
				// 集計項目のみ設定する
				if (!FSC_SUM_INFO_TYPE.isTYPE_GROUP(siy)
						&& !FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(siy)) {
					o.null_zero(d.isNullToZero());
				}

				// ソート順、ソートタイプ、ソートタイプ名
				o.sort_order(d.getSortOrder());
				o.sort_type(d.getSortType());
				FSC_SORT_TYPE.putNameNE(o,
						InfoDtlR.$sort_type, InfoDtlR.$sort_type_nm);

				// グラフ、グラフ色
				if (d.getChartType() != null) {
					o.chart_type(d.getChartType());
					FSC_GADGET_CHART_TYPE.putName(
							o, InfoDtlR.$chart_type, InfoDtlR.$chart_type_nm);

					String color = d.getChartColor();
					o.chart_color(color);
					MCNumber[] rgb = MCFXGraph.splitColorValue(color);
					o.red(rgb[0]);
					o.green(rgb[1]);
					o.blue(rgb[2]);
				}

				// 行ラベル
				o.row_label(d.isRowLabel());

				c1.add(o);

				// 集計条件
				setInitSumCondData(o, d.getSumCondList());
			}
			ca[1] = c1;

			_sum_info_map.put(MCConst.createKey(
					i.getSettingUnitType(), i.getSettingInfoID()), ca);
		}

		// 画面に反映
		setListDtlL(il);
		ListDtlTable.adjustWidth();
	}

	/**
	 * 集計条件を初期化します。
	 *
	 * @param row 集計情報
	 * @param dlist 集計条件
	 */
	protected void setInitSumCondData(InfoDtlR row, List<MCRowFilterData> dlist) {
		if (dlist == null || dlist.size() <= 0) {
			return;
		}

		List<MCRowFilter> flist = new ArrayList<>();
		dlist.forEach(d -> flist.add(getTargetTable().toRowFilter(d)));
		_sum_cond_map.put(row, flist);
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
		ListDtlTable.setSortable(false);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();

		ListDtlTable.fillSpace();
	}

	@Override
	public void setOpenFocus() {
		super.setOpenFocus();

		ListDtlTable.selectLeftmostColumn(0);
	}

	@Override
	public void screenClearBody() {
		String u = getSettingR().setting_unit();
		super.screenClearBody();
		getSettingR().setting_unit(u);
	}

	@Override
	public void setStatus(String status) {
		if (EDIT.equals(status)) {
			// 選択されている集計情報ヘッダと設定単位が一致しない場合 DISABLE
			ListDtlR o = ListDtlTable.getSelectedMCRow();
			if (o != null) {
				String u = getSettingR().setting_unit();
				String y = o.setting_unit_type();
				if (!isNull(y) && !isSame(u, y)) {
					status = DISABLE;
				}
			}
		}

		super.setStatus(status);

		// 権限による設定単位部品制御
		if (!InfoBtn_upd_ext.authorize() || !isSearchedProgram(
				FXC_RESOURCE_SETTING_UNIT.TYPE_EXT.value(),
				MCGroupResource.PGM_ID_SYSTEM)) {
			Setting_setting_PPanel.Setting_setting_unit_EXT.setMode(MCMode.READ_ONLY);
		}
		if (!InfoBtn_upd_sys.authorize() || !isSearchedProgram(
				FXC_RESOURCE_SETTING_UNIT.TYPE_SYS.value(),
				MCGroupResource.PGM_ID_SYSTEM)) {
			Setting_setting_PPanel.Setting_setting_unit_SYS.setMode(MCMode.READ_ONLY);
		}

		// 見える化ボタン制御
		MCRootPanel p = getParentPanel();
		if (!(p instanceof IfMCMiningBase)) {
			InfoBtn_mining.setMode(MCMode.DISABLE);
		}
		else {
			IfMCMiningBase i = (IfMCMiningBase) p;
			if (i.getMiningCaller() == null) {
				InfoBtn_mining.setMode(MCMode.DISABLE);
			}
		}
	}

	protected boolean isSearchedProgram(String type, String pgmid) {
		return MCSumInfoResourceIO.isSearchedProgram(type, pgmid);
	}

	@Override
	public void setEDITStatus() {
		super.setEDITStatus();

		// グループ化可能カラム追加ボタン
		// 新規作成時のみ有効
		ListDtlR o = ListDtlTable.getSelectedMCRow();
		if (o == null || _sum_info_map.containsKey(
					MCConst.createKey(o.setting_unit_type(), o.sum_info_id()))) {
			InfoOpt_grp_all_col.setMode(MCMode.DISABLE);
		}
		else {
			setDefaultMode(InfoOpt_grp_all_col);
		}

		// 順位と日時補完の制御
		// 対象カラムが未設定の場合は入力不可
		boolean rank = false;
		boolean fill_dt = false;
		for (InfoDtlR r : getInfoDtlL()) {
			if (r.rank()) {
				rank = true;
			}
			if (r.fill_dt()) {
				fill_dt = true;
			}
		}
		if (!rank) {
			InfoOpt_rank_type_nm.setMode(MCMode.DISABLE);
			InfoOpt_rank_size.setMode(MCMode.DISABLE);
		}
		if (!fill_dt) {
			InfoOpt_fill_dt_fm.setMode(MCMode.DISABLE);
			InfoOpt_fill_dt_to.setMode(MCMode.DISABLE);
		}
	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!super.doListDtl_VC(info)) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone()
				|| !getInfoOptR().isStatusNone()
				|| !getInfoBtnR().isStatusNone()) {
			if (confirm(FSBAC0056) != MCMessageBox.YES_OPTION) {
				return false;
			}

			setInitListData(ListDtlTable.getSelectedMCRow());
		}
		return true;
	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);

		ListDtlR o = ListDtlTable.getSelectedMCRow();
		if (o == null) {
			// 行が選択されなかった場合
			getInfoBtnR().clearAll();
			getInfoOptR().clearAll();
			getInfoDtlL().clear();
			setStatus(INIT);
		}
		else {
			setInitListData(o);
			setInitInfoData(o);
			setStatus(EDIT);
		}
	}

	/**
	 * 設定情報を初期化します。
	 *
	 * @param data 設定情報
	 */
	protected void setInitListData(ListDtlR data) {
		String k = MCConst.createKey(data.setting_unit_type(), data.sum_info_id());
		if (_sum_info_map.containsKey(k)) {
			MCContainer[] a = _sum_info_map.get(k);
			data.setValues(ListDtlR.colnames(),
					(ListDtlR)a[0], ListDtlR.colnames());
			data.setStatus(MCRow.NONE);
		}
		else {
			data.clearAll();
			data.setStatus(MCRow.GUICREATE);
		}
	}

	/**
	 * 設定情報の詳細情報を初期化します。
	 *
	 * @param data 設定情報
	 */
	protected void setInitInfoData(ListDtlR data) {
		_sel_cond_map.clear();

		String k = MCConst.createKey(data.setting_unit_type(), data.sum_info_id());
		if (_sum_info_map.containsKey(k)) {
			// 既存行が選択された場合
			MCContainer[] a = _sum_info_map.get(k);
			setInfoBtnR((ListDtlR)a[0]);

			MCList<InfoDtlR> c1 = (MCList<InfoDtlR>)a[1];
			MCList<InfoDtlR> l = createInfoDtlL();
			getInfoOptR().clearAll();
			for (InfoDtlR f : c1) {
				InfoDtlR d = f.clone();
				l.add(d);
				// オプション
				setInitOptData(d);
				// 集計条件
				List<MCRowFilter> conds = _sum_cond_map.get(f);
				if (conds != null) {
					_sel_cond_map.put(d, conds);
				}
			}

			setInfoDtlL(l);
			getInfoDtlL().setStatus(MCRow.NONE);

			// 計算式 変数変換
			getInfoDtlL().forEach(infoR -> {
				String formula = toColumnNameFormula(infoR.formula_calc(), infoR.sum_info_type());
				infoR.formula(formula);
			});
		}
		else {
			// 新規行が選択された場合
			getInfoDtlL().clear();
			getInfoOptR().clearAll();
			getInfoBtnR().clearAll();
		}

		InfoDtlTable.fillSpace();
		InfoDtlTable.adjustWidth();
		// adjustWidthでテーブルの横スクロールバーが消える。
		// 横スクロールバーが消えた後に１行分の隙間ができる可能性があるため、
		// 再度fillSpaceを実行する。
		InfoDtlTable.fillSpace();
	}

	/**
	 * 詳細情報のオプションを初期化します。
	 *
	 * @param data 設定情報
	 */
	protected void setInitOptData(InfoDtlR data) {
		InfoOptR opt = getInfoOptR();
		// 順位
		if (data.rank()) {
			opt.rank_type(data.rank_type());
			FSC_SORT_TYPE.putNameNE(opt,
					InfoOptR.$rank_type, InfoOptR.$rank_type_nm);
			opt.rank_size(data.rank_size());
		}
		// 日時補完
		if (data.fill_dt()) {
			opt.fill_dt_fm(data.fill_dt_fm());
			opt.fill_dt_to(data.fill_dt_to());
		}
	}

	@Override
	public void doListDtl_init_flg_NC(MCEventInfo info) {
		super.doListDtl_init_flg_NC(info);

		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s.init_flg()) {
			String y = getSettingR().setting_unit();

			for (ListDtlR o : getListDtlL()) {
				if (o != s && !o.isEmpty()
						&& isSame(y, o.setting_unit_type())) {
					setValueEx(columnListDtl_init_flg, o.getGUIIndex(), false);
				}
			}
		}

	}

	@Override
	protected void listInit() {
		super.listInit();

		columnInfoDtl_column_nm.setListVisibleColumn(InfoDtlR.$column_nm);
		columnInfoDtl_date_fmt.setListVisibleColumn(InfoDtlR.$date_fmt);

		getInfoDtl_chart_type_nm_ListPutter().setColumns(
					FSC_GADGET_CHART_TYPE.$NAME,
					FSC_GADGET_CHART_TYPE.$VALUE
				);


		getInfoOpt_rank_type_nm_ListPutter().setColumns(
					FSC_SORT_TYPE.$NAME,
					FSC_SORT_TYPE.$VALUE
				);
	}

	@Override
	public MCList getInfoDtl_date_fmt(MCRow row, MCEventInfo info){
		String[] fmts = MCConst.format.findPattern("date.*");

		MCList<MCRow> list = MCList.create(MCRow.class);
		for (String fmt : fmts) {
			MCRow w = MCRow.create();
			w.setStringNE(InfoDtlR.$date_fmt, fmt.substring(5));// "date."を除く
			list.add(w);
		}
		return list;
	}

	@Override
	public MCList getInfoDtl_column_nm(MCRow row, MCEventInfo info) {
		String s = getInfoDtlL().get(info.getEventIndex()).sum_info_type();
		if (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(s)) {
			// 集計後計算の場合、リストは空にする
			return MCList.create(MCRow.class);
		}
		return getColumnNameList(s);
	}

	/**
	 * 集計情報区分に応じた、カラムのリストを返します。
	 *
	 * @param type 集計情報区分
	 * @return カラムのリスト
	 */
	public MCList<MCRow> getColumnNameList(String type) {
		FSC_SUM_INFO_TYPE y = FSC_SUM_INFO_TYPE.getNE(type);
		return getColumnNameList(y);
	}

	/**
	 * 集計情報区分に応じた、カラムのリストを返します。
	 *
	 * <p>
	 * 集計情報区分による違いは次の通りです。
	 * <dl>
	 * <dt>定数定義で数値項目フラグがtrueの区分</dt>
	 * <dd>数値項目のみ</dd>
	 * <dt>集計後計算</dt>
	 * <dd>集計情報のうち、集計区分が「グループ化」と「集計後検索」以外の項目</dd>
	 * <dt>その他</dt>
	 * <dd>パスワード項目、バイナリ項目、連携で値が設定される項目以外の項目</dd>
	 * </dl>
	 *
	 * @param type 集計情報区分
	 * @return カラムのリスト
	 */
	public MCList<MCRow> getColumnNameList(FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return null;
		}

		// リスト（一時カラムを追加しておく）
		MCList<MCRow> l = MCList.create(MCRow.class);
		l.addStringColumn(InfoDtlR.$column_key);
		l.addStringColumn(InfoDtlR.$column_nm);
		l.addBooleanColumn(InfoDtlR.$disable);

		if (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type)) {
			// 集計後計算
			getInfoDtlL().forEach(infoR -> {
				if (!isVariableCandidateForAfterCalc(infoR)) {
					// 集計後計算の変数に利用不可
					return;
				}

				WBP_ColumnInfo ci = createColumnInfo(infoR);
				if (ci == null) {
					// 集計後計算行を追加した後に集計行を追加すると、ここを通る
					return;
				}

				MCRow o = l.createRow();
				o.setString(InfoDtlR.$column_key, ci.getColumnName());
				o.setString(InfoDtlR.$column_nm, ci.getCalcName());
				o.setBoolean(InfoDtlR.$disable, ci.getInfoDtlR().disable());
				l.add(o);
			});
			return l;
		}

		MCColumnConfig[] a = getTargetTable().getPersonalizedTargetColumnConfigs(
				SUM_INFO_PANEL);
		for (MCColumnConfig c : a) {
			String n = c.getMessageByLocale();
			if (isNull(n)) {
				continue;
			}

			if (!MCDataType.NUMBER.equals(c.getDataType())) {
				if (type.is_num()) {
					continue;
				}
			}

			MCRow o = l.createRow();
			o.setString(InfoDtlR.$column_key, c.getBaseRowColumnName());
			o.setString(InfoDtlR.$column_nm, n);
			o.setBoolean(InfoDtlR.$disable, false);
			l.add(o);
		}

		return l;
	}

	/**
	 * 計算式のカラム名と表示名をマップするためのリストを設定します。
	 *
	 * <p>
	 * 集計情報区分に応じた項目が対象です。
	 * <p>
	 * 戻り値の配列は、インデックス0がカラム名、インデックス1が表示名の
	 * リストになっています。
	 * 並び順でマッピングされています。
	 *
	 * @param type 集計情報区分
	 * @return マップしたリストの配列
	 */
	protected List<String>[] getVariableMapList(FSC_SUM_INFO_TYPE type) {
		List<String>[] lists = new List[2];
		MCList<MCRow> list = getColumnNameList(type);
		list = list.subList(InfoDtlR.$disable, false);
		lists[0] = list.getString(InfoDtlR.$column_key);
		lists[1] = list.getString(InfoDtlR.$column_nm);
		return lists;
	}
	/**
	 * 計算式のカラム名のリストを設定します。
	 *
	 * <p>
	 * 集計情報区分に応じた項目が対象です。
	 * <p>
	 *
	 * @param type 集計情報区分
	 * @return リスト
	 */
	protected List<String> getVariableKeyList(FSC_SUM_INFO_TYPE type) {
		List<String> lists = new ArrayList<>();
		MCList<MCRow> list = getColumnNameList(type);
		list = list.subList(InfoDtlR.$disable, false);
		lists = list.getString(InfoDtlR.$column_key);
		return lists;
	}
	/**
	 * 日時カラムの場合trueを返します。
	 *
	 * @param key コンテナのカラム名
	 * @return 日時カラムの場合 true それ以外はfalse
	 */
	protected boolean isDateColumn(String key) {
		MCColumnConfig[] a = getTargetTable().getPersonalizedTargetColumnConfigs(
				SUM_INFO_PANEL);
		for (MCColumnConfig c : a) {
			if (isDateColumn(c)) {
				String n = c.getBaseRowColumnName();
				if (!isNull(n) && n.equals(key)) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * 日時カラムの場合trueを返します。
	 * @param c カラム
	 * @return 日時カラムの場合 true それ以外はfalse
	 */
	private boolean isDateColumn(MCColumnConfig c) {
		if (c != null) {
			MCDataType d = c.getDataType();
			if (d != null && d.isDateType()) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public boolean doInfoDtl_sum_info_type_nm_VC(MCEventInfo info) {
		if (!confirmResetSumcond(InfoDtlTable.getSelectedMCRow())) {
			return false;
		}

		return super.doInfoDtl_sum_info_type_nm_VC(info);
	}

	@Override
	public void doInfoDtl_sum_info_type_LC(MCEventInfo info) {
		try {
			_sumcond_reset_force = true;// 集計条件強制クリアON

			super.doInfoDtl_sum_info_type_LC(info);

			int i = info.getEventIndex();
			setValueEx(columnInfoDtl_column_nm, i, null);
			setValueEx(columnInfoDtl_date_fmt, i, null);
			setValueEx(columnInfoDtl_formula, i, null);
			setValueEx(columnInfoDtl_sumcond, i, null);
			setValueEx(columnInfoDtl_rank, i, null);
			setValueEx(columnInfoDtl_fill_dt, i, null);
			setValueEx(columnInfoDtl_dec_place, i, null);
			setValueEx(columnInfoDtl_rounding_mode_type_nm, i, null);
			setValueEx(columnInfoDtl_null_zero, i, null);
			setValueEx(columnInfoDtl_sort_order, i, null);
			setValueEx(columnInfoDtl_sort_type, i, null);
			setValueEx(columnInfoDtl_chart_type_nm, i, null);
			setValueEx(columnInfoDtl_row_label, i, null);

			setValueEx(columnInfoDtl_chart_color, i, null);
			setValueEx(InfoDtl_chart_color_p_PPanel.columnColor_red, i, null);
			setValueEx(InfoDtl_chart_color_p_PPanel.columnColor_green, i, null);
			setValueEx(InfoDtl_chart_color_p_PPanel.columnColor_blue, i, null);

			// 件数の場合、既定のカラム名、ラベルを設定
			String type = (String) info.getNewValue();
			FSC_SUM_INFO_TYPE y = FSC_SUM_INFO_TYPE.getNE(type);
			if (y != null && FSC_SUM_INFO_TYPE.isTYPE_COUNT(y)) {
				// 連携が動くことを考慮し、column_keyの設定は後にする
				setValueEx(columnInfoDtl_column_nm, i, getLabelName(y));
				setValueEx(columnInfoDtl_column_key, i, COUNT_GROUP);
			}
		}
		finally {
			_sumcond_reset_force = false;// 集計条件強制クリアOFF
		}
	}

	@Override
	public void doInfoBtn_remark_LC(MCEventInfo info) {
		super.doInfoBtn_remark_LC(info);

		int i = ListDtlTable.getMCSelectedRow();
		if (i != -1) {
			// 7013-1856 連携を誘発させるため画面イベント有りで値変更する
			setValueEx(columnListDtl_remark, i, getInfoBtnR().remark());
		}
	}

	@Override
	public void doInfoBtn_sum_info_nm_LC(MCEventInfo info) {
		super.doInfoBtn_sum_info_nm_LC(info);

		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnListDtl_sum_info_nm,
					s.getGUIIndex(), getInfoBtnR().sum_info_nm());

			if (isNull(s.setting_unit_type())) {
				s.setting_unit_type(getSettingR().setting_unit());
				FXC_RESOURCE_SETTING_UNIT.putNameNE(s,
						ListDtlR.$setting_unit_type,
						ListDtlR.$setting_unit_type_nm);
			}
		}
	}

	@Override
	protected void listenerInit() {
		super.listenerInit();

		Setting_setting_PPanel.Setting_setting_unit_Group.addVCListener(this);
		Setting_setting_PPanel.Setting_setting_unit_Group.addNCListener(this);
	}

	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}

		if (vc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			return doSetting_setting_unit_VC(info);
		}
		return true;
	}

	protected boolean doSetting_setting_unit_VC(MCEventInfo info) {
		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}

		return true;
	}

	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);

		if (nc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			doSetting_setting_unit_NC(info);
		}
	}

	protected void doSetting_setting_unit_NC(MCEventInfo info) {
		valueInit();
		fillSpaceForOpen();
		setOpenFocus();
	}

	@Override
	public boolean doInfoDtl_column_nm_VC(MCEventInfo info) {
		String column_nm = (String) info.getNewValue();
		InfoDtlR infoR = InfoDtlTable.getSelectedMCRow().clone();
		infoR.column_nm(column_nm);

		if (editableFormula(infoR)) {
			// 計算項目
			for (InfoDtlR dtlR : getInfoDtlL()) {
				if (isSame(dtlR.column_nm(), column_nm)) {
					// 登録済み一時カラム NG
					return false;
				}
			}
		}
		else {
			// 画面項目（リストの項目）
			// 集計情報区分が件数 ※件数の場合カラム選択不可
		}

		return super.doInfoDtl_column_nm_VC(info);
	}

	@Override
	public void doInfoDtl_column_nm_LC(MCEventInfo info) {
		// 7013-1856 連携を誘発させるため画面イベント有りで値変更する

		int i = info.getEventIndex();
		InfoDtlR infoR = getInfoDtlL().get(i);

		// カラム名任意：計算項目
		if (editableFormula(infoR)) {
			// 計算項目の場合、表示名称をキーに設定
			infoR.column_key(CALC_PREFIX + infoR.column_nm());
		}
		else {
			// 計算項目以外は空
			// 対象はColumnConfigでeditableFormula()判定しているカラムと同じ
			setValueEx(columnInfoDtl_formula, i, null);
			setValueEx(columnInfoDtl_dec_place, i, null);
			setValueEx(columnInfoDtl_rounding_mode_type_nm, i, null);
		}

		// 日付関連
		if (isDateColumn(infoR.column_key())) {
			// 日付書式
			// 日付項目の場合、画面の表示書式を設定
			MCColumnConfig tc = getTargetColumnConfig(infoR.column_key());
			String fmt = tc.getDateFormat().getID();
			setValueEx(columnInfoDtl_date_fmt, i, fmt);
		}
		else {
			// 日付項目以外は空
			// 日付書式
			setValueEx(columnInfoDtl_date_fmt, i, null);
			// 日時補完
			setValueEx(columnInfoDtl_fill_dt, i, false);
			setValueEx(InfoOpt_fill_dt_fm, null);
			setValueEx(InfoOpt_fill_dt_to, null);
		}
	}

	@Override
	public void doInfoDtl_date_fmt_NC(MCEventInfo info) {
		InfoDtlR infoR = InfoDtlTable.getSelectedMCRow();
		if (isNull(infoR.date_fmt())) {
			// 空にした場合、画面の表示書式を設定
			MCColumnConfig tc = getTargetColumnConfig(infoR.column_key());
			if (isDateColumn(tc)) {
				String fmt = tc.getDateFormat().getID();
				infoR.date_fmt(fmt);
			}
		}
	}

	@Override
	public void doInfoDtl_rank_NC(MCEventInfo info) {
		int sel = info.getNewIndex();
		MCList<InfoDtlR> list = getInfoDtlL();
		for (int i = 0; i < list.size(); i++) {
			if (i != sel) {
				InfoDtlR row = list.get(i);
				row.rank(false);
			}
		}

		if (!(Boolean) info.getNewValue()) {
			getInfoOptR().rank_type(null);
			getInfoOptR().rank_type_nm(null);
			getInfoOptR().rank_size(null);
			InfoOpt_rank_type_nm.setMode(MCMode.DISABLE);
			InfoOpt_rank_size.setMode(MCMode.DISABLE);
		}
		else {
			InfoOpt_rank_type_nm.setMode(MCMode.ENABLE);
			InfoOpt_rank_size.setMode(MCMode.ENABLE);
		}
	}

	@Override
	public void doInfoDtl_fill_dt_NC(MCEventInfo info) {
		int sel = info.getNewIndex();
		MCList<InfoDtlR> list = getInfoDtlL();
		for (int i = 0; i < list.size(); i++) {
			if (i != sel) {
				InfoDtlR row = list.get(i);
				row.fill_dt(false);
			}
		}

		if (!(Boolean) info.getNewValue()) {
			getInfoOptR().fill_dt_fm(null);
			getInfoOptR().fill_dt_to(null);
			InfoOpt_fill_dt_fm.setMode(MCMode.DISABLE);
			InfoOpt_fill_dt_to.setMode(MCMode.DISABLE);
		}
		else {
			InfoOpt_fill_dt_fm.setMode(MCMode.ENABLE);
			InfoOpt_fill_dt_to.setMode(MCMode.ENABLE);
		}
	}

	@Override
	public boolean doInfoDtl_formula_VC(MCEventInfo info) {
		String formula = (String) info.getNewValue();

		InfoDtlR infoR = getInfoDtlL().get(info.getEventIndex());

		try {
			// 式の検査
			toColumnKeyFormula(formula, infoR.sum_info_type());
			return true;
		}
		catch (MCException e) {
			// 式不正
			dialog(e);
			return false;
		}
	}
	
	@Override
	public void doInfoDtl_formula_NC(MCEventInfo info) {
		String formula = (String) info.getNewValue();

		InfoDtlR infoR = getInfoDtlL().get(info.getEventIndex());
		// 式の保存
		infoR.formula_calc(toColumnKeyFormula(formula, infoR.sum_info_type()));
	}

	@Override
	public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
		super.doDCEvent(compo, info);

		if (compo == columnInfoDtl_sumcond) {
			doInfoDtl_sumcond_DC(info);
		}
	}

	/**
	 * [InfoDtl]パネルの[sumcond]のDoubleClickイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	protected void doInfoDtl_sumcond_DC(MCEventInfo info) {
		doDCEventForIS(columnInfoDtl_sumcond, info);
	}

	@Override
	public void openISPanel(MCLinkBeans compo, int eventIndex) {
		if (compo == columnInfoDtl_sumcond) {
			openModalPanel("FS", "FSBAP0810", T1, null, this);
			return;
		}
		super.openISPanel(compo, eventIndex);
	}

	@Override
	public boolean doInfoDtl_sumcond_VC(MCEventInfo info) {
		if (!super.doInfoDtl_sumcond_VC(info)) {
			return false;
		}

		InfoDtlR o = InfoDtlTable.getSelectedMCRow();
		if (isNull(info.getNewValue())) {
			// 集計条件名空拍時＆集計条件強制クリアOFF：集計条件設定削除を確認
			if (!_sumcond_reset_force && !confirmResetSumcond(o)) {
				return false;
			}
		}
		else {
			List<MCRowFilter> list = _sel_cond_map.get(o);
			if (list == null || list.size() <= 0) {
				// 集計条件名入力時：集計条件設定必須
				dialog(FSBAC0076);
				return false;
			}
		}
		return true;
	}

	/**
	 * 集計条件強制クリアフラグです。
	 * 集計条件をクリアする前に確認を行う場合は false を設定します。
	 */
	private boolean _sumcond_reset_force = false;

	/**
	 * 集計条件の削除を確認します。
	 *
	 * @param o 集計情報
	 * @return 削除を許可した場合または集計条件が0件の場合 true
	 */
	protected boolean confirmResetSumcond(InfoDtlR o) {
		List<MCRowFilter> list = _sel_cond_map.get(o);
		if (list != null && list.size() > 0) {
			// 集計条件名が空の時は集計条件設定を削除
			if (confirm(FSBAC0075) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}
		return true;
	}

	@Override
	public void doInfoDtl_sumcond_NC(MCEventInfo info) {
		super.doInfoDtl_sumcond_NC(info);

		if (isNull(info.getNewValue())) {
			// 集計条件名を空にすると、集計条件設定を削除
			InfoDtlR infoR = InfoDtlTable.getSelectedMCRow();
			_sel_cond_map.remove(infoR);
		}
	}

	@Override
	public String getSumCondName() {
		// フィールド未確定で呼ばれる場合があるので、セルコンフィグから値を取得
		int index = InfoDtlTable.getMCSelectedRow();
		return (index < 0) ? null : (String) columnInfoDtl_sumcond.getValue(index);
	}

	@Override
	public List<MCRowFilter> getSumCondList() {
		InfoDtlR infoR = InfoDtlTable.getSelectedMCRow();
		return getSumCondList(infoR);
	}

	/**
	 * 集計情報の集計条件を格納するListをを返します。
	 *
	 * <p>
	 * 引数のインスタンスがキーになっています。
	 * 同じ値を格納した別インスタンスでは取得できません。
	 * <p>
	 * 集計条件が設定されていない場合は null を返します。
	 *
	 * @param infoR 集計情報
	 * @return 集計条件を格納するList、または null
	 */
	public List<MCRowFilter> getSumCondList(InfoDtlR infoR) {
		return _sel_cond_map.get(infoR);
	}

	@Override
	public void setSumCond(String name, List<MCRowFilter> list) {
		InfoDtlR infoR = InfoDtlTable.getSelectedMCRow();
		if (name == null || list == null || list.size() <= 0) {
			// 値がそろわない場合は設定を削除
			infoR.sumcond(null);
			_sel_cond_map.remove(infoR);
		}
		else {
			infoR.sumcond(name);
			_sel_cond_map.put(infoR, list);
		}
		if (infoR.isStatusNone()) {
			infoR.setStatus(Status.MODIFY);
		}

		InfoDtlTable.adjustWidth();
	}

	/**
	 * 集計対象のテーブルを設定します。
	 *
	 * @param table 集計対象のテーブル
	 */
	protected void setTargetTable(MCTable<?> table) {
		_table = table;
	}

	/**
	 * 集計対象のテーブルを返します。
	 *
	 * @return 集計対象のテーブル
	 */
	@Override
	public MCTable<?> getTargetTable() {
		return _table;
	}

	/**
	 * 集計対象のテーブルカラムを返します。<p>
	 * {@link #getTargetTable()} のテーブルに配置されているテーブルカラムから、
	 * Row コンテナのカラム名が指定されたカラム名と同じテーブルカラムを探索します。<p>
	 * テーブルカラムが見つからなかった場合は null を返します。
	 *
	 * @param name カラム名
	 * @return テーブルカラム、または null
	 */
	protected MCColumnConfig getTargetColumnConfig(String name) {
		if (isNull(name)) {
			return null;
		}
		MCTable<?> t = getTargetTable();
		MCColumnConfig[] a = t.getPersonalizedTargetColumnConfigs(
				SUM_INFO_PANEL);

		for (MCColumnConfig c : a) {
			if (name.equals(c.getBaseRowColumnName())) {
				return c;
			}
		}

		return null;
	}

	/**
	 * 集計結果のテーブルカラムを返します。<p>
	 * 集計結果テーブルに配置されているテーブルカラムから、
	 * Row コンテナのカラム名が指定されたカラム名と同じテーブルカラムを探索します。<p>
	 * テーブルカラムが見つからなかった場合は null を返します。
	 *
	 * @param name カラム名
	 * @return テーブルカラム、または null
	 */
	protected MCColumnConfig getRsltColumnConfig(String name) {
		for (MCColumnConfig c : RsltTable.getColumnConfigs()) {
			if (name.equals(c.getBaseRowColumnName())) {
				return c;
			}
		}
		return null;
	}

	/**
	 * 集計情報の順番を表すリソースキーを返します。
	 *
	 * @param index 集計情報のインデックス値
	 * @return 集計情報の順番を表すリソースキー
	 */
	protected String createOrderKey(int index) {
		return ORDER_PREFIX + String.valueOf(index + 1);
	}

	/**
	 * 集計情報ＩＤを表すリソースキーを返します。
	 *
	 * @param index 集計情報ＩＤのインデックス値
	 * @return 集計情報ＩＤを表すリソースキー
	 */
	protected String createSumInfoKey(int index) {
		return SUM_INFO_PREFIX + String.valueOf(index + 1);
	}

	@Override
	protected Set<MCColumnConfig> getCachedVisibleColumnConfigs(MCTable tbl,
			String type) {
		return null;
	}

	/**
	 * 集計区分の表示名称を返します。
	 *
	 * @param type 集計区分
	 * @return 表示名称
	 */
	public String getLabelName(FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return null;
		}
		String sfx = MCConst.createKey(
				"SumInfoType", type.key(), "label");

		String[][] msa = getModuleAndScreenIDs();
		for (String[] ms : msa) {
			String k = MCConst.createKey(ms[0], ms[1], sfx);
			if (MCConst.label.containsKey(k)) {
				return MCConst.label.getLabel(k);
			}
		}
		return null;
	}

	protected String getLabelPosition(FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return POSITION_TAIL;
		}
		String sfx = MCConst.createKey(
				"SumInfoType", type.key(), "label_position");

		String[][] msa = getModuleAndScreenIDs();
		for (String[] ms : msa) {
			String k = MCConst.createKey(ms[0], ms[1], sfx);
			if (MCConst.layout.containsKey(k)) {
				String p = MCConst.layout.getString(k);
				if (POSITION_HEAD.equalsIgnoreCase(p)) {
					return POSITION_HEAD;
				}
				return POSITION_TAIL;
			}
		}
		return POSITION_TAIL;
	}

	protected String getMessageName(FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return null;
		}
		String sfx = MCConst.createKey(
				"SumInfoType", type.key(), "message");

		String[][] msa = getModuleAndScreenIDs();
		for (String[] ms : msa) {
			String k = MCConst.createKey(ms[0], ms[1], sfx);
			if (MCConst.label.containsKey(k)) {
				return MCConst.label.getLabel(k);
			}
		}
		return null;
	}

	protected String getMessagePosition(FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return POSITION_TAIL;
		}
		String sfx = MCConst.createKey(
				"SumInfoType", type.key(), "message_position");

		String[][] msa = getModuleAndScreenIDs();
		for (String[] ms : msa) {
			String k = MCConst.createKey(ms[0], ms[1], sfx);
			if (MCConst.layout.containsKey(k)) {
				String p = MCConst.layout.getString(k);
				if (POSITION_HEAD.equalsIgnoreCase(p)) {
					return POSITION_HEAD;
				}
				return POSITION_TAIL;
			}
		}
		return POSITION_TAIL;
	}

	/**
	 * 計算式が入力可能な場合 true を返します。
	 *
	 * @param infoR 評価する行のRow
	 * @return 入力不可の場合 false
	 */
	protected boolean editableFormula(InfoDtlR infoR) {
		String colnm = infoR.column_nm();
		FSC_SUM_INFO_TYPE type = FSC_SUM_INFO_TYPE.getNE(infoR.sum_info_type());
		if (colnm == null || type == null || FSC_SUM_INFO_TYPE.isTYPE_COUNT(type)) {
			// カラム名、集計情報区分なし
			// 集計情報区分が件数
			return false;
		}
		MCList colList = getColumnNameList(type);
		if (colList.getFirst(InfoDtlR.$column_nm, colnm) != null) {
			return false;
		}
		return true;
	}

	/**
	 * 計算式の変数を表示項目からカラム名に変換します。
	 *
	 * <p>
	 * 集計情報区分に対応した項目が変換対象です。
	 *
	 * @param formula 計算式
	 * @param type 集計情報区分
	 * @return 変換した計算式
	 * @throws MCException [FCBEC0059] 式に文法エラーがある場合
	 */
	public String toColumnKeyFormula(String formula, String type) {
		FSC_SUM_INFO_TYPE y = FSC_SUM_INFO_TYPE.getNE(type);
		return toColumnKeyFormula(formula, y);
	}

	/**
	 * 計算式の変数を表示項目からカラム名に変換します。
	 *
	 * <p>
	 * 集計情報区分に対応した項目が変換対象です。
	 *
	 * @param formula 計算式
	 * @param type 集計情報区分
	 * @return 変換した計算式
	 * @throws MCException [FCBEC0059] 式に文法エラーがある場合
	 */
	public String toColumnKeyFormula(String formula, FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return formula;
		}

		MCExpressionBuilder eb = (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type))
							? createExpressionBuilder(MCList.create(MCRow.class))
							: createExpressionBuilder();
		List<String>[] lists = getVariableMapList(type);
		return eb.convertVariables(formula, lists[1], lists[0]);
	}
	
	/**
	 * IDに変換済みの計算式の妥当性をチェックします。
	 * @param f 集計情報行
	 */
	private boolean checkFormulaCalc(InfoDtlR f, MCMessageList ml) {
		String fomura_calc= f.formula_calc();
		FSC_SUM_INFO_TYPE type = FSC_SUM_INFO_TYPE.getNE(f.sum_info_type());
		
		if (type == null) {
			return true;
		}

		MCExpressionBuilder eb = (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type))
							? createExpressionBuilder(MCList.create(MCRow.class))
							: createExpressionBuilder();
		List<String> list = getVariableKeyList(type);
		try {
			eb.convertVariables(fomura_calc, list, list);
		}
		catch (MCException e) {
			if (FCBEC0059.equals(e.getID())) {
				ml.add(e.getMCMessage());
				return false;
			}
		}
		return true;
		
	}
	
	/**
	 * 計算式の変数をカラム名から表示項目に変換します。
	 *
	 * <p>
	 * 集計情報区分に対応した項目が変換対象です。
	 *
	 * @param formula 計算式
	 * @param type 集計情報区分
	 * @return 変換した計算式
	 * @throws MCException [FCBEC0059] 式に文法エラーがある場合
	 */
	public String toColumnNameFormula(String formula, String type) {
		FSC_SUM_INFO_TYPE y = FSC_SUM_INFO_TYPE.getNE(type);
		return toColumnNameFormula(formula, y);
	}

	/**
	 * 計算式の変数をカラム名から表示項目に変換します。
	 *
	 * <p>
	 * 集計情報区分に対応した項目が変換対象です。
	 *
	 * @param formula 計算式
	 * @param type 集計情報区分
	 * @return 変換した計算式
	 * @throws MCException [FCBEC0059] 式に文法エラーがある場合
	 */
	public String toColumnNameFormula(String formula, FSC_SUM_INFO_TYPE type) {
		if (type == null) {
			return formula;
		}

		MCExpressionBuilder eb = (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type))
							? createExpressionBuilder(MCList.create(MCRow.class))
							: createExpressionBuilder();
		List<String>[] lists = getVariableMapList(type);
		return eb.convertVariables(formula, lists[0], lists[1]);
	}

	/**
	 * ExpressionBuilderを生成します。
	 *
	 * <p>
	 * 集計関数は使えません。
	 *
	 * @return ExpressionBuilder
	 */
	protected MCExpressionBuilder createExpressionBuilder() {
		return createExpressionBuilder(null);
	}

	/**
	 * ExpressionBuilderを生成します。
	 *
	 * <p>
	 * 集計関数を使用する場合には、集計に使用するリストを引数に設定してください。
	 * nullの場合、集計関数は使えません。
	 *
	 * @param list 集計関数用リスト
	 * @return ExpressionBuilder
	 */
	protected MCExpressionBuilder createExpressionBuilder(MCList<MCRow> list) {
		MCExpressionBuilder eb = new MCExpressionBuilder();
		if (list != null) {
			// 集計関数追加
			eb.addFunctions(new MCAggregateFunctions(list));
		}
		return eb;
	}

	/**
	 * 集計情報が、集計後計算における式の変数として使用可能な場合は true を返します。
	 * 無効フラグは評価しません。
	 * @param infoR 集計情報
	 * @return 利用不可の場合 false
	 */
	protected boolean isVariableCandidateForAfterCalc(InfoDtlR infoR) {
		if (infoR == null) {
			return false;
		}
		FSC_SUM_INFO_TYPE sit = FSC_SUM_INFO_TYPE.getNE(infoR.sum_info_type());
		return (sit != null
				&& !FSC_SUM_INFO_TYPE.isTYPE_GROUP(sit)
				&& !FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(sit)
		);
	}


	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		ListDtlTable.setCellConfig(createListDtlCellConfig());
		InfoDtlTable.setCellConfig(createInfoDtlCellConfig());
		RsltTable.setCellConfig(createRsltCellConfig());

	}

	/**
	 * 集計情報テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 集計情報テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createInfoDtlCellConfig() {
		return new WBP_InfoDtl_CellConfig();
	}

	/**
	 * 集計情報テーブルのセルコンフィグです。
	 *
	 */
	public class WBP_InfoDtl_CellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			// 利用不可のカラムのモード
			final MCMode _LIMITED_MODE = MCMode.DISABLE;//READ_ONLY;

			InfoDtlR o = getInfoDtlL().get(index);
			String y = o.sum_info_type();

			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}

			if (column == columnInfoDtl_column_nm) {
				if (isNull(y)) {
					return _LIMITED_MODE;
				}
				if (FSC_SUM_INFO_TYPE.isTYPE_COUNT(y)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_sumcond) {
				if (isNull(y)
						|| FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)
						|| FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(y)
				) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_rank) {
				if (isNull(y) || FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_fill_dt) {
				if (isNull(y) || !isDateColumn(o.column_key())) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_date_fmt) {
				if (isNull(y) || !isDateColumn(o.column_key())) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_formula) {
				if (!editableFormula(o)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_dec_place
					|| column == columnInfoDtl_rounding_mode_type_nm) {
				if (editableFormula(o)) {
					// 計算式有効 -> 小数桁数必須
					return MCMode.REQUIRED;
				}
				else {
					// 計算式無効
					if (!FSC_SUM_INFO_TYPE.isTYPE_AVG(y)) {
						return _LIMITED_MODE;
					}
				}
			}
			else if (column == columnInfoDtl_null_zero) {
				if (isNull(y)
						|| FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)
						|| FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(y)
				) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_sort_order
					|| column == columnInfoDtl_sort_type) {
				if (isNull(y)) {
					return _LIMITED_MODE;
				}
				if (!isNullAnd(o.sort_order(), o.sort_type())) {
					return MCMode.REQUIRED;
				}
			}
			else if (column == columnInfoDtl_chart_type_nm) {
				if (isNull(y) || FSC_SUM_INFO_TYPE.isTYPE_GROUP(y)) {
					return _LIMITED_MODE;
				}
			}
			else if (column == InfoDtl_chart_color_p_PPanel.columnColor_color) {
				if (isNull(y) || FSC_SUM_INFO_TYPE.isTYPE_GROUP(y) || isNull(o.chart_type())) {
					return _LIMITED_MODE;
				}
			}
			else if (column == columnInfoDtl_row_label) {
				if (isNull(y)) {
					return _LIMITED_MODE;
				}
			}

			return super.getPriorMode(index, column, table);
		}
	}

	/**
	 * 集計情報一覧テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 集計情報一覧テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createListDtlCellConfig() {
		return new WBC_ListDtl_CellConfig();
	}

	/**
	 * 集計情報一覧テーブルのセルコンフィグです。
	 *
	 */
	public class WBC_ListDtl_CellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {

			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}

			if (column == columnListDtl_init_flg) {
				if (index == ListDtlTable.getMCSelectedRow()) {
					if (isNull(getInfoBtnR().sum_info_nm())) {
						return MCMode.READ_ONLY;
					}
				}
				else if (getListDtlL().get(index).isEmpty()) {
					return MCMode.READ_ONLY;
				}
			}

			return super.getPriorMode(index, column, table);
		}

	}

	/**
	 * 集計結果テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 集計結果テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createRsltCellConfig() {
		return new RsltCellConfig();
	}

	/**
	 * 集計結果テーブルのセルコンフィグです。
	 *
	 */
	public class RsltCellConfig extends FXBAP_CellConfig {

		@Override
		public MCZeroType getPriorViewZeroType(int index,
				MCColumnConfig column, MCTable<?> table) {
			return MCZeroType.NONE;
		}

	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	protected SettingR getSettingR() {
		return Setting_setting_PPanel.getSettingR();
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		if (RsltTable.equals(beans)) {
			return createRsltPopupConfig();
		}
		return super.createFXBAP_PopupConfig(beans);
	}

	protected FXBAP_PopupConfig createRsltPopupConfig() {
		return new WBP_RsltPopupConfig();
	}

	public class WBP_RsltPopupConfig extends FSUCP_PopupConfig {

		public WBP_RsltPopupConfig() {
			super(FSUCP_PopupConfig.PERSONALIZE_PANEL);
		}
	}


	@Override
	public void doCloseOuterGraph(MCFXGraphCore graph) {
	}

	@Override
	public boolean doClickXYGraph(MCFXGraphCore graph, XYChart chart,
			Series<String, Number> series, Data data, String xValue, Number yValue) {
		return false;
	}

	@Override
	public boolean doClickPieGraph(MCFXGraphCore graph, PieChart chart,
			javafx.scene.chart.PieChart.Data item, String labelValue, Number pieValue) {
		return false;
	}

	@Override
	public boolean installTooltipPie(MCFXGraphCore graph, PieChart chart,
			javafx.scene.chart.PieChart.Data data) {
		return false;
	}

	@Override
	public MCFXGraphDetailsTooltip getDetailsTooltip(MCFXGraphCore graph) {
		return null;
	}

	@Override
	public MCFXGraphDetailsTooltipPie getDetailsTooltipPie(MCFXGraphCore graph) {
		return null;
	}


	/**
	 * 集計結果のカラムを作成するための情報です。
	 */
	public class WBP_ColumnInfo {

		/**
		 * 集計情報です。
		 */
		protected InfoDtlR _info = null;

		/**
		 * 親画面のテーブルカラムです。
		 */
		protected MCColumnConfig _target_column_config = null;

		/**
		 * カラム名です。
		 */
		protected String _column_name = null;

		/**
		 * ラベル名です。
		 */
		protected String _label_name = null;

		/**
		 * メッセージ用名称です。
		 */
		protected String _message_name = null;

		/**
		 * 計算式用名称です。
		 */
		protected String _calc_name = null;

		/**
		 * カラムタイプです。
		 */
		protected MCColumnType _column_type = null;

		/**
		 * メタです。
		 */
		protected MCMeta _meta = null;

		/**
		 * フォーマットＩＤです。
		 */
		protected String _format_id = null;

		/**
		 * コンストラクタです。
		 */
		public WBP_ColumnInfo() {}

		/**
		 * 集計情報を設定します。
		 *
		 * @param info 集計情報
		 */
		public void setInfoDtlR(InfoDtlR info) {
			_info = info;
		}

		/**
		 * 集計情報を返します。
		 *
		 * @return 集計情報
		 */
		public InfoDtlR getInfoDtlR() {
			return _info;
		}

		/**
		 * 親画面のテーブルカラムを設定します。
		 *
		 * @param column 親画面のテーブルカラム
		 */
		public void setTargetColumnConfig(MCColumnConfig column) {
			_target_column_config = column;
		}

		/**
		 * 親画面のテーブルカラムを返します。
		 *
		 * @return 親画面のテーブルカラム
		 */
		public MCColumnConfig getTargetColumnConfig() {
			return _target_column_config;
		}

		/**
		 * カラム名を設定します。
		 *
		 * @param name カラム名
		 */
		public void setColumnName(String name) {
			_column_name = name;
		}

		/**
		 * カラム名を返します。
		 *
		 * @return カラム名
		 */
		public String getColumnName() {
			return _column_name;
		}

		/**
		 * ラベル名を設定します。
		 *
		 * @param name ラベル名
		 */
		public void setLabelName(String name) {
			_label_name = name;
		}

		/**
		 * ラベル名を返します。
		 *
		 * @return ラベル名
		 */
		public String getLabelName() {
			return _label_name;
		}

		/**
		 * メッセージ用名称を設定します。
		 *
		 * @param name メッセージ用名称
		 */
		public void setMessageName(String name) {
			_message_name = name;
		}

		/**
		 * メッセージ用名称を返します。
		 *
		 * @return メッセージ用名称
		 */
		public String getMessageName() {
			return _message_name;
		}

		/**
		 * 計算式用名称を設定します。
		 *
		 * @param name 計算式用名称
		 */
		public void setCalcName(String name) {
			_calc_name = name;
		}

		/**
		 * 計算式用名称を返します。
		 *
		 * @return 計算式用名称
		 */
		public String getCalcName() {
			return _calc_name;
		}

		/**
		 * カラムタイプを設定します。
		 *
		 * @param type カラムタイプ
		 */
		public void setColumnType(MCColumnType type) {
			_column_type = type;
		}

		/**
		 * カラムタイプを返します。
		 *
		 * @return カラムタイプ
		 */
		public MCColumnType getColumnType() {
			return _column_type;
		}

		/**
		 * メタを設定します。
		 *
		 * @param meta メタ
		 */
		public void setMeta(MCMeta meta) {
			_meta = meta;
		}

		/**
		 * メタを返します。
		 *
		 * @return メタ
		 */
		public MCMeta getMeta() {
			return _meta;
		}

		/**
		 * フォーマットＩＤを設定します。
		 *
		 * @param id フォーマットＩＤ
		 */
		public void setFormatID(String id) {
			_format_id = id;
		}

		/**
		 * フォーマットＩＤを返します。
		 *
		 * @return フォーマットＩＤ
		 */
		public String getFormatID() {
			return _format_id;
		}
	}

}