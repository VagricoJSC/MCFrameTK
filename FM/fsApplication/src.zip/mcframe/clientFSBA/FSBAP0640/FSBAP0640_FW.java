package mcframe.clientFSBA.FSBAP0640;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0060.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientFSBA.FSBAP0650.FSBAP0650;
import mcframe.clientFSBA.FSBAP0650.InfoR;
import mcframe.clientFSBE.FSBEP0330.MCBarcodeUtil;
import mcframe.clientFSUB.FSUBP0000.IfRowMoveBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0640"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0640_FW extends FSBAP0640_FW_A implements IfRowMoveBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0640_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0640_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[ListSrcBtn]のボタン[appendEnd]の押下時の処理
	 */
	@Override
	public void doListSrcBtn_appendEnd(MCEventInfo info) {
		appendCommand(MCBarcodeUtil.commandEnd, null);
	}
	/**
	 * Panel[ListSrcBtn]のボタン[appendUser]の押下時の処理
	 */
	@Override
	public void doListSrcBtn_appendUser(MCEventInfo info) {
		appendCommand(MCBarcodeUtil.commandUser, null);
	}
//	/**
//	 * Panel[ListSrcBtn]のボタン[appendAuto]の押下時の処理
//	 */
//	@Override
//	public void doListSrcBtn_appendAuto(MCEventInfo info) {
//		appendCommand(MCBarcodeUtil.commandAuto, null);
//	}

	protected void appendCommand(String id, String nm) {

		ListDestTblR r2 = ListDestTblR.create();
		r2.comp_id(id);
		r2.comp_nm(nm);
		r2.btn_flg(false);
		r2.panel_id("");
		r2.root_panel_id("");

		ListDestTblR r3 = ListDestTblTable.getSelectedMCRow();
		if (r3 == null) {
			ListDestTblTable.getList().add(r2);
		}
		else {
			int idx3 = ListDestTblTable.getList().indexOf(r3);
			ListDestTblTable.getList().add(idx3 + 1, r2);
		}

		int index = ListDestTblTable.getList().indexOf(r2);
		ListDestTblTable.selectRowNoFocus(index);

		r2.setStatus(Status.CREATE);
	}

	/**
	 * Panel[ListSrcBtn]のボタン[moveToRight]の押下時の処理
	 */
	@Override
	public void doListSrcBtn_moveToRight(MCEventInfo info) {
		ListSrcTblR r1 = ListSrcTblTable.getSelectedMCRow();
		if (r1 == null) {
			return;
		}

		ListDestTblR r2 = ListDestTblR.create();
		r2.comp_id(r1.comp_id());
		r2.comp_nm(r1.comp_nm());
		r2.btn_flg(r1.btn_flg());
		r2.panel_id(r1.panel_id());
		r2.root_panel_id(r1.root_panel_id());

		ListDestTblR r3 = ListDestTblTable.getSelectedMCRow();
		int idx3 = ListDestTblTable.getList().indexOf(r3);
		if (r3 == null) {
			ListDestTblTable.getList().add(r2);
		}
		else {
			ListDestTblTable.getList().add(idx3 + 1, r2);
		}

		int index = ListDestTblTable.getList().indexOf(r2);
		ListDestTblTable.selectRowNoFocus(index);

		r2.setStatus(Status.CREATE);
	}

	/**
	 * Panel[ListDestBtn]のボタン[moveToLeft]の押下時の処理
	 */
	@Override
	public void doListDestBtn_moveToLeft(MCEventInfo info) {
		ListDestTblR r1 = ListDestTblTable.getSelectedMCRow();
		if (r1 == null) {
			return;
		}
		int index = ListDestTblTable.getList().indexOf(r1);
		ListDestTblTable.getList().remove(r1);

		if (index > 0) {
			ListDestTblTable.selectRowNoFocus(index - 1);
		}
		else {
			ListDestTblTable.selectRowNoFocus(0);
		}
	}

	/**
	 * Panel[UpdBtn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doUpdBtn_upd(MCEventInfo info) {
		// 値を親画面側に適用する。
		MCLinkBeans lb = getISListPutter().getLinkBeans();

		if (lb instanceof MCTableColumn == false) {
			return;
		}
		MCTableColumn c = (MCTableColumn) lb;

		boolean isSingleBeans = isSingleBeans();
		boolean f = false;
		StringBuilder sb = new StringBuilder();
		
		if(isSingleBeans) {
			for (ListDestTblR r1 : ListDestTblTable.getList()) {
				sb.append(r1.comp_id());
				break;
			}
		}
		else {
			for (ListDestTblR r1 : ListDestTblTable.getList()) {
				if (f) {
					sb.append("^");
				}
				sb.append(r1.comp_id());
				f = true;
			}
		}

		int idx = c.getTable().getMCSelectedRow();
		c.setValue(idx, sb.toString());

		requestCloseWindow();
	}

	/**
	 * Panel[Cnd]のボタン[reload]の押下時の処理
	 */
	@Override
	public void doCnd_reload(MCEventInfo info) {
		reloadSrc();
	}

	@Override
	public void doCnd_srch(MCEventInfo info) {
	}

	//リロードする。
	protected void reloadSrc() {

		MCLinkBeans b = getISListPutter().getLinkBeans();
		if (b instanceof MCTableColumn == false) {
			return;
		}

		boolean onlyButton = false;

		MCTableColumn c = (MCTableColumn) b;
		if ("Info.focus_out_nm".equals(c.getName())) {
			onlyButton = true;
		}

		MCList<InfoR> list = get_component_list();
		MCList<ListSrcTblR> list2 = MCList.create(ListSrcTblR.class);
		for (InfoR r1 : list) {
			if (onlyButton) {
				if (r1.btn_flg() == false) {
					continue;
				}
			}
			ListSrcTblR r2 = ListSrcTblR.create();
			r2.comp_id(r1.comp_id());
			r2.comp_nm(r1.comp_nm());
			r2.btn_flg(r1.btn_flg());
			r2.panel_id(r1.panel_id());
			r2.root_panel_id(r1.root_panel_id());

			list2.add(r2);
		}
		setListSrcTblL(list2);
	}

	@Override
	public void setCondition(MCRow row, String mode) {
	}

	@Override
	public MCList<?> getRsltL() {
		return getListDestTblL();
	}

	@Override
	public void layoutVerticalSplitPane2(MCRootPanel p) {
		MCSplitPane cont[] = MCBeansUtil.getAllComponents(MCSplitPane.class, p);
		if (cont.length == 0) {
			return;
		}

		for (MCSplitPane sp : cont) {
			Container c = sp.getBaseRootPanel();
			int w1 = c.getPreferredSize().width;
			int pos = w1 / 2;
			sp.setDividerLocationWithRatio(pos);
			break;
		}
	}

	@Override
	public MCTable<?> getRowMoveTable() {
		return ListDestTblTable;
	}

	@Override
	public boolean isStatusChange() {
		return true;
	}

	protected MCList<InfoR> get_component_list() {
		MCLinkBeans b = getISListPutter().getLinkBeans();
		FSBAP0650 rp = (FSBAP0650) b.getBaseRootPanel();
		return rp.get_component_list();
	}

	//複数指定不可かどうか
	protected boolean isSingleBeans() {
		MCLinkBeans b = getISListPutter().getLinkBeans();
		if (b instanceof MCTableColumn == false) {
			return false;
		}

		boolean isSingle = false;
		
		MCTableColumn c = (MCTableColumn) b;

		if ("Info.focus_in_nm".equals(c.getName())) {
			isSingle = true;
		}
		if ("Info.button_next_focus_nm".equals(c.getName())) {
			isSingle = true;
		}

		return isSingle;
	}
	
	
	// User/Autoが使えるかどうか
	protected boolean useUser() {
		MCLinkBeans b = getISListPutter().getLinkBeans();
		if (b instanceof MCTableColumn == false) {
			return false;
		}

		boolean onlyButton = false;

		MCTableColumn c = (MCTableColumn) b;
		if ("Info.focus_out_nm".equals(c.getName())) {
			onlyButton = true;
		}
		return onlyButton;
	}

	protected void reloadDest() {
		ListDestTblTable.clear();

		MCLinkBeans lb = getISListPutter().getLinkBeans();
		if (lb instanceof MCTableColumn == false) {
			return;
		}
		MCTableColumn c = (MCTableColumn) lb;

		int idx = c.getTable().getMCSelectedRow();
		String s = (String) c.getValue(idx);
		if (MCStringUtil.nullToBlank(s).equals("")) {
			return;
		}
		String a[] = s.split("\\^");
		for (String s1 : a) {
			if (s1.equals(MCBarcodeUtil.commandUser)) {
				ListDestTblR r2 = ListDestTblR.create();
				r2.comp_id(MCBarcodeUtil.commandUser);
				r2.comp_nm(null);
				r2.btn_flg(false);
				r2.panel_id(null);
				r2.root_panel_id(null);
				ListDestTblTable.getList().add(r2);
			}
			else if (s1.equals(MCBarcodeUtil.commandAuto)) {
				ListDestTblR r2 = ListDestTblR.create();
				r2.comp_id(MCBarcodeUtil.commandAuto);
				r2.comp_nm(null);
				r2.btn_flg(false);
				r2.panel_id(null);
				r2.root_panel_id(null);
				ListDestTblTable.getList().add(r2);
			}
			else if (s1.equals(MCBarcodeUtil.commandEnd)) {
				ListDestTblR r2 = ListDestTblR.create();
				r2.comp_id(MCBarcodeUtil.commandEnd);
				r2.comp_nm(null);
				r2.btn_flg(false);
				r2.panel_id(null);
				r2.root_panel_id(null);
				ListDestTblTable.getList().add(r2);
			}
			else {
				for (ListSrcTblR r1 : ListSrcTblTable.getList()) {
					String s2 = r1.comp_id();
					if (s2.equals(s1)) {
						ListDestTblR r2 = ListDestTblR.create();
						r2.comp_id(r1.comp_id());
						r2.comp_nm(r1.comp_nm());
						r2.btn_flg(r1.btn_flg());
						r2.panel_id(r1.panel_id());
						r2.root_panel_id(r1.root_panel_id());
						ListDestTblTable.getList().add(r2);
						break;
					}
				}
			}
		}
	}

	@Override
	public boolean beforeOpen() {
		boolean b = super.beforeOpen();
		if (getISListPutter() == null) {
			return b;
		}

		if (b) {
			MCLinkBeans lb = getISListPutter().getLinkBeans();
			FSBAP0650 rp = (FSBAP0650) lb.getBaseRootPanel();
			if (lb instanceof MCTableColumn == false) {
				return true;
			}
			MCTableColumn c = (MCTableColumn) lb;
			InfoR r = (InfoR) c.getTable().getSelectedMCRow();

			Cnd_module_id.setValue(rp.getTargetRootPanel().getModuleID());
			Cnd_screen_id.setValue(rp.getTargetRootPanel().getScreenID());
			Cnd_componentID.setValue(r.comp_id());
			Cnd_componentNM.setValue(r.comp_nm());

			reloadSrc();
			reloadDest();

			if (useUser()) {
				ListSrcBtn_appendUser.setMode(MCMode.ENABLE);
//				ListSrcBtn_appendAuto.setMode(MCMode.ENABLE);
			}
			else {
				ListSrcBtn_appendUser.setMode(MCMode.DISABLE);
//				ListSrcBtn_appendAuto.setMode(MCMode.DISABLE);
			}
		}
		return b;
	}

}