package mcframe.clientFSBA.FSBAP0640;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ListDest"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListDestR_FW_A extends MCConstRow {

	/**
	 *  部品ID.<p>
	 *
	 */
	public static final String $componentID = "componentID";


	public static final MCMeta componentID_META = createStringMeta($componentID);

	protected static final ConstMetaList<ListDestR> constMetas = new ConstMetaList<ListDestR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			componentID_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListDestR_FW_A(ConstMetaList<? extends ListDestR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDestR clone() {
		return (ListDestR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDestR createInstance() {
		return (ListDestR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDestR getValues(String... names) {
		return (ListDestR) super.getValues(names);
	}



	/**
	 *  部品ID.<p>
	 *
	 */
	public String componentID() {
		return getConstString(offset + 0, $componentID);
	}

	/**
	 *  部品ID.<p>
	 *
	 */
	public void componentID(String value) {
		setConstString(offset + 0, $componentID, value);
	}


	public String getString(String name) {
		if ($componentID.equalsIgnoreCase(name)) {
			return componentID();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($componentID.equalsIgnoreCase(name)) {
			return componentID();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($componentID.equalsIgnoreCase(name)) {
			componentID(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($componentID.equalsIgnoreCase(name)) {
			componentID(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

