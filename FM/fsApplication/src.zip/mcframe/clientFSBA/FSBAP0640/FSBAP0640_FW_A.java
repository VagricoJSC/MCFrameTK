package mcframe.clientFSBA.FSBAP0640;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0640"パネルクラスです。<p>
 *
 * バーコードフォーカス入力補助<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0640_FW_A extends mcframe.clientFXBA.FXBAP0030.FXBAP_ISPanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0640";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	// [Cnd]ブロックの項目のField定義
	public MCLabel Cnd_module_id_Label = null;
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_module_id = null;
	public MCLabel Cnd_screen_id_Label = null;
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_screen_id = null;
	public MCLabel Cnd_componentID_Label = null;
	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_componentID = null;
	/**
	 *  画面部品名.<p>
	 *
	 */
	public MCTextField Cnd_componentNM = null;
	/**
	 *  最新情報を取得.<p>
	 *
	 */
	public MCButton Cnd_reload = null;
	// [ListSrc]ブロック関連のField定義
	public MCPanel ListSrcPanel = null;
	// [ListSrc]ブロックの項目のField定義
	// [ListSrcTbl]ブロック関連のField定義
	public MCPanel ListSrcTblPanel = null;
	public MCScrollPane ListSrcTblScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0640.ListSrcTblR> ListSrcTblTable = null;
	// [ListSrcTbl]ブロックの項目のField定義
	/**
	 *  画面部品.<p>
	 *
	 */
	public MCColumnConfig columnListSrcTbl_comp_id = null;
	/**
	 *  画面部品名.<p>
	 *
	 */
	public MCColumnConfig columnListSrcTbl_comp_nm = null;
	// [ListDest]ブロック関連のField定義
	public MCPanel ListDestPanel = null;
	// [ListDest]ブロックの項目のField定義
	// [ListDestTbl]ブロック関連のField定義
	public MCPanel ListDestTblPanel = null;
	public MCScrollPane ListDestTblScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0640.ListDestTblR> ListDestTblTable = null;
	// [ListDestTbl]ブロックの項目のField定義
	/**
	 *  画面部品.<p>
	 *
	 */
	public MCColumnConfig columnListDestTbl_comp_id = null;
	/**
	 *  画面部品名.<p>
	 *
	 */
	public MCColumnConfig columnListDestTbl_comp_nm = null;
	// [ListSrcBtn]ブロック関連のField定義
	public MCPanel ListSrcBtnPanel = null;
	// [ListSrcBtn]ブロックの項目のField定義
	/**
	 *  >>.<p>
	 *
	 */
	public MCButton ListSrcBtn_moveToRight = null;
	/**
	 *  User>>.<p>
	 *
	 */
	public MCButton ListSrcBtn_appendUser = null;
	/**
	 *  End>>.<p>
	 *
	 */
	public MCButton ListSrcBtn_appendEnd = null;
	// [ListDestBtn]ブロック関連のField定義
	public MCPanel ListDestBtnPanel = null;
	// [ListDestBtn]ブロックの項目のField定義
	/**
	 *  <<.<p>
	 *
	 */
	public MCButton ListDestBtn_moveToLeft = null;
	// [MoveP]ブロック関連のField定義
	public MCPanel MovePPanel = null;
	// [MoveP]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H MoveP_menu_move_p_PPanel;
	// [UpdBtn]ブロック関連のField定義
	public MCPanel UpdBtnPanel = null;
	// [UpdBtn]ブロックの項目のField定義
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton UpdBtn_upd = null;
	/** [UPD]モードを表す定数 */
	public static final String UPD = "UPD";
	/** [FIX]モードを表す定数 */
	public static final String FIX = "FIX";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{UPD, FIX};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0640.CndR aCndR;
	/** [ListSrcTbl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0640.ListSrcTblR> aListSrcTblL;
	/** [ListDestTbl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0640.ListDestTblR> aListDestTblL;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFSBA.FSBAP0640.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0640.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0640.CndR createCndR() {
		return mcframe.clientFSBA.FSBAP0640.CndR.create();
	}

	/**
	 * コピーによってaListSrcTblLを設定します。
	 *
	 * aListSrcTblLのインスタンスは変更されません。
	 *
	 * @param dataset ListSrcTblL
	 */
	public void setListSrcTblL(MCList<mcframe.clientFSBA.FSBAP0640.ListSrcTblR> aList) {
		if (getListSrcTblL() != aList) {
			getListSrcTblL().setAll(aList);
		}
	}

	/**
	 * [ListSrcTbl]ブロックのコンテナaListSrcTblLを返します。
	 *
	 * @return ListSrcTblL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0640.ListSrcTblR> getListSrcTblL() {
		return aListSrcTblL;
	}

	/**
	 * aListSrcTblRを作成します。
	 *
	 * @return ListSrcTblR
	 */
	public mcframe.clientFSBA.FSBAP0640.ListSrcTblR createListSrcTblR() {
		return mcframe.clientFSBA.FSBAP0640.ListSrcTblR.create();
	}

	/**
	 * aListSrcTblLを作成します。
	 *
	 * @return ListSrcTblL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0640.ListSrcTblR> createListSrcTblL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0640.ListSrcTblR.class);
	}

	/**
	 * ListSrcTblTableを初期化します。
	 */
	protected void createListSrcTblTable(){
		if(ListSrcTblTable == null){
			ListSrcTblTable = beansFactory.createTable2("ListSrcTbl.table");
		}
	}

	/**
	 * コピーによってaListDestTblLを設定します。
	 *
	 * aListDestTblLのインスタンスは変更されません。
	 *
	 * @param dataset ListDestTblL
	 */
	public void setListDestTblL(MCList<mcframe.clientFSBA.FSBAP0640.ListDestTblR> aList) {
		if (getListDestTblL() != aList) {
			getListDestTblL().setAll(aList);
		}
	}

	/**
	 * [ListDestTbl]ブロックのコンテナaListDestTblLを返します。
	 *
	 * @return ListDestTblL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0640.ListDestTblR> getListDestTblL() {
		return aListDestTblL;
	}

	/**
	 * aListDestTblRを作成します。
	 *
	 * @return ListDestTblR
	 */
	public mcframe.clientFSBA.FSBAP0640.ListDestTblR createListDestTblR() {
		return mcframe.clientFSBA.FSBAP0640.ListDestTblR.create();
	}

	/**
	 * aListDestTblLを作成します。
	 *
	 * @return ListDestTblL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0640.ListDestTblR> createListDestTblL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0640.ListDestTblR.class);
	}

	/**
	 * ListDestTblTableを初期化します。
	 */
	protected void createListDestTblTable(){
		if(ListDestTblTable == null){
			ListDestTblTable = beansFactory.createTable2("ListDestTbl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getListSrcTblL())) ret.add(getListSrcTblL());
		if(!MCCollectionUtil.contains(ret, getListDestTblL())) ret.add(getListDestTblL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getListSrcTblL()) return "ListSrcTbl";
		if(aCnt == getListDestTblL()) return "ListDestTbl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("ListSrcTbl")) return getListSrcTblL();
		if(bId.equals("ListDestTbl")) return getListDestTblL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(ListSrcPanel);
		ret.add(ListSrcTblPanel);
		ret.add(ListDestPanel);
		ret.add(ListDestTblPanel);
		ret.add(ListSrcBtnPanel);
		ret.add(ListDestBtnPanel);
		ret.add(MovePPanel);
		ret.add(UpdBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0640_FW_A() {
		aCndR = createCndR();
		aListSrcTblL = createListSrcTblL();
		aListDestTblL = createListDestTblL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0640_FW_A(String name) {
		aCndR = createCndR();
		aListSrcTblL = createListSrcTblL();
		createListSrcTblTable();
		ListSrcTblTable.setRowName(name);
		aListDestTblL = createListDestTblL();
		createListDestTblTable();
		ListDestTblTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0640_FW.jbCreateCnd((FSBAP0640)this);
		FSBAP0640_FW.jbCreateListSrc((FSBAP0640)this);
		FSBAP0640_FW.jbCreateListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.jbCreateListDest((FSBAP0640)this);
		FSBAP0640_FW.jbCreateListDestTbl((FSBAP0640)this);
		FSBAP0640_FW.jbCreateListSrcBtn((FSBAP0640)this);
		FSBAP0640_FW.jbCreateListDestBtn((FSBAP0640)this);
		FSBAP0640_FW.jbCreateMoveP((FSBAP0640)this);
		FSBAP0640_FW.jbCreateUpdBtn((FSBAP0640)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FSBAP0640 p) {
	}

	/**
	 * [ListSrc]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListSrc(FSBAP0640 p) {
	}

	/**
	 * [ListSrcTbl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListSrcTbl(FSBAP0640 p) {
	}

	/**
	 * [ListDest]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDest(FSBAP0640 p) {
	}

	/**
	 * [ListDestTbl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDestTbl(FSBAP0640 p) {
	}

	/**
	 * [ListSrcBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListSrcBtn(FSBAP0640 p) {
	}

	/**
	 * [ListDestBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDestBtn(FSBAP0640 p) {
	}

	/**
	 * [MoveP]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMoveP(FSBAP0640 p) {
		p.MoveP_menu_move_p_PPanel = mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.create();
		p.MoveP_menu_move_p_PPanel.setName("MoveP.menu_move_p");
	}

	/**
	 * [UpdBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateUpdBtn(FSBAP0640 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0640 create(){
		FSBAP0640 p = new FSBAP0640();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0640 create(String name){
		FSBAP0640 p = new FSBAP0640(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0640_FW.jbfInitCnd((FSBAP0640)this);
		FSBAP0640_FW.jbfInitListSrc((FSBAP0640)this);
		FSBAP0640_FW.jbfInitListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.jbfInitListDest((FSBAP0640)this);
		FSBAP0640_FW.jbfInitListDestTbl((FSBAP0640)this);
		FSBAP0640_FW.jbfInitListSrcBtn((FSBAP0640)this);
		FSBAP0640_FW.jbfInitListDestBtn((FSBAP0640)this);
		FSBAP0640_FW.jbfInitMoveP((FSBAP0640)this);
		FSBAP0640_FW.jbfInitUpdBtn((FSBAP0640)this);
		FSBAP0640_FW.jbInitCnd((FSBAP0640)this);
		FSBAP0640_FW.jbInitListSrc((FSBAP0640)this);
		FSBAP0640_FW.jbInitListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.jbInitListDest((FSBAP0640)this);
		FSBAP0640_FW.jbInitListDestTbl((FSBAP0640)this);
		FSBAP0640_FW.jbInitListSrcBtn((FSBAP0640)this);
		FSBAP0640_FW.jbInitListDestBtn((FSBAP0640)this);
		FSBAP0640_FW.jbInitMoveP((FSBAP0640)this);
		FSBAP0640_FW.jbInitUpdBtn((FSBAP0640)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FSBAP0640 p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		// ブロックの項目の初期化
		p.Cnd_module_id_Label = p.beansFactory.createLabel("Cnd.module_id_Label");
		p.Cnd_module_id = p.beansFactory.createTextField("Cnd.module_id");
		p.Cnd_module_id.setLabel(p.Cnd_module_id_Label);
		p.Cnd_screen_id_Label = p.beansFactory.createLabel("Cnd.screen_id_Label");
		p.Cnd_screen_id = p.beansFactory.createTextField("Cnd.screen_id");
		p.Cnd_screen_id.setLabel(p.Cnd_screen_id_Label);
		p.Cnd_componentID_Label = p.beansFactory.createLabel("Cnd.componentID_Label");
		p.Cnd_componentID = p.beansFactory.createTextField("Cnd.componentID");
		p.Cnd_componentID.setLabel(p.Cnd_componentID_Label);
		p.Cnd_componentNM = p.beansFactory.createTextField("Cnd.componentNM");
		p.Cnd_reload = p.beansFactory.createButton("Cnd.reload", "no_border");
	}

	/**
	 * [ListSrc]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListSrc(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListSrcPanel = p.beansFactory.createPanel("ListSrc");
		// ブロックの項目の初期化
	}

	/**
	 * [ListSrcTbl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListSrcTbl(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListSrcTblPanel = p.beansFactory.createPanel("ListSrcTbl");
		p.ListSrcTblScrollPane = p.beansFactory.createScrollPane("ListSrcTbl.scroll");
		p.createListSrcTblTable();
		// ブロックの項目の初期化
		p.columnListSrcTbl_comp_id = p.beansFactory.createTableColumn("ListSrcTbl.comp_id", MCColumnType.TEXT);
		p.columnListSrcTbl_comp_nm = p.beansFactory.createTableColumn("ListSrcTbl.comp_nm", MCColumnType.TEXT);
	}

	/**
	 * [ListDest]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDest(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListDestPanel = p.beansFactory.createPanel("ListDest");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDestTbl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDestTbl(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListDestTblPanel = p.beansFactory.createPanel("ListDestTbl");
		p.ListDestTblScrollPane = p.beansFactory.createScrollPane("ListDestTbl.scroll");
		p.createListDestTblTable();
		// ブロックの項目の初期化
		p.columnListDestTbl_comp_id = p.beansFactory.createTableColumn("ListDestTbl.comp_id", MCColumnType.TEXT);
		p.columnListDestTbl_comp_nm = p.beansFactory.createTableColumn("ListDestTbl.comp_nm", MCColumnType.TEXT);
	}

	/**
	 * [ListSrcBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListSrcBtn(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListSrcBtnPanel = p.beansFactory.createPanel("ListSrcBtn");
		// ブロックの項目の初期化
		p.ListSrcBtn_moveToRight = p.beansFactory.createButton("ListSrcBtn.moveToRight");
		p.ListSrcBtn_appendUser = p.beansFactory.createButton("ListSrcBtn.appendUser");
		p.ListSrcBtn_appendEnd = p.beansFactory.createButton("ListSrcBtn.appendEnd");
	}

	/**
	 * [ListDestBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDestBtn(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListDestBtnPanel = p.beansFactory.createPanel("ListDestBtn");
		// ブロックの項目の初期化
		p.ListDestBtn_moveToLeft = p.beansFactory.createButton("ListDestBtn.moveToLeft");
	}

	/**
	 * [MoveP]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMoveP(FSBAP0640 p) {
		// ブロック関連の初期化
		p.MovePPanel = p.beansFactory.createPanel("MoveP");
		// ブロックの項目の初期化
	}

	/**
	 * [UpdBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitUpdBtn(FSBAP0640 p) {
		// ブロック関連の初期化
		p.UpdBtnPanel = p.beansFactory.createPanel("UpdBtn");
		// ブロックの項目の初期化
		p.UpdBtn_upd = p.beansFactory.createButton("UpdBtn.upd", "upd");
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FSBAP0640 p) {
		// ブロック関連の初期化
		p.add(p.CndPanel);
		p.setLastBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.ListSrcPanel);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.CndPanel.add(p.Cnd_module_id_Label);
		p.CndPanel.add(p.Cnd_module_id);
		p.CndPanel.setLastBeans(p.Cnd_module_id);
		p.Cnd_module_id.setNextBeans(p.Cnd_screen_id);
		p.Cnd_module_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0640.CndR.module_id_META);
		p.CndPanel.add(p.Cnd_screen_id_Label);
		p.CndPanel.add(p.Cnd_screen_id);
		p.Cnd_screen_id.setNextBeans(p.Cnd_componentID);
		p.Cnd_screen_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0640.CndR.screen_id_META);
		p.CndPanel.add(p.Cnd_componentID_Label);
		p.CndPanel.add(p.Cnd_componentID);
		p.Cnd_componentID.setNextBeans(p.Cnd_componentNM);
		p.Cnd_componentID.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0640.CndR.componentID_META);
		p.CndPanel.add(p.Cnd_componentNM);
		p.Cnd_componentNM.setNextBeans(p.Cnd_reload);
		p.Cnd_componentNM.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0640.CndR.componentNM_META);
		p.Cnd_reload.setIcon("RELOAD");
		p.Cnd_reload.setFunctionKey(MCFunctionKey.F1);
		p.CndPanel.add(p.Cnd_reload);
	}

	/**
	 * [ListSrc]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListSrc(FSBAP0640 p) {
		// ブロック関連の初期化
		p.add(p.ListSrcPanel);
		p.ListSrcPanel.setNextBeans(p.ListDestPanel);
		p.ListSrcPanel.setLayoutPosition("CL+");
		// ブロックの項目の初期化
		p.ListSrcPanel.add(p.ListSrcTblPanel, null);
		p.ListSrcPanel.setLastBeans(p.ListSrcTblPanel);
		p.ListSrcTblPanel.setNextBeans(p.ListSrcBtnPanel);
		p.ListSrcPanel.add(p.ListSrcBtnPanel, null);
	}

	/**
	 * [ListSrcTbl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListSrcTbl(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListSrcTblPanel.add(p.ListSrcTblScrollPane);
		p.ListSrcTblPanel.setLastBeans(p.ListSrcTblTable);
		p.ListSrcTblScrollPane.setViewportView(p.ListSrcTblTable);
		p.ListSrcTblTable.setList(p.getListSrcTblL());
		p.ListSrcTblPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDest]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDest(FSBAP0640 p) {
		// ブロック関連の初期化
		p.add(p.ListDestPanel);
		p.ListDestPanel.setNextBeans(p.UpdBtnPanel);
		p.ListDestPanel.setLayoutPosition("CR+");
		// ブロックの項目の初期化
		p.ListDestPanel.add(p.ListDestBtnPanel, null);
		p.ListDestPanel.setLastBeans(p.ListDestBtnPanel);
		p.ListDestBtnPanel.setNextBeans(p.ListDestTblPanel);
		p.ListDestPanel.add(p.ListDestTblPanel, null);
		p.ListDestTblPanel.setNextBeans(p.MovePPanel);
		p.ListDestPanel.add(p.MovePPanel, null);
	}

	/**
	 * [ListDestTbl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDestTbl(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListDestTblPanel.add(p.ListDestTblScrollPane);
		p.ListDestTblPanel.setLastBeans(p.ListDestTblTable);
		p.ListDestTblScrollPane.setViewportView(p.ListDestTblTable);
		p.ListDestTblTable.setList(p.getListDestTblL());
		p.ListDestTblPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ListSrcBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListSrcBtn(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListSrcBtnPanel.setLayoutPosition("E");
		// ブロックの項目の初期化
		p.ListSrcBtnPanel.add(p.ListSrcBtn_moveToRight);
		p.ListSrcBtnPanel.setLastBeans(p.ListSrcBtn_moveToRight);
		p.ListSrcBtn_moveToRight.setNextBeans(p.ListSrcBtn_appendUser);
		p.ListSrcBtnPanel.add(p.ListSrcBtn_appendUser);
		p.ListSrcBtn_appendUser.setNextBeans(p.ListSrcBtn_appendEnd);
		p.ListSrcBtnPanel.add(p.ListSrcBtn_appendEnd);
	}

	/**
	 * [ListDestBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDestBtn(FSBAP0640 p) {
		// ブロック関連の初期化
		p.ListDestBtnPanel.setLayoutPosition("W");
		// ブロックの項目の初期化
		p.ListDestBtnPanel.add(p.ListDestBtn_moveToLeft);
		p.ListDestBtnPanel.setLastBeans(p.ListDestBtn_moveToLeft);
	}

	/**
	 * [MoveP]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMoveP(FSBAP0640 p) {
		// ブロック関連の初期化
		p.MovePPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.MovePPanel.add(p.MoveP_menu_move_p_PPanel);
		p.MovePPanel.setLastBeans(p.MoveP_menu_move_p_PPanel);
	}

	/**
	 * [UpdBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitUpdBtn(FSBAP0640 p) {
		// ブロック関連の初期化
		p.add(p.UpdBtnPanel);
		p.UpdBtnPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.UpdBtn_upd.setIcon("REGISTER");
		p.UpdBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.UpdBtnPanel.add(p.UpdBtn_upd);
		p.UpdBtnPanel.setLastBeans(p.UpdBtn_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0640_FW.mcInitCnd((FSBAP0640)this);
		FSBAP0640_FW.mcInitListSrc((FSBAP0640)this);
		FSBAP0640_FW.mcInitListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.mcInitListDest((FSBAP0640)this);
		FSBAP0640_FW.mcInitListDestTbl((FSBAP0640)this);
		FSBAP0640_FW.mcInitListSrcBtn((FSBAP0640)this);
		FSBAP0640_FW.mcInitListDestBtn((FSBAP0640)this);
		FSBAP0640_FW.mcInitMoveP((FSBAP0640)this);
		FSBAP0640_FW.mcInitUpdBtn((FSBAP0640)this);

		// [UPD]ステータスのモードの設定
		FSBAP0640_FW.statusInitUPD_Cnd((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_ListSrc((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_ListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_ListDest((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_ListDestTbl((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_ListSrcBtn((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_ListDestBtn((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_MoveP((FSBAP0640)this);
		FSBAP0640_FW.statusInitUPD_UpdBtn((FSBAP0640)this);

		// [FIX]ステータスのモードの設定
		FSBAP0640_FW.statusInitFIX_Cnd((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_ListSrc((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_ListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_ListDest((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_ListDestTbl((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_ListSrcBtn((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_ListDestBtn((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_MoveP((FSBAP0640)this);
		FSBAP0640_FW.statusInitFIX_UpdBtn((FSBAP0640)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FSBAP0640 p) {
		p.Cnd_module_id.setListListener(p);
		p.Cnd_module_id.addAllListener(p);
		p.Cnd_screen_id.setListListener(p);
		p.Cnd_screen_id.addAllListener(p);
		p.Cnd_componentID.setListListener(p);
		p.Cnd_componentID.addAllListener(p);
		p.Cnd_componentNM.setListListener(p);
		p.Cnd_componentNM.addAllListener(p);
		p.Cnd_reload.addAllListener(p);
		p.Cnd_reload.setAPMethodName("doCnd_reload");
	}

	/**
	 *  [ListSrc]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListSrc(FSBAP0640 p) {
	}

	/**
	 *  [ListSrcTbl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListSrcTbl(FSBAP0640 p) {
		p.ListSrcTblTable.addAllListener(p);
		p.columnListSrcTbl_comp_id.addAllListener(p);
		p.columnListSrcTbl_comp_id.setListListener(p);
		p.columnListSrcTbl_comp_nm.addAllListener(p);
		p.columnListSrcTbl_comp_nm.setListListener(p);
	}

	/**
	 *  [ListDest]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDest(FSBAP0640 p) {
	}

	/**
	 *  [ListDestTbl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDestTbl(FSBAP0640 p) {
		p.ListDestTblTable.addAllListener(p);
		p.columnListDestTbl_comp_id.addAllListener(p);
		p.columnListDestTbl_comp_id.setListListener(p);
		p.columnListDestTbl_comp_nm.addAllListener(p);
		p.columnListDestTbl_comp_nm.setListListener(p);
	}

	/**
	 *  [ListSrcBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListSrcBtn(FSBAP0640 p) {
		p.ListSrcBtn_moveToRight.addAllListener(p);
		p.ListSrcBtn_moveToRight.setAPMethodName("doListSrcBtn_moveToRight");
		p.ListSrcBtn_appendUser.addAllListener(p);
		p.ListSrcBtn_appendUser.setAPMethodName("doListSrcBtn_appendUser");
		p.ListSrcBtn_appendEnd.addAllListener(p);
		p.ListSrcBtn_appendEnd.setAPMethodName("doListSrcBtn_appendEnd");
	}

	/**
	 *  [ListDestBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDestBtn(FSBAP0640 p) {
		p.ListDestBtn_moveToLeft.addAllListener(p);
		p.ListDestBtn_moveToLeft.setAPMethodName("doListDestBtn_moveToLeft");
	}

	/**
	 *  [MoveP]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMoveP(FSBAP0640 p) {
	}

	/**
	 *  [UpdBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitUpdBtn(FSBAP0640 p) {
		p.UpdBtn_upd.addAllListener(p);
		p.UpdBtn_upd.setAPMethodName("doUpdBtn_upd");
	}

	/**
	 * [UPD]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Cnd(FSBAP0640 p){
		p.Cnd_module_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.Cnd_screen_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.Cnd_componentID.putMode(p, UPD, MCMode.READ_ONLY);
		p.Cnd_componentNM.putMode(p, UPD, MCMode.READ_ONLY);
		p.Cnd_reload.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[ListSrc]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListSrc(FSBAP0640 p){

	}

	/**
	 * [UPD]ステータスの[ListSrcTbl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListSrcTbl(FSBAP0640 p){
		p.columnListSrcTbl_comp_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnListSrcTbl_comp_nm.putMode(p, UPD, MCMode.READ_ONLY);

	}

	/**
	 * [UPD]ステータスの[ListDest]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListDest(FSBAP0640 p){

	}

	/**
	 * [UPD]ステータスの[ListDestTbl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListDestTbl(FSBAP0640 p){
		p.columnListDestTbl_comp_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnListDestTbl_comp_nm.putMode(p, UPD, MCMode.READ_ONLY);

	}

	/**
	 * [UPD]ステータスの[ListSrcBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListSrcBtn(FSBAP0640 p){
		p.ListSrcBtn_moveToRight.putMode(p, UPD, MCMode.ENABLE);
		p.ListSrcBtn_appendUser.putMode(p, UPD, MCMode.ENABLE);
		p.ListSrcBtn_appendEnd.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[ListDestBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListDestBtn(FSBAP0640 p){
		p.ListDestBtn_moveToLeft.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[MoveP]ブロックのモードの設定
	 */
	protected static void statusInitUPD_MoveP(FSBAP0640 p){
		p.MoveP_menu_move_p_PPanel.putStatus(UPD, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.ENABLE);

	}

	/**
	 * [UPD]ステータスの[UpdBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_UpdBtn(FSBAP0640 p){
		p.UpdBtn_upd.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Cnd(FSBAP0640 p){
		p.Cnd_module_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.Cnd_screen_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.Cnd_componentID.putMode(p, FIX, MCMode.READ_ONLY);
		p.Cnd_componentNM.putMode(p, FIX, MCMode.READ_ONLY);
		p.Cnd_reload.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[ListSrc]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListSrc(FSBAP0640 p){

	}

	/**
	 * [FIX]ステータスの[ListSrcTbl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListSrcTbl(FSBAP0640 p){
		p.columnListSrcTbl_comp_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnListSrcTbl_comp_nm.putMode(p, FIX, MCMode.READ_ONLY);

	}

	/**
	 * [FIX]ステータスの[ListDest]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListDest(FSBAP0640 p){

	}

	/**
	 * [FIX]ステータスの[ListDestTbl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListDestTbl(FSBAP0640 p){
		p.columnListDestTbl_comp_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnListDestTbl_comp_nm.putMode(p, FIX, MCMode.READ_ONLY);

	}

	/**
	 * [FIX]ステータスの[ListSrcBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListSrcBtn(FSBAP0640 p){
		p.ListSrcBtn_moveToRight.putMode(p, FIX, MCMode.ENABLE);
		p.ListSrcBtn_appendUser.putMode(p, FIX, MCMode.ENABLE);
		p.ListSrcBtn_appendEnd.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[ListDestBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListDestBtn(FSBAP0640 p){
		p.ListDestBtn_moveToLeft.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[MoveP]ブロックのモードの設定
	 */
	protected static void statusInitFIX_MoveP(FSBAP0640 p){
		p.MoveP_menu_move_p_PPanel.putStatus(FIX, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.ENABLE);

	}

	/**
	 * [FIX]ステータスの[UpdBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_UpdBtn(FSBAP0640 p){
		p.UpdBtn_upd.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return UPD;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0640_FW.setTableConfigListSrcTbl((FSBAP0640)this);
		FSBAP0640_FW.setTableConfigListDestTbl((FSBAP0640)this);
	}

	/**
	 * [ListSrcTbl]ブロックのTableの設定
	 */
	protected static void setTableConfigListSrcTbl(FSBAP0640 p) {
		p.columnListSrcTbl_comp_id.setMeta(mcframe.clientFSBA.FSBAP0640.ListSrcTblR.comp_id_META);
		p.ListSrcTblTable.addColumnConfig(p.columnListSrcTbl_comp_id);
		p.columnListSrcTbl_comp_nm.setMeta(mcframe.clientFSBA.FSBAP0640.ListSrcTblR.comp_nm_META);
		p.ListSrcTblTable.addColumnConfig(p.columnListSrcTbl_comp_nm);
	}

	/**
	 * [ListDestTbl]ブロックのTableの設定
	 */
	protected static void setTableConfigListDestTbl(FSBAP0640 p) {
		p.columnListDestTbl_comp_id.setMeta(mcframe.clientFSBA.FSBAP0640.ListDestTblR.comp_id_META);
		p.ListDestTblTable.addColumnConfig(p.columnListDestTbl_comp_id);
		p.columnListDestTbl_comp_nm.setMeta(mcframe.clientFSBA.FSBAP0640.ListDestTblR.comp_nm_META);
		p.ListDestTblTable.addColumnConfig(p.columnListDestTbl_comp_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[UPD]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setUPDStatus() {
		status = UPD;
		setAllStatus(status);
	}

	/**
	 * この画面を[FIX]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setFIXStatus() {
		status = FIX;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (UPD.equals(status)) {
			setUPDStatus();
		}
		else if (FIX.equals(status)) {
			setFIXStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Cnd_reload) doCnd_reload(info);
		else if (ap == ListSrcBtn_moveToRight) doListSrcBtn_moveToRight(info);
		else if (ap == ListSrcBtn_appendUser) doListSrcBtn_appendUser(info);
		else if (ap == ListSrcBtn_appendEnd) doListSrcBtn_appendEnd(info);
		else if (ap == ListDestBtn_moveToLeft) doListDestBtn_moveToLeft(info);
		else if (ap == UpdBtn_upd) doUpdBtn_upd(info);
	}

	/**
	 * [Cnd]パネルの[reload]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCnd_reload(MCEventInfo info);

	/**
	 * [ListSrcBtn]パネルの[moveToRight]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListSrcBtn_moveToRight(MCEventInfo info);

	/**
	 * [ListSrcBtn]パネルの[appendUser]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListSrcBtn_appendUser(MCEventInfo info);

	/**
	 * [ListSrcBtn]パネルの[appendEnd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListSrcBtn_appendEnd(MCEventInfo info);

	/**
	 * [ListDestBtn]パネルの[moveToLeft]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDestBtn_moveToLeft(MCEventInfo info);

	/**
	 * [UpdBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doUpdBtn_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListSrcTblTable) return doListSrcTbl_VC(info);
		if (vc == ListDestTblTable) return doListDestTbl_VC(info);
		if (vc == Cnd_module_id) return doCnd_module_id_VC(info);
		if (vc == Cnd_screen_id) return doCnd_screen_id_VC(info);
		if (vc == Cnd_componentID) return doCnd_componentID_VC(info);
		if (vc == Cnd_componentNM) return doCnd_componentNM_VC(info);
		if (vc == columnListSrcTbl_comp_id) return doListSrcTbl_comp_id_VC(info);
		if (vc == columnListSrcTbl_comp_nm) return doListSrcTbl_comp_nm_VC(info);
		if (vc == columnListDestTbl_comp_id) return doListDestTbl_comp_id_VC(info);
		if (vc == columnListDestTbl_comp_nm) return doListDestTbl_comp_nm_VC(info);
		return true;
	}

	/**
	 * [ListSrcTbl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListSrcTbl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDestTbl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDestTbl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[module_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_module_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[componentID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_componentID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[componentNM]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_componentNM_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListSrcTbl]パネルの[comp_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListSrcTbl_comp_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListSrcTbl]パネルの[comp_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListSrcTbl_comp_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDestTbl]パネルの[comp_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDestTbl_comp_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDestTbl]パネルの[comp_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDestTbl_comp_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListSrcTblTable) doListSrcTbl_NC(info);
		else if (nc == ListDestTblTable) doListDestTbl_NC(info);
		else if (nc == Cnd_module_id) doCnd_module_id_NC(info);
		else if (nc == Cnd_screen_id) doCnd_screen_id_NC(info);
		else if (nc == Cnd_componentID) doCnd_componentID_NC(info);
		else if (nc == Cnd_componentNM) doCnd_componentNM_NC(info);
		else if (nc == columnListSrcTbl_comp_id) doListSrcTbl_comp_id_NC(info);
		else if (nc == columnListSrcTbl_comp_nm) doListSrcTbl_comp_nm_NC(info);
		else if (nc == columnListDestTbl_comp_id) doListDestTbl_comp_id_NC(info);
		else if (nc == columnListDestTbl_comp_nm) doListDestTbl_comp_nm_NC(info);
	}

	/**
	 * [ListSrcTbl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_NC(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[module_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentID_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentNM]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentNM_NC(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_id_NC(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListSrcTblTable) doListSrcTbl_NE(info);
		else if (ne == ListDestTblTable) doListDestTbl_NE(info);
		else if (ne == Cnd_module_id) doCnd_module_id_NE(info);
		else if (ne == Cnd_screen_id) doCnd_screen_id_NE(info);
		else if (ne == Cnd_componentID) doCnd_componentID_NE(info);
		else if (ne == Cnd_componentNM) doCnd_componentNM_NE(info);
		else if (ne == columnListSrcTbl_comp_id) doListSrcTbl_comp_id_NE(info);
		else if (ne == columnListSrcTbl_comp_nm) doListSrcTbl_comp_nm_NE(info);
		else if (ne == columnListDestTbl_comp_id) doListDestTbl_comp_id_NE(info);
		else if (ne == columnListDestTbl_comp_nm) doListDestTbl_comp_nm_NE(info);
	}

	/**
	 * [ListSrcTbl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_NE(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[module_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentID_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentNM]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentNM_NE(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_id_NE(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListSrcTblTable) doListSrcTbl_NX(info);
		else if (nx == ListDestTblTable) doListDestTbl_NX(info);
		else if (nx == Cnd_module_id) doCnd_module_id_NX(info);
		else if (nx == Cnd_screen_id) doCnd_screen_id_NX(info);
		else if (nx == Cnd_componentID) doCnd_componentID_NX(info);
		else if (nx == Cnd_componentNM) doCnd_componentNM_NX(info);
		else if (nx == columnListSrcTbl_comp_id) doListSrcTbl_comp_id_NX(info);
		else if (nx == columnListSrcTbl_comp_nm) doListSrcTbl_comp_nm_NX(info);
		else if (nx == columnListDestTbl_comp_id) doListDestTbl_comp_id_NX(info);
		else if (nx == columnListDestTbl_comp_nm) doListDestTbl_comp_nm_NX(info);
	}

	/**
	 * [ListSrcTbl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_NX(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[module_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentID_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentNM]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentNM_NX(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_id_NX(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_module_id) doCnd_module_id_LC(info);
		else if (lc == Cnd_screen_id) doCnd_screen_id_LC(info);
		else if (lc == Cnd_componentID) doCnd_componentID_LC(info);
		else if (lc == Cnd_componentNM) doCnd_componentNM_LC(info);
		else if (lc == columnListSrcTbl_comp_id) doListSrcTbl_comp_id_LC(info);
		else if (lc == columnListSrcTbl_comp_nm) doListSrcTbl_comp_nm_LC(info);
		else if (lc == columnListDestTbl_comp_id) doListDestTbl_comp_id_LC(info);
		else if (lc == columnListDestTbl_comp_nm) doListDestTbl_comp_nm_LC(info);
	}

	/**
	 * [Cnd]パネルの[module_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentID_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[componentNM]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_componentNM_LC(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_id_LC(MCEventInfo info){
	}

	/**
	 * [ListSrcTbl]パネルの[comp_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListSrcTbl_comp_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDestTbl]パネルの[comp_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDestTbl_comp_nm_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}