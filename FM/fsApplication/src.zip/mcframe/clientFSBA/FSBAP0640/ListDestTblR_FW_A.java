package mcframe.clientFSBA.FSBAP0640;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ListDestTbl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListDestTblR_FW_A extends MCConstRow {

	/**
	 *  画面部品.<p>
	 *
	 */
	public static final String $comp_id = "comp_id";
	/**
	 *  画面部品名.<p>
	 *
	 */
	public static final String $comp_nm = "comp_nm";
	public static final String $btn_flg = "btn_flg";
	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public static final String $panel_id = "panel_id";
	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public static final String $root_panel_id = "root_panel_id";


	public static final MCMeta comp_id_META = createStringMeta($comp_id);
	public static final MCMeta comp_nm_META = createStringMeta($comp_nm);
	public static final MCMeta btn_flg_META = createCommonMeta($btn_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta panel_id_META = createCommonMeta($panel_id, mcframe.commonCore.meta.M_META.PANEL_ID);
	public static final MCMeta root_panel_id_META = createCommonMeta($root_panel_id, mcframe.commonCore.meta.M_META.PANEL_ID);

	protected static final ConstMetaList<ListDestTblR> constMetas = new ConstMetaList<ListDestTblR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			comp_id_META,
			comp_nm_META,
			btn_flg_META,
			panel_id_META,
			root_panel_id_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListDestTblR_FW_A(ConstMetaList<? extends ListDestTblR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDestTblR clone() {
		return (ListDestTblR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDestTblR createInstance() {
		return (ListDestTblR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDestTblR getValues(String... names) {
		return (ListDestTblR) super.getValues(names);
	}



	/**
	 *  画面部品.<p>
	 *
	 */
	public String comp_id() {
		return getConstString(offset + 0, $comp_id);
	}

	/**
	 *  画面部品.<p>
	 *
	 */
	public void comp_id(String value) {
		setConstString(offset + 0, $comp_id, value);
	}


	/**
	 *  画面部品名.<p>
	 *
	 */
	public String comp_nm() {
		return getConstString(offset + 1, $comp_nm);
	}

	/**
	 *  画面部品名.<p>
	 *
	 */
	public void comp_nm(String value) {
		setConstString(offset + 1, $comp_nm, value);
	}


	public boolean btn_flg() {
		return getConstBoolean(offset + 2, $btn_flg);
	}

	public void btn_flg(boolean value) {
		setConstBoolean(offset + 2, $btn_flg, value);
	}


	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public String panel_id() {
		return getConstString(offset + 3, $panel_id);
	}

	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public void panel_id(String value) {
		setConstString(offset + 3, $panel_id, value);
	}


	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public String root_panel_id() {
		return getConstString(offset + 4, $root_panel_id);
	}

	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public void root_panel_id(String value) {
		setConstString(offset + 4, $root_panel_id, value);
	}


	public String getString(String name) {
		if ($comp_id.equalsIgnoreCase(name)) {
			return comp_id();
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			return comp_nm();
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			return panel_id();
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			return root_panel_id();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			return btn_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($comp_id.equalsIgnoreCase(name)) {
			return comp_id();
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			return comp_nm();
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			return panel_id();
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			return root_panel_id();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			return btn_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($comp_id.equalsIgnoreCase(name)) {
			comp_id(value);
			return;
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			comp_nm(value);
			return;
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			panel_id(value);
			return;
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			root_panel_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			btn_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($comp_id.equalsIgnoreCase(name)) {
			comp_id(value);
			return;
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			comp_nm(value);
			return;
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			panel_id(value);
			return;
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			root_panel_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			btn_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

