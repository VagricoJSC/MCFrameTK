package mcframe.clientFSBA.FSBAP0640;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cnd"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CndR_FW_A extends MCConstRow {

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $module_id = "module_id";
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public static final String $screen_id = "screen_id";
	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public static final String $componentID = "componentID";
	/**
	 *  画面部品名.<p>
	 *
	 */
	public static final String $componentNM = "componentNM";


	public static final MCMeta module_id_META = createCommonMeta($module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta screen_id_META = createCommonMeta($screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta componentID_META = createStringMeta($componentID, 20);
	public static final MCMeta componentNM_META = createStringMeta($componentNM, 20);

	protected static final ConstMetaList<CndR> constMetas = new ConstMetaList<CndR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			module_id_META,
			screen_id_META,
			componentID_META,
			componentNM_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CndR_FW_A(ConstMetaList<? extends CndR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR clone() {
		return (CndR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR createInstance() {
		return (CndR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR getValues(String... names) {
		return (CndR) super.getValues(names);
	}



	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String module_id() {
		return getConstString(offset + 0, $module_id);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void module_id(String value) {
		setConstString(offset + 0, $module_id, value);
	}


	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public String screen_id() {
		return getConstString(offset + 1, $screen_id);
	}

	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public void screen_id(String value) {
		setConstString(offset + 1, $screen_id, value);
	}


	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public String componentID() {
		return getConstString(offset + 2, $componentID);
	}

	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public void componentID(String value) {
		setConstString(offset + 2, $componentID, value);
	}


	/**
	 *  画面部品名.<p>
	 *
	 */
	public String componentNM() {
		return getConstString(offset + 3, $componentNM);
	}

	/**
	 *  画面部品名.<p>
	 *
	 */
	public void componentNM(String value) {
		setConstString(offset + 3, $componentNM, value);
	}


	public String getString(String name) {
		if ($module_id.equalsIgnoreCase(name)) {
			return module_id();
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			return screen_id();
		}
		if ($componentID.equalsIgnoreCase(name)) {
			return componentID();
		}
		if ($componentNM.equalsIgnoreCase(name)) {
			return componentNM();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($module_id.equalsIgnoreCase(name)) {
			return module_id();
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			return screen_id();
		}
		if ($componentID.equalsIgnoreCase(name)) {
			return componentID();
		}
		if ($componentNM.equalsIgnoreCase(name)) {
			return componentNM();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($module_id.equalsIgnoreCase(name)) {
			module_id(value);
			return;
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			screen_id(value);
			return;
		}
		if ($componentID.equalsIgnoreCase(name)) {
			componentID(value);
			return;
		}
		if ($componentNM.equalsIgnoreCase(name)) {
			componentNM(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($module_id.equalsIgnoreCase(name)) {
			module_id(value);
			return;
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			screen_id(value);
			return;
		}
		if ($componentID.equalsIgnoreCase(name)) {
			componentID(value);
			return;
		}
		if ($componentNM.equalsIgnoreCase(name)) {
			componentNM(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

