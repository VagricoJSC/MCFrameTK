package mcframe.clientFSBA.FSBAP0800;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoDtlR_FW_A extends mcframe.clientFSBA.FSBAP0110.InfoDtlR {

	/**
	 *  フォーカス有.<p>
	 *
	 */
	public static final String $focus_flg = "focus_flg";
	/**
	 *  桁数.<p>
	 *
	 */
	public static final String $column_size = "column_size";


	public static final MCMeta focus_flg_META = createCommonMeta($focus_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta column_size_META = createNumberMeta($column_size);

	protected static final ConstMetaList<InfoDtlR> constMetas = new ConstMetaList<InfoDtlR>(
		mcframe.clientFSBA.FSBAP0110.InfoDtlR.constMetas,
		new MCMeta[]{
			focus_flg_META,
			column_size_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		mcframe.clientFSBA.FSBAP0110.InfoDtlR.KEYS,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		mcframe.clientFSBA.FSBAP0110.InfoDtlR.EXTMAP
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoDtlR_FW_A(ConstMetaList<? extends InfoDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR clone() {
		return (InfoDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR createInstance() {
		return (InfoDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR getValues(String... names) {
		return (InfoDtlR) super.getValues(names);
	}



	/**
	 *  フォーカス有.<p>
	 *
	 */
	public boolean focus_flg() {
		return getConstBoolean(offset + 0, $focus_flg);
	}

	/**
	 *  フォーカス有.<p>
	 *
	 */
	public void focus_flg(boolean value) {
		setConstBoolean(offset + 0, $focus_flg, value);
	}


	/**
	 *  桁数.<p>
	 *
	 */
	public MCNumber column_size() {
		return getConstNumber(offset + 1, $column_size);
	}

	/**
	 *  桁数.<p>
	 *
	 */
	public void column_size(MCNumber value) {
		setConstNumber(offset + 1, $column_size, value);
	}

	/**
	 *  桁数.<p>
	 *
	 */
	public void column_size(int value) {
		setConstNumber(offset + 1, $column_size, value);
	}

	/**
	 *  桁数.<p>
	 *
	 */
	public void column_size(long value) {
		setConstNumber(offset + 1, $column_size, value);
	}

	/**
	 *  桁数.<p>
	 *
	 */
	public void column_size(float value) {
		setConstNumber(offset + 1, $column_size, value);
	}

	/**
	 *  桁数.<p>
	 *
	 */
	public void column_size(double value) {
		setConstNumber(offset + 1, $column_size, value);
	}


	public MCNumber getNumber(String name) {
		if ($column_size.equalsIgnoreCase(name)) {
			return column_size();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($focus_flg.equalsIgnoreCase(name)) {
			return focus_flg();
		}
		return super.getBoolean(name);
	}

	public MCNumber getNumberNE(String name) {
		if ($column_size.equalsIgnoreCase(name)) {
			return column_size();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($focus_flg.equalsIgnoreCase(name)) {
			return focus_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setNumber(String name, MCNumber value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($focus_flg.equalsIgnoreCase(name)) {
			focus_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setNumberNE(String name, MCNumber value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($column_size.equalsIgnoreCase(name)) {
			column_size(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($focus_flg.equalsIgnoreCase(name)) {
			focus_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

