package mcframe.clientFSBA.FSBAP0740;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0750.*;
import mcframe.clientFSUB.FSUBP0170.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

import mcframe.clientCore.acl.MCACLManager;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.resource.MCRowFilterData;
import mcframe.clientCore.beans.resource.MCRowSignalInfo;
import mcframe.clientCore.beans.resource.MCRowSignalResourceIO;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import java.util.HashMap;
import java.util.Map;
import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0750.InfoDtlR;
import mcframe.clientCore.beans.table.MCRowSignal;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_RowSignal"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_RowSignal_FW extends FSBAP_RowSignal_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 設定対象のテーブルです。
	 */
	protected MCTable<?> _target_table = null;

	/**
	 * シグナルごとの一覧部品です。
	 */
	protected Map<Integer, FSBAP_RowSignalParts> _condPartsMap = new HashMap<>();

	/**
	 * シグナル条件のリストです。
	 */
	protected List<MCRowFilter> conds = new ArrayList<>();

	/**
	 * シグナルの定数配列です。
	 */
	protected int[] signal = new int[] {
			MCRowSignal.SAFETY,
			MCRowSignal.CAUTION,
			MCRowSignal.DANGER
	};

	/**
	 * 登録時のメッセージを格納するためのリストです。
	 */
	protected MCMessageList _message_list = new MCMessageList();

	/**
	 * 設定情報ＩＤのシーケンス番号のマップです。
	 */
	protected Map<String, Integer> _setting_info_no_map = null;

//	FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_RowSignal_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_RowSignal_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * 登録処理の実行可否を判断します。<p>
	 * 登録処理を続行する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	@Override
	protected boolean checkForUpd() {
		if (!super.checkForUpd()) {
			return false;
		}

		MCMessageList m = new MCMessageList();
		_condPartsMap.values().stream().forEach(parts -> m.addAll(parts.checkForUpd()));

		if (m.size() > 0) {
			message(m);
			return false;
		}
		return true;
	}

	@Override
	public MCList<ListDtlR> getListDtlL() {
		return super.getListDtlL();
	}

	/**
	 * 適用処理の実行可否を判断します。<p>
	 * 適用処理を続行する場合は true を返します。
	 *
	 * @return 適用処理を中断する場合は false
	 */
	@Override
	protected boolean checkForApply() {
		if (!super.checkForApply()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		MCList<InfoDtlR> l = null;
		for (int sig : signal) {
			l = exceptEmpty(_condPartsMap.get(sig).getInfoDtlL());
		}

		// シグナルの必須項目をチェックする
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			ListDtlR o = ListDtlTable.getSelectedMCRow();
			setInitListData(o);
			setInitInfoData(o);
		}

		return true;
	}

	/**
	 * 登録処理の後処理を実行します。
	 */
	@Override
	protected void afterUpd() {
		super.afterUpd();

		getTargetTable()._setRowSignalInfoList(null);
	}

	/**
	 * 登録処理の完了メッセージを表示します。
	 */
	@Override
	protected void showUpdEndMsg() {
		dialog(FXBAP0021);
	}

	/**
	 * 適用処理を実行します。
	 */
	@Override
	protected void doApply() {
		super.doApply();

		if (_message_list.size() > 0) {
			MCMessageList l = _message_list;
			sortMessageList(l);
			MCMessageBox.message(this, MCFrameType.SYSTEM_MODAL, null, l);
		}
	}

	/**
	 * Panel[ListDtlBtn]のボタン[rcopy]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_rcopy(MCEventInfo info) {
		super.doListDtlBtn_rcopy(info);
		_condPartsMap.values().stream().forEach(parts -> parts.setStatus(EDIT));
		setEDITStatus();
	}

	@Override
	protected void afterCopyRow() {
		super.afterCopyRow();

		for (int sig : signal) {
			for (InfoDtlR o : _condPartsMap.get(sig).getInfoDtlL()) {
				if (!o.isEmpty()) {
					o.setStatus(MCRow.CREATE);
				}
			}
		}

		getListHdrR().init_flg(false);
		getListHdrR().setting_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		getListHdrR().setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(getListHdrR(), 
				ListDtlR.$setting_unit_type, 
				ListDtlR.$setting_unit_type_nm);

		setStatus(EDIT);
	}

	/**
	 * 設定情報をリソースに保存します。
	 */
	@Override
	protected void writeResource() {
		// 既存データを削除する
//		removeResource(false);

		// 汎用テーブル編集以外の場合、既存データを削除する
		if (!isTargetGeneralTable()) {
			removeResource(false);
		}

		MCTable<?> tbl = getTargetTable();
		String pfx = tbl.getPersonalizedKeyPrefix(ROW_SIGNAL_PANEL, null);

		MCRowSignalResourceIO sio = new MCRowSignalResourceIO();

		ListDtlR sr = ListDtlTable.getSelectedMCRow();

		String u = getSettingR().setting_unit();
		_setting_info_no_map = sio.readSettingInfoNOMap(pfx);

		Integer no = _setting_info_no_map.get(u);
		if (no == null) {
			no = Math.max(getMaxSettingInfoNO(), 0);
		}

		for (ListDtlR o : getListDtlL()) {
			if (o.isEmpty() || (o.isStatusDelete() && !isTargetGeneralTable())) {
				continue;
			}

			ListDtlR c1;
			Map<Integer, MCList<InfoDtlR>> c2 = new HashMap<Integer, MCList<InfoDtlR>>();
			String y = o.setting_unit_type();

			// 選択行ではない場合
			if (sr != o) {
				if (!u.equals(y)) {
					continue;
				}

				FSBAP_RowSignalInfo si = getSettingInfo(o);
				if (si == null) {
					continue;
				}

				c1 = si.getSettingInfo().clone();
				c1.init_flg(o.init_flg());
				c2 = si.getRowSignalMap();
			}
			// 選択行の場合
			else {
				if (isNull(y)) {
					o.setting_unit_type(u);
					FXC_RESOURCE_SETTING_UNIT.putNameNE(o, ListDtlR.$setting_unit_type,
							ListDtlR.$setting_unit_type_nm);
					y = o.setting_unit_type();
				}

				if (!u.equals(y)) {
					continue;
				}
				c1 = createListDtlR();
				MCList<InfoDtlR> c3;
				c1.setValues(ListDtlR.colnames(), getListHdrR(), ListDtlR.colnames());
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				c1.setting_info_nm(o.setting_info_nm());

				for (int sig : signal) {
					MCList<InfoDtlR> c4 = _condPartsMap.get(sig).createInfoDtlL();
					c3 = _condPartsMap.get(sig).getInfoDtlL();
					for (InfoDtlR d : c3) {
						if (d.isEmpty() || d.isStatusDelete()) {
							continue;
						}
						InfoDtlR s = c3.createRow();
						s.setValues(InfoDtlR.colnames(), d, InfoDtlR.colnames());
						c4.add(s);
					}
					c2.put(sig, c4);
				}


				// 汎用テーブル編集の場合
				if (isTargetGeneralTable()) {
					String id = c1.setting_info_id();
					// 新規の場合
					if (isNull(id)) {
						c1.setting_info_id(sio.createSettingInfoID(c1.setting_unit_type(), no++));
						removeResourceById(false, null);
					}
					// 更新または削除の場合、対象のIDのみを削除する
					else {
						removeResourceById(false, id);
					}
					// 削除の場合は追加しない
					if (!sr.isStatusDelete()) {
						MCRowSignalInfo si = MCRowSignalInfo.create();
						
						si.setSettingUnitType(c1.setting_unit_type());
						si.setInitFlg(c1.init_flg());
						si.setSettingInfoID(c1.setting_info_id());
						si.setSettingInfoName(c1.setting_info_nm());
						si.setRemark(c1.remark());
			
						for (int sig : signal) {
							List<MCRowFilterData> dl = new ArrayList<MCRowFilterData>();
							if (c2.get(sig) == null) {
								continue;
							}
			
							for (InfoDtlR t : c2.get(sig)) {
								if (t.isEmpty() || t.isStatusDelete()) {
									continue;
								}
			
								MCDataType dy = MCDataType.valueOf(t.data_type());
								Comparable<?> v = _condPartsMap.get(sig)
										.getConditionValue(t.cond_p());
			
								MCRowFilter s = new MCRowFilter();
								s.setDisable(t.disable());
								s.setConditionNoCheck(t.column_key(), dy, v, t.relative_type(),
										t.logic_type());
			
								MCRowFilterData d = tbl.toRowSignalData(s);
								if (d != null) {
									dl.add(d);
								}
							}
							si.setConditionList(sig, dl);
						}
						sio.addInfo(si);
					}
				}
				
			}
			// 汎用テーブル編集以外の場合
			if (!isTargetGeneralTable()) {
				MCRowSignalInfo si = MCRowSignalInfo.create();
	
				String id = c1.setting_info_id();
				if (isNull(id)) {
					c1.setting_info_id(sio.createSettingInfoID(c1.setting_unit_type(), no++));
				}
				si.setSettingUnitType(c1.setting_unit_type());
				si.setInitFlg(c1.init_flg());
				si.setSettingInfoID(c1.setting_info_id());
				si.setSettingInfoName(c1.setting_info_nm());
				si.setRemark(c1.remark());
	
				for (int sig : signal) {
					List<MCRowFilterData> dl = new ArrayList<MCRowFilterData>();
					if (c2.get(sig) == null) {
						continue;
					}
	
					for (InfoDtlR t : c2.get(sig)) {
						if (t.isEmpty() || t.isStatusDelete()) {
							continue;
						}
	
						MCDataType dy = MCDataType.valueOf(t.data_type());
						Comparable<?> v = _condPartsMap.get(sig)
								.getConditionValue(t.cond_p());
	
						MCRowFilter s = new MCRowFilter();
						s.setDisable(t.disable());
						s.setConditionNoCheck(t.column_key(), dy, v, t.relative_type(),
								t.logic_type());
	
						MCRowFilterData d = tbl.toRowSignalData(s);
						if (d != null) {
							dl.add(d);
						}
					}
					si.setConditionList(sig, dl);
				}
				sio.addInfo(si);
			}
		}

		boolean isNotEmpty = sio.getInfoList().size() > 0 ? true : false;
		if (isNotEmpty) {
			Map<String, Integer> m = new HashMap<String, Integer>();
			m.put(u, no);
			sio.writeNoSave(pfx, m);
		}
		MCRowSignalResourceIO.saveResource();
	}

	/**
	 * 設定対象の画面の情報を更新します。
	 *
	 */
	@Override
	protected void updateTargetPanel() {

		ListDtlR s = ListDtlTable.getSelectedMCRow();
		MCTable<?> t = getTargetTable();

		for (MCRowSignalInfo i : t.getRowSignalInfoList()) {
			if (isSame(s.setting_unit_type(), i.getSettingUnitType())
					&& isSame(s.setting_info_id(), i.getSettingInfoID())) {
				t._applyRowSignalInfo(i);
				break;
			}
		}
	}

	/**
	 * 対象のテーブルを設定します。
	 *
	 * @param table 対象のテーブル
	 */
	protected void setTargetTable(MCTable<?> table) {
		_target_table = table;

		_condPartsMap.entrySet().stream().forEach(
				entry -> entry.getValue().setTargetTable(_target_table, entry.getKey()));
	}

	/**
	 * 設定対象のテーブルを返します。<p>
	 * 設定対象のテーブルが設定されていない場合は null を返します。
	 *
	 * @return 設定対象のテーブル、または null
	 */
	protected MCTable<?> getTargetTable() {
		return _target_table;
	}

	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * 設定対象のテーブルを指定してください。
	 * </li>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0048] 引数の指定に誤りがあった場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ]
	 * 起動タイプに {@link T1} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			Object o = args[0];
			if (o == null || !(o instanceof MCTable<?>)) {
				throw new MCAppException(FSBAC0049);
			}

			setTargetTable((MCTable<?>) o);
			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}

	}

	@Override
	public void layoutInit() {
		super.layoutInit();

		DangerPanel.removeAll();
		DangerPanel.setLayout(new BorderLayout());
		DangerPanel.add(Danger_cond_PPanel, BorderLayout.CENTER);

		CautionPanel.removeAll();
		CautionPanel.setLayout(new BorderLayout());
		CautionPanel.add(Caution_cond_PPanel, BorderLayout.CENTER);

		SafetyPanel.removeAll();
		SafetyPanel.setLayout(new BorderLayout());
		SafetyPanel.add(Safety_cond_PPanel, BorderLayout.CENTER);
	}

	@Override
	protected void partsInit() {
		super.partsInit();

		_condPartsMap.put(MCRowSignal.DANGER, Danger_cond_PPanel);
		_condPartsMap.put(MCRowSignal.CAUTION, Caution_cond_PPanel);
		_condPartsMap.put(MCRowSignal.SAFETY, Safety_cond_PPanel);

		TabTab.setMCIconAt(TabTab.indexOfComponent(DangerPanel),
				MCRowSignal.geIcon(MCRowSignal.DANGER));
		TabTab.setMCIconAt(TabTab.indexOfComponent(CautionPanel),
				MCRowSignal.geIcon(MCRowSignal.CAUTION));
		TabTab.setMCIconAt(TabTab.indexOfComponent(SafetyPanel),
				MCRowSignal.geIcon(MCRowSignal.SAFETY));
	}

	@Override
	protected void tableInit() {
		super.tableInit();
		_condPartsMap.values().stream().forEach(parts -> parts.tableInit());
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		_condPartsMap.values().stream().forEach(parts -> parts.fillSpaceForOpen());
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	public void setEDITStatus() {
		if (ListBtn_upd.authorize()) {
			// 編集権限あり
			super.setEDITStatus();
		}
		else {
			// 編集権限なし
			setDISABLEStatus();
		}
	}

	/**
	 * 編集権限がある場合 true を返します。
	 *
	 * @return 編集権限がない場合 false
	 */
	protected boolean checkACL() {
		MCRootPanel p = getBaseRootPanel().getParentPanel();
		if (p == null) {
			p = this;
		}
		String mid = p.getModuleID();
		String sid = p.getScreenID();

		// ACタイプ取得
		String key = MCConst.createKey(MCBeansConsts.TYPE_TABLE, "rowsignal", "type");
		String k = MCConst.actype.findHierarchy(mid, sid, key);
		if (MCStringUtil.isNull(k)) {
			// キーなし＝ACタイプなし > 権限制御不要
			return true;
		}
		if (k.endsWith(".type")) {
			k = k.substring(0, k.length() - 5);
		}
		String actype = MCConst.actype.getType(k);

		return MCACLManager.authorize(mid, sid, actype, getScreenName());
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		setInitData();

		// 更新可能かチャレンジする
		setEDITStatus();
	}

	/**
	 * この画面の情報を初期化します。
	 */
	@Override
	protected void setInitData() {
		super.setInitData();

		getInfoDtlL().clear();
		Safety_cond_PPanel.getInfoDtlL().clear();
		Caution_cond_PPanel.getInfoDtlL().clear();
		Danger_cond_PPanel.getInfoDtlL().clear();

		MCTable<?> t = getTargetTable();

		List<MCRowSignalInfo> l = new ArrayList<MCRowSignalInfo>();

		List<MCRowSignalInfo> sl = new ArrayList<MCRowSignalInfo>();
		List<MCRowSignalInfo> el = new ArrayList<MCRowSignalInfo>();
		List<MCRowSignalInfo> ul = new ArrayList<MCRowSignalInfo>();

		for (MCRowSignalInfo i : t.getRowSignalInfoList()) {
			String y = i.getSettingUnitType();
			if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
				sl.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
				el.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
				ul.add(i);
			}
		}

		String u = getSettingR().setting_unit();
		l.addAll(0, sl);
		if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
			l.addAll(0, el);
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
				l.addAll(0, ul);
			}
		}


		// 設定情報一覧のリスト
		MCList<ListDtlR> il = createListDtlL();

		for (MCRowSignalInfo i : l) {
			FSBAP_RowSignalInfo si = new FSBAP_RowSignalInfo();

			// 設定情報
			ListDtlR lo = il.createRow();

			lo.init_flg(i.getInitFlg());
			lo.setting_unit_type(i.getSettingUnitType());
			FXC_RESOURCE_SETTING_UNIT.putName(lo, ListDtlR.$setting_unit_type,
					ListDtlR.$setting_unit_type_nm);

			lo.setting_info_id(i.getSettingInfoID());
			lo.setting_info_nm(i.getSettingInfoName());
			if (isNull(lo.setting_info_nm())) {
				lo.init_flg(true);
				lo.setting_unit_type_nm(FXC_RESOURCE_SETTING_UNIT.TYPE_EXT.name());
				lo.setting_info_nm("signal");
			}
			lo.remark(i.getRemark());
			il.add(lo);

			si.setSettingInfo(lo.clone());

			//シグナル情報
			for (int sig : signal) {
				List<MCRowFilterData> sdl = i.getConditionList(sig);
				MCList<InfoDtlR> dl = _condPartsMap.get(sig).createInfoDtlL();
				for (MCRowFilterData sd : sdl) {
					MCRowFilter s = t.toRowSignal(sd);
					if (s == null) {
						continue;
					}
					conds.add(s);
					_condPartsMap.get(sig).addConditionRow(dl, conds);
					si.setRowSignalList(sig, dl);
					conds.clear();
				}
			}

			getSettingInfoMap().put(
					MCConst.createKey(i.getSettingUnitType(), i.getSettingInfoID()), si);
		}

		setListDtlL(il);

		ListDtlTable.adjustWidth();
	}

	/**
	 * リソースに保存されている全ての設定情報を削除します。
	 */
	@Override
	protected void removeResource(boolean doSave) {
		MCTable<?> t = getTargetTable();

		MCRowSignalResourceIO sio = new MCRowSignalResourceIO();

		String u = getSettingR().setting_unit();

		String pfx = t.getPersonalizedKeyPrefix(ROW_SIGNAL_PANEL, null);

		Map<String, Integer> m = sio.readSettingInfoNOMap(pfx);

		// リソースを削除する
		MCRowSignalResourceIO.removeNoSave(u, pfx);

		// 設定情報ＩＤのシーケンスを再設定する
		if (m.containsKey(u) && isRemainedAfterDel(u)) {
			Map<String, Integer> nm = new HashMap<String, Integer>();
			nm.put(u, m.get(u));
			sio.writeNoSave(pfx, nm);
		}

		if (doSave) {
			MCRowSignalResourceIO.saveResource();
		}
		t._setRowSignalInfo(null);
		t._setRowSignalInfoList(null);
	}

	/**
	 * リソースに保存されている設定情報から指定したIDのみを削除します。
	 *
	 * @param doSave 保存するかどうかのフラグ
	 * @param setting_info_id 設定情報ID
	 */
	protected void removeResourceById(boolean doSave, String setting_info_id) {
		MCTable<?> t = getTargetTable();
		if (setting_info_id != null) {
			MCRowSignalResourceIO sio = new MCRowSignalResourceIO();
	
			String u = getSettingR().setting_unit();
	
			String pfx = t.getPersonalizedKeyPrefix(ROW_SIGNAL_PANEL, null);
	
			Map<String, Integer> m = sio.readSettingInfoNOMap(pfx);
	
			// リソースを削除する
			MCRowSignalResourceIO.removeNoSaveById(u, pfx, setting_info_id);
			// 初期設定のリソースが引数のIDと一致する場合は削除
			sio.removeInitResourceById(u, pfx, setting_info_id);

			// 設定情報ＩＤのシーケンスを再設定する
			if (m.containsKey(u) && isRemainedAfterDel(u)) {
				Map<String, Integer> nm = new HashMap<String, Integer>();
				nm.put(u, m.get(u));
				sio.writeNoSave(pfx, nm);
			}
	
			if (doSave) {
				MCRowSignalResourceIO.saveResource();
			}
		}
		t._setRowSignalInfo(null);
		t._setRowSignalInfoList(null);
	}

	@Override
	protected void setTargetPanelDefault() {
		MCTable<?> t = getTargetTable();
		t._applyRowSignalInfo(null);
		t._setRowSignalInfoList(null);
	}

	@Override
	protected boolean isInfoDataChanged() {
		if(!Safety_cond_PPanel.getInfoDtlL().isStatusNone()
			|| !Caution_cond_PPanel.getInfoDtlL().isStatusNone()
			|| !Danger_cond_PPanel.getInfoDtlL().isStatusNone()) {
			return true;
		}
		return false;
	}

	@Override
	protected boolean isSearchedProgram(String type, String pgmid) {
		return MCRowSignalResourceIO.isSearchedProgram(type, pgmid);
	}

	@Override
	protected int getSettingInfoNO(ListDtlR data) {
		return MCRowSignalResourceIO.getSettingInfoNO(data.setting_unit_type(),
				data.setting_info_id());
	}

	/**
	 * 削除処理を実行します。
	 */
	@Override
	protected void doDel() {
		// 汎用テーブル編集の場合、ステータスをDELETEにする
		// リソース更新後にリストから対象行を削除する
		if (isTargetGeneralTable()) {
			// 選択中の行を取得
			ListDtlR s = ListDtlTable.getSelectedMCRow();
			if (s != null) {
				s.setStatus(Status.DELETE);
				writeResource();
				getListDtlL().remove(s);
				clearSelection(ListDtlTable);
			}
		}
		// 汎用テーブル編集以外の場合、親クラスのメソッドを呼び出す。
		else {
			super.doDel();
		}
	}

	/**
	 * 対象画面が汎用テーブル編集かどうかを返します。
	 * 
	 * @return 汎用テーブル編集の場合はtrue、それ以外の場合はfalse
	 */
	private boolean isTargetGeneralTable() {
		MCTable<?> t = getTargetTable();
		if (t != null) {
			MCRootPanel p = t.getBaseRootPanel();

			if (p != null && p.isGeneralTable()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 設定情報を格納します。
	 */
	public class FSBAP_RowSignalInfo extends WBP_PersonalizeInfo {

		/**
		 * シグナルのマップです。
		 */
		protected Map<Integer, MCList<InfoDtlR>> _row_signal_map = new HashMap<Integer, MCList<InfoDtlR>>();

		/**
		 * コンストラクタです。
		 */
		public FSBAP_RowSignalInfo() {
		}

		/**
		 * レベル（SAFETY,CAUTION,DANGER）に応じたシグナル条件のリストを設定します。
		 */
		public void setRowSignalList(int i, MCList<InfoDtlR> list) {
			_row_signal_map.put(i, list);
		}

		/**
		 * シグナル条件のマップ返します。
		 *
		 * @param map シグナル条件のマップ
		 */
		public Map<Integer, MCList<InfoDtlR>> getRowSignalMap() {
			return _row_signal_map;
		}

		/**
		 * レベル（SAFETY,CAUTION,DANGER）に応じたシグナル条件のリストを返します。
		 *
		 * @return 指定したレベルのシグナルのリスト
		 */
		public MCList<InfoDtlR> getRowSignalList(int i) {
			return _row_signal_map.get(i);
		}
	}

	@Override
	protected FSBAP_RowSignalInfo getSettingInfo(ListDtlR data) {
		return (FSBAP_RowSignalInfo) super.getSettingInfo(data);
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);
	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);

		ListDtlR o = ListDtlTable.getSelectedMCRow();
		// 行が選択されなかった場合
		if (o == null) {
			_condPartsMap.values().stream().forEach(parts -> parts.getInfoDtlL().clear());
			getListHdrR().clearAll();
			_condPartsMap.values().stream().forEach(parts -> parts.setStatus(INIT));
			return;
		}

		setInitListData(o);
		setInitInfoData(o);

		setStatus(EDIT);
	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!super.doListDtl_VC(info)) {
			return false;
		}

		if (isInfoDataChanged() || !getListHdrR().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			setInitListData(ListDtlTable.getSelectedMCRow());
		}

		return true;
	}

	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);

		FSBAP_RowSignalInfo si = getSettingInfo(data);

		// 登録済みの行が選択された場合
		if (si != null) {
			setListHdrR(si.getSettingInfo());

			for (int sig : signal) {
				MCList<InfoDtlR> l = si.getRowSignalList(sig);
				if (l != null) {
					_condPartsMap.get(sig).setInfoDtlL(l.clone());
				}
				else {
					_condPartsMap.get(sig).setInfoDtlL(null);
				}

				getListHdrR().setStatus(MCRow.NONE);
				getInfoDtlL().setStatus(MCRow.NONE);

				_condPartsMap.get(sig).InfoDtlTable.fillSpace();
				_condPartsMap.get(sig).InfoDtlTable.adjustWidth();
				// adjustWidthでテーブルの横スクロールバーが消える。
				// 横スクロールバーが消えた後に１行分の隙間ができる可能性があるため、
				// 再度fillSpaceを実行する。
				_condPartsMap.get(sig).InfoDtlTable.fillSpace();
			}
			return;
		}

		// 新規行が選択された場合
		getInfoDtlL().clear();
		getListHdrR().clearAll();
		for (int sig : signal) {
			_condPartsMap.get(sig).InfoDtlTable.clear();
			_condPartsMap.get(sig).InfoDtlTable.fillSpace();
			_condPartsMap.get(sig).InfoDtlTable.adjustWidth();
			// adjustWidthでテーブルの横スクロールバーが消える。
			// 横スクロールバーが消えた後に１行分の隙間ができる可能性があるため、
			// 再度fillSpaceを実行する。
			_condPartsMap.get(sig).InfoDtlTable.fillSpace();
		}
	}
}