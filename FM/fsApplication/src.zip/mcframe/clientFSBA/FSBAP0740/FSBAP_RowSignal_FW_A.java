package mcframe.clientFSBA.FSBAP0740;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_RowSignal"パネルクラスです。<p>
 *
 * シグナルの閾値を設定する画面です。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_RowSignal_FW_A extends mcframe.clientFSBA.FSBAP0030.FSBAP_PersonalizeBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0740";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [ListDtlBtn]ブロック関連のField定義
	// [ListDtlBtn]ブロックの項目のField定義
	// [Info]ブロック関連のField定義
	// [Info]ブロックの項目のField定義
	// [Tab]ブロック関連のField定義
	public MCPanel TabPanel = null;
	public MCTabbedPane TabTab = null;
	// [Tab]ブロックの項目のField定義
	// [Danger]ブロック関連のField定義
	public MCPanel DangerPanel = null;
	// [Danger]ブロックの項目のField定義
	public mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts Danger_cond_PPanel;
	// [Caution]ブロック関連のField定義
	public MCPanel CautionPanel = null;
	// [Caution]ブロックの項目のField定義
	public mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts Caution_cond_PPanel;
	// [Safety]ブロック関連のField定義
	public MCPanel SafetyPanel = null;
	// [Safety]ブロックの項目のField定義
	public mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts Safety_cond_PPanel;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};
	
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> aInfoDtlL;

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0750.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0750.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0750.InfoDtlR> createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0750.InfoDtlR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(TabPanel);
		ret.add(DangerPanel);
		ret.add(CautionPanel);
		ret.add(SafetyPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_RowSignal_FW_A() {
		aInfoDtlL = createInfoDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_RowSignal_FW_A(String name) {
		aInfoDtlL = createInfoDtlL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_RowSignal_FW.jbCreateListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbCreateInfo((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbCreateTab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbCreateDanger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbCreateCaution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbCreateSafety((FSBAP_RowSignal)this);
	}

	/**
	 * [ListDtlBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtlBtn(FSBAP_RowSignal p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP_RowSignal p) {
	}

	/**
	 * [Tab]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTab(FSBAP_RowSignal p) {
	}

	/**
	 * [Danger]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDanger(FSBAP_RowSignal p) {
		p.Danger_cond_PPanel = mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.create();
		p.Danger_cond_PPanel.setName("Danger.cond");
	}

	/**
	 * [Caution]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCaution(FSBAP_RowSignal p) {
		p.Caution_cond_PPanel = mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.create();
		p.Caution_cond_PPanel.setName("Caution.cond");
	}

	/**
	 * [Safety]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSafety(FSBAP_RowSignal p) {
		p.Safety_cond_PPanel = mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.create();
		p.Safety_cond_PPanel.setName("Safety.cond");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_RowSignal create(){
		FSBAP_RowSignal p = new FSBAP_RowSignal();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_RowSignal create(String name){
		FSBAP_RowSignal p = new FSBAP_RowSignal(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_RowSignal_FW.jbfInitListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbfInitInfo((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbfInitTab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbfInitDanger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbfInitCaution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbfInitSafety((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbInitListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbInitInfo((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbInitTab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbInitDanger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbInitCaution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.jbInitSafety((FSBAP_RowSignal)this);
	}

	/**
	 * [ListDtlBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtlBtn(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Tab]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTab(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.TabPanel = p.beansFactory.createPanel("Tab");
		p.TabTab = p.beansFactory.createTabbedPane("Tab.tab");
		// ブロックの項目の初期化
	}

	/**
	 * [Danger]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDanger(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.DangerPanel = p.beansFactory.createPanel("Danger");
		// ブロックの項目の初期化
	}

	/**
	 * [Caution]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCaution(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.CautionPanel = p.beansFactory.createPanel("Caution");
		// ブロックの項目の初期化
	}

	/**
	 * [Safety]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSafety(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.SafetyPanel = p.beansFactory.createPanel("Safety");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDtlBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtlBtn(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.InfoPanel.add(p.TabPanel, null);
		p.InfoPanel.setLastBeans(p.TabPanel);
	}

	/**
	 * [Tab]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTab(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.TabPanel.add(p.TabTab);
		p.TabPanel.setLastBeans(p.TabTab);
		p.TabPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.TabTab.add(p.DangerPanel, "Tab.danger");
		p.TabTab.setLastBeans(p.DangerPanel);
		p.DangerPanel.setNextBeans(p.CautionPanel);
		p.TabTab.add(p.CautionPanel, "Tab.caution");
		p.CautionPanel.setNextBeans(p.SafetyPanel);
		p.TabTab.add(p.SafetyPanel, "Tab.safety");
	}

	/**
	 * [Danger]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDanger(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.DangerPanel.setNextBeans(p.CautionPanel);
		p.DangerPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.DangerPanel.add(p.Danger_cond_PPanel);
		p.DangerPanel.setLastBeans(p.Danger_cond_PPanel);
	}

	/**
	 * [Caution]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCaution(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.CautionPanel.setNextBeans(p.SafetyPanel);
		p.CautionPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.CautionPanel.add(p.Caution_cond_PPanel);
		p.CautionPanel.setLastBeans(p.Caution_cond_PPanel);
	}

	/**
	 * [Safety]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSafety(FSBAP_RowSignal p) {
		// ブロック関連の初期化
		p.SafetyPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.SafetyPanel.add(p.Safety_cond_PPanel);
		p.SafetyPanel.setLastBeans(p.Safety_cond_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_RowSignal_FW.mcInitListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.mcInitInfo((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.mcInitTab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.mcInitDanger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.mcInitCaution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.mcInitSafety((FSBAP_RowSignal)this);

		// [INIT]ステータスのモードの設定
		FSBAP_RowSignal_FW.statusInitINIT_ListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitINIT_Info((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitINIT_Tab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitINIT_Danger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitINIT_Caution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitINIT_Safety((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitINIT_InfoDtl((FSBAP_RowSignal)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_RowSignal_FW.statusInitEDIT_ListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitEDIT_Info((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitEDIT_Tab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitEDIT_Danger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitEDIT_Caution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitEDIT_Safety((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitEDIT_InfoDtl((FSBAP_RowSignal)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_RowSignal_FW.statusInitDISABLE_ListDtlBtn((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitDISABLE_Info((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitDISABLE_Tab((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitDISABLE_Danger((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitDISABLE_Caution((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitDISABLE_Safety((FSBAP_RowSignal)this);
		FSBAP_RowSignal_FW.statusInitDISABLE_InfoDtl((FSBAP_RowSignal)this);

	}

	/**
	 *  [ListDtlBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtlBtn(FSBAP_RowSignal p) {
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP_RowSignal p) {
	}

	/**
	 *  [Tab]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTab(FSBAP_RowSignal p) {
		p.TabTab.addAllListener(p);
	}

	/**
	 *  [Danger]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDanger(FSBAP_RowSignal p) {
	}

	/**
	 *  [Caution]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCaution(FSBAP_RowSignal p) {
	}

	/**
	 *  [Safety]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSafety(FSBAP_RowSignal p) {
	}

	/**
	 * [INIT]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListDtlBtn(FSBAP_RowSignal p){
		p.ListDtlBtn_load.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP_RowSignal p){

	}

	/**
	 * [INIT]ステータスの[Tab]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Tab(FSBAP_RowSignal p){

	}

	/**
	 * [INIT]ステータスの[Danger]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Danger(FSBAP_RowSignal p){
		p.Danger_cond_PPanel.putStatus(INIT, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.INIT);

	}

	/**
	 * [INIT]ステータスの[Caution]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Caution(FSBAP_RowSignal p){
		p.Caution_cond_PPanel.putStatus(INIT, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.INIT);

	}

	/**
	 * [INIT]ステータスの[Safety]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Safety(FSBAP_RowSignal p){
		p.Safety_cond_PPanel.putStatus(INIT, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.INIT);

	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP_RowSignal p){

	}

	/**
	 * [EDIT]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListDtlBtn(FSBAP_RowSignal p){
		p.ListDtlBtn_load.putMode(p, EDIT, MCMode.INVISIBLE);

	}

	/**
	 * [EDIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Info(FSBAP_RowSignal p){

	}

	/**
	 * [EDIT]ステータスの[Tab]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Tab(FSBAP_RowSignal p){

	}

	/**
	 * [EDIT]ステータスの[Danger]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Danger(FSBAP_RowSignal p){
		p.Danger_cond_PPanel.putStatus(EDIT, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.EDIT);

	}

	/**
	 * [EDIT]ステータスの[Caution]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Caution(FSBAP_RowSignal p){
		p.Caution_cond_PPanel.putStatus(EDIT, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.EDIT);

	}

	/**
	 * [EDIT]ステータスの[Safety]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Safety(FSBAP_RowSignal p){
		p.Safety_cond_PPanel.putStatus(EDIT, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.EDIT);

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP_RowSignal p){

	}

	/**
	 * [DISABLE]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListDtlBtn(FSBAP_RowSignal p){
		p.ListDtlBtn_load.putMode(p, DISABLE, MCMode.INVISIBLE);

	}

	/**
	 * [DISABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Info(FSBAP_RowSignal p){

	}

	/**
	 * [DISABLE]ステータスの[Tab]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Tab(FSBAP_RowSignal p){

	}

	/**
	 * [DISABLE]ステータスの[Danger]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Danger(FSBAP_RowSignal p){
		p.Danger_cond_PPanel.putStatus(DISABLE, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[Caution]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Caution(FSBAP_RowSignal p){
		p.Caution_cond_PPanel.putStatus(DISABLE, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[Safety]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Safety(FSBAP_RowSignal p){
		p.Safety_cond_PPanel.putStatus(DISABLE, mcframe.clientFSBA.FSBAP0750.FSBAP_RowSignalParts.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP_RowSignal p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == TabTab) return doTab_VC(info);
		return true;
	}

	/**
	 * [Tab]Tabの選択Tabが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTab_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == TabTab) doTab_NC(info);
	}

	/**
	 * [Tab]Tabの選択Tabが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTab_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == TabTab) doTab_NE(info);
	}

	/**
	 * [Tab]TabのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTab_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == TabTab) doTab_NX(info);
	}

	/**
	 * [Tab]TabのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTab_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}