package mcframe.clientFSBA.FSBAP0340;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0340.FSBAP_CommonMemo_FW.FS_FSBAL0150_Srch03Caller;
import mcframe.clientFSBA.FSBAP0340.FSBAP_CommonMemo_FW.FS_FSBAL0150_Upd03Caller;

/**
 * 画面"FSBAP_CommonMemo"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_CommonMemo_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0340";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Menu]ブロック関連のField定義
	public MCPanel MenuPanel = null;
	public MCTitledBorder MenuTitledBorder = null;
	// [Menu]ブロックの項目のField定義
	/**
	 *  タイトル.<p>
	 *
	 */
	public MCTextField Menu_title = null;
	// [MemoList]ブロック関連のField定義
	public MCPanel MemoListPanel = null;
	public MCScrollPane MemoListScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0340.MemoListR> MemoListTable = null;
	// [MemoList]ブロックの項目のField定義
	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public MCColumnConfig columnMemoList_locale_cd = null;
	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public MCColumnConfig columnMemoList_locale = null;
	public mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL MemoList_extL_PPanel;
	public MCColumnConfig columnMemoList_co_cd;// [MemoList]の[extL.co_cd]を[columnMemoList_co_cd]としてエイリアス定義。
	public MCColumnConfig columnMemoList_co_nm;// [MemoList]の[extL.co_nm]を[columnMemoList_co_nm]としてエイリアス定義。
	public MCColumnConfig columnMemoList_attr1;// [MemoList]の[extL.attr1]を[columnMemoList_attr1]としてエイリアス定義。
	public MCColumnConfig columnMemoList_attr2;// [MemoList]の[extL.attr2]を[columnMemoList_attr2]としてエイリアス定義。
	public MCColumnConfig columnMemoList_attr3;// [MemoList]の[extL.attr3]を[columnMemoList_attr3]としてエイリアス定義。
	/**
	 *  共通メモ.<p>
	 *
	 */
	public MCColumnConfig columnMemoList_memo = null;
	// [MemoBtn]ブロック関連のField定義
	public MCPanel MemoBtnPanel = null;
	// [MemoBtn]ブロックの項目のField定義
	/**
	 * 追加 追加.<p>
	 *
	 */
	public MCButton MemoBtn_add = null;
	/**
	 * 削除 削除.<p>
	 *
	 */
	public MCButton MemoBtn_del = null;
	/**
	 * 行コピー 行コピー.<p>
	 *
	 */
	public MCButton MemoBtn_copy = null;
	// [Memo]ブロック関連のField定義
	public MCPanel MemoPanel = null;
	public MCTitledBorder MemoTitledBorder = null;
	// [Memo]ブロックの項目のField定義
	public MCScrollPane Memo_memoScrollPane = null;
	/**
	 * 共通メモ 共通メモ.<p>
	 *
	 */
	public MCTextArea Memo_memo = null;
	// [Command]ブロック関連のField定義
	public MCPanel CommandPanel = null;
	// [Command]ブロックの項目のField定義
	/**
	 * 更新 更新する.<p>
	 *
	 */
	public MCButton Command_update = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EXT]モードを表す定数 */
	public static final String EXT = "EXT";
	/** [NOEDIT]モードを表す定数 */
	public static final String NOEDIT = "NOEDIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EXT, NOEDIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0150_Srch03]のCallerの作成 */
	protected FSBAP_CommonMemo_FW.FS_FSBAL0150_Srch03Caller createFS_FSBAL0150_Srch03() {
		FSBAP_CommonMemo_FW.FS_FSBAL0150_Srch03Caller<FSBAP_CommonMemo, FS_FSBAL0150_Srch03Bridge>
		caller = ((FSBAP_CommonMemo_FW)this).new FS_FSBAL0150_Srch03Caller<FSBAP_CommonMemo, FS_FSBAL0150_Srch03Bridge>(
					(FSBAP_CommonMemo)this, new FS_FSBAL0150_Srch03Bridge());
		return caller;
	}
	/** [FS_FSBAL0150_Srch03]の呼び出し */
	protected void callFS_FSBAL0150_Srch03() {
		MCCaller caller = createFS_FSBAL0150_Srch03();
		caller.exec();
	}
	/** [FS_FSBAL0150_Upd03]のCallerの作成 */
	protected FSBAP_CommonMemo_FW.FS_FSBAL0150_Upd03Caller createFS_FSBAL0150_Upd03() {
		FSBAP_CommonMemo_FW.FS_FSBAL0150_Upd03Caller<FSBAP_CommonMemo, FS_FSBAL0150_Upd03Bridge>
		caller = ((FSBAP_CommonMemo_FW)this).new FS_FSBAL0150_Upd03Caller<FSBAP_CommonMemo, FS_FSBAL0150_Upd03Bridge>(
					(FSBAP_CommonMemo)this, new FS_FSBAL0150_Upd03Bridge());
		return caller;
	}
	/** [FS_FSBAL0150_Upd03]の呼び出し */
	protected void callFS_FSBAL0150_Upd03() {
		MCCaller caller = createFS_FSBAL0150_Upd03();
		caller.exec();
	}
	/** [Menu]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0340.MenuR aMenuR;
	/** [MemoList]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0340.MemoListR> aMemoListL;
	/** [Memo]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0340.MemoR aMemoR;

	/**
	 * 項目コピーによってaMenuRを設定します。
	 *
	 * aMenuRのインスタンスは変更されません。
	 *
	 * @param row MenuR
	 */
	public void setMenuR(mcframe.clientFSBA.FSBAP0340.MenuR row) {
		if (row != null) {
			MCRow.copyall(getMenuR(), row);
		}
	}

	/**
	 * [Menu]ブロックのコンテナaMenuRを返します。
	 *
	 * @return MenuR
	 */
	public mcframe.clientFSBA.FSBAP0340.MenuR getMenuR() {
		return aMenuR;
	}

	/**
	 * aMenuRを作成します。
	 *
	 * @return MenuR
	 */
	public mcframe.clientFSBA.FSBAP0340.MenuR createMenuR() {
		return mcframe.clientFSBA.FSBAP0340.MenuR.create();
	}

	/**
	 * コピーによってaMemoListLを設定します。
	 *
	 * aMemoListLのインスタンスは変更されません。
	 *
	 * @param dataset MemoListL
	 */
	public void setMemoListL(MCList<mcframe.clientFSBA.FSBAP0340.MemoListR> aList) {
		if (getMemoListL() != aList) {
			getMemoListL().setAll(aList);
		}
	}

	/**
	 * [MemoList]ブロックのコンテナaMemoListLを返します。
	 *
	 * @return MemoListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0340.MemoListR> getMemoListL() {
		return aMemoListL;
	}

	/**
	 * aMemoListRを作成します。
	 *
	 * @return MemoListR
	 */
	public mcframe.clientFSBA.FSBAP0340.MemoListR createMemoListR() {
		return mcframe.clientFSBA.FSBAP0340.MemoListR.create();
	}

	/**
	 * aMemoListLを作成します。
	 *
	 * @return MemoListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0340.MemoListR> createMemoListL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0340.MemoListR.class);
	}

	/**
	 * MemoListTableを初期化します。
	 */
	protected void createMemoListTable(){
		if(MemoListTable == null){
			MemoListTable = beansFactory.createTable2("MemoList.table");
		}
	}

	/**
	 * 項目コピーによってaMemoRを設定します。
	 *
	 * aMemoRのインスタンスは変更されません。
	 *
	 * @param row MemoR
	 */
	public void setMemoR(mcframe.clientFSBA.FSBAP0340.MemoR row) {
		if (row != null) {
			MCRow.copyall(getMemoR(), row);
		}
	}

	/**
	 * [Memo]ブロックのコンテナaMemoRを返します。
	 *
	 * @return MemoR
	 */
	public mcframe.clientFSBA.FSBAP0340.MemoR getMemoR() {
		return aMemoR;
	}

	/**
	 * aMemoRを作成します。
	 *
	 * @return MemoR
	 */
	public mcframe.clientFSBA.FSBAP0340.MemoR createMemoR() {
		return mcframe.clientFSBA.FSBAP0340.MemoR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getMenuR())) ret.add(getMenuR());
		if(!MCCollectionUtil.contains(ret, getMemoListL())) ret.add(getMemoListL());
		if(!MCCollectionUtil.contains(ret, getMemoR())) ret.add(getMemoR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getMenuR()) return "Menu";
		if(aCnt == getMemoListL()) return "MemoList";
		if(aCnt == getMemoR()) return "Memo";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Menu")) return getMenuR();
		if(bId.equals("MemoList")) return getMemoListL();
		if(bId.equals("Memo")) return getMemoR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(MenuPanel);
		ret.add(MemoListPanel);
		ret.add(MemoBtnPanel);
		ret.add(MemoPanel);
		ret.add(CommandPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_CommonMemo_FW_A() {
		aMenuR = createMenuR();
		aMemoListL = createMemoListL();
		aMemoR = createMemoR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_CommonMemo_FW_A(String name) {
		aMenuR = createMenuR();
		aMemoListL = createMemoListL();
		createMemoListTable();
		MemoListTable.setRowName(name);
		aMemoR = createMemoR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_CommonMemo_FW.jbCreateMenu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbCreateMemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbCreateMemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbCreateMemo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbCreateCommand((FSBAP_CommonMemo)this);
	}

	/**
	 * [Menu]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMenu(FSBAP_CommonMemo p) {
	}

	/**
	 * [MemoList]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMemoList(FSBAP_CommonMemo p) {
		p.MemoList_extL_PPanel = mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.create(mcframe.clientFSBA.FSBAP0340.MemoListR.$extL);
		p.MemoList_extL_PPanel.setName("MemoList.extL");
		p.columnMemoList_co_cd = p.MemoList_extL_PPanel.columnExtL_co_cd;
		p.columnMemoList_co_cd.addAliasName("MemoList.co_cd", p);
		p.columnMemoList_co_nm = p.MemoList_extL_PPanel.columnExtL_co_nm;
		p.columnMemoList_co_nm.addAliasName("MemoList.co_nm", p);
		p.columnMemoList_attr1 = p.MemoList_extL_PPanel.columnExtL_attr1;
		p.columnMemoList_attr1.addAliasName("MemoList.attr1", p);
		p.columnMemoList_attr2 = p.MemoList_extL_PPanel.columnExtL_attr2;
		p.columnMemoList_attr2.addAliasName("MemoList.attr2", p);
		p.columnMemoList_attr3 = p.MemoList_extL_PPanel.columnExtL_attr3;
		p.columnMemoList_attr3.addAliasName("MemoList.attr3", p);
	}

	/**
	 * [MemoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMemoBtn(FSBAP_CommonMemo p) {
	}

	/**
	 * [Memo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMemo(FSBAP_CommonMemo p) {
	}

	/**
	 * [Command]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommand(FSBAP_CommonMemo p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [MemoList_locale_cd_ListPutter]の定義 */
	private MCListPutter MemoList_locale_cd_p = null;

	/**
	 * [MemoList_locale_cd_ListPutter]の取得
	 */
	protected MCListPutter getMemoList_locale_cd_ListPutter() {
		if (MemoList_locale_cd_p == null) {
			MemoList_locale_cd_p = createMemoList_locale_cd_ListPutter(columnMemoList_locale_cd, "locale_cd", "locale");

		}
		return MemoList_locale_cd_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_CommonMemo create(){
		FSBAP_CommonMemo p = new FSBAP_CommonMemo();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_CommonMemo create(String name){
		FSBAP_CommonMemo p = new FSBAP_CommonMemo(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_CommonMemo_FW.jbfInitMenu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbfInitMemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbfInitMemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbfInitMemo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbfInitCommand((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbInitMenu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbInitMemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbInitMemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbInitMemo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.jbInitCommand((FSBAP_CommonMemo)this);
	}

	/**
	 * [Menu]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMenu(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.MenuPanel = p.beansFactory.createPanel("Menu");
		p.MenuTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Menu_title = p.beansFactory.createTextField("Menu.title");
	}

	/**
	 * [MemoList]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMemoList(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.MemoListPanel = p.beansFactory.createPanel("MemoList");
		p.MemoListScrollPane = p.beansFactory.createScrollPane("MemoList.scroll");
		p.createMemoListTable();
		// ブロックの項目の初期化
		p.columnMemoList_locale_cd = p.beansFactory.createTableColumn("MemoList.locale_cd", MCColumnType.TEXT_COMBO);
		p.columnMemoList_locale = p.beansFactory.createTableColumn("MemoList.locale", MCColumnType.TEXT);
		p.columnMemoList_memo = p.beansFactory.createTableColumn("MemoList.memo", MCColumnType.TEXT);
	}

	/**
	 * [MemoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMemoBtn(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.MemoBtnPanel = p.beansFactory.createPanel("MemoBtn");
		// ブロックの項目の初期化
		p.MemoBtn_add = p.beansFactory.createButton("MemoBtn.add", "no_border");
		p.MemoBtn_del = p.beansFactory.createButton("MemoBtn.del", "no_border");
		p.MemoBtn_copy = p.beansFactory.createButton("MemoBtn.copy", "no_border");
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMemo(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.MemoPanel = p.beansFactory.createPanel("Memo");
		p.MemoTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Memo_memoScrollPane = p.beansFactory.createScrollPane("Memo.memoscroll");
		p.Memo_memo = p.beansFactory.createTextArea("Memo.memo");
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommand(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.CommandPanel = p.beansFactory.createPanel("Command");
		// ブロックの項目の初期化
		p.Command_update = p.beansFactory.createButton("Command.update", "upd");
	}

	/**
	 * [Menu]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMenu(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.MenuPanel.setBorder(p.MenuTitledBorder);
		p.add(p.MenuPanel);
		p.setLastBeans(p.MenuPanel);
		p.MenuPanel.setNextBeans(p.MemoListPanel);
		p.MenuPanel.setValueCheck(false);
		p.MenuPanel.setLayoutPosition("CTN");
		// ブロックの項目の初期化
		p.MenuPanel.add(p.Menu_title);
		p.MenuPanel.setLastBeans(p.Menu_title);
		p.Menu_title.setRow(p.getMenuR(), mcframe.clientFSBA.FSBAP0340.MenuR.title_META);
	}

	/**
	 * [MemoList]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMemoList(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.add(p.MemoListPanel);
		p.MemoListPanel.setNextBeans(p.MemoBtnPanel);
		p.MemoListPanel.add(p.MemoListScrollPane);
		p.MemoListPanel.setLastBeans(p.MemoListTable);
		p.MemoListScrollPane.setViewportView(p.MemoListTable);
		p.MemoListTable.setList(p.getMemoListL());
		p.MemoListPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [MemoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMemoBtn(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.add(p.MemoBtnPanel);
		p.MemoBtnPanel.setNextBeans(p.MemoPanel);
		p.MemoBtnPanel.setValueCheck(false);
		p.MemoBtnPanel.setLayoutPosition("CTS");
		// ブロックの項目の初期化
		p.MemoBtn_add.setIcon("INSERT_RECORD");
		p.MemoBtn_add.setFunctionKey(MCFunctionKey.F5);
		p.MemoBtnPanel.add(p.MemoBtn_add);
		p.MemoBtnPanel.setLastBeans(p.MemoBtn_add);
		p.MemoBtn_add.setNextBeans(p.MemoBtn_del);
		p.MemoBtn_del.setIcon("DELETE_RECORD");
		p.MemoBtn_del.setFunctionKey(MCFunctionKey.F6);
		p.MemoBtnPanel.add(p.MemoBtn_del);
		p.MemoBtn_del.setNextBeans(p.MemoBtn_copy);
		p.MemoBtn_copy.setIcon("COPY_RECORD");
		p.MemoBtn_copy.setFunctionKey(MCFunctionKey.F17);
		p.MemoBtnPanel.add(p.MemoBtn_copy);
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMemo(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.MemoPanel.setBorder(p.MemoTitledBorder);
		p.add(p.MemoPanel);
		p.MemoPanel.setNextBeans(p.CommandPanel);
		p.MemoPanel.setValueCheck(false);
		p.MemoPanel.setLayoutPosition("CBC");
		// ブロックの項目の初期化
		p.Memo_memoScrollPane.getViewport().add(p.Memo_memo);
		p.MemoPanel.add(p.Memo_memoScrollPane);
		p.MemoPanel.setLastBeans(p.Memo_memo);
		p.Memo_memo.setRow(p.getMemoR(), mcframe.clientFSBA.FSBAP0340.MemoR.memo_META);
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommand(FSBAP_CommonMemo p) {
		// ブロック関連の初期化
		p.add(p.CommandPanel);
		p.CommandPanel.setLayoutPosition("CBS");
		// ブロックの項目の初期化
		p.Command_update.setIcon("REGISTER");
		p.Command_update.setFunctionKey(MCFunctionKey.F9);
		p.CommandPanel.add(p.Command_update);
		p.CommandPanel.setLastBeans(p.Command_update);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_CommonMemo_FW.mcInitMenu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.mcInitMemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.mcInitMemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.mcInitMemo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.mcInitCommand((FSBAP_CommonMemo)this);

		// [INIT]ステータスのモードの設定
		FSBAP_CommonMemo_FW.statusInitINIT_Menu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitINIT_MemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitINIT_MemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitINIT_Memo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitINIT_Command((FSBAP_CommonMemo)this);

		// [EXT]ステータスのモードの設定
		FSBAP_CommonMemo_FW.statusInitEXT_Menu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitEXT_MemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitEXT_MemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitEXT_Memo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitEXT_Command((FSBAP_CommonMemo)this);

		// [NOEDIT]ステータスのモードの設定
		FSBAP_CommonMemo_FW.statusInitNOEDIT_Menu((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitNOEDIT_MemoList((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitNOEDIT_MemoBtn((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitNOEDIT_Memo((FSBAP_CommonMemo)this);
		FSBAP_CommonMemo_FW.statusInitNOEDIT_Command((FSBAP_CommonMemo)this);

	}

	/**
	 *  [Menu]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMenu(FSBAP_CommonMemo p) {
		p.Menu_title.setListListener(p);
		p.Menu_title.addAllListener(p);
	}

	/**
	 *  [MemoList]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMemoList(FSBAP_CommonMemo p) {
		p.MemoListTable.addAllListener(p);
		p.columnMemoList_locale_cd.addAllListener(p);
		p.columnMemoList_locale_cd.setListListener(p);
		p.columnMemoList_locale.addAllListener(p);
		p.columnMemoList_locale.setListListener(p);
		p.columnMemoList_memo.addAllListener(p);
		p.columnMemoList_memo.setListListener(p);
	}

	/**
	 *  [MemoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMemoBtn(FSBAP_CommonMemo p) {
		p.MemoBtn_add.addAllListener(p);
		p.MemoBtn_add.setAPMethodName("doMemoBtn_add");
		p.MemoBtn_del.addAllListener(p);
		p.MemoBtn_del.setAPMethodName("doMemoBtn_del");
		p.MemoBtn_copy.addAllListener(p);
		p.MemoBtn_copy.setAPMethodName("doMemoBtn_copy");
	}

	/**
	 *  [Memo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMemo(FSBAP_CommonMemo p) {
		p.Memo_memo.addAllListener(p);
	}

	/**
	 *  [Command]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommand(FSBAP_CommonMemo p) {
		p.Command_update.addAllListener(p);
		p.Command_update.setAPMethodName("doCommand_update");
	}

	/**
	 * [INIT]ステータスの[Menu]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Menu(FSBAP_CommonMemo p){
		p.Menu_title.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[MemoList]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MemoList(FSBAP_CommonMemo p){
		p.columnMemoList_locale_cd.putMode(p, INIT, MCMode.ENABLE);
		p.columnMemoList_locale.putMode(p, INIT, MCMode.READ_ONLY);
		p.MemoList_extL_PPanel.putStatus(INIT, mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.REQ);
		p.columnMemoList_memo.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[MemoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MemoBtn(FSBAP_CommonMemo p){
		p.MemoBtn_add.putMode(p, INIT, MCMode.ENABLE);
		p.MemoBtn_del.putMode(p, INIT, MCMode.ENABLE);
		p.MemoBtn_copy.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Memo(FSBAP_CommonMemo p){
		p.Memo_memo.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Command(FSBAP_CommonMemo p){
		p.Command_update.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [EXT]ステータスの[Menu]ブロックのモードの設定
	 */
	protected static void statusInitEXT_Menu(FSBAP_CommonMemo p){
		p.Menu_title.putMode(p, EXT, MCMode.READ_ONLY);

	}

	/**
	 * [EXT]ステータスの[MemoList]ブロックのモードの設定
	 */
	protected static void statusInitEXT_MemoList(FSBAP_CommonMemo p){
		p.columnMemoList_locale_cd.putMode(p, EXT, MCMode.ENABLE);
		p.columnMemoList_locale.putMode(p, EXT, MCMode.READ_ONLY);
		p.MemoList_extL_PPanel.putStatus(EXT, mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.REF);
		p.columnMemoList_memo.putMode(p, EXT, MCMode.READ_ONLY);

	}

	/**
	 * [EXT]ステータスの[MemoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEXT_MemoBtn(FSBAP_CommonMemo p){
		p.MemoBtn_add.putMode(p, EXT, MCMode.ENABLE);
		p.MemoBtn_del.putMode(p, EXT, MCMode.ENABLE);
		p.MemoBtn_copy.putMode(p, EXT, MCMode.ENABLE);

	}

	/**
	 * [EXT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitEXT_Memo(FSBAP_CommonMemo p){
		p.Memo_memo.putMode(p, EXT, MCMode.ENABLE);

	}

	/**
	 * [EXT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitEXT_Command(FSBAP_CommonMemo p){
		p.Command_update.putMode(p, EXT, MCMode.ENABLE);

	}

	/**
	 * [NOEDIT]ステータスの[Menu]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Menu(FSBAP_CommonMemo p){
		p.Menu_title.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[MemoList]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_MemoList(FSBAP_CommonMemo p){
		p.columnMemoList_locale_cd.putMode(p, NOEDIT, MCMode.READ_ONLY);
		p.columnMemoList_locale.putMode(p, NOEDIT, MCMode.READ_ONLY);
		p.MemoList_extL_PPanel.putStatus(NOEDIT, mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.REF);
		p.columnMemoList_memo.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[MemoBtn]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_MemoBtn(FSBAP_CommonMemo p){
		p.MemoBtn_add.putMode(p, NOEDIT, MCMode.READ_ONLY);
		p.MemoBtn_del.putMode(p, NOEDIT, MCMode.READ_ONLY);
		p.MemoBtn_copy.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Memo(FSBAP_CommonMemo p){
		p.Memo_memo.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Command(FSBAP_CommonMemo p){
		p.Command_update.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_CommonMemo_FW.setTableConfigMemoList((FSBAP_CommonMemo)this);
	}

	/**
	 * [MemoList]ブロックのTableの設定
	 */
	protected static void setTableConfigMemoList(FSBAP_CommonMemo p) {
		p.columnMemoList_locale_cd.setMeta(mcframe.clientFSBA.FSBAP0340.MemoListR.locale_cd_META);
		p.columnMemoList_locale_cd.addLinkBeans(p.columnMemoList_locale);
		p.MemoListTable.addColumnConfig(p.columnMemoList_locale_cd);
		p.columnMemoList_locale.setMeta(mcframe.clientFSBA.FSBAP0340.MemoListR.locale_META);
		p.MemoListTable.addColumnConfig(p.columnMemoList_locale);
		p.MemoListTable.addTable(p.MemoList_extL_PPanel.ExtLTable);
		p.columnMemoList_memo.setMeta(mcframe.clientFSBA.FSBAP0340.MemoListR.memo_META);
		p.MemoListTable.addColumnConfig(p.columnMemoList_memo);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnMemoList_locale_cd.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnMemoList_locale_cd.getListConfig().setPutter(getMemoList_locale_cd_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EXT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEXTStatus() {
		status = EXT;
		setAllStatus(status);
	}

	/**
	 * この画面を[NOEDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setNOEDITStatus() {
		status = NOEDIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EXT.equals(status)) {
			setEXTStatus();
		}
		else if (NOEDIT.equals(status)) {
			setNOEDITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [MemoList_locale_cd_ListPutter]の作成
	 */
	protected MCListPutter createMemoList_locale_cd_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.Locale");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnMemoList_locale_cd) return getMemoList_locale_cd(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == MemoBtn_add) doMemoBtn_add(info);
		else if (ap == MemoBtn_del) doMemoBtn_del(info);
		else if (ap == MemoBtn_copy) doMemoBtn_copy(info);
		else if (ap == Command_update) doCommand_update(info);
	}

	/**
	 * [MemoBtn]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMemoBtn_add(MCEventInfo info);

	/**
	 * [MemoBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMemoBtn_del(MCEventInfo info);

	/**
	 * [MemoBtn]パネルの[copy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMemoBtn_copy(MCEventInfo info);

	/**
	 * [Command]パネルの[update]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_update(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == MemoListTable) return doMemoList_VC(info);
		if (vc == Menu_title) return doMenu_title_VC(info);
		if (vc == columnMemoList_locale_cd) return doMemoList_locale_cd_VC(info);
		if (vc == columnMemoList_locale) return doMemoList_locale_VC(info);
		if (vc == columnMemoList_memo) return doMemoList_memo_VC(info);
		if (vc == Memo_memo) return doMemo_memo_VC(info);
		return true;
	}

	/**
	 * [MemoList]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemoList_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Menu]パネルの[title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMenu_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MemoList]パネルの[locale_cd]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemoList_locale_cd_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MemoList]パネルの[locale]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemoList_locale_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MemoList]パネルの[memo]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemoList_memo_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Memo]パネルの[memo]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemo_memo_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == MemoListTable) doMemoList_NC(info);
		else if (nc == Menu_title) doMenu_title_NC(info);
		else if (nc == columnMemoList_locale_cd) doMemoList_locale_cd_NC(info);
		else if (nc == columnMemoList_locale) doMemoList_locale_NC(info);
		else if (nc == columnMemoList_memo) doMemoList_memo_NC(info);
		else if (nc == Memo_memo) doMemo_memo_NC(info);
	}

	/**
	 * [MemoList]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_NC(MCEventInfo info){
	}

	/**
	 * [Menu]パネルの[title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_title_NC(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale_cd]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_cd_NC(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_NC(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[memo]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_memo_NC(MCEventInfo info){
	}

	/**
	 * [Memo]パネルの[memo]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_memo_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == MemoListTable) doMemoList_NE(info);
		else if (ne == Menu_title) doMenu_title_NE(info);
		else if (ne == columnMemoList_locale_cd) doMemoList_locale_cd_NE(info);
		else if (ne == columnMemoList_locale) doMemoList_locale_NE(info);
		else if (ne == columnMemoList_memo) doMemoList_memo_NE(info);
		else if (ne == Memo_memo) doMemo_memo_NE(info);
	}

	/**
	 * [MemoList]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_NE(MCEventInfo info){
	}

	/**
	 * [Menu]パネルの[title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_title_NE(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale_cd]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_cd_NE(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_NE(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[memo]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_memo_NE(MCEventInfo info){
	}

	/**
	 * [Memo]パネルの[memo]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_memo_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == MemoListTable) doMemoList_NX(info);
		else if (nx == Menu_title) doMenu_title_NX(info);
		else if (nx == columnMemoList_locale_cd) doMemoList_locale_cd_NX(info);
		else if (nx == columnMemoList_locale) doMemoList_locale_NX(info);
		else if (nx == columnMemoList_memo) doMemoList_memo_NX(info);
		else if (nx == Memo_memo) doMemo_memo_NX(info);
	}

	/**
	 * [MemoList]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_NX(MCEventInfo info){
	}

	/**
	 * [Menu]パネルの[title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_title_NX(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale_cd]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_cd_NX(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_NX(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[memo]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_memo_NX(MCEventInfo info){
	}

	/**
	 * [Memo]パネルの[memo]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_memo_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Menu_title) doMenu_title_LC(info);
		else if (lc == columnMemoList_locale_cd) doMemoList_locale_cd_LC(info);
		else if (lc == columnMemoList_locale) doMemoList_locale_LC(info);
		else if (lc == columnMemoList_memo) doMemoList_memo_LC(info);
	}

	/**
	 * [Menu]パネルの[title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_title_LC(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale_cd]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_cd_LC(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[locale]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_locale_LC(MCEventInfo info){
	}

	/**
	 * [MemoList]パネルの[memo]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemoList_memo_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnMemoList_locale_cd]の作成メソッド
	 */
	public MCList getMemoList_locale_cd(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getLocale(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0150.Srch03")) {
			return new FS_FSBAL0150_Srch03Bridge();
		}
		if (id.equals("FS.FSBAL0150.Upd03")) {
			return new FS_FSBAL0150_Upd03Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0150_Srch03]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Srch03Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0150_Srch03;

		/** コンストラクタ */
		protected FS_FSBAL0150_Srch03Bridge() {
			p_FS_FSBAL0150_Srch03 = new MCParam(PDef.FS_FSBAL0150_Srch03_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0150_Srch03_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0340.MenuR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0340.MemoListR.class));

			p_FS_FSBAL0150_Srch03 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0150_Srch03.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0150_Srch03.addUpBlock(getMenuR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0150_Srch03.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0150_Srch03.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0340.MenuR up0() {
			return (mcframe.clientFSBA.FSBAP0340.MenuR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0340.MemoListR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0340.MemoListR>)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0150_Srch03.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0340.MemoListR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0150_Srch03;
		}

		protected void show() {
			setMemoListL((MCList<mcframe.clientFSBA.FSBAP0340.MemoListR>)p_FS_FSBAL0150_Srch03.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMemoListL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMenuR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoListL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0150_Upd03]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Upd03Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0150_Upd03;

		/** コンストラクタ */
		protected FS_FSBAL0150_Upd03Bridge() {
			p_FS_FSBAL0150_Upd03 = new MCParam(PDef.FS_FSBAL0150_Upd03_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0150_Upd03_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0340.MemoListR.class));
			// Down

			p_FS_FSBAL0150_Upd03 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0150_Upd03.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0150_Upd03.addUpBlock(getMemoListL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0150_Upd03.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0150_Upd03.getContainerParam().getDownBlock(i);
		}
		
		protected MCList<mcframe.clientFSBA.FSBAP0340.MemoListR> up0() {
			return (MCList<mcframe.clientFSBA.FSBAP0340.MemoListR>)up(0);
		}


		protected void setupDownParam() {
		}
		protected MCParam param() {
			return p_FS_FSBAL0150_Upd03;
		}

		protected void show() {
		}

		protected void clear() {
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoListL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			return result;
		}
	}
}