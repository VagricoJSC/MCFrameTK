package mcframe.clientFSBA.FSBAP0340;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_CommonMemo]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0150.Srch03.UP.BLOCK0")){
			return FS_FSBAL0150_Srch03_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Srch03.DOWN.BLOCK0")){
			return FS_FSBAL0150_Srch03_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Upd03.UP.BLOCK0")){
			return FS_FSBAL0150_Upd03_UP_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
		
	
	static final MCOperationInfo FS_FSBAL0150_Srch03_INFO = new MCOperationInfo("FS", "FSBAL0150", "Srch03", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0150_Srch03_UP_BLOCK0() {
		/** Ope.のBlock [Srch03_Cnd] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("memo_key", "memo_key"),
				MCItemDef.create("use_ext", "use_ext"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("ext_attr1", "ext_attr1"),
				MCItemDef.create("ext_attr2", "ext_attr2"),
				MCItemDef.create("ext_attr3", "ext_attr3")
			}
			,
			MCBlockDef.create("Menu")
		);
	}


	public static MCContainerDef FS_FSBAL0150_Srch03_DOWN_BLOCK0() {
	/** Ope.のBlock [Srch03_Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("locale_cd", "locale"),
				MCItemDef.create("memo_key", "memo_key"),
				MCItemDef.create("memo", "memo"),
				MCItemDef.create("extL" + ".co_cd", "co_cd"),
				MCItemDef.create("extL" + ".co_nm", "co_nm"),
				MCItemDef.create("extL" + ".attr1", "ext_attr1"),
				MCItemDef.create("extL" + ".attr2", "ext_attr2"),
				MCItemDef.create("extL" + ".attr3", "ext_attr3"),
				MCItemDef.create("org_locale_cd", "org_locale"),
				MCItemDef.create("org_co_cd", "org_co_cd"),
				MCItemDef.create("org_ext_attr1", "org_ext_attr1"),
				MCItemDef.create("org_ext_attr2", "org_ext_attr2"),
				MCItemDef.create("org_ext_attr3", "org_ext_attr3"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("MemoList")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0150_Upd03_INFO = new MCOperationInfo("FS", "FSBAL0150", "Upd03", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0150_Upd03_UP_BLOCK0() {
		/** Ope.のBlock [Upd03_Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Upd03",
			new MCItemDef[]{
				MCItemDef.create("locale_cd", "locale"),
				MCItemDef.create("memo_key", "memo_key"),
				MCItemDef.create("memo", "memo"),
				MCItemDef.create("extL" + ".co_cd", "co_cd"),
				MCItemDef.create("extL" + ".attr1", "ext_attr1"),
				MCItemDef.create("extL" + ".attr2", "ext_attr2"),
				MCItemDef.create("extL" + ".attr3", "ext_attr3"),
				MCItemDef.create("org_locale_cd", "org_locale"),
				MCItemDef.create("org_co_cd", "org_co_cd"),
				MCItemDef.create("org_ext_attr1", "org_ext_attr1"),
				MCItemDef.create("org_ext_attr2", "org_ext_attr2"),
				MCItemDef.create("org_ext_attr3", "org_ext_attr3"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("MemoList")
		);
	}


	//FMCB DEF_CLASSES END
}

