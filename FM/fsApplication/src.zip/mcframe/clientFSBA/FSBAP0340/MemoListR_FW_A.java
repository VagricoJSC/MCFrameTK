package mcframe.clientFSBA.FSBAP0340;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"MemoList"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MemoListR_FW_A extends MCConstRow {

	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public static final String $locale_cd = "locale_cd";
	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public static final String $locale = "locale";
	public static final String $memo_key = "memo_key";
	public static final String $extL = "extL";
	/**
	 *  共通メモ.<p>
	 *
	 */
	public static final String $memo = "memo";
	public static final String $org_locale_cd = "org_locale_cd";
	public static final String $org_co_cd = "org_co_cd";
	public static final String $org_ext_attr1 = "org_ext_attr1";
	public static final String $org_ext_attr2 = "org_ext_attr2";
	public static final String $org_ext_attr3 = "org_ext_attr3";
	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public static final String $upd_cntr = "upd_cntr";

	public static final String $co_cd = $extL + ".co_cd";
	public static final String $co_nm = $extL + ".co_nm";
	public static final String $attr1 = $extL + ".attr1";
	public static final String $attr2 = $extL + ".attr2";
	public static final String $attr3 = $extL + ".attr3";

	public static final MCMeta locale_cd_META = createCommonMeta($locale_cd, mcframe.commonCore.meta.M_META.LOCALE_CD);
	public static final MCMeta locale_META = createCommonMeta($locale, mcframe.commonCore.meta.M_META.LOCALE_NM);
	public static final MCMeta memo_key_META = createCommonMeta($memo_key, mcframe.commonCore.meta.M_META.MEMO_KEY);
	public static final MCMeta extL_META = createInnerRowMeta($extL, mcframe.clientFSBF.FSBFP0130.ExtLR.class);
	public static final MCMeta memo_META = createCommonMeta($memo, mcframe.commonCore.meta.M_META.MEMO);
	public static final MCMeta org_locale_cd_META = createCommonMeta($org_locale_cd, mcframe.commonCore.meta.M_META.LOCALE_CD);
	public static final MCMeta org_co_cd_META = createCommonMeta($org_co_cd, mcframe.commonCore.meta.M_META.CO_CD);
	public static final MCMeta org_ext_attr1_META = createCommonMeta($org_ext_attr1, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta org_ext_attr2_META = createCommonMeta($org_ext_attr2, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta org_ext_attr3_META = createCommonMeta($org_ext_attr3, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta upd_cntr_META = createCommonMeta($upd_cntr, mcframe.commonCore.meta.M_META.UPD_CNT);

	protected static final ConstMetaList<MemoListR> constMetas = new ConstMetaList<MemoListR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			locale_cd_META,
			locale_META,
			memo_key_META,
			extL_META,
			memo_META,
			org_locale_cd_META,
			org_co_cd_META,
			org_ext_attr1_META,
			org_ext_attr2_META,
			org_ext_attr3_META,
			upd_cntr_META
		},
		new String[][]{
			{
				"co_cd",
				"co_nm",
				"attr1",
				"attr2",
				"attr3"
			},
			{
				$co_cd,
				$co_nm,
				$attr1,
				$attr2,
				$attr3
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MemoListR_FW_A(ConstMetaList<? extends MemoListR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MemoListR clone() {
		return (MemoListR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MemoListR createInstance() {
		return (MemoListR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MemoListR getValues(String... names) {
		return (MemoListR) super.getValues(names);
	}



	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public String locale_cd() {
		return getConstString(offset + 0, $locale_cd);
	}

	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public void locale_cd(String value) {
		setConstString(offset + 0, $locale_cd, value);
	}


	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public String locale() {
		return getConstString(offset + 1, $locale);
	}

	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public void locale(String value) {
		setConstString(offset + 1, $locale, value);
	}


	public String memo_key() {
		return getConstString(offset + 2, $memo_key);
	}

	public void memo_key(String value) {
		setConstString(offset + 2, $memo_key, value);
	}


	public mcframe.clientFSBF.FSBFP0130.ExtLR extL(){
		return (mcframe.clientFSBF.FSBFP0130.ExtLR) getConstInnerRow(offset + 3, $extL);
	}
	
	public void extL(mcframe.clientFSBF.FSBFP0130.ExtLR row){
		setConstInnerRow(offset + 3, $extL, row);
	}


	/**
	 *  共通メモ.<p>
	 *
	 */
	public String memo() {
		return getConstString(offset + 4, $memo);
	}

	/**
	 *  共通メモ.<p>
	 *
	 */
	public void memo(String value) {
		setConstString(offset + 4, $memo, value);
	}


	public String org_locale_cd() {
		return getConstString(offset + 5, $org_locale_cd);
	}

	public void org_locale_cd(String value) {
		setConstString(offset + 5, $org_locale_cd, value);
	}


	public String org_co_cd() {
		return getConstString(offset + 6, $org_co_cd);
	}

	public void org_co_cd(String value) {
		setConstString(offset + 6, $org_co_cd, value);
	}


	public String org_ext_attr1() {
		return getConstString(offset + 7, $org_ext_attr1);
	}

	public void org_ext_attr1(String value) {
		setConstString(offset + 7, $org_ext_attr1, value);
	}


	public String org_ext_attr2() {
		return getConstString(offset + 8, $org_ext_attr2);
	}

	public void org_ext_attr2(String value) {
		setConstString(offset + 8, $org_ext_attr2, value);
	}


	public String org_ext_attr3() {
		return getConstString(offset + 9, $org_ext_attr3);
	}

	public void org_ext_attr3(String value) {
		setConstString(offset + 9, $org_ext_attr3, value);
	}


	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public MCNumber upd_cntr() {
		return getConstNumber(offset + 10, $upd_cntr);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(MCNumber value) {
		setConstNumber(offset + 10, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(int value) {
		setConstNumber(offset + 10, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(long value) {
		setConstNumber(offset + 10, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(float value) {
		setConstNumber(offset + 10, $upd_cntr, value);
	}

	/**
	 *  更新カウンタ.<p>
	 *
	 */
	public void upd_cntr(double value) {
		setConstNumber(offset + 10, $upd_cntr, value);
	}


	public String getString(String name) {
		if ($locale_cd.equalsIgnoreCase(name)) {
			return locale_cd();
		}
		if ($locale.equalsIgnoreCase(name)) {
			return locale();
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			return memo_key();
		}
		if ($memo.equalsIgnoreCase(name)) {
			return memo();
		}
		if ($org_locale_cd.equalsIgnoreCase(name)) {
			return org_locale_cd();
		}
		if ($org_co_cd.equalsIgnoreCase(name)) {
			return org_co_cd();
		}
		if ($org_ext_attr1.equalsIgnoreCase(name)) {
			return org_ext_attr1();
		}
		if ($org_ext_attr2.equalsIgnoreCase(name)) {
			return org_ext_attr2();
		}
		if ($org_ext_attr3.equalsIgnoreCase(name)) {
			return org_ext_attr3();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			return upd_cntr();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($locale_cd.equalsIgnoreCase(name)) {
			return locale_cd();
		}
		if ($locale.equalsIgnoreCase(name)) {
			return locale();
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			return memo_key();
		}
		if ($memo.equalsIgnoreCase(name)) {
			return memo();
		}
		if ($org_locale_cd.equalsIgnoreCase(name)) {
			return org_locale_cd();
		}
		if ($org_co_cd.equalsIgnoreCase(name)) {
			return org_co_cd();
		}
		if ($org_ext_attr1.equalsIgnoreCase(name)) {
			return org_ext_attr1();
		}
		if ($org_ext_attr2.equalsIgnoreCase(name)) {
			return org_ext_attr2();
		}
		if ($org_ext_attr3.equalsIgnoreCase(name)) {
			return org_ext_attr3();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			return upd_cntr();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($locale_cd.equalsIgnoreCase(name)) {
			locale_cd(value);
			return;
		}
		if ($locale.equalsIgnoreCase(name)) {
			locale(value);
			return;
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			memo_key(value);
			return;
		}
		if ($memo.equalsIgnoreCase(name)) {
			memo(value);
			return;
		}
		if ($org_locale_cd.equalsIgnoreCase(name)) {
			org_locale_cd(value);
			return;
		}
		if ($org_co_cd.equalsIgnoreCase(name)) {
			org_co_cd(value);
			return;
		}
		if ($org_ext_attr1.equalsIgnoreCase(name)) {
			org_ext_attr1(value);
			return;
		}
		if ($org_ext_attr2.equalsIgnoreCase(name)) {
			org_ext_attr2(value);
			return;
		}
		if ($org_ext_attr3.equalsIgnoreCase(name)) {
			org_ext_attr3(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($locale_cd.equalsIgnoreCase(name)) {
			locale_cd(value);
			return;
		}
		if ($locale.equalsIgnoreCase(name)) {
			locale(value);
			return;
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			memo_key(value);
			return;
		}
		if ($memo.equalsIgnoreCase(name)) {
			memo(value);
			return;
		}
		if ($org_locale_cd.equalsIgnoreCase(name)) {
			org_locale_cd(value);
			return;
		}
		if ($org_co_cd.equalsIgnoreCase(name)) {
			org_co_cd(value);
			return;
		}
		if ($org_ext_attr1.equalsIgnoreCase(name)) {
			org_ext_attr1(value);
			return;
		}
		if ($org_ext_attr2.equalsIgnoreCase(name)) {
			org_ext_attr2(value);
			return;
		}
		if ($org_ext_attr3.equalsIgnoreCase(name)) {
			org_ext_attr3(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($upd_cntr.equalsIgnoreCase(name)) {
			upd_cntr(value);
			return;
		}
		super.setNumberNE(name, value);
	}

	public MCRow getInnerRow(String name) {
		if ($extL.equalsIgnoreCase(name)) {
			return extL();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($extL.equalsIgnoreCase(name)) {
			extL(
				((MCContainerMeta) extL_META).castInnerRow(mcframe.clientFSBF.FSBFP0130.ExtLR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public String co_cd() {
		return extL().co_cd();
	}

	public void co_cd(String value) {
		extL().co_cd(value);
	}

	public String co_nm() {
		return extL().co_nm();
	}

	public void co_nm(String value) {
		extL().co_nm(value);
	}

	public String attr1() {
		return extL().attr1();
	}

	public void attr1(String value) {
		extL().attr1(value);
	}

	public String attr2() {
		return extL().attr2();
	}

	public void attr2(String value) {
		extL().attr2(value);
	}

	public String attr3() {
		return extL().attr3();
	}

	public void attr3(String value) {
		extL().attr3(value);
	}

}

