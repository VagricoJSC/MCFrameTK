package mcframe.clientFSBA.FSBAP0340;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Menu"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MenuR_FW_A extends MCConstRow {

	/**
	 *  親メニューID.<p>
	 *
	 */
	public static final String $parent_menu_id = "parent_menu_id";
	/**
	 *  メニューID.<p>
	 *
	 */
	public static final String $menu_id = "menu_id";
	/**
	 *  並び順.<p>
	 *
	 */
	public static final String $menu_order = "menu_order";
	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public static final String $co_cd = "co_cd";
	/**
	 *  拡張属性１.<p>
	 *
	 */
	public static final String $ext_attr1 = "ext_attr1";
	/**
	 *  拡張属性２.<p>
	 *
	 */
	public static final String $ext_attr2 = "ext_attr2";
	/**
	 *  拡張属性３.<p>
	 *
	 */
	public static final String $ext_attr3 = "ext_attr3";
	/**
	 *  モジュールID.<p>
	 *
	 */
	public static final String $module_id = "module_id";
	/**
	 *  画面ID.<p>
	 *
	 */
	public static final String $screen_id = "screen_id";
	/**
	 *  メニューインデックス.<p>
	 *
	 */
	public static final String $menu_index = "menu_index";
	/**
	 *  タイトル.<p>
	 *
	 */
	public static final String $title = "title";
	/**
	 *  拡張属性使用有無.<p>
	 *
	 */
	public static final String $use_ext = "use_ext";
	/**
	 *  メモキー.<p>
	 *
	 */
	public static final String $memo_key = "memo_key";


	public static final MCMeta parent_menu_id_META = createCommonMeta($parent_menu_id, mcframe.commonCore.meta.M_META.PARENT_MENU_ID);
	public static final MCMeta menu_id_META = createCommonMeta($menu_id, mcframe.commonCore.meta.M_META.MENU_ID);
	public static final MCMeta menu_order_META = createCommonMeta($menu_order, mcframe.commonCore.meta.M_META.INT);
	public static final MCMeta co_cd_META = createCommonMeta($co_cd, mcframe.commonCore.meta.M_META.CO_CD);
	public static final MCMeta ext_attr1_META = createCommonMeta($ext_attr1, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta ext_attr2_META = createCommonMeta($ext_attr2, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta ext_attr3_META = createCommonMeta($ext_attr3, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta module_id_META = createCommonMeta($module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta screen_id_META = createCommonMeta($screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta menu_index_META = createCommonMeta($menu_index, mcframe.commonCore.meta.M_META.NUM_STR);
	public static final MCMeta title_META = createStringMeta($title);
	public static final MCMeta use_ext_META = createCommonMeta($use_ext, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta memo_key_META = createCommonMeta($memo_key, mcframe.commonCore.meta.M_META.MEMO_KEY);

	protected static final ConstMetaList<MenuR> constMetas = new ConstMetaList<MenuR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			parent_menu_id_META,
			menu_id_META,
			menu_order_META,
			co_cd_META,
			ext_attr1_META,
			ext_attr2_META,
			ext_attr3_META,
			module_id_META,
			screen_id_META,
			menu_index_META,
			title_META,
			use_ext_META,
			memo_key_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MenuR_FW_A(ConstMetaList<? extends MenuR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuR clone() {
		return (MenuR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuR createInstance() {
		return (MenuR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuR getValues(String... names) {
		return (MenuR) super.getValues(names);
	}



	/**
	 *  親メニューID.<p>
	 *
	 */
	public String parent_menu_id() {
		return getConstString(offset + 0, $parent_menu_id);
	}

	/**
	 *  親メニューID.<p>
	 *
	 */
	public void parent_menu_id(String value) {
		setConstString(offset + 0, $parent_menu_id, value);
	}


	/**
	 *  メニューID.<p>
	 *
	 */
	public String menu_id() {
		return getConstString(offset + 1, $menu_id);
	}

	/**
	 *  メニューID.<p>
	 *
	 */
	public void menu_id(String value) {
		setConstString(offset + 1, $menu_id, value);
	}


	/**
	 *  並び順.<p>
	 *
	 */
	public MCNumber menu_order() {
		return getConstNumber(offset + 2, $menu_order);
	}

	/**
	 *  並び順.<p>
	 *
	 */
	public void menu_order(MCNumber value) {
		setConstNumber(offset + 2, $menu_order, value);
	}

	/**
	 *  並び順.<p>
	 *
	 */
	public void menu_order(int value) {
		setConstNumber(offset + 2, $menu_order, value);
	}

	/**
	 *  並び順.<p>
	 *
	 */
	public void menu_order(long value) {
		setConstNumber(offset + 2, $menu_order, value);
	}

	/**
	 *  並び順.<p>
	 *
	 */
	public void menu_order(float value) {
		setConstNumber(offset + 2, $menu_order, value);
	}

	/**
	 *  並び順.<p>
	 *
	 */
	public void menu_order(double value) {
		setConstNumber(offset + 2, $menu_order, value);
	}


	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public String co_cd() {
		return getConstString(offset + 3, $co_cd);
	}

	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public void co_cd(String value) {
		setConstString(offset + 3, $co_cd, value);
	}


	/**
	 *  拡張属性１.<p>
	 *
	 */
	public String ext_attr1() {
		return getConstString(offset + 4, $ext_attr1);
	}

	/**
	 *  拡張属性１.<p>
	 *
	 */
	public void ext_attr1(String value) {
		setConstString(offset + 4, $ext_attr1, value);
	}


	/**
	 *  拡張属性２.<p>
	 *
	 */
	public String ext_attr2() {
		return getConstString(offset + 5, $ext_attr2);
	}

	/**
	 *  拡張属性２.<p>
	 *
	 */
	public void ext_attr2(String value) {
		setConstString(offset + 5, $ext_attr2, value);
	}


	/**
	 *  拡張属性３.<p>
	 *
	 */
	public String ext_attr3() {
		return getConstString(offset + 6, $ext_attr3);
	}

	/**
	 *  拡張属性３.<p>
	 *
	 */
	public void ext_attr3(String value) {
		setConstString(offset + 6, $ext_attr3, value);
	}


	/**
	 *  モジュールID.<p>
	 *
	 */
	public String module_id() {
		return getConstString(offset + 7, $module_id);
	}

	/**
	 *  モジュールID.<p>
	 *
	 */
	public void module_id(String value) {
		setConstString(offset + 7, $module_id, value);
	}


	/**
	 *  画面ID.<p>
	 *
	 */
	public String screen_id() {
		return getConstString(offset + 8, $screen_id);
	}

	/**
	 *  画面ID.<p>
	 *
	 */
	public void screen_id(String value) {
		setConstString(offset + 8, $screen_id, value);
	}


	/**
	 *  メニューインデックス.<p>
	 *
	 */
	public String menu_index() {
		return getConstString(offset + 9, $menu_index);
	}

	/**
	 *  メニューインデックス.<p>
	 *
	 */
	public void menu_index(String value) {
		setConstString(offset + 9, $menu_index, value);
	}


	/**
	 *  タイトル.<p>
	 *
	 */
	public String title() {
		return getConstString(offset + 10, $title);
	}

	/**
	 *  タイトル.<p>
	 *
	 */
	public void title(String value) {
		setConstString(offset + 10, $title, value);
	}


	/**
	 *  拡張属性使用有無.<p>
	 *
	 */
	public boolean use_ext() {
		return getConstBoolean(offset + 11, $use_ext);
	}

	/**
	 *  拡張属性使用有無.<p>
	 *
	 */
	public void use_ext(boolean value) {
		setConstBoolean(offset + 11, $use_ext, value);
	}


	/**
	 *  メモキー.<p>
	 *
	 */
	public String memo_key() {
		return getConstString(offset + 12, $memo_key);
	}

	/**
	 *  メモキー.<p>
	 *
	 */
	public void memo_key(String value) {
		setConstString(offset + 12, $memo_key, value);
	}


	public String getString(String name) {
		if ($parent_menu_id.equalsIgnoreCase(name)) {
			return parent_menu_id();
		}
		if ($menu_id.equalsIgnoreCase(name)) {
			return menu_id();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			return ext_attr1();
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			return ext_attr2();
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			return ext_attr3();
		}
		if ($module_id.equalsIgnoreCase(name)) {
			return module_id();
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			return screen_id();
		}
		if ($menu_index.equalsIgnoreCase(name)) {
			return menu_index();
		}
		if ($title.equalsIgnoreCase(name)) {
			return title();
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			return memo_key();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($menu_order.equalsIgnoreCase(name)) {
			return menu_order();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($use_ext.equalsIgnoreCase(name)) {
			return use_ext();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($parent_menu_id.equalsIgnoreCase(name)) {
			return parent_menu_id();
		}
		if ($menu_id.equalsIgnoreCase(name)) {
			return menu_id();
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			return co_cd();
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			return ext_attr1();
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			return ext_attr2();
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			return ext_attr3();
		}
		if ($module_id.equalsIgnoreCase(name)) {
			return module_id();
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			return screen_id();
		}
		if ($menu_index.equalsIgnoreCase(name)) {
			return menu_index();
		}
		if ($title.equalsIgnoreCase(name)) {
			return title();
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			return memo_key();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($menu_order.equalsIgnoreCase(name)) {
			return menu_order();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($use_ext.equalsIgnoreCase(name)) {
			return use_ext();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($parent_menu_id.equalsIgnoreCase(name)) {
			parent_menu_id(value);
			return;
		}
		if ($menu_id.equalsIgnoreCase(name)) {
			menu_id(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			ext_attr1(value);
			return;
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			ext_attr2(value);
			return;
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			ext_attr3(value);
			return;
		}
		if ($module_id.equalsIgnoreCase(name)) {
			module_id(value);
			return;
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			screen_id(value);
			return;
		}
		if ($menu_index.equalsIgnoreCase(name)) {
			menu_index(value);
			return;
		}
		if ($title.equalsIgnoreCase(name)) {
			title(value);
			return;
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			memo_key(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($use_ext.equalsIgnoreCase(name)) {
			use_ext(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($parent_menu_id.equalsIgnoreCase(name)) {
			parent_menu_id(value);
			return;
		}
		if ($menu_id.equalsIgnoreCase(name)) {
			menu_id(value);
			return;
		}
		if ($co_cd.equalsIgnoreCase(name)) {
			co_cd(value);
			return;
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			ext_attr1(value);
			return;
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			ext_attr2(value);
			return;
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			ext_attr3(value);
			return;
		}
		if ($module_id.equalsIgnoreCase(name)) {
			module_id(value);
			return;
		}
		if ($screen_id.equalsIgnoreCase(name)) {
			screen_id(value);
			return;
		}
		if ($menu_index.equalsIgnoreCase(name)) {
			menu_index(value);
			return;
		}
		if ($title.equalsIgnoreCase(name)) {
			title(value);
			return;
		}
		if ($memo_key.equalsIgnoreCase(name)) {
			memo_key(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($menu_order.equalsIgnoreCase(name)) {
			menu_order(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($use_ext.equalsIgnoreCase(name)) {
			use_ext(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

