package mcframe.clientFSBA.FSBAP0340;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBF.FSBFP0130.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSUA.FSUAP0010.FSUAP_List;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCMenuItemModel;
import mcframe.clientFSBA.FSBAP0200.FSBAP0200;
import mcframe.clientCore.beans.menu.MCMenuBeansUtil;
import mcframe.clientCore.sys.MCSys;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_CommonMemo"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_CommonMemo_FW extends FSBAP_CommonMemo_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	
	/**
	 * 対象のメニューモデル
	 */
	MCMenuItemModel _model = null;
	
	MCRow rtn_bind = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_CommonMemo_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_CommonMemo_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[MemoBtn]のボタン[copy]の押下時の処理
	 */
	@Override
	public void doMemoBtn_copy(MCEventInfo info) {
		MemoListR r = MemoListTable.getSelectedMCRow();
		if (r != null) {
			MemoListR add = r.clone();
			add.setStatus(MCRow.CREATE);
			MemoListTable.insertRow(add);
		}
	}
	/**
	 * [FS_FSBAL0150_Upd03]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Upd03Caller<P extends FSBAP_CommonMemo, B extends FS_FSBAL0150_Upd03Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected FS_FSBAL0150_Upd03Caller(P p, B b) {
			super(p, b);
		}
		
		@Override
		protected void beforeCall() {
			super.beforeCall();
			setMemoKey(true);
			String key = getMenuR().memo_key();
			for (int i = 0; i < bridge.up0().size(); i++) {
				bridge.up0().get(i).memo_key(key);
			}
		}
		
		@Override
		protected void checkForCallStack(MCMessageList msgList) {
			super.checkForCallStack(msgList);
			checkMemo(msgList);
		}
		
		/**
		 * 更新前のチェック処理<P>
		 *
		 * @param ls メッセージリスト
		 */
		protected void checkMemo(MCMessageList mls) {
			checkDuplicate(mls , MemoListTable, getCheckDuplicateCols());
		}
		
		/**
		 * キー項目の重複チェック対象のカラム名のリスト
		 * @return カラム名のリスト
		 */
		protected List<String> getCheckDuplicateCols(){
			MCColumnConfig[] cols = new MCColumnConfig[] {
					columnMemoList_locale, MemoList_extL_PPanel.columnExtL_co_cd,
					MemoList_extL_PPanel.columnExtL_attr1,
					MemoList_extL_PPanel.columnExtL_attr2,
					MemoList_extL_PPanel.columnExtL_attr3
			};
			List<String> a = new ArrayList<String>();
			for(MCColumnConfig c : cols){
				if(c.getModeInfo().getStatus() != MCMode.INVISIBLE_STATUS){
					a.add(c.getBaseRowColumnName());
				}
			}
			return a;
		}
		
		/**
		 * キー重複時のメッセージ用項目名を返します。
		 * 
		 * @return キー重複時のメッセージ用項目名
		 */
		protected String getKeyName() {
			return columnMemoList_locale.getMessageByLocale() + labelSeparator()
					+ MemoList_extL_PPanel.columnExtL_co_cd.getMessageByLocale()
					+ labelSeparator()
					+ MemoList_extL_PPanel.columnExtL_attr1.getMessageByLocale()
					+ labelSeparator()
					+ MemoList_extL_PPanel.columnExtL_attr2.getMessageByLocale()
					+ labelSeparator()
					+ MemoList_extL_PPanel.columnExtL_attr3.getMessageByLocale();
		}

		@Override
		protected void resultSuccess() {
			callFS_FSBAL0150_Srch03();
			updateCache();
		}

	}


	/**
	 * [FS_FSBAL0150_Srch03]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Srch03Caller<P extends FSBAP_CommonMemo, B extends FS_FSBAL0150_Srch03Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FS_FSBAL0150_Srch03Caller(P p, B b) {
			super(p, b);
		}
		
		@Override
		protected boolean isDownBlockChanged() {
			return false;
		}
		
		@Override
		protected boolean checkForCall() {
			boolean boo = super.checkForCall();
			if (boo) {
				MenuR r = getMenuR();
				if ((MCStringUtil.isNull(r.module_id()) ||
						MCStringUtil.isNull(r.screen_id())) &&
					MCStringUtil.isNull(r.menu_index())){
					boo =  false;
				}
			}
			return boo;
		}
		
		
		@Override
		protected void initCaller() {
			super.initCaller();
			setMemoKey(false);
		}
		
		@Override
		protected void setMode() {
			super.setMode();
			
			if (getMemoListL().size() > 0) {
				setLocaleName(getMemoListL());
				
				focusToMemoListTable();
			}
		}

		@Override
		protected void moveFocus() {
			super.moveFocus();
			
			focusToMemoListTable();
		}
		
		@Override
		protected void moveFocusNoDown() {
			super.moveFocusNoDown();
			
			focusToMemoListTable();
		}

		@Override
		protected void show() {
			super.show();
			MemoListTable.fillSpace();
		}
		
		@Override
		protected void setModeNoDown() {
			super.setModeNoDown();
			MemoListTable.fillSpace();
		}				
	
		@Override
		protected void showNoDownDataMsg() {
		}

		protected void focusToMemoListTable() {
			MemoListTable.selectLeftmostColumn(0);
		}
	}

	/**
	 * メモキーを設定します。
	 *
	 * @param update メニューINDEXを発行する場合は、true
	 */
	protected void setMemoKey(boolean update) {
		String key = null;
		MenuR r = getMenuR();
		if (!MCStringUtil.isNull(r.module_id()) &&
				!MCStringUtil.isNull(r.screen_id())) {
			key = FSBAP0200.createMemoKey(r.module_id(), r.screen_id());
		}
		else {
			if (MCStringUtil.isNull(r.menu_index()) && update) {
				//インデックス登録
				mcframe.clientCore.beans.menu.requester.MenuR ir =
					mcframe.clientCore.beans.menu.requester.MenuR.create();
				mcframe.clientCore.beans.menu.requester.MenuR or = null;
				ir.parent_menu_id(r.parent_menu_id());
				ir.menu_id(r.menu_id());
				ir.menu_order(r.menu_order());
				ir.co_cd(r.co_cd());
				ir.ext_attr1(r.ext_attr1());
				ir.ext_attr2(r.ext_attr2());
				ir.ext_attr3(r.ext_attr3());
			
				or = MCMenuBeansUtil.updateMenuIndex(ir);
				if (or != null) {
					r.menu_index(or.menu_index());
				}
			}
			key = FSBAP0200.createMemoKey(r.menu_index());
		}
		r.memo_key(key);
	}
	


	/**
	 * Panel[MemoBtn]のボタン[add]の押下時の処理
	 */
	@Override
	public void doMemoBtn_add(MCEventInfo info) {
		MemoListTable.insertRow();
	}
	/**
	 * Panel[MemoBtn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doMemoBtn_del(MCEventInfo info) {
		MemoListTable.deleteRow();
		if (MemoListTable.getRowCount() == 0) {
			Memo_memo.setMode(MCMode.READ_ONLY);
		}
		else{
			MCRow r = MemoListTable.getSelectedMCRow();
			if (r != null && r.isStatusDelete()) {
				Memo_memo.setMode(MCMode.READ_ONLY);
			}
			else{
				Memo_memo.setMode(MCMode.ENABLE);
			}
		}
	}
	
	/**
	 * Panel[Command]のボタン[update]の押下時の処理
	 */
	@Override
	public void doCommand_update(MCEventInfo info) {
		callFS_FSBAL0150_Upd03();
	}
	
	/**
	 * メモ情報のキャッシュを更新します。
	 *
	 */
	protected void updateCache() {
		MCIndexKey key = getMemoListL().createIndex(
				MemoListR.$locale_cd,
				MCRow.createColumnPath(MemoListR.$extL, "co_cd"),
				MCRow.createColumnPath(MemoListR.$extL, "attr1"),
				MCRow.createColumnPath(MemoListR.$extL, "attr2"),
				MCRow.createColumnPath(MemoListR.$extL, "attr3"));
		MCList<MemoListR> temp = getMemoListL().subList(key,
				MCSys.user.locale().toString(),
				MCSys.user.coCD(), 
				MCSys.user.extattr1(), 
				MCSys.user.extattr2(), 
				MCSys.user.extattr2());
		MCMemoCache c = MCCache.getInstance().getCommonMemoCache();
		for (int i = 0; i < temp.size(); i++) {
			MemoListR r = temp.get(i);
			c.put(r.memo_key(), r.memo(), r.getRefTime(), r.upd_cntr());
		}
		
		if (rtn_bind != null) {
			rtn_bind.setStringNE("menu_index", getMenuR().menu_index());
		}
	}
	
	/**
	 * 他画面から呼び出された場合の初期化を実装します。<br>
	 * <P>
	 * <P>
	 * <li>起動タイプ：T1<br>
	 * バインド値 ＜必須＞<br>
	 * 検索条件を指定してください。各項目画面の検索条件と同じです。
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>parent_menu_id</td>
	 * <td>String</td>
	 * <td>親メニューID</td>
	 * </tr>
	 * <tr>
	 * <td>menu_id</td>
	 * <td>String</td>
	 * <td>メニューID</td>
	 * </tr>
	 * <tr>
	 * <td>menu_order</td>
	 * <td>String</td>
	 * <td>メニュー順序</td>
	 * </tr>
	 * <tr>
	 * <td>co_cd</td>
	 * <td>String</td>
	 * <td>会社ＣＤ</td>
	 * </tr>
	 * <tr>
	 * <td>ext_attr1</td>
	 * <td>String</td>
	 * <td>拡張属性１</td>
	 * </tr>
	 * <tr>
	 * <td>ext_attr2</td>
	 * <td>String</td>
	 * <td>拡張属性２</td>
	 * </tr>
	 * <tr>
	 * <td>ext_attr3</td>
	 * <td>String</td>
	 * <td>拡張属性３</td>
	 * </tr>
	 * <tr>
	 * <td>module_id</td>
	 * <td>String</td>
	 * <td>モジュールID</td>
	 * </tr>
	 * <tr>
	 * <td>screen_id</td>
	 * <td>String</td>
	 * <td>画面ID</td>
	 * </tr>
	 * <tr>
	 * <td>menu_index</td>
	 * <td>String</td>
	 * <td>メニューインデックス</td>
	 * </tr>
	 * <tr>
	 * <td>tilte</td>
	 * <td>String</td>
	 * <td>タイトル</td>
	 * </tr>
	 * <tr>
	 * <td>use_ext</td>
	 * <td>boolean</td>
	 * <td>拡張属性使用有無</td>
	 * </tr>
	 * </table><br>
	 * その他の引数：なし</li>
	 * </P>
	 * 
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他の引数
	 *       </P>
	 */
	public void initByScreenParam(String openTyp, MCRow bind,
										Object... args) {
		super.initTrace(this, "initByScreenParam");
		if (openTyp == T1) {
			if (bind != null) {
				rtn_bind = bind;
				
				MenuR r = getMenuR();
				r.parent_menu_id(bind.getStringNE("parent_menu_id"));
				r.menu_id(bind.getStringNE("menu_id"));
				r.menu_order(bind.getNumberNE("menu_order"));
				r.co_cd(bind.getStringNE("co_cd"));
				r.ext_attr1(bind.getStringNE("ext_attr1"));
				r.ext_attr2(bind.getStringNE("ext_attr2"));
				r.ext_attr3(bind.getStringNE("ext_attr3"));
				r.module_id(bind.getStringNE("module_id"));
				r.screen_id(bind.getStringNE("screen_id"));
				r.menu_index(bind.getStringNE("menu_index"));
				r.title(bind.getStringNE("title"));
				r.use_ext(bind.getBooleanNE("use_ext"));

				if (!MCStringUtil.isNull(r.co_cd())
						|| !MCStringUtil.isNull(r.ext_attr1())
						|| !MCStringUtil.isNull(r.ext_attr2())
						|| !MCStringUtil.isNull(r.ext_attr3())) {

					r.use_ext(true);
					setEXTStatus();
				}				
			}
			callFS_FSBAL0150_Srch03();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}	

	@Override
	protected void listInit() {
		super.listInit();
		
		// ロケール
		getMemoList_locale_cd_ListPutter().setColumns(
										FSUAP_List.LocaleCols.$o_lcl_cd,
										FSUAP_List.LocaleCols.$o_lcl_nm);
	}	
	/**
	 * ソート順の設定
	 */
	protected void setSortColumn() {
		super.setSortColumn();
		MemoListTable.addSortColumn(columnMemoList_locale_cd, MCList.SortType.ASC);
		MemoListTable.addSortColumn(MemoList_extL_PPanel.columnExtL_co_cd, MCList.SortType.ASC);
		MemoListTable.addSortColumn(MemoList_extL_PPanel.columnExtL_attr1, MCList.SortType.ASC);
		MemoListTable.addSortColumn(MemoList_extL_PPanel.columnExtL_attr2, MCList.SortType.ASC);
		MemoListTable.addSortColumn(MemoList_extL_PPanel.columnExtL_attr3, MCList.SortType.ASC);
		
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		MemoListTable.fillSpace();
	}
	@Override
	public void doMemoList_NC(MCEventInfo info){
		MemoListR r = MemoListTable.getSelectedMCRow();
		if (r != null) {
			getMemoR().memo(r.memo());
			if (r.isStatusDelete()) {
				Memo_memo.setMode(MCMode.READ_ONLY);
			}
			else{
				Memo_memo.setMode(MCMode.ENABLE);
			}
		}
		else{
			Memo_memo.setMode(MCMode.READ_ONLY);
		}
	}	
	
	
	@Override
	public void doMemoList_locale_cd_NC(MCEventInfo info){
		if (getMenuR().use_ext()) {
			MemoListR r = MemoListTable.getSelectedMCRow();
			if (r != null) {
				setExt(r);
			}
		}
	}
	
	/**
	 * ユーザ属性を設定します。
	 * 
	 * @param r 設定対象のロウ
	 */
	protected void setExt(MemoListR r) {
		setValueEx(columnMemoList_co_cd, r.getGUIIndex(), getMenuR().co_cd());
		setValueEx(columnMemoList_attr1, r.getGUIIndex(), getMenuR().ext_attr1());
		setValueEx(columnMemoList_attr2, r.getGUIIndex(), getMenuR().ext_attr2());
		setValueEx(columnMemoList_attr3, r.getGUIIndex(), getMenuR().ext_attr3());
	}
	
	@Override
	public void doMemo_memo_NC(mcframe.clientCore.event.MCEventInfo info) {
		super.doMemo_memo_NC(info);
		
		MemoListR r = MemoListTable.getSelectedMCRow();
		if (r != null) {
			r.memo(getMemoR().memo());
			if (r.isStatusGUICreate() || MCStringUtil.isNull(r.memo_key())) {
				r.setStatus(MCRow.CREATE);
			}
			else{
				r.setStatus(MCRow.MODIFY);
			}
			if (getMenuR().use_ext()) {
				setExt(r);
			}
		}
	}

	
	/**
	 * ロケールの名称のセットを行います。<P>
	 */
	protected void setLocaleName(MCList<MemoListR> memoL) {
		MCList<MCRow> ls = MCConfig.client.getEntryLocaleList(
										MemoListR.$locale_cd, MemoListR.$locale);
		for (int i = 0; i < memoL.size(); i++) {
			MemoListR r = memoL.get(i);
			MCList<MCRow> sub = ls.subList(MemoListR.$locale_cd, r.locale_cd());
			if (sub.size() > 0) {
				r.locale(sub.getString(0, MemoListR.$locale));
			}
		}
	}
	
	@Override
	public boolean beforeOpen() {
		if (!super.beforeOpen()) {
			return false;
		}

		// 画面のセンタリング
		if (!isPartsPanel()) {
			setArrangementCenter();
		}

		return true;
	}	
	
	
	/**
	 * メモ情報をロードします。 
	 *
	 * @param mid モジュールID
	 * @param sid 画面ID
	 * @param title タイトル
	 * @param use_ext 拡張属性使用有無
	 */
	public void loadScreenMemo(String mid,	String sid,  
			String title, boolean use_ext) {
		
		if (mid == null) {
			getMenuR().clear();
			getMemoListL().clear();
			getMemoR().clear();
			setNOEDITStatus();
			return;
		}
		
		MenuR r = getMenuR();
		r.module_id(mid);
		r.screen_id(sid);

		r.title(title);
		r.use_ext(use_ext);
		
		if (use_ext) {
			r.co_cd(MCSys.user.coCD());
			r.ext_attr1(MCSys.user.extattr1());
			r.ext_attr2(MCSys.user.extattr2());
			r.ext_attr3(MCSys.user.extattr3());
			
		}
		
		callFS_FSBAL0150_Srch03();
		
		if (use_ext) {
			setEXTStatus();
		}
		else{
			setINITStatus();
		}
	}

}