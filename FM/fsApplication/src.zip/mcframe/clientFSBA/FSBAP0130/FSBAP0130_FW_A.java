package mcframe.clientFSBA.FSBAP0130;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0130"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0130_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0130";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Dialog]ブロック関連のField定義
	public MCPanel DialogPanel = null;
	// [Dialog]ブロックの項目のField定義
	/**
	 * アイコン .<p>
	 *
	 */
	public MCLabel Dialog_Icon = null;
	public MCScrollPane Dialog_MessageScrollPane = null;
	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public MCTextArea Dialog_Message = null;
	/**
	 * 了解 了解.<p>
	 *
	 */
	public MCButton Dialog_OK = null;
	/**
	 * はい はい.<p>
	 *
	 */
	public MCButton Dialog_Yes = null;
	/**
	 * いいえ いいえ.<p>
	 *
	 */
	public MCButton Dialog_No = null;
	/**
	 * キャンセル キャンセル.<p>
	 *
	 */
	public MCButton Dialog_Cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [OK]モードを表す定数 */
	public static final String OK = "OK";
	/** [Y_N]モードを表す定数 */
	public static final String Y_N = "Y_N";
	/** [Y_N_C]モードを表す定数 */
	public static final String Y_N_C = "Y_N_C";
	/** [O_C]モードを表す定数 */
	public static final String O_C = "O_C";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, OK, Y_N, Y_N_C, O_C};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Dialog]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0130.DialogR aDialogR;

	/**
	 * 項目コピーによってaDialogRを設定します。
	 *
	 * aDialogRのインスタンスは変更されません。
	 *
	 * @param row DialogR
	 */
	public void setDialogR(mcframe.clientFSBA.FSBAP0130.DialogR row) {
		if (row != null) {
			MCRow.copyall(getDialogR(), row);
		}
	}

	/**
	 * [Dialog]ブロックのコンテナaDialogRを返します。
	 *
	 * @return DialogR
	 */
	public mcframe.clientFSBA.FSBAP0130.DialogR getDialogR() {
		return aDialogR;
	}

	/**
	 * aDialogRを作成します。
	 *
	 * @return DialogR
	 */
	public mcframe.clientFSBA.FSBAP0130.DialogR createDialogR() {
		return mcframe.clientFSBA.FSBAP0130.DialogR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getDialogR())) ret.add(getDialogR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getDialogR()) return "Dialog";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Dialog")) return getDialogR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(DialogPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0130_FW_A() {
		aDialogR = createDialogR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0130_FW_A(mcframe.clientFSBA.FSBAP0130.DialogR row){
		aDialogR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0130_FW.jbCreateDialog((FSBAP0130)this);
	}

	/**
	 * [Dialog]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDialog(FSBAP0130 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FSBAP0130 create(mcframe.clientFSBA.FSBAP0130.DialogR row){
		FSBAP0130 p = new FSBAP0130(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0130 create(){
		FSBAP0130 p = new FSBAP0130();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0130_FW.jbfInitDialog((FSBAP0130)this);
		FSBAP0130_FW.jbInitDialog((FSBAP0130)this);
	}

	/**
	 * [Dialog]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDialog(FSBAP0130 p) {
		// ブロック関連の初期化
		p.DialogPanel = p.beansFactory.createPanel("Dialog");
		// ブロックの項目の初期化
		p.Dialog_Icon = p.beansFactory.createLabel("Dialog.Icon");
		p.Dialog_MessageScrollPane = p.beansFactory.createScrollPane("Dialog.Messagescroll");
		p.Dialog_Message = p.beansFactory.createTextArea("Dialog.Message");
		p.Dialog_OK = p.beansFactory.createButton("Dialog.OK");
		p.Dialog_Yes = p.beansFactory.createButton("Dialog.Yes");
		p.Dialog_No = p.beansFactory.createButton("Dialog.No");
		p.Dialog_Cancel = p.beansFactory.createButton("Dialog.Cancel");
	}

	/**
	 * [Dialog]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDialog(FSBAP0130 p) {
		// ブロック関連の初期化
		p.add(p.DialogPanel);
		p.setLastBeans(p.DialogPanel);
		p.DialogPanel.setValueCheck(false);
		p.DialogPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.DialogPanel.add(p.Dialog_Icon);
		p.Dialog_MessageScrollPane.getViewport().add(p.Dialog_Message);
		p.DialogPanel.add(p.Dialog_MessageScrollPane);
		p.DialogPanel.setLastBeans(p.Dialog_Message);
		p.Dialog_Message.setNextBeans(p.Dialog_OK);
		p.Dialog_Message.setRow(p.getDialogR(), mcframe.clientFSBA.FSBAP0130.DialogR.Message_META);
		p.DialogPanel.add(p.Dialog_OK);
		p.Dialog_OK.setNextBeans(p.Dialog_Yes);
		p.DialogPanel.add(p.Dialog_Yes);
		p.Dialog_Yes.setNextBeans(p.Dialog_No);
		p.DialogPanel.add(p.Dialog_No);
		p.Dialog_No.setNextBeans(p.Dialog_Cancel);
		p.DialogPanel.add(p.Dialog_Cancel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0130_FW.mcInitDialog((FSBAP0130)this);

		// [INIT]ステータスのモードの設定
		FSBAP0130_FW.statusInitINIT_Dialog((FSBAP0130)this);

		// [OK]ステータスのモードの設定
		FSBAP0130_FW.statusInitOK_Dialog((FSBAP0130)this);

		// [Y_N]ステータスのモードの設定
		FSBAP0130_FW.statusInitY__N_Dialog((FSBAP0130)this);

		// [Y_N_C]ステータスのモードの設定
		FSBAP0130_FW.statusInitY__N__C_Dialog((FSBAP0130)this);

		// [O_C]ステータスのモードの設定
		FSBAP0130_FW.statusInitO__C_Dialog((FSBAP0130)this);

	}

	/**
	 *  [Dialog]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDialog(FSBAP0130 p) {
		p.Dialog_Message.addAllListener(p);
		p.Dialog_OK.addAllListener(p);
		p.Dialog_OK.setAPMethodName("doDialog_OK");
		p.Dialog_Yes.addAllListener(p);
		p.Dialog_Yes.setAPMethodName("doDialog_Yes");
		p.Dialog_No.addAllListener(p);
		p.Dialog_No.setAPMethodName("doDialog_No");
		p.Dialog_Cancel.addAllListener(p);
		p.Dialog_Cancel.setAPMethodName("doDialog_Cancel");
	}

	/**
	 * [INIT]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dialog(FSBAP0130 p){
		p.Dialog_Message.putMode(p, INIT, MCMode.READ_ONLY);
		p.Dialog_OK.putMode(p, INIT, MCMode.ENABLE);
		p.Dialog_Yes.putMode(p, INIT, MCMode.ENABLE);
		p.Dialog_No.putMode(p, INIT, MCMode.ENABLE);
		p.Dialog_Cancel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [OK]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitOK_Dialog(FSBAP0130 p){
		p.Dialog_Message.putMode(p, OK, MCMode.READ_ONLY);
		p.Dialog_OK.putMode(p, OK, MCMode.ENABLE);
		p.Dialog_Yes.putMode(p, OK, MCMode.INVISIBLE);
		p.Dialog_No.putMode(p, OK, MCMode.INVISIBLE);
		p.Dialog_Cancel.putMode(p, OK, MCMode.INVISIBLE);

	}

	/**
	 * [Y_N]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitY__N_Dialog(FSBAP0130 p){
		p.Dialog_Message.putMode(p, Y_N, MCMode.READ_ONLY);
		p.Dialog_OK.putMode(p, Y_N, MCMode.INVISIBLE);
		p.Dialog_Yes.putMode(p, Y_N, MCMode.ENABLE);
		p.Dialog_No.putMode(p, Y_N, MCMode.ENABLE);
		p.Dialog_Cancel.putMode(p, Y_N, MCMode.INVISIBLE);

	}

	/**
	 * [Y_N_C]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitY__N__C_Dialog(FSBAP0130 p){
		p.Dialog_Message.putMode(p, Y_N_C, MCMode.READ_ONLY);
		p.Dialog_OK.putMode(p, Y_N_C, MCMode.INVISIBLE);
		p.Dialog_Yes.putMode(p, Y_N_C, MCMode.ENABLE);
		p.Dialog_No.putMode(p, Y_N_C, MCMode.ENABLE);
		p.Dialog_Cancel.putMode(p, Y_N_C, MCMode.ENABLE);

	}

	/**
	 * [O_C]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitO__C_Dialog(FSBAP0130 p){
		p.Dialog_Message.putMode(p, O_C, MCMode.READ_ONLY);
		p.Dialog_OK.putMode(p, O_C, MCMode.ENABLE);
		p.Dialog_Yes.putMode(p, O_C, MCMode.INVISIBLE);
		p.Dialog_No.putMode(p, O_C, MCMode.INVISIBLE);
		p.Dialog_Cancel.putMode(p, O_C, MCMode.ENABLE);

	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[OK]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setOKStatus() {
		status = OK;
		setAllStatus(status);
	}

	/**
	 * この画面を[Y_N]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setY_NStatus() {
		status = Y_N;
		setAllStatus(status);
	}

	/**
	 * この画面を[Y_N_C]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setY_N_CStatus() {
		status = Y_N_C;
		setAllStatus(status);
	}

	/**
	 * この画面を[O_C]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setO_CStatus() {
		status = O_C;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (OK.equals(status)) {
			setOKStatus();
		}
		else if (Y_N.equals(status)) {
			setY_NStatus();
		}
		else if (Y_N_C.equals(status)) {
			setY_N_CStatus();
		}
		else if (O_C.equals(status)) {
			setO_CStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Dialog_OK) doDialog_OK(info);
		else if (ap == Dialog_Yes) doDialog_Yes(info);
		else if (ap == Dialog_No) doDialog_No(info);
		else if (ap == Dialog_Cancel) doDialog_Cancel(info);
	}

	/**
	 * [Dialog]パネルの[OK]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDialog_OK(MCEventInfo info);

	/**
	 * [Dialog]パネルの[Yes]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDialog_Yes(MCEventInfo info);

	/**
	 * [Dialog]パネルの[No]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDialog_No(MCEventInfo info);

	/**
	 * [Dialog]パネルの[Cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDialog_Cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Dialog_Message) return doDialog_Message_VC(info);
		return true;
	}

	/**
	 * [Dialog]パネルの[Message]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDialog_Message_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Dialog_Message) doDialog_Message_NC(info);
	}

	/**
	 * [Dialog]パネルの[Message]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_Message_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Dialog_Message) doDialog_Message_NE(info);
	}

	/**
	 * [Dialog]パネルの[Message]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_Message_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Dialog_Message) doDialog_Message_NX(info);
	}

	/**
	 * [Dialog]パネルの[Message]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_Message_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}