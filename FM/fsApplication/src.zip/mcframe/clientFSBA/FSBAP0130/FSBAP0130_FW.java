package mcframe.clientFSBA.FSBAP0130;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import mcframe.clientCore.beans.message.MCDialogPanel;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.message.MCDialogInfo;
import mcframe.clientCore.beans.popup.MCPopupBeans;

import mcframe.clientFSBA.FSBAP0040.FSBAP0040;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;

import mcframe.clientCore.beans.layout.MCGeneralLayout;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0130"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0130_FW extends FSBAP0130_FW_A implements MCDialogPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * ユーザが選択したボタンを表す定数
	 */
	private int result = MCMessageBox.CLOSE_OPTION;

	/**
	 * ボタンの推奨サイズを計算するためのテキストフィールド
	 */
	private final JTextField field = new JTextField();

	/**
	 * ダイアログ情報
	 */
	private MCDialogInfo info = null;

	/**
	 * 幅の最小値
	 */
	private int minWidth = 250;

	/**
	 * 高さの最小値
	 */
	private int minHeight = 0;

	private String _msg_id = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0130_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0130_FW(mcframe.clientFSBA.FSBAP0130.DialogR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Dialog START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Dialog END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	// 7.0.1 _msg_idを取り出す。
	// 7.0.2 再自動生成すると消滅するため移動
	public String getMsgID() {
		return _msg_id;
	}

	/**
	 * Panel[Dialog]のボタン[OK]の押下時の処理
	 */
	public void doDialog_OK(MCEventInfo info) {
		doButtonAction(MCMessageBox.OK_OPTION);
	}

	/**
	 * Panel[Dialog]のボタン[Yes]の押下時の処理
	 */
	public void doDialog_Yes(MCEventInfo info) {
		doButtonAction(MCMessageBox.YES_OPTION);
	}

	/**
	 * Panel[Dialog]のボタン[No]の押下時の処理
	 */
	public void doDialog_No(MCEventInfo info) {
		doButtonAction(MCMessageBox.NO_OPTION);
	}

	/**
	 * Panel[Dialog]のボタン[Cancel]の押下時の処理
	 */
	public void doDialog_Cancel(MCEventInfo info) {
		doButtonAction(MCMessageBox.CANCEL_OPTION);
	}

	/**
	 * ボタンアクションを実行します。
	 *
	 * @param option 選択したボタンを表す定数
	 */
	protected void doButtonAction(int option) {
		result = option;
		requestCloseWindow();
	}

	@Override
	public void customInit() {
		super.customInit();
		DialogPanel.setOpaque(true);//背景色を有効にする
		Dialog_Message.setBorder(null);
		Dialog_MessageScrollPane.setBorder(null);

		Dialog_MessageScrollPane.setOpaque(false);
		for (JComponent c : MCBeansUtil.getAllComponents(
				JComponent.class, Dialog_MessageScrollPane)) {
			c.setOpaque(false);
		}

		setValueCheck(false);

		Dialog_Yes.setMnemonic(java.awt.event.KeyEvent.VK_Y);
		Dialog_No.setMnemonic(java.awt.event.KeyEvent.VK_N);
	}

	@Override
	public boolean beforeOpen() {
		boolean rslt = super.beforeOpen();
		if (rslt) {
			setParentPanelFocus();
		}
		return rslt;
	}

	@Override
	public void afterOpen() {
		super.afterOpen();
		setInitFocus(getDialogInfo().getFocusButton());
	}

	@Override
	public void panelClosed() {
		super.panelClosed();
		setDialogInfo(null);
	}

	public int getResultOption() {
		return result;
	}

	public void setMessage(MCDialogInfo info) {
		setINITStatus();
		setDialogInfo(info);
		setFrameTitle(info.getTitle());
		MCMessage msg = info.getMessage();
		if (msg != null) {
			setMessage(msg, info.getIcon());
		} else {
			setMessage(
					FSBAP0040.formatMessage("develop", info.getDevelopMessage()),
					info.getIcon());
		}
		switch (info.getDialogType()) {
			case MCMessageBox.YES_NO_DIALOG:
				init_YES_NO_Type();
				break;
			case MCMessageBox.OK_DIALOG:
				init_OK_Type();
				break;
			case MCMessageBox.NO_YES_DIALOG:
				init_NO_YES_Type();
				break;
			case MCMessageBox.OK_CANCEL_DIALOG:
				init_OK_CANCEL_Type();
				break;
			//#7033-1679 YES_NO_CANCEL_DIALOG追加
			case MCMessageBox.YES_NO_CANCEL_DIALOG:
				init_YES_NO_CANCEL_Type();
				break;
		}

		result = MCMessageBox.CLOSE_OPTION;
	}

	/**
	 * メッセージを表示します。
	 *
	 * @param msg メッセージ
	 */
	protected void setMessage(MCMessage msg, Icon icon) {
		_msg_id = msg.getID();
		setMessage(FSBAP0040.formatMessage(msg.getID(), msg.toString()), icon);
	}

	/**
	 * メッセージを表示します。
	 *
	 * @param msg メッセージ
	 * @param icon アイコン
	 */
	protected void setMessage(String msg, Icon icon) {

		Dialog_Icon.setIcon((Icon)null);

		int[] i_bounds = MCBeansUtil.getBounds(Dialog_Icon);
		int i_width = i_bounds[2];
		int i_height = i_bounds[3];
		if (i_width <= 0) {
			i_width = icon.getIconWidth();
		}
		if (i_height <= 0) {
			i_height = icon.getIconHeight();
		}

		Dialog_Icon.setIcon(icon);

		Dialog_Icon.setBounds(10, 10, i_width, i_height);


		Dialog_MessageScrollPane.setLocation(
				Dialog_Icon.getLocation().x + Dialog_Icon.getSize().width + 10, 10);

		Dialog_Message.setValue(msg);
		Dimension size = Dialog_Message.getPreferredSize();

		int[] bounds = MCBeansUtil.getBounds(this);
		int m_width = bounds[2];
		int m_height = bounds[3];
		if (m_width < 0) {
			m_width = 640;
		}
		if (m_height < 0) {
			m_height = 480;
		}
		if (size.width > m_width - 60) {
			size.width = m_width - 60;
		}
		if (size.height > m_height - 50) {
			size.height = m_height - 50;
		}

		Dimension s_size = Dialog_MessageScrollPane.getPreferredSize();
		int s_x = Dialog_MessageScrollPane.getLocation().x + s_size.width;
		int m_x = minWidth - s_x;
		if (m_x > 0) {
			s_size.width+=m_x;
		}
		Dialog_MessageScrollPane.setSize(s_size);
	}

	/**
	 * [OK] ダイアログを表示するための設定を行います。
	 */
	protected void init_OK_Type() {
		setStatus(OK);
		int i_h = Dialog_Icon.getLocation().y + Dialog_Icon.getHeight() + 5;
		int m_h = Dialog_MessageScrollPane.getLocation().y + Dialog_MessageScrollPane.getHeight() + 5;
		int y = Math.max(i_h, m_h);

		Dimension size = getButtonSize(Dialog_OK);

		int b_w = size.width + 10;
		int m_w = Dialog_MessageScrollPane.getLocation().x + Dialog_MessageScrollPane.getWidth() + 5;

		int p_w = Math.max(b_w, m_w);
		int x = (p_w / 2) - (size.width / 2);
		Dialog_OK.setBounds(x, y, size.width, size.height);

		int p_h = y + Dialog_OK.getSize().height + 5;

		p_w = Math.max(p_w, minWidth);
		p_h = Math.max(p_h, minHeight);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// DialogPanel.setBounds(0, 0, p_w, p_h);
		// setBounds(0, 0, p_w, p_h);

		setPreferredSizeToFrame(new Dimension(p_w, p_h));

		// getFrame().pack();

		setArrangementCenter();

		Dialog_OK.setNextBeans(null);
	}

	/**
	 * [YES]/[NO] ダイアログを表示するための設定を行います。
	 */
	protected void init_YES_NO_Type() {
		setStatus(Y_N);
		int i_h = Dialog_Icon.getLocation().y + Dialog_Icon.getHeight() + 5;
		int m_h = Dialog_MessageScrollPane.getLocation().y + Dialog_MessageScrollPane.getHeight() + 5;
		int y = Math.max(i_h, m_h);

		Dimension y_size = getButtonSize(Dialog_Yes);
		Dimension n_size = getButtonSize(Dialog_No);

		int b_w = y_size.width + n_size.width + 15;
		int m_w = Dialog_MessageScrollPane.getLocation().x + Dialog_MessageScrollPane.getWidth() + 5;

		int p_w = Math.max(b_w, m_w);
		int y_x = (p_w - 5) / 2 - y_size.width;
		Dialog_Yes.setBounds(y_x, y, y_size.width, y_size.height);
		int n_x = (p_w + 5) / 2;
		Dialog_No.setBounds(n_x, y, n_size.width, n_size.height);

		int p_h = y + Dialog_Yes.getSize().height + 5;

		p_w = Math.max(p_w, minWidth);
		p_h = Math.max(p_h, minHeight);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// DialogPanel.setBounds(0, 0, p_w, p_h);
		// setBounds(0, 0, p_w, p_h);

		setPreferredSizeToFrame(new Dimension(p_w, p_h));

		// getFrame().pack();

		setArrangementCenter();

		Dialog_Message.setNextBeans(Dialog_Yes);
		Dialog_Yes.setNextBeans(Dialog_No);
		Dialog_No.setNextBeans(null);
	}

	/**
	 * [NO]/[YES] ダイアログを表示するための設定を行います。
	 */
	protected void init_NO_YES_Type() {
		setStatus(Y_N);
		int i_h = Dialog_Icon.getLocation().y + Dialog_Icon.getHeight() + 5;
		int m_h = Dialog_MessageScrollPane.getLocation().y + Dialog_MessageScrollPane.getHeight() + 5;
		int y = Math.max(i_h, m_h);

		Dimension n_size = getButtonSize(Dialog_No);
		Dimension y_size = getButtonSize(Dialog_Yes);

		int b_w = n_size.width + y_size.width + 15;
		int m_w = Dialog_MessageScrollPane.getLocation().x + Dialog_MessageScrollPane.getWidth() + 5;

		int p_w = Math.max(b_w, m_w);
		int n_x = (p_w - 5) / 2 - n_size.width;
		Dialog_No.setBounds(n_x, y, n_size.width, n_size.height);
		int y_x = (p_w + 5) / 2;
		Dialog_Yes.setBounds(y_x, y, y_size.width, y_size.height);

		int p_h = y + Dialog_No.getSize().height + 5;

		p_w = Math.max(p_w, minWidth);
		p_h = Math.max(p_h, minHeight);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// DialogPanel.setBounds(0, 0, p_w, p_h);
		// setBounds(0, 0, p_w, p_h);

		setPreferredSizeToFrame(new Dimension(p_w, p_h));

		// getFrame().pack();

		setArrangementCenter();

		Dialog_Message.setNextBeans(Dialog_No);
		Dialog_No.setNextBeans(Dialog_Yes);
		Dialog_Yes.setNextBeans(null);
	}

	/**
	 * [OK]/[CANCEL] ダイアログを表示するための設定を行います。
	 */
	protected void init_OK_CANCEL_Type() {
		setStatus(O_C);
		int i_h = Dialog_Icon.getLocation().y + Dialog_Icon.getHeight() + 5;
		int m_h = Dialog_MessageScrollPane.getLocation().y + Dialog_MessageScrollPane.getHeight() + 5;
		int y = Math.max(i_h, m_h);

		Dimension o_size = getButtonSize(Dialog_OK);
		Dimension c_size = getButtonSize(Dialog_Cancel);

		int b_w = o_size.width + c_size.width + 15;
		int m_w = Dialog_MessageScrollPane.getLocation().x + Dialog_MessageScrollPane.getWidth() + 5;

		int p_w = Math.max(b_w, m_w);
		int o_x = (p_w - 5) / 2 - o_size.width;
		Dialog_OK.setBounds(o_x, y, o_size.width, o_size.height);
		int c_x = (p_w + 5) / 2;
		Dialog_Cancel.setBounds(c_x, y, c_size.width, c_size.height);

		int p_h = y + Dialog_OK.getSize().height + 5;

		p_w = Math.max(p_w, minWidth);
		p_h = Math.max(p_h, minHeight);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// DialogPanel.setBounds(0, 0, p_w, p_h);
		// setBounds(0, 0, p_w, p_h);

		setPreferredSizeToFrame(new Dimension(p_w, p_h));

		// getFrame().pack();

		setArrangementCenter();

		Dialog_Message.setNextBeans(Dialog_OK);
		Dialog_OK.setNextBeans(Dialog_Cancel);
		Dialog_Cancel.setNextBeans(null);
	}

	/**
	 * [YES]/[NO]/[CANCEL] ダイアログを表示するための設定を行います。
	 */
	protected void init_YES_NO_CANCEL_Type() {
		setStatus(Y_N_C);
		int i_h = Dialog_Icon.getLocation().y + Dialog_Icon.getHeight() + 5;
		int m_h = Dialog_MessageScrollPane.getLocation().y + Dialog_MessageScrollPane.getHeight() + 5;
		int y = Math.max(i_h, m_h);

		Dimension y_size = getButtonSize(Dialog_Yes);
		Dimension n_size = getButtonSize(Dialog_No);
		Dimension c_size = getButtonSize(Dialog_Cancel);
		//#7033-1679 サイズ調整
//		int b_w = y_size.width + n_size.width + 15;
		int b_w = y_size.width + n_size.width + c_size.width + 40;
		int m_w = Dialog_MessageScrollPane.getLocation().x + Dialog_MessageScrollPane.getWidth() + 5;

		int p_w = Math.max(b_w, m_w);
		//#7033-1679 サイズ調整
//		int y_x = (p_w - 5 - n_size.width) / 2 - y_size.width;
		int y_x = (p_w - n_size.width) / 2 - y_size.width - 10;
		Dialog_Yes.setBounds(y_x, y, y_size.width, y_size.height);
		int n_x = (p_w - n_size.width) / 2;
		Dialog_No.setBounds(n_x, y, n_size.width, n_size.height);
		//#7033-1679 サイズ調整
//		int c_x = (p_w + 5 + n_size.width) / 2;
		int c_x = (p_w + n_size.width) / 2 + 10;
		Dialog_Cancel.setBounds(c_x, y, c_size.width, c_size.height);

		int p_h = y + Dialog_Yes.getSize().height + 5;

		p_w = Math.max(p_w, minWidth);
		p_h = Math.max(p_h, minHeight);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// DialogPanel.setBounds(0, 0, p_w, p_h);
		// setBounds(0, 0, p_w, p_h);

		setPreferredSizeToFrame(new Dimension(p_w, p_h));

		// getFrame().pack();

		setArrangementCenter();

		Dialog_Message.setNextBeans(Dialog_Yes);
		Dialog_Yes.setNextBeans(Dialog_No);
		Dialog_No.setNextBeans(Dialog_Cancel);
		Dialog_Cancel.setNextBeans(null);
	}

	/**
	 * ボタンのサイズを返します。
	 *
	 * @param compo ボタン
	 * @return サイズ
	 */
	protected Dimension getButtonSize(MCButton compo) {
		String text = field.getText();
		Font font = field.getFont();
		try {
			field.setText(compo.getText());
			field.setFont(compo.getFont());
			Dimension size = field.getPreferredSize();
			int width = size.width + 30;
			int[] bounds = MCBeansUtil.getBounds(compo);
			int height = bounds[3];
			if (height <= 0) {
				height = size.height + 3;
			}
			return new Dimension(width, height);
		} finally {
			field.setText(text);
			field.setFont(font);
		}
	}

	/**
	 * 画面の推奨サイズを設定します。
	 * フレームまでの親コンポーネントの推奨サイズも合わせて変更します。
	 *
	 * @param size 推奨サイズ
	 */
	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	protected void setPreferredSizeToFrame(Dimension size) {

//		DialogPanel.setPreferredSize(size);
//		setBounds(0, 0, size.width, size.height);
//
//		removeHeaderBar();
//		removeStatusBar();

		Component compo = this;
		MCFrame frame = MCBeansUtil.getFrame(compo);
		while (compo != null) {
			if (compo != frame) {
				compo.setPreferredSize(size);
			} else {
				break;
			}
			compo = compo.getParent();
		}

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// フレームサイズを再計算する。
//		frame.setPreferredSize(null);
		frame.pack();

		setDefaultRatioSize(getBounds());

		Dialog_OK.setDefaultRatioSize(Dialog_OK.getBounds());
		Dialog_Yes.setDefaultRatioSize(Dialog_Yes.getBounds());
		Dialog_No.setDefaultRatioSize(Dialog_No.getBounds());
		// #7033-1679 高解像度ディスプレイでキャンセルボタンが表示されない不具合の対応
		Dialog_Cancel.setDefaultRatioSize(Dialog_Cancel.getBounds());

		Dialog_Icon.setDefaultRatioSize(Dialog_Icon.getBounds());

		// スクロールバー不要
		Dialog_MessageScrollPane.setHorizontalScrollBarPolicy(MCScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		Dialog_MessageScrollPane.setVerticalScrollBarPolicy(MCScrollPane.VERTICAL_SCROLLBAR_NEVER);
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// 拡大されたフレームのサイズ調整
	@Override
	public void initialized() {

		Dimension s1 = ((JDialog)getFrame()).getContentPane().getSize();
		Dimension s2 = getFrame().getSize();

		super.initialized();

		// 7013-2275(SP3高解像度対応不具合まとめ)
		// 親画面のフォント比率を継承する。
		MCBeans rp = getParentPanel();
		if (rp != null) {
			if (rp.getBaseRootPanel() != null) {
				int ratio = rp.getBaseRootPanel().getLayoutRatio();
				if (ratio != 100) {
					// 100以外のときはフォント比率を適用し拡大縮小を行う。
					MCLayouter.fontRatioChange(this, ratio);
				}
			}
		}
		// 7013-2275 ここまで

		//フレームのサイズはフォント比率と比例しない。
		// DialogPanelが丁度嵌るようにサイズ調整する。
		// フレームの枠部の幅と高さ
		int w1 = s2.width - s1.width;
		int h1 = s2.height - s1.height;

		Dimension s4 = DialogPanel.getSize();
		Dimension s3 = new Dimension(s4.width + w1, s4.height + h1);

		getFrame().setSize(s3);

		// 7013-2275(SP3高解像度対応不具合まとめ)
		// センターに移動
		setArrangementCenter();
	}

	/**
	 * 初期フォーカスを設定します。
	 *
	 * @param button ボタンを表す定数
	 */
	protected void setInitFocus(MCDialogButton button) {
		switch (button) {
			case YES:
				Dialog_Yes.mcRequestFocus();
				break;
			case NO:
				Dialog_No.mcRequestFocus();
				break;
			case OK:
				this.Dialog_OK.mcRequestFocus();
				break;
			case CANCEL:
				this.Dialog_Cancel.mcRequestFocus();
				break;
		}
	}

	/**
	 * ダイアログ情報を設定します。
	 * {@link #setMessage(MCDialogInfo)} から実行されます。
	 *
	 * @param info ダイアログ情報
	 * @see #setMessage(MCDialogInfo)
	 * @see #getDialogInfo()
	 */
	protected void setDialogInfo(MCDialogInfo info) {
		this.info = info;
	}

	/**
	 * ダイアログ情報を返します。
	 * ダイアログ情報が設定されていない場合は null を返します。
	 *
	 * @return ダイアログ情報
	 * @see #setDialogInfo(MCDialogInfo)
	 */
	public final MCDialogInfo getDialogInfo() {
		return info;
	}

	/**
	 * 親画面のフォーカスを設定します。<br>
	 * ダイアログのメッセージ（{@link MCMessage}）にエラーコンテナが設定されている場合は、
	 * エラーコンテナと連携する GUI 部品にフォーカスを移動します。
	 */
	protected void setParentPanelFocus() {
		MCRootPanel p = getParentPanel();
		if (p == null) {
			return;
		}
		MCDialogInfo i = getDialogInfo();
		if (i == null) {
			return;
		}
		p.setFocus(i.getMessage());
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected Dimension _adjistFrameSize(Dimension d) {
		// スクロールバーがでてしまうためMCRootPanelのサイズで調整する。
		if (this.getWidth() > d.width) {
			d.width = this.getWidth();
		}
		if (this.getHeight() > d.height) {
			d.height = this.getHeight();
		}
		return d;
	}
	// 7013-0007 ここまで

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	// 7013-0007 ここまで
}