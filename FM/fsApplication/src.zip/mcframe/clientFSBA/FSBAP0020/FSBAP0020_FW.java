package mcframe.clientFSBA.FSBAP0020;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.container.MCRowEvent;
import mcframe.clientCore.container.MCRowListener;

import mcframe.clientFSBA.FSBAP0000.IfSyncTableBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0020"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0020_FW extends FSBAP0020_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 土台画面です。
	 */
	protected IfSyncTableBase _panel = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0020_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0020_FW(mcframe.clientFSBA.FSBAP0020.SyncR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Sync START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Sync END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void afterOpen() {
		super.afterOpen();
		
		getSyncR().sync_flg(getMainTable().isHSyncTable());
	}
	
	@Override
	protected void valueInit() {
		super.valueInit();
		
		getSyncR().sync_flg(true);
	}
	
	@Override
	protected void listenerInit() {
		super.listenerInit();
		
		getSyncR().addRowListener(createRowListener());
	}
	
	/**
	 * ロウリスナを作成します。
	 * 
	 * @return ロウリスナ
	 */
	protected MCRowListener createRowListener() {
		return new WBPRowListener();
	}
	
	/**
	 * Panel[Sync]のボタン[sync]の押下時の処理
	 */
	public void doSync_sync(MCEventInfo info) {
		doSyncAction();
	}
	
	/**
	 * 「同期」ボタンのボタンアクションを実行します。
	 */
	protected void doSyncAction() {
		if (isSyncTable()) {
			getMainTable().doHSyncTable();
		}
	}
	
	/**
	 * テーブル同期を実行する場合は true を返します。
	 * 
	 * @return テーブル同期を実行しない場合は false
	 */
	protected boolean isSyncTable() {
		return getSyncR().sync_flg();
	}
	
	/**
	 * 同期ＦＬＧが変更されたときに実行されます。
	 */
	protected void doSyncFlgChanged() {
		getMainTable().setHSyncTable(getSyncR().sync_flg());
		doSyncAction();
	}
	
	/**
	 * テーブル同期の対象となる画面を返します。
	 * 
	 * @return 画面
	 * @throws MCAppException [FSBAC0040] この画面が埋込画面ではない場合
	 * @throws MCAppException [FSBAC0041] 土台画面が IfSyncTableBase を実装していない場合
	 */
	protected IfSyncTableBase getTargetPanel() {
		if (_panel != null) {
			return _panel;
		}
		MCRootPanel p = getBaseRootPanel();
		if (p == null || p == this) {
			throw new MCAppException(FSBAC0040, 
					getModuleID(), getScreenID(), getScreenName());
		}
		if (!(p instanceof IfSyncTableBase)) {
			throw new MCAppException(FSBAC0041, p.getModuleID(), p.getScreenID());
		}
		return _panel = (IfSyncTableBase)p;
	}
	
	/**
	 * テーブル同期の主となるテーブルを返します。
	 * 
	 * @return テーブル
	 */
	protected MCTable<?> getMainTable() {
		return getTargetPanel().getHSyncMainTable(this);
	}

	public class WBPRowListener implements MCRowListener {

		@Override
		public void valueChanged(MCRowEvent event) {
			if (SyncR.$sync_flg.equals(event.getColumn())) {
				doSyncFlgChanged();
			}
		}
	}

}