package mcframe.clientFSBA.FSBAP0810;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_SumCond"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_SumCond_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0810";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [InfoHdr]ブロック関連のField定義
	public MCPanel InfoHdrPanel = null;
	// [InfoHdr]ブロックの項目のField定義
	public MCLabel InfoHdr_cond_nm_Label = null;
	/**
	 *  集計条件名.<p>
	 *
	 */
	public MCTextField InfoHdr_cond_nm = null;
	// [InfoDtl]ブロック関連のField定義
	public MCPanel InfoDtlPanel = null;
	public MCScrollPane InfoDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0810.InfoDtlR> InfoDtlTable = null;
	// [InfoDtl]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D InfoDtl_cond_p_PPanel;
	public MCColumnConfig columnInfoDtl_disable;// [InfoDtl]の[cond_p.disable]を[columnInfoDtl_disable]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_logic_type_nm;// [InfoDtl]の[cond_p.logic_type_nm]を[columnInfoDtl_logic_type_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_logic_type;// [InfoDtl]の[cond_p.logic_type]を[columnInfoDtl_logic_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_column_nm;// [InfoDtl]の[cond_p.column_nm]を[columnInfoDtl_column_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_column_key;// [InfoDtl]の[cond_p.column_key]を[columnInfoDtl_column_key]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_data_type;// [InfoDtl]の[cond_p.data_type]を[columnInfoDtl_data_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_diff_nm;// [InfoDtl]の[cond_p.date_diff_nm]を[columnInfoDtl_date_diff_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_diff_key;// [InfoDtl]の[cond_p.date_diff_key]を[columnInfoDtl_date_diff_key]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_relative_type_nm;// [InfoDtl]の[cond_p.relative_type_nm]を[columnInfoDtl_relative_type_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_relative_type;// [InfoDtl]の[cond_p.relative_type]を[columnInfoDtl_relative_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_number;// [InfoDtl]の[cond_p.number]を[columnInfoDtl_number]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_field_type_nm;// [InfoDtl]の[cond_p.date_field_type_nm]を[columnInfoDtl_date_field_type_nm]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_field_type;// [InfoDtl]の[cond_p.date_field_type]を[columnInfoDtl_date_field_type]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date_diff;// [InfoDtl]の[cond_p.date_diff]を[columnInfoDtl_date_diff]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_date;// [InfoDtl]の[cond_p.date]を[columnInfoDtl_date]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_text;// [InfoDtl]の[cond_p.text]を[columnInfoDtl_text]としてエイリアス定義。
	public MCColumnConfig columnInfoDtl_check;// [InfoDtl]の[cond_p.check]を[columnInfoDtl_check]としてエイリアス定義。
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton InfoBtn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton InfoBtn_rdel = null;
	/**
	 *  決定する.<p>
	 *
	 */
	public MCButton InfoBtn_upd = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [MODIFY]モードを表す定数 */
	public static final String MODIFY = "MODIFY";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, MODIFY, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [InfoHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0810.InfoHdrR aInfoHdrR;
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0810.InfoDtlR> aInfoDtlL;

	/**
	 * 項目コピーによってaInfoHdrRを設定します。
	 *
	 * aInfoHdrRのインスタンスは変更されません。
	 *
	 * @param row InfoHdrR
	 */
	public void setInfoHdrR(mcframe.clientFSBA.FSBAP0810.InfoHdrR row) {
		if (row != null) {
			MCRow.copyall(getInfoHdrR(), row);
		}
	}

	/**
	 * [InfoHdr]ブロックのコンテナaInfoHdrRを返します。
	 *
	 * @return InfoHdrR
	 */
	public mcframe.clientFSBA.FSBAP0810.InfoHdrR getInfoHdrR() {
		return aInfoHdrR;
	}

	/**
	 * aInfoHdrRを作成します。
	 *
	 * @return InfoHdrR
	 */
	public mcframe.clientFSBA.FSBAP0810.InfoHdrR createInfoHdrR() {
		return mcframe.clientFSBA.FSBAP0810.InfoHdrR.create();
	}

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFSBA.FSBAP0810.InfoDtlR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0810.InfoDtlR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0810.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0810.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0810.InfoDtlR> createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0810.InfoDtlR.class);
	}

	/**
	 * InfoDtlTableを初期化します。
	 */
	protected void createInfoDtlTable(){
		if(InfoDtlTable == null){
			InfoDtlTable = beansFactory.createTable2("InfoDtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoHdrR())) ret.add(getInfoHdrR());
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoHdrR()) return "InfoHdr";
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("InfoHdr")) return getInfoHdrR();
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(InfoHdrPanel);
		ret.add(InfoDtlPanel);
		ret.add(InfoBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SumCond_FW_A() {
		aInfoHdrR = createInfoHdrR();
		aInfoDtlL = createInfoDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SumCond_FW_A(String name) {
		aInfoHdrR = createInfoHdrR();
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_SumCond_FW.jbCreateInfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbCreateInfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbCreateInfoBtn((FSBAP_SumCond)this);
	}

	/**
	 * [InfoHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoHdr(FSBAP_SumCond p) {
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP_SumCond p) {
		p.InfoDtl_cond_p_PPanel = mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.create(mcframe.clientFSBA.FSBAP0810.InfoDtlR.$cond_p);
		p.InfoDtl_cond_p_PPanel.setName("InfoDtl.cond_p");
		p.columnInfoDtl_disable = p.InfoDtl_cond_p_PPanel.columnInfoDtl_disable;
		p.columnInfoDtl_disable.addAliasName("InfoDtl.disable", p);
		p.columnInfoDtl_logic_type_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type_nm;
		p.columnInfoDtl_logic_type_nm.addAliasName("InfoDtl.logic_type_nm", p);
		p.columnInfoDtl_logic_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type;
		p.columnInfoDtl_logic_type.addAliasName("InfoDtl.logic_type", p);
		p.columnInfoDtl_column_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_nm;
		p.columnInfoDtl_column_nm.addAliasName("InfoDtl.column_nm", p);
		p.columnInfoDtl_column_key = p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_key;
		p.columnInfoDtl_column_key.addAliasName("InfoDtl.column_key", p);
		p.columnInfoDtl_data_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_data_type;
		p.columnInfoDtl_data_type.addAliasName("InfoDtl.data_type", p);
		p.columnInfoDtl_date_diff_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm;
		p.columnInfoDtl_date_diff_nm.addAliasName("InfoDtl.date_diff_nm", p);
		p.columnInfoDtl_date_diff_key = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_key;
		p.columnInfoDtl_date_diff_key.addAliasName("InfoDtl.date_diff_key", p);
		p.columnInfoDtl_relative_type_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_relative_type_nm;
		p.columnInfoDtl_relative_type_nm.addAliasName("InfoDtl.relative_type_nm", p);
		p.columnInfoDtl_relative_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_relative_type;
		p.columnInfoDtl_relative_type.addAliasName("InfoDtl.relative_type", p);
		p.columnInfoDtl_number = p.InfoDtl_cond_p_PPanel.columnInfoDtl_number;
		p.columnInfoDtl_number.addAliasName("InfoDtl.number", p);
		p.columnInfoDtl_date_field_type_nm = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_field_type_nm;
		p.columnInfoDtl_date_field_type_nm.addAliasName("InfoDtl.date_field_type_nm", p);
		p.columnInfoDtl_date_field_type = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_field_type;
		p.columnInfoDtl_date_field_type.addAliasName("InfoDtl.date_field_type", p);
		p.columnInfoDtl_date_diff = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff;
		p.columnInfoDtl_date_diff.addAliasName("InfoDtl.date_diff", p);
		p.columnInfoDtl_date = p.InfoDtl_cond_p_PPanel.columnInfoDtl_date;
		p.columnInfoDtl_date.addAliasName("InfoDtl.date", p);
		p.columnInfoDtl_text = p.InfoDtl_cond_p_PPanel.columnInfoDtl_text;
		p.columnInfoDtl_text.addAliasName("InfoDtl.text", p);
		p.columnInfoDtl_check = p.InfoDtl_cond_p_PPanel.columnInfoDtl_check;
		p.columnInfoDtl_check.addAliasName("InfoDtl.check", p);
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP_SumCond p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SumCond create(){
		FSBAP_SumCond p = new FSBAP_SumCond();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SumCond create(String name){
		FSBAP_SumCond p = new FSBAP_SumCond(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_SumCond_FW.jbfInitInfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbfInitInfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbfInitInfoBtn((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbInitInfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbInitInfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.jbInitInfoBtn((FSBAP_SumCond)this);
	}

	/**
	 * [InfoHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoHdr(FSBAP_SumCond p) {
		// ブロック関連の初期化
		p.InfoHdrPanel = p.beansFactory.createPanel("InfoHdr");
		// ブロックの項目の初期化
		p.InfoHdr_cond_nm_Label = p.beansFactory.createLabel("InfoHdr.cond_nm_Label");
		p.InfoHdr_cond_nm = p.beansFactory.createTextField("InfoHdr.cond_nm");
		p.InfoHdr_cond_nm.setLabel(p.InfoHdr_cond_nm_Label);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP_SumCond p) {
		// ブロック関連の初期化
		p.InfoDtlPanel = p.beansFactory.createPanel("InfoDtl");
		p.InfoDtlScrollPane = p.beansFactory.createScrollPane("InfoDtl.scroll");
		p.createInfoDtlTable();
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP_SumCond p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_radd = p.beansFactory.createButton("InfoBtn.radd", "no_border");
		p.InfoBtn_rdel = p.beansFactory.createButton("InfoBtn.rdel", "no_border");
		p.InfoBtn_upd = p.beansFactory.createButton("InfoBtn.upd", "upd");
	}

	/**
	 * [InfoHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoHdr(FSBAP_SumCond p) {
		// ブロック関連の初期化
		p.add(p.InfoHdrPanel);
		p.setLastBeans(p.InfoHdrPanel);
		p.InfoHdrPanel.setNextBeans(p.InfoDtlPanel);
		p.InfoHdrPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.InfoHdrPanel.add(p.InfoHdr_cond_nm_Label);
		p.InfoHdrPanel.add(p.InfoHdr_cond_nm);
		p.InfoHdrPanel.setLastBeans(p.InfoHdr_cond_nm);
		p.InfoHdr_cond_nm.setRow(p.getInfoHdrR(), mcframe.clientFSBA.FSBAP0810.InfoHdrR.cond_nm_META);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP_SumCond p) {
		// ブロック関連の初期化
		p.add(p.InfoDtlPanel);
		p.InfoDtlPanel.setNextBeans(p.InfoBtnPanel);
		p.InfoDtlPanel.add(p.InfoDtlScrollPane);
		p.InfoDtlPanel.setLastBeans(p.InfoDtlTable);
		p.InfoDtlScrollPane.setViewportView(p.InfoDtlTable);
		p.InfoDtlTable.setList(p.getInfoDtlL());
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP_SumCond p) {
		// ブロック関連の初期化
		p.add(p.InfoBtnPanel);
		p.InfoBtnPanel.setValueCheck(false);
		p.InfoBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoBtn_radd.setIcon("INSERT_RECORD");
		p.InfoBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.InfoBtnPanel.add(p.InfoBtn_radd);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_radd);
		p.InfoBtn_radd.setNextBeans(p.InfoBtn_rdel);
		p.InfoBtn_rdel.setIcon("DELETE_RECORD");
		p.InfoBtn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.InfoBtnPanel.add(p.InfoBtn_rdel);
		p.InfoBtn_rdel.setNextBeans(p.InfoBtn_upd);
		p.InfoBtn_upd.setIcon("REGISTER");
		p.InfoBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_SumCond_FW.mcInitInfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.mcInitInfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.mcInitInfoBtn((FSBAP_SumCond)this);

		// [INIT]ステータスのモードの設定
		FSBAP_SumCond_FW.statusInitINIT_InfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitINIT_InfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitINIT_InfoBtn((FSBAP_SumCond)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_SumCond_FW.statusInitEDIT_InfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitEDIT_InfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitEDIT_InfoBtn((FSBAP_SumCond)this);

		// [MODIFY]ステータスのモードの設定
		FSBAP_SumCond_FW.statusInitMODIFY_InfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitMODIFY_InfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitMODIFY_InfoBtn((FSBAP_SumCond)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_SumCond_FW.statusInitDISABLE_InfoHdr((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitDISABLE_InfoDtl((FSBAP_SumCond)this);
		FSBAP_SumCond_FW.statusInitDISABLE_InfoBtn((FSBAP_SumCond)this);

	}

	/**
	 *  [InfoHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoHdr(FSBAP_SumCond p) {
		p.InfoHdr_cond_nm.setListListener(p);
		p.InfoHdr_cond_nm.addAllListener(p);
	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP_SumCond p) {
		p.InfoDtlTable.addAllListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP_SumCond p) {
		p.InfoBtn_radd.addAllListener(p);
		p.InfoBtn_radd.setAPMethodName("doInfoBtn_radd");
		p.InfoBtn_rdel.addAllListener(p);
		p.InfoBtn_rdel.setAPMethodName("doInfoBtn_rdel");
		p.InfoBtn_upd.addAllListener(p);
		p.InfoBtn_upd.setAPMethodName("doInfoBtn_upd");
	}

	/**
	 * [INIT]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoHdr(FSBAP_SumCond p){
		p.InfoHdr_cond_nm.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP_SumCond p){
		p.InfoDtl_cond_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.DISABLE);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP_SumCond p){
		p.InfoBtn_radd.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_upd.putMode(p, INIT, MCMode.DISABLE);

	}

	/**
	 * [EDIT]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoHdr(FSBAP_SumCond p){
		p.InfoHdr_cond_nm.putMode(p, EDIT, MCMode.REQUIRED);

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP_SumCond p){
		p.InfoDtl_cond_p_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.EDIT);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, EDIT, MCMode.INVISIBLE);

	}

	/**
	 * [EDIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoBtn(FSBAP_SumCond p){
		p.InfoBtn_radd.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_rdel.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_upd.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [MODIFY]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitMODIFY_InfoHdr(FSBAP_SumCond p){
		p.InfoHdr_cond_nm.putMode(p, MODIFY, MCMode.READ_ONLY);

	}

	/**
	 * [MODIFY]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitMODIFY_InfoDtl(FSBAP_SumCond p){
		p.InfoDtl_cond_p_PPanel.putStatus(MODIFY, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.EDIT);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type_nm.putMode(p, MODIFY, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_nm.putMode(p, MODIFY, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, MODIFY, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, MODIFY, MCMode.INVISIBLE);

	}

	/**
	 * [MODIFY]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitMODIFY_InfoBtn(FSBAP_SumCond p){
		p.InfoBtn_radd.putMode(p, MODIFY, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, MODIFY, MCMode.DISABLE);
		p.InfoBtn_upd.putMode(p, MODIFY, MCMode.ENABLE);

	}

	/**
	 * [DISABLE]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoHdr(FSBAP_SumCond p){
		p.InfoHdr_cond_nm.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP_SumCond p){
		p.InfoDtl_cond_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D.DISABLE);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_logic_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_column_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date_diff_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoDtl_cond_p_PPanel.columnInfoDtl_date.putMode(p, DISABLE, MCMode.INVISIBLE);

	}

	/**
	 * [DISABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoBtn(FSBAP_SumCond p){
		p.InfoBtn_radd.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_upd.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_SumCond_FW.setTableConfigInfoDtl((FSBAP_SumCond)this);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP_SumCond p) {
		p.InfoDtlTable.addTable(p.InfoDtl_cond_p_PPanel.InfoDtlTable);
		// スクロール固定カラムの指定
		p.InfoDtlTable.setUnscrollColumn(p.columnInfoDtl_relative_type);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[MODIFY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setMODIFYStatus() {
		status = MODIFY;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (MODIFY.equals(status)) {
			setMODIFYStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == InfoBtn_radd) doInfoBtn_radd(info);
		else if (ap == InfoBtn_rdel) doInfoBtn_rdel(info);
		else if (ap == InfoBtn_upd) doInfoBtn_upd(info);
	}

	/**
	 * [InfoBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_radd(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_rdel(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == InfoDtlTable) return doInfoDtl_VC(info);
		if (vc == InfoHdr_cond_nm) return doInfoHdr_cond_nm_VC(info);
		return true;
	}

	/**
	 * [InfoDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoHdr]パネルの[cond_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoHdr_cond_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == InfoDtlTable) doInfoDtl_NC(info);
		else if (nc == InfoHdr_cond_nm) doInfoHdr_cond_nm_NC(info);
	}

	/**
	 * [InfoDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[cond_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_cond_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == InfoDtlTable) doInfoDtl_NE(info);
		else if (ne == InfoHdr_cond_nm) doInfoHdr_cond_nm_NE(info);
	}

	/**
	 * [InfoDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NE(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[cond_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_cond_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == InfoDtlTable) doInfoDtl_NX(info);
		else if (nx == InfoHdr_cond_nm) doInfoHdr_cond_nm_NX(info);
	}

	/**
	 * [InfoDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NX(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[cond_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_cond_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == InfoHdr_cond_nm) doInfoHdr_cond_nm_LC(info);
	}

	/**
	 * [InfoHdr]パネルの[cond_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_cond_nm_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}