package mcframe.clientFSBA.FSBAP0810;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoDtlR_FW_A extends MCConstRow {

	public static final String $cond_p = "cond_p";

	public static final String $disable = $cond_p + ".disable";
	public static final String $logic_type_nm = $cond_p + ".logic_type_nm";
	public static final String $logic_type = $cond_p + ".logic_type";
	public static final String $column_nm = $cond_p + ".column_nm";
	public static final String $column_key = $cond_p + ".column_key";
	public static final String $data_type = $cond_p + ".data_type";
	public static final String $date_diff_nm = $cond_p + ".date_diff_nm";
	public static final String $date_diff_key = $cond_p + ".date_diff_key";
	public static final String $relative_type_nm = $cond_p + ".relative_type_nm";
	public static final String $relative_type = $cond_p + ".relative_type";
	public static final String $number = $cond_p + ".number";
	public static final String $date_field_type_nm = $cond_p + ".date_field_type_nm";
	public static final String $date_field_type = $cond_p + ".date_field_type";
	public static final String $date_diff = $cond_p + ".date_diff";
	public static final String $date = $cond_p + ".date";
	public static final String $text = $cond_p + ".text";
	public static final String $check = $cond_p + ".check";

	public static final MCMeta cond_p_META = createInnerRowMeta($cond_p, mcframe.clientFSUB.FSUBP0170.InfoDtlR.class);

	protected static final ConstMetaList<InfoDtlR> constMetas = new ConstMetaList<InfoDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			cond_p_META
		},
		new String[][]{
			{
				"disable",
				"logic_type_nm",
				"logic_type",
				"column_nm",
				"column_key",
				"data_type",
				"date_diff_nm",
				"date_diff_key",
				"relative_type_nm",
				"relative_type",
				"number",
				"date_field_type_nm",
				"date_field_type",
				"date_diff",
				"date",
				"text",
				"check"
			},
			{
				$disable,
				$logic_type_nm,
				$logic_type,
				$column_nm,
				$column_key,
				$data_type,
				$date_diff_nm,
				$date_diff_key,
				$relative_type_nm,
				$relative_type,
				$number,
				$date_field_type_nm,
				$date_field_type,
				$date_diff,
				$date,
				$text,
				$check
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoDtlR_FW_A(ConstMetaList<? extends InfoDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR clone() {
		return (InfoDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR createInstance() {
		return (InfoDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR getValues(String... names) {
		return (InfoDtlR) super.getValues(names);
	}



	public mcframe.clientFSUB.FSUBP0170.InfoDtlR cond_p(){
		return (mcframe.clientFSUB.FSUBP0170.InfoDtlR) getConstInnerRow(offset + 0, $cond_p);
	}
	
	public void cond_p(mcframe.clientFSUB.FSUBP0170.InfoDtlR row){
		setConstInnerRow(offset + 0, $cond_p, row);
	}






	public MCRow getInnerRow(String name) {
		if ($cond_p.equalsIgnoreCase(name)) {
			return cond_p();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($cond_p.equalsIgnoreCase(name)) {
			cond_p(
				((MCContainerMeta) cond_p_META).castInnerRow(mcframe.clientFSUB.FSUBP0170.InfoDtlR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public boolean disable() {
		return cond_p().disable();
	}

	public void disable(boolean value) {
		cond_p().disable(value);
	}

	public String logic_type_nm() {
		return cond_p().logic_type_nm();
	}

	public void logic_type_nm(String value) {
		cond_p().logic_type_nm(value);
	}

	public String logic_type() {
		return cond_p().logic_type();
	}

	public void logic_type(String value) {
		cond_p().logic_type(value);
	}

	public String column_nm() {
		return cond_p().column_nm();
	}

	public void column_nm(String value) {
		cond_p().column_nm(value);
	}

	public String column_key() {
		return cond_p().column_key();
	}

	public void column_key(String value) {
		cond_p().column_key(value);
	}

	public String data_type() {
		return cond_p().data_type();
	}

	public void data_type(String value) {
		cond_p().data_type(value);
	}

	public String date_diff_nm() {
		return cond_p().date_diff_nm();
	}

	public void date_diff_nm(String value) {
		cond_p().date_diff_nm(value);
	}

	public String date_diff_key() {
		return cond_p().date_diff_key();
	}

	public void date_diff_key(String value) {
		cond_p().date_diff_key(value);
	}

	public String relative_type_nm() {
		return cond_p().relative_type_nm();
	}

	public void relative_type_nm(String value) {
		cond_p().relative_type_nm(value);
	}

	public String relative_type() {
		return cond_p().relative_type();
	}

	public void relative_type(String value) {
		cond_p().relative_type(value);
	}

	public MCNumber number() {
		return cond_p().number();
	}

	public void number(MCNumber value) {
		cond_p().number(value);
	}

	public void number(int value) {
		cond_p().number(value);
	}

	public void number(long value) {
		cond_p().number(value);
	}

	public void number(float value) {
		cond_p().number(value);
	}

	public void number(double value) {
		cond_p().number(value);
	}

	public String date_field_type_nm() {
		return cond_p().date_field_type_nm();
	}

	public void date_field_type_nm(String value) {
		cond_p().date_field_type_nm(value);
	}

	public String date_field_type() {
		return cond_p().date_field_type();
	}

	public void date_field_type(String value) {
		cond_p().date_field_type(value);
	}

	public MCNumber date_diff() {
		return cond_p().date_diff();
	}

	public void date_diff(MCNumber value) {
		cond_p().date_diff(value);
	}

	public void date_diff(int value) {
		cond_p().date_diff(value);
	}

	public void date_diff(long value) {
		cond_p().date_diff(value);
	}

	public void date_diff(float value) {
		cond_p().date_diff(value);
	}

	public void date_diff(double value) {
		cond_p().date_diff(value);
	}

	public MCTimestamp date() {
		return cond_p().date();
	}

	public void date(MCTimestamp value) {
		cond_p().date(value);
	}

	public String text() {
		return cond_p().text();
	}

	public void text(String value) {
		cond_p().text(value);
	}

	public boolean check() {
		return cond_p().check();
	}

	public void check(boolean value) {
		cond_p().check(value);
	}

}

