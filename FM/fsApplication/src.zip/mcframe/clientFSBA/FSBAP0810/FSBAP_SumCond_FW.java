package mcframe.clientFSBA.FSBAP0810;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0170.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSUB.FSUBP0000.IfCompCondBase;
import mcframe.clientFSUB.FSUBP0000.IfSumCondBase;
import mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D_FW.FSUBP_InfoDtlCellConfig;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;

import mcframe.clientCore.beans.popup.MCPopupBeans;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_SumCond"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_SumCond_FW extends FSBAP_SumCond_FW_A implements IfCompCondBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 設定対象の画面です。
	 */
	protected IfSumCondBase _sumCond = null;

	/**
	 * 画面の初期ステータスです。
	 */
	protected String _init_status = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SumCond_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SumCond_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[InfoBtn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd(MCEventInfo info) {
		if (!checkForUpd()) {
			return;
		}
		applyData();

		statusClear();
		requestCloseWindow();
	}
	/**
	 * Panel[InfoBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_radd(MCEventInfo info) {
		insertRow(InfoDtlTable);

		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}
	/**
	 * Panel[InfoBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doInfoBtn_rdel(MCEventInfo info) {
		deleteRow(InfoDtlTable);

		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
	}
	
	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		
		InfoDtlTable.fillSpace();
		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}

	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1（編集可）<br>
	 * <li>起動タイプ：T2（修正可）<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * 設定対象の画面を指定してください。
	 * </li>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0052] 引数の指定に誤りがあった場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ] 
	 * 起動タイプに {@link T1} および {@link T2} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp) || T2.equals(openTyp)) {
			Object o = args[0];
			if (o == null || !(o instanceof IfSumCondBase)) {
				throw new MCAppException(FSBAC0052);
			}
			setSumCondBase((IfSumCondBase) o); 

			_init_status = (T1.equals(openTyp)) ? EDIT : MODIFY;

			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	/**
	 * 起動元の画面を設定します。
	 * 
	 * @param sumCond 起動元画面
	 */
	protected void setSumCondBase(IfSumCondBase sumCond) {
		_sumCond = sumCond;

		// 計算式の初期化
		InfoDtl_cond_p_PPanel.initExpressionBuilder();
	}

	@Override
	public void setOpenFocus() {
		super.setOpenFocus();

		InfoHdr_cond_nm.mcRequestFocus();
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		setInitData();

		setStatus(_init_status);
	}

	/**
	 * この画面の情報を初期化します。
	 */
	protected void setInitData() {
		getInfoHdrR().cond_nm(_sumCond.getSumCondName());

		MCList<InfoDtlR> dtlL = getInfoDtlL();
		dtlL.clear();
		addConditionRow(dtlL, _sumCond.getSumCondList());

		InfoDtlTable.adjustWidth();
	}

	/**
	 * 条件から、リストに行を追加します。
	 *
	 * @param dtlL 追加するリスト
	 * @param conds シグナルの条件
	 */
	protected void addConditionRow(MCList<InfoDtlR> dtlL, List<MCRowFilter> conds) {
		if (conds == null) {
			return;
		}
		conds.forEach(cond -> {
			InfoDtlR dtlR = dtlL.createRow();
			InfoDtl_cond_p_PPanel.addConditionRow(dtlR.cond_p(), cond);
			dtlL.add(dtlR);
		});
	}

	/**
	 * この画面の情報を適用します。
	 */
	protected void applyData() {
		List<MCRowFilter> list = new ArrayList<>();
		for (InfoDtlR d : getInfoDtlL()) {
			if (d.isEmpty() || d.isStatusDelete()) {
				continue;
			}

			MCRowFilter cond = new MCRowFilter();
			cond.setDisable(d.disable());
			Comparable<?> v = InfoDtl_cond_p_PPanel.getConditionValue(d.cond_p());
			if (cond.setCondition(
							d.column_key(),
							MCDataType.valueOf(d.data_type()),
							v,
							d.relative_type(),
							d.logic_type())
			) {
				list.add(cond);
			}
		}

		_sumCond.setSumCond(getInfoHdrR().cond_nm(), list);
	}

	/**
	 * 登録処理の実行可否を判断します。
	 * 実行可能な場合は true を返します。
	 * 
	 * <p>
	 * 名称と一覧のいずれかまたは両方が空の場合は実行不可です。
	 * 
	 * @return 実行不可の場合は false
	 */
	protected boolean checkForUpd() {
		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		// フィルタ情報の必須項目をチェックする
		MCMessageList m = new MCMessageList();
		MCRowFilter cond = new MCRowFilter();

		// ヘッダチェック
		MCMessageList chk = checkReq(getInfoHdrR());
		if (chk.size() > 0) {
			m.addAll(chk);
		}

		// 明細チェック
		int rec = 0;
		MCList<InfoDtlR> dtlL = exceptEmpty(getInfoDtlL());
		for (InfoDtlR dtlR : dtlL) {
			if (dtlR.isEmpty() || dtlR.isStatusDelete()) {
				continue;
			}
			rec++;

			chk = checkReq(InfoDtlTable, dtlR);
			if (chk.size() > 0) {
				m.addAll(chk);
				continue;
			}

			// 判断条件チェック
			chk = InfoDtl_cond_p_PPanel.checkCondition(cond, dtlR.cond_p());
			if (chk.size() > 0) {
				m.addAll(chk);
			}
		}
		if (rec == 0) {
			// 定義がない！
			m.add(new MCMessage(FSBAC0082));
		}

		if (m.size() > 0) {
			message(m);
			return false;
		}
		return true;
	}

	/**
	 * 空行のステータスをクリアします。
	 * 
	 * @param lists リスト
	 */
	protected void clearEmptyRowStatus(MCList<?>... lists) {
		for (MCList<?> l : lists) {
			for (MCRow o : l) {
				if (o.isEmpty()) {
					o.clearAll();
					o.setStatus(MCRow.GUICREATE);
				}
			}
		}
	}

	@Override
	public MCTable<?> getTargetTable() {
 		return _sumCond.getTargetTable();
 	}

	@Override
	public String getPersonalizedType() {
		return SUM_INFO_PANEL;
	}


	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();
	
		InfoDtlTable.setCellConfig(createInfoDtlCellConfig());
	}

	/**
	 * 情報テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 情報テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createInfoDtlCellConfig() {
		return new FSBAP_InfoDtlCellConfig();
	}

	/**
	 * 情報テーブルに設定するセルコンフィグです。
	 */
	public class FSBAP_InfoDtlCellConfig extends FSUBP_InfoDtlCellConfig {
		FSBAP_InfoDtlCellConfig() {
			super(InfoDtl_cond_p_PPanel);
		}
	}

}