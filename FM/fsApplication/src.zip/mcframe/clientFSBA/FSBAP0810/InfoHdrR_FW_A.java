package mcframe.clientFSBA.FSBAP0810;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoHdr"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoHdrR_FW_A extends MCConstRow {

	/**
	 *  集計条件名.<p>
	 *
	 */
	public static final String $cond_nm = "cond_nm";


	public static final MCMeta cond_nm_META = createStringMeta($cond_nm);

	protected static final ConstMetaList<InfoHdrR> constMetas = new ConstMetaList<InfoHdrR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			cond_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoHdrR_FW_A(ConstMetaList<? extends InfoHdrR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoHdrR clone() {
		return (InfoHdrR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoHdrR createInstance() {
		return (InfoHdrR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoHdrR getValues(String... names) {
		return (InfoHdrR) super.getValues(names);
	}



	/**
	 *  集計条件名.<p>
	 *
	 */
	public String cond_nm() {
		return getConstString(offset + 0, $cond_nm);
	}

	/**
	 *  集計条件名.<p>
	 *
	 */
	public void cond_nm(String value) {
		setConstString(offset + 0, $cond_nm, value);
	}


	public String getString(String name) {
		if ($cond_nm.equalsIgnoreCase(name)) {
			return cond_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($cond_nm.equalsIgnoreCase(name)) {
			return cond_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($cond_nm.equalsIgnoreCase(name)) {
			cond_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($cond_nm.equalsIgnoreCase(name)) {
			cond_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

