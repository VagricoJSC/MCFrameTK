package mcframe.clientFSBA.FSBAP0220;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil;
import mcframe.clientFXUC.FXUCP0070.SrchCndInfo;

import java.io.File;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JViewport;

import mcframe.clientCore.beans.popup.MCImageBeans;
import mcframe.clientCore.beans.popup.MCImagePanelInfo;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_PicSelect"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_PicSelect_FW extends FSBAP_PicSelect_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected MCImagePanelInfo _info;

	protected MCBinary _value;

	private Icon _default_icon;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_PicSelect_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[select]の押下時の処理
	 */
	@Override
	public void doBtn_select(MCEventInfo info) {
		showLoadImageDialog(null);
	}

	protected void showLoadImageDialog(File file) {
		String[] types = _info.getFileTypes();
		File f = MCFileChooser.showLoadImageDialog(file, getBaseRootPanel(), types);
		if (f != null) {
			MCMessageList l = new MCMessageList();
			MCBeansUtil.getImage(f, l);
			MCBinary v = null;
			switch (l.size()) {
				// 画像ファイルの場合
				case 0:
					v = MCBinary.valueOf(f);
					break;
				// 画像ファイルではない場合
				case 1:
					dialog(l.get(0));
					showLoadImageDialog(f);
					return;
				default:
					message(l);
					showLoadImageDialog(f);
					return;
			}
			setInitValue(v);
		}
	}

	/**
	 * Panel[Btn]のボタン[accept]の押下時の処理
	 */
	@Override
	public void doBtn_accept(MCEventInfo info) {
		setValueToParent(_value);

		if (!isPartsPanel()) {
			requestCloseWindow();
		}
	}
	/**
	 * Panel[Btn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doBtn_del(MCEventInfo info) {
		setValueToParent(null);

		if (!isPartsPanel()) {
			requestCloseWindow();
		}
	}

	protected void setValueToParent(MCBinary value) {
		if (_info.getLinkComponent() != null) {
			_info.getLinkComponent().setValue(value);
		}
		else if (_info.getLinkColumn() != null) {
			_info.getLinkColumn().setValue(_info.getLinkIndex(), value);
		}
	}

	protected void setInitValue(MCBinary value) {
		getImageR().image(null);
		_default_icon = null;
		getBtnR().ratio(100);

		getImageR().image(value);
		_default_icon = Image_image.getIcon();
		adjustImageView(_default_icon);
		_value = value;

		// JRW-5-016-06468 2008/11/11
		Btn_ratio.setValue(MCNumber.valueOf(getAdjustedImageRatio()));
		
	}
	
	protected void adjustImageView(Icon icon) {
		if (icon != null) {
			Insets insets = Image_image.getInsets();
			int mw = insets.left + insets.right;
			int mh = insets.top + insets.bottom;
			Image_image.setPreferredSize(
					new Dimension(icon.getIconWidth() + mw, icon.getIconHeight() + mh));
		}
	}
	
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			if (args != null && args.length == 1 &&
					args[0] instanceof MCImagePanelInfo) {
				setImagePanelInfo((MCImagePanelInfo) args[0], null, false);
			}
			else {
				throw new MCAppException(msgUnknownOpenParam());
			}
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	public void layoutInit() {
		// ImageViewがつぶれるためレイアウトする前に初期化
		Image_image.setImagePanelEnabled(false);

		ImagePanel.remove(Image_image);
		ImagePanel.setLayout(new BorderLayout());
		MCScrollPane pane = beansFactory.createScrollPane("_image_scroll");
		pane.setViewportView(Image_image);
		ImagePanel.add(pane, BorderLayout.CENTER);

		super.layoutInit();
	}

	@Override
	protected void beansAttrInit() {
		super.beansAttrInit();

//		ImagePanel.remove(Image_image);
//		ImagePanel.setLayout(new BorderLayout());
//		ImagePanel.add(Image_image, BorderLayout.CENTER);
	}

	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();

		setArrangementCenter();
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);

		Image_image.setFocusable(false);
	}

	@Override
	public void setENABLEStatus() {
		super.setENABLEStatus();

		Btn_select.mcRequestFocus();
	}

	@Override
	public void setDISABLEStatus() {
		super.setDISABLEStatus();

		Btn_ratio.mcRequestFocus();
	}

	@Override
	public boolean doBtn_ratio_VC(MCEventInfo info) {
		if (!super.doBtn_ratio_VC(info)) {
			return false;
		}

		MCNumber v = (MCNumber)info.getNewValue();
		if (v == null) {
			return false;
		}

		int i = v.intValue();
		if (i < getImageMinRatio() || i > getImageMaxRatio()) {
			return false;
		}

		return true;
	}

	@Override
	public void doBtn_ratio_NC(MCEventInfo info) {
		super.doBtn_ratio_NC(info);

		int v = getBtnR().ratio().intValue();
		Icon i = _default_icon;
		if (i instanceof ImageIcon) {
			ImageIcon m = (ImageIcon)i;
			int w = m.getIconWidth() * v / 100;
			if (w < 1) {
				w = 1;
			}
			int h = m.getIconHeight() * v / 100;
			if (h < 1) {
				h = 1;
			}
			ImageIcon n = new ImageIcon(m.getImage());
			n.setImage(n.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH));
			adjustImageView(n);
			
			Image_image.setIcon(n);
		}
	}

	/**
	 * 部品利用時の初期化処理です。
	 *
	 * @param info 初期化情報
	 * @param img 表示する画像。null の場合引数 info に依存
	 */
	public void initForParts(MCImagePanelInfo info, MCBinary img) {
		setImagePanelInfo(info, img, true);
	}

	/**
	 * この画面を利用するための情報を設定します。
	 *
	 * 引数 img が null の場合、引数 info に設定されている連携項目に
	 * 設定されている画像を使用します。
	 * 連携項目がない場合は null になります。
	 *
	 * @param info 初期化情報
	 * @param img 表示する画像。null の場合引数 info に依存
	 * @param parts 部品利用時は true
	 */
	protected void setImagePanelInfo(MCImagePanelInfo info, MCBinary img, boolean parts) {
		_info = info;

		// 画面モード設定
		Boolean force_e = _info.isEditable();
		Boolean e = null;
		MCMode m = null;
		if (force_e == null) {
			MCImageBeans c = _info.getLinkComponent();
			if (c != null) {
				e = MCMode.isEnable(c);
				m = c.getMode();
			}
			else {
				MCColumnConfig o = _info.getLinkColumn();
				if (o != null) {
					m = o.getBaseTable().isCellEditable(
							_info.getLinkIndex(), o);
					e = o.getModeInfo(m).getStatus() == MCMode.ENABLE_STATUS;
				}
				else {
					e = false;	// デフォルト
				}
			}
		}
		else {
			e = force_e;
			m = MCMode.READ_ONLY;
		}
		if (parts) {
			if (e) {
				setPARTS_WStatus();
			}
			else {
				setPARTS_RStatus();
			}
		}
		else {
			if (e) {
				setENABLEStatus();
			}
			else {
				if (m != null && MCMode.READ_ONLY.getName().equals(m.getName())) {
					setREAD_ONLYStatus();
				}
				else {
					setDISABLEStatus();
				}
			}
		}

		MCBinary v = img;
		if (v == null) {
			if (_info.getLinkComponent() != null) {
				v = _info.getLinkComponent().getValue();
			}
			else if (_info.getLinkColumn() != null) {
				v = (MCBinary) _info.getLinkColumn().getValue(
						_info.getLinkIndex());
			}
		}
		setInitValue(v);
		
		if (!parts) {
			SrchCndInfo ci = FXUCP_SrchCndUtil.getInitSrchCndInfo(getSrchCndInfoList());
			if (ci != null) {
				_applySrchCndInfo(ci);
			}
		}
	}

	/**
	 * 画像比率調整フラグを返します。
	 *
	 * @return 画像比率調整フラグ
	 */
	protected boolean isAdjustImageRatio() {
		Boolean a = _info.isAdjustImageRatio();
		if (a != null) {
			return a;
		}

		return getPgmSettingBooleanNE(this, true, "Image.RatioAdjusted");
	}

	/**
	 * 画像比率の最小値を返します。
	 *
	 * @return 画像比率の最小値
	 */
	protected int getImageMinRatio() {
		Integer x = _info.getMinRatio();
		if (x != null) {
			return x;
		}

		return getPgmSettingIntNE(this, 10, "Image.ratio.min");
	}

	/**
	 * 画像比率の最大値を返します。
	 *
	 * @return 画像比率の最大値
	 */
	protected int getImageMaxRatio() {
		Integer x = _info.getMaxRatio();
		if (x != null) {
			return x;
		}

		return getPgmSettingIntNE(this, 400, "Image.ratio.max");
	}

	/**
	 * 調整されたイメージ比率を返します。<p>
	 * イメージ比率を調整しない場合は 100 を返します。
	 * イメージがイメージ領域（ImagePanelのサイズ）よりも小さい場合は 100 を返します。
	 * イメージがイメージ領域よりも大きい場合は、イメージがイメージ領域に収まる比率を返します。
	 *
	 * @return 調整されたイメージ比率または 100
	 */
	protected int getAdjustedImageRatio() {
		if (!isAdjustImageRatio()) {
			return 100;
		}

		Icon i = Image_image.getIcon();
		if (!(i instanceof ImageIcon)) {
			return 100;
		}
		ImageIcon m = (ImageIcon)i;
		int iw = m.getIconWidth();
		int ih = m.getIconHeight();
		MCScrollPane sp = (MCScrollPane)ImagePanel.getComponent(0);
		JViewport vp = sp.getViewport();
		Insets vpi = vp.getInsets();
		Insets ivi = Image_image.getInsets();
		
		int pw = vp.getExtentSize().width- vpi.left - vpi.right - ivi.left - ivi.right;
		int ph = vp.getExtentSize().height - vpi.top - vpi.bottom - ivi.top - ivi.bottom;
		
		
		boolean w = pw > iw;
		boolean h = ph > ih;
		if (w && h) {
			return 100;
		}
		int wr = (pw * 100) / iw;
		int hr = (ph * 100) / ih;
		return wr > hr ? hr : wr;
	}

}