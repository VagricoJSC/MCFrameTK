package mcframe.clientFSBA.FSBAP0220;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Image"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ImageR_FW_A extends MCConstRow {

	/**
	 *  画像データ.<p>
	 *
	 */
	public static final String $image = "image";


	public static final MCMeta image_META = createBinaryMeta($image);

	protected static final ConstMetaList<ImageR> constMetas = new ConstMetaList<ImageR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			image_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ImageR_FW_A(ConstMetaList<? extends ImageR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ImageR clone() {
		return (ImageR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ImageR createInstance() {
		return (ImageR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ImageR getValues(String... names) {
		return (ImageR) super.getValues(names);
	}



	/**
	 *  画像データ.<p>
	 *
	 */
	public MCBinary image() {
		return getConstBinary(offset + 0, $image);
	}

	/**
	 *  画像データ.<p>
	 *
	 */
	public void image(MCBinary value) {
		setConstBinary(offset + 0, $image, value);
	}


	public MCBinary getBinary(String name) {
		if ($image.equalsIgnoreCase(name)) {
			return image();
		}
		return super.getBinary(name);
	}

	public MCBinary getBinaryNE(String name) {
		if ($image.equalsIgnoreCase(name)) {
			return image();
		}
		return super.getBinaryNE(name);
	}

	public void setBinary(String name, MCBinary value) {
		if ($image.equalsIgnoreCase(name)) {
			image(value);
			return;
		}
		super.setBinary(name, value);
	}

	public void setBinaryNE(String name, MCBinary value) {
		if ($image.equalsIgnoreCase(name)) {
			image(value);
			return;
		}
		super.setBinaryNE(name, value);
	}



}

