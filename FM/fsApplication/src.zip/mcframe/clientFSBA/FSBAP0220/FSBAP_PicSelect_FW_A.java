package mcframe.clientFSBA.FSBAP0220;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_PicSelect"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_PicSelect_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0220";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Image]ブロック関連のField定義
	public MCPanel ImagePanel = null;
	// [Image]ブロックの項目のField定義
	/**
	 *  画像データ.<p>
	 *
	 */
	public MCImageView Image_image = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	public MCLabel Btn_ratio_Label = null;
	/**
	 *  画像表示比率.<p>
	 *
	 */
	public MCNumberField Btn_ratio = null;
	/**
	 *  ファイル選択.<p>
	 *
	 */
	public MCButton Btn_select = null;
	/**
	 *  決定する.<p>
	 *
	 */
	public MCButton Btn_accept = null;
	/**
	 *  削除する.<p>
	 *
	 */
	public MCButton Btn_del = null;
	// [EastBtn]ブロック関連のField定義
	public MCPanel EastBtnPanel = null;
	// [EastBtn]ブロックの項目のField定義
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";
	/** [PARTS_W]モードを表す定数 */
	public static final String PARTS_W = "PARTS_W";
	/** [PARTS_R]モードを表す定数 */
	public static final String PARTS_R = "PARTS_R";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, READ_ONLY, DISABLE, PARTS_W, PARTS_R};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Image]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0220.ImageR aImageR;
	/** [Btn]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0220.BtnR aBtnR;

	/**
	 * 項目コピーによってaImageRを設定します。
	 *
	 * aImageRのインスタンスは変更されません。
	 *
	 * @param row ImageR
	 */
	public void setImageR(mcframe.clientFSBA.FSBAP0220.ImageR row) {
		if (row != null) {
			MCRow.copyall(getImageR(), row);
		}
	}

	/**
	 * [Image]ブロックのコンテナaImageRを返します。
	 *
	 * @return ImageR
	 */
	public mcframe.clientFSBA.FSBAP0220.ImageR getImageR() {
		return aImageR;
	}

	/**
	 * aImageRを作成します。
	 *
	 * @return ImageR
	 */
	public mcframe.clientFSBA.FSBAP0220.ImageR createImageR() {
		return mcframe.clientFSBA.FSBAP0220.ImageR.create();
	}

	/**
	 * 項目コピーによってaBtnRを設定します。
	 *
	 * aBtnRのインスタンスは変更されません。
	 *
	 * @param row BtnR
	 */
	public void setBtnR(mcframe.clientFSBA.FSBAP0220.BtnR row) {
		if (row != null) {
			MCRow.copyall(getBtnR(), row);
		}
	}

	/**
	 * [Btn]ブロックのコンテナaBtnRを返します。
	 *
	 * @return BtnR
	 */
	public mcframe.clientFSBA.FSBAP0220.BtnR getBtnR() {
		return aBtnR;
	}

	/**
	 * aBtnRを作成します。
	 *
	 * @return BtnR
	 */
	public mcframe.clientFSBA.FSBAP0220.BtnR createBtnR() {
		return mcframe.clientFSBA.FSBAP0220.BtnR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getImageR())) ret.add(getImageR());
		if(!MCCollectionUtil.contains(ret, getBtnR())) ret.add(getBtnR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getImageR()) return "Image";
		if(aCnt == getBtnR()) return "Btn";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Image")) return getImageR();
		if(bId.equals("Btn")) return getBtnR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ImagePanel);
		ret.add(BtnPanel);
		ret.add(EastBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_PicSelect_FW_A() {
		aImageR = createImageR();
		aBtnR = createBtnR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_PicSelect_FW.jbCreateImage((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbCreateBtn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbCreateEastBtn((FSBAP_PicSelect)this);
	}

	/**
	 * [Image]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateImage(FSBAP_PicSelect p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP_PicSelect p) {
	}

	/**
	 * [EastBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateEastBtn(FSBAP_PicSelect p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_PicSelect create(){
		FSBAP_PicSelect p = new FSBAP_PicSelect();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_PicSelect_FW.jbfInitImage((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbfInitBtn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbfInitEastBtn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbInitImage((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbInitBtn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.jbInitEastBtn((FSBAP_PicSelect)this);
	}

	/**
	 * [Image]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitImage(FSBAP_PicSelect p) {
		// ブロック関連の初期化
		p.ImagePanel = p.beansFactory.createPanel("Image");
		// ブロックの項目の初期化
		p.Image_image = p.beansFactory.createImageView("Image.image");
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP_PicSelect p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_ratio_Label = p.beansFactory.createLabel("Btn.ratio_Label");
		p.Btn_ratio = p.beansFactory.createNumberField("Btn.ratio");
		p.Btn_ratio.setLabel(p.Btn_ratio_Label);
		p.Btn_select = p.beansFactory.createButton("Btn.select", "no_border");
		p.Btn_accept = p.beansFactory.createButton("Btn.accept", "upd");
		p.Btn_del = p.beansFactory.createButton("Btn.del", "del");
	}

	/**
	 * [EastBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitEastBtn(FSBAP_PicSelect p) {
		// ブロック関連の初期化
		p.EastBtnPanel = p.beansFactory.createPanel("EastBtn");
		// ブロックの項目の初期化
	}

	/**
	 * [Image]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitImage(FSBAP_PicSelect p) {
		// ブロック関連の初期化
		p.add(p.ImagePanel);
		p.setLastBeans(p.ImagePanel);
		p.ImagePanel.setNextBeans(p.BtnPanel);
		p.ImagePanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.ImagePanel.add(p.Image_image);
		p.ImagePanel.setLastBeans(p.Image_image);
		p.Image_image.setRow(p.getImageR(), mcframe.clientFSBA.FSBAP0220.ImageR.image_META);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP_PicSelect p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setNextBeans(p.EastBtnPanel);
		p.BtnPanel.setValueCheck(false);
		p.BtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.BtnPanel.add(p.Btn_ratio_Label);
		p.BtnPanel.add(p.Btn_ratio);
		p.BtnPanel.setLastBeans(p.Btn_ratio);
		p.Btn_ratio.setNextBeans(p.Btn_select);
		p.Btn_ratio.setRow(p.getBtnR(), mcframe.clientFSBA.FSBAP0220.BtnR.ratio_META);
		p.Btn_ratio.setFormatID("NONE");
		p.Btn_select.setIcon("FOLDER");
		p.Btn_select.setFunctionKey(MCFunctionKey.F5);
		p.BtnPanel.add(p.Btn_select);
		p.Btn_select.setNextBeans(p.Btn_accept);
		p.Btn_accept.setIcon("REGISTER");
		p.Btn_accept.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_accept);
		p.Btn_del.setIcon("DELETE");
		p.Btn_del.setFunctionKey(MCFunctionKey.F12);
		p.EastBtnPanel.setLastBeans(p.Btn_del);
		p.EastBtnPanel.add(p.Btn_del);
	}

	/**
	 * [EastBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitEastBtn(FSBAP_PicSelect p) {
		// ブロック関連の初期化
		p.add(p.EastBtnPanel);
		p.EastBtnPanel.setLayoutPosition("SE");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_PicSelect_FW.mcInitImage((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.mcInitBtn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.mcInitEastBtn((FSBAP_PicSelect)this);

		// [ENABLE]ステータスのモードの設定
		FSBAP_PicSelect_FW.statusInitENABLE_Image((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitENABLE_Btn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitENABLE_EastBtn((FSBAP_PicSelect)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP_PicSelect_FW.statusInitREAD__ONLY_Image((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitREAD__ONLY_Btn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitREAD__ONLY_EastBtn((FSBAP_PicSelect)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_PicSelect_FW.statusInitDISABLE_Image((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitDISABLE_Btn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitDISABLE_EastBtn((FSBAP_PicSelect)this);

		// [PARTS_W]ステータスのモードの設定
		FSBAP_PicSelect_FW.statusInitPARTS__W_Image((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitPARTS__W_Btn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitPARTS__W_EastBtn((FSBAP_PicSelect)this);

		// [PARTS_R]ステータスのモードの設定
		FSBAP_PicSelect_FW.statusInitPARTS__R_Image((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitPARTS__R_Btn((FSBAP_PicSelect)this);
		FSBAP_PicSelect_FW.statusInitPARTS__R_EastBtn((FSBAP_PicSelect)this);

	}

	/**
	 *  [Image]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitImage(FSBAP_PicSelect p) {
		p.Image_image.addAllListener(p);
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP_PicSelect p) {
		p.Btn_ratio.setListListener(p);
		p.Btn_ratio.addAllListener(p);
		p.Btn_select.addAllListener(p);
		p.Btn_select.setAPMethodName("doBtn_select");
		p.Btn_accept.addAllListener(p);
		p.Btn_accept.setAPMethodName("doBtn_accept");
		p.Btn_del.addAllListener(p);
		p.Btn_del.setAPMethodName("doBtn_del");
	}

	/**
	 *  [EastBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitEastBtn(FSBAP_PicSelect p) {
	}

	/**
	 * [ENABLE]ステータスの[Image]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Image(FSBAP_PicSelect p){
		p.Image_image.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Btn(FSBAP_PicSelect p){
		p.Btn_ratio.putMode(p, ENABLE, MCMode.ENABLE);
		p.Btn_select.putMode(p, ENABLE, MCMode.ENABLE);
		p.Btn_accept.putMode(p, ENABLE, MCMode.ENABLE);
		p.Btn_del.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_EastBtn(FSBAP_PicSelect p){

	}

	/**
	 * [READ_ONLY]ステータスの[Image]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Image(FSBAP_PicSelect p){
		p.Image_image.putMode(p, READ_ONLY, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Btn(FSBAP_PicSelect p){
		p.Btn_ratio.putMode(p, READ_ONLY, MCMode.ENABLE);
		p.Btn_select.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_accept.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_del.putMode(p, READ_ONLY, MCMode.INVISIBLE);

	}

	/**
	 * [READ_ONLY]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_EastBtn(FSBAP_PicSelect p){

	}

	/**
	 * [DISABLE]ステータスの[Image]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Image(FSBAP_PicSelect p){
		p.Image_image.putMode(p, DISABLE, MCMode.ENABLE);

	}

	/**
	 * [DISABLE]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Btn(FSBAP_PicSelect p){
		p.Btn_ratio.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_select.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_accept.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_del.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_EastBtn(FSBAP_PicSelect p){

	}

	/**
	 * [PARTS_W]ステータスの[Image]ブロックのモードの設定
	 */
	protected static void statusInitPARTS__W_Image(FSBAP_PicSelect p){
		p.Image_image.putMode(p, PARTS_W, MCMode.ENABLE);

	}

	/**
	 * [PARTS_W]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitPARTS__W_Btn(FSBAP_PicSelect p){
		p.Btn_ratio.putMode(p, PARTS_W, MCMode.ENABLE);
		p.Btn_select.putMode(p, PARTS_W, MCMode.ENABLE);
		p.Btn_accept.putMode(p, PARTS_W, MCMode.INVISIBLE);
		p.Btn_del.putMode(p, PARTS_W, MCMode.ENABLE);

	}

	/**
	 * [PARTS_W]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitPARTS__W_EastBtn(FSBAP_PicSelect p){

	}

	/**
	 * [PARTS_R]ステータスの[Image]ブロックのモードの設定
	 */
	protected static void statusInitPARTS__R_Image(FSBAP_PicSelect p){
		p.Image_image.putMode(p, PARTS_R, MCMode.ENABLE);

	}

	/**
	 * [PARTS_R]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitPARTS__R_Btn(FSBAP_PicSelect p){
		p.Btn_ratio.putMode(p, PARTS_R, MCMode.ENABLE);
		p.Btn_select.putMode(p, PARTS_R, MCMode.INVISIBLE);
		p.Btn_accept.putMode(p, PARTS_R, MCMode.INVISIBLE);
		p.Btn_del.putMode(p, PARTS_R, MCMode.INVISIBLE);

	}

	/**
	 * [PARTS_R]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitPARTS__R_EastBtn(FSBAP_PicSelect p){

	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[READ_ONLY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setREAD_ONLYStatus() {
		status = READ_ONLY;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[PARTS_W]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setPARTS_WStatus() {
		status = PARTS_W;
		setAllStatus(status);
	}

	/**
	 * この画面を[PARTS_R]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setPARTS_RStatus() {
		status = PARTS_R;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (READ_ONLY.equals(status)) {
			setREAD_ONLYStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
		else if (PARTS_W.equals(status)) {
			setPARTS_WStatus();
		}
		else if (PARTS_R.equals(status)) {
			setPARTS_RStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_select) doBtn_select(info);
		else if (ap == Btn_accept) doBtn_accept(info);
		else if (ap == Btn_del) doBtn_del(info);
	}

	/**
	 * [Btn]パネルの[select]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_select(MCEventInfo info);

	/**
	 * [Btn]パネルの[accept]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_accept(MCEventInfo info);

	/**
	 * [Btn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_del(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Image_image) return doImage_image_VC(info);
		if (vc == Btn_ratio) return doBtn_ratio_VC(info);
		return true;
	}

	/**
	 * [Image]パネルの[image]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doImage_image_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[ratio]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_ratio_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Image_image) doImage_image_NC(info);
		else if (nc == Btn_ratio) doBtn_ratio_NC(info);
	}

	/**
	 * [Image]パネルの[image]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doImage_image_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[ratio]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_ratio_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Image_image) doImage_image_NE(info);
		else if (ne == Btn_ratio) doBtn_ratio_NE(info);
	}

	/**
	 * [Image]パネルの[image]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doImage_image_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[ratio]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_ratio_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Image_image) doImage_image_NX(info);
		else if (nx == Btn_ratio) doBtn_ratio_NX(info);
	}

	/**
	 * [Image]パネルの[image]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doImage_image_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[ratio]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_ratio_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Btn_ratio) doBtn_ratio_LC(info);
	}

	/**
	 * [Btn]パネルの[ratio]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_ratio_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}