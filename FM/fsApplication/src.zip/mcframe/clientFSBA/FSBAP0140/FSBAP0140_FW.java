package mcframe.clientFSBA.FSBAP0140;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.resource.MCPanelBoundsResourceIO;
import mcframe.clientCore.beans.resource.MCPersonalizeResourceIO;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientFSBA.FSBAP0080.FontR;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0140"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0140_FW extends FSBAP0140_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0140_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0140_FW(mcframe.clientFSBA.FSBAP0140.ScreenR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Screen START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Screen END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Screen]のボタン[Default]の押下時の処理
	 */
	@Override
	public void doScreen_Default(MCEventInfo info) {
		if (beforeDefault()) {
			setDefault();
			showDefaultEndMsg();
			requestCloseWindow();
		}
	}
	/**
	 * Panel[Screen]のボタン[Commit]の押下時の処理
	 */
	@Override
	public void doScreen_Commit(MCEventInfo info) {
		if (beforeCommit()) {
			doCommit();
			showCommitEndMsg();
			requestCloseWindow();
		}
	}
	/**
	 * Panel[Screen]のボタン[Cancel]の押下時の処理
	 */
	@Override
	public void doScreen_Cancel(MCEventInfo info) {
		requestCloseWindow();
	}

	@Override
	public void doScreen_Location_NC(MCEventInfo info) {
		changeSelection();
	}

	@Override
	public void doScreen_Size_NC(MCEventInfo info) {
		changeSelection();
	}
	
	@Override
	public void doScreen_Split_Divider_Location_NC(MCEventInfo info) {
		changeSelection();
	}

	/**
	 * 保存可否の選択を変更したときに実行されます。
	 * 「設定」ボタンの押下可否を制御します。
	 */
	protected void changeSelection() {
		ScreenR c = getScreenR();
		if (c.Location() || c.Size() || c.Split_Divider_Location()) {
			Screen_Commit.setMode(MCMode.ENABLE);
		} 
		else {
			Screen_Commit.setMode(MCMode.DISABLE);
		}
	}

	@Override
	public boolean beforeOpen() {
		MCRootPanel panel = getTargetPanel();
		if (panel == null) {
			throw new MCAppException(
					FSBAC0012, getModuleID(), getScreenID(), getScreenName());
		}
		MCFrame frame = panel.getFrame();
		ScreenR row = getScreenR();
		if (frame != null) {
			row.x(frame.getLocation().x);
			row.y(frame.getLocation().y);
			row.w(frame.getSize().width);
			row.h(frame.getSize().height);
			row.Location(true);
			row.Size(true);
		}
		
		MCSplitPane[] a = MCBeansUtil.getAllComponents(MCSplitPane.class, panel);
		row.Split_Divider_Location(a.length > 0);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//		removeHeaderBar();
//		removeStatusBar();

		setArrangementCenter();
		return super.beforeOpen();
	}

	/**
	 * ユーザ設定を破棄し、初期状態に戻します。
	 */
	protected void setDefault() {
		removeResource(true);
		setPanelDefault();
		setSplitPaneDefault();
	}
	
	/**
	 * リソース情報を削除します。
	 */
	protected void removeResource(boolean doSave) {
		MCRootPanel p = getTargetPanel();
		MCPanelBoundsResourceIO.removeNoSave(
				MCConst.createKey(p.getModuleID(), p.getScreenID()));
		if (doSave) {
			MCPersonalizeResourceIO.saveResource();
		}
	}
	
	/**
	 * 画面の位置とサイズをデフォルトに戻します。
	 */
	protected void setPanelDefault() {
		MCRootPanel p = getTargetPanel();
		MCFrame f = p.getFrame();
		if (f != null) {
			f.setMaximum(false);
		}
		p.setBoundsDefault();
	}
	
	/**
	 * スプリットペインのディバイダの位置をデフォルトに戻します。
	 */
	protected void setSplitPaneDefault() {
		MCSplitPane[] a = MCBeansUtil.getAllComponents(
				MCSplitPane.class, getTargetPanel());
		for (MCSplitPane sp : a) {
			sp.setDefault();
		}
	}
	
	/**
	 * 画面の位置・サイズをリソースに保存します。
	 */
	protected void doCommit() {
		writeResource();
		updatePanel();
	}
	
	/**
	 * リソース情報を保存します。
	 */
	protected void writeResource() {
		MCRootPanel p = getTargetPanel();
		ScreenR row = getScreenR();
		
		MCPanelBoundsResourceIO pio = new MCPanelBoundsResourceIO(p);
		String pfx = MCConst.createKey(p.getModuleID(), p.getScreenID());
		
		// リソース情報を読み込む
		pio.read(pfx);
		
		// リソース情報を削除する
		// 旧仕様の残骸が残るのを防止するため
		removeResource(false);
		
		// x 座標と y 座標を保存する
		if (row.Location()) {
			pio.setFrameLocation(
					new Point(row.x().intValue(), row.y().intValue()));
		}
		
		// 幅と高さを保存する
		if (row.Size()) {
			pio.setFrameSize(
					new Dimension(row.w().intValue(), row.h().intValue()));

			// JRW-5-016-06324 2008/10/08
			// 画面の最小サイズと推奨サイズも保存する
			pio.setPanelMinimumSize(p.getMinimumSize());
			pio.setPanelPreferredSize(p.getPreferredSize());
		}
		
		// スプリットペインのディバイダの位置を保存する
		if (row.Split_Divider_Location()) {
			MCSplitPane[] a = MCBeansUtil.getAllComponents(
					MCSplitPane.class, p);
			for (MCSplitPane sp : a) {
				pio.setSplitPaneDividerLocation(
						sp.getName(), sp.getDividerLocation());
			}
		}
		
		pio.writeNoSave(pfx);
		MCPersonalizeResourceIO.saveResource();
	}
	
	/**
	 * 親画面を更新します。
	 */
	protected void updatePanel() {
		MCRootPanel p = getTargetPanel();
		MCFrame f = p.getFrame();
		ScreenR row = getScreenR();
		if (f != null) {
			boolean m = f.isMaximum();
			try {
				f.setMaximum(false);
				f.setBounds(row.x().intValue(), row.y().intValue(), 
						row.w().intValue(), row.h().intValue());
			} 
			finally {
				f.setMaximum(m);
			}
		} 
		else {
			p.setBounds(row.x().intValue(), row.y().intValue(), 
					row.w().intValue(), row.h().intValue());
		}
	}

	/**
	 * 登録確認メッセージを表示します。
	 * 
	 * @return 登録する場合は true、登録しない場合は false
	 */
	protected boolean beforeCommit() {
		ScreenR c = getScreenR();
		if (c.Location() || c.Size() || c.Split_Divider_Location()) {
			return confirm(FCBAC0100) == MCMessageBox.YES_OPTION;
		} 
		else {
			dialog(FCBAC0102);
			return false;
		}
	}
	
	/**
	 * 登録完了メッセージを表示します。
	 */
	protected void showCommitEndMsg() {
		dialog(FCBAC0101);
	}
	
	/**
	 * デフォルトに戻す前の確認メッセージを表示します。
	 * 
	 * @return デフォルトに戻す場合は true、戻さない場合は false
	 */
	protected boolean beforeDefault() {
		return confirm(FSBAC0004) == MCMessageBox.YES_OPTION;
	}
	
	/**
	 * デフォルトに戻した後のメッセージを表示します。
	 */
	protected void showDefaultEndMsg() {
		dialog(FSBAC0005);
	}
	
	/**
	 * 画面の位置・サイズを保存する対象となる画面を返します。
	 * この画面が子画面の場合は親画面を返します。
	 * それ以外の場合は null を返します。
	 * 
	 * @return 画面または null
	 */
	protected MCRootPanel getTargetPanel() {
		return getParentPanel();
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();
		setStatusAfter();
	}
	
	/**
	 * 画面ステータスが更新された後に実行されます。
	 */
	protected void setStatusAfter() {
		MCSplitPane[] a = MCBeansUtil.getAllComponents(
				MCSplitPane.class, getTargetPanel());
		if (a.length == 0) {
			Screen_Split_Divider_Location.setMode(MCMode.READ_ONLY);
		}
	}
	
	@Override
	public void afterOpen() {
		Screen_Commit.mcRequestFocus();
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// スクロールバーが出る場合の自動調整を行う。
	@Override
	protected Dimension _adjistFrameSize(Dimension d) {
		// スクロールバーがでてしまうためMCRootPanelの横幅で調整する。
		if (this.getWidth() > d.width) {
			d.width = this.getWidth();
		}
		// 縦方向も計算する。
		if (this.getHeight() > d.height) {
			d.height = this.getHeight();
		}
		return d;
	}
	// 7013-0007 ここまで


	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	// 7013-0007 ここまで
}