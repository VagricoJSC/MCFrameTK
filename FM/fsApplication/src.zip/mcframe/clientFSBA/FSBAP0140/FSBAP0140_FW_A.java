package mcframe.clientFSBA.FSBAP0140;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0140"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0140_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0140";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Screen]ブロック関連のField定義
	public MCPanel ScreenPanel = null;
	// [Screen]ブロックの項目のField定義
	public MCLabel Screen_x_Label = null;
	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public MCNumberField Screen_x = null;
	public MCLabel Screen_y_Label = null;
	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public MCNumberField Screen_y = null;
	public MCLabel Screen_w_Label = null;
	/**
	 * 幅 幅.<p>
	 *
	 */
	public MCNumberField Screen_w = null;
	public MCLabel Screen_h_Label = null;
	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public MCNumberField Screen_h = null;
	/**
	 * 位置を保存する 位置を保存する.<p>
	 *
	 */
	public MCCheckBox Screen_Location = null;
	/**
	 * サイズを保存する サイズを保存する.<p>
	 *
	 */
	public MCCheckBox Screen_Size = null;
	/**
	 * スプリット位置を保存する スプリット位置を保存する.<p>
	 *
	 */
	public MCCheckBox Screen_Split_Divider_Location = null;
	/**
	 * デフォルト デフォルトに戻す.<p>
	 *
	 */
	public MCButton Screen_Default = null;
	/**
	 * 設定 設定する.<p>
	 *
	 */
	public MCButton Screen_Commit = null;
	/**
	 * キャンセル キャンセル.<p>
	 *
	 */
	public MCButton Screen_Cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Screen]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0140.ScreenR aScreenR;

	/**
	 * 項目コピーによってaScreenRを設定します。
	 *
	 * aScreenRのインスタンスは変更されません。
	 *
	 * @param row ScreenR
	 */
	public void setScreenR(mcframe.clientFSBA.FSBAP0140.ScreenR row) {
		if (row != null) {
			MCRow.copyall(getScreenR(), row);
		}
	}

	/**
	 * [Screen]ブロックのコンテナaScreenRを返します。
	 *
	 * @return ScreenR
	 */
	public mcframe.clientFSBA.FSBAP0140.ScreenR getScreenR() {
		return aScreenR;
	}

	/**
	 * aScreenRを作成します。
	 *
	 * @return ScreenR
	 */
	public mcframe.clientFSBA.FSBAP0140.ScreenR createScreenR() {
		return mcframe.clientFSBA.FSBAP0140.ScreenR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getScreenR())) ret.add(getScreenR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getScreenR()) return "Screen";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Screen")) return getScreenR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ScreenPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0140_FW_A() {
		aScreenR = createScreenR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0140_FW_A(mcframe.clientFSBA.FSBAP0140.ScreenR row){
		aScreenR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0140_FW.jbCreateScreen((FSBAP0140)this);
	}

	/**
	 * [Screen]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateScreen(FSBAP0140 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FSBAP0140 create(mcframe.clientFSBA.FSBAP0140.ScreenR row){
		FSBAP0140 p = new FSBAP0140(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0140 create(){
		FSBAP0140 p = new FSBAP0140();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0140_FW.jbfInitScreen((FSBAP0140)this);
		FSBAP0140_FW.jbInitScreen((FSBAP0140)this);
	}

	/**
	 * [Screen]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitScreen(FSBAP0140 p) {
		// ブロック関連の初期化
		p.ScreenPanel = p.beansFactory.createPanel("Screen");
		// ブロックの項目の初期化
		p.Screen_x_Label = p.beansFactory.createLabel("Screen.x_Label");
		p.Screen_x = p.beansFactory.createNumberField("Screen.x");
		p.Screen_x.setLabel(p.Screen_x_Label);
		p.Screen_y_Label = p.beansFactory.createLabel("Screen.y_Label");
		p.Screen_y = p.beansFactory.createNumberField("Screen.y");
		p.Screen_y.setLabel(p.Screen_y_Label);
		p.Screen_w_Label = p.beansFactory.createLabel("Screen.w_Label");
		p.Screen_w = p.beansFactory.createNumberField("Screen.w");
		p.Screen_w.setLabel(p.Screen_w_Label);
		p.Screen_h_Label = p.beansFactory.createLabel("Screen.h_Label");
		p.Screen_h = p.beansFactory.createNumberField("Screen.h");
		p.Screen_h.setLabel(p.Screen_h_Label);
		p.Screen_Location = p.beansFactory.createCheckBox("Screen.Location");
		p.Screen_Size = p.beansFactory.createCheckBox("Screen.Size");
		p.Screen_Split_Divider_Location = p.beansFactory.createCheckBox("Screen.Split_Divider_Location");
		p.Screen_Default = p.beansFactory.createButton("Screen.Default");
		p.Screen_Commit = p.beansFactory.createButton("Screen.Commit");
		p.Screen_Cancel = p.beansFactory.createButton("Screen.Cancel");
	}

	/**
	 * [Screen]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitScreen(FSBAP0140 p) {
		// ブロック関連の初期化
		p.add(p.ScreenPanel);
		p.setLastBeans(p.ScreenPanel);
		p.ScreenPanel.setValueCheck(false);
		// ブロックの項目の初期化
		p.ScreenPanel.add(p.Screen_x_Label);
		p.ScreenPanel.add(p.Screen_x);
		p.ScreenPanel.setLastBeans(p.Screen_x);
		p.Screen_x.setNextBeans(p.Screen_y);
		p.Screen_x.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.x_META);
		p.ScreenPanel.add(p.Screen_y_Label);
		p.ScreenPanel.add(p.Screen_y);
		p.Screen_y.setNextBeans(p.Screen_w);
		p.Screen_y.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.y_META);
		p.ScreenPanel.add(p.Screen_w_Label);
		p.ScreenPanel.add(p.Screen_w);
		p.Screen_w.setNextBeans(p.Screen_h);
		p.Screen_w.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.w_META);
		p.ScreenPanel.add(p.Screen_h_Label);
		p.ScreenPanel.add(p.Screen_h);
		p.Screen_h.setNextBeans(p.Screen_Location);
		p.Screen_h.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.h_META);
		p.ScreenPanel.add(p.Screen_Location);
		p.Screen_Location.setNextBeans(p.Screen_Size);
		p.Screen_Location.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.Location_META);
		p.ScreenPanel.add(p.Screen_Size);
		p.Screen_Size.setNextBeans(p.Screen_Split_Divider_Location);
		p.Screen_Size.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.Size_META);
		p.ScreenPanel.add(p.Screen_Split_Divider_Location);
		p.Screen_Split_Divider_Location.setNextBeans(p.Screen_Default);
		p.Screen_Split_Divider_Location.setRow(p.getScreenR(), mcframe.clientFSBA.FSBAP0140.ScreenR.Split_Divider_Location_META);
		p.Screen_Default.setFunctionKey(MCFunctionKey.F3);
		p.ScreenPanel.add(p.Screen_Default);
		p.Screen_Default.setNextBeans(p.Screen_Commit);
		p.Screen_Commit.setFunctionKey(MCFunctionKey.F9);
		p.ScreenPanel.add(p.Screen_Commit);
		p.Screen_Commit.setNextBeans(p.Screen_Cancel);
		p.Screen_Cancel.setFunctionKey(MCFunctionKey.F11);
		p.ScreenPanel.add(p.Screen_Cancel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0140_FW.mcInitScreen((FSBAP0140)this);

		// [INIT]ステータスのモードの設定
		FSBAP0140_FW.statusInitINIT_Screen((FSBAP0140)this);

	}

	/**
	 *  [Screen]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitScreen(FSBAP0140 p) {
		p.Screen_x.setListListener(p);
		p.Screen_x.addAllListener(p);
		p.Screen_y.setListListener(p);
		p.Screen_y.addAllListener(p);
		p.Screen_w.setListListener(p);
		p.Screen_w.addAllListener(p);
		p.Screen_h.setListListener(p);
		p.Screen_h.addAllListener(p);
		p.Screen_Location.addAllListener(p);
		p.Screen_Size.addAllListener(p);
		p.Screen_Split_Divider_Location.addAllListener(p);
		p.Screen_Default.addAllListener(p);
		p.Screen_Default.setAPMethodName("doScreen_Default");
		p.Screen_Commit.addAllListener(p);
		p.Screen_Commit.setAPMethodName("doScreen_Commit");
		p.Screen_Cancel.addAllListener(p);
		p.Screen_Cancel.setAPMethodName("doScreen_Cancel");
	}

	/**
	 * [INIT]ステータスの[Screen]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Screen(FSBAP0140 p){
		p.Screen_x.putMode(p, INIT, MCMode.READ_ONLY);
		p.Screen_y.putMode(p, INIT, MCMode.READ_ONLY);
		p.Screen_w.putMode(p, INIT, MCMode.READ_ONLY);
		p.Screen_h.putMode(p, INIT, MCMode.READ_ONLY);
		p.Screen_Location.putMode(p, INIT, MCMode.REQUIRED);
		p.Screen_Size.putMode(p, INIT, MCMode.REQUIRED);
		p.Screen_Split_Divider_Location.putMode(p, INIT, MCMode.REQUIRED);
		p.Screen_Default.putMode(p, INIT, MCMode.ENABLE);
		p.Screen_Commit.putMode(p, INIT, MCMode.ENABLE);
		p.Screen_Cancel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Screen_Default) doScreen_Default(info);
		else if (ap == Screen_Commit) doScreen_Commit(info);
		else if (ap == Screen_Cancel) doScreen_Cancel(info);
	}

	/**
	 * [Screen]パネルの[Default]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScreen_Default(MCEventInfo info);

	/**
	 * [Screen]パネルの[Commit]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScreen_Commit(MCEventInfo info);

	/**
	 * [Screen]パネルの[Cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScreen_Cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Screen_x) return doScreen_x_VC(info);
		if (vc == Screen_y) return doScreen_y_VC(info);
		if (vc == Screen_w) return doScreen_w_VC(info);
		if (vc == Screen_h) return doScreen_h_VC(info);
		if (vc == Screen_Location) return doScreen_Location_VC(info);
		if (vc == Screen_Size) return doScreen_Size_VC(info);
		if (vc == Screen_Split_Divider_Location) return doScreen_Split_Divider_Location_VC(info);
		return true;
	}

	/**
	 * [Screen]パネルの[x]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_x_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[y]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_y_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[w]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_w_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[h]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_h_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[Location]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_Location_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[Size]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_Size_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[Split_Divider_Location]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_Split_Divider_Location_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Screen_x) doScreen_x_NC(info);
		else if (nc == Screen_y) doScreen_y_NC(info);
		else if (nc == Screen_w) doScreen_w_NC(info);
		else if (nc == Screen_h) doScreen_h_NC(info);
		else if (nc == Screen_Location) doScreen_Location_NC(info);
		else if (nc == Screen_Size) doScreen_Size_NC(info);
		else if (nc == Screen_Split_Divider_Location) doScreen_Split_Divider_Location_NC(info);
	}

	/**
	 * [Screen]パネルの[x]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_x_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[y]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_y_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[w]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_w_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[h]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_h_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Location]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Location_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Size]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Size_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Split_Divider_Location]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Split_Divider_Location_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Screen_x) doScreen_x_NE(info);
		else if (ne == Screen_y) doScreen_y_NE(info);
		else if (ne == Screen_w) doScreen_w_NE(info);
		else if (ne == Screen_h) doScreen_h_NE(info);
		else if (ne == Screen_Location) doScreen_Location_NE(info);
		else if (ne == Screen_Size) doScreen_Size_NE(info);
		else if (ne == Screen_Split_Divider_Location) doScreen_Split_Divider_Location_NE(info);
	}

	/**
	 * [Screen]パネルの[x]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_x_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[y]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_y_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[w]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_w_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[h]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_h_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Location]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Location_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Size]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Size_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Split_Divider_Location]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Split_Divider_Location_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Screen_x) doScreen_x_NX(info);
		else if (nx == Screen_y) doScreen_y_NX(info);
		else if (nx == Screen_w) doScreen_w_NX(info);
		else if (nx == Screen_h) doScreen_h_NX(info);
		else if (nx == Screen_Location) doScreen_Location_NX(info);
		else if (nx == Screen_Size) doScreen_Size_NX(info);
		else if (nx == Screen_Split_Divider_Location) doScreen_Split_Divider_Location_NX(info);
	}

	/**
	 * [Screen]パネルの[x]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_x_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[y]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_y_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[w]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_w_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[h]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_h_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Location]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Location_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Size]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Size_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[Split_Divider_Location]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_Split_Divider_Location_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Screen_x) doScreen_x_LC(info);
		else if (lc == Screen_y) doScreen_y_LC(info);
		else if (lc == Screen_w) doScreen_w_LC(info);
		else if (lc == Screen_h) doScreen_h_LC(info);
	}

	/**
	 * [Screen]パネルの[x]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_x_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[y]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_y_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[w]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_w_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[h]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_h_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}