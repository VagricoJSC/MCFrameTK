package mcframe.clientFSBA.FSBAP0140;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Screen"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ScreenR_FW_A extends MCConstRow {

	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public static final String $x = "x";
	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public static final String $y = "y";
	/**
	 * 幅 幅.<p>
	 *
	 */
	public static final String $w = "w";
	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public static final String $h = "h";
	/**
	 * 位置を保存する 位置を保存する.<p>
	 *
	 */
	public static final String $Location = "Location";
	/**
	 * サイズを保存する サイズを保存する.<p>
	 *
	 */
	public static final String $Size = "Size";
	/**
	 * スプリット位置を保存する スプリット位置を保存する.<p>
	 *
	 */
	public static final String $Split_Divider_Location = "Split_Divider_Location";


	public static final MCMeta x_META = createNumberMeta($x, 10, 0, false);
	public static final MCMeta y_META = createNumberMeta($y, 10, 0, false);
	public static final MCMeta w_META = createNumberMeta($w, 10, 0, false);
	public static final MCMeta h_META = createNumberMeta($h, 10, 0, false);
	public static final MCMeta Location_META = createCommonMeta($Location, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta Size_META = createCommonMeta($Size, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta Split_Divider_Location_META = createCommonMeta($Split_Divider_Location, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<ScreenR> constMetas = new ConstMetaList<ScreenR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			x_META,
			y_META,
			w_META,
			h_META,
			Location_META,
			Size_META,
			Split_Divider_Location_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ScreenR_FW_A(ConstMetaList<? extends ScreenR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScreenR clone() {
		return (ScreenR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScreenR createInstance() {
		return (ScreenR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScreenR getValues(String... names) {
		return (ScreenR) super.getValues(names);
	}



	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public MCNumber x() {
		return getConstNumber(offset + 0, $x);
	}

	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public void x(MCNumber value) {
		setConstNumber(offset + 0, $x, value);
	}

	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public void x(int value) {
		setConstNumber(offset + 0, $x, value);
	}

	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public void x(long value) {
		setConstNumber(offset + 0, $x, value);
	}

	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public void x(float value) {
		setConstNumber(offset + 0, $x, value);
	}

	/**
	 * ｘ　座標位置 ｘ　座標位置.<p>
	 *
	 */
	public void x(double value) {
		setConstNumber(offset + 0, $x, value);
	}


	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public MCNumber y() {
		return getConstNumber(offset + 1, $y);
	}

	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public void y(MCNumber value) {
		setConstNumber(offset + 1, $y, value);
	}

	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public void y(int value) {
		setConstNumber(offset + 1, $y, value);
	}

	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public void y(long value) {
		setConstNumber(offset + 1, $y, value);
	}

	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public void y(float value) {
		setConstNumber(offset + 1, $y, value);
	}

	/**
	 * ｙ　座標位置 ｙ　座標位置.<p>
	 *
	 */
	public void y(double value) {
		setConstNumber(offset + 1, $y, value);
	}


	/**
	 * 幅 幅.<p>
	 *
	 */
	public MCNumber w() {
		return getConstNumber(offset + 2, $w);
	}

	/**
	 * 幅 幅.<p>
	 *
	 */
	public void w(MCNumber value) {
		setConstNumber(offset + 2, $w, value);
	}

	/**
	 * 幅 幅.<p>
	 *
	 */
	public void w(int value) {
		setConstNumber(offset + 2, $w, value);
	}

	/**
	 * 幅 幅.<p>
	 *
	 */
	public void w(long value) {
		setConstNumber(offset + 2, $w, value);
	}

	/**
	 * 幅 幅.<p>
	 *
	 */
	public void w(float value) {
		setConstNumber(offset + 2, $w, value);
	}

	/**
	 * 幅 幅.<p>
	 *
	 */
	public void w(double value) {
		setConstNumber(offset + 2, $w, value);
	}


	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public MCNumber h() {
		return getConstNumber(offset + 3, $h);
	}

	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public void h(MCNumber value) {
		setConstNumber(offset + 3, $h, value);
	}

	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public void h(int value) {
		setConstNumber(offset + 3, $h, value);
	}

	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public void h(long value) {
		setConstNumber(offset + 3, $h, value);
	}

	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public void h(float value) {
		setConstNumber(offset + 3, $h, value);
	}

	/**
	 * 高さ 高さ.<p>
	 *
	 */
	public void h(double value) {
		setConstNumber(offset + 3, $h, value);
	}


	/**
	 * 位置を保存する 位置を保存する.<p>
	 *
	 */
	public boolean Location() {
		return getConstBoolean(offset + 4, $Location);
	}

	/**
	 * 位置を保存する 位置を保存する.<p>
	 *
	 */
	public void Location(boolean value) {
		setConstBoolean(offset + 4, $Location, value);
	}


	/**
	 * サイズを保存する サイズを保存する.<p>
	 *
	 */
	public boolean Size() {
		return getConstBoolean(offset + 5, $Size);
	}

	/**
	 * サイズを保存する サイズを保存する.<p>
	 *
	 */
	public void Size(boolean value) {
		setConstBoolean(offset + 5, $Size, value);
	}


	/**
	 * スプリット位置を保存する スプリット位置を保存する.<p>
	 *
	 */
	public boolean Split_Divider_Location() {
		return getConstBoolean(offset + 6, $Split_Divider_Location);
	}

	/**
	 * スプリット位置を保存する スプリット位置を保存する.<p>
	 *
	 */
	public void Split_Divider_Location(boolean value) {
		setConstBoolean(offset + 6, $Split_Divider_Location, value);
	}


	public MCNumber getNumber(String name) {
		if ($x.equalsIgnoreCase(name)) {
			return x();
		}
		if ($y.equalsIgnoreCase(name)) {
			return y();
		}
		if ($w.equalsIgnoreCase(name)) {
			return w();
		}
		if ($h.equalsIgnoreCase(name)) {
			return h();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($Location.equalsIgnoreCase(name)) {
			return Location();
		}
		if ($Size.equalsIgnoreCase(name)) {
			return Size();
		}
		if ($Split_Divider_Location.equalsIgnoreCase(name)) {
			return Split_Divider_Location();
		}
		return super.getBoolean(name);
	}

	public MCNumber getNumberNE(String name) {
		if ($x.equalsIgnoreCase(name)) {
			return x();
		}
		if ($y.equalsIgnoreCase(name)) {
			return y();
		}
		if ($w.equalsIgnoreCase(name)) {
			return w();
		}
		if ($h.equalsIgnoreCase(name)) {
			return h();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($Location.equalsIgnoreCase(name)) {
			return Location();
		}
		if ($Size.equalsIgnoreCase(name)) {
			return Size();
		}
		if ($Split_Divider_Location.equalsIgnoreCase(name)) {
			return Split_Divider_Location();
		}
		return super.getBooleanNE(name);
	}

	public void setNumber(String name, MCNumber value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($Location.equalsIgnoreCase(name)) {
			Location(value);
			return;
		}
		if ($Size.equalsIgnoreCase(name)) {
			Size(value);
			return;
		}
		if ($Split_Divider_Location.equalsIgnoreCase(name)) {
			Split_Divider_Location(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setNumberNE(String name, MCNumber value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($x.equalsIgnoreCase(name)) {
			x(value);
			return;
		}
		if ($y.equalsIgnoreCase(name)) {
			y(value);
			return;
		}
		if ($w.equalsIgnoreCase(name)) {
			w(value);
			return;
		}
		if ($h.equalsIgnoreCase(name)) {
			h(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($Location.equalsIgnoreCase(name)) {
			Location(value);
			return;
		}
		if ($Size.equalsIgnoreCase(name)) {
			Size(value);
			return;
		}
		if ($Split_Divider_Location.equalsIgnoreCase(name)) {
			Split_Divider_Location(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

