package mcframe.clientFSBA.FSBAP0070;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0070"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0070_FW_A extends MCRootPanel{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0070";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Date]ブロック関連のField定義
	public MCPanel DatePanel = null;
	// [Date]ブロックの項目のField定義
	/**
	 *  Sun..<p>
	 *
	 */
	public MCLabel Date_Su = null;
	/**
	 *  Mon..<p>
	 *
	 */
	public MCLabel Date_Mo = null;
	/**
	 *  Tue..<p>
	 *
	 */
	public MCLabel Date_Tu = null;
	/**
	 *  Wed..<p>
	 *
	 */
	public MCLabel Date_We = null;
	/**
	 *  Thu..<p>
	 *
	 */
	public MCLabel Date_Th = null;
	/**
	 *  Fri..<p>
	 *
	 */
	public MCLabel Date_Fr = null;
	/**
	 *  Sat..<p>
	 *
	 */
	public MCLabel Date_Sa = null;
	public MCButton Date_b01 = null;
	public MCButton Date_b02 = null;
	public MCButton Date_b03 = null;
	public MCButton Date_b04 = null;
	public MCButton Date_b05 = null;
	public MCButton Date_b06 = null;
	public MCButton Date_b07 = null;
	public MCButton Date_b08 = null;
	public MCButton Date_b09 = null;
	public MCButton Date_b10 = null;
	public MCButton Date_b11 = null;
	public MCButton Date_b12 = null;
	public MCButton Date_b13 = null;
	public MCButton Date_b14 = null;
	public MCButton Date_b15 = null;
	public MCButton Date_b16 = null;
	public MCButton Date_b17 = null;
	public MCButton Date_b18 = null;
	public MCButton Date_b19 = null;
	public MCButton Date_b20 = null;
	public MCButton Date_b21 = null;
	public MCButton Date_b22 = null;
	public MCButton Date_b23 = null;
	public MCButton Date_b24 = null;
	public MCButton Date_b25 = null;
	public MCButton Date_b26 = null;
	public MCButton Date_b27 = null;
	public MCButton Date_b28 = null;
	public MCButton Date_b29 = null;
	public MCButton Date_b30 = null;
	public MCButton Date_b31 = null;
	public MCButton Date_b32 = null;
	public MCButton Date_b33 = null;
	public MCButton Date_b34 = null;
	public MCButton Date_b35 = null;
	public MCButton Date_b36 = null;
	public MCButton Date_b37 = null;
	public MCButton Date_b38 = null;
	public MCButton Date_b39 = null;
	public MCButton Date_b40 = null;
	public MCButton Date_b41 = null;
	public MCButton Date_b42 = null;

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(DatePanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0070_FW_A() {

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0070_FW.jbCreateDate((FSBAP0070)this);
	}

	/**
	 * [Date]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDate(FSBAP0070 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0070 create(){
		FSBAP0070 p = new FSBAP0070();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0070_FW.jbfInitDate((FSBAP0070)this);
		FSBAP0070_FW.jbInitDate((FSBAP0070)this);
	}

	/**
	 * [Date]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDate(FSBAP0070 p) {
		// ブロック関連の初期化
		p.DatePanel = p.beansFactory.createPanel("Date");
		// ブロックの項目の初期化
		p.Date_Su = p.beansFactory.createLabel("Date.Su");
		p.Date_Mo = p.beansFactory.createLabel("Date.Mo");
		p.Date_Tu = p.beansFactory.createLabel("Date.Tu");
		p.Date_We = p.beansFactory.createLabel("Date.We");
		p.Date_Th = p.beansFactory.createLabel("Date.Th");
		p.Date_Fr = p.beansFactory.createLabel("Date.Fr");
		p.Date_Sa = p.beansFactory.createLabel("Date.Sa");
		p.Date_b01 = p.beansFactory.createButton("Date.b01", "calender_date");
		p.Date_b02 = p.beansFactory.createButton("Date.b02", "calender_date");
		p.Date_b03 = p.beansFactory.createButton("Date.b03", "calender_date");
		p.Date_b04 = p.beansFactory.createButton("Date.b04", "calender_date");
		p.Date_b05 = p.beansFactory.createButton("Date.b05", "calender_date");
		p.Date_b06 = p.beansFactory.createButton("Date.b06", "calender_date");
		p.Date_b07 = p.beansFactory.createButton("Date.b07", "calender_date");
		p.Date_b08 = p.beansFactory.createButton("Date.b08", "calender_date");
		p.Date_b09 = p.beansFactory.createButton("Date.b09", "calender_date");
		p.Date_b10 = p.beansFactory.createButton("Date.b10", "calender_date");
		p.Date_b11 = p.beansFactory.createButton("Date.b11", "calender_date");
		p.Date_b12 = p.beansFactory.createButton("Date.b12", "calender_date");
		p.Date_b13 = p.beansFactory.createButton("Date.b13", "calender_date");
		p.Date_b14 = p.beansFactory.createButton("Date.b14", "calender_date");
		p.Date_b15 = p.beansFactory.createButton("Date.b15", "calender_date");
		p.Date_b16 = p.beansFactory.createButton("Date.b16", "calender_date");
		p.Date_b17 = p.beansFactory.createButton("Date.b17", "calender_date");
		p.Date_b18 = p.beansFactory.createButton("Date.b18", "calender_date");
		p.Date_b19 = p.beansFactory.createButton("Date.b19", "calender_date");
		p.Date_b20 = p.beansFactory.createButton("Date.b20", "calender_date");
		p.Date_b21 = p.beansFactory.createButton("Date.b21", "calender_date");
		p.Date_b22 = p.beansFactory.createButton("Date.b22", "calender_date");
		p.Date_b23 = p.beansFactory.createButton("Date.b23", "calender_date");
		p.Date_b24 = p.beansFactory.createButton("Date.b24", "calender_date");
		p.Date_b25 = p.beansFactory.createButton("Date.b25", "calender_date");
		p.Date_b26 = p.beansFactory.createButton("Date.b26", "calender_date");
		p.Date_b27 = p.beansFactory.createButton("Date.b27", "calender_date");
		p.Date_b28 = p.beansFactory.createButton("Date.b28", "calender_date");
		p.Date_b29 = p.beansFactory.createButton("Date.b29", "calender_date");
		p.Date_b30 = p.beansFactory.createButton("Date.b30", "calender_date");
		p.Date_b31 = p.beansFactory.createButton("Date.b31", "calender_date");
		p.Date_b32 = p.beansFactory.createButton("Date.b32", "calender_date");
		p.Date_b33 = p.beansFactory.createButton("Date.b33", "calender_date");
		p.Date_b34 = p.beansFactory.createButton("Date.b34", "calender_date");
		p.Date_b35 = p.beansFactory.createButton("Date.b35", "calender_date");
		p.Date_b36 = p.beansFactory.createButton("Date.b36", "calender_date");
		p.Date_b37 = p.beansFactory.createButton("Date.b37", "calender_date");
		p.Date_b38 = p.beansFactory.createButton("Date.b38", "calender_date");
		p.Date_b39 = p.beansFactory.createButton("Date.b39", "calender_date");
		p.Date_b40 = p.beansFactory.createButton("Date.b40", "calender_date");
		p.Date_b41 = p.beansFactory.createButton("Date.b41", "calender_date");
		p.Date_b42 = p.beansFactory.createButton("Date.b42", "calender_date");
	}

	/**
	 * [Date]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDate(FSBAP0070 p) {
		// ブロック関連の初期化
		p.add(p.DatePanel);
		p.setFirstBeans(p.DatePanel);
		// ブロックの項目の初期化
		p.DatePanel.add(p.Date_Su);
		p.DatePanel.add(p.Date_Mo);
		p.DatePanel.add(p.Date_Tu);
		p.DatePanel.add(p.Date_We);
		p.DatePanel.add(p.Date_Th);
		p.DatePanel.add(p.Date_Fr);
		p.DatePanel.add(p.Date_Sa);
		p.DatePanel.add(p.Date_b01);
		p.DatePanel.setFirstBeans(p.Date_b01);
		p.Date_b01.setNextBeans(p.Date_b02);
		p.DatePanel.add(p.Date_b02);
		p.Date_b02.setNextBeans(p.Date_b03);
		p.DatePanel.add(p.Date_b03);
		p.Date_b03.setNextBeans(p.Date_b04);
		p.DatePanel.add(p.Date_b04);
		p.Date_b04.setNextBeans(p.Date_b05);
		p.DatePanel.add(p.Date_b05);
		p.Date_b05.setNextBeans(p.Date_b06);
		p.DatePanel.add(p.Date_b06);
		p.Date_b06.setNextBeans(p.Date_b07);
		p.DatePanel.add(p.Date_b07);
		p.Date_b07.setNextBeans(p.Date_b08);
		p.DatePanel.add(p.Date_b08);
		p.Date_b08.setNextBeans(p.Date_b09);
		p.DatePanel.add(p.Date_b09);
		p.Date_b09.setNextBeans(p.Date_b10);
		p.DatePanel.add(p.Date_b10);
		p.Date_b10.setNextBeans(p.Date_b11);
		p.DatePanel.add(p.Date_b11);
		p.Date_b11.setNextBeans(p.Date_b12);
		p.DatePanel.add(p.Date_b12);
		p.Date_b12.setNextBeans(p.Date_b13);
		p.DatePanel.add(p.Date_b13);
		p.Date_b13.setNextBeans(p.Date_b14);
		p.DatePanel.add(p.Date_b14);
		p.Date_b14.setNextBeans(p.Date_b15);
		p.DatePanel.add(p.Date_b15);
		p.Date_b15.setNextBeans(p.Date_b16);
		p.DatePanel.add(p.Date_b16);
		p.Date_b16.setNextBeans(p.Date_b17);
		p.DatePanel.add(p.Date_b17);
		p.Date_b17.setNextBeans(p.Date_b18);
		p.DatePanel.add(p.Date_b18);
		p.Date_b18.setNextBeans(p.Date_b19);
		p.DatePanel.add(p.Date_b19);
		p.Date_b19.setNextBeans(p.Date_b20);
		p.DatePanel.add(p.Date_b20);
		p.Date_b20.setNextBeans(p.Date_b21);
		p.DatePanel.add(p.Date_b21);
		p.Date_b21.setNextBeans(p.Date_b22);
		p.DatePanel.add(p.Date_b22);
		p.Date_b22.setNextBeans(p.Date_b23);
		p.DatePanel.add(p.Date_b23);
		p.Date_b23.setNextBeans(p.Date_b24);
		p.DatePanel.add(p.Date_b24);
		p.Date_b24.setNextBeans(p.Date_b25);
		p.DatePanel.add(p.Date_b25);
		p.Date_b25.setNextBeans(p.Date_b26);
		p.DatePanel.add(p.Date_b26);
		p.Date_b26.setNextBeans(p.Date_b27);
		p.DatePanel.add(p.Date_b27);
		p.Date_b27.setNextBeans(p.Date_b28);
		p.DatePanel.add(p.Date_b28);
		p.Date_b28.setNextBeans(p.Date_b29);
		p.DatePanel.add(p.Date_b29);
		p.Date_b29.setNextBeans(p.Date_b30);
		p.DatePanel.add(p.Date_b30);
		p.Date_b30.setNextBeans(p.Date_b31);
		p.DatePanel.add(p.Date_b31);
		p.Date_b31.setNextBeans(p.Date_b32);
		p.DatePanel.add(p.Date_b32);
		p.Date_b32.setNextBeans(p.Date_b33);
		p.DatePanel.add(p.Date_b33);
		p.Date_b33.setNextBeans(p.Date_b34);
		p.DatePanel.add(p.Date_b34);
		p.Date_b34.setNextBeans(p.Date_b35);
		p.DatePanel.add(p.Date_b35);
		p.Date_b35.setNextBeans(p.Date_b36);
		p.DatePanel.add(p.Date_b36);
		p.Date_b36.setNextBeans(p.Date_b37);
		p.DatePanel.add(p.Date_b37);
		p.Date_b37.setNextBeans(p.Date_b38);
		p.DatePanel.add(p.Date_b38);
		p.Date_b38.setNextBeans(p.Date_b39);
		p.DatePanel.add(p.Date_b39);
		p.Date_b39.setNextBeans(p.Date_b40);
		p.DatePanel.add(p.Date_b40);
		p.Date_b40.setNextBeans(p.Date_b41);
		p.DatePanel.add(p.Date_b41);
		p.Date_b41.setNextBeans(p.Date_b42);
		p.DatePanel.add(p.Date_b42);
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0070_FW.mcInitDate((FSBAP0070)this);

	}

	/**
	 *  [Date]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDate(FSBAP0070 p) {
		p.Date_b01.addAllListener(p);
		p.Date_b01.setAPMethodName("doDate_b01");
		p.Date_b02.addAllListener(p);
		p.Date_b02.setAPMethodName("doDate_b02");
		p.Date_b03.addAllListener(p);
		p.Date_b03.setAPMethodName("doDate_b03");
		p.Date_b04.addAllListener(p);
		p.Date_b04.setAPMethodName("doDate_b04");
		p.Date_b05.addAllListener(p);
		p.Date_b05.setAPMethodName("doDate_b05");
		p.Date_b06.addAllListener(p);
		p.Date_b06.setAPMethodName("doDate_b06");
		p.Date_b07.addAllListener(p);
		p.Date_b07.setAPMethodName("doDate_b07");
		p.Date_b08.addAllListener(p);
		p.Date_b08.setAPMethodName("doDate_b08");
		p.Date_b09.addAllListener(p);
		p.Date_b09.setAPMethodName("doDate_b09");
		p.Date_b10.addAllListener(p);
		p.Date_b10.setAPMethodName("doDate_b10");
		p.Date_b11.addAllListener(p);
		p.Date_b11.setAPMethodName("doDate_b11");
		p.Date_b12.addAllListener(p);
		p.Date_b12.setAPMethodName("doDate_b12");
		p.Date_b13.addAllListener(p);
		p.Date_b13.setAPMethodName("doDate_b13");
		p.Date_b14.addAllListener(p);
		p.Date_b14.setAPMethodName("doDate_b14");
		p.Date_b15.addAllListener(p);
		p.Date_b15.setAPMethodName("doDate_b15");
		p.Date_b16.addAllListener(p);
		p.Date_b16.setAPMethodName("doDate_b16");
		p.Date_b17.addAllListener(p);
		p.Date_b17.setAPMethodName("doDate_b17");
		p.Date_b18.addAllListener(p);
		p.Date_b18.setAPMethodName("doDate_b18");
		p.Date_b19.addAllListener(p);
		p.Date_b19.setAPMethodName("doDate_b19");
		p.Date_b20.addAllListener(p);
		p.Date_b20.setAPMethodName("doDate_b20");
		p.Date_b21.addAllListener(p);
		p.Date_b21.setAPMethodName("doDate_b21");
		p.Date_b22.addAllListener(p);
		p.Date_b22.setAPMethodName("doDate_b22");
		p.Date_b23.addAllListener(p);
		p.Date_b23.setAPMethodName("doDate_b23");
		p.Date_b24.addAllListener(p);
		p.Date_b24.setAPMethodName("doDate_b24");
		p.Date_b25.addAllListener(p);
		p.Date_b25.setAPMethodName("doDate_b25");
		p.Date_b26.addAllListener(p);
		p.Date_b26.setAPMethodName("doDate_b26");
		p.Date_b27.addAllListener(p);
		p.Date_b27.setAPMethodName("doDate_b27");
		p.Date_b28.addAllListener(p);
		p.Date_b28.setAPMethodName("doDate_b28");
		p.Date_b29.addAllListener(p);
		p.Date_b29.setAPMethodName("doDate_b29");
		p.Date_b30.addAllListener(p);
		p.Date_b30.setAPMethodName("doDate_b30");
		p.Date_b31.addAllListener(p);
		p.Date_b31.setAPMethodName("doDate_b31");
		p.Date_b32.addAllListener(p);
		p.Date_b32.setAPMethodName("doDate_b32");
		p.Date_b33.addAllListener(p);
		p.Date_b33.setAPMethodName("doDate_b33");
		p.Date_b34.addAllListener(p);
		p.Date_b34.setAPMethodName("doDate_b34");
		p.Date_b35.addAllListener(p);
		p.Date_b35.setAPMethodName("doDate_b35");
		p.Date_b36.addAllListener(p);
		p.Date_b36.setAPMethodName("doDate_b36");
		p.Date_b37.addAllListener(p);
		p.Date_b37.setAPMethodName("doDate_b37");
		p.Date_b38.addAllListener(p);
		p.Date_b38.setAPMethodName("doDate_b38");
		p.Date_b39.addAllListener(p);
		p.Date_b39.setAPMethodName("doDate_b39");
		p.Date_b40.addAllListener(p);
		p.Date_b40.setAPMethodName("doDate_b40");
		p.Date_b41.addAllListener(p);
		p.Date_b41.setAPMethodName("doDate_b41");
		p.Date_b42.addAllListener(p);
		p.Date_b42.setAPMethodName("doDate_b42");
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Date_b01) doDate_b01(info);
		else if (ap == Date_b02) doDate_b02(info);
		else if (ap == Date_b03) doDate_b03(info);
		else if (ap == Date_b04) doDate_b04(info);
		else if (ap == Date_b05) doDate_b05(info);
		else if (ap == Date_b06) doDate_b06(info);
		else if (ap == Date_b07) doDate_b07(info);
		else if (ap == Date_b08) doDate_b08(info);
		else if (ap == Date_b09) doDate_b09(info);
		else if (ap == Date_b10) doDate_b10(info);
		else if (ap == Date_b11) doDate_b11(info);
		else if (ap == Date_b12) doDate_b12(info);
		else if (ap == Date_b13) doDate_b13(info);
		else if (ap == Date_b14) doDate_b14(info);
		else if (ap == Date_b15) doDate_b15(info);
		else if (ap == Date_b16) doDate_b16(info);
		else if (ap == Date_b17) doDate_b17(info);
		else if (ap == Date_b18) doDate_b18(info);
		else if (ap == Date_b19) doDate_b19(info);
		else if (ap == Date_b20) doDate_b20(info);
		else if (ap == Date_b21) doDate_b21(info);
		else if (ap == Date_b22) doDate_b22(info);
		else if (ap == Date_b23) doDate_b23(info);
		else if (ap == Date_b24) doDate_b24(info);
		else if (ap == Date_b25) doDate_b25(info);
		else if (ap == Date_b26) doDate_b26(info);
		else if (ap == Date_b27) doDate_b27(info);
		else if (ap == Date_b28) doDate_b28(info);
		else if (ap == Date_b29) doDate_b29(info);
		else if (ap == Date_b30) doDate_b30(info);
		else if (ap == Date_b31) doDate_b31(info);
		else if (ap == Date_b32) doDate_b32(info);
		else if (ap == Date_b33) doDate_b33(info);
		else if (ap == Date_b34) doDate_b34(info);
		else if (ap == Date_b35) doDate_b35(info);
		else if (ap == Date_b36) doDate_b36(info);
		else if (ap == Date_b37) doDate_b37(info);
		else if (ap == Date_b38) doDate_b38(info);
		else if (ap == Date_b39) doDate_b39(info);
		else if (ap == Date_b40) doDate_b40(info);
		else if (ap == Date_b41) doDate_b41(info);
		else if (ap == Date_b42) doDate_b42(info);
	}

	/**
	 * [Date]パネルの[b01]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b01(MCEventInfo info);

	/**
	 * [Date]パネルの[b02]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b02(MCEventInfo info);

	/**
	 * [Date]パネルの[b03]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b03(MCEventInfo info);

	/**
	 * [Date]パネルの[b04]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b04(MCEventInfo info);

	/**
	 * [Date]パネルの[b05]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b05(MCEventInfo info);

	/**
	 * [Date]パネルの[b06]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b06(MCEventInfo info);

	/**
	 * [Date]パネルの[b07]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b07(MCEventInfo info);

	/**
	 * [Date]パネルの[b08]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b08(MCEventInfo info);

	/**
	 * [Date]パネルの[b09]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b09(MCEventInfo info);

	/**
	 * [Date]パネルの[b10]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b10(MCEventInfo info);

	/**
	 * [Date]パネルの[b11]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b11(MCEventInfo info);

	/**
	 * [Date]パネルの[b12]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b12(MCEventInfo info);

	/**
	 * [Date]パネルの[b13]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b13(MCEventInfo info);

	/**
	 * [Date]パネルの[b14]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b14(MCEventInfo info);

	/**
	 * [Date]パネルの[b15]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b15(MCEventInfo info);

	/**
	 * [Date]パネルの[b16]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b16(MCEventInfo info);

	/**
	 * [Date]パネルの[b17]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b17(MCEventInfo info);

	/**
	 * [Date]パネルの[b18]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b18(MCEventInfo info);

	/**
	 * [Date]パネルの[b19]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b19(MCEventInfo info);

	/**
	 * [Date]パネルの[b20]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b20(MCEventInfo info);

	/**
	 * [Date]パネルの[b21]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b21(MCEventInfo info);

	/**
	 * [Date]パネルの[b22]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b22(MCEventInfo info);

	/**
	 * [Date]パネルの[b23]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b23(MCEventInfo info);

	/**
	 * [Date]パネルの[b24]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b24(MCEventInfo info);

	/**
	 * [Date]パネルの[b25]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b25(MCEventInfo info);

	/**
	 * [Date]パネルの[b26]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b26(MCEventInfo info);

	/**
	 * [Date]パネルの[b27]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b27(MCEventInfo info);

	/**
	 * [Date]パネルの[b28]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b28(MCEventInfo info);

	/**
	 * [Date]パネルの[b29]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b29(MCEventInfo info);

	/**
	 * [Date]パネルの[b30]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b30(MCEventInfo info);

	/**
	 * [Date]パネルの[b31]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b31(MCEventInfo info);

	/**
	 * [Date]パネルの[b32]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b32(MCEventInfo info);

	/**
	 * [Date]パネルの[b33]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b33(MCEventInfo info);

	/**
	 * [Date]パネルの[b34]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b34(MCEventInfo info);

	/**
	 * [Date]パネルの[b35]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b35(MCEventInfo info);

	/**
	 * [Date]パネルの[b36]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b36(MCEventInfo info);

	/**
	 * [Date]パネルの[b37]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b37(MCEventInfo info);

	/**
	 * [Date]パネルの[b38]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b38(MCEventInfo info);

	/**
	 * [Date]パネルの[b39]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b39(MCEventInfo info);

	/**
	 * [Date]パネルの[b40]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b40(MCEventInfo info);

	/**
	 * [Date]パネルの[b41]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b41(MCEventInfo info);

	/**
	 * [Date]パネルの[b42]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDate_b42(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}