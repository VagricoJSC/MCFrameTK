package mcframe.clientFSBA.FSBAP0070;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.SwingUtilities;

import mcframe.clientCore.beans.popup.MCCalendarPopup;
import mcframe.clientFSBA.FSBAP0000.IfCalendarDatePanel;
import mcframe.clientFSBA.FSBAP0000.IfCalendarPanel;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0070"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0070_FW extends FSBAP0070_FW_A implements IfCalendarDatePanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * ボタンを日付のマッピング情報です。
	 */
	private LinkedHashMap<MCButton, MCCalendarDate<?>> map = 
		new LinkedHashMap<MCButton, MCCalendarDate<?>>();
	
	/**
	 * 日付ボタンです。
	 */
	private MCButton[] buttons = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0070_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Date]のボタン[b01]の押下時の処理
	 */
	public void doDate_b01(MCEventInfo info) {
		doDateButtonAction(Date_b01);
	}

	/**
	 * Panel[Date]のボタン[b02]の押下時の処理
	 */
	public void doDate_b02(MCEventInfo info) {
		doDateButtonAction(Date_b02);
	}

	/**
	 * Panel[Date]のボタン[b03]の押下時の処理
	 */
	public void doDate_b03(MCEventInfo info) {
		doDateButtonAction(Date_b03);
	}

	/**
	 * Panel[Date]のボタン[b04]の押下時の処理
	 */
	public void doDate_b04(MCEventInfo info) {
		doDateButtonAction(Date_b04);
	}

	/**
	 * Panel[Date]のボタン[b05]の押下時の処理
	 */
	public void doDate_b05(MCEventInfo info) {
		doDateButtonAction(Date_b05);
	}

	/**
	 * Panel[Date]のボタン[b06]の押下時の処理
	 */
	public void doDate_b06(MCEventInfo info) {
		doDateButtonAction(Date_b06);
	}

	/**
	 * Panel[Date]のボタン[b07]の押下時の処理
	 */
	public void doDate_b07(MCEventInfo info) {
		doDateButtonAction(Date_b07);
	}

	/**
	 * Panel[Date]のボタン[b08]の押下時の処理
	 */
	public void doDate_b08(MCEventInfo info) {
		doDateButtonAction(Date_b08);
	}

	/**
	 * Panel[Date]のボタン[b09]の押下時の処理
	 */
	public void doDate_b09(MCEventInfo info) {
		doDateButtonAction(Date_b09);
	}

	/**
	 * Panel[Date]のボタン[b10]の押下時の処理
	 */
	public void doDate_b10(MCEventInfo info) {
		doDateButtonAction(Date_b10);
	}

	/**
	 * Panel[Date]のボタン[b11]の押下時の処理
	 */
	public void doDate_b11(MCEventInfo info) {
		doDateButtonAction(Date_b11);
	}

	/**
	 * Panel[Date]のボタン[b12]の押下時の処理
	 */
	public void doDate_b12(MCEventInfo info) {
		doDateButtonAction(Date_b12);
	}

	/**
	 * Panel[Date]のボタン[b13]の押下時の処理
	 */
	public void doDate_b13(MCEventInfo info) {
		doDateButtonAction(Date_b13);
	}

	/**
	 * Panel[Date]のボタン[b14]の押下時の処理
	 */
	public void doDate_b14(MCEventInfo info) {
		doDateButtonAction(Date_b14);
	}

	/**
	 * Panel[Date]のボタン[b15]の押下時の処理
	 */
	public void doDate_b15(MCEventInfo info) {
		doDateButtonAction(Date_b15);
	}

	/**
	 * Panel[Date]のボタン[b16]の押下時の処理
	 */
	public void doDate_b16(MCEventInfo info) {
		doDateButtonAction(Date_b16);
	}

	/**
	 * Panel[Date]のボタン[b17]の押下時の処理
	 */
	public void doDate_b17(MCEventInfo info) {
		doDateButtonAction(Date_b17);
	}

	/**
	 * Panel[Date]のボタン[b18]の押下時の処理
	 */
	public void doDate_b18(MCEventInfo info) {
		doDateButtonAction(Date_b18);
	}

	/**
	 * Panel[Date]のボタン[b19]の押下時の処理
	 */
	public void doDate_b19(MCEventInfo info) {
		doDateButtonAction(Date_b19);
	}

	/**
	 * Panel[Date]のボタン[b20]の押下時の処理
	 */
	public void doDate_b20(MCEventInfo info) {
		doDateButtonAction(Date_b20);
	}

	/**
	 * Panel[Date]のボタン[b21]の押下時の処理
	 */
	public void doDate_b21(MCEventInfo info) {
		doDateButtonAction(Date_b21);
	}

	/**
	 * Panel[Date]のボタン[b22]の押下時の処理
	 */
	public void doDate_b22(MCEventInfo info) {
		doDateButtonAction(Date_b22);
	}

	/**
	 * Panel[Date]のボタン[b23]の押下時の処理
	 */
	public void doDate_b23(MCEventInfo info) {
		doDateButtonAction(Date_b23);
	}

	/**
	 * Panel[Date]のボタン[b24]の押下時の処理
	 */
	public void doDate_b24(MCEventInfo info) {
		doDateButtonAction(Date_b24);
	}

	/**
	 * Panel[Date]のボタン[b25]の押下時の処理
	 */
	public void doDate_b25(MCEventInfo info) {
		doDateButtonAction(Date_b25);
	}

	/**
	 * Panel[Date]のボタン[b26]の押下時の処理
	 */
	public void doDate_b26(MCEventInfo info) {
		doDateButtonAction(Date_b26);
	}

	/**
	 * Panel[Date]のボタン[b27]の押下時の処理
	 */
	public void doDate_b27(MCEventInfo info) {
		doDateButtonAction(Date_b27);
	}

	/**
	 * Panel[Date]のボタン[b28]の押下時の処理
	 */
	public void doDate_b28(MCEventInfo info) {
		doDateButtonAction(Date_b28);
	}

	/**
	 * Panel[Date]のボタン[b29]の押下時の処理
	 */
	public void doDate_b29(MCEventInfo info) {
		doDateButtonAction(Date_b29);
	}

	/**
	 * Panel[Date]のボタン[b30]の押下時の処理
	 */
	public void doDate_b30(MCEventInfo info) {
		doDateButtonAction(Date_b30);
	}

	/**
	 * Panel[Date]のボタン[b31]の押下時の処理
	 */
	public void doDate_b31(MCEventInfo info) {
		doDateButtonAction(Date_b31);
	}

	/**
	 * Panel[Date]のボタン[b32]の押下時の処理
	 */
	public void doDate_b32(MCEventInfo info) {
		doDateButtonAction(Date_b32);
	}

	/**
	 * Panel[Date]のボタン[b33]の押下時の処理
	 */
	public void doDate_b33(MCEventInfo info) {
		doDateButtonAction(Date_b33);
	}

	/**
	 * Panel[Date]のボタン[b34]の押下時の処理
	 */
	public void doDate_b34(MCEventInfo info) {
		doDateButtonAction(Date_b34);
	}

	/**
	 * Panel[Date]のボタン[b35]の押下時の処理
	 */
	public void doDate_b35(MCEventInfo info) {
		doDateButtonAction(Date_b35);
	}

	/**
	 * Panel[Date]のボタン[b36]の押下時の処理
	 */
	public void doDate_b36(MCEventInfo info) {
		doDateButtonAction(Date_b36);
	}

	/**
	 * Panel[Date]のボタン[b37]の押下時の処理
	 */
	public void doDate_b37(MCEventInfo info) {
		doDateButtonAction(Date_b37);
	}

	/**
	 * Panel[Date]のボタン[b38]の押下時の処理
	 */
	public void doDate_b38(MCEventInfo info) {
		doDateButtonAction(Date_b38);
	}

	/**
	 * Panel[Date]のボタン[b39]の押下時の処理
	 */
	public void doDate_b39(MCEventInfo info) {
		doDateButtonAction(Date_b39);
	}

	/**
	 * Panel[Date]のボタン[b40]の押下時の処理
	 */
	public void doDate_b40(MCEventInfo info) {
		doDateButtonAction(Date_b40);
	}

	/**
	 * Panel[Date]のボタン[b41]の押下時の処理
	 */
	public void doDate_b41(MCEventInfo info) {
		doDateButtonAction(Date_b41);
	}

	/**
	 * Panel[Date]のボタン[b42]の押下時の処理
	 */
	public void doDate_b42(MCEventInfo info) {
		doDateButtonAction(Date_b42);
	}
	
	@Override
	protected void mcInit() {
		super.mcInit();
		
		Date_Su.setHorizontalAlignment(MCLabel.CENTER);
		Date_Mo.setHorizontalAlignment(MCLabel.CENTER);
		Date_Tu.setHorizontalAlignment(MCLabel.CENTER);
		Date_We.setHorizontalAlignment(MCLabel.CENTER);
		Date_Th.setHorizontalAlignment(MCLabel.CENTER);
		Date_Fr.setHorizontalAlignment(MCLabel.CENTER);
		Date_Sa.setHorizontalAlignment(MCLabel.CENTER);
		
		initDateButton();
	}
	
	@Override
	public void afterOpen() {
		super.afterOpen();
		setInitFocus();
	}

	/**
	 * 初期フォーカスを設定します。
	 */
	protected void setInitFocus() {
		if (!getCalendarPanel().getCalendarPopup().addedToLayerdPane()) {
			MCButton c = getDateButton(
					getCalendarPanel().getCalendarPopup().getCurrentDate());
			if (c != null) {
				SwingUtilities.invokeLater(() -> c.mcRequestFocus());
//				c.mcRequestFocus();
			}
		}
	}
	
	public IfCalendarPanel getCalendarPanel() {
		MCRootPanel p = getBaseRootPanel();
		return p instanceof IfCalendarPanel ? (IfCalendarPanel)p : null;
	}
	
	/**
	 * 日付ボタンと日付のマップを返します。
	 *
	 * @return マップ
	 */
	public final Map<MCButton, MCCalendarDate<?>> getDateMap() {
		return map;
	}
	
	/**
	 * 日付ボタンを配列で返します。
	 * 
	 * @return 日付ボタンの配列
	 */
	public final MCButton[] getDateButtons() {
		if (buttons == null) {
			buttons = new MCButton[] {
					Date_b01, Date_b02, Date_b03, Date_b04, Date_b05, Date_b06, 
					Date_b07, Date_b08, Date_b09, Date_b10, Date_b11, Date_b12, 
					Date_b13, Date_b14, Date_b15, Date_b16, Date_b17, Date_b18, 
					Date_b19, Date_b20, Date_b21, Date_b22, Date_b23, Date_b24, 
					Date_b25, Date_b26, Date_b27, Date_b28, Date_b29, Date_b30, 
					Date_b31, Date_b32, Date_b33, Date_b34, Date_b35, Date_b36, 
					Date_b37, Date_b38, Date_b39, Date_b40, Date_b41, Date_b42
			};
		}
		return buttons;
	}
	
	/**
	 * 日付ボタンを返します。
	 * 指定された日付とマッピングされている日付ボタンを返します。
	 * 日付ボタンが見つからなかった場合は null を返します。
	 *
	 * @param value 日付
	 * @return 日付ボタンまたは null
	 */
	@SuppressWarnings("unchecked")
	protected MCButton getDateButton(MCCalendarDate value) {
		for (MCButton c : getDateButtons()) {
			MCCalendarDate d = getDateMap().get(c);
			if (d.eqDate(value)) {
				return c;
			}
		}
		return null;
	}
	
	/**
	 * 日付ボタンが押下されたときに実行されます。
	 * 
	 * @param compo 日付ボタン
	 */
	protected void doDateButtonAction(MCButton compo) {
		MCCalendarPopup p = getCalendarPanel().getCalendarPopup();
		if (p.addedToLayerdPane()) {
			Component cp = (Component)p.getCalendarPanel();
			if (cp != null && !cp.isVisible()) {
				return;
			}
		}
		else {
			if (!p.isVisible()) {
				return;
			}
		}
		
		p.setCalendarValue(getDateMap().get(compo));
		if (p.addedToLayerdPane()) {
			p.hideIfAddedToLayerdPane(true);
		}
		else {
			MCRootPanel rp = compo.getBaseRootPanel();
			rp.requestCloseWindow();
			rp.getParent().remove(rp);
			((Component) p.getCalendarBeans()).requestFocus();
		}
	}
	
	/**
	 * 日付ボタンに日付を設定します。
	 * カレンダポップアップの基準月に合わせて日付ボタンに日付を設定します。
	 */
	public void setButtonDate() {
		MCCalendarDate<?> v = 
				getCalendarPanel().getCalendarPopup().getCurrentDate();
		v = v.startOfMonth();
		v = v.addDay(-1 * (v.getDayOfWeek() - 1));
		map.clear();
		for (MCButton c : getDateButtons()) {
			map.put(c, v);
			setButtonDate(c, v);
			v = v.addDay(1);
		}
	}
	
	/**
	 * 日付ボタンに日付を設定します。
	 *
	 * @param compo 日付ボタン
	 * @param value 日付
	 */
	protected void setButtonDate(MCButton compo, MCCalendarDate<?> value) {
		getCalendarPanel().setButtonDate(compo, value);
	}
	
	/**
	 * 日付ボタンのインデックス値を返します。
	 * {@link #getDateButtons()} の配列の中のインデックス値を返します。
	 * 
	 * @param compo ボタン
	 * @return インデックス値
	 * @see #getDateButtons()
	 */
	protected int getButtonNumber(MCButton compo) {
		if (compo == null) {
			return -1;
		}

		MCButton[] a = getDateButtons();
		for (int i=0;i<a.length;i++) {
			if (a[i] == compo) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * 日付ボタンにキーリスナを設定します。
	 */
	protected void addKeyListener() {
		for (MCButton c : getDateButtons()) {
			c.addKeyListener(createMCButtonKeyAdapter());
		}
	}
	
	/**
	 * 日付ボタンを初期化します。
	 */
	protected void initDateButton() {
		addKeyListener();
	}
	
	/**
	 * 日付ボタンに設定するキーリスナを作成します。
	 */
	protected KeyAdapter createMCButtonKeyAdapter() {
		return new MCButtonKeyAdapter();
	}
	
	/**
	 * 日付ボタンに設定するキーリスナです。
	 */
	public class MCButtonKeyAdapter extends KeyAdapter {
		
		@Override
		public void keyPressed(KeyEvent e) {
			Object source = e.getSource();
			if (source instanceof MCButton) {
				MCButton compo = (MCButton)source;
				switch (e.getKeyCode()) {
					case KeyEvent.VK_UP:
						verticalKeyEvent(compo, true);
						break;
					case KeyEvent.VK_DOWN:
						verticalKeyEvent(compo, false);
						break;
					case KeyEvent.VK_RIGHT:
						horizontalKeyEvent(compo, true);
						break;
					case KeyEvent.VK_LEFT:
						horizontalKeyEvent(compo, false);
						break;
					default:
						break;
				}
			}
		}
		
		/**
		 * ↑キー、↓キーのイベントを実行します。
		 * 
		 * @param compo GUI 部品
		 * @param up ↑キーの場合は true、↓キーの場合は false
		 */
		protected void verticalKeyEvent(MCButton compo, boolean up) {
			if (compo == null) {
				return;
			}
			int i = getButtonNumber(compo);
			if (i < 0) {
				return;
			}
			MCButton n = null;
			MCButton[] a = getDateButtons();
			int m = a.length - 1;
			while (true) {
				i = up ? i - 7 : i + 7;
				if (i < 0 || i > m) {
					break;
				}
				n = a[i];
				
				if (isModeEditable(n)) {
					n.mcRequestFocus();
					break;
				}
			}
		}
		
		/**
		 * →キー、←キーのイベントを実行します。
		 * 
		 * @param compo GUI 部品
		 * @param right →キーの場合は true、←キーの場合は false
		 */
		protected void horizontalKeyEvent(MCButton compo, boolean right) {
			if (compo == null) {
				return;
			}
			int i = getButtonNumber(compo);
			if (i < 0) {
				return;
			}
			MCButton n = null;
			MCButton[] a = getDateButtons();
			int m = a.length - 1;
			while (true) {
				if (!right && i % 7 == 0) {
					break;
				} else if (right && i % 7 == 6) {
					break;
				}
				i = right ? i + 1 : i - 1;
				if (i < 0 || i > m) {
					break;
				}
				n = a[i];
				
				if (isModeEditable(n)) {
					n.mcRequestFocus();
					break;
				}
			}
		}
	}

	/**
	 * GUI 部品のモードが入力可能モードの場合は true を返します。
	 * 
	 * @param compo GUI 部品
	 * @return GUI 部品のモードが入力可能モード以外の場合は false
	 */
	protected boolean isModeEditable(MCModeBeans compo) {
		if (compo == null) {
			return false;
		}
		MCModeInfo i = compo.getModeInfo();
		if (i == null) {
			return false;
		}
		return i.getStatus() == MCMode.ENABLE_STATUS;
	}

}