package mcframe.clientFSBA.FSBAP0150;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.beans.menu.MCMenuBeansUtil;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.sys.MCSys;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0150"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0150_FW extends FSBAP0150_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0150_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0150_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FS_FSBAL0150_Srch02]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Srch02Caller<P extends FSBAP0150, B extends FS_FSBAL0150_Srch02Bridge>
			extends
			mcframe.clientFSBA.FSBAP0200.FSBAP0200.FS_FSBAL0150_Srch02Caller<P, B> {

		protected FS_FSBAL0150_Srch02Caller(P p, B b) {
			super(p, b);
		}
	}

	/**
	 * [FS_FSBAL0150_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Upd01Caller<P extends FSBAP0150, B extends FS_FSBAL0150_Upd01Bridge>
			extends MCCaller<P, B> {

		protected FS_FSBAL0150_Upd01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void beforeCall() {
			updateMenuindex();
			getMemoR().Key(key);
		}

		@Override
		protected void show() {
			// 下り電文の更新カウンタをキャッシュに入れる
			getMemoR().upd_cntr(bridge.down0().upd_cntr());
			MCMemoCache u = MCCache.getInstance().getUserMemoCache();
			u.put(key, getMemoR().UserMemo(), getMemoR().getRefTime(),
					getMemoR().upd_cntr());
			getMemoR().setStatus(MCRow.NONE);
		}

	}

	/**
	 * [FS_FSBAL0150_Del01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Del01Caller<P extends FSBAP0150, B extends FS_FSBAL0150_Del01Bridge>
			extends MCCaller<P, B> {

		protected FS_FSBAL0150_Del01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void beforeCall() {
			getMemoR().Key(key);
		}

		@Override
		protected boolean checkForCall() {
			// 削除確認メッセージ
			if (confirm(MCDialogButton.NO, FSBAC0021) != MCMessageBox.YES_OPTION) {
				return false;
			}
			return true;
		}

		@Override
		protected void show() {
			MCCache.getInstance().getUserMemoCache().put(key, null, null, null);
			getMemoR().setStatus(MCRow.NONE);
			showCacheMemo();
		}

		@Override
		protected void showEndMsg() {
			dialog(FSBAC0025);
		}
	}

	@Override
	protected void customInit() {
		super.customInit();
		Memo_UserMemo.setLineWrap(true);
	}

	@Override
	protected void removeMemoCache() {
		super.removeMemoCache();
		MCCache.getInstance().getUserMemoCache().clear();
	}

	/**
	 * 削除処理を実行します。
	 */
	@Override
	protected void doDeleteAction() {
		callFS_FSBAL0150_Del01();
	}

	/**
	 * キャッシュされている共通メモとユーザメモを表示します。
	 */
	@Override
	public void showCacheMemo() {
		MCMemoCache c = MCCache.getInstance().getCommonMemoCache();
		MCMemoCache u = MCCache.getInstance().getUserMemoCache();
		MemoR m = getMemoR();

		String tk = createMemoKey(key, MCSys.user.locale().toString());
		String mm = c.getValue(tk);
		if (mm != null) {
			m.CommonMemo(mm);
		}
		else {
			m.CommonMemo(c.getValue(key));
		}
		m.UserMemo(u.getValue(key));
		m.setRefTime(u.getRefTime(key));
		m.upd_cntr(u.getUpdCntr(key));

		Memo_CommonMemo.moveCaretPosition(0);
		Memo_UserMemo.moveCaretPosition(0);

		adjustStatus();
	}

	/**
	 * ユーザメモが変更されている場合は true を返します。
	 *
	 * @return ユーザメモが変更されていない場合は false
	 */
	@Override
	protected boolean isMemoChanged() {
		return UserMemoPanel.isChanged();
	}

	@Override
	public String getUpdateMsgId() {
		return FSBAC0027;
	}

	@Override
	protected void jbInit() {
		super.jbInit();
		CommonMemoPanel.insertNextBeans(UserMemoPanel);
	}

	/**
	 * メモを更新するロジックを呼び出します。
	 * 
	 */
	@Override
	public void callUpadate() {
		callFS_FSBAL0150_Upd01();
	}

	/**
	 * 登録時の確認ダイアログのメッセージIDを返します。
	 *
	 * @return 登録時の確認メッセージID 
	 */
	@Override
	public String getUpdateConfirmMsgId() {
		return FSBAC0023;
	}

}