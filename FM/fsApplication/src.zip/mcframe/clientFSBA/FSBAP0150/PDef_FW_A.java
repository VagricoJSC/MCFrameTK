package mcframe.clientFSBA.FSBAP0150;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP0150]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0150.Srch02.UP.BLOCK0")){
			return FS_FSBAL0150_Srch02_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Srch02.DOWN.BLOCK0")){
			return FS_FSBAL0150_Srch02_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Upd01.UP.BLOCK0")){
			return FS_FSBAL0150_Upd01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Upd01.DOWN.BLOCK0")){
			return FS_FSBAL0150_Upd01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Del01.UP.BLOCK0")){
			return FS_FSBAL0150_Del01_UP_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
			
	
	static final MCOperationInfo FS_FSBAL0150_Srch02_INFO = new MCOperationInfo("FS", "FSBAL0150", "Srch02", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0150_Srch02_UP_BLOCK0() {
		/** Ope.のBlock [] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Srch02",
			mcframe.clientFSBA.FSBAP0200.PDef.FS_FSBAL0150_Srch02_UP_BLOCK0(),
			new MCItemDef[]{
			}
			,
			MCBlockDef.create("SearchAll")
		);
	}


	public static MCContainerDef FS_FSBAL0150_Srch02_DOWN_BLOCK0() {
	/** Ope.のBlock [] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Srch02",
			mcframe.clientFSBA.FSBAP0200.PDef.FS_FSBAL0150_Srch02_DOWN_BLOCK0(),
			new MCItemDef[]{
			}
			,
			MCBlockDef.create("MemoAll")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0150_Upd01_INFO = new MCOperationInfo("FS", "FSBAL0150", "Upd01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0150_Upd01_UP_BLOCK0() {
		/** Ope.のBlock [Upd01_Cnd] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("UserID", "user_id"),
				MCItemDef.create("Locale", "locale"),
				MCItemDef.create("Key", "memo_key"),
				MCItemDef.create("UserMemo", "user_memo"),
				MCItemDef.create("CoCD", "co_cd"),
				MCItemDef.create("Ext_attr1", "ext_attr1"),
				MCItemDef.create("Ext_attr2", "ext_attr2"),
				MCItemDef.create("Ext_attr3", "ext_attr3"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Memo")
		);
	}


	public static MCContainerDef FS_FSBAL0150_Upd01_DOWN_BLOCK0() {
	/** Ope.のBlock [Upd01_Cnd] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Memo")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0150_Del01_INFO = new MCOperationInfo("FS", "FSBAL0150", "Del01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0150_Del01_UP_BLOCK0() {
		/** Ope.のBlock [Del01_Cnd] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Del01",
			new MCItemDef[]{
				MCItemDef.create("UserID", "user_id"),
				MCItemDef.create("Locale", "locale"),
				MCItemDef.create("Key", "memo_key"),
				MCItemDef.create("CoCD", "co_cd"),
				MCItemDef.create("Ext_attr1", "ext_attr1"),
				MCItemDef.create("Ext_attr2", "ext_attr2"),
				MCItemDef.create("Ext_attr3", "ext_attr3"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Memo")
		);
	}


	//FMCB DEF_CLASSES END
}

