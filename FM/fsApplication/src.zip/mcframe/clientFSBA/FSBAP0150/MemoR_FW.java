package mcframe.clientFSBA.FSBAP0150;

import mcframe.commonCore.notice.*;
//FMCB IMPORT START

//FMCB IMPORT END

/**
 * ブロック"Memo"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
abstract public class MemoR_FW extends MemoR_FW_A {

//FMCB CUSTOM_METHOD START
	/**
	 * コンストラクタ
	 */
	protected MemoR_FW(ConstMetaList<? extends MemoR> metas) {
		super(metas);
	}

	@Override
	public void init() {
		super.init();
		UserID(mcframe.commonCore.sys.MCSys.user.ID());
		Locale(mcframe.commonCore.sys.MCSys.user.locale().toString());
	}

}