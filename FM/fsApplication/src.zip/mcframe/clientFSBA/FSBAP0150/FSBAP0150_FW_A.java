package mcframe.clientFSBA.FSBAP0150;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0150.FSBAP0150_FW.FS_FSBAL0150_Srch02Caller;
import mcframe.clientFSBA.FSBAP0150.FSBAP0150_FW.FS_FSBAL0150_Upd01Caller;
import mcframe.clientFSBA.FSBAP0150.FSBAP0150_FW.FS_FSBAL0150_Del01Caller;

/**
 * 画面"FSBAP0150"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0150_FW_A extends mcframe.clientFSBA.FSBAP0200.FSBAP0200{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0150";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Memo]ブロック関連のField定義
	// [Memo]ブロックの項目のField定義
	public MCScrollPane Memo_UserMemoScrollPane = null;
	/**
	 * ユーザメモ ユーザメモ.<p>
	 *
	 */
	public MCTextArea Memo_UserMemo = null;
	// [CommonMemo]ブロック関連のField定義
	// [CommonMemo]ブロックの項目のField定義
	// [UserMemo]ブロック関連のField定義
	public MCPanel UserMemoPanel = null;
	// [UserMemo]ブロックの項目のField定義
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [INSERT]モードを表す定数 */
	public static final String INSERT = "INSERT";
	/** [NOEDIT]モードを表す定数 */
	public static final String NOEDIT = "NOEDIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{EDIT, INSERT, NOEDIT};
	
	/** [FS_FSBAL0150_Srch02]のCallerの作成 */
	protected FSBAP0150_FW.FS_FSBAL0150_Srch02Caller createFS_FSBAL0150_Srch02() {
		FSBAP0150_FW.FS_FSBAL0150_Srch02Caller<FSBAP0150, FS_FSBAL0150_Srch02Bridge>
		caller = ((FSBAP0150_FW)this).new FS_FSBAL0150_Srch02Caller<FSBAP0150, FS_FSBAL0150_Srch02Bridge>(
					(FSBAP0150)this, new FS_FSBAL0150_Srch02Bridge());
		return caller;
	}
	/** [FS_FSBAL0150_Srch02]の呼び出し */
	protected void callFS_FSBAL0150_Srch02() {
		MCCaller caller = createFS_FSBAL0150_Srch02();
		caller.exec();
	}
	/** [FS_FSBAL0150_Upd01]のCallerの作成 */
	protected FSBAP0150_FW.FS_FSBAL0150_Upd01Caller createFS_FSBAL0150_Upd01() {
		FSBAP0150_FW.FS_FSBAL0150_Upd01Caller<FSBAP0150, FS_FSBAL0150_Upd01Bridge>
		caller = ((FSBAP0150_FW)this).new FS_FSBAL0150_Upd01Caller<FSBAP0150, FS_FSBAL0150_Upd01Bridge>(
					(FSBAP0150)this, new FS_FSBAL0150_Upd01Bridge());
		return caller;
	}
	/** [FS_FSBAL0150_Upd01]の呼び出し */
	protected void callFS_FSBAL0150_Upd01() {
		MCCaller caller = createFS_FSBAL0150_Upd01();
		caller.exec();
	}
	/** [FS_FSBAL0150_Del01]のCallerの作成 */
	protected FSBAP0150_FW.FS_FSBAL0150_Del01Caller createFS_FSBAL0150_Del01() {
		FSBAP0150_FW.FS_FSBAL0150_Del01Caller<FSBAP0150, FS_FSBAL0150_Del01Bridge>
		caller = ((FSBAP0150_FW)this).new FS_FSBAL0150_Del01Caller<FSBAP0150, FS_FSBAL0150_Del01Bridge>(
					(FSBAP0150)this, new FS_FSBAL0150_Del01Bridge());
		return caller;
	}
	/** [FS_FSBAL0150_Del01]の呼び出し */
	protected void callFS_FSBAL0150_Del01() {
		MCCaller caller = createFS_FSBAL0150_Del01();
		caller.exec();
	}
	/** [Memo]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0150.MemoR aMemoR;

	/**
	 * 項目コピーによってaMemoRを設定します。
	 *
	 * aMemoRのインスタンスは変更されません。
	 *
	 * @param row MemoR
	 */
	public void setMemoR(mcframe.clientFSBA.FSBAP0150.MemoR row) {
		if (row != null) {
			MCRow.copyall(getMemoR(), row);
		}
	}

	/**
	 * [Memo]ブロックのコンテナaMemoRを返します。
	 *
	 * @return MemoR
	 */
	public mcframe.clientFSBA.FSBAP0150.MemoR getMemoR() {
		return aMemoR;
	}

	/**
	 * aMemoRを作成します。
	 *
	 * @return MemoR
	 */
	public mcframe.clientFSBA.FSBAP0150.MemoR createMemoR() {
		return mcframe.clientFSBA.FSBAP0150.MemoR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getMemoR())) ret.add(getMemoR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getMemoR()) return "Memo";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Memo")) return getMemoR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(UserMemoPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0150_FW_A() {
		aMemoR = createMemoR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0150_FW_A(String name) {
		super(name);
		aMemoR = createMemoR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0150_FW.jbCreateMemo((FSBAP0150)this);
		FSBAP0150_FW.jbCreateCommonMemo((FSBAP0150)this);
		FSBAP0150_FW.jbCreateUserMemo((FSBAP0150)this);
	}

	/**
	 * [Memo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMemo(FSBAP0150 p) {
	}

	/**
	 * [CommonMemo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommonMemo(FSBAP0150 p) {
	}

	/**
	 * [UserMemo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateUserMemo(FSBAP0150 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0150 create(){
		FSBAP0150 p = new FSBAP0150();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0150_FW.jbfInitMemo((FSBAP0150)this);
		FSBAP0150_FW.jbfInitCommonMemo((FSBAP0150)this);
		FSBAP0150_FW.jbfInitUserMemo((FSBAP0150)this);
		FSBAP0150_FW.jbInitMemo((FSBAP0150)this);
		FSBAP0150_FW.jbInitCommonMemo((FSBAP0150)this);
		FSBAP0150_FW.jbInitUserMemo((FSBAP0150)this);
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMemo(FSBAP0150 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.Memo_UserMemoScrollPane = p.beansFactory.createScrollPane("Memo.UserMemoscroll");
		p.Memo_UserMemo = p.beansFactory.createTextArea("Memo.UserMemo");
	}

	/**
	 * [CommonMemo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommonMemo(FSBAP0150 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [UserMemo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitUserMemo(FSBAP0150 p) {
		// ブロック関連の初期化
		p.UserMemoPanel = p.beansFactory.createPanel("UserMemo");
		// ブロックの項目の初期化
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMemo(FSBAP0150 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.Memo_UserMemoScrollPane.getViewport().add(p.Memo_UserMemo);
		p.UserMemoPanel.add(p.Memo_UserMemoScrollPane);
		p.UserMemoPanel.setLastBeans(p.Memo_UserMemo);
		p.Memo_UserMemo.setRow(p.getMemoR(), mcframe.clientFSBA.FSBAP0150.MemoR.UserMemo_META);
	}

	/**
	 * [CommonMemo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommonMemo(FSBAP0150 p) {
		// ブロック関連の初期化
		p.CommonMemoPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [UserMemo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitUserMemo(FSBAP0150 p) {
		// ブロック関連の初期化
		p.add(p.UserMemoPanel);
		p.setLastBeans(p.UserMemoPanel);
		p.UserMemoPanel.setLayoutPosition("CBC");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0150_FW.mcInitMemo((FSBAP0150)this);
		FSBAP0150_FW.mcInitCommonMemo((FSBAP0150)this);
		FSBAP0150_FW.mcInitUserMemo((FSBAP0150)this);

		// [EDIT]ステータスのモードの設定
		FSBAP0150_FW.statusInitEDIT_Memo((FSBAP0150)this);
		FSBAP0150_FW.statusInitEDIT_CommonMemo((FSBAP0150)this);
		FSBAP0150_FW.statusInitEDIT_UserMemo((FSBAP0150)this);

		// [INSERT]ステータスのモードの設定
		FSBAP0150_FW.statusInitINSERT_Memo((FSBAP0150)this);
		FSBAP0150_FW.statusInitINSERT_CommonMemo((FSBAP0150)this);
		FSBAP0150_FW.statusInitINSERT_UserMemo((FSBAP0150)this);

		// [NOEDIT]ステータスのモードの設定
		FSBAP0150_FW.statusInitNOEDIT_Memo((FSBAP0150)this);
		FSBAP0150_FW.statusInitNOEDIT_CommonMemo((FSBAP0150)this);
		FSBAP0150_FW.statusInitNOEDIT_UserMemo((FSBAP0150)this);

	}

	/**
	 *  [Memo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMemo(FSBAP0150 p) {
		p.Memo_UserMemo.addAllListener(p);
	}

	/**
	 *  [CommonMemo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommonMemo(FSBAP0150 p) {
	}

	/**
	 *  [UserMemo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitUserMemo(FSBAP0150 p) {
	}

	/**
	 * [EDIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Memo(FSBAP0150 p){
		p.Memo_CommonMemo.putMode(p, EDIT, MCMode.READ_ONLY);
		p.Memo_UserMemo.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[CommonMemo]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_CommonMemo(FSBAP0150 p){

	}

	/**
	 * [EDIT]ステータスの[UserMemo]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_UserMemo(FSBAP0150 p){

	}

	/**
	 * [INSERT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_Memo(FSBAP0150 p){
		p.Memo_CommonMemo.putMode(p, INSERT, MCMode.READ_ONLY);
		p.Memo_UserMemo.putMode(p, INSERT, MCMode.ENABLE);

	}

	/**
	 * [INSERT]ステータスの[CommonMemo]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_CommonMemo(FSBAP0150 p){

	}

	/**
	 * [INSERT]ステータスの[UserMemo]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_UserMemo(FSBAP0150 p){

	}

	/**
	 * [NOEDIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Memo(FSBAP0150 p){
		p.Memo_CommonMemo.putMode(p, NOEDIT, MCMode.READ_ONLY);
		p.Memo_UserMemo.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[CommonMemo]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_CommonMemo(FSBAP0150 p){

	}

	/**
	 * [NOEDIT]ステータスの[UserMemo]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_UserMemo(FSBAP0150 p){

	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Memo_UserMemo) return doMemo_UserMemo_VC(info);
		return true;
	}

	/**
	 * [Memo]パネルの[UserMemo]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemo_UserMemo_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Memo_UserMemo) doMemo_UserMemo_NC(info);
	}

	/**
	 * [Memo]パネルの[UserMemo]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_UserMemo_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Memo_UserMemo) doMemo_UserMemo_NE(info);
	}

	/**
	 * [Memo]パネルの[UserMemo]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_UserMemo_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Memo_UserMemo) doMemo_UserMemo_NX(info);
	}

	/**
	 * [Memo]パネルの[UserMemo]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_UserMemo_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0150.Srch02")) {
			return new FS_FSBAL0150_Srch02Bridge();
		}
		if (id.equals("FS.FSBAL0150.Upd01")) {
			return new FS_FSBAL0150_Upd01Bridge();
		}
		if (id.equals("FS.FSBAL0150.Del01")) {
			return new FS_FSBAL0150_Del01Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0150_Srch02]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Srch02Bridge extends mcframe.clientFSBA.FSBAP0200.FSBAP0200.FS_FSBAL0150_Srch02Bridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0150_Srch02;

		/** コンストラクタ */
		protected FS_FSBAL0150_Srch02Bridge() {
			p_FS_FSBAL0150_Srch02 = new MCParam(PDef.FS_FSBAL0150_Srch02_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0150_Srch02_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0200.SearchAllR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0200.MemoAllR.class));

			p_FS_FSBAL0150_Srch02 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0150_Srch02.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0150_Srch02.addUpBlock(getSearchAllR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0150_Srch02.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0150_Srch02.getContainerParam().getDownBlock(i);
		}
		
		//
		// up0() は自動生成されません。
		//     up0 のアクセサはsuperScreenのメソッドを使用します。
		//

		// down0() は自動生成されません。
		//     down0() は、superScreenのメソッドを使用します。

		protected void setupDownParam() {
			p_FS_FSBAL0150_Srch02.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0200.MemoAllR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0150_Srch02;
		}

		protected void show() {
			setMemoAllL((MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR>)p_FS_FSBAL0150_Srch02.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMemoAllL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getSearchAllR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoAllL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0150_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Upd01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0150_Upd01;

		/** コンストラクタ */
		protected FS_FSBAL0150_Upd01Bridge() {
			p_FS_FSBAL0150_Upd01 = new MCParam(PDef.FS_FSBAL0150_Upd01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0150_Upd01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0150.MemoR.create());
			// Down
			param.addDownBlock(mcframe.clientFSBA.FSBAP0150.MemoR.create());

			p_FS_FSBAL0150_Upd01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0150_Upd01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0150_Upd01.addUpBlock(getMemoR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0150_Upd01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0150_Upd01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0150.MemoR up0() {
			return (mcframe.clientFSBA.FSBAP0150.MemoR)up(0);
		}

		protected mcframe.clientFSBA.FSBAP0150.MemoR down0() {
			return (mcframe.clientFSBA.FSBAP0150.MemoR)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0150_Upd01.addDownBlock(mcframe.clientFSBA.FSBAP0150.MemoR.create());
		}
		protected MCParam param() {
			return p_FS_FSBAL0150_Upd01;
		}

		protected void show() {
			setMemoR((mcframe.clientFSBA.FSBAP0150.MemoR)p_FS_FSBAL0150_Upd01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMemoR().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoR());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0150_Del01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Del01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0150_Del01;

		/** コンストラクタ */
		protected FS_FSBAL0150_Del01Bridge() {
			p_FS_FSBAL0150_Del01 = new MCParam(PDef.FS_FSBAL0150_Del01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0150_Del01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0150.MemoR.create());
			// Down

			p_FS_FSBAL0150_Del01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0150_Del01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0150_Del01.addUpBlock(getMemoR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0150_Del01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0150_Del01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0150.MemoR up0() {
			return (mcframe.clientFSBA.FSBAP0150.MemoR)up(0);
		}


		protected void setupDownParam() {
		}
		protected MCParam param() {
			return p_FS_FSBAL0150_Del01;
		}

		protected void show() {
		}

		protected void clear() {
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			return result;
		}
	}
}