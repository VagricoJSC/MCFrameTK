package mcframe.clientFSBA.FSBAP0290;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0090.*;
import mcframe.clientFSUB.FSUBP0100.*;
import mcframe.clientFSUB.FSUBP0110.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.util.Map;
import java.util.IdentityHashMap;

import javax.swing.Icon;

import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.sys.MCSys;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXUC.FXUCP0040.FXUCP_ToolBarUtil;
import mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR;
import mcframe.clientFXUC.FXUCP0040.OpenScreenParamR;
import mcframe.commonFS.constant.FSC_MODULE_ID;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_ScreenBookmarkSetting"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_ScreenBookmarkSetting_FW extends FSBAP_ScreenBookmarkSetting_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected boolean _isBaseScreenFixed = false;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ScreenBookmarkSetting_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ScreenBookmarkSetting_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[upd_ext]の押下時の処理
	 */
	@Override
	public void doBtn_upd_ext(MCEventInfo info) {
	}
	/**
	 * Panel[Btn]のボタン[upd_sys]の押下時の処理
	 */
	@Override
	public void doBtn_upd_sys(MCEventInfo info) {
	}
	/**
	 * Panel[Dtl]のボタン[value_forward]の押下時の処理
	 */
	@Override
	public void doDtl_value_forward(MCEventInfo info) {
		DtlR dtlR = DtlTable.getSelectedMCRow();
		if (dtlR.module_id() == null || dtlR.screen_id() == null) {
			// モジュールIDまたは画面IDが未設定
			return;
		}
		if (isNull(dtlR.setting_unit_type())) {
			// fillspaceやボタンで追加されたRowの設定単位を補完する
			dtlR.setting_unit_type(Cnd_setting_PPanel.getSettingR().setting_unit());
		}

		openModalPanel("FS", "FSBAP0300", T1, dtlR, getParentPanel());
	}
	/**
	 * Panel[Btn]のボタン[move_top]の押下時の処理
	 */
	@Override
	public void doBtn_move_top(MCEventInfo info) {
		moveTop(DtlTable);
	}

	/**
	 * Panel[Btn]のボタン[move_up]の押下時の処理
	 */
	@Override
	public void doBtn_move_up(MCEventInfo info) {
		moveUp(DtlTable);
	}

	/**
	 * Panel[Btn]のボタン[move_down]の押下時の処理
	 */
	@Override
	public void doBtn_move_down(MCEventInfo info) {
		moveDown(DtlTable);
	}

	/**
	 * Panel[Btn]のボタン[move_bottom]の押下時の処理
	 */
	@Override
	public void doBtn_move_bottom(MCEventInfo info) {
		moveBottom(DtlTable);
	}

	/**
	 * Panel[Btn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doBtn_radd(MCEventInfo info) {
		insertRow(DtlTable);
	}

	/**
	 * Panel[Btn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doBtn_rdel(MCEventInfo info) {
		deleteRow(DtlTable);
	}

	/**
	 * Panel[Btn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doBtn_upd(MCEventInfo info) {
		if (confirm(FXUCP0018) != MCMessageBox.YES_OPTION) {
			return;
		}

		MCList<DtlR> dl = exceptEmpty(getDtlL());
		MCMessageList m = checkReq(dl);
		if (m.size() > 0) {
			message(m);
			return;
		}

		dl.setString(DtlR.$base_module_id, getCndR().base_module_id());
		dl.setString(DtlR.$base_screen_id, getCndR().base_screen_id());
		dl.setString(DtlR.$setting_unit_type,
				Cnd_setting_PPanel.getSettingR().setting_unit());

		MCList<OpenScreenInfoR> ol = MCList.create(OpenScreenInfoR.class);
		addAll(ol, dl, createMap_OpenScreenInfoR_DtlR());
		Map<OpenScreenInfoR, MCList<OpenScreenParamR>> om = createOpenScreenParamMap(ol,
				dl);
		FXUCP_ToolBarUtil.saveOpenScreenInfo(ol, om);

		MCRootPanel p = getParentPanel();
		if (p instanceof FXBAP_PanelBase) {
			FXBAP_PanelBase appPanel = (FXBAP_PanelBase) p;
			appPanel.resetToolBar();
		}

		dialog(FXUCP0019);
		statusClear();
	}

	/**
	 * Panel[Btn]のボタン[upd_close]の押下時の処理
	 */
	@Override
	public void doBtn_upd_close(MCEventInfo info) {
		doBtn_upd(info);
		requestCloseWindow();
	}

	/**
	 * [Dtl]パネルの[screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_screen_id_NC(MCEventInfo info){
		// 画面IDが変わったら連携パラメータを削除する
		DtlR dtlR = DtlTable.getSelectedMCRow();
		paramMap.remove(dtlR);
	}

	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);

		// GUI部品が[text_field]の場合はdo_text_field_NCを実行する
		if (nc == Dtl_screen_p_PPanel.columnScreen_screen_id) {
			doDtl_screen_id_NC(info);
		}
		if (nc == Cnd_setting_PPanel.Setting_setting_unit_Group) {
			doSetting_setting_unit_NC(info);
		}
	}

	protected void doSetting_setting_unit_NC(MCEventInfo info) {
		valueInit();
		fillSpaceForOpen();
		setOpenFocus();
	}

	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		
		if (vc == Cnd_setting_PPanel.Setting_setting_unit_Group) {
			return doSetting_setting_unit_VC(info);
		}
		return true;
	}

	protected boolean doSetting_setting_unit_VC(MCEventInfo info) {
		if (isChanged() && confirm(FSBAC0059) == MCMessageBox.NO_OPTION) {
			return false;
		}
		return true;
	}

	@Override
	protected void listenerInit() {
		super.listenerInit();

		// 画面の伝票ＣＤ変更時のイベントを設定
		Dtl_screen_p_PPanel.columnScreen_screen_id.addNCListener(this);

		Cnd_setting_PPanel.Setting_setting_unit_Group.addVCListener(this);
		Cnd_setting_PPanel.Setting_setting_unit_Group.addNCListener(this);
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		DtlTable.setCellConfig(createDtlCellConfig());
	}

	/**
	 * 一覧テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 一覧テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createDtlCellConfig() {
		return new DtlCellConfig();
	}

	@Override
	public void valueInit() {
		super.valueInit();
		getDtlL().clear();

		String m = getCndR().base_module_id();
		String s = getCndR().base_screen_id();
		String u = Cnd_setting_PPanel.getSettingR().setting_unit();
		if (isNullOr(m, s)) {
			return;
		}

		DtlR d = createDtlR();
		d.base_module_id(m);
		d.base_screen_id(s);
		d.setting_unit_type(u);// ここで設定した設定単位のみロードされる

		OpenScreenInfoR o = OpenScreenInfoR.create();
		copy(o, d, createMap_OpenScreenInfoR_DtlR());
		MCList<OpenScreenInfoR> ol = FXUCP_ToolBarUtil.loadOpenScreenInfo(o);

		MCList<DtlR> dl = createDtlL();
		addAll(dl, ol, createMap_DtlR_OpenScreenInfoR());
		int size = dl.size();
		for (int i = 0; i < size; i++) {
			OpenScreenInfoR or = ol.get(i);
			MCList<OpenScreenParamR> pl = FXUCP_ToolBarUtil.loadOpenScreenParam(or, i);
			if (pl != null && pl.size() > 0) {
				DtlR dr = dl.get(i);
				paramMap.put(dr, pl);
			}
		}
		setDtlL(dl);

		DtlTable.adjustWidth();
	}

	@Override
	public void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		DtlTable.fillSpace();
	}

	
	@Override
	public void setStatus(String status) {
		super.setStatus(status);

		// ラジオボタンを選択できるかどうか
		if (!isSettingUnitUserEnable()) {
			Cnd_setting_PPanel.Setting_setting_unit_USER.setMode(MCMode.READ_ONLY);
		}
		if (!isSettingUnitExtEnable()) {
			Cnd_setting_PPanel.Setting_setting_unit_EXT.setMode(MCMode.READ_ONLY);
		}
		if (!isSettingUnitSysEnable()) {
			Cnd_setting_PPanel.Setting_setting_unit_SYS.setMode(MCMode.READ_ONLY);
		}
	}

	protected boolean isSettingUnitUserEnable() {
		return true;
	}
	
	protected boolean isSettingUnitExtEnable() {
		// パーソナライズデータが取得できているかどうかも加味
		return Btn_upd_ext.authorize() && FXUCP_ToolBarUtil.isSearchedProgram(
				FXC_RESOURCE_SETTING_UNIT.TYPE_EXT.value(),
				MCGroupResource.PGM_ID_SYSTEM);
	}	

	protected boolean isSettingUnitSysEnable() {
		return Btn_upd_sys.authorize() && FXUCP_ToolBarUtil.isSearchedProgram(
				FXC_RESOURCE_SETTING_UNIT.TYPE_SYS.value(),
				MCGroupResource.PGM_ID_SYSTEM);
	}

	/**
	 * 他画面から呼び出された場合の初期化を実装します。
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値（使用しません）
	 * @param args その他の引数（使用しません）
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1 == openTyp) {
			CndR c = getCndR();
			String m = getParentPanel().getModuleID();
			String s = getParentPanel().getScreenID();

			c.usr_id(MCSys.user.ID());
			c.base_module_id(m);
			if(m.equals("Z") == false) {
				// Zはエラーにしない。
				FSC_MODULE_ID.putName(
						c, CndR.$base_module_id, CndR.$base_module_nm);
			}

			c.base_screen_id(s);
			c.base_screen_nm(getParentPanel().getScreenName());

			_isBaseScreenFixed = true;

			valueInit();
		}
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();

		if (_isBaseScreenFixed) {
			Cnd_base_screen_id.setMode(MCMode.READ_ONLY);
		}
	}

	protected Map_OpenScreenInfoR_DtlR<OpenScreenInfoR,DtlR> createMap_OpenScreenInfoR_DtlR() {
		return new Map_OpenScreenInfoR_DtlR<OpenScreenInfoR, DtlR>();
	}

	public class Map_OpenScreenInfoR_DtlR<D extends OpenScreenInfoR, S extends DtlR> extends MCRowMapper<D,S>{
		@Override
		public void valueCopy(D dest, S src){
			dest.setting_unit_type(src.setting_unit_type());
			dest.panel_typ(src.panel_typ());
			dest.lbl_text(src.lbl_text());
			dest.usr_id(src.usr_id());
			dest.base_module_id(src.base_module_id());
			dest.base_screen_id(src.base_screen_id());

			dest.open_module_id(src.module_id());
			dest.open_module_nm(src.module_id_nm());
			dest.open_screen_id(src.screen_id());
			dest.msg_text(src.screen_name());
		}
	}


	protected Map_DtlR_OpenScreenInfoR<DtlR,OpenScreenInfoR> createMap_DtlR_OpenScreenInfoR() {
		return new Map_DtlR_OpenScreenInfoR<DtlR, OpenScreenInfoR>();
	}

	public class Map_DtlR_OpenScreenInfoR<D extends DtlR, S extends OpenScreenInfoR> extends MCRowMapper<D,S>{
		@Override
		public void valueCopy(D dest, S src){
			dest.setting_unit_type(src.setting_unit_type());
			dest.lbl_text(src.lbl_text());
			dest.panel_typ(src.panel_typ());
			dest.usr_id(src.usr_id());
			dest.base_module_id(src.base_module_id());
			dest.base_screen_id(src.base_screen_id());

			dest.module_id(src.open_module_id());
			dest.module_id_nm(src.open_module_nm());
			dest.screen_id(src.open_screen_id());
			dest.screen_name(src.msg_text());
		}
	}


	/**
	 * 連携パラメータ格納マップ。
	 * キー：対象行のRowインスタンス
	 * 値：連携パラメータのリスト
	 */
	private IdentityHashMap<DtlR, MCList<OpenScreenParamR>> paramMap =
						new IdentityHashMap<DtlR, MCList<OpenScreenParamR>>();

	/**
	 * 連携パラメータを設定します。
	 *
	 * @param target 設定対象の行
	 * @param paramList 連携パラメータ
	 */
	public void setOpenParamList(DtlR target, MCList<OpenScreenParamR> paramList) {
		if (target == null) {
			// 対象行がない場合は何もしない
			return;
		}
		if (!getDtlL().contains(target)) {
			// 対象行がこの画面にない場合は何もしない
			return;
		}

		if (paramList != null && paramList.size() <= 0) {
			// パラメータがない場合はListをnullにする
			paramList = null;
		}

		paramMap.put(target, paramList);

		if (target.getStatus() == MCRow.NONE) {
			// 行ステータスの変更
			target.setStatus(MCRow.MODIFY);
		}
	}

	/**
	 * 連携パラメータを返します。
	 *
	 * @param target 取得対象の行
	 * @return 連携パラメータ
	 */
	public MCList<OpenScreenParamR> getOpenParamList(DtlR target) {
		return paramMap.get(target);
	}

	/**
	 * 連携パラメータの設定を、fxApps用のマップに変換して返します。
	 *
	 * 引数 ol と dl はマッピングされたリストで、並び順が一致している必要が
	 * あります。
	 *
	 * @param ol fxApps処理用リスト
	 * @param dl この画面で設定されたリスト
	 * @return 変換されたマップ
	 */
	protected IdentityHashMap<OpenScreenInfoR, MCList<OpenScreenParamR>> createOpenScreenParamMap(
								MCList<OpenScreenInfoR> ol, MCList<DtlR> dl) {
		IdentityHashMap<OpenScreenInfoR, MCList<OpenScreenParamR>> om =
					new IdentityHashMap<OpenScreenInfoR, MCList<OpenScreenParamR>>();
		int size = dl.size();
		for (int i = 0; i < size; i++) {
			DtlR dr = dl.get(i);
			MCList<OpenScreenParamR> pl = paramMap.get(dr);
			if (pl == null || pl.size() <= 0) {
				continue;
			}
			OpenScreenInfoR or = ol.get(i);
			om.put(or, pl);
		}
		return om;
	}

	/**
	 * 一覧テーブルに設定するセルコンフィグです。
	 */
	public class DtlCellConfig extends FXBAP_CellConfig {
		@Override
		protected Icon getButtonColumnIcon(int index, MCColumnConfig column,
				MCTable<?> table, boolean selected) {
			if (column == columnDtl_value_forward) {
				DtlR dtlR = getDtlL().get(index);
				if (dtlR.module_id() != null && dtlR.screen_id() != null) {
					// モジュールIDおよび画面IDが設定済み
					MCList<OpenScreenParamR> paramList = getOpenParamList(dtlR);
					if (paramList != null && paramList.size() > 0) {
						// 連携設定あり
						Icon icon = MCBeansUtil.get(column, "SETPARAM");
						if (icon != null) {
							return icon;
						}

					}
				}
			}
			return super.getButtonColumnIcon(index, column, table, selected);
		}
	}


	@Override
	public void setOpenFocus() {
		super.setOpenFocus();
		DtlTable.selectLeftmostColumn(0);
	}
	
	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		return new FSBAP_PopupConfig();
	}

	public class FSBAP_PopupConfig extends FSUCP_PopupConfig {
		
		public FSBAP_PopupConfig() {
			super(null);
		}
		
		@Override
		protected boolean ignoreSrchCnd(MCRootPanel panel) {
			return true;
		}
		
	}

}