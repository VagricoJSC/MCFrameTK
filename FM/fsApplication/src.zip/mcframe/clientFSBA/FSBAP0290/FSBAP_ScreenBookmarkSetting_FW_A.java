package mcframe.clientFSBA.FSBAP0290;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_ScreenBookmarkSetting"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_ScreenBookmarkSetting_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0290";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	// [Cnd]ブロックの項目のField定義
	public MCLabel Cnd_base_screen_id_Label = null;
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_base_screen_id = null;
	/**
	 *  画面名.<p>
	 *
	 */
	public MCTextField Cnd_base_screen_nm = null;
	public mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H Cnd_setting_PPanel;
	// [Dtl]ブロック関連のField定義
	public MCPanel DtlPanel = null;
	public MCScrollPane DtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0290.DtlR> DtlTable = null;
	// [Dtl]ブロックの項目のField定義
	/**
	 *  ボタン.<p>
	 *
	 */
	public MCColumnConfig columnDtl_lbl_text = null;
	public mcframe.clientFSUB.FSUBP0100.FSUBP_Module_D Dtl_module_p_PPanel;
	public MCColumnConfig columnDtl_module_id;// [Dtl]の[module_p.module_id]を[columnDtl_module_id]としてエイリアス定義。
	public MCColumnConfig columnDtl_module_id_nm;// [Dtl]の[module_p.module_id_nm]を[columnDtl_module_id_nm]としてエイリアス定義。
	public mcframe.clientFSUB.FSUBP0110.FSUBP_Screen_D Dtl_screen_p_PPanel;
	public MCColumnConfig columnDtl_screen_id;// [Dtl]の[screen_p.screen_id]を[columnDtl_screen_id]としてエイリアス定義。
	public MCColumnConfig columnDtl_screen_name;// [Dtl]の[screen_p.screen_name]を[columnDtl_screen_name]としてエイリアス定義。
	/**
	 *  連携設定.<p>
	 *
	 */
	public MCColumnConfig columnDtl_value_forward = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton Btn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton Btn_rdel = null;
	/**
	 *  １番上へ.<p>
	 *
	 */
	public MCButton Btn_move_top = null;
	/**
	 *  上へ.<p>
	 *
	 */
	public MCButton Btn_move_up = null;
	/**
	 *  下へ.<p>
	 *
	 */
	public MCButton Btn_move_down = null;
	/**
	 *  １番下へ.<p>
	 *
	 */
	public MCButton Btn_move_bottom = null;
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton Btn_upd = null;
	/**
	 *  更新する（システム共通）.<p>
	 *
	 */
	public MCButton Btn_upd_sys = null;
	/**
	 *  更新する（会社共通）.<p>
	 *
	 */
	public MCButton Btn_upd_ext = null;
	/**
	 *  更新後閉じる.<p>
	 *
	 */
	public MCButton Btn_upd_close = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0290.CndR aCndR;
	/** [Dtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0290.DtlR> aDtlL;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFSBA.FSBAP0290.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0290.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0290.CndR createCndR() {
		return mcframe.clientFSBA.FSBAP0290.CndR.create();
	}

	/**
	 * コピーによってaDtlLを設定します。
	 *
	 * aDtlLのインスタンスは変更されません。
	 *
	 * @param dataset DtlL
	 */
	public void setDtlL(MCList<mcframe.clientFSBA.FSBAP0290.DtlR> aList) {
		if (getDtlL() != aList) {
			getDtlL().setAll(aList);
		}
	}

	/**
	 * [Dtl]ブロックのコンテナaDtlLを返します。
	 *
	 * @return DtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0290.DtlR> getDtlL() {
		return aDtlL;
	}

	/**
	 * aDtlRを作成します。
	 *
	 * @return DtlR
	 */
	public mcframe.clientFSBA.FSBAP0290.DtlR createDtlR() {
		return mcframe.clientFSBA.FSBAP0290.DtlR.create();
	}

	/**
	 * aDtlLを作成します。
	 *
	 * @return DtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0290.DtlR> createDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0290.DtlR.class);
	}

	/**
	 * DtlTableを初期化します。
	 */
	protected void createDtlTable(){
		if(DtlTable == null){
			DtlTable = beansFactory.createTable2("Dtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getDtlL())) ret.add(getDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getDtlL()) return "Dtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("Dtl")) return getDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(DtlPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ScreenBookmarkSetting_FW_A() {
		aCndR = createCndR();
		aDtlL = createDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ScreenBookmarkSetting_FW_A(String name) {
		aCndR = createCndR();
		aDtlL = createDtlL();
		createDtlTable();
		DtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_ScreenBookmarkSetting_FW.jbCreateCnd((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbCreateDtl((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbCreateBtn((FSBAP_ScreenBookmarkSetting)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FSBAP_ScreenBookmarkSetting p) {
		p.Cnd_setting_PPanel = mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.create();
		p.Cnd_setting_PPanel.setName("Cnd.setting");
	}

	/**
	 * [Dtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDtl(FSBAP_ScreenBookmarkSetting p) {
		p.Dtl_module_p_PPanel = mcframe.clientFSUB.FSUBP0100.FSUBP_Module_D.create(mcframe.clientFSBA.FSBAP0290.DtlR.$module_p);
		p.Dtl_module_p_PPanel.setName("Dtl.module_p");
		p.columnDtl_module_id = p.Dtl_module_p_PPanel.columnModule_module_id;
		p.columnDtl_module_id.addAliasName("Dtl.module_id", p);
		p.columnDtl_module_id_nm = p.Dtl_module_p_PPanel.columnModule_module_id_nm;
		p.columnDtl_module_id_nm.addAliasName("Dtl.module_id_nm", p);
		p.Dtl_screen_p_PPanel = mcframe.clientFSUB.FSUBP0110.FSUBP_Screen_D.create(mcframe.clientFSBA.FSBAP0290.DtlR.$screen_p);
		p.Dtl_screen_p_PPanel.setName("Dtl.screen_p");
		p.columnDtl_screen_id = p.Dtl_screen_p_PPanel.columnScreen_screen_id;
		p.columnDtl_screen_id.addAliasName("Dtl.screen_id", p);
		p.columnDtl_screen_name = p.Dtl_screen_p_PPanel.columnScreen_screen_name;
		p.columnDtl_screen_name.addAliasName("Dtl.screen_name", p);
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP_ScreenBookmarkSetting p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_ScreenBookmarkSetting create(){
		FSBAP_ScreenBookmarkSetting p = new FSBAP_ScreenBookmarkSetting();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_ScreenBookmarkSetting create(String name){
		FSBAP_ScreenBookmarkSetting p = new FSBAP_ScreenBookmarkSetting(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_ScreenBookmarkSetting_FW.jbfInitCnd((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbfInitDtl((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbfInitBtn((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbInitCnd((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbInitDtl((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.jbInitBtn((FSBAP_ScreenBookmarkSetting)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FSBAP_ScreenBookmarkSetting p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		// ブロックの項目の初期化
		p.Cnd_base_screen_id_Label = p.beansFactory.createLabel("Cnd.base_screen_id_Label");
		p.Cnd_base_screen_id = p.beansFactory.createTextField("Cnd.base_screen_id");
		p.Cnd_base_screen_id.setLabel(p.Cnd_base_screen_id_Label);
		p.Cnd_base_screen_nm = p.beansFactory.createTextField("Cnd.base_screen_nm");
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDtl(FSBAP_ScreenBookmarkSetting p) {
		// ブロック関連の初期化
		p.DtlPanel = p.beansFactory.createPanel("Dtl");
		p.DtlScrollPane = p.beansFactory.createScrollPane("Dtl.scroll");
		p.createDtlTable();
		// ブロックの項目の初期化
		p.columnDtl_lbl_text = p.beansFactory.createTableColumn("Dtl.lbl_text", MCColumnType.TEXT);
		p.columnDtl_value_forward = p.beansFactory.createTableColumn("Dtl.value_forward", MCColumnType.BUTTON);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP_ScreenBookmarkSetting p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_radd = p.beansFactory.createButton("Btn.radd", "no_border");
		p.Btn_rdel = p.beansFactory.createButton("Btn.rdel", "no_border");
		p.Btn_move_top = p.beansFactory.createButton("Btn.move_top", "no_border");
		p.Btn_move_up = p.beansFactory.createButton("Btn.move_up", "no_border");
		p.Btn_move_down = p.beansFactory.createButton("Btn.move_down", "no_border");
		p.Btn_move_bottom = p.beansFactory.createButton("Btn.move_bottom", "no_border");
		p.Btn_upd = p.beansFactory.createButton("Btn.upd", "upd");
		p.Btn_upd_sys = p.beansFactory.createButton("Btn.upd_sys", "upd");
		p.Btn_upd_ext = p.beansFactory.createButton("Btn.upd_ext", "upd");
		p.Btn_upd_close = p.beansFactory.createButton("Btn.upd_close", "upd");
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FSBAP_ScreenBookmarkSetting p) {
		// ブロック関連の初期化
		p.add(p.CndPanel);
		p.setLastBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.DtlPanel);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.CndPanel.add(p.Cnd_base_screen_id_Label);
		p.CndPanel.add(p.Cnd_base_screen_id);
		p.CndPanel.setLastBeans(p.Cnd_base_screen_id);
		p.Cnd_base_screen_id.setNextBeans(p.Cnd_base_screen_nm);
		p.Cnd_base_screen_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0290.CndR.base_screen_id_META);
		p.CndPanel.add(p.Cnd_base_screen_nm);
		p.Cnd_base_screen_nm.setNextBeans(p.Cnd_setting_PPanel);
		p.Cnd_base_screen_nm.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0290.CndR.base_screen_nm_META);
		p.CndPanel.add(p.Cnd_setting_PPanel);
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDtl(FSBAP_ScreenBookmarkSetting p) {
		// ブロック関連の初期化
		p.add(p.DtlPanel);
		p.DtlPanel.setNextBeans(p.BtnPanel);
		p.DtlPanel.add(p.DtlScrollPane);
		p.DtlPanel.setLastBeans(p.DtlTable);
		p.DtlScrollPane.setViewportView(p.DtlTable);
		p.DtlTable.setList(p.getDtlL());
		p.DtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP_ScreenBookmarkSetting p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_radd.setIcon("INSERT_RECORD");
		p.Btn_radd.setFunctionKey(MCFunctionKey.F5);
		p.BtnPanel.add(p.Btn_radd);
		p.BtnPanel.setLastBeans(p.Btn_radd);
		p.Btn_radd.setNextBeans(p.Btn_rdel);
		p.Btn_rdel.setIcon("DELETE_RECORD");
		p.Btn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.BtnPanel.add(p.Btn_rdel);
		p.Btn_rdel.setNextBeans(p.Btn_move_top);
		p.Btn_move_top.setIcon("MOVE_TOP");
		p.Btn_move_top.setFunctionKey(MCFunctionKey.F18);
		p.BtnPanel.add(p.Btn_move_top);
		p.Btn_move_top.setNextBeans(p.Btn_move_up);
		p.Btn_move_up.setIcon("MOVE_UP");
		p.Btn_move_up.setFunctionKey(MCFunctionKey.F19);
		p.BtnPanel.add(p.Btn_move_up);
		p.Btn_move_up.setNextBeans(p.Btn_move_down);
		p.Btn_move_down.setIcon("MOVE_DOWN");
		p.Btn_move_down.setFunctionKey(MCFunctionKey.F20);
		p.BtnPanel.add(p.Btn_move_down);
		p.Btn_move_down.setNextBeans(p.Btn_move_bottom);
		p.Btn_move_bottom.setIcon("MOVE_BOTTOM");
		p.Btn_move_bottom.setFunctionKey(MCFunctionKey.F21);
		p.BtnPanel.add(p.Btn_move_bottom);
		p.Btn_move_bottom.setNextBeans(p.Btn_upd);
		p.Btn_upd.setIcon("REGISTER");
		p.Btn_upd.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_upd);
		p.Btn_upd.setNextBeans(p.Btn_upd_sys);
		p.Btn_upd_sys.setIcon("REGISTER");
		p.Btn_upd_sys.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_upd_sys);
		p.Btn_upd_sys.setNextBeans(p.Btn_upd_ext);
		p.Btn_upd_ext.setIcon("REGISTER");
		p.Btn_upd_ext.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_upd_ext);
		p.Btn_upd_ext.setNextBeans(p.Btn_upd_close);
		p.Btn_upd_close.setIcon("REGISTER");
		p.Btn_upd_close.setFunctionKey(MCFunctionKey.F8);
		p.BtnPanel.add(p.Btn_upd_close);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_ScreenBookmarkSetting_FW.mcInitCnd((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.mcInitDtl((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.mcInitBtn((FSBAP_ScreenBookmarkSetting)this);

		// [INIT]ステータスのモードの設定
		FSBAP_ScreenBookmarkSetting_FW.statusInitINIT_Cnd((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.statusInitINIT_Dtl((FSBAP_ScreenBookmarkSetting)this);
		FSBAP_ScreenBookmarkSetting_FW.statusInitINIT_Btn((FSBAP_ScreenBookmarkSetting)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FSBAP_ScreenBookmarkSetting p) {
		p.Cnd_base_screen_id.setListListener(p);
		p.Cnd_base_screen_id.addAllListener(p);
		p.Cnd_base_screen_nm.setListListener(p);
		p.Cnd_base_screen_nm.addAllListener(p);
	}

	/**
	 *  [Dtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDtl(FSBAP_ScreenBookmarkSetting p) {
		p.DtlTable.addAllListener(p);
		p.columnDtl_lbl_text.addAllListener(p);
		p.columnDtl_lbl_text.setListListener(p);
		p.columnDtl_value_forward.addAllListener(p);
		p.columnDtl_value_forward.setAPMethodName("doDtl_value_forward");
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP_ScreenBookmarkSetting p) {
		p.Btn_radd.addAllListener(p);
		p.Btn_radd.setAPMethodName("doBtn_radd");
		p.Btn_rdel.addAllListener(p);
		p.Btn_rdel.setAPMethodName("doBtn_rdel");
		p.Btn_move_top.addAllListener(p);
		p.Btn_move_top.setAPMethodName("doBtn_move_top");
		p.Btn_move_up.addAllListener(p);
		p.Btn_move_up.setAPMethodName("doBtn_move_up");
		p.Btn_move_down.addAllListener(p);
		p.Btn_move_down.setAPMethodName("doBtn_move_down");
		p.Btn_move_bottom.addAllListener(p);
		p.Btn_move_bottom.setAPMethodName("doBtn_move_bottom");
		p.Btn_upd.addAllListener(p);
		p.Btn_upd.setAPMethodName("doBtn_upd");
		p.Btn_upd_sys.addAllListener(p);
		p.Btn_upd_sys.setAPMethodName("doBtn_upd_sys");
		p.Btn_upd_ext.addAllListener(p);
		p.Btn_upd_ext.setAPMethodName("doBtn_upd_ext");
		p.Btn_upd_close.addAllListener(p);
		p.Btn_upd_close.setAPMethodName("doBtn_upd_close");
	}

	/**
	 * [INIT]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Cnd(FSBAP_ScreenBookmarkSetting p){
		p.Cnd_base_screen_id.putMode(p, INIT, MCMode.READ_ONLY);
		p.Cnd_base_screen_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.Cnd_setting_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dtl(FSBAP_ScreenBookmarkSetting p){
		p.columnDtl_lbl_text.putMode(p, INIT, MCMode.REQUIRED);
		p.Dtl_module_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0100.FSUBP_Module_D.REQUIRED);
		p.Dtl_screen_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0110.FSUBP_Screen_D.REQUIRED);
		p.Dtl_screen_p_PPanel.columnScreen_screen_name.putMode(p, INIT, MCMode.REQUIRED);
		p.columnDtl_value_forward.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP_ScreenBookmarkSetting p){
		p.Btn_radd.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_rdel.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_move_top.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_move_up.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_move_down.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_move_bottom.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_upd.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_upd_sys.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_upd_ext.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_upd_close.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_ScreenBookmarkSetting_FW.setTableConfigDtl((FSBAP_ScreenBookmarkSetting)this);
	}

	/**
	 * [Dtl]ブロックのTableの設定
	 */
	protected static void setTableConfigDtl(FSBAP_ScreenBookmarkSetting p) {
		p.columnDtl_lbl_text.setMeta(mcframe.clientFSBA.FSBAP0290.DtlR.lbl_text_META);
		p.DtlTable.addColumnConfig(p.columnDtl_lbl_text);
		p.DtlTable.addTable(p.Dtl_module_p_PPanel.ModuleTable);
		p.DtlTable.addTable(p.Dtl_screen_p_PPanel.ScreenTable);
		p.DtlTable.addColumnConfig(p.columnDtl_value_forward);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == columnDtl_value_forward) doDtl_value_forward(info);
		else if (ap == Btn_radd) doBtn_radd(info);
		else if (ap == Btn_rdel) doBtn_rdel(info);
		else if (ap == Btn_move_top) doBtn_move_top(info);
		else if (ap == Btn_move_up) doBtn_move_up(info);
		else if (ap == Btn_move_down) doBtn_move_down(info);
		else if (ap == Btn_move_bottom) doBtn_move_bottom(info);
		else if (ap == Btn_upd) doBtn_upd(info);
		else if (ap == Btn_upd_sys) doBtn_upd_sys(info);
		else if (ap == Btn_upd_ext) doBtn_upd_ext(info);
		else if (ap == Btn_upd_close) doBtn_upd_close(info);
	}

	/**
	 * [Dtl]パネルの[value_forward]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDtl_value_forward(MCEventInfo info);

	/**
	 * [Btn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_radd(MCEventInfo info);

	/**
	 * [Btn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_rdel(MCEventInfo info);

	/**
	 * [Btn]パネルの[move_top]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_move_top(MCEventInfo info);

	/**
	 * [Btn]パネルの[move_up]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_move_up(MCEventInfo info);

	/**
	 * [Btn]パネルの[move_down]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_move_down(MCEventInfo info);

	/**
	 * [Btn]パネルの[move_bottom]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_move_bottom(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd_sys(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd_ext(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd_close]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd_close(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == DtlTable) return doDtl_VC(info);
		if (vc == Cnd_base_screen_id) return doCnd_base_screen_id_VC(info);
		if (vc == Cnd_base_screen_nm) return doCnd_base_screen_nm_VC(info);
		if (vc == columnDtl_lbl_text) return doDtl_lbl_text_VC(info);
		return true;
	}

	/**
	 * [Dtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[base_screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_base_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[base_screen_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_base_screen_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dtl]パネルの[lbl_text]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDtl_lbl_text_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == DtlTable) doDtl_NC(info);
		else if (nc == Cnd_base_screen_id) doCnd_base_screen_id_NC(info);
		else if (nc == Cnd_base_screen_nm) doCnd_base_screen_nm_NC(info);
		else if (nc == columnDtl_lbl_text) doDtl_lbl_text_NC(info);
	}

	/**
	 * [Dtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_nm_NC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lbl_text]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lbl_text_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == DtlTable) doDtl_NE(info);
		else if (ne == Cnd_base_screen_id) doCnd_base_screen_id_NE(info);
		else if (ne == Cnd_base_screen_nm) doCnd_base_screen_nm_NE(info);
		else if (ne == columnDtl_lbl_text) doDtl_lbl_text_NE(info);
	}

	/**
	 * [Dtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_nm_NE(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lbl_text]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lbl_text_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == DtlTable) doDtl_NX(info);
		else if (nx == Cnd_base_screen_id) doCnd_base_screen_id_NX(info);
		else if (nx == Cnd_base_screen_nm) doCnd_base_screen_nm_NX(info);
		else if (nx == columnDtl_lbl_text) doDtl_lbl_text_NX(info);
	}

	/**
	 * [Dtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_nm_NX(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lbl_text]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lbl_text_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_base_screen_id) doCnd_base_screen_id_LC(info);
		else if (lc == Cnd_base_screen_nm) doCnd_base_screen_nm_LC(info);
		else if (lc == columnDtl_lbl_text) doDtl_lbl_text_LC(info);
	}

	/**
	 * [Cnd]パネルの[base_screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[base_screen_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_base_screen_nm_LC(MCEventInfo info){
	}

	/**
	 * [Dtl]パネルの[lbl_text]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDtl_lbl_text_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}