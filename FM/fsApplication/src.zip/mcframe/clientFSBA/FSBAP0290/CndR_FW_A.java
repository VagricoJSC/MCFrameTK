package mcframe.clientFSBA.FSBAP0290;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cnd"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CndR_FW_A extends MCConstRow {

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $usr_id = "usr_id";
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $base_module_id = "base_module_id";
	/**
	 *  モジュール名.<p>
	 *
	 */
	public static final String $base_module_nm = "base_module_nm";
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public static final String $base_screen_id = "base_screen_id";
	/**
	 *  画面名.<p>
	 *
	 */
	public static final String $base_screen_nm = "base_screen_nm";


	public static final MCMeta usr_id_META = createCommonMeta($usr_id, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta base_module_id_META = createCommonMeta($base_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta base_module_nm_META = createCommonMeta($base_module_nm, mcframe.commonCore.meta.M_META.MODULE_ID_NM);
	public static final MCMeta base_screen_id_META = createCommonMeta($base_screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta base_screen_nm_META = createCommonMeta($base_screen_nm, mcframe.commonCore.meta.M_META.SCREEN_NAME);

	protected static final ConstMetaList<CndR> constMetas = new ConstMetaList<CndR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			usr_id_META,
			base_module_id_META,
			base_module_nm_META,
			base_screen_id_META,
			base_screen_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CndR_FW_A(ConstMetaList<? extends CndR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR clone() {
		return (CndR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR createInstance() {
		return (CndR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR getValues(String... names) {
		return (CndR) super.getValues(names);
	}



	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String usr_id() {
		return getConstString(offset + 0, $usr_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void usr_id(String value) {
		setConstString(offset + 0, $usr_id, value);
	}


	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String base_module_id() {
		return getConstString(offset + 1, $base_module_id);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void base_module_id(String value) {
		setConstString(offset + 1, $base_module_id, value);
	}


	/**
	 *  モジュール名.<p>
	 *
	 */
	public String base_module_nm() {
		return getConstString(offset + 2, $base_module_nm);
	}

	/**
	 *  モジュール名.<p>
	 *
	 */
	public void base_module_nm(String value) {
		setConstString(offset + 2, $base_module_nm, value);
	}


	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public String base_screen_id() {
		return getConstString(offset + 3, $base_screen_id);
	}

	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public void base_screen_id(String value) {
		setConstString(offset + 3, $base_screen_id, value);
	}


	/**
	 *  画面名.<p>
	 *
	 */
	public String base_screen_nm() {
		return getConstString(offset + 4, $base_screen_nm);
	}

	/**
	 *  画面名.<p>
	 *
	 */
	public void base_screen_nm(String value) {
		setConstString(offset + 4, $base_screen_nm, value);
	}


	public String getString(String name) {
		if ($usr_id.equalsIgnoreCase(name)) {
			return usr_id();
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			return base_module_id();
		}
		if ($base_module_nm.equalsIgnoreCase(name)) {
			return base_module_nm();
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			return base_screen_id();
		}
		if ($base_screen_nm.equalsIgnoreCase(name)) {
			return base_screen_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($usr_id.equalsIgnoreCase(name)) {
			return usr_id();
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			return base_module_id();
		}
		if ($base_module_nm.equalsIgnoreCase(name)) {
			return base_module_nm();
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			return base_screen_id();
		}
		if ($base_screen_nm.equalsIgnoreCase(name)) {
			return base_screen_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($usr_id.equalsIgnoreCase(name)) {
			usr_id(value);
			return;
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			base_module_id(value);
			return;
		}
		if ($base_module_nm.equalsIgnoreCase(name)) {
			base_module_nm(value);
			return;
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			base_screen_id(value);
			return;
		}
		if ($base_screen_nm.equalsIgnoreCase(name)) {
			base_screen_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($usr_id.equalsIgnoreCase(name)) {
			usr_id(value);
			return;
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			base_module_id(value);
			return;
		}
		if ($base_module_nm.equalsIgnoreCase(name)) {
			base_module_nm(value);
			return;
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			base_screen_id(value);
			return;
		}
		if ($base_screen_nm.equalsIgnoreCase(name)) {
			base_screen_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

