package mcframe.clientFSBA.FSBAP0290;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Dtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class DtlR_FW_A extends MCConstRow {

	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public static final String $setting_unit_type = "setting_unit_type";
	/**
	 *  ボタン.<p>
	 *
	 */
	public static final String $lbl_text = "lbl_text";
	public static final String $module_p = "module_p";
	public static final String $screen_p = "screen_p";
	/**
	 *  画面タイプ.<p>
	 *
	 */
	public static final String $panel_typ = "panel_typ";
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $usr_id = "usr_id";
	/**
	 *  起動元画面モジュールＩＤ.<p>
	 *
	 */
	public static final String $base_module_id = "base_module_id";
	/**
	 *  起動元画面画面ＩＤ.<p>
	 *
	 */
	public static final String $base_screen_id = "base_screen_id";

	public static final String $module_id = $module_p + ".module_id";
	public static final String $module_id_nm = $module_p + ".module_id_nm";
	public static final String $screen_id = $screen_p + ".screen_id";
	public static final String $screen_name = $screen_p + ".screen_name";

	public static final MCMeta setting_unit_type_META = createStringMeta($setting_unit_type);
	public static final MCMeta lbl_text_META = createStringMeta($lbl_text, 10);
	public static final MCMeta module_p_META = createInnerRowMeta($module_p, mcframe.clientFSUB.FSUBP0030.ModuleR.class);
	public static final MCMeta screen_p_META = createInnerRowMeta($screen_p, mcframe.clientFSUB.FSUBP0040.ScreenR.class);
	public static final MCMeta panel_typ_META = createStringMeta($panel_typ);
	public static final MCMeta usr_id_META = createStringMeta($usr_id);
	public static final MCMeta base_module_id_META = createStringMeta($base_module_id);
	public static final MCMeta base_screen_id_META = createStringMeta($base_screen_id);

	protected static final ConstMetaList<DtlR> constMetas = new ConstMetaList<DtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			setting_unit_type_META,
			lbl_text_META,
			module_p_META,
			screen_p_META,
			panel_typ_META,
			usr_id_META,
			base_module_id_META,
			base_screen_id_META
		},
		new String[][]{
			{
				"module_id",
				"module_id_nm",
				"screen_id",
				"screen_name"
			},
			{
				$module_id,
				$module_id_nm,
				$screen_id,
				$screen_name
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected DtlR_FW_A(ConstMetaList<? extends DtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DtlR clone() {
		return (DtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DtlR createInstance() {
		return (DtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DtlR getValues(String... names) {
		return (DtlR) super.getValues(names);
	}



	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public String setting_unit_type() {
		return getConstString(offset + 0, $setting_unit_type);
	}

	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public void setting_unit_type(String value) {
		setConstString(offset + 0, $setting_unit_type, value);
	}


	/**
	 *  ボタン.<p>
	 *
	 */
	public String lbl_text() {
		return getConstString(offset + 1, $lbl_text);
	}

	/**
	 *  ボタン.<p>
	 *
	 */
	public void lbl_text(String value) {
		setConstString(offset + 1, $lbl_text, value);
	}


	public mcframe.clientFSUB.FSUBP0030.ModuleR module_p(){
		return (mcframe.clientFSUB.FSUBP0030.ModuleR) getConstInnerRow(offset + 2, $module_p);
	}
	
	public void module_p(mcframe.clientFSUB.FSUBP0030.ModuleR row){
		setConstInnerRow(offset + 2, $module_p, row);
	}


	public mcframe.clientFSUB.FSUBP0040.ScreenR screen_p(){
		return (mcframe.clientFSUB.FSUBP0040.ScreenR) getConstInnerRow(offset + 3, $screen_p);
	}
	
	public void screen_p(mcframe.clientFSUB.FSUBP0040.ScreenR row){
		setConstInnerRow(offset + 3, $screen_p, row);
	}


	/**
	 *  画面タイプ.<p>
	 *
	 */
	public String panel_typ() {
		return getConstString(offset + 4, $panel_typ);
	}

	/**
	 *  画面タイプ.<p>
	 *
	 */
	public void panel_typ(String value) {
		setConstString(offset + 4, $panel_typ, value);
	}


	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String usr_id() {
		return getConstString(offset + 5, $usr_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void usr_id(String value) {
		setConstString(offset + 5, $usr_id, value);
	}


	/**
	 *  起動元画面モジュールＩＤ.<p>
	 *
	 */
	public String base_module_id() {
		return getConstString(offset + 6, $base_module_id);
	}

	/**
	 *  起動元画面モジュールＩＤ.<p>
	 *
	 */
	public void base_module_id(String value) {
		setConstString(offset + 6, $base_module_id, value);
	}


	/**
	 *  起動元画面画面ＩＤ.<p>
	 *
	 */
	public String base_screen_id() {
		return getConstString(offset + 7, $base_screen_id);
	}

	/**
	 *  起動元画面画面ＩＤ.<p>
	 *
	 */
	public void base_screen_id(String value) {
		setConstString(offset + 7, $base_screen_id, value);
	}


	public String getString(String name) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			return lbl_text();
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			return panel_typ();
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			return usr_id();
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			return base_module_id();
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			return base_screen_id();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			return lbl_text();
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			return panel_typ();
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			return usr_id();
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			return base_module_id();
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			return base_screen_id();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			lbl_text(value);
			return;
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			panel_typ(value);
			return;
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			usr_id(value);
			return;
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			base_module_id(value);
			return;
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			base_screen_id(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			lbl_text(value);
			return;
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			panel_typ(value);
			return;
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			usr_id(value);
			return;
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			base_module_id(value);
			return;
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			base_screen_id(value);
			return;
		}
		super.setStringNE(name, value);
	}

	public MCRow getInnerRow(String name) {
		if ($module_p.equalsIgnoreCase(name)) {
			return module_p();
		}
		if ($screen_p.equalsIgnoreCase(name)) {
			return screen_p();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($module_p.equalsIgnoreCase(name)) {
			module_p(
				((MCContainerMeta) module_p_META).castInnerRow(mcframe.clientFSUB.FSUBP0030.ModuleR.class, value)
			);
			return;
		}
		if ($screen_p.equalsIgnoreCase(name)) {
			screen_p(
				((MCContainerMeta) screen_p_META).castInnerRow(mcframe.clientFSUB.FSUBP0040.ScreenR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public String module_id() {
		return module_p().module_id();
	}

	public void module_id(String value) {
		module_p().module_id(value);
	}

	public String module_id_nm() {
		return module_p().module_id_nm();
	}

	public void module_id_nm(String value) {
		module_p().module_id_nm(value);
	}

	public String screen_id() {
		return screen_p().screen_id();
	}

	public void screen_id(String value) {
		screen_p().screen_id(value);
	}

	public String screen_name() {
		return screen_p().screen_name();
	}

	public void screen_name(String value) {
		screen_p().screen_name(value);
	}

}

