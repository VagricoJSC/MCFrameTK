package mcframe.clientFSBA.FSBAP0680;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSBA.FSBAP0670.FSBAP0670_FW;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_SrchCnd"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_SrchCnd_FW extends FSBAP_SrchCnd_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SrchCnd_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SrchCnd_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[InfoBtn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_select_all(MCEventInfo info) {
	}
	/**
	 * Panel[InfoBtn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_deselect_all(MCEventInfo info) {
	}

	protected void mcInit() {
		super.mcInit();

		ListBtn_upd_apply.putMode(this, INIT, MCMode.INVISIBLE);
		ListBtn_upd_apply.putMode(this, EDIT, MCMode.INVISIBLE);
		ListBtn_upd_apply.putMode(this, DISABLE, MCMode.INVISIBLE);
		SettingPanel.setVisible(false);
	}

	//画面処理メソッドはこれより下に定義してください

}