package mcframe.clientFSBA.FSBAP0430;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.Box;
import javax.swing.BoxLayout;

import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.commonFS.constant.FSC_RELATIVE_OPERATOR_TYP;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0430"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0430_FW extends FSBAP0430_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * ラベル
	 */
	protected MCLabel Value_value_Label = null;

	/**
	 * パラメータ：項目
	 */
	protected MCValueSupply.StringVS _param_col = null;

	/**
	 * パラメータ：しきい値
	 */
	protected MCValueSupply.NumberVS _param_num = null;

	/**
	 * パラメータ：比較条件
	 */
	protected MCValueSupply.StringVS _param_rel = null;

	/**
	 * コンボ用List
	 */
	protected MCList<ListR> _listL;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0430_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0430_FW(mcframe.clientFSBA.FSBAP0430.ValueR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void doValue_column_nm_LC(MCEventInfo info){
		if (info.getNewValue() == null) {
			Value_value.setValue(null);
			Value_relative_type_nm.setValue(null);
		}
	}

	@Override
	public void layoutInit() {
		super.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BoxLayout(ValuePanel, BoxLayout.X_AXIS));

		Value_value_Label = beansFactory.createLabel("Value.value_Label");
		Value_value.setLabel(Value_value_Label);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//		Value_column_nm.setMaximumSize(Value_column_nm.getPreferredSize());
//		Value_value.setMaximumSize(Value_value.getPreferredSize());
//		Value_relative_type_nm.setMaximumSize(Value_relative_type_nm.getPreferredSize());

		ValuePanel.add(Value_value_Label);
		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_column_nm);
		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_relative_type_nm);
		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_value);
		// 非表示も追加しておく
		ValuePanel.add(Value_column_pos);
		ValuePanel.add(Value_relative_type);
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return new MCModeBeans[] { Value_column_nm, Value_value, Value_relative_type_nm };
	}

	@Override
	public String getStatusFor(MCValueSupply...param) {
		// 項目で判定
		return super.getStatusFor(param);
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param_col, _param_num, _param_rel };
	}

	@Override
	public void setValueList(MCList<ListR> listL) {
		_listL = listL;
	}

	/**
	 * パラメータを設定します。
	 *
	 * @param param 設定パラメータの配列（項目、しきい値、比較方法）
	 */
	@Override
	public void setParam(MCValueSupply...param) {
		_param_col = (MCValueSupply.StringVS) param[0];	// 項目
		_param_num = (MCValueSupply.NumberVS) param[1];	// しきい値
		_param_rel = (MCValueSupply.StringVS) param[2];	// 比較方法

		// 表示名称の設定
		Value_value_Label.setText(_param_num.name());

		// メッセージ用表示名称の設定
		Value_column_nm.setMessageName(_param_col.name());
		Value_value.setMessageName(_param_num.name());
		Value_relative_type_nm.setMessageName(_param_rel.name());

		// 初期値：しきい値
		getValueR().value((MCNumber) _param_num.value());

		MCList<ListR> colL = getValue_column_nm(null, null);
		if (colL != null && colL.size() > 0) {
			// 表示カラム設定
			Value_column_nm.setListVisibleColumn(ListR.$name);
			// 連携カラム設定 
			getValue_column_nm_ListPutter().setColumns(ListR.$name, ListR.$value);

			// 初期値：カラム名（コンボ連携）
			String col = (String) _param_col.value();
			ListR listR = colL.getFirst(ListR.$value, col);
			String col_nm = (listR != null) ? listR.name() :  null;
			Value_column_nm.setValue(col_nm);
		}

		// 初期値：比較条件（コンボ連携）
		String rel = (String) _param_rel.value();
		String rel_nm = (rel != null) ? FSC_RELATIVE_OPERATOR_TYP.getNE(rel).name() : null;
		Value_relative_type_nm.setValue(rel_nm);
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);

		// 項目のリストが未設定の場合、項目は利用不可
		MCList<ListR> colL = getValue_column_nm(null, null);
		if (colL == null || colL.size() <= 0) {
			Value_column_nm.setMode(MCMode.DISABLE);
		}
	}


	@Override
	public MCRowBeans checkRequiredValue() {
		ValueR valueR = getValueR();
		String col = valueR.column_nm();
		String rel = valueR.relative_type();
		MCNumber num = valueR.value();

		// 必須入力チェック
		if (_param_col.required() && isNull(col)) {
			return Value_column_nm;
		}
		if (_param_num.required() && isNull(rel)) {
			return Value_relative_type_nm;
		}
		if (_param_rel.required() && isNull(num)) {
			return Value_value;
		}

		// 関連チェック
		// posはnull可（nullの場合は全項目が対象）
		if (num == null && rel != null) {
			return Value_value;
		}
		if (num != null && rel == null) {
			return Value_relative_type_nm;
		}

		return null;
	}

	@Override
	public void updateParam() {
		_param_col.value(getValueR().column_pos());
		_param_num.value(getValueR().value());
		_param_rel.value(getValueR().relative_type());
	}


	@Override
	protected void listInit() {
		super.listInit();

		Value_relative_type_nm.setListVisibleColumn(
				RelativeOperatorTypeCols.$o_relative_operator_typ_nm);
		getValue_relative_type_nm_ListPutter().setColumns(
				RelativeOperatorTypeCols.$o_relative_operator_typ_nm, 
				RelativeOperatorTypeCols.$o_relative_operator_typ);
	}

	@Override
	public MCList getValue_column_nm(MCRow row, MCEventInfo info){
		if (_listL != null) {
			// Paramからのリスト使用時
			// indexを使うまでもない？
			return _listL.subList(ListR.$item, _param_col.column());
		}
		return null;
	}

	@Override
	public MCList getValue_relative_type_nm(MCRow row, MCEventInfo info){
		// 使用可能な演算子（RowFilterのNumberと同じ）
		List<String> a = MCDataMatcher.getEnableRelativeOperatorList(MCDataType.NUMBER);

		MCList<MCRow> e = MCList.create(MCRow.class);
		MCList<?> l = super.getValue_relative_type_nm(row, info);
		for (MCRow o : l) {
			String y = o.getString(
					RelativeOperatorTypeCols.$o_relative_operator_typ);
			if (a.contains(y)) {
				e.add(o);
			}
		}
		
		return e;
	}

}