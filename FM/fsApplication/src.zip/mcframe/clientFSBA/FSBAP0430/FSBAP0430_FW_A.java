package mcframe.clientFSBA.FSBAP0430;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0430"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0430_FW_A extends mcframe.clientFXBA.FXBAP0150.FXBAP0150{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0430";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Value]ブロック関連のField定義
	public MCPanel ValuePanel = null;
	// [Value]ブロックの項目のField定義
	/**
	 * 項目 項目.<p>
	 *
	 */
	public MCTextComboBox Value_column_nm = null;
	public MCTextField Value_column_pos = null;
	/**
	 *  比較条件.<p>
	 *
	 */
	public MCTextComboBox Value_relative_type_nm = null;
	public MCTextField Value_relative_type = null;
	/**
	 * 数値 数値.<p>
	 *
	 */
	public MCNumberField Value_value = null;
	/** [EDITABLE]モードを表す定数 */
	public static final String EDITABLE = "EDITABLE";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{EDITABLE, READ_ONLY};
	
	/** [Value]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0430.ValueR aValueR;

	/**
	 * 項目コピーによってaValueRを設定します。
	 *
	 * aValueRのインスタンスは変更されません。
	 *
	 * @param row ValueR
	 */
	public void setValueR(mcframe.clientFSBA.FSBAP0430.ValueR row) {
		if (row != null) {
			MCRow.copyall(getValueR(), row);
		}
	}

	/**
	 * [Value]ブロックのコンテナaValueRを返します。
	 *
	 * @return ValueR
	 */
	public mcframe.clientFSBA.FSBAP0430.ValueR getValueR() {
		return aValueR;
	}

	/**
	 * aValueRを作成します。
	 *
	 * @return ValueR
	 */
	public mcframe.clientFSBA.FSBAP0430.ValueR createValueR() {
		return mcframe.clientFSBA.FSBAP0430.ValueR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getValueR())) ret.add(getValueR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getValueR()) return "Value";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Value")) return getValueR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ValuePanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0430_FW_A() {
		aValueR = createValueR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0430_FW_A(mcframe.clientFSBA.FSBAP0430.ValueR row){
		aValueR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0430_FW.jbCreateValue((FSBAP0430)this);
	}

	/**
	 * [Value]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateValue(FSBAP0430 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Value_column_nm_ListPutter]の定義 */
	private MCListPutter Value_column_nm_p = null;

	/**
	 * [Value_column_nm_ListPutter]の取得
	 */
	protected MCListPutter getValue_column_nm_ListPutter() {
		if (Value_column_nm_p == null) {
			Value_column_nm_p = createValue_column_nm_ListPutter(Value_column_nm, "column_nm", "column_pos");

		}
		return Value_column_nm_p;
	}
	
	
	/** [Value_relative_type_nm_ListPutter]の定義 */
	private MCListPutter Value_relative_type_nm_p = null;

	/**
	 * [Value_relative_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getValue_relative_type_nm_ListPutter() {
		if (Value_relative_type_nm_p == null) {
			Value_relative_type_nm_p = createValue_relative_type_nm_ListPutter(Value_relative_type_nm, "relative_type_nm", "relative_type");

		}
		return Value_relative_type_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FSBAP0430 create(mcframe.clientFSBA.FSBAP0430.ValueR row){
		FSBAP0430 p = new FSBAP0430(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0430 create(){
		FSBAP0430 p = new FSBAP0430();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0430_FW.jbfInitValue((FSBAP0430)this);
		FSBAP0430_FW.jbInitValue((FSBAP0430)this);
	}

	/**
	 * [Value]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitValue(FSBAP0430 p) {
		// ブロック関連の初期化
		p.ValuePanel = p.beansFactory.createPanel("Value");
		// ブロックの項目の初期化
		p.Value_column_nm = p.beansFactory.createTextComboBox("Value.column_nm");
		p.Value_column_pos = p.beansFactory.createTextField("Value.column_pos");
		p.Value_relative_type_nm = p.beansFactory.createTextComboBox("Value.relative_type_nm");
		p.Value_relative_type = p.beansFactory.createTextField("Value.relative_type");
		p.Value_value = p.beansFactory.createNumberField("Value.value");
	}

	/**
	 * [Value]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitValue(FSBAP0430 p) {
		// ブロック関連の初期化
		p.add(p.ValuePanel);
		p.setLastBeans(p.ValuePanel);
		p.ValuePanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.Value_column_nm.setListType(MCListType.STRICT);
		p.Value_column_nm.setLinkBeans(p.Value_column_pos);
		p.ValuePanel.add(p.Value_column_nm);
		p.ValuePanel.setLastBeans(p.Value_column_nm);
		p.Value_column_nm.setNextBeans(p.Value_column_pos);
		p.Value_column_nm.setRow(p.getValueR(), mcframe.clientFSBA.FSBAP0430.ValueR.column_nm_META);
		p.ValuePanel.add(p.Value_column_pos);
		p.Value_column_pos.setNextBeans(p.Value_relative_type_nm);
		p.Value_column_pos.setRow(p.getValueR(), mcframe.clientFSBA.FSBAP0430.ValueR.column_pos_META);
		p.Value_relative_type_nm.setListType(MCListType.STRICT);
		p.Value_relative_type_nm.setLinkBeans(p.Value_relative_type);
		p.ValuePanel.add(p.Value_relative_type_nm);
		p.Value_relative_type_nm.setNextBeans(p.Value_relative_type);
		p.Value_relative_type_nm.setRow(p.getValueR(), mcframe.clientFSBA.FSBAP0430.ValueR.relative_type_nm_META);
		p.ValuePanel.add(p.Value_relative_type);
		p.Value_relative_type.setNextBeans(p.Value_value);
		p.Value_relative_type.setRow(p.getValueR(), mcframe.clientFSBA.FSBAP0430.ValueR.relative_type_META);
		p.ValuePanel.add(p.Value_value);
		p.Value_value.setRow(p.getValueR(), mcframe.clientFSBA.FSBAP0430.ValueR.value_META);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0430_FW.mcInitValue((FSBAP0430)this);

		// [EDITABLE]ステータスのモードの設定
		FSBAP0430_FW.statusInitEDITABLE_Value((FSBAP0430)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP0430_FW.statusInitREAD__ONLY_Value((FSBAP0430)this);

	}

	/**
	 *  [Value]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitValue(FSBAP0430 p) {
		p.Value_column_nm.setListListener(p);
		p.Value_column_nm.addAllListener(p);
		p.Value_column_pos.setListListener(p);
		p.Value_column_pos.addAllListener(p);
		p.Value_relative_type_nm.setListListener(p);
		p.Value_relative_type_nm.addAllListener(p);
		p.Value_relative_type.setListListener(p);
		p.Value_relative_type.addAllListener(p);
		p.Value_value.setListListener(p);
		p.Value_value.addAllListener(p);
	}

	/**
	 * [EDITABLE]ステータスの[Value]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_Value(FSBAP0430 p){
		p.Value_column_nm.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Value_column_pos.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.Value_relative_type_nm.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Value_relative_type.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.Value_value.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Value]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Value(FSBAP0430 p){
		p.Value_column_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Value_column_pos.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Value_relative_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Value_relative_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Value_value.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return EDITABLE;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Value_column_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		Value_column_nm.getListConfig().setPutter(getValue_column_nm_ListPutter());
		Value_relative_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		Value_relative_type_nm.getListConfig().setPutter(getValue_relative_type_nm_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [Value_column_nm_ListPutter]の作成
	 */
	protected MCListPutter createValue_column_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Value_relative_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createValue_relative_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.RelativeOperatorType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Value_column_nm) return getValue_column_nm(row, info);
		if(combo == Value_relative_type_nm) return getValue_relative_type_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Value_column_nm) return doValue_column_nm_VC(info);
		if (vc == Value_column_pos) return doValue_column_pos_VC(info);
		if (vc == Value_relative_type_nm) return doValue_relative_type_nm_VC(info);
		if (vc == Value_relative_type) return doValue_relative_type_VC(info);
		if (vc == Value_value) return doValue_value_VC(info);
		return true;
	}

	/**
	 * [Value]パネルの[column_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doValue_column_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Value]パネルの[column_pos]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doValue_column_pos_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Value]パネルの[relative_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doValue_relative_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Value]パネルの[relative_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doValue_relative_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Value]パネルの[value]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doValue_value_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Value_column_nm) doValue_column_nm_NC(info);
		else if (nc == Value_column_pos) doValue_column_pos_NC(info);
		else if (nc == Value_relative_type_nm) doValue_relative_type_nm_NC(info);
		else if (nc == Value_relative_type) doValue_relative_type_NC(info);
		else if (nc == Value_value) doValue_value_NC(info);
	}

	/**
	 * [Value]パネルの[column_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_nm_NC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[column_pos]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_pos_NC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_NC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[value]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Value_column_nm) doValue_column_nm_NE(info);
		else if (ne == Value_column_pos) doValue_column_pos_NE(info);
		else if (ne == Value_relative_type_nm) doValue_relative_type_nm_NE(info);
		else if (ne == Value_relative_type) doValue_relative_type_NE(info);
		else if (ne == Value_value) doValue_value_NE(info);
	}

	/**
	 * [Value]パネルの[column_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_nm_NE(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[column_pos]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_pos_NE(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_NE(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[value]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Value_column_nm) doValue_column_nm_NX(info);
		else if (nx == Value_column_pos) doValue_column_pos_NX(info);
		else if (nx == Value_relative_type_nm) doValue_relative_type_nm_NX(info);
		else if (nx == Value_relative_type) doValue_relative_type_NX(info);
		else if (nx == Value_value) doValue_value_NX(info);
	}

	/**
	 * [Value]パネルの[column_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_nm_NX(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[column_pos]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_pos_NX(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_NX(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[value]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Value_column_nm) doValue_column_nm_LC(info);
		else if (lc == Value_column_pos) doValue_column_pos_LC(info);
		else if (lc == Value_relative_type_nm) doValue_relative_type_nm_LC(info);
		else if (lc == Value_relative_type) doValue_relative_type_LC(info);
		else if (lc == Value_value) doValue_value_LC(info);
	}

	/**
	 * [Value]パネルの[column_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_nm_LC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[column_pos]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_column_pos_LC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[relative_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_relative_type_LC(MCEventInfo info){
	}

	/**
	 * [Value]パネルの[value]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Value_column_nm]の作成メソッド
	 */
	public MCList getValue_column_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[Value_relative_type_nm]の作成メソッド
	 */
	public MCList getValue_relative_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getRelativeOperatorType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}