package mcframe.clientFSBA.FSBAP0380;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Target"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class TargetR_FW_A extends MCConstRow {

	/**
	 *  選択.<p>
	 *
	 */
	public static final String $check = "check";
	/**
	 *  枠キー.<p>
	 *
	 */
	public static final String $pnl_nm = "pnl_nm";
	/**
	 *  枠名.<p>
	 *
	 */
	public static final String $pnl_title = "pnl_title";


	public static final MCMeta check_META = createCommonMeta($check, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta pnl_nm_META = createStringMeta($pnl_nm);
	public static final MCMeta pnl_title_META = createStringMeta($pnl_title);

	protected static final ConstMetaList<TargetR> constMetas = new ConstMetaList<TargetR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			check_META,
			pnl_nm_META,
			pnl_title_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected TargetR_FW_A(ConstMetaList<? extends TargetR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TargetR clone() {
		return (TargetR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TargetR createInstance() {
		return (TargetR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TargetR getValues(String... names) {
		return (TargetR) super.getValues(names);
	}



	/**
	 *  選択.<p>
	 *
	 */
	public boolean check() {
		return getConstBoolean(offset + 0, $check);
	}

	/**
	 *  選択.<p>
	 *
	 */
	public void check(boolean value) {
		setConstBoolean(offset + 0, $check, value);
	}


	/**
	 *  枠キー.<p>
	 *
	 */
	public String pnl_nm() {
		return getConstString(offset + 1, $pnl_nm);
	}

	/**
	 *  枠キー.<p>
	 *
	 */
	public void pnl_nm(String value) {
		setConstString(offset + 1, $pnl_nm, value);
	}


	/**
	 *  枠名.<p>
	 *
	 */
	public String pnl_title() {
		return getConstString(offset + 2, $pnl_title);
	}

	/**
	 *  枠名.<p>
	 *
	 */
	public void pnl_title(String value) {
		setConstString(offset + 2, $pnl_title, value);
	}


	public String getString(String name) {
		if ($pnl_nm.equalsIgnoreCase(name)) {
			return pnl_nm();
		}
		if ($pnl_title.equalsIgnoreCase(name)) {
			return pnl_title();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($pnl_nm.equalsIgnoreCase(name)) {
			return pnl_nm();
		}
		if ($pnl_title.equalsIgnoreCase(name)) {
			return pnl_title();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($pnl_nm.equalsIgnoreCase(name)) {
			pnl_nm(value);
			return;
		}
		if ($pnl_title.equalsIgnoreCase(name)) {
			pnl_title(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($pnl_nm.equalsIgnoreCase(name)) {
			pnl_nm(value);
			return;
		}
		if ($pnl_title.equalsIgnoreCase(name)) {
			pnl_title(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

