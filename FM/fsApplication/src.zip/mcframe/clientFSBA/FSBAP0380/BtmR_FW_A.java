package mcframe.clientFSBA.FSBAP0380;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Btm"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BtmR_FW_A extends MCConstRow {

	/**
	 *  簡易入力.<p>
	 *
	 */
	public static final String $input = "input";
	public static final String $h_align_type = "h_align_type";
	/**
	 *  値の横位置.<p>
	 *
	 */
	public static final String $h_align_type_nm = "h_align_type_nm";


	public static final MCMeta input_META = createCommonMeta($input, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta h_align_type_META = createStringMeta($h_align_type);
	public static final MCMeta h_align_type_nm_META = createStringMeta($h_align_type_nm);

	protected static final ConstMetaList<BtmR> constMetas = new ConstMetaList<BtmR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			input_META,
			h_align_type_META,
			h_align_type_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BtmR_FW_A(ConstMetaList<? extends BtmR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtmR clone() {
		return (BtmR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtmR createInstance() {
		return (BtmR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtmR getValues(String... names) {
		return (BtmR) super.getValues(names);
	}



	/**
	 *  簡易入力.<p>
	 *
	 */
	public boolean input() {
		return getConstBoolean(offset + 0, $input);
	}

	/**
	 *  簡易入力.<p>
	 *
	 */
	public void input(boolean value) {
		setConstBoolean(offset + 0, $input, value);
	}


	public String h_align_type() {
		return getConstString(offset + 1, $h_align_type);
	}

	public void h_align_type(String value) {
		setConstString(offset + 1, $h_align_type, value);
	}


	/**
	 *  値の横位置.<p>
	 *
	 */
	public String h_align_type_nm() {
		return getConstString(offset + 2, $h_align_type_nm);
	}

	/**
	 *  値の横位置.<p>
	 *
	 */
	public void h_align_type_nm(String value) {
		setConstString(offset + 2, $h_align_type_nm, value);
	}


	public String getString(String name) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			return h_align_type();
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			return h_align_type_nm();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($input.equalsIgnoreCase(name)) {
			return input();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			return h_align_type();
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			return h_align_type_nm();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($input.equalsIgnoreCase(name)) {
			return input();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			h_align_type(value);
			return;
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			h_align_type_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($input.equalsIgnoreCase(name)) {
			input(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			h_align_type(value);
			return;
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			h_align_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($input.equalsIgnoreCase(name)) {
			input(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

