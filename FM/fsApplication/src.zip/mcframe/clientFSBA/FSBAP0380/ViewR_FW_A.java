package mcframe.clientFSBA.FSBAP0380;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"View"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ViewR_FW_A extends MCConstRow {

	/**
	 *  枠名.<p>
	 *
	 */
	public static final String $pnl_title = "pnl_title";
	/**
	 *  項目.<p>
	 *
	 */
	public static final String $title = "title";
	/**
	 *  1.<p>
	 *
	 */
	public static final String $data = "data";
	/**
	 *  データ型.<p>
	 *
	 */
	public static final String $dat_typ = "dat_typ";
	/**
	 *  親パネル名.<p>
	 *
	 */
	public static final String $par_pnl_nm = "par_pnl_nm";
	/**
	 *  親フィールド名.<p>
	 *
	 */
	public static final String $par_field_nm = "par_field_nm";


	public static final MCMeta pnl_title_META = createStringMeta($pnl_title);
	public static final MCMeta title_META = createStringMeta($title);
	public static final MCMeta data_META = createStringMeta($data);
	public static final MCMeta dat_typ_META = createStringMeta($dat_typ);
	public static final MCMeta par_pnl_nm_META = createStringMeta($par_pnl_nm);
	public static final MCMeta par_field_nm_META = createStringMeta($par_field_nm);

	protected static final ConstMetaList<ViewR> constMetas = new ConstMetaList<ViewR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			pnl_title_META,
			title_META,
			data_META,
			dat_typ_META,
			par_pnl_nm_META,
			par_field_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ViewR_FW_A(ConstMetaList<? extends ViewR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ViewR clone() {
		return (ViewR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ViewR createInstance() {
		return (ViewR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ViewR getValues(String... names) {
		return (ViewR) super.getValues(names);
	}



	/**
	 *  枠名.<p>
	 *
	 */
	public String pnl_title() {
		return getConstString(offset + 0, $pnl_title);
	}

	/**
	 *  枠名.<p>
	 *
	 */
	public void pnl_title(String value) {
		setConstString(offset + 0, $pnl_title, value);
	}


	/**
	 *  項目.<p>
	 *
	 */
	public String title() {
		return getConstString(offset + 1, $title);
	}

	/**
	 *  項目.<p>
	 *
	 */
	public void title(String value) {
		setConstString(offset + 1, $title, value);
	}


	/**
	 *  1.<p>
	 *
	 */
	public String data() {
		return getConstString(offset + 2, $data);
	}

	/**
	 *  1.<p>
	 *
	 */
	public void data(String value) {
		setConstString(offset + 2, $data, value);
	}


	/**
	 *  データ型.<p>
	 *
	 */
	public String dat_typ() {
		return getConstString(offset + 3, $dat_typ);
	}

	/**
	 *  データ型.<p>
	 *
	 */
	public void dat_typ(String value) {
		setConstString(offset + 3, $dat_typ, value);
	}


	/**
	 *  親パネル名.<p>
	 *
	 */
	public String par_pnl_nm() {
		return getConstString(offset + 4, $par_pnl_nm);
	}

	/**
	 *  親パネル名.<p>
	 *
	 */
	public void par_pnl_nm(String value) {
		setConstString(offset + 4, $par_pnl_nm, value);
	}


	/**
	 *  親フィールド名.<p>
	 *
	 */
	public String par_field_nm() {
		return getConstString(offset + 5, $par_field_nm);
	}

	/**
	 *  親フィールド名.<p>
	 *
	 */
	public void par_field_nm(String value) {
		setConstString(offset + 5, $par_field_nm, value);
	}


	public String getString(String name) {
		if ($pnl_title.equalsIgnoreCase(name)) {
			return pnl_title();
		}
		if ($title.equalsIgnoreCase(name)) {
			return title();
		}
		if ($data.equalsIgnoreCase(name)) {
			return data();
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			return dat_typ();
		}
		if ($par_pnl_nm.equalsIgnoreCase(name)) {
			return par_pnl_nm();
		}
		if ($par_field_nm.equalsIgnoreCase(name)) {
			return par_field_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($pnl_title.equalsIgnoreCase(name)) {
			return pnl_title();
		}
		if ($title.equalsIgnoreCase(name)) {
			return title();
		}
		if ($data.equalsIgnoreCase(name)) {
			return data();
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			return dat_typ();
		}
		if ($par_pnl_nm.equalsIgnoreCase(name)) {
			return par_pnl_nm();
		}
		if ($par_field_nm.equalsIgnoreCase(name)) {
			return par_field_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($pnl_title.equalsIgnoreCase(name)) {
			pnl_title(value);
			return;
		}
		if ($title.equalsIgnoreCase(name)) {
			title(value);
			return;
		}
		if ($data.equalsIgnoreCase(name)) {
			data(value);
			return;
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			dat_typ(value);
			return;
		}
		if ($par_pnl_nm.equalsIgnoreCase(name)) {
			par_pnl_nm(value);
			return;
		}
		if ($par_field_nm.equalsIgnoreCase(name)) {
			par_field_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($pnl_title.equalsIgnoreCase(name)) {
			pnl_title(value);
			return;
		}
		if ($title.equalsIgnoreCase(name)) {
			title(value);
			return;
		}
		if ($data.equalsIgnoreCase(name)) {
			data(value);
			return;
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			dat_typ(value);
			return;
		}
		if ($par_pnl_nm.equalsIgnoreCase(name)) {
			par_pnl_nm(value);
			return;
		}
		if ($par_field_nm.equalsIgnoreCase(name)) {
			par_field_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

