package mcframe.clientFSBA.FSBAP0380;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_VerticalView_H"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_VerticalView_H_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0380";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Target]ブロック関連のField定義
	public MCPanel TargetPanel = null;
	public MCScrollPane TargetScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0380.TargetR> TargetTable = null;
	// [Target]ブロックの項目のField定義
	/**
	 *  選択.<p>
	 *
	 */
	public MCColumnConfig columnTarget_check = null;
	/**
	 *  枠名.<p>
	 *
	 */
	public MCColumnConfig columnTarget_pnl_title = null;
	// [ViewPanel]ブロック関連のField定義
	public MCPanel ViewPanelPanel = null;
	// [ViewPanel]ブロックの項目のField定義
	// [View]ブロック関連のField定義
	public MCPanel ViewPanel = null;
	public MCScrollPane ViewScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0380.ViewR> ViewTable = null;
	// [View]ブロックの項目のField定義
	/**
	 *  枠名.<p>
	 *
	 */
	public MCColumnConfig columnView_pnl_title = null;
	/**
	 *  項目.<p>
	 *
	 */
	public MCColumnConfig columnView_title = null;
	/**
	 *  1.<p>
	 *
	 */
	public MCColumnConfig columnView_data = null;
	// [Btm]ブロック関連のField定義
	public MCPanel BtmPanel = null;
	// [Btm]ブロックの項目のField定義
	/**
	 *  簡易入力.<p>
	 *
	 */
	public MCCheckBox Btm_input = null;
	public MCTextField Btm_h_align_type = null;
	public MCLabel Btm_h_align_type_nm_Label = null;
	/**
	 *  値の横位置.<p>
	 *
	 */
	public MCTextComboBox Btm_h_align_type_nm = null;
	public mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H Btm_par_screen_nm_p_PPanel;
	/** [SRCH]モードを表す定数 */
	public static final String SRCH = "SRCH";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{SRCH};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Target]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0380.TargetR> aTargetL;
	/** [View]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0380.ViewR> aViewL;
	/** [Btm]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0380.BtmR aBtmR;

	/**
	 * コピーによってaTargetLを設定します。
	 *
	 * aTargetLのインスタンスは変更されません。
	 *
	 * @param dataset TargetL
	 */
	public void setTargetL(MCList<mcframe.clientFSBA.FSBAP0380.TargetR> aList) {
		if (getTargetL() != aList) {
			getTargetL().setAll(aList);
		}
	}

	/**
	 * [Target]ブロックのコンテナaTargetLを返します。
	 *
	 * @return TargetL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0380.TargetR> getTargetL() {
		return aTargetL;
	}

	/**
	 * aTargetRを作成します。
	 *
	 * @return TargetR
	 */
	public mcframe.clientFSBA.FSBAP0380.TargetR createTargetR() {
		return mcframe.clientFSBA.FSBAP0380.TargetR.create();
	}

	/**
	 * aTargetLを作成します。
	 *
	 * @return TargetL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0380.TargetR> createTargetL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0380.TargetR.class);
	}

	/**
	 * TargetTableを初期化します。
	 */
	protected void createTargetTable(){
		if(TargetTable == null){
			TargetTable = beansFactory.createTable2("Target.table");
		}
	}

	/**
	 * コピーによってaViewLを設定します。
	 *
	 * aViewLのインスタンスは変更されません。
	 *
	 * @param dataset ViewL
	 */
	public void setViewL(MCList<mcframe.clientFSBA.FSBAP0380.ViewR> aList) {
		if (getViewL() != aList) {
			getViewL().setAll(aList);
		}
	}

	/**
	 * [View]ブロックのコンテナaViewLを返します。
	 *
	 * @return ViewL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0380.ViewR> getViewL() {
		return aViewL;
	}

	/**
	 * aViewRを作成します。
	 *
	 * @return ViewR
	 */
	public mcframe.clientFSBA.FSBAP0380.ViewR createViewR() {
		return mcframe.clientFSBA.FSBAP0380.ViewR.create();
	}

	/**
	 * aViewLを作成します。
	 *
	 * @return ViewL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0380.ViewR> createViewL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0380.ViewR.class);
	}

	/**
	 * ViewTableを初期化します。
	 */
	protected void createViewTable(){
		if(ViewTable == null){
			ViewTable = beansFactory.createTable2("View.table");
		}
	}

	/**
	 * 項目コピーによってaBtmRを設定します。
	 *
	 * aBtmRのインスタンスは変更されません。
	 *
	 * @param row BtmR
	 */
	public void setBtmR(mcframe.clientFSBA.FSBAP0380.BtmR row) {
		if (row != null) {
			MCRow.copyall(getBtmR(), row);
		}
	}

	/**
	 * [Btm]ブロックのコンテナaBtmRを返します。
	 *
	 * @return BtmR
	 */
	public mcframe.clientFSBA.FSBAP0380.BtmR getBtmR() {
		return aBtmR;
	}

	/**
	 * aBtmRを作成します。
	 *
	 * @return BtmR
	 */
	public mcframe.clientFSBA.FSBAP0380.BtmR createBtmR() {
		return mcframe.clientFSBA.FSBAP0380.BtmR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getTargetL())) ret.add(getTargetL());
		if(!MCCollectionUtil.contains(ret, getViewL())) ret.add(getViewL());
		if(!MCCollectionUtil.contains(ret, getBtmR())) ret.add(getBtmR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getTargetL()) return "Target";
		if(aCnt == getViewL()) return "View";
		if(aCnt == getBtmR()) return "Btm";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Target")) return getTargetL();
		if(bId.equals("View")) return getViewL();
		if(bId.equals("Btm")) return getBtmR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(TargetPanel);
		ret.add(ViewPanelPanel);
		ret.add(ViewPanel);
		ret.add(BtmPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_VerticalView_H_FW_A() {
		aTargetL = createTargetL();
		aViewL = createViewL();
		aBtmR = createBtmR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_VerticalView_H_FW_A(String name) {
		aTargetL = createTargetL();
		createTargetTable();
		TargetTable.setRowName(name);
		aViewL = createViewL();
		createViewTable();
		ViewTable.setRowName(name);
		aBtmR = createBtmR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_VerticalView_H_FW.jbCreateTarget((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbCreateViewPanel((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbCreateView((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbCreateBtm((FSBAP_VerticalView_H)this);
	}

	/**
	 * [Target]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTarget(FSBAP_VerticalView_H p) {
	}

	/**
	 * [ViewPanel]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateViewPanel(FSBAP_VerticalView_H p) {
	}

	/**
	 * [View]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateView(FSBAP_VerticalView_H p) {
	}

	/**
	 * [Btm]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtm(FSBAP_VerticalView_H p) {
		p.Btm_par_screen_nm_p_PPanel = mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.create();
		p.Btm_par_screen_nm_p_PPanel.setName("Btm.par_screen_nm_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Btm_h_align_type_nm_ListPutter]の定義 */
	private MCListPutter Btm_h_align_type_nm_p = null;

	/**
	 * [Btm_h_align_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getBtm_h_align_type_nm_ListPutter() {
		if (Btm_h_align_type_nm_p == null) {
			Btm_h_align_type_nm_p = createBtm_h_align_type_nm_ListPutter(Btm_h_align_type_nm, "h_align_type_nm", "h_align_type");

		}
		return Btm_h_align_type_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_VerticalView_H create(){
		FSBAP_VerticalView_H p = new FSBAP_VerticalView_H();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_VerticalView_H create(String name){
		FSBAP_VerticalView_H p = new FSBAP_VerticalView_H(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_VerticalView_H_FW.jbfInitTarget((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbfInitViewPanel((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbfInitView((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbfInitBtm((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbInitTarget((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbInitViewPanel((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbInitView((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.jbInitBtm((FSBAP_VerticalView_H)this);
	}

	/**
	 * [Target]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTarget(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.TargetPanel = p.beansFactory.createPanel("Target");
		p.TargetScrollPane = p.beansFactory.createScrollPane("Target.scroll");
		p.createTargetTable();
		// ブロックの項目の初期化
		p.columnTarget_check = p.beansFactory.createTableColumn("Target.check", MCColumnType.CHECK);
		p.columnTarget_pnl_title = p.beansFactory.createTableColumn("Target.pnl_title", MCColumnType.TEXT);
	}

	/**
	 * [ViewPanel]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitViewPanel(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.ViewPanelPanel = p.beansFactory.createPanel("ViewPanel");
		// ブロックの項目の初期化
	}

	/**
	 * [View]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitView(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.ViewPanel = p.beansFactory.createPanel("View");
		p.ViewScrollPane = p.beansFactory.createScrollPane("View.scroll");
		p.createViewTable();
		// ブロックの項目の初期化
		p.columnView_pnl_title = p.beansFactory.createTableColumn("View.pnl_title", MCColumnType.TEXT);
		p.columnView_title = p.beansFactory.createTableColumn("View.title", MCColumnType.TEXT);
		p.columnView_data = p.beansFactory.createTableColumn("View.data", MCColumnType.TEXT);
	}

	/**
	 * [Btm]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtm(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.BtmPanel = p.beansFactory.createPanel("Btm");
		// ブロックの項目の初期化
		p.Btm_input = p.beansFactory.createCheckBox("Btm.input");
		p.Btm_h_align_type = p.beansFactory.createTextField("Btm.h_align_type");
		p.Btm_h_align_type_nm_Label = p.beansFactory.createLabel("Btm.h_align_type_nm_Label");
		p.Btm_h_align_type_nm = p.beansFactory.createTextComboBox("Btm.h_align_type_nm");
		p.Btm_h_align_type_nm.setLabel(p.Btm_h_align_type_nm_Label);
	}

	/**
	 * [Target]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTarget(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.add(p.TargetPanel);
		p.setLastBeans(p.TargetPanel);
		p.TargetPanel.setNextBeans(p.ViewPanelPanel);
		p.TargetPanel.add(p.TargetScrollPane);
		p.TargetPanel.setLastBeans(p.TargetTable);
		p.TargetScrollPane.setViewportView(p.TargetTable);
		p.TargetTable.setList(p.getTargetL());
		p.TargetTable.setStatusColumnVisible(false);
		p.TargetPanel.setValueCheck(false);
		p.TargetPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [ViewPanel]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitViewPanel(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.add(p.ViewPanelPanel);
		p.ViewPanelPanel.setLayoutPosition("CBC+");
		// ブロックの項目の初期化
		p.ViewPanelPanel.add(p.ViewPanel, null);
		p.ViewPanelPanel.setLastBeans(p.ViewPanel);
		p.ViewPanel.setNextBeans(p.BtmPanel);
		p.ViewPanelPanel.add(p.BtmPanel, null);
	}

	/**
	 * [View]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitView(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.ViewPanel.add(p.ViewScrollPane);
		p.ViewPanel.setLastBeans(p.ViewTable);
		p.ViewScrollPane.setViewportView(p.ViewTable);
		p.ViewTable.setList(p.getViewL());
		p.ViewTable.setStatusColumnVisible(false);
		p.ViewPanel.setValueCheck(false);
		p.ViewPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btm]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtm(FSBAP_VerticalView_H p) {
		// ブロック関連の初期化
		p.BtmPanel.setValueCheck(false);
		p.BtmPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.BtmPanel.add(p.Btm_input);
		p.BtmPanel.setLastBeans(p.Btm_input);
		p.Btm_input.setNextBeans(p.Btm_h_align_type);
		p.Btm_input.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0380.BtmR.input_META);
		p.BtmPanel.add(p.Btm_h_align_type);
		p.Btm_h_align_type.setNextBeans(p.Btm_h_align_type_nm);
		p.Btm_h_align_type.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0380.BtmR.h_align_type_META);
		p.Btm_h_align_type_nm.setListType(MCListType.STRICT);
		p.Btm_h_align_type_nm.setLinkBeans(p.Btm_h_align_type);
		p.BtmPanel.add(p.Btm_h_align_type_nm_Label);
		p.BtmPanel.add(p.Btm_h_align_type_nm);
		p.Btm_h_align_type_nm.setNextBeans(p.Btm_par_screen_nm_p_PPanel);
		p.Btm_h_align_type_nm.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0380.BtmR.h_align_type_nm_META);
		p.BtmPanel.add(p.Btm_par_screen_nm_p_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_VerticalView_H_FW.mcInitTarget((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.mcInitViewPanel((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.mcInitView((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.mcInitBtm((FSBAP_VerticalView_H)this);

		// [SRCH]ステータスのモードの設定
		FSBAP_VerticalView_H_FW.statusInitSRCH_Target((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.statusInitSRCH_ViewPanel((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.statusInitSRCH_View((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.statusInitSRCH_Btm((FSBAP_VerticalView_H)this);

	}

	/**
	 *  [Target]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTarget(FSBAP_VerticalView_H p) {
		p.TargetTable.addAllListener(p);
		p.columnTarget_check.addAllListener(p);
		p.columnTarget_pnl_title.addAllListener(p);
		p.columnTarget_pnl_title.setListListener(p);
	}

	/**
	 *  [ViewPanel]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitViewPanel(FSBAP_VerticalView_H p) {
	}

	/**
	 *  [View]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitView(FSBAP_VerticalView_H p) {
		p.ViewTable.addAllListener(p);
		p.columnView_pnl_title.addAllListener(p);
		p.columnView_pnl_title.setListListener(p);
		p.columnView_title.addAllListener(p);
		p.columnView_title.setListListener(p);
		p.columnView_data.addAllListener(p);
		p.columnView_data.setListListener(p);
	}

	/**
	 *  [Btm]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtm(FSBAP_VerticalView_H p) {
		p.Btm_input.addAllListener(p);
		p.Btm_h_align_type.setListListener(p);
		p.Btm_h_align_type.addAllListener(p);
		p.Btm_h_align_type_nm.setListListener(p);
		p.Btm_h_align_type_nm.addAllListener(p);
	}

	/**
	 * [SRCH]ステータスの[Target]ブロックのモードの設定
	 */
	protected static void statusInitSRCH_Target(FSBAP_VerticalView_H p){
		p.columnTarget_check.putMode(p, SRCH, MCMode.REQUIRED);
		p.columnTarget_pnl_title.putMode(p, SRCH, MCMode.READ_ONLY);

	}

	/**
	 * [SRCH]ステータスの[ViewPanel]ブロックのモードの設定
	 */
	protected static void statusInitSRCH_ViewPanel(FSBAP_VerticalView_H p){

	}

	/**
	 * [SRCH]ステータスの[View]ブロックのモードの設定
	 */
	protected static void statusInitSRCH_View(FSBAP_VerticalView_H p){
		p.columnView_pnl_title.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_title.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data.putMode(p, SRCH, MCMode.READ_ONLY);

	}

	/**
	 * [SRCH]ステータスの[Btm]ブロックのモードの設定
	 */
	protected static void statusInitSRCH_Btm(FSBAP_VerticalView_H p){
		p.Btm_input.putMode(p, SRCH, MCMode.REQUIRED);
		p.Btm_h_align_type.putMode(p, SRCH, MCMode.INVISIBLE);
		p.Btm_h_align_type_nm.putMode(p, SRCH, MCMode.ENABLE);
		p.Btm_par_screen_nm_p_PPanel.putStatus(SRCH, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return SRCH;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_VerticalView_H_FW.setTableConfigTarget((FSBAP_VerticalView_H)this);
		FSBAP_VerticalView_H_FW.setTableConfigView((FSBAP_VerticalView_H)this);
	}

	/**
	 * [Target]ブロックのTableの設定
	 */
	protected static void setTableConfigTarget(FSBAP_VerticalView_H p) {
		p.columnTarget_check.setMeta(mcframe.clientFSBA.FSBAP0380.TargetR.check_META);
		p.TargetTable.addColumnConfig(p.columnTarget_check);
		p.columnTarget_pnl_title.setMeta(mcframe.clientFSBA.FSBAP0380.TargetR.pnl_title_META);
		p.TargetTable.addColumnConfig(p.columnTarget_pnl_title);
	}

	/**
	 * [View]ブロックのTableの設定
	 */
	protected static void setTableConfigView(FSBAP_VerticalView_H p) {
		p.columnView_pnl_title.setMeta(mcframe.clientFSBA.FSBAP0380.ViewR.pnl_title_META);
		p.ViewTable.addColumnConfig(p.columnView_pnl_title);
		p.columnView_title.setMeta(mcframe.clientFSBA.FSBAP0380.ViewR.title_META);
		p.ViewTable.addColumnConfig(p.columnView_title);
		p.columnView_data.setMeta(mcframe.clientFSBA.FSBAP0380.ViewR.data_META);
		p.ViewTable.addColumnConfig(p.columnView_data);
		// スクロール固定カラムの指定
		p.ViewTable.setUnscrollColumn(p.columnView_title);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Btm_h_align_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		Btm_h_align_type_nm.getListConfig().setPutter(getBtm_h_align_type_nm_ListPutter());
	}

	/**
	 * この画面を[SRCH]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setSRCHStatus() {
		status = SRCH;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (SRCH.equals(status)) {
			setSRCHStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Btm_h_align_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createBtm_h_align_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.HAlignType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Btm_h_align_type_nm) return getBtm_h_align_type_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == TargetTable) return doTarget_VC(info);
		if (vc == ViewTable) return doView_VC(info);
		if (vc == columnTarget_check) return doTarget_check_VC(info);
		if (vc == columnTarget_pnl_title) return doTarget_pnl_title_VC(info);
		if (vc == columnView_pnl_title) return doView_pnl_title_VC(info);
		if (vc == columnView_title) return doView_title_VC(info);
		if (vc == columnView_data) return doView_data_VC(info);
		if (vc == Btm_input) return doBtm_input_VC(info);
		if (vc == Btm_h_align_type) return doBtm_h_align_type_VC(info);
		if (vc == Btm_h_align_type_nm) return doBtm_h_align_type_nm_VC(info);
		return true;
	}

	/**
	 * [Target]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTarget_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Target]パネルの[check]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTarget_check_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Target]パネルの[pnl_title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTarget_pnl_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[pnl_title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_pnl_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[input]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_input_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[h_align_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_h_align_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_h_align_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == TargetTable) doTarget_NC(info);
		else if (nc == ViewTable) doView_NC(info);
		else if (nc == columnTarget_check) doTarget_check_NC(info);
		else if (nc == columnTarget_pnl_title) doTarget_pnl_title_NC(info);
		else if (nc == columnView_pnl_title) doView_pnl_title_NC(info);
		else if (nc == columnView_title) doView_title_NC(info);
		else if (nc == columnView_data) doView_data_NC(info);
		else if (nc == Btm_input) doBtm_input_NC(info);
		else if (nc == Btm_h_align_type) doBtm_h_align_type_NC(info);
		else if (nc == Btm_h_align_type_nm) doBtm_h_align_type_nm_NC(info);
	}

	/**
	 * [Target]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_NC(MCEventInfo info){
	}

	/**
	 * [View]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NC(MCEventInfo info){
	}

	/**
	 * [Target]パネルの[check]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_check_NC(MCEventInfo info){
	}

	/**
	 * [Target]パネルの[pnl_title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_pnl_title_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[pnl_title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_pnl_title_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[input]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_input_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == TargetTable) doTarget_NE(info);
		else if (ne == ViewTable) doView_NE(info);
		else if (ne == columnTarget_check) doTarget_check_NE(info);
		else if (ne == columnTarget_pnl_title) doTarget_pnl_title_NE(info);
		else if (ne == columnView_pnl_title) doView_pnl_title_NE(info);
		else if (ne == columnView_title) doView_title_NE(info);
		else if (ne == columnView_data) doView_data_NE(info);
		else if (ne == Btm_input) doBtm_input_NE(info);
		else if (ne == Btm_h_align_type) doBtm_h_align_type_NE(info);
		else if (ne == Btm_h_align_type_nm) doBtm_h_align_type_nm_NE(info);
	}

	/**
	 * [Target]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_NE(MCEventInfo info){
	}

	/**
	 * [View]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NE(MCEventInfo info){
	}

	/**
	 * [Target]パネルの[check]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_check_NE(MCEventInfo info){
	}

	/**
	 * [Target]パネルの[pnl_title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_pnl_title_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[pnl_title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_pnl_title_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[input]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_input_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == TargetTable) doTarget_NX(info);
		else if (nx == ViewTable) doView_NX(info);
		else if (nx == columnTarget_check) doTarget_check_NX(info);
		else if (nx == columnTarget_pnl_title) doTarget_pnl_title_NX(info);
		else if (nx == columnView_pnl_title) doView_pnl_title_NX(info);
		else if (nx == columnView_title) doView_title_NX(info);
		else if (nx == columnView_data) doView_data_NX(info);
		else if (nx == Btm_input) doBtm_input_NX(info);
		else if (nx == Btm_h_align_type) doBtm_h_align_type_NX(info);
		else if (nx == Btm_h_align_type_nm) doBtm_h_align_type_nm_NX(info);
	}

	/**
	 * [Target]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_NX(MCEventInfo info){
	}

	/**
	 * [View]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NX(MCEventInfo info){
	}

	/**
	 * [Target]パネルの[check]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_check_NX(MCEventInfo info){
	}

	/**
	 * [Target]パネルの[pnl_title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_pnl_title_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[pnl_title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_pnl_title_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[input]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_input_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnTarget_pnl_title) doTarget_pnl_title_LC(info);
		else if (lc == columnView_pnl_title) doView_pnl_title_LC(info);
		else if (lc == columnView_title) doView_title_LC(info);
		else if (lc == columnView_data) doView_data_LC(info);
		else if (lc == Btm_h_align_type) doBtm_h_align_type_LC(info);
		else if (lc == Btm_h_align_type_nm) doBtm_h_align_type_nm_LC(info);
	}

	/**
	 * [Target]パネルの[pnl_title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTarget_pnl_title_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[pnl_title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_pnl_title_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Btm_h_align_type_nm]の作成メソッド
	 */
	public MCList getBtm_h_align_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getHAlignType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}