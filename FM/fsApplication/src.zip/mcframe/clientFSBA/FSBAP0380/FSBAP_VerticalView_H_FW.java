package mcframe.clientFSBA.FSBAP0380;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0080.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.MenuElement;

import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.popup.MCMenu;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.popup.MCPopupMenu;
import mcframe.clientCore.beans.popup.MCPopupMenuItem;
import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
import mcframe.clientCore.beans.text.MCCalendarFormat;
import mcframe.clientCore.beans.text.MCNumberDocumentBeans;
import mcframe.clientCore.beans.text.MCNumberFormat;
import mcframe.clientCore.container.MCRowEvent;
import mcframe.clientCore.container.MCRowStatusEvent;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.util.MCCollectionUtil;

import mcframe.clientFSBA.FSBAP0370.FSBAP_VerticalView_D;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.commonFS.constant.FSC_H_ALIGN_TYPE;

import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientFXBA.FXBAP0110.FXBAP_RowListener;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_VerticalView_H"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_VerticalView_H_FW extends FSBAP_VerticalView_H_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 縦表示の対象となる画面です。
	 */
	protected FXBAP_PanelBase _target_panel = null;
	
	/**
	 * 縦表示対象のパネルのマップです。
	 */
	protected Map<String, JPanel> _target_panel_map = null;
	
	/**
	 * 縦表示テーブルのリストを格納します。<p>
	 * 全てのパネルのデータを格納します。
	 */
	protected MCList<ViewR> _all_list = createViewL();
	
	/**
	 * 親画面のコンテナに設定するロウリスナです。
	 */
	protected ParRowListener _par_row_listener = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_VerticalView_H_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_VerticalView_H_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * 他画面から呼び出された場合の初期化を実装します。<p>
	 * <li>
	 * 起動タイプ：T1<br>
	 * バインド値：無し<br>
	 * その他の引数：無し
	 * </li>
	 * 
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他の引数
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... param) {
		super.initByScreenParam(openTyp, bind, param);
		
		if (T1.equals(openTyp)) {
			init();
			conv();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}
	
	/**
	 * 画面呼び出し時の初期化処理を実行します。
	 */
	protected void init() {
		initTargetInfo();
		addParRowListener();
	}
	
	/**
	 * 親画面のコンテナにロウリスナとリストリスナを設定します。
	 */
	protected void addParRowListener() {
		FXBAP_RowListener l = getParRowListener();
		
		for (JPanel p : getTargetPanelMap().values()) {
			MCModeBeans[] a = MCBeansUtil.getAllComponents(
					MCModeBeans.class, p);
			for (MCModeBeans c : a) {
				MCRowBeans w;
				if (c instanceof MCRowBeans) {
					w = (MCRowBeans)c;
				}
				else if (c instanceof MCRadioButton) {
					w = ((MCRadioButton)c).getGroup();
				}
				else {
					continue;
				}
				
				MCConstRow o = w.getBaseRow();
				o.removeRowListener(l);
				o.removeRowStatusListener(l);
				o.addRowListener(l);
				o.addRowStatusListener(l);
			}
		}
	}
	
	/**
	 * 親テーブルのコンテナからロウリスナとリストリスナを削除します。<p>
	 * {@link #addParRowListener()} で設定したロウリスナとリストリスナを削除します。
	 */
	protected void removeParRowListener() {
		FXBAP_RowListener l = getParRowListener();
		
		for (JPanel p : getTargetPanelMap().values()) {
			MCModeBeans[] a = MCBeansUtil.getAllComponents(
					MCModeBeans.class, p);
			for (MCModeBeans c : a) {
				MCRowBeans w;
				if (c instanceof MCRowBeans) {
					w = (MCRowBeans)c;
				}
				else if (c instanceof MCRadioButton) {
					w = ((MCRadioButton)c).getGroup();
				}
				else {
					continue;
				}
				
				MCConstRow o = w.getBaseRow();
				o.removeRowListener(l);
				o.removeRowStatusListener(l);				
			}
		}
	}
	
	/**
	 * 縦表示対象のパネルに関する情報を初期化します。
	 */
	protected void initTargetInfo() {
		clearTargetPanelMap();
		
		Map<String, JPanel> pm = getTargetPanelMap();
		MCList<TargetR> tl = createTargetL();
		
		List<MCButtonGroup> gl = new ArrayList<MCButtonGroup>();
		
		List<Object[]> ol = MCBeansUtil.getPanelNameList(getTargetPanel());
		
		for (MCTabOrderBeans c : getTargetPanel().getTabOrderBeans()) {
			if (!(c instanceof MCRowBeans) 
					&& !(c instanceof MCRadioButton)) {
				continue;
			}
			
			if (!(c instanceof MCModeBeans) 
					|| !isTargetBeans((MCModeBeans)c)) {
				continue;
			}

			String n = null;
			MCDataType y = null;
			if (c instanceof MCRowBeans) {
				y = ((MCRowBeans)c).getDataType();
				n = c.getLabelByLocale();
				if (isNull(n)) {
					n = c.getMessageByLocale();
				}
			}
			else if (c instanceof MCRadioButton) {
				MCButtonGroup g = ((MCRadioButton)c).getGroup();
				if (gl.contains(g)) {
					continue;
				}
				gl.add(g);
				
				y = g.getDataType();
				
				StringBuilder sb = new StringBuilder();
				String nd = MCConst.app.getString(MCConst.createKey(
						getModuleID(), getScreenID(), "BTN_GRP_NM_DLM"));
				
				for (MCRadioButton u : g.getRadioButtons()) {
					if (u.getModeInfo().getStatus() 
							!= MCMode.INVISIBLE_STATUS) {
						if (sb.length() != 0) {
							sb.append(nd);
						}
						sb.append(u.getLabelByLocale());
					}
				}

				n = sb.toString();
			}

			Object[] a = null;
			for (Object[] o : ol) {
				if (o[0] == c) {
					a = o;
					ol.remove(o);
					break;
				}
			}
			if (a != null) {
				JPanel p = (JPanel)a[1];
				String pn = null;
				for (Map.Entry<String, JPanel> e : pm.entrySet()) {
					if (p == e.getValue()) {
						pn = e.getKey();
						break;
					}
				}
				if (pn == null) {
					if (p instanceof MCPanel) {
						pn = getBaseFieldName((MCPanel)p);
					}
					else if (p instanceof MCRootPanel) {
						pn = getBaseFieldName((MCRootPanel)p);
					}
					else {
						continue;
					}
					
					TargetR o = tl.createRow();
					o.check(true);
					
					while (true) {
						MCList<TargetR> sl = tl.subList(TargetR.$pnl_nm, pn);
						if (sl.size() == 0) {
							break;
						}
						pn = pn + "_";
					}
					
					o.pnl_nm(pn);
					o.pnl_title((String)a[2]);
					tl.add(o);
					pm.put(pn, p);
				}
				
				ViewR vo = _all_list.createRow();
				vo.pnl_title((String)a[2]);
				vo.title(n);
				vo.dat_typ(y.name());
				vo.par_pnl_nm(pn);
				vo.par_field_nm(getBaseFieldName(c));

				_all_list.add(vo);
			}
		}		
		setTargetL(tl);
	}
	
	/**
	 * GUI 部品が縦表示対象になりうる場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return GUI 部品が縦表示対象になり得ない場合は false
	 */
	protected boolean isTargetBeans(MCModeBeans compo) {
		if (compo.getModeInfo().getStatus() == MCMode.INVISIBLE_STATUS) {
			return false;
		}
		
		if (!(compo instanceof Component)) {
			return false;
		}

		Component c = (Component)compo;

		while (c != null) {
			if (c instanceof MCRootPanel
					&& !(((MCRootPanel) c).isPartsPanel())) {
				break;
			}
			
			Component p = c.getParent();
			
			if (!c.isVisible()) {
				if (p instanceof MCTabbedPane) {
					MCTabbedPane tp = (MCTabbedPane) p;
					if (!tp.isVisible()) {
						return false;
					}
					int i = tp.indexOfComponent(c);
					if (i != -1 && tp.isEnabledAt(i)) {
						c = p;
						continue;
					}
				}
				return false;
			}
			
			c = p;
		}
		
		return true;	
	}
	
	/**
	 * 縦横変換処理を実行します。
	 */
	protected void conv() {
		beforeConv();
		doConv();
	}
	
	/**
	 * 縦横変換の前処理を実行します。
	 */
	protected void beforeConv() {
		// クリア
		getViewL().clear();
		
		// モードの初期設定
		setSRCHStatus();
	}
	
	/**
	 * 縦横変換処理を実行します。
	 */
	protected void doConv() {
		MCList<ViewR> l = createViewL();

		List<MCRow> vl = new ArrayList<MCRow>();
		
		for (TargetR g : getTargetL()) {
			if (!g.check()) {
				continue;
			}
			JPanel p = getTargetPanel(g.pnl_nm());
			MCList<ViewR> pl = _all_list.subList(
					ViewR.$par_pnl_nm, g.pnl_nm());
			
			for (ViewR o : pl) {
				ViewR no = l.createRow();
				no.title(o.title());
				no.par_field_nm(o.par_field_nm());
				no.par_pnl_nm(o.par_pnl_nm());
				no.dat_typ(o.dat_typ());
				
				MCModeBeans c = getTargetBeans(p, o.par_field_nm());
				if (c.getModeInfo().getStatus() == MCMode.INVISIBLE_STATUS) {
					continue;
				}
				
				if (c instanceof MCRowBeans) {
					MCRowBeans w = (MCRowBeans)c;
					String v = toViewData(w.getRowValue(), w);
					o.data(v);
					MCRow wo = w.getBaseRow();
					if (!vl.contains(wo)) {
						vl.add(wo);
					}
				}
				else if (c instanceof MCRadioButton) {
					MCRadioButton r = (MCRadioButton)c;
					MCButtonGroup u = r.getGroup();
					String v = toViewData(u.getRowValue(), u);
					o.data(v);
					MCRow wo = u.getBaseRow();
					if (!vl.contains(wo)) {
						vl.add(wo);
					}
				}
				l.add(o);
			}
		}

		Status s = MCRow.NONE;
		for (MCRow w : vl) {
			if (w.isStatusModify()) {
				s = MCRow.MODIFY;
				break;
			}
		}
		columnView_data.setHeaderBackground(
				getStatusCellBackground(s));
		columnView_data.setHeaderForeground(
				getStatusCellForeground(s));

		setViewL(l);
	}
		
	protected String toViewData(Comparable<?> p_val, MCRowBeans parent) {
		boolean input = (((MCModeBeans)parent).getModeInfo().getStatus() 
				== MCMode.ENABLE_STATUS) ? getBtmR().input() : false;
		MCDataType py = parent.getDataType();
		if (py == null) {
			return null;
		}
		
		switch (py) {
			case STRING:
				if (parent instanceof MCPasswordField) {
					return null;
				}
				if (parent instanceof MCButtonGroup) {
					MCButtonGroup g = (MCButtonGroup)parent;
					for (MCRadioButton o : g.getRadioButtons()) {
						if (MCStringUtil.eq(
								o.getActionCommand(), (String)p_val)) {
							return o.getLabelByLocale();
						}
					}
					return null;
				}
				return (String) p_val;
			case NUMBER:
				if (parent instanceof MCNumberDocumentBeans) {
					MCNumberDocumentBeans nc = (MCNumberDocumentBeans)parent;
					MCNumberFormat nf = nc.getNumberFormat();
					int ns = nc.getScale();
					return input ? nf.doInputFormat((MCNumber) p_val, ns) 
							: nf.doOutputFormat((MCNumber) p_val, ns);
				}
				return null;
			case DATE:
			case TIMESTAMP:
				if (parent instanceof MCCalendarDocumentBeans<?>) {
					MCCalendarDocumentBeans<?> dc = (MCCalendarDocumentBeans<?>)parent;
					MCCalendarFormat<?> df = dc.getCalendarFormat();
					
					if (p_val != null) {
						String dp = input 
								? df.getInputPattern() : df.getOutputPattern();
						return ((MCCalendarDate<?>)p_val).toString(dp);
					}
					return input ? null : df.getOutputBlank();
				}
				return null;
			case BOOLEAN:
				return convBooleanToString((Boolean)p_val);
//				return String.valueOf(p_val);
			default:
				return null;
		}
	}
	
	protected Comparable<?> toParData(String v_val, MCRowBeans parent) {
		MCDataType py = parent.getDataType();
		if (py == null) {
			return null;
		}
		switch (py) {
			case STRING:
				if (v_val == null) {
					return null;
				}
				if (parent instanceof MCButtonGroup) {
					MCButtonGroup g = (MCButtonGroup)parent;
					for (MCRadioButton o : g.getRadioButtons()) {
						if (MCStringUtil.eq(v_val, o.getLabelByLocale())) {
							return o.getActionCommand();
						}
					}
				}
				return v_val;
			case NUMBER:
				if (v_val == null) {
					return null;
				}
				return MCNumber.valueOf(v_val);
			case DATE:
				if (v_val == null) {
					return null;
				}
				if (parent instanceof MCCalendarDocumentBeans<?>) {
					MCCalendarDocumentBeans<?> dc = (MCCalendarDocumentBeans<?>)parent;
					MCCalendarFormat<?> df = dc.getCalendarFormat();
					return df.doInputParse(v_val);
//					return MCDate.valueOf(v_val, df.getInputPattern());
				}
				return null;
			case TIMESTAMP:
				if (v_val == null) {
					return null;
				}
				if (parent instanceof MCCalendarDocumentBeans<?>) {
					MCCalendarDocumentBeans<?> dc = (MCCalendarDocumentBeans<?>)parent;
					MCCalendarFormat<?> df = dc.getCalendarFormat();
					return df.doInputParse(v_val);
//					return MCTimestamp.valueOf(v_val, df.getInputPattern());
				}
				return null;
			case BOOLEAN:
				return convStringToBoolean(v_val);
//				return Boolean.valueOf(v_val).booleanValue();
			default:
				return null;
		}
	}
	
	@Override
	protected void tableInit() {
		super.tableInit();
		
		ViewTable.setSortable(false);
		ViewTable.setReorderingAllowed(false);
		
		// トリムの設定は親画面に任せるため本画面では全てオフにする
		for (MCColumnConfig conf : ViewTable.getColumnConfigs()) {
			conf.setTrimPattern(MCBeansConsts.TRIM_NONE);
		}
	}

	/**
	 * 縦表示の対象となりうるパネルのマップを返します。
	 * 
	 * @return 縦表示の対象となりうるパネルのマップ
	 */
	protected Map<String, JPanel> getTargetPanelMap() {
		return _target_panel_map != null 
				? _target_panel_map 
				: (_target_panel_map = new LinkedHashMap<String, JPanel>());
	}
	
	protected void clearTargetPanelMap() {
		_target_panel_map = null;
	}
	
	protected String getBaseFieldName(MCBeans compo) {
		if (compo instanceof MCRowBeans) {
			return ((MCRowBeans)compo).getBaseRowColumnName();
		}
		else if (compo instanceof MCRadioButton) {
			return ((MCRadioButton)compo).getGroup().getBaseRowColumnName();
		}
		List<String> l = new ArrayList<String>();
		l.add(compo.getName());
		MCRootPanel p = compo.getRootPanel();
		while (p != null && p.isPartsPanel()) {
			l.add(p.getName());
			p = p.getUnderPanel();
		}
		String[] a = l.toArray(new String[l.size()]);
		MCCollectionUtil.reverse(a);
		return MCStringUtil.join(".", a);
	}
	
	protected JPanel getTargetPanel(String name) {
		return getTargetPanelMap().get(name);
	}
	
	protected MCModeBeans getTargetBeans(JPanel panel, String name) {
		MCModeBeans[] a = MCBeansUtil.getAllComponents(MCModeBeans.class, panel);
		for (MCModeBeans c : a) {
			if (MCStringUtil.eq(name, getBaseFieldName(c))) {
				return c;
			}
		}
		return null;
	}
	
	@Override
	public void openISPanel(MCLinkBeans compo, int eventIndex) {
		// 親テーブルのセルの入力補助を起動する
		ViewR vo = getViewL().get(eventIndex);
		
		JPanel pp = getTargetPanel(vo.par_pnl_nm());
		MCModeBeans pc = getTargetBeans(pp, vo.par_field_nm());
		if (pc instanceof MCLinkBeans) {
			((FXBAP_PanelBase)pc.getRootPanel()).openISPanel(
					(MCLinkBeans)pc, -1);
		}
	}
	
	@Override
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		
		if (getBtmR().input() 
				&& isDataColumn(info.getComponent())) {
			setFocusToParentField(info);
		}
	}

	@Override
	public void doTarget_check_NC(MCEventInfo info) {
		super.doTarget_check_NC(info);
		
		conv();
	}

	@Override
	public void doBtm_input_NC(MCEventInfo info) {
		super.doBtm_input_NC(info);
		
		conv();
	}
	
	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		
		if (isDataColumn(vc)) {
			return setValToParField(info);
		}
		
		return true;
	}
	
	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		
		if (isDataColumn(nc)) {
			int idx = info.getEventIndex();
			MCColumnConfig vc = (MCColumnConfig)info.getComponent();
			ViewR vo = getViewL().get(idx);
			
			JPanel pp = getTargetPanel(vo.par_pnl_nm());
			MCModeBeans pmc = getTargetBeans(pp, vo.par_field_nm());
			if (pmc instanceof MCRowBeans) {
				MCRowBeans pc = (MCRowBeans)pmc;
				MCDataType py = pc.getDataType();
				if (MCDataType.BOOLEAN.equals(py)) {
					MCRow po = pc.getBaseRow();
					Boolean pv = po.getBoolean(pc.getBaseRowColumnName());
					if (!isSame(pv.booleanValue(), 
							convStringToBoolean((String)info.getNewValue()))) {
//					if (!isSame(pv.toString(), (String)info.getNewValue())) {
						getViewL().get(idx).setString(
								vc.getBaseRowColumnName(), pv.toString());
					}
				}
			}
			
		}
	}
	
	@Override
	public void doDCEvent(MCDCBeans dc, MCEventInfo info) {
		super.doDCEvent(dc, info);
		
		if (isDataColumn(dc)) {
			openISPanel((MCColumnConfig)dc, info.getEventIndex());
			doViewTable_DC(dc, info);
		}
		else if (dc == ViewTable) {
			doViewTable_DC(dc, info);
		}
	}

	/**
	 * 縦表示テーブルをダブルクリックしたときの処理を実行します。
	 * 
	 * @param dc GUI 部品
	 * @param info イベント情報
	 */
	public void doViewTable_DC(MCDCBeans dc, MCEventInfo info) {
		// 編集不可の場合
		if (isDataColumn(info.getClickColumn())) {
			// 親テーブルのセルにフォーカスを移動する
			setFocusToParentField(info);
			// 画面を閉じる
			closeView();
		}
		// 編集可能な場合
		else if (isDataColumn(info.getComponent())) {
			// 親テーブルのセルにフォーカスを移動する
			setFocusToParentField(info);
		}
	}
	
	/**
	 * 親画面の GUI 部品にフォーカスを移動します。
	 * 
	 * @param info イベント情報
	 */
	protected void setFocusToParentField(MCEventInfo info) {
		if (info.getEventIndex() < 0) {
			return;
		}
		
		ViewR vo = getViewL().get(info.getEventIndex());
		JPanel pp = getTargetPanel(vo.par_pnl_nm());
		MCModeBeans pc = getTargetBeans(pp, vo.par_field_nm());
		if (pc instanceof MCRowBeans) {
//			MCRowBeans c = (MCRowBeans)pc;
			if (pc instanceof Component) {
				doFocus((Component)pc);
			}
//			getTargetPanel().setFocus(
//					c.getBaseRow(), c.getBaseRowColumnName());
		}
		else if (pc instanceof MCRadioButton) {
			MCRadioButton c = (MCRadioButton)pc;
			MCButtonGroup g = c.getGroup();
			MCRadioButton s = g.getSelectedButton();
			if (s.getModeInfo().getStatus() == MCMode.ENABLE_STATUS) {
				doFocus(s);
			}
			else {
				for (MCRadioButton o : g.getRadioButtons()) {
					if (o.getModeInfo().getStatus() == MCMode.ENABLE_STATUS) {
						doFocus(o);
						break;
					}
				}
			}
		}
	}
	
	protected void doFocus(Component compo) {
		if (compo instanceof MCModeBeans) {
			if (((MCModeBeans)compo).getModeInfo().getStatus() 
					!= MCMode.ENABLE_STATUS) {
				return;
			}
		}
		
		List<Object[]> l = new ArrayList<Object[]>();
		
		Component c = compo;
		while (c != null) {
			Component p = c.getParent();
			if (p instanceof MCTabbedPane) {
				l.add(new Object[] {
						p, Integer.valueOf(
								((MCTabbedPane)p).indexOfComponent(c))
				});
			}
			c = p;
		}
		
		Object[][] a = l.toArray(new Object[l.size()][]);
		MCCollectionUtil.reverse(a);
		for (Object[] o : a) {
			MCTabbedPane tp = (MCTabbedPane)o[0];
			int i = ((Integer)o[1]).intValue();
			if (!tp.isEnabledAt(i)) {
				return;
			}
		}
		for (Object[] o : a) {
			MCTabbedPane tp = (MCTabbedPane)o[0];
			int i = ((Integer)o[1]).intValue();
			tp.requestFocus();
			tp.setSelectedIndex(i);
		}
		compo.requestFocus();
	}

	/**
	 * 画面を閉じます。
	 */
	protected void closeView() {
		// 親画面を前面に出して自身を閉じる
		getTargetPanel().moveToFront();
		requestCloseWindow();
	}

	/**
	 * 指定された項目がタイトルカラムの場合は true を返します。
	 * 
	 * @param compo 画面項目
	 * @return 指定された項目がタイトルカラムではない場合は false
	 */
	protected boolean isTitleColumn(MCBeans compo) {
		return compo == columnView_pnl_title || compo == columnView_title;
	}

	/**
	 * 指定された項目がデータ表示用カラムの場合は true を返します。
	 * 
	 * @param compo 画面項目
	 * @return 指定された項目がデータ表示用カラムではない場合は false
	 */
	protected boolean isDataColumn(MCBeans compo) {
		return compo == columnView_data;
	}
	
	protected boolean setValToParField(MCEventInfo info) {
		int idx = info.getEventIndex();
		ViewR vo = getViewL().get(idx);
		
		JPanel pp = getTargetPanel(vo.par_pnl_nm());
		MCModeBeans pc = getTargetBeans(pp, vo.par_field_nm());
		try {
			if (pc instanceof MCRowBeans) {
				MCRowBeans c = (MCRowBeans)pc;
				Comparable<?> pv = toParData((String)info.getNewValue(), c);
				getTargetPanel().setFocus(
						c.getBaseRow(), c.getBaseRowColumnName());
				setValueEx(c, pv);
			}
			else if (pc instanceof MCRadioButton) {
				MCRadioButton c = (MCRadioButton)pc;
				MCButtonGroup g = c.getGroup();
				Comparable<?> pv = toParData((String)info.getNewValue(), g);
				if (pv != null) {
					for (MCRadioButton u : g.getRadioButtons()) {
						if (pv.equals(u.getActionCommand())) {
							if (u.getModeInfo().getStatus() 
									!= MCMode.ENABLE_STATUS) {
								return false;
							}
							u.mcRequestFocus();
							setValueEx(g, pv);
							break;
						}
					}
					c.mcRequestFocus();
					setValueEx(g, pv);
				}
				else {
					return false;
				}
			}
		}
		catch (MCException e) {
			return false;
		}
		return true;
	}

	/**
	 * 親画面の GUI 部品に対応する縦表示テーブルの行を取得します。
	 * 
	 * @param p_bo_col_nm 親画面の GUI 部品の {@link MCRowBeans#getBaseRowColumnName()}
	 * @return 縦表示テーブルの行
	 */
	protected ViewR getViewRow(MCRow p_row, String p_bo_col_nm) {
		for (JPanel p : getTargetPanelMap().values()) {
			MCModeBeans[] a = MCBeansUtil.getAllComponents(MCModeBeans.class, p);
			for (MCModeBeans c : a) {
				MCRowBeans o;
				if (c instanceof MCRowBeans) {
					o = (MCRowBeans)c;
				}
				else if (c instanceof MCRadioButton) {
					o = ((MCRadioButton)c).getGroup();
				}
				else {
					continue;
				}
				if (p_row == o.getBaseRow() 
						&& MCStringUtil.eq(p_bo_col_nm, o.getBaseRowColumnName())) {
					return getViewRow(p, p_bo_col_nm);
				}
			}
		}
		return null;
	}

	protected ViewR getViewRow(JPanel p_pnl, String p_bo_col_nm) {
		String pn;
		if (p_pnl instanceof MCPanel) {
			pn = getBaseFieldName((MCPanel)p_pnl);
		}
		else if (p_pnl instanceof MCRootPanel) {
			pn = getBaseFieldName((MCRootPanel)p_pnl);
		}
		else {
			return null;
		}
		String[] na = new String[] {
				ViewR.$par_pnl_nm, ViewR.$par_field_nm
		};
		Comparable<?>[] va = new Comparable<?>[] {
				pn, p_bo_col_nm
		};
		return getViewL().subList(na, va).getFirst(
				ViewR.$par_field_nm, p_bo_col_nm);	
	}
	
	/**
	 * 親画面の GUI 部品のデータを縦表示テーブルに反映します。
	 *
	 * @param p_pnl 親画面のパネル
	 * @param parent 親画面の GUI 部品
	 */
	protected void convByParField(JPanel p_pnl, MCRowBeans parent) {
		ViewR vo = getViewRow(p_pnl, parent.getBaseRowColumnName());
		String v = toViewData(parent.getRowValue(), parent);
		setValueInConv(vo.getGUIIndex(), v);
	}

	/**
	 * 縦表示テーブルに値を設定します。縦横変換処理で使用します。
	 * 
	 * @param index 行番号
	 * @param value 値
	 */
	protected void setValueInConv(int index, String value) {
		getViewL().get(index).data(value);
	}
	
	/**
	 * 縦表示テーブルのステータスカラムの背景色を返します。
	 *
	 * @param status ステータス
	 * @return 縦表示テーブルのステータスカラムの背景色
	 */
	protected Color getStatusCellBackground(Status status) {
		FXBAP_CellConfig vf = (FXBAP_CellConfig)ViewTable.getCellConfig();
		return vf.getStatusColumnBackground(
				0, ViewTable.getStatusColumn(), ViewTable, false, status);
	}
	
	/**
	 * 縦表示テーブルのステータスカラムの文字の色を返します。
	 *
	 * @param status ステータス
	 * @return 縦表示テーブルのステータスカラムの文字の色
	 */
	protected Color getStatusCellForeground(Status status) {
		FXBAP_CellConfig vf = (FXBAP_CellConfig)ViewTable.getCellConfig();
		return vf.getStatusColumnForeground(
				0, ViewTable.getStatusColumn(), ViewTable, false, status);
	}
	
	@Override
	public boolean screenClear() {
		// 画面クリアを無効にする
		return false;
	}
	
	@Override
	public boolean beforeClose() {
		if (!super.beforeClose()) {
			return false;
		}
		
		removeParRowListener();
		return true;
	}
	
	/**
	 * 縦表示の対象となる画面を返します。
	 *
	 * @return 縦表示の対象となる画面
	 */
	protected FXBAP_PanelBase getTargetPanel() {
		if (_target_panel != null) {
			return _target_panel;
		}
		
		MCRootPanel p = getParentPanel();
		if (p == null || !(p instanceof FXBAP_PanelBase)) {
			throw new MCAppException(FSBAC0058);
		}
		return (_target_panel = (FXBAP_PanelBase)p);
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();
		
		ViewTable.setCellConfig(createViewTableCellConfig());
	}
	
	/**
	 * 縦表示テーブルに設定するセルコンフィグを作成します。
	 * 
	 * @return セルコンフィグ
	 */
	protected MCCellConfig createViewTableCellConfig() {
		return new ViewTableCellConfig();
	}

	/**
	 * 縦表示テーブルに設定するセルコンフィグです。
	 */
	protected class ViewTableCellConfig extends FXBAP_CellConfig {
		
		@Override
		public Color getPriorFG(
				int index, MCColumnConfig column, MCTable table, MCMode mode) {
			// タイトル列
			if (isTitleColumn(column)) {
				return column.getHeaderForeground();
			}
			return super.getPriorFG(index, column, table, mode);
		}
		
		@Override
		public Color getPriorBG(
				int index, MCColumnConfig column, MCTable table, MCMode mode) {
			// タイトル列
			if (isTitleColumn(column)) {
				return column.getHeaderBackground();
			}
			return super.getPriorBG(index, column, table, mode);
		}
		
		@Override
		public MCMode getPriorMode(
				int index, MCColumnConfig column, MCTable table) {
			// 入力モードではない場合は入力不可
			if (!getBtmR().input()) {
				return super.getPriorMode(index, column, table);
			}
			// タイトル列
			if (isTitleColumn(column)) {
				return super.getPriorMode(index, column, table);
			}

			ViewR vo = getViewL().get(index);
			JPanel pp = getTargetPanel(vo.par_pnl_nm());
			MCModeBeans pc = getTargetBeans(pp, vo.par_field_nm());
			if (pc instanceof MCPasswordField 
					|| pc instanceof MCImageView) {
				return super.getPriorMode(index, column, table);
			}
			else if (pc instanceof MCRowBeans) {
				if (!isTargetBeans(pc)) {
					return super.getPriorMode(index, column, table);
				}
				return pc.getMode();
			}
			else if (pc instanceof MCRadioButton) {
				if (!isTargetBeans(pc)) {
					return super.getPriorMode(index, column, table);
				}
				return pc.getMode();
			}
			return super.getPriorMode(index, column, table);
		}
	}
	
	/**
	 * 親テーブルのコンテナに設定するロウリスナを返します。
	 *
	 * @return ロウリスナ
	 */
	protected FXBAP_RowListener getParRowListener() {
		return _par_row_listener != null 
				? _par_row_listener 
				: (_par_row_listener = new ParRowListener());
	}

	/**
	 * 親テーブルのコンテナに設定するロウリスナです。
	 */
	protected class ParRowListener extends FXBAP_RowListener {
		
		@Override
		public void valueChanged(MCRowEvent event) {
			super.valueChanged(event);
			
			// イベントが発生した値を縦表示テーブルに反映する
			ViewR o = getViewRow(event.getSourceRow(), event.getColumn());
			if (o == null) {
				return;
			}

			JPanel pp = getTargetPanel(o.par_pnl_nm());
			MCModeBeans pc = getTargetBeans(pp, o.par_field_nm());
			if (pc instanceof MCRowBeans) {
				convByParField(pp, (MCRowBeans)pc);
			}
			else if (pc instanceof MCRadioButton) {
				convByParField(pp, ((MCRadioButton)pc).getGroup());
			}
		}
		
		@Override
		public void statusChanged(MCRowStatusEvent event) {
			super.statusChanged(event);

			columnView_data.setHeaderBackground(
					getStatusCellBackground(event.getNewStatus()));
			columnView_data.setHeaderForeground(
					getStatusCellForeground(event.getNewStatus()));
		}
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		return new VerticalViewPopupConfig();
	}

	/**
	 * 縦表示テーブルに設定するポップアップコンフィグです。
	 */
	protected class VerticalViewPopupConfig extends FSUCP_PopupConfig {

		/**
		 * コンストラクタです。
		 */
		public VerticalViewPopupConfig() {
			super(null);
		}
		
		@Override
		protected void customPopup(MCPopupMenu menu, MCTable table) {
			super.customPopup(menu, table);
			
			MCRootPanel pp = getTargetPanel();
			MCPopupMenu pm = pp.configurePopup();
			MenuElement[] pse = pm.getSubElements();
			
			// 親テーブルのファイル入出力の設定に合わせてポップアップ表示を調整する
			if (!isVisible(pse, pp.getFileIOMenu())) {
				menu.removeMenu(table.getFileIOMenu());
			}
			else {
				if (!isVisible(pse, pp.getExcelOutMenuItem())) {
					menu.removeMenuItem(table.getExcelOutMenuItem());
				}
				if (!isVisible(pse, pp.getExcelOutMenuItem())) {
					menu.removeMenuItem(table.getExcelOutSelectMenuItem());
				}
				if (!isVisible(pse, pp.getExcelOpenMenuItem())) {
					menu.removeMenuItem(table.getExcelOpenMenuItem());
				}
				if (!isVisible(pse, pp.getExcelOpenMenuItem())) {
					menu.removeMenuItem(table.getExcelOpenSelectMenuItem());
				}
				if (!isVisible(pse, pp.getCSVOutMenuItem())) {
					menu.removeMenuItem(table.getCSVOutMenuItem());
				}
				if (!isVisible(pse, pp.getCSVOutMenuItem())) {
					menu.removeMenuItem(table.getCSVOutSelectMenuItem());
				}
			}
		}
		
		@Override
		protected boolean ignorePanelFileIO() {
			return true;
		}

		@Override
		protected boolean ignorePanelVerticalView(MCRootPanel pnl) {
			return true;
		}

		@Override
		protected boolean ignoreTableVerticalView(MCTable<?> tbl) {
			return true;
		}

		@Override
		protected boolean ignoreSortOrder() {
			return true;
		}

		@Override
		protected boolean ignoreTableSort() {
			return true;
		}

		@Override
		protected boolean ignoreRowFilter() {
			return true;
		}

		@Override
		protected boolean ignoreSrchCnd(MCRootPanel panel) {
			return true;
		}

		@Override
		protected boolean ignoreSumInfo() {
			return true;
		}

		@Override
		protected boolean ignoreColumnWidth() {
			return true;
		}

	}
	
	/**
	 * itm に指定されたオブジェクトを elms が含み、かつ表示されているかどうかをチェックする
	 * 
	 * @param elms メニューの構成要素の配列
	 * @param itm メニューの構成要素
	 * @return itm が elms に含まれ、かつ表示されている場合はtrue
	 */
	protected boolean isVisible(MenuElement[] elms, Object itm) {
		if (contains(elms, itm)) {
			if (itm instanceof MCPopupMenuItem) {
				return ((MCPopupMenuItem)itm).isVisible();
			}
			if (itm instanceof MCMenu) {
				return ((MCMenu)itm).isVisible();
			}
		}
		return false;
	}
	
	/**
	 * itm に指定されたオブジェクトを elms が含むかどうかをチェックする
	 * 
	 * @param elms メニューの構成要素の配列
	 * @param itm メニューの構成要素
	 * @return itm が elms に含まれる場合はtrue
	 */
	protected boolean contains(MenuElement[] elms, Object itm) {
		if (elms == null) {
			return false;
		}
		
		for (MenuElement elm : elms) {
			if (elm == itm) {
				return true;
			}
			else if (elm instanceof JPopupMenu) {
				if (contains(((JPopupMenu)elm).getSubElements(), itm)) {
					return true;
				}
			}
			else if (elm instanceof JMenu) {
				if (contains(((JMenu)elm).getSubElements(), itm)) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	protected void listInit() {
		super.listInit();
		
		Btm_h_align_type_nm.setListVisibleColumn(BtmR.$h_align_type_nm);
	}

	@Override
	public void doBtm_h_align_type_LC(MCEventInfo info) {
		super.doBtm_h_align_type_LC(info);

		int ha = MCColumnConfig.LEFT;
		String v = getBtmR().h_align_type();
		if (FSC_H_ALIGN_TYPE.isTYPE_LEFT(v)) {
			ha = MCColumnConfig.LEFT;
		}
		else if (FSC_H_ALIGN_TYPE.isTYPE_CENTER(v)) {
			ha = MCColumnConfig.CENTER;
		}
		else if (FSC_H_ALIGN_TYPE.isTYPE_RIGHT(v)) {
			ha = MCColumnConfig.RIGHT;
		}
		
		for (MCColumnConfig c : ViewTable.getViewColumnConfigs()) {
			if (isDataColumn(c)) {
				c.setHorizontalAlignment(ha);
			}
		}
	}

	/**
	 * チェックボックスの値の表現方法を返します。
	 *
	 * @return チェックボックスの値の表現方法
	 */
	protected int getBooleanType() {
		String pfx = "BooleanType";
		for (String[] msa : getModuleAndScreenIDs()) {
			String k = MCConst.createKey(msa[0], msa[1], pfx);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getInteger(k, 
						FSBAP_VerticalView_D.BOOLEAN_TYPE_1_0);
			}
		}
		return FSBAP_VerticalView_D.BOOLEAN_TYPE_1_0;
	}

	/**
	 * チェックボックス項目の値を String から boolean に変換します。
	 *
	 * @param value チェックボックス項目の値（String）
	 * @return チェックボックス項目の値（boolean）
	 */
	protected boolean convStringToBoolean(String value) {
		switch (getBooleanType()) {
			case FSBAP_VerticalView_D.BOOLEAN_TYPE_TRUE_FALSE:
				return Boolean.TRUE.toString().equals(value);
			default:
				return "1".equals(value);
		}
	}
	
	/**
	 * チェックボックス項目の値を boolean から String に変換します。
	 * 
	 * @param value チェックボックス項目の値（boolean）
	 * @return チェックボックス項目の値（String）
	 */
	protected String convBooleanToString(boolean value) {
		switch (getBooleanType()) {
			case FSBAP_VerticalView_D.BOOLEAN_TYPE_TRUE_FALSE:
				return Boolean.toString(value);
			default:
				return value ? "1" : "0";
		}
	}

}