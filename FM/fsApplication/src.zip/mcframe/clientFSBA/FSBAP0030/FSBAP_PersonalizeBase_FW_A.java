package mcframe.clientFSBA.FSBAP0030;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_PersonalizeBase"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_PersonalizeBase_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0030";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Setting]ブロック関連のField定義
	public MCPanel SettingPanel = null;
	// [Setting]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H Setting_setting_PPanel;
	// [ListPanel]ブロック関連のField定義
	public MCPanel ListPanelPanel = null;
	// [ListPanel]ブロックの項目のField定義
	// [ListDtl]ブロック関連のField定義
	public MCPanel ListDtlPanel = null;
	public MCScrollPane ListDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0030.ListDtlR> ListDtlTable = null;
	// [ListDtl]ブロックの項目のField定義
	/**
	 *  初期設定.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_flg = null;
	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_setting_unit_type = null;
	/**
	 *  設定単位名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_setting_unit_type_nm = null;
	/**
	 *  設定情報ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_setting_info_id = null;
	/**
	 *  設定情報名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_setting_info_nm = null;
	/**
	 *  備考.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_remark = null;
	// [ListDtlBtn]ブロック関連のField定義
	public MCPanel ListDtlBtnPanel = null;
	// [ListDtlBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton ListDtlBtn_radd = null;
	/**
	 *  行コピー.<p>
	 *
	 */
	public MCButton ListDtlBtn_rcopy = null;
	/**
	 *  現在の状態を表示.<p>
	 *
	 */
	public MCButton ListDtlBtn_load = null;
	/**
	 *  適用する.<p>
	 *
	 */
	public MCButton ListDtlBtn_apply = null;
	/**
	 *  適用後閉じる.<p>
	 *
	 */
	public MCButton ListDtlBtn_apply_close = null;
	/**
	 *  削除する.<p>
	 *
	 */
	public MCButton ListDtlBtn_del = null;
	// [ListDtlEastBtn]ブロック関連のField定義
	public MCPanel ListDtlEastBtnPanel = null;
	// [ListDtlEastBtn]ブロックの項目のField定義
	// [InfoPanel]ブロック関連のField定義
	public MCPanel InfoPanelPanel = null;
	// [InfoPanel]ブロックの項目のField定義
	// [Info]ブロック関連のField定義
	public MCPanel InfoPanel = null;
	// [Info]ブロックの項目のField定義
	// [ListHdr]ブロック関連のField定義
	public MCPanel ListHdrPanel = null;
	// [ListHdr]ブロックの項目のField定義
	/**
	 *  初期設定.<p>
	 *
	 */
	public MCCheckBox ListHdr_init_flg = null;
	public MCLabel ListHdr_setting_info_nm_Label = null;
	/**
	 *  設定情報名.<p>
	 *
	 */
	public MCTextField ListHdr_setting_info_nm = null;
	public MCLabel ListHdr_remark_Label = null;
	/**
	 *  備考.<p>
	 *
	 */
	public MCTextField ListHdr_remark = null;
	// [ListBtn]ブロック関連のField定義
	public MCPanel ListBtnPanel = null;
	// [ListBtn]ブロックの項目のField定義
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton ListBtn_upd = null;
	/**
	 *  更新する（会社共通）.<p>
	 *
	 */
	public MCButton ListBtn_upd_ext = null;
	/**
	 *  更新する（システム共通）.<p>
	 *
	 */
	public MCButton ListBtn_upd_sys = null;
	/**
	 *  更新後適用する.<p>
	 *
	 */
	public MCButton ListBtn_upd_apply = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H Btn_par_screen_nm_p_PPanel;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [ListDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0030.ListDtlR> aListDtlL;
	/** [ListHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0030.ListDtlR aListHdrR;

	/**
	 * コピーによってaListDtlLを設定します。
	 *
	 * aListDtlLのインスタンスは変更されません。
	 *
	 * @param dataset ListDtlL
	 */
	public void setListDtlL(MCList<mcframe.clientFSBA.FSBAP0030.ListDtlR> aList) {
		if (getListDtlL() != aList) {
			getListDtlL().setAll(aList);
		}
	}

	/**
	 * [ListDtl]ブロックのコンテナaListDtlLを返します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0030.ListDtlR> getListDtlL() {
		return aListDtlL;
	}

	/**
	 * aListDtlRを作成します。
	 *
	 * @return ListDtlR
	 */
	public mcframe.clientFSBA.FSBAP0030.ListDtlR createListDtlR() {
		return mcframe.clientFSBA.FSBAP0030.ListDtlR.create();
	}

	/**
	 * aListDtlLを作成します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0030.ListDtlR> createListDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0030.ListDtlR.class);
	}

	/**
	 * ListDtlTableを初期化します。
	 */
	protected void createListDtlTable(){
		if(ListDtlTable == null){
			ListDtlTable = beansFactory.createTable2("ListDtl.table");
		}
	}

	/**
	 * 項目コピーによってaListHdrRを設定します。
	 *
	 * aListHdrRのインスタンスは変更されません。
	 *
	 * @param row ListHdrR
	 */
	public void setListHdrR(mcframe.clientFSBA.FSBAP0030.ListDtlR row) {
		if (row != null) {
			MCRow.copyall(getListHdrR(), row);
		}
	}

	/**
	 * [ListHdr]ブロックのコンテナaListHdrRを返します。
	 *
	 * @return ListHdrR
	 */
	public mcframe.clientFSBA.FSBAP0030.ListDtlR getListHdrR() {
		return aListHdrR;
	}

	/**
	 * aListHdrRを作成します。
	 *
	 * @return ListHdrR
	 */
	public mcframe.clientFSBA.FSBAP0030.ListDtlR createListHdrR() {
		return mcframe.clientFSBA.FSBAP0030.ListDtlR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getListDtlL())) ret.add(getListDtlL());
		if(!MCCollectionUtil.contains(ret, getListHdrR())) ret.add(getListHdrR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getListDtlL()) return "ListDtl";
		if(aCnt == getListHdrR()) return "ListHdr";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("ListDtl")) return getListDtlL();
		if(bId.equals("ListHdr")) return getListHdrR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(SettingPanel);
		ret.add(ListPanelPanel);
		ret.add(ListDtlPanel);
		ret.add(ListDtlBtnPanel);
		ret.add(ListDtlEastBtnPanel);
		ret.add(InfoPanelPanel);
		ret.add(InfoPanel);
		ret.add(ListHdrPanel);
		ret.add(ListBtnPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_PersonalizeBase_FW_A() {
		aListDtlL = createListDtlL();
		aListHdrR = createListHdrR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_PersonalizeBase_FW_A(String name) {
		aListDtlL = createListDtlL();
		createListDtlTable();
		ListDtlTable.setRowName(name);
		aListHdrR = createListHdrR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_PersonalizeBase_FW.jbCreateSetting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateInfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateInfo((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbCreateBtn((FSBAP_PersonalizeBase)this);
	}

	/**
	 * [Setting]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSetting(FSBAP_PersonalizeBase p) {
		p.Setting_setting_PPanel = mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.create();
		p.Setting_setting_PPanel.setName("Setting.setting");
	}

	/**
	 * [ListPanel]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListPanel(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [ListDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtl(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [ListDtlBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtlBtn(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [ListDtlEastBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtlEastBtn(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [InfoPanel]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoPanel(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [ListHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListHdr(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [ListBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListBtn(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP_PersonalizeBase p) {
		p.Btn_par_screen_nm_p_PPanel = mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.create();
		p.Btn_par_screen_nm_p_PPanel.setName("Btn.par_screen_nm_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}



	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_PersonalizeBase_FW.jbfInitSetting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitInfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitInfo((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbfInitBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitSetting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitInfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitInfo((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.jbInitBtn((FSBAP_PersonalizeBase)this);
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSetting(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.SettingPanel = p.beansFactory.createPanel("Setting");
		// ブロックの項目の初期化
	}

	/**
	 * [ListPanel]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListPanel(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListPanelPanel = p.beansFactory.createPanel("ListPanel");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtl(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListDtlPanel = p.beansFactory.createPanel("ListDtl");
		p.ListDtlScrollPane = p.beansFactory.createScrollPane("ListDtl.scroll");
		p.createListDtlTable();
		// ブロックの項目の初期化
		p.columnListDtl_init_flg = p.beansFactory.createTableColumn("ListDtl.init_flg", MCColumnType.CHECK);
		p.columnListDtl_setting_unit_type = p.beansFactory.createTableColumn("ListDtl.setting_unit_type", MCColumnType.TEXT);
		p.columnListDtl_setting_unit_type_nm = p.beansFactory.createTableColumn("ListDtl.setting_unit_type_nm", MCColumnType.TEXT);
		p.columnListDtl_setting_info_id = p.beansFactory.createTableColumn("ListDtl.setting_info_id", MCColumnType.TEXT);
		p.columnListDtl_setting_info_nm = p.beansFactory.createTableColumn("ListDtl.setting_info_nm", MCColumnType.TEXT);
		p.columnListDtl_remark = p.beansFactory.createTableColumn("ListDtl.remark", MCColumnType.TEXT);
	}

	/**
	 * [ListDtlBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtlBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListDtlBtnPanel = p.beansFactory.createPanel("ListDtlBtn");
		// ブロックの項目の初期化
		p.ListDtlBtn_radd = p.beansFactory.createButton("ListDtlBtn.radd", "no_border");
		p.ListDtlBtn_rcopy = p.beansFactory.createButton("ListDtlBtn.rcopy", "no_border");
		p.ListDtlBtn_load = p.beansFactory.createButton("ListDtlBtn.load");
		p.ListDtlBtn_apply = p.beansFactory.createButton("ListDtlBtn.apply");
		p.ListDtlBtn_apply_close = p.beansFactory.createButton("ListDtlBtn.apply_close");
		p.ListDtlBtn_del = p.beansFactory.createButton("ListDtlBtn.del", "del");
	}

	/**
	 * [ListDtlEastBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtlEastBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListDtlEastBtnPanel = p.beansFactory.createPanel("ListDtlEastBtn");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoPanel]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoPanel(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.InfoPanelPanel = p.beansFactory.createPanel("InfoPanel");
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.InfoPanel = p.beansFactory.createPanel("Info");
		// ブロックの項目の初期化
	}

	/**
	 * [ListHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListHdr(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListHdrPanel = p.beansFactory.createPanel("ListHdr");
		// ブロックの項目の初期化
		p.ListHdr_init_flg = p.beansFactory.createCheckBox("ListHdr.init_flg");
		p.ListHdr_setting_info_nm_Label = p.beansFactory.createLabel("ListHdr.setting_info_nm_Label");
		p.ListHdr_setting_info_nm = p.beansFactory.createTextField("ListHdr.setting_info_nm");
		p.ListHdr_setting_info_nm.setLabel(p.ListHdr_setting_info_nm_Label);
		p.ListHdr_remark_Label = p.beansFactory.createLabel("ListHdr.remark_Label");
		p.ListHdr_remark = p.beansFactory.createTextField("ListHdr.remark");
		p.ListHdr_remark.setLabel(p.ListHdr_remark_Label);
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListBtnPanel = p.beansFactory.createPanel("ListBtn");
		// ブロックの項目の初期化
		p.ListBtn_upd = p.beansFactory.createButton("ListBtn.upd", "upd");
		p.ListBtn_upd_ext = p.beansFactory.createButton("ListBtn.upd_ext", "upd");
		p.ListBtn_upd_sys = p.beansFactory.createButton("ListBtn.upd_sys", "upd");
		p.ListBtn_upd_apply = p.beansFactory.createButton("ListBtn.upd_apply", "upd");
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSetting(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.add(p.SettingPanel);
		p.setLastBeans(p.SettingPanel);
		p.SettingPanel.setNextBeans(p.ListPanelPanel);
		p.SettingPanel.setValueCheck(false);
		p.SettingPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.SettingPanel.add(p.Setting_setting_PPanel);
		p.SettingPanel.setLastBeans(p.Setting_setting_PPanel);
	}

	/**
	 * [ListPanel]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListPanel(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.add(p.ListPanelPanel);
		p.ListPanelPanel.setNextBeans(p.InfoPanelPanel);
		p.ListPanelPanel.setLayoutPosition("CTC+");
		// ブロックの項目の初期化
		p.ListPanelPanel.add(p.ListDtlPanel, null);
		p.ListPanelPanel.setLastBeans(p.ListDtlPanel);
		p.ListDtlPanel.setNextBeans(p.ListDtlBtnPanel);
		p.ListPanelPanel.add(p.ListDtlBtnPanel, null);
		p.ListDtlBtnPanel.setNextBeans(p.ListDtlEastBtnPanel);
		p.ListPanelPanel.add(p.ListDtlEastBtnPanel, null);
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtl(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListDtlPanel.add(p.ListDtlScrollPane);
		p.ListDtlPanel.setLastBeans(p.ListDtlTable);
		p.ListDtlScrollPane.setViewportView(p.ListDtlTable);
		p.ListDtlTable.setList(p.getListDtlL());
		p.ListDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDtlBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtlBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListDtlBtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.ListDtlBtn_radd.setIcon("INSERT_RECORD");
		p.ListDtlBtn_radd.setFunctionKey(MCFunctionKey.F11);
		p.ListDtlBtnPanel.add(p.ListDtlBtn_radd);
		p.ListDtlBtnPanel.setLastBeans(p.ListDtlBtn_radd);
		p.ListDtlBtn_radd.setNextBeans(p.ListDtlBtn_rcopy);
		p.ListDtlBtn_rcopy.setIcon("COPY_RECORD");
		p.ListDtlBtn_rcopy.setFunctionKey(MCFunctionKey.F15);
		p.ListDtlBtnPanel.add(p.ListDtlBtn_rcopy);
		p.ListDtlBtn_rcopy.setNextBeans(p.ListDtlBtn_load);
		p.ListDtlBtn_load.setFunctionKey(MCFunctionKey.F7);
		p.ListDtlBtnPanel.add(p.ListDtlBtn_load);
		p.ListDtlBtn_load.setNextBeans(p.ListDtlBtn_apply);
		p.ListDtlBtn_apply.setFunctionKey(MCFunctionKey.F3);
		p.ListDtlBtnPanel.add(p.ListDtlBtn_apply);
		p.ListDtlBtn_apply.setNextBeans(p.ListDtlBtn_apply_close);
		p.ListDtlBtn_apply_close.setFunctionKey(MCFunctionKey.F4);
		p.ListDtlBtnPanel.add(p.ListDtlBtn_apply_close);
		p.ListDtlBtn_del.setIcon("DELETE");
		p.ListDtlBtn_del.setFunctionKey(MCFunctionKey.F12);
		p.ListDtlEastBtnPanel.setLastBeans(p.ListDtlBtn_del);
		p.ListDtlEastBtnPanel.add(p.ListDtlBtn_del);
	}

	/**
	 * [ListDtlEastBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtlEastBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListDtlEastBtnPanel.setLayoutPosition("SE");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoPanel]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoPanel(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.add(p.InfoPanelPanel);
		p.InfoPanelPanel.setNextBeans(p.BtnPanel);
		p.InfoPanelPanel.setLayoutPosition("CBC+");
		// ブロックの項目の初期化
		p.InfoPanelPanel.add(p.InfoPanel, null);
		p.InfoPanelPanel.setLastBeans(p.InfoPanel);
		p.InfoPanel.setNextBeans(p.ListHdrPanel);
		p.InfoPanelPanel.add(p.ListHdrPanel, null);
		p.ListHdrPanel.setNextBeans(p.ListBtnPanel);
		p.InfoPanelPanel.add(p.ListBtnPanel, null);
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.InfoPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
	}

	/**
	 * [ListHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListHdr(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListHdrPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.ListHdrPanel.add(p.ListHdr_init_flg);
		p.ListHdrPanel.setLastBeans(p.ListHdr_init_flg);
		p.ListHdr_init_flg.setNextBeans(p.ListHdr_setting_info_nm);
		p.ListHdr_init_flg.setRow(p.getListHdrR(), mcframe.clientFSBA.FSBAP0030.ListDtlR.init_flg_META);
		p.ListHdrPanel.add(p.ListHdr_setting_info_nm_Label);
		p.ListHdrPanel.add(p.ListHdr_setting_info_nm);
		p.ListHdr_setting_info_nm.setNextBeans(p.ListHdr_remark);
		p.ListHdr_setting_info_nm.setRow(p.getListHdrR(), mcframe.clientFSBA.FSBAP0030.ListDtlR.setting_info_nm_META);
		p.ListHdrPanel.add(p.ListHdr_remark_Label);
		p.ListHdrPanel.add(p.ListHdr_remark);
		p.ListHdr_remark.setRow(p.getListHdrR(), mcframe.clientFSBA.FSBAP0030.ListDtlR.remark_META);
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.ListBtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.ListBtn_upd.setIcon("REGISTER");
		p.ListBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.ListBtnPanel.add(p.ListBtn_upd);
		p.ListBtnPanel.setLastBeans(p.ListBtn_upd);
		p.ListBtn_upd.setNextBeans(p.ListBtn_upd_ext);
		p.ListBtn_upd_ext.setIcon("REGISTER");
		p.ListBtn_upd_ext.setFunctionKey(MCFunctionKey.F9);
		p.ListBtnPanel.add(p.ListBtn_upd_ext);
		p.ListBtn_upd_ext.setNextBeans(p.ListBtn_upd_sys);
		p.ListBtn_upd_sys.setIcon("REGISTER");
		p.ListBtn_upd_sys.setFunctionKey(MCFunctionKey.F9);
		p.ListBtnPanel.add(p.ListBtn_upd_sys);
		p.ListBtn_upd_sys.setNextBeans(p.ListBtn_upd_apply);
		p.ListBtn_upd_apply.setIcon("REGISTER");
		p.ListBtn_upd_apply.setFunctionKey(MCFunctionKey.F8);
		p.ListBtnPanel.add(p.ListBtn_upd_apply);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP_PersonalizeBase p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.BtnPanel.add(p.Btn_par_screen_nm_p_PPanel);
		p.BtnPanel.setLastBeans(p.Btn_par_screen_nm_p_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_PersonalizeBase_FW.mcInitSetting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitInfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitInfo((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.mcInitBtn((FSBAP_PersonalizeBase)this);

		// [INIT]ステータスのモードの設定
		FSBAP_PersonalizeBase_FW.statusInitINIT_Setting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_ListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_ListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_ListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_ListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_InfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_Info((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_ListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_ListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitINIT_Btn((FSBAP_PersonalizeBase)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_PersonalizeBase_FW.statusInitEDIT_Setting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_ListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_ListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_ListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_ListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_InfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_Info((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_ListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_ListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitEDIT_Btn((FSBAP_PersonalizeBase)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_Setting((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_ListPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_ListDtl((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_ListDtlBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_ListDtlEastBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_InfoPanel((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_Info((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_ListHdr((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_ListBtn((FSBAP_PersonalizeBase)this);
		FSBAP_PersonalizeBase_FW.statusInitDISABLE_Btn((FSBAP_PersonalizeBase)this);

	}

	/**
	 *  [Setting]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSetting(FSBAP_PersonalizeBase p) {
	}

	/**
	 *  [ListPanel]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListPanel(FSBAP_PersonalizeBase p) {
	}

	/**
	 *  [ListDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtl(FSBAP_PersonalizeBase p) {
		p.ListDtlTable.addAllListener(p);
		p.columnListDtl_init_flg.addAllListener(p);
		p.columnListDtl_setting_unit_type.addAllListener(p);
		p.columnListDtl_setting_unit_type.setListListener(p);
		p.columnListDtl_setting_unit_type_nm.addAllListener(p);
		p.columnListDtl_setting_unit_type_nm.setListListener(p);
		p.columnListDtl_setting_info_id.addAllListener(p);
		p.columnListDtl_setting_info_id.setListListener(p);
		p.columnListDtl_setting_info_nm.addAllListener(p);
		p.columnListDtl_setting_info_nm.setListListener(p);
		p.columnListDtl_remark.addAllListener(p);
		p.columnListDtl_remark.setListListener(p);
	}

	/**
	 *  [ListDtlBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtlBtn(FSBAP_PersonalizeBase p) {
		p.ListDtlBtn_radd.addAllListener(p);
		p.ListDtlBtn_radd.setAPMethodName("doListDtlBtn_radd");
		p.ListDtlBtn_rcopy.addAllListener(p);
		p.ListDtlBtn_rcopy.setAPMethodName("doListDtlBtn_rcopy");
		p.ListDtlBtn_load.addAllListener(p);
		p.ListDtlBtn_load.setAPMethodName("doListDtlBtn_load");
		p.ListDtlBtn_apply.addAllListener(p);
		p.ListDtlBtn_apply.setAPMethodName("doListDtlBtn_apply");
		p.ListDtlBtn_apply_close.addAllListener(p);
		p.ListDtlBtn_apply_close.setAPMethodName("doListDtlBtn_apply_close");
		p.ListDtlBtn_del.addAllListener(p);
		p.ListDtlBtn_del.setAPMethodName("doListDtlBtn_del");
	}

	/**
	 *  [ListDtlEastBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtlEastBtn(FSBAP_PersonalizeBase p) {
	}

	/**
	 *  [InfoPanel]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoPanel(FSBAP_PersonalizeBase p) {
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP_PersonalizeBase p) {
	}

	/**
	 *  [ListHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListHdr(FSBAP_PersonalizeBase p) {
		p.ListHdr_init_flg.addAllListener(p);
		p.ListHdr_setting_info_nm.setListListener(p);
		p.ListHdr_setting_info_nm.addAllListener(p);
		p.ListHdr_remark.setListListener(p);
		p.ListHdr_remark.addAllListener(p);
	}

	/**
	 *  [ListBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListBtn(FSBAP_PersonalizeBase p) {
		p.ListBtn_upd.addAllListener(p);
		p.ListBtn_upd.setAPMethodName("doListBtn_upd");
		p.ListBtn_upd_ext.addAllListener(p);
		p.ListBtn_upd_ext.setAPMethodName("doListBtn_upd_ext");
		p.ListBtn_upd_sys.addAllListener(p);
		p.ListBtn_upd_sys.setAPMethodName("doListBtn_upd_sys");
		p.ListBtn_upd_apply.addAllListener(p);
		p.ListBtn_upd_apply.setAPMethodName("doListBtn_upd_apply");
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP_PersonalizeBase p) {
	}

	/**
	 * [INIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Setting(FSBAP_PersonalizeBase p){
		p.Setting_setting_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[ListPanel]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListPanel(FSBAP_PersonalizeBase p){

	}

	/**
	 * [INIT]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListDtl(FSBAP_PersonalizeBase p){
		p.columnListDtl_init_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnListDtl_setting_unit_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnListDtl_setting_unit_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnListDtl_setting_info_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnListDtl_setting_info_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnListDtl_remark.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListDtlBtn(FSBAP_PersonalizeBase p){
		p.ListDtlBtn_radd.putMode(p, INIT, MCMode.ENABLE);
		p.ListDtlBtn_rcopy.putMode(p, INIT, MCMode.DISABLE);
		p.ListDtlBtn_load.putMode(p, INIT, MCMode.DISABLE);
		p.ListDtlBtn_apply.putMode(p, INIT, MCMode.DISABLE);
		p.ListDtlBtn_apply_close.putMode(p, INIT, MCMode.DISABLE);
		p.ListDtlBtn_del.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[ListDtlEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListDtlEastBtn(FSBAP_PersonalizeBase p){

	}

	/**
	 * [INIT]ステータスの[InfoPanel]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoPanel(FSBAP_PersonalizeBase p){

	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP_PersonalizeBase p){

	}

	/**
	 * [INIT]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListHdr(FSBAP_PersonalizeBase p){
		p.ListHdr_init_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.ListHdr_setting_info_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.ListHdr_remark.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListBtn(FSBAP_PersonalizeBase p){
		p.ListBtn_upd.putMode(p, INIT, MCMode.ENABLE);
		p.ListBtn_upd_ext.putMode(p, INIT, MCMode.INVISIBLE);
		p.ListBtn_upd_sys.putMode(p, INIT, MCMode.INVISIBLE);
		p.ListBtn_upd_apply.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP_PersonalizeBase p){
		p.Btn_par_screen_nm_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Setting(FSBAP_PersonalizeBase p){
		p.Setting_setting_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [EDIT]ステータスの[ListPanel]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListPanel(FSBAP_PersonalizeBase p){

	}

	/**
	 * [EDIT]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListDtl(FSBAP_PersonalizeBase p){
		p.columnListDtl_init_flg.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnListDtl_setting_unit_type.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnListDtl_setting_unit_type_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnListDtl_setting_info_id.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnListDtl_setting_info_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnListDtl_remark.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListDtlBtn(FSBAP_PersonalizeBase p){
		p.ListDtlBtn_radd.putMode(p, EDIT, MCMode.ENABLE);
		p.ListDtlBtn_rcopy.putMode(p, EDIT, MCMode.ENABLE);
		p.ListDtlBtn_load.putMode(p, EDIT, MCMode.ENABLE);
		p.ListDtlBtn_apply.putMode(p, EDIT, MCMode.ENABLE);
		p.ListDtlBtn_apply_close.putMode(p, EDIT, MCMode.ENABLE);
		p.ListDtlBtn_del.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[ListDtlEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListDtlEastBtn(FSBAP_PersonalizeBase p){

	}

	/**
	 * [EDIT]ステータスの[InfoPanel]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoPanel(FSBAP_PersonalizeBase p){

	}

	/**
	 * [EDIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Info(FSBAP_PersonalizeBase p){

	}

	/**
	 * [EDIT]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListHdr(FSBAP_PersonalizeBase p){
		p.ListHdr_init_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.ListHdr_setting_info_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.ListHdr_remark.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListBtn(FSBAP_PersonalizeBase p){
		p.ListBtn_upd.putMode(p, EDIT, MCMode.ENABLE);
		p.ListBtn_upd_ext.putMode(p, EDIT, MCMode.INVISIBLE);
		p.ListBtn_upd_sys.putMode(p, EDIT, MCMode.INVISIBLE);
		p.ListBtn_upd_apply.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Btn(FSBAP_PersonalizeBase p){
		p.Btn_par_screen_nm_p_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Setting(FSBAP_PersonalizeBase p){
		p.Setting_setting_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [DISABLE]ステータスの[ListPanel]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListPanel(FSBAP_PersonalizeBase p){

	}

	/**
	 * [DISABLE]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListDtl(FSBAP_PersonalizeBase p){
		p.columnListDtl_init_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnListDtl_setting_unit_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnListDtl_setting_unit_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnListDtl_setting_info_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnListDtl_setting_info_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnListDtl_remark.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListDtlBtn(FSBAP_PersonalizeBase p){
		p.ListDtlBtn_radd.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListDtlBtn_rcopy.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListDtlBtn_load.putMode(p, DISABLE, MCMode.DISABLE);
		p.ListDtlBtn_apply.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListDtlBtn_apply_close.putMode(p, DISABLE, MCMode.ENABLE);
		p.ListDtlBtn_del.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[ListDtlEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListDtlEastBtn(FSBAP_PersonalizeBase p){

	}

	/**
	 * [DISABLE]ステータスの[InfoPanel]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoPanel(FSBAP_PersonalizeBase p){

	}

	/**
	 * [DISABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Info(FSBAP_PersonalizeBase p){

	}

	/**
	 * [DISABLE]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListHdr(FSBAP_PersonalizeBase p){
		p.ListHdr_init_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.ListHdr_setting_info_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.ListHdr_remark.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListBtn(FSBAP_PersonalizeBase p){
		p.ListBtn_upd.putMode(p, DISABLE, MCMode.DISABLE);
		p.ListBtn_upd_ext.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.ListBtn_upd_sys.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.ListBtn_upd_apply.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Btn(FSBAP_PersonalizeBase p){
		p.Btn_par_screen_nm_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_PersonalizeBase_FW.setTableConfigListDtl((FSBAP_PersonalizeBase)this);
	}

	/**
	 * [ListDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigListDtl(FSBAP_PersonalizeBase p) {
		p.columnListDtl_init_flg.setMeta(mcframe.clientFSBA.FSBAP0030.ListDtlR.init_flg_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_flg);
		p.columnListDtl_setting_unit_type.setMeta(mcframe.clientFSBA.FSBAP0030.ListDtlR.setting_unit_type_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_setting_unit_type);
		p.columnListDtl_setting_unit_type_nm.setMeta(mcframe.clientFSBA.FSBAP0030.ListDtlR.setting_unit_type_nm_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_setting_unit_type_nm);
		p.columnListDtl_setting_info_id.setMeta(mcframe.clientFSBA.FSBAP0030.ListDtlR.setting_info_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_setting_info_id);
		p.columnListDtl_setting_info_nm.setMeta(mcframe.clientFSBA.FSBAP0030.ListDtlR.setting_info_nm_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_setting_info_nm);
		p.columnListDtl_remark.setMeta(mcframe.clientFSBA.FSBAP0030.ListDtlR.remark_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_remark);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == ListDtlBtn_radd) doListDtlBtn_radd(info);
		else if (ap == ListDtlBtn_rcopy) doListDtlBtn_rcopy(info);
		else if (ap == ListDtlBtn_load) doListDtlBtn_load(info);
		else if (ap == ListDtlBtn_apply) doListDtlBtn_apply(info);
		else if (ap == ListDtlBtn_apply_close) doListDtlBtn_apply_close(info);
		else if (ap == ListDtlBtn_del) doListDtlBtn_del(info);
		else if (ap == ListBtn_upd) doListBtn_upd(info);
		else if (ap == ListBtn_upd_ext) doListBtn_upd_ext(info);
		else if (ap == ListBtn_upd_sys) doListBtn_upd_sys(info);
		else if (ap == ListBtn_upd_apply) doListBtn_upd_apply(info);
	}

	/**
	 * [ListDtlBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDtlBtn_radd(MCEventInfo info);

	/**
	 * [ListDtlBtn]パネルの[rcopy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDtlBtn_rcopy(MCEventInfo info);

	/**
	 * [ListDtlBtn]パネルの[load]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDtlBtn_load(MCEventInfo info);

	/**
	 * [ListDtlBtn]パネルの[apply]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDtlBtn_apply(MCEventInfo info);

	/**
	 * [ListDtlBtn]パネルの[apply_close]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDtlBtn_apply_close(MCEventInfo info);

	/**
	 * [ListDtlBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListDtlBtn_del(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_upd(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[upd_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_upd_ext(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[upd_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_upd_sys(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[upd_apply]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_upd_apply(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListDtlTable) return doListDtl_VC(info);
		if (vc == columnListDtl_init_flg) return doListDtl_init_flg_VC(info);
		if (vc == columnListDtl_setting_unit_type) return doListDtl_setting_unit_type_VC(info);
		if (vc == columnListDtl_setting_unit_type_nm) return doListDtl_setting_unit_type_nm_VC(info);
		if (vc == columnListDtl_setting_info_id) return doListDtl_setting_info_id_VC(info);
		if (vc == columnListDtl_setting_info_nm) return doListDtl_setting_info_nm_VC(info);
		if (vc == columnListDtl_remark) return doListDtl_remark_VC(info);
		if (vc == ListHdr_init_flg) return doListHdr_init_flg_VC(info);
		if (vc == ListHdr_setting_info_nm) return doListHdr_setting_info_nm_VC(info);
		if (vc == ListHdr_remark) return doListHdr_remark_VC(info);
		return true;
	}

	/**
	 * [ListDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_setting_unit_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_setting_unit_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[setting_info_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_setting_info_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[setting_info_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_setting_info_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListHdr]パネルの[init_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListHdr_init_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListHdr]パネルの[setting_info_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListHdr_setting_info_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListHdr]パネルの[remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListHdr_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListDtlTable) doListDtl_NC(info);
		else if (nc == columnListDtl_init_flg) doListDtl_init_flg_NC(info);
		else if (nc == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_NC(info);
		else if (nc == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_NC(info);
		else if (nc == columnListDtl_setting_info_id) doListDtl_setting_info_id_NC(info);
		else if (nc == columnListDtl_setting_info_nm) doListDtl_setting_info_nm_NC(info);
		else if (nc == columnListDtl_remark) doListDtl_remark_NC(info);
		else if (nc == ListHdr_init_flg) doListHdr_init_flg_NC(info);
		else if (nc == ListHdr_setting_info_nm) doListHdr_setting_info_nm_NC(info);
		else if (nc == ListHdr_remark) doListHdr_remark_NC(info);
	}

	/**
	 * [ListDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_flg_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_NC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[init_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_init_flg_NC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[setting_info_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_setting_info_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_remark_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListDtlTable) doListDtl_NE(info);
		else if (ne == columnListDtl_init_flg) doListDtl_init_flg_NE(info);
		else if (ne == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_NE(info);
		else if (ne == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_NE(info);
		else if (ne == columnListDtl_setting_info_id) doListDtl_setting_info_id_NE(info);
		else if (ne == columnListDtl_setting_info_nm) doListDtl_setting_info_nm_NE(info);
		else if (ne == columnListDtl_remark) doListDtl_remark_NE(info);
		else if (ne == ListHdr_init_flg) doListHdr_init_flg_NE(info);
		else if (ne == ListHdr_setting_info_nm) doListHdr_setting_info_nm_NE(info);
		else if (ne == ListHdr_remark) doListHdr_remark_NE(info);
	}

	/**
	 * [ListDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_flg_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_NE(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[init_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_init_flg_NE(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[setting_info_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_setting_info_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_remark_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListDtlTable) doListDtl_NX(info);
		else if (nx == columnListDtl_init_flg) doListDtl_init_flg_NX(info);
		else if (nx == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_NX(info);
		else if (nx == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_NX(info);
		else if (nx == columnListDtl_setting_info_id) doListDtl_setting_info_id_NX(info);
		else if (nx == columnListDtl_setting_info_nm) doListDtl_setting_info_nm_NX(info);
		else if (nx == columnListDtl_remark) doListDtl_remark_NX(info);
		else if (nx == ListHdr_init_flg) doListHdr_init_flg_NX(info);
		else if (nx == ListHdr_setting_info_nm) doListHdr_setting_info_nm_NX(info);
		else if (nx == ListHdr_remark) doListHdr_remark_NX(info);
	}

	/**
	 * [ListDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_flg_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_NX(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[init_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_init_flg_NX(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[setting_info_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_setting_info_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_remark_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnListDtl_setting_unit_type) doListDtl_setting_unit_type_LC(info);
		else if (lc == columnListDtl_setting_unit_type_nm) doListDtl_setting_unit_type_nm_LC(info);
		else if (lc == columnListDtl_setting_info_id) doListDtl_setting_info_id_LC(info);
		else if (lc == columnListDtl_setting_info_nm) doListDtl_setting_info_nm_LC(info);
		else if (lc == columnListDtl_remark) doListDtl_remark_LC(info);
		else if (lc == ListHdr_setting_info_nm) doListHdr_setting_info_nm_LC(info);
		else if (lc == ListHdr_remark) doListHdr_remark_LC(info);
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_unit_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_unit_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[setting_info_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_setting_info_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_remark_LC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[setting_info_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_setting_info_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_remark_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}