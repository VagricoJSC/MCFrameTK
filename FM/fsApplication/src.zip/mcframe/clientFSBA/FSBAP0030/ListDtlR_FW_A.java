package mcframe.clientFSBA.FSBAP0030;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ListDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListDtlR_FW_A extends MCConstRow {

	/**
	 *  初期設定.<p>
	 *
	 */
	public static final String $init_flg = "init_flg";
	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public static final String $setting_unit_type = "setting_unit_type";
	/**
	 *  設定単位名.<p>
	 *
	 */
	public static final String $setting_unit_type_nm = "setting_unit_type_nm";
	/**
	 *  設定情報ＩＤ.<p>
	 *
	 */
	public static final String $setting_info_id = "setting_info_id";
	/**
	 *  設定情報名.<p>
	 *
	 */
	public static final String $setting_info_nm = "setting_info_nm";
	/**
	 *  備考.<p>
	 *
	 */
	public static final String $remark = "remark";


	public static final MCMeta init_flg_META = createCommonMeta($init_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta setting_unit_type_META = createStringMeta($setting_unit_type);
	public static final MCMeta setting_unit_type_nm_META = createStringMeta($setting_unit_type_nm);
	public static final MCMeta setting_info_id_META = createStringMeta($setting_info_id);
	public static final MCMeta setting_info_nm_META = createStringMeta($setting_info_nm, 20);
	public static final MCMeta remark_META = createStringMeta($remark, 60);

	protected static final ConstMetaList<ListDtlR> constMetas = new ConstMetaList<ListDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			init_flg_META,
			setting_unit_type_META,
			setting_unit_type_nm_META,
			setting_info_id_META,
			setting_info_nm_META,
			remark_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListDtlR_FW_A(ConstMetaList<? extends ListDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR clone() {
		return (ListDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR createInstance() {
		return (ListDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR getValues(String... names) {
		return (ListDtlR) super.getValues(names);
	}



	/**
	 *  初期設定.<p>
	 *
	 */
	public boolean init_flg() {
		return getConstBoolean(offset + 0, $init_flg);
	}

	/**
	 *  初期設定.<p>
	 *
	 */
	public void init_flg(boolean value) {
		setConstBoolean(offset + 0, $init_flg, value);
	}


	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public String setting_unit_type() {
		return getConstString(offset + 1, $setting_unit_type);
	}

	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public void setting_unit_type(String value) {
		setConstString(offset + 1, $setting_unit_type, value);
	}


	/**
	 *  設定単位名.<p>
	 *
	 */
	public String setting_unit_type_nm() {
		return getConstString(offset + 2, $setting_unit_type_nm);
	}

	/**
	 *  設定単位名.<p>
	 *
	 */
	public void setting_unit_type_nm(String value) {
		setConstString(offset + 2, $setting_unit_type_nm, value);
	}


	/**
	 *  設定情報ＩＤ.<p>
	 *
	 */
	public String setting_info_id() {
		return getConstString(offset + 3, $setting_info_id);
	}

	/**
	 *  設定情報ＩＤ.<p>
	 *
	 */
	public void setting_info_id(String value) {
		setConstString(offset + 3, $setting_info_id, value);
	}


	/**
	 *  設定情報名.<p>
	 *
	 */
	public String setting_info_nm() {
		return getConstString(offset + 4, $setting_info_nm);
	}

	/**
	 *  設定情報名.<p>
	 *
	 */
	public void setting_info_nm(String value) {
		setConstString(offset + 4, $setting_info_nm, value);
	}


	/**
	 *  備考.<p>
	 *
	 */
	public String remark() {
		return getConstString(offset + 5, $remark);
	}

	/**
	 *  備考.<p>
	 *
	 */
	public void remark(String value) {
		setConstString(offset + 5, $remark, value);
	}


	public String getString(String name) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			return setting_unit_type_nm();
		}
		if ($setting_info_id.equalsIgnoreCase(name)) {
			return setting_info_id();
		}
		if ($setting_info_nm.equalsIgnoreCase(name)) {
			return setting_info_nm();
		}
		if ($remark.equalsIgnoreCase(name)) {
			return remark();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($init_flg.equalsIgnoreCase(name)) {
			return init_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			return setting_unit_type_nm();
		}
		if ($setting_info_id.equalsIgnoreCase(name)) {
			return setting_info_id();
		}
		if ($setting_info_nm.equalsIgnoreCase(name)) {
			return setting_info_nm();
		}
		if ($remark.equalsIgnoreCase(name)) {
			return remark();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($init_flg.equalsIgnoreCase(name)) {
			return init_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			setting_unit_type_nm(value);
			return;
		}
		if ($setting_info_id.equalsIgnoreCase(name)) {
			setting_info_id(value);
			return;
		}
		if ($setting_info_nm.equalsIgnoreCase(name)) {
			setting_info_nm(value);
			return;
		}
		if ($remark.equalsIgnoreCase(name)) {
			remark(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($init_flg.equalsIgnoreCase(name)) {
			init_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			setting_unit_type_nm(value);
			return;
		}
		if ($setting_info_id.equalsIgnoreCase(name)) {
			setting_info_id(value);
			return;
		}
		if ($setting_info_nm.equalsIgnoreCase(name)) {
			setting_info_nm(value);
			return;
		}
		if ($remark.equalsIgnoreCase(name)) {
			remark(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($init_flg.equalsIgnoreCase(name)) {
			init_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

