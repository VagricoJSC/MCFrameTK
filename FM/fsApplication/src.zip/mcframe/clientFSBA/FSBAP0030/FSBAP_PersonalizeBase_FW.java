package mcframe.clientFSBA.FSBAP0030;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0080.*;
import mcframe.clientFSUB.FSUBP0090.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.HashMap;
import java.util.Map;

import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.resource.ctrl.MCGroupResource;

import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_PersonalizeBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_PersonalizeBase_FW extends FSBAP_PersonalizeBase_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 設定情報ＩＤと設定情報のマップです。
	 */
	protected Map<String, WBP_PersonalizeInfo> _setting_info_map 
			= new HashMap<String, WBP_PersonalizeInfo>();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_PersonalizeBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_PersonalizeBase_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[ListBtn]のボタン[upd_ext]の押下時の処理
	 */
	@Override
	public void doListBtn_upd_ext(MCEventInfo info) {
	}
	/**
	 * Panel[ListBtn]のボタン[upd_sys]の押下時の処理
	 */
	@Override
	public void doListBtn_upd_sys(MCEventInfo info) {
	}
	/**
	 * Panel[ListDtlBtn]のボタン[apply_close]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_apply_close(MCEventInfo info) {
		doApplyCloseAction();
	}
	/**
	 * Panel[ListBtn]のボタン[upd_apply]の押下時の処理
	 */
	@Override
	public void doListBtn_upd_apply(MCEventInfo info) {
		doUpdApplyAction();
	}
	/**
	 * Panel[ListDtlBtn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_del(MCEventInfo info) {
		doDelAction();
	}
	/**
	 * Panel[ListDtlBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_radd(MCEventInfo info) {
		insertRow(ListDtlTable);
	}
	/**
	 * Panel[ListDtlBtn]のボタン[rcopy]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_rcopy(MCEventInfo info) {
		doCopyRowAction();
	}
	/**
	 * Panel[ListDtlBtn]のボタン[load]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_load(MCEventInfo info) {
		doLoadAction();
	}
	/**
	 * Panel[ListDtlBtn]のボタン[apply]の押下時の処理
	 */
	@Override
	public void doListDtlBtn_apply(MCEventInfo info) {
		doApplyAction();
	}
	/**
	 * Panel[ListBtn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doListBtn_upd(MCEventInfo info) {
		doUpdAction();
	}
	
	/**
	 * 行コピーボタンの処理を実行します。
	 */
	protected void doCopyRowAction() {
		if (!checkForCopyRow()) {
			return;
		}
		
		beforeCopyRow();
		doCopyRow();
		afterCopyRow();
	}

	/**
	 * 行コピーの処理の実行可否を判断します。<p>
	 * 行コピーの処理を続行する場合は true を返します。
	 * 
	 * @return 行コピーの処理を中断する場合は false
	 */
	protected boolean checkForCopyRow() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s == null || s.isEmpty()) {
			return false;
		}
		if (!getListHdrR().isStatusNone() || isInfoDataChanged()) {
			return false;
		}
		return true;
	}
	
	/**
	 * 行コピーの処理の前処理を実行します。
	 */
	protected void beforeCopyRow() {
		
	}

	/**
	 * 行コピーの処理を実行します。
	 */
	protected void doCopyRow() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		ListDtlR n = s.clone();
		
		ListDtlTable.insertRow(s.getGUIIndex() + 1, n);

		n.init_flg(false);
		n.setting_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		n.setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(n, 
				ListDtlR.$setting_unit_type, 
				ListDtlR.$setting_unit_type_nm);
		// 2017/01/05 登録名も複製する
//		n.setting_info_nm(null);
		n.setStatus(MCRow.CREATE);
	}
	
	/**
	 * 行コピーの処理の後処理を実行します。
	 */
	protected void afterCopyRow() {
		
	}
	
	/**
	 * 現在の状態を表示ボタンの処理を実行します。
	 */
	protected void doLoadAction() {
		if (!checkForLoad()) {
			return;
		}

		beforeLoad();
		doLoad();
		afterLoad();
	}
	
	/**
	 * 現在の状態を表示する処理の実行可否を判断します。<p>
	 * 現在の状態を表示する処理を続行する場合は true を返します。
	 * 
	 * @return 現在の状態を表示する処理を中断する場合は false
	 */
	protected boolean checkForLoad() {
		return true;
	}
	
	/**
	 * 現在の状態を表示する処理の前処理を実行します。
	 */
	protected void beforeLoad() {
		
	}

	/**
	 * 現在の状態を表示する処理を実行します。
	 */
	protected void doLoad() {
		
	}

	/**
	 * 現在の状態を表示する処理の後処理を実行します。
	 */
	protected void afterLoad() {
		
	}

	/**
	 * 適用ボタンの処理を実行します。
	 */
	protected void doApplyAction() {
		if (!checkForApply()) {
			return;
		}
		
		beforeApply();
		doApply();
		afterApply();
	}
	
	/**
	 * 適用後閉じるボタンの処理を実行します。
	 */
	protected void doApplyCloseAction() {
		if (!checkForApply()) {
			return;
		}
		
		beforeApply();
		doApply();
		afterApply();
		
		requestCloseWindow();
	}

	/**
	 * 適用処理の実行可否を判断します。<p>
	 * 適用処理を続行する場合は true を返します。
	 * 
	 * @return 適用処理を中断する場合は false
	 */
	protected boolean checkForApply() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s == null) {
			dialog(FXBAP0035);
			return false;
		}
		
		if (getSettingInfo(s) == null) {
			dialog(FSBAC0066);
			return false;
		}
		
		return true;
	}
	
	/**
	 * 適用処理の前処理を実行します。
	 */
	protected void beforeApply() {
		
	}

	/**
	 * 適用処理を実行します。
	 */
	protected void doApply() {
		updateTargetPanel();
	}

	/**
	 * 設定対象の画面の情報を更新します。
	 */
	protected abstract void updateTargetPanel();
	
	/**
	 * 適用処理の後処理を実行します。
	 */
	protected void afterApply() {
		statusClear();
	}

	/**
	 * デフォルトボタンの処理を実行します。
	 */
	protected void doDefAction() {
		if (!execDefConfirm() || !checkForDef()) {
			return;
		}
		
		beforeDef();
		doDef();
		afterDef();
		
		showDefEndMsg();
		
		requestCloseWindow();
	}
	
	/**
	 * デフォルトに戻す処理の実行確認メッセージを表示します。<p>
	 * デフォルトに戻す処理を続行する場合は true を返します。
	 * 
	 * @return デフォルトに戻す処理を中断する場合は false
	 */
	protected boolean execDefConfirm() {
		return confirm(MCDialogButton.NO, FSBAC0004) == MCMessageBox.YES_OPTION;
	}

	/**
	 * デフォルトに戻す処理の実行可否を判断します。<p>
	 * デフォルトに戻す処理を続行する場合は true を返します。
	 * 
	 * @return デフォルトに戻す処理を中断する場合は false
	 */
	protected boolean checkForDef() {
		return true;
	}

	/**
	 * デフォルトに戻す処理の前処理を実行します。
	 */
	protected void beforeDef() {
		
	}

	/**
	 * デフォルトに戻す処理を実行します。
	 */
	protected void doDef() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		getListDtlL().remove(s);
		
		removeResource(true);
		setTargetPanelDefault();
		
		setInitData();
		fillSpaceForOpen();
	}
	
	/**
	 * リソースに保存されている全ての設定情報を削除します。
	 */
	protected abstract void removeResource(boolean doSave);

	/**
	 * 削除対象の行と同じ設定単位のパーソナライズ情報が、 残っているかどうかを返します。
	 * </p>
	 * 選択行を含めて複数存在する場合は、削除後にも残っているとみなされます。
	 * 登録もしくは更新を行った場合は、残っているかどうかを判断せずにtrueを返します。
	 * 
	 * @param u 設定情報単位(ユーザ / 会社共通 / システム共通 / バーコード)
	 * @return true : 削除後にも残っている or 登録もしくは更新を行った場合
	 */
	protected boolean isRemainedAfterDel(String settingUnitType) {
		ListDtlR r = getListDtlL().getFirst(ListDtlR.$setting_unit_type, settingUnitType);
		return r != null;
	}

	/**
	 * 設定対象の画面の状態をデフォルトに戻します。
	 */
	protected abstract void setTargetPanelDefault();
	
	/**
	 * デフォルトに戻す処理の後処理を実行します。
	 */
	protected void afterDef() {
		
	}
	
	/**
	 * デフォルトに戻す処理の完了メッセージを表示します。
	 */
	protected void showDefEndMsg() {
		dialog(FSBAC0005);
	}
	
	/**
	 * 登録ボタンの処理を実行します。
	 */
	protected void doUpdAction() {
		if (!execUpdComfirm() || !checkForUpd()) {
			return;
		}

		beforeUpd();
		doUpd();
		afterUpd();
		
		showUpdEndMsg();
	}

	/**
	 * 登録後適用ボタンの処理を実行します。
	 */
	protected void doUpdApplyAction() {
		if (!execUpdComfirm() || !checkForUpd()) {
			return;
		}

		beforeUpd();
		doUpd();
		afterUpd();
		
		showUpdEndMsg();
		
		beforeApply();
		doApply();
		afterApply();
	}

	/**
	 * 登録処理の実行確認メッセージを表示します。<p>
	 * 登録処理を続行する場合は true を返します。
	 * 
	 * @return 登録処理を中断する場合は false
	 */
	protected boolean execUpdComfirm() {
		return confirm(FSBAC0063, 
				FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
				getListHdrR().setting_info_nm()) 
				== MCMessageBox.YES_OPTION;
	}

	/**
	 * 登録処理の実行可否を判断します。<p>
	 * 登録処理を続行する場合は true を返します。
	 * 
	 * @return 登録処理を中断する場合は false
	 */
	protected boolean checkForUpd() {
		// 空行のステータスをクリアする
		clearEmptyRowStatus(getListDtlL());
		
		// 設定情報の必須項目をチェックする
		MCMessageList l = checkReq(getListHdrR());
			
		// 設定情報の必須項目が入力されていない場合
		if (l.size() > 0) {
			message(l);
			return false;
		}
			
		// 有効な設定情報
		MCList<ListDtlR> el = exceptEmpty(getListDtlL());
		
		el = el.subList(ListDtlR.$setting_unit_type, getSettingR().setting_unit());
		
		// 有効な設定情報が存在しない場合
		if (el.size() == 0) {
			dialog(FSBAC0061);
			return false;
		}

		// 初期ＦＬＧが複数行に設定されている場合
		if (el.subList(ListDtlR.$init_flg, true).size() > 1) {
			dialog(FSBAC0060);
			return false;
		}

		// 設定情報名をチェックする
		MCList<ListDtlR> sl = el.subList(
				ListDtlR.$setting_info_nm, getListHdrR().setting_info_nm());
		sl.remove(ListDtlTable.getSelectedMCRow());
		
		// 設定情報名が重複している場合
		if (sl.size() > 0) {
			MCMessage m = new MCMessage(
					FSBAC0062, 
					FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(), 
					getListHdrR().setting_info_nm());
			m.setCauseRow(getListHdrR(), ListDtlR.$setting_info_nm);
			dialog(m);
			return false;
		}
		
		return true;
	}

	/**
	 * 登録処理の前処理を実行します。
	 */
	protected void beforeUpd() {
		
	}

	/**
	 * 登録処理を実行します。
	 */
	protected void doUpd() {
		writeResource();
	}

	/**
	 * 設定情報をリソースに保存します。
	 */
	protected abstract void writeResource();
	
	/**
	 * 登録処理の後処理を実行します。
	 */
	protected void afterUpd() {
		// コンテナのステータスをクリアする
		statusClear();
		
		String n = getListHdrR().setting_info_nm();
		
		// 初期値を設定（再検索）する
		setInitData();
		fillSpaceForOpen();
		
		MCList<ListDtlR> l = getListDtlL().subList(
				ListDtlR.$setting_info_nm, n);
		if (l.size() > 0) {
			ListDtlTable.selectLeftmostColumn(l.get(0).getGUIIndex());
		}
		
	}

	/**
	 * 登録処理の完了メッセージを表示します。
	 */
	protected void showUpdEndMsg() {
		dialog(FXBAP0021);
	}

	/**
	 * 削除ボタンの処理を実行します。
	 */
	protected void doDelAction() {
		// 削除後に設定情報がなくなる場合は、デフォルトの処理を実行する
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		
		if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(getSettingR().setting_unit())) {
			MCList<ListDtlR> el = createListDtlL();
			for (ListDtlR o : getListDtlL()) {
				if (o == s) {
					continue;
				}
				if (o.isEmpty() || !getSettingInfoMap().containsKey(
						MCConst.createKey(o.setting_unit_type(), o.setting_info_id()))) {
					continue;
				}
				el.add(o);
			}
			if (el.size() == 0) {
				doDefAction();
				return;
			}
		}
		
		if (!execDelComfirm() || !checkForDel()) {
			return;
		}
		
		beforeDel();
		doDel();
		afterDel();
		
		showDelEndMsg();
	}
	
	/**
	 * 削除処理の実行確認メッセージを表示します。<p>
	 * 削除処理を続行する場合は true を返します。
	 * 
	 * @return 削除処理を中断する場合は false
	 */
	protected boolean execDelComfirm() {
		if (!getListHdrR().isStatusNone() || isInfoDataChanged()) {
			if (confirm(FXBAP0034) != MCMessageBox.YES_OPTION) {
				return false;
			}
			ListDtlR s = ListDtlTable.getSelectedMCRow();
			setInitListData(s);
			setInitInfoData(s);
		}

		MCMessage m = new MCMessage(FSBAC0064, 
				FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
				getListHdrR().setting_info_nm());
		return confirm(MCDialogButton.NO, m) == MCMessageBox.YES_OPTION;
	}
	
	protected abstract boolean isInfoDataChanged();
	
	/**
	 * 削除処理の実行可否を判断します。
	 * 削除処理を続行する場合は true を返します。
	 * 
	 * @return 削除処理を中断する場合は false
	 */
	protected boolean checkForDel() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s == null) {
			dialog(FXBAP0035);
			return false;
		}
		return true;
	}
	
	/**
	 * 削除処理の前処理を実行します。
	 */
	protected void beforeDel() {
		
	}

	/**
	 * 削除処理を実行します。
	 */
	protected void doDel() {
		// 削除対象行を削除する
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		getListDtlL().remove(s);
		
		clearSelection(ListDtlTable);
		
		writeResource();
	}
	
	/**
	 * 削除処理の後処理を実行します。
	 */
	protected void afterDel() {
		// コンテナのステータスをクリアする
		statusClear();
		
		// 初期値を設定（再検索）する
		setInitData();
		fillSpaceForOpen();

		setOpenFocus();
	}
	
	protected void showDelEndMsg() {
		dialog(FXBAP0022);
	}
	
	@Override
	protected void valueInit() {
		super.valueInit();
		
		setInitData();
	}

	/**
	 * この画面の情報を初期化します。
	 */
	protected void setInitData() {
		getListDtlL().clear();
		getListHdrR().clearAll();
	}
	
	/**
	 * 設定情報を初期化します。
	 * 
	 * @param data 設定情報
	 */
	protected void setInitListData(ListDtlR data) {
		WBP_PersonalizeInfo pi = getSettingInfo(data);
		if (pi != null) {
			ListDtlR c1 = pi.getSettingInfo();
			data.setValues(ListDtlR.colnames(), c1, ListDtlR.colnames());
			data.setStatus(MCRow.NONE);
		}
		else {
			data.clearAll();
			data.setStatus(MCRow.GUICREATE);
		}
	}
	
	/**
	 * 設定情報の詳細情報を初期化します。
	 * 
	 * @param data 設定情報
	 */
	protected void setInitInfoData(ListDtlR data) {
		
	}
	
	protected WBP_PersonalizeInfo getSettingInfo(ListDtlR data) {
		String k = MCConst.createKey(data.setting_unit_type(), data.setting_info_id());
		Map<String, WBP_PersonalizeInfo> m = getSettingInfoMap();
		if (m.containsKey(k)) {
			return m.get(k);
		}
		return null;
	}
	
	@Override
	protected void tableInit() {
		super.tableInit();

		ListDtlTable.setSortable(false);
	}
	
	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();
		
		setArrangementCenter();
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();

		ListDtlTable.fillSpace();
	}	
	
	@Override
	public void setOpenFocus() {
		super.setOpenFocus();
		
		ListDtlTable.selectLeftmostColumn(0);
	}
	
	@Override
	public void screenClearBody() {
		String u = getSettingR().setting_unit();
		super.screenClearBody();
		getSettingR().setting_unit(u);
	}

	@Override
	public void setStatus(String status) {
		if (EDIT.equals(status)) {
			
			ListDtlR o = ListDtlTable.getSelectedMCRow();
			if (o != null) {
				String u = getSettingR().setting_unit();
				String y = o.setting_unit_type();
				if (!isNull(y) && !isSame(u, y)) {
					status = DISABLE;
				}
			}
		}
		
		super.setStatus(status);
		
		if (!isSettingUnitUserEnable()) {
			Setting_setting_PPanel.Setting_setting_unit_USER.setMode(MCMode.READ_ONLY);
		}
		if (!isSettingUnitExtEnable()) {
			Setting_setting_PPanel.Setting_setting_unit_EXT.setMode(MCMode.READ_ONLY);
		}
		if (!isSettingUnitSysEnable()) {
			Setting_setting_PPanel.Setting_setting_unit_SYS.setMode(MCMode.READ_ONLY);
		}
		
	}
	
	protected boolean isSettingUnitUserEnable() {
		return true;
	}
	
	protected boolean isSettingUnitExtEnable() {
		return ListBtn_upd_ext.authorize()
				&& isSearchedProgram(FXC_RESOURCE_SETTING_UNIT.TYPE_EXT.value(),
						MCGroupResource.PGM_ID_SYSTEM);
	}	

	protected boolean isSettingUnitSysEnable() {
		return ListBtn_upd_sys.authorize()
				&& isSearchedProgram(FXC_RESOURCE_SETTING_UNIT.TYPE_SYS.value(),
						MCGroupResource.PGM_ID_SYSTEM);
	}

	protected abstract boolean isSearchedProgram(String type, String pgmid);
	
	@Override
	public void doListDtl_init_flg_NC(MCEventInfo info) {
		super.doListDtl_init_flg_NC(info);
		
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s.init_flg()) {
			String y = getSettingR().setting_unit();
			
			for (ListDtlR o : getListDtlL()) {
				if (o != s && !o.isEmpty() 
						&& isSame(y, o.setting_unit_type())) {
					setValueEx(columnListDtl_init_flg, o.getGUIIndex(), false);
				}
			}
		}
		
	}
	
	@Override
	public void doListHdr_init_flg_NC(MCEventInfo info) {
		super.doListHdr_init_flg_NC(info);
		
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnListDtl_init_flg, 
					s.getGUIIndex(), getListHdrR().init_flg());
		}
	}

	@Override
	public void doListHdr_remark_LC(MCEventInfo info) {
		super.doListHdr_remark_LC(info);
		
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnListDtl_remark, 
					s.getGUIIndex(), getListHdrR().remark());
		}
		
	}

	@Override
	public void doListHdr_setting_info_nm_LC(MCEventInfo info) {
		super.doListHdr_setting_info_nm_LC(info);
		
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnListDtl_setting_info_nm, 
					s.getGUIIndex(), getListHdrR().setting_info_nm());
			
			if (isNull(s.setting_unit_type())) {
				s.setting_unit_type(getSettingR().setting_unit());
				FXC_RESOURCE_SETTING_UNIT.putNameNE(s, 
						ListDtlR.$setting_unit_type, 
						ListDtlR.$setting_unit_type_nm);
			}
		}
		
	}
	
	@Override
	protected void listenerInit() {
		super.listenerInit();
		
		Setting_setting_PPanel.Setting_setting_unit_Group.addVCListener(this);
		Setting_setting_PPanel.Setting_setting_unit_Group.addNCListener(this);
	}

	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		
		if (vc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			return doSetting_setting_unit_VC(info);
		}
		return true;
	}

	protected boolean doSetting_setting_unit_VC(MCEventInfo info) {
		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}
		
		return true;
	}

	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		
		if (nc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			doSetting_setting_unit_NC(info);
		}
	}

	protected void doSetting_setting_unit_NC(MCEventInfo info) {
		valueInit();
		fillSpaceForOpen();
		setOpenFocus();
	}

	/**
	 * 空行のステータスをクリアします。
	 * 
	 * @param lists リスト
	 */
	protected void clearEmptyRowStatus(MCList<?>... lists) {
		for (MCList<?> l : lists) {
			for (MCRow o : l) {
				if (o.isEmpty()) {
					o.clearAll();
					o.setStatus(MCRow.GUICREATE);
				}
			}
		}
	}

	/**
	 * 旧仕様の設定情報の設定情報名の接頭辞を返します。
	 * 
	 * @return 旧仕様の設定情報の設定情報名の接頭辞
	 */
	protected String getPreviousSettingNamePrefix() {
		String[][] msa = getModuleAndScreenIDs();
		for (String[] ms : msa) {
			String k = MCConst.createKey(
					ms[0], ms[1], "previous_setting_name_prefix");
			if (MCConst.label.containsKey(k)) {
				return MCConst.label.getLabel(k);
			}
		}
		return null;
	}
	
	/**
	 * プログラムによる設定情報の設定情報名を返します。
	 *
	 * @return プログラムによる設定情報の設定情報名
	 */
	protected String getDefaultSettingName() {
		String[][] msa = getModuleAndScreenIDs();
		for (String[] ms : msa) {
			String k = MCConst.createKey(
					ms[0], ms[1], "default_setting_name");
			if (MCConst.label.containsKey(k)) {
				return MCConst.label.getLabel(k);
			}
		}
		return null;
	}
	
	/**
	 * プログラムによる設定情報の設定情報ＩＤを返します。
	 * 
	 * @return プログラムによる設定情報の設定情報ＩＤ
	 */
	protected String getPgmSettingInfoID() {
		return "PGM_SETTING_INFO";
	}

	/**
	 * 設定情報ＩＤと設定情報のマップを返します。
	 * 
	 * @return 設定情報ＩＤと設定情報のマップ
	 */
	protected Map<String, WBP_PersonalizeInfo> getSettingInfoMap() {
		return _setting_info_map;
	}
	
	/**
	 * 設定情報を格納します。
	 */
	public abstract class WBP_PersonalizeInfo {
		
		/**
		 * 設定情報です。
		 */
		protected ListDtlR _setting_info = null;
		
		/**
		 * コンストラクタです。
		 */
		public WBP_PersonalizeInfo() {}
		
		/**
		 * 設定情報を設定します。
		 * 
		 * @param info 設定情報
		 */
		public void setSettingInfo(ListDtlR info) {
			_setting_info = info;
		}
		
		/**
		 * 設定情報を返します。<p>
		 * 設定情報が設定されていない場合は null を返します。
		 * 
		 * @return 設定情報、または null
		 */
		public ListDtlR getSettingInfo() {
			return _setting_info;
		}
		
	}
	
	@Override
	protected void setCellConfig() {
		super.setCellConfig();
		
		ListDtlTable.setCellConfig(createListDtlCellConfig());
	}
	
	/**
	 * 設定情報一覧テーブルに設定するセルコンフィグを作成します。
	 * 
	 * @return 設定情報一覧テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createListDtlCellConfig() {
		return new WBP_ListDtlCellConfig();
	}
	
	/**
	 * 設定情報一覧テーブルに設定するセルコンフィグです。
	 */
	public class WBP_ListDtlCellConfig extends FXBAP_CellConfig {
		
		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {

			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}

			if (column == columnListDtl_init_flg) {
				ListDtlR o = getListDtlL().get(index);
				if (o.isEmpty() || o.isStatusDelete() 
						|| isNull(o.setting_info_nm())) {
					return MCMode.READ_ONLY;
				}
			}
			
			return super.getPriorMode(index, column, table);
			
		}
		
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	protected int getMaxSettingInfoNO() {
		int n = -1;
		for (ListDtlR o : getListDtlL()) {
			n = Math.max(n, getSettingInfoNO(o));
		}
		return n;
	}
	
	protected abstract int getSettingInfoNO(ListDtlR data);

	protected SettingR getSettingR() {
		return Setting_setting_PPanel.getSettingR();
	}

}