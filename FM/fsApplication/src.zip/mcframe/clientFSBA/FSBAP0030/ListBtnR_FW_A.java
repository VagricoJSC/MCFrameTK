package mcframe.clientFSBA.FSBAP0030;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ListBtn"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListBtnR_FW_A extends MCConstRow {

	/**
	 *  初期設定情報ＩＤ.<p>
	 *
	 */
	public static final String $init_setting_info_id = "init_setting_info_id";
	/**
	 *  初期設定情報名.<p>
	 *
	 */
	public static final String $init_setting_info_nm = "init_setting_info_nm";


	public static final MCMeta init_setting_info_id_META = createStringMeta($init_setting_info_id);
	public static final MCMeta init_setting_info_nm_META = createStringMeta($init_setting_info_nm);

	protected static final ConstMetaList<ListBtnR> constMetas = new ConstMetaList<ListBtnR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			init_setting_info_id_META,
			init_setting_info_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListBtnR_FW_A(ConstMetaList<? extends ListBtnR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListBtnR clone() {
		return (ListBtnR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListBtnR createInstance() {
		return (ListBtnR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListBtnR getValues(String... names) {
		return (ListBtnR) super.getValues(names);
	}



	/**
	 *  初期設定情報ＩＤ.<p>
	 *
	 */
	public String init_setting_info_id() {
		return getConstString(offset + 0, $init_setting_info_id);
	}

	/**
	 *  初期設定情報ＩＤ.<p>
	 *
	 */
	public void init_setting_info_id(String value) {
		setConstString(offset + 0, $init_setting_info_id, value);
	}


	/**
	 *  初期設定情報名.<p>
	 *
	 */
	public String init_setting_info_nm() {
		return getConstString(offset + 1, $init_setting_info_nm);
	}

	/**
	 *  初期設定情報名.<p>
	 *
	 */
	public void init_setting_info_nm(String value) {
		setConstString(offset + 1, $init_setting_info_nm, value);
	}


	public String getString(String name) {
		if ($init_setting_info_id.equalsIgnoreCase(name)) {
			return init_setting_info_id();
		}
		if ($init_setting_info_nm.equalsIgnoreCase(name)) {
			return init_setting_info_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($init_setting_info_id.equalsIgnoreCase(name)) {
			return init_setting_info_id();
		}
		if ($init_setting_info_nm.equalsIgnoreCase(name)) {
			return init_setting_info_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($init_setting_info_id.equalsIgnoreCase(name)) {
			init_setting_info_id(value);
			return;
		}
		if ($init_setting_info_nm.equalsIgnoreCase(name)) {
			init_setting_info_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($init_setting_info_id.equalsIgnoreCase(name)) {
			init_setting_info_id(value);
			return;
		}
		if ($init_setting_info_nm.equalsIgnoreCase(name)) {
			init_setting_info_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

