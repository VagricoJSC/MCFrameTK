package mcframe.clientFSBA.FSBAP0050;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0060.*;
import mcframe.clientFSBA.FSBAP0070.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientFSBA.FSBAP0000.IfCalendarDatePanel;
import mcframe.clientFSBA.FSBAP0000.IfCalendarMonthPanel;
import mcframe.clientFSBA.FSBAP0000.IfCalendarPanel;

import mcframe.clientCore.beans.popup.MCCalendarPopup;
import mcframe.clientCore.beans.text.MCCalendarValidator;

import mcframe.clientCore.beans.popup.MCPopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0050"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0050_FW extends FSBAP0050_FW_A implements IfCalendarPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * カレンダポップアップです。
	 */
	private MCCalendarPopup popup;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0050_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void requestCloseWindow() {
		if (!getCalendarPopup().addedToLayerdPane()) {
			getCalendarPopup().setVisible(false);
		}
		else {
			Component c = (Component)getCalendarPopup().getCalendarBeans();
			getCalendarPopup().setVisible(false);
			c.requestFocus();
		}
	}

	public void setCalendarPopup(MCCalendarPopup popup) {
		this.popup = popup;
		
		getMonthPanel().setCalendarPopup(popup);
	}
	
	public MCCalendarPopup getCalendarPopup() {
		return popup;
	}
	
	public void setButtonDate(MCButton compo, MCCalendarDate<?> value) {
		compo.setMode(getMode(compo, value));
		compo.setForeground(getForeground(compo, value));
		compo.setBackground(getBackground(compo, value));
		compo.setText(String.valueOf(value.getDay()));
	}
	
	/**
	 * 日付ボタンの文字の色を返します。
	 * 
	 * @param compo 日付ボタン
	 * @param value 日付
	 * @return 文字の色
	 */
	protected Color getForeground(MCButton compo, MCCalendarDate<?> value) {
		if (value.getMonth() == getCalendarPopup().getCurrentDate().getMonth()) {
			switch (value.getDayOfWeek()) {
				case MCDate.SUNDAY:
					return Color.RED;
				case MCDate.SATURDAY:
					return Color.BLUE;
				default:
					return Color.BLACK;
			}
		}
		switch (value.getDayOfWeek()) {
			case MCDate.SUNDAY:
				return new Color(255, 100, 100);
			case MCDate.SATURDAY:
				return new Color(100, 100, 255);
			default:
				return Color.GRAY;
		}
	}
	
	/**
	 * 日付ボタンの背景色を返します。
	 * 
	 * @param compo 日付ボタン
	 * @param value 日付
	 * @return 背景色
	 */
	protected Color getBackground(MCButton compo, MCCalendarDate<?> value) {
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 色を指定しないと背景色になるため指定する。
		return Color.WHITE;
//		return null;
	}
	
	/**
	 * 日付ボタンのモードを返します。
	 * 
	 * @param compo 日付ボタン
	 * @param value 日付
	 * @return モード
	 */
	protected MCMode getMode(MCButton compo, MCCalendarDate<?> value) {
		MCCalendarValidator v = 
				getCalendarPopup().getCalendarBeans().getCalendarValidator();
		return v.checkDate(value) ? MCMode.ENABLE : MCMode.DISABLE;
	}
	
	public IfCalendarMonthPanel getMonthPanel() {
		return Calendar_Month_PPanel;
	}
	
	public IfCalendarDatePanel getDatePanel() {
		return Calendar_Date_PPanel;
	}

	@Override
	protected void customInit() {
		super.customInit();
	
		MCPopupConfig c = new MCPopupConfig();
		c.ignorePanelPopup(true);
		setPopupConfig(c);
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected void updatedResourceColor() {
		// 背景色設定不要
//		super.updatedResourceColor();
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	// 7013-0007 ここまで

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	/**
	 * MCLayouterの指定文字列を返します。
	 */
	@Override
	public String getLayoutKey() {
		return "S";
	}
}