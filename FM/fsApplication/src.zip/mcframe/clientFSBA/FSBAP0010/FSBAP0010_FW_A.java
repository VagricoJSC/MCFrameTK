package mcframe.clientFSBA.FSBAP0010;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0010"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0010_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0010";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Command]ブロック関連のField定義
	public MCPanel CommandPanel = null;
	// [Command]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H Command_row_move_p_PPanel;
	/**
	 *  デフォルト.<p>
	 *
	 */
	public MCButton Command_Default = null;
	/**
	 *  設定.<p>
	 *
	 */
	public MCButton Command_OK = null;
	/**
	 *  キャンセル.<p>
	 *
	 */
	public MCButton Command_Cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [FIX]モードを表す定数 */
	public static final String FIX = "FIX";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, FIX};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CommandPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0010_FW_A() {

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0010_FW.jbCreateCommand((FSBAP0010)this);
	}

	/**
	 * [Command]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommand(FSBAP0010 p) {
		p.Command_row_move_p_PPanel = mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.create();
		p.Command_row_move_p_PPanel.setName("Command.row_move_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0010 create(){
		FSBAP0010 p = new FSBAP0010();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0010_FW.jbfInitCommand((FSBAP0010)this);
		FSBAP0010_FW.jbInitCommand((FSBAP0010)this);
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommand(FSBAP0010 p) {
		// ブロック関連の初期化
		p.CommandPanel = p.beansFactory.createPanel("Command");
		// ブロックの項目の初期化
		p.Command_Default = p.beansFactory.createButton("Command.Default");
		p.Command_OK = p.beansFactory.createButton("Command.OK");
		p.Command_Cancel = p.beansFactory.createButton("Command.Cancel");
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommand(FSBAP0010 p) {
		// ブロック関連の初期化
		p.add(p.CommandPanel);
		p.setLastBeans(p.CommandPanel);
		// ブロックの項目の初期化
		p.CommandPanel.add(p.Command_row_move_p_PPanel);
		p.CommandPanel.setLastBeans(p.Command_row_move_p_PPanel);
		p.Command_row_move_p_PPanel.setNextBeans(p.Command_Default);
		p.Command_Default.setFunctionKey(MCFunctionKey.F3);
		p.CommandPanel.add(p.Command_Default);
		p.Command_Default.setNextBeans(p.Command_OK);
		p.Command_OK.setFunctionKey(MCFunctionKey.F9);
		p.CommandPanel.add(p.Command_OK);
		p.Command_OK.setNextBeans(p.Command_Cancel);
		p.Command_Cancel.setFunctionKey(MCFunctionKey.F11);
		p.CommandPanel.add(p.Command_Cancel);
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0010_FW.mcInitCommand((FSBAP0010)this);

		// [INIT]ステータスのモードの設定
		FSBAP0010_FW.statusInitINIT_Command((FSBAP0010)this);

		// [FIX]ステータスのモードの設定
		FSBAP0010_FW.statusInitFIX_Command((FSBAP0010)this);

	}

	/**
	 *  [Command]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommand(FSBAP0010 p) {
		p.Command_Default.addAllListener(p);
		p.Command_Default.setAPMethodName("doCommand_Default");
		p.Command_OK.addAllListener(p);
		p.Command_OK.setAPMethodName("doCommand_OK");
		p.Command_Cancel.addAllListener(p);
		p.Command_Cancel.setAPMethodName("doCommand_Cancel");
	}

	/**
	 * [INIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Command(FSBAP0010 p){
		p.Command_row_move_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.ENABLE);
		p.Command_Default.putMode(p, INIT, MCMode.ENABLE);
		p.Command_OK.putMode(p, INIT, MCMode.ENABLE);
		p.Command_Cancel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Command(FSBAP0010 p){
		p.Command_row_move_p_PPanel.putStatus(FIX, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[FIX]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setFIXStatus() {
		status = FIX;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (FIX.equals(status)) {
			setFIXStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Command_Default) doCommand_Default(info);
		else if (ap == Command_OK) doCommand_OK(info);
		else if (ap == Command_Cancel) doCommand_Cancel(info);
	}

	/**
	 * [Command]パネルの[Default]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Default(MCEventInfo info);

	/**
	 * [Command]パネルの[OK]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_OK(MCEventInfo info);

	/**
	 * [Command]パネルの[Cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}