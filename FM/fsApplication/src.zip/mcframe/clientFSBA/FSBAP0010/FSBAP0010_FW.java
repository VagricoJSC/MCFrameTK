package mcframe.clientFSBA.FSBAP0010;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0060.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientFSBA.FSBAP0000.IfPersonalizePanel;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0010"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0010_FW extends FSBAP0010_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0010_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Command]のボタン[Default]の押下時の処理
	 */
	public void doCommand_Default(MCEventInfo info) {
		getPersonalizePanel().doDefaultAction();
	}

	/**
	 * Panel[Command]のボタン[Cancel]の押下時の処理
	 */
	public void doCommand_Cancel(MCEventInfo info) {
		getPersonalizePanel().doCancelAction();
	}

	/**
	 * Panel[Command]のボタン[OK]の押下時の処理
	 */
	public void doCommand_OK(MCEventInfo info) {
		getPersonalizePanel().doDecisionAction();
	}

	/**
	 * この画面が配置されている画面を返します。
	 * この画面が埋込画面ではない場合や、
	 * この画面が IfPersonalizePanel に配置されていない場合は null を返します。
	 *
	 * @return 画面または null
	 */
	protected IfPersonalizePanel getPersonalizePanel() {
		MCRootPanel p = getUnderPanel();
		return p instanceof IfPersonalizePanel ? (IfPersonalizePanel)p : null;
	}
		
	/**
	 * 初期フォーカスを設定します。
	 */
	public void setInitFocus() {
		Command_OK.mcRequestFocus();
	}

}