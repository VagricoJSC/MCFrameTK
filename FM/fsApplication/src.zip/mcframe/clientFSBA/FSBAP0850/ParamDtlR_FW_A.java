package mcframe.clientFSBA.FSBAP0850;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ParamDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ParamDtlR_FW_A extends MCConstRow {

	/**
	 * タスクＩＤ .<p>
	 *
	 */
	public static final String $task_id = "task_id";
	/**
	 * プロパティキー .<p>
	 *
	 */
	public static final String $key = "key";
	/**
	 * プロパティ値 .<p>
	 *
	 */
	public static final String $value = "value";


	public static final MCMeta task_id_META = createCommonMeta($task_id, mcframe.commonCore.meta.M_META.MINING_TASK_ID);
	public static final MCMeta key_META = createCommonMeta($key, mcframe.commonCore.meta.M_META.RES_KEY);
	public static final MCMeta value_META = createCommonMeta($value, mcframe.commonCore.meta.M_META.RES_VAL);

	protected static final ConstMetaList<ParamDtlR> constMetas = new ConstMetaList<ParamDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			task_id_META,
			key_META,
			value_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ParamDtlR_FW_A(ConstMetaList<? extends ParamDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ParamDtlR clone() {
		return (ParamDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ParamDtlR createInstance() {
		return (ParamDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ParamDtlR getValues(String... names) {
		return (ParamDtlR) super.getValues(names);
	}



	/**
	 * タスクＩＤ .<p>
	 *
	 */
	public String task_id() {
		return getConstString(offset + 0, $task_id);
	}

	/**
	 * タスクＩＤ .<p>
	 *
	 */
	public void task_id(String value) {
		setConstString(offset + 0, $task_id, value);
	}


	/**
	 * プロパティキー .<p>
	 *
	 */
	public String key() {
		return getConstString(offset + 1, $key);
	}

	/**
	 * プロパティキー .<p>
	 *
	 */
	public void key(String value) {
		setConstString(offset + 1, $key, value);
	}


	/**
	 * プロパティ値 .<p>
	 *
	 */
	public String value() {
		return getConstString(offset + 2, $value);
	}

	/**
	 * プロパティ値 .<p>
	 *
	 */
	public void value(String value) {
		setConstString(offset + 2, $value, value);
	}


	public String getString(String name) {
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($value.equalsIgnoreCase(name)) {
			return value();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($value.equalsIgnoreCase(name)) {
			return value();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($value.equalsIgnoreCase(name)) {
			value(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($value.equalsIgnoreCase(name)) {
			value(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

