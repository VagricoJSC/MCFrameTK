package mcframe.clientFSBA.FSBAP0850;

import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.clientFXBA.FXBAP0150.ConditionEditor;
import mcframe.commonCore.container.MCList;


/**
 * マイニングタスクのパラメータ編集用の部品です。
 * 
 */
public interface TaskParamEditor extends ConditionEditor {

	/**
	 * この部品用のパラメータオブジェクトを生成します。
	 *
	 * <p>
	 * 複数のオブジェクトを生成する場合、戻り値の順序は
	 * {@link #setParam(MCValueSupply...)}などの順序と同じになります。
	 *
	 * @return パラメータオブジェクト
	 */
	public MCValueSupply[] createParam() ;

	/**
	 * この部品用のコンボリストを生成します。
	 *
	 * <p>
	 * 戻り値の ListR の gkey は使用しないため、値は null です。
	 *
	 * @param params パラメータオブジェクト
	 * @param condL マイニング定義の検索条件
	 * @param methodL マイニング定義の集計情報
	 * @param paramL マイニングタスクのパラメータ
	 * @return コンボリスト
	 */
	public default MCList<ListR> createComboList(
			MCValueSupply[] params,
			MCList<CondDtlR> condL,
			MCList<MethodDtlR> methodL,
			MCList<ParamDtlR> paramL
	) {
		return null;
	}

}