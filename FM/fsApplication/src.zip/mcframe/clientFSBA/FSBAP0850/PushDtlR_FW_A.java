package mcframe.clientFSBA.FSBAP0850;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"PushDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class PushDtlR_FW_A extends MCConstRow {

	/**
	 *  id,ＩＤ指定;edit,直接入力.<p>
	 *
	 */
	public static final String $msg_type = "msg_type";
	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public static final String $msg_id = "msg_id";
	/**
	 *  メッセージ.<p>
	 *
	 */
	public static final String $msg = "msg";
	/**
	 *  通知方法種別.<p>
	 *
	 */
	public static final String $push_type = "push_type";
	/**
	 *  通知方法.<p>
	 *
	 */
	public static final String $push_type_nm = "push_type_nm";
	/**
	 *  重要で送信.<p>
	 *
	 */
	public static final String $push_imp = "push_imp";


	public static final MCMeta msg_type_META = createStringMeta($msg_type, 1);
	public static final MCMeta msg_id_META = createCommonMeta($msg_id, mcframe.commonCore.meta.M_META.MSG_ID);
	public static final MCMeta msg_META = createCommonMeta($msg, mcframe.commonCore.meta.M_META.MSG);
	public static final MCMeta push_type_META = createCommonMeta($push_type, mcframe.commonCore.meta.M_META.PUSH_TYPE);
	public static final MCMeta push_type_nm_META = createCommonMeta($push_type_nm, mcframe.commonCore.meta.M_META.PUSH_TYPE_NM);
	public static final MCMeta push_imp_META = createCommonMeta($push_imp, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<PushDtlR> constMetas = new ConstMetaList<PushDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			msg_type_META,
			msg_id_META,
			msg_META,
			push_type_META,
			push_type_nm_META,
			push_imp_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected PushDtlR_FW_A(ConstMetaList<? extends PushDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PushDtlR clone() {
		return (PushDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PushDtlR createInstance() {
		return (PushDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PushDtlR getValues(String... names) {
		return (PushDtlR) super.getValues(names);
	}



	/**
	 *  id,ＩＤ指定;edit,直接入力.<p>
	 *
	 */
	public String msg_type() {
		return getConstString(offset + 0, $msg_type);
	}

	/**
	 *  id,ＩＤ指定;edit,直接入力.<p>
	 *
	 */
	public void msg_type(String value) {
		setConstString(offset + 0, $msg_type, value);
	}


	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public String msg_id() {
		return getConstString(offset + 1, $msg_id);
	}

	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public void msg_id(String value) {
		setConstString(offset + 1, $msg_id, value);
	}


	/**
	 *  メッセージ.<p>
	 *
	 */
	public String msg() {
		return getConstString(offset + 2, $msg);
	}

	/**
	 *  メッセージ.<p>
	 *
	 */
	public void msg(String value) {
		setConstString(offset + 2, $msg, value);
	}


	/**
	 *  通知方法種別.<p>
	 *
	 */
	public String push_type() {
		return getConstString(offset + 3, $push_type);
	}

	/**
	 *  通知方法種別.<p>
	 *
	 */
	public void push_type(String value) {
		setConstString(offset + 3, $push_type, value);
	}


	/**
	 *  通知方法.<p>
	 *
	 */
	public String push_type_nm() {
		return getConstString(offset + 4, $push_type_nm);
	}

	/**
	 *  通知方法.<p>
	 *
	 */
	public void push_type_nm(String value) {
		setConstString(offset + 4, $push_type_nm, value);
	}


	/**
	 *  重要で送信.<p>
	 *
	 */
	public boolean push_imp() {
		return getConstBoolean(offset + 5, $push_imp);
	}

	/**
	 *  重要で送信.<p>
	 *
	 */
	public void push_imp(boolean value) {
		setConstBoolean(offset + 5, $push_imp, value);
	}


	public String getString(String name) {
		if ($msg_type.equalsIgnoreCase(name)) {
			return msg_type();
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			return msg_id();
		}
		if ($msg.equalsIgnoreCase(name)) {
			return msg();
		}
		if ($push_type.equalsIgnoreCase(name)) {
			return push_type();
		}
		if ($push_type_nm.equalsIgnoreCase(name)) {
			return push_type_nm();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($push_imp.equalsIgnoreCase(name)) {
			return push_imp();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($msg_type.equalsIgnoreCase(name)) {
			return msg_type();
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			return msg_id();
		}
		if ($msg.equalsIgnoreCase(name)) {
			return msg();
		}
		if ($push_type.equalsIgnoreCase(name)) {
			return push_type();
		}
		if ($push_type_nm.equalsIgnoreCase(name)) {
			return push_type_nm();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($push_imp.equalsIgnoreCase(name)) {
			return push_imp();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($msg_type.equalsIgnoreCase(name)) {
			msg_type(value);
			return;
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			msg_id(value);
			return;
		}
		if ($msg.equalsIgnoreCase(name)) {
			msg(value);
			return;
		}
		if ($push_type.equalsIgnoreCase(name)) {
			push_type(value);
			return;
		}
		if ($push_type_nm.equalsIgnoreCase(name)) {
			push_type_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($push_imp.equalsIgnoreCase(name)) {
			push_imp(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($msg_type.equalsIgnoreCase(name)) {
			msg_type(value);
			return;
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			msg_id(value);
			return;
		}
		if ($msg.equalsIgnoreCase(name)) {
			msg(value);
			return;
		}
		if ($push_type.equalsIgnoreCase(name)) {
			push_type(value);
			return;
		}
		if ($push_type_nm.equalsIgnoreCase(name)) {
			push_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($push_imp.equalsIgnoreCase(name)) {
			push_imp(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

