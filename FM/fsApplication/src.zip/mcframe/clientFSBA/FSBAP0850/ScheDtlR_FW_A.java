package mcframe.clientFSBA.FSBAP0850;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ScheDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ScheDtlR_FW_A extends MCConstRow {

	/**
	 *  無効.<p>
	 *
	 */
	public static final String $inv_flg = "inv_flg";
	/**
	 *  実行時刻.<p>
	 *
	 */
	public static final String $time = "time";
	/**
	 *  説明.<p>
	 *
	 */
	public static final String $desc = "desc";
	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public static final String $task_id = "task_id";
	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public static final String $sche_no = "sche_no";
	/**
	 *  時.<p>
	 *
	 */
	public static final String $hour = "hour";
	/**
	 *  分.<p>
	 *
	 */
	public static final String $minute = "minute";
	/**
	 *  月.<p>
	 *
	 */
	public static final String $month = "month";
	/**
	 *  日.<p>
	 *
	 */
	public static final String $day = "day";
	/**
	 *  週.<p>
	 *
	 */
	public static final String $week_no = "week_no";
	/**
	 *  曜日.<p>
	 *
	 */
	public static final String $week_day = "week_day";


	public static final MCMeta inv_flg_META = createCommonMeta($inv_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta time_META = createCommonMeta($time, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta desc_META = createStringMeta($desc);
	public static final MCMeta task_id_META = createCommonMeta($task_id, mcframe.commonCore.meta.M_META.MINING_TASK_ID);
	public static final MCMeta sche_no_META = createNumberMeta($sche_no);
	public static final MCMeta hour_META = createNumberMeta($hour);
	public static final MCMeta minute_META = createNumberMeta($minute);
	public static final MCMeta month_META = createNumberMeta($month);
	public static final MCMeta day_META = createNumberMeta($day);
	public static final MCMeta week_no_META = createNumberMeta($week_no);
	public static final MCMeta week_day_META = createNumberMeta($week_day);

	protected static final ConstMetaList<ScheDtlR> constMetas = new ConstMetaList<ScheDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			inv_flg_META,
			time_META,
			desc_META,
			task_id_META,
			sche_no_META,
			hour_META,
			minute_META,
			month_META,
			day_META,
			week_no_META,
			week_day_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ScheDtlR_FW_A(ConstMetaList<? extends ScheDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScheDtlR clone() {
		return (ScheDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScheDtlR createInstance() {
		return (ScheDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScheDtlR getValues(String... names) {
		return (ScheDtlR) super.getValues(names);
	}



	/**
	 *  無効.<p>
	 *
	 */
	public boolean inv_flg() {
		return getConstBoolean(offset + 0, $inv_flg);
	}

	/**
	 *  無効.<p>
	 *
	 */
	public void inv_flg(boolean value) {
		setConstBoolean(offset + 0, $inv_flg, value);
	}


	/**
	 *  実行時刻.<p>
	 *
	 */
	public MCDate time() {
		return getConstDate(offset + 1, $time);
	}

	/**
	 *  実行時刻.<p>
	 *
	 */
	public void time(MCDate value) {
		setConstDate(offset + 1, $time, value);
	}


	/**
	 *  説明.<p>
	 *
	 */
	public String desc() {
		return getConstString(offset + 2, $desc);
	}

	/**
	 *  説明.<p>
	 *
	 */
	public void desc(String value) {
		setConstString(offset + 2, $desc, value);
	}


	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public String task_id() {
		return getConstString(offset + 3, $task_id);
	}

	/**
	 *  タスクＩＤ.<p>
	 *
	 */
	public void task_id(String value) {
		setConstString(offset + 3, $task_id, value);
	}


	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public MCNumber sche_no() {
		return getConstNumber(offset + 4, $sche_no);
	}

	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public void sche_no(MCNumber value) {
		setConstNumber(offset + 4, $sche_no, value);
	}

	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public void sche_no(int value) {
		setConstNumber(offset + 4, $sche_no, value);
	}

	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public void sche_no(long value) {
		setConstNumber(offset + 4, $sche_no, value);
	}

	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public void sche_no(float value) {
		setConstNumber(offset + 4, $sche_no, value);
	}

	/**
	 *  スケジュール番号.<p>
	 *
	 */
	public void sche_no(double value) {
		setConstNumber(offset + 4, $sche_no, value);
	}


	/**
	 *  時.<p>
	 *
	 */
	public MCNumber hour() {
		return getConstNumber(offset + 5, $hour);
	}

	/**
	 *  時.<p>
	 *
	 */
	public void hour(MCNumber value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 *  時.<p>
	 *
	 */
	public void hour(int value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 *  時.<p>
	 *
	 */
	public void hour(long value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 *  時.<p>
	 *
	 */
	public void hour(float value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 *  時.<p>
	 *
	 */
	public void hour(double value) {
		setConstNumber(offset + 5, $hour, value);
	}


	/**
	 *  分.<p>
	 *
	 */
	public MCNumber minute() {
		return getConstNumber(offset + 6, $minute);
	}

	/**
	 *  分.<p>
	 *
	 */
	public void minute(MCNumber value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 *  分.<p>
	 *
	 */
	public void minute(int value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 *  分.<p>
	 *
	 */
	public void minute(long value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 *  分.<p>
	 *
	 */
	public void minute(float value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 *  分.<p>
	 *
	 */
	public void minute(double value) {
		setConstNumber(offset + 6, $minute, value);
	}


	/**
	 *  月.<p>
	 *
	 */
	public MCNumber month() {
		return getConstNumber(offset + 7, $month);
	}

	/**
	 *  月.<p>
	 *
	 */
	public void month(MCNumber value) {
		setConstNumber(offset + 7, $month, value);
	}

	/**
	 *  月.<p>
	 *
	 */
	public void month(int value) {
		setConstNumber(offset + 7, $month, value);
	}

	/**
	 *  月.<p>
	 *
	 */
	public void month(long value) {
		setConstNumber(offset + 7, $month, value);
	}

	/**
	 *  月.<p>
	 *
	 */
	public void month(float value) {
		setConstNumber(offset + 7, $month, value);
	}

	/**
	 *  月.<p>
	 *
	 */
	public void month(double value) {
		setConstNumber(offset + 7, $month, value);
	}


	/**
	 *  日.<p>
	 *
	 */
	public MCNumber day() {
		return getConstNumber(offset + 8, $day);
	}

	/**
	 *  日.<p>
	 *
	 */
	public void day(MCNumber value) {
		setConstNumber(offset + 8, $day, value);
	}

	/**
	 *  日.<p>
	 *
	 */
	public void day(int value) {
		setConstNumber(offset + 8, $day, value);
	}

	/**
	 *  日.<p>
	 *
	 */
	public void day(long value) {
		setConstNumber(offset + 8, $day, value);
	}

	/**
	 *  日.<p>
	 *
	 */
	public void day(float value) {
		setConstNumber(offset + 8, $day, value);
	}

	/**
	 *  日.<p>
	 *
	 */
	public void day(double value) {
		setConstNumber(offset + 8, $day, value);
	}


	/**
	 *  週.<p>
	 *
	 */
	public MCNumber week_no() {
		return getConstNumber(offset + 9, $week_no);
	}

	/**
	 *  週.<p>
	 *
	 */
	public void week_no(MCNumber value) {
		setConstNumber(offset + 9, $week_no, value);
	}

	/**
	 *  週.<p>
	 *
	 */
	public void week_no(int value) {
		setConstNumber(offset + 9, $week_no, value);
	}

	/**
	 *  週.<p>
	 *
	 */
	public void week_no(long value) {
		setConstNumber(offset + 9, $week_no, value);
	}

	/**
	 *  週.<p>
	 *
	 */
	public void week_no(float value) {
		setConstNumber(offset + 9, $week_no, value);
	}

	/**
	 *  週.<p>
	 *
	 */
	public void week_no(double value) {
		setConstNumber(offset + 9, $week_no, value);
	}


	/**
	 *  曜日.<p>
	 *
	 */
	public MCNumber week_day() {
		return getConstNumber(offset + 10, $week_day);
	}

	/**
	 *  曜日.<p>
	 *
	 */
	public void week_day(MCNumber value) {
		setConstNumber(offset + 10, $week_day, value);
	}

	/**
	 *  曜日.<p>
	 *
	 */
	public void week_day(int value) {
		setConstNumber(offset + 10, $week_day, value);
	}

	/**
	 *  曜日.<p>
	 *
	 */
	public void week_day(long value) {
		setConstNumber(offset + 10, $week_day, value);
	}

	/**
	 *  曜日.<p>
	 *
	 */
	public void week_day(float value) {
		setConstNumber(offset + 10, $week_day, value);
	}

	/**
	 *  曜日.<p>
	 *
	 */
	public void week_day(double value) {
		setConstNumber(offset + 10, $week_day, value);
	}


	public String getString(String name) {
		if ($desc.equalsIgnoreCase(name)) {
			return desc();
		}
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($sche_no.equalsIgnoreCase(name)) {
			return sche_no();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($week_no.equalsIgnoreCase(name)) {
			return week_no();
		}
		if ($week_day.equalsIgnoreCase(name)) {
			return week_day();
		}
		return super.getNumber(name);
	}
	public MCDate getDate(String name) {
		if ($time.equalsIgnoreCase(name)) {
			return time();
		}
		return super.getDate(name);
	}
	public boolean getBoolean(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($desc.equalsIgnoreCase(name)) {
			return desc();
		}
		if ($task_id.equalsIgnoreCase(name)) {
			return task_id();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($sche_no.equalsIgnoreCase(name)) {
			return sche_no();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($week_no.equalsIgnoreCase(name)) {
			return week_no();
		}
		if ($week_day.equalsIgnoreCase(name)) {
			return week_day();
		}
		return super.getNumberNE(name);
	}
	public MCDate getDateNE(String name) {
		if ($time.equalsIgnoreCase(name)) {
			return time();
		}
		return super.getDateNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($desc.equalsIgnoreCase(name)) {
			desc(value);
			return;
		}
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setDate(String name, MCDate value) {
		if ($time.equalsIgnoreCase(name)) {
			time(value);
			return;
		}
		super.setDate(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($desc.equalsIgnoreCase(name)) {
			desc(value);
			return;
		}
		if ($task_id.equalsIgnoreCase(name)) {
			task_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($sche_no.equalsIgnoreCase(name)) {
			sche_no(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($week_no.equalsIgnoreCase(name)) {
			week_no(value);
			return;
		}
		if ($week_day.equalsIgnoreCase(name)) {
			week_day(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setDateNE(String name, MCDate value) {
		if ($time.equalsIgnoreCase(name)) {
			time(value);
			return;
		}
		super.setDateNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

