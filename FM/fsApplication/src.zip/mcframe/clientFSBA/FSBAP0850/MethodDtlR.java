package mcframe.clientFSBA.FSBAP0850;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.annotation.EI;

/**
 * ブロック"MethodDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * <table border=1 cellspacing=0 cellpadding=2 >
 *  <caption>[項目定義]</caption>
 * 	<tr bgcolor="#cccccc">
 *  	<th>alias</th>
 *  	<th>項目名</th>
 *  	<th>フルネーム</th>
 *  	<th>型</th>
 *  	<th>桁</th>
 *  	<th>INNERROW/COLUMNPATH</th>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>mining_id</td>
 *  	<td>マイニングＩＤ</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#MINING_ID MINING_ID}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>col_id</td>
 *  	<td>項目名</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#RES_KEY RES_KEY}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>col_nm</td>
 *  	<td>表示名称</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#RES_VAL RES_VAL}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>list_order</td>
 *  	<td>表示順</td>
 *  	<td>Number</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#SORT_ORDER SORT_ORDER}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>sum_info_typ</td>
 *  	<td>集計区分</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#SUM_INFO_TYP SUM_INFO_TYP}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>sumcond</td>
 *  	<td>集計条件名</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#RES_VAL RES_VAL}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>rank_flg</td>
 *  	<td>順位ＦＬＧ</td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>rank_typ</td>
 *  	<td>順位ソート区分</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#SORT_TYP SORT_TYP}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>rank_size</td>
 *  	<td>有効順位</td>
 *  	<td>Number</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#INT INT}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>date_fmt</td>
 *  	<td>日時書式</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#RES_VAL RES_VAL}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>fill_dt_flg</td>
 *  	<td>日時補完ＦＬＧ</td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>fill_dt_fm</td>
 *  	<td>日時補完開始日時</td>
 *  	<td>Timestamp</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#TS TS}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>fill_dt_to</td>
 *  	<td>日時補完終了日時</td>
 *  	<td>Timestamp</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#TS TS}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>formula</td>
 *  	<td>計算式</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FORMULA FORMULA}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>dec_place</td>
 *  	<td>小数部有効桁数</td>
 *  	<td>Number</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#DEC_PLACE DEC_PLACE}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>round_mode_typ</td>
 *  	<td>端数処理区分</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#ROUND_MODE_TYP ROUND_MODE_TYP}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>null_zero</td>
 *  	<td>NULL集計0変換</td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>sort_order</td>
 *  	<td>ソート順</td>
 *  	<td>Number</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#SORT_ORDER SORT_ORDER}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>sort_typ</td>
 *  	<td>ソート区分</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#SORT_TYP SORT_TYP}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>graph_typ</td>
 *  	<td>グラフ種類</td>
 *  	<td>Number</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#GRAPH_TYP GRAPH_TYP}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>graph_label_flg</td>
 *  	<td>グラフ行ラベルＦＬＧ</td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>graph_color</td>
 *  	<td>グラフ色</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#COLOR COLOR}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>inv_flg</td>
 *  	<td>無効ＦＬＧ</td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 * </table>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class MethodDtlR extends MethodDtlR_FW_A {

	/**
	 * 新しいRowを生成します。
	 *
	 * @return 新しいインスタンス
	 */
	public static MethodDtlR create() {
		MethodDtlR row = new MethodDtlR(constMetas);
		return row;
	}

	/**
	 * 新しいRowを生成し別のRowの内容を設定します。
	 *
	 * @param proto 設定するRow
	 * @return 内容を設定した新しいインスタンス
	 */
	public static <T extends MCRow> MethodDtlR createByName(T proto) {
		MethodDtlR row = MethodDtlR.create();
		copyByName(row, proto);
		return row;
	}

	/**
	 * コンストラクタです。
	 */
	public MethodDtlR(ConstMetaList<? extends MethodDtlR> metas) {
		super(metas);
	}
}