package mcframe.clientFSBA.FSBAP0850;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"MethodDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MethodDtlR_FW_A extends MCConstRow {

	/**
	 * マイニングＩＤ .<p>
	 *
	 */
	public static final String $mining_id = "mining_id";
	/**
	 * 項目名 .<p>
	 *
	 */
	public static final String $col_id = "col_id";
	/**
	 * 表示名称 .<p>
	 *
	 */
	public static final String $col_nm = "col_nm";
	/**
	 * 表示順 .<p>
	 *
	 */
	public static final String $list_order = "list_order";
	/**
	 * 集計区分 .<p>
	 *
	 */
	public static final String $sum_info_typ = "sum_info_typ";
	/**
	 * 集計条件名 .<p>
	 *
	 */
	public static final String $sumcond = "sumcond";
	/**
	 * 順位ＦＬＧ .<p>
	 *
	 */
	public static final String $rank_flg = "rank_flg";
	/**
	 * 順位ソート区分 .<p>
	 *
	 */
	public static final String $rank_typ = "rank_typ";
	/**
	 * 有効順位 .<p>
	 *
	 */
	public static final String $rank_size = "rank_size";
	/**
	 * 日時書式 .<p>
	 *
	 */
	public static final String $date_fmt = "date_fmt";
	/**
	 * 日時補完ＦＬＧ .<p>
	 *
	 */
	public static final String $fill_dt_flg = "fill_dt_flg";
	/**
	 * 日時補完開始日時 .<p>
	 *
	 */
	public static final String $fill_dt_fm = "fill_dt_fm";
	/**
	 * 日時補完終了日時 .<p>
	 *
	 */
	public static final String $fill_dt_to = "fill_dt_to";
	/**
	 * 計算式 .<p>
	 *
	 */
	public static final String $formula = "formula";
	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public static final String $dec_place = "dec_place";
	/**
	 * 端数処理区分 .<p>
	 *
	 */
	public static final String $round_mode_typ = "round_mode_typ";
	/**
	 * NULL集計0変換 .<p>
	 *
	 */
	public static final String $null_zero = "null_zero";
	/**
	 * ソート順 .<p>
	 *
	 */
	public static final String $sort_order = "sort_order";
	/**
	 * ソート区分 .<p>
	 *
	 */
	public static final String $sort_typ = "sort_typ";
	/**
	 * グラフ種類 .<p>
	 *
	 */
	public static final String $graph_typ = "graph_typ";
	/**
	 * グラフ行ラベルＦＬＧ .<p>
	 *
	 */
	public static final String $graph_label_flg = "graph_label_flg";
	/**
	 * グラフ色 .<p>
	 *
	 */
	public static final String $graph_color = "graph_color";
	/**
	 * 無効ＦＬＧ .<p>
	 *
	 */
	public static final String $inv_flg = "inv_flg";


	public static final MCMeta mining_id_META = createCommonMeta($mining_id, mcframe.commonCore.meta.M_META.MINING_ID);
	public static final MCMeta col_id_META = createCommonMeta($col_id, mcframe.commonCore.meta.M_META.RES_KEY);
	public static final MCMeta col_nm_META = createCommonMeta($col_nm, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta list_order_META = createCommonMeta($list_order, mcframe.commonCore.meta.M_META.SORT_ORDER);
	public static final MCMeta sum_info_typ_META = createCommonMeta($sum_info_typ, mcframe.commonCore.meta.M_META.SUM_INFO_TYP);
	public static final MCMeta sumcond_META = createCommonMeta($sumcond, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta rank_flg_META = createCommonMeta($rank_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta rank_typ_META = createCommonMeta($rank_typ, mcframe.commonCore.meta.M_META.SORT_TYP);
	public static final MCMeta rank_size_META = createCommonMeta($rank_size, mcframe.commonCore.meta.M_META.INT);
	public static final MCMeta date_fmt_META = createCommonMeta($date_fmt, mcframe.commonCore.meta.M_META.RES_VAL);
	public static final MCMeta fill_dt_flg_META = createCommonMeta($fill_dt_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta fill_dt_fm_META = createCommonMeta($fill_dt_fm, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta fill_dt_to_META = createCommonMeta($fill_dt_to, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta formula_META = createCommonMeta($formula, mcframe.commonCore.meta.M_META.FORMULA);
	public static final MCMeta dec_place_META = createCommonMeta($dec_place, mcframe.commonCore.meta.M_META.DEC_PLACE);
	public static final MCMeta round_mode_typ_META = createCommonMeta($round_mode_typ, mcframe.commonCore.meta.M_META.ROUND_MODE_TYP);
	public static final MCMeta null_zero_META = createCommonMeta($null_zero, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta sort_order_META = createCommonMeta($sort_order, mcframe.commonCore.meta.M_META.SORT_ORDER);
	public static final MCMeta sort_typ_META = createCommonMeta($sort_typ, mcframe.commonCore.meta.M_META.SORT_TYP);
	public static final MCMeta graph_typ_META = createCommonMeta($graph_typ, mcframe.commonCore.meta.M_META.GRAPH_TYP);
	public static final MCMeta graph_label_flg_META = createCommonMeta($graph_label_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta graph_color_META = createCommonMeta($graph_color, mcframe.commonCore.meta.M_META.COLOR);
	public static final MCMeta inv_flg_META = createCommonMeta($inv_flg, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<MethodDtlR> constMetas = new ConstMetaList<MethodDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			mining_id_META,
			col_id_META,
			col_nm_META,
			list_order_META,
			sum_info_typ_META,
			sumcond_META,
			rank_flg_META,
			rank_typ_META,
			rank_size_META,
			date_fmt_META,
			fill_dt_flg_META,
			fill_dt_fm_META,
			fill_dt_to_META,
			formula_META,
			dec_place_META,
			round_mode_typ_META,
			null_zero_META,
			sort_order_META,
			sort_typ_META,
			graph_typ_META,
			graph_label_flg_META,
			graph_color_META,
			inv_flg_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MethodDtlR_FW_A(ConstMetaList<? extends MethodDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MethodDtlR clone() {
		return (MethodDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MethodDtlR createInstance() {
		return (MethodDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MethodDtlR getValues(String... names) {
		return (MethodDtlR) super.getValues(names);
	}



	/**
	 * マイニングＩＤ .<p>
	 *
	 */
	public String mining_id() {
		return getConstString(offset + 0, $mining_id);
	}

	/**
	 * マイニングＩＤ .<p>
	 *
	 */
	public void mining_id(String value) {
		setConstString(offset + 0, $mining_id, value);
	}


	/**
	 * 項目名 .<p>
	 *
	 */
	public String col_id() {
		return getConstString(offset + 1, $col_id);
	}

	/**
	 * 項目名 .<p>
	 *
	 */
	public void col_id(String value) {
		setConstString(offset + 1, $col_id, value);
	}


	/**
	 * 表示名称 .<p>
	 *
	 */
	public String col_nm() {
		return getConstString(offset + 2, $col_nm);
	}

	/**
	 * 表示名称 .<p>
	 *
	 */
	public void col_nm(String value) {
		setConstString(offset + 2, $col_nm, value);
	}


	/**
	 * 表示順 .<p>
	 *
	 */
	public MCNumber list_order() {
		return getConstNumber(offset + 3, $list_order);
	}

	/**
	 * 表示順 .<p>
	 *
	 */
	public void list_order(MCNumber value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 * 表示順 .<p>
	 *
	 */
	public void list_order(int value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 * 表示順 .<p>
	 *
	 */
	public void list_order(long value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 * 表示順 .<p>
	 *
	 */
	public void list_order(float value) {
		setConstNumber(offset + 3, $list_order, value);
	}

	/**
	 * 表示順 .<p>
	 *
	 */
	public void list_order(double value) {
		setConstNumber(offset + 3, $list_order, value);
	}


	/**
	 * 集計区分 .<p>
	 *
	 */
	public String sum_info_typ() {
		return getConstString(offset + 4, $sum_info_typ);
	}

	/**
	 * 集計区分 .<p>
	 *
	 */
	public void sum_info_typ(String value) {
		setConstString(offset + 4, $sum_info_typ, value);
	}


	/**
	 * 集計条件名 .<p>
	 *
	 */
	public String sumcond() {
		return getConstString(offset + 5, $sumcond);
	}

	/**
	 * 集計条件名 .<p>
	 *
	 */
	public void sumcond(String value) {
		setConstString(offset + 5, $sumcond, value);
	}


	/**
	 * 順位ＦＬＧ .<p>
	 *
	 */
	public boolean rank_flg() {
		return getConstBoolean(offset + 6, $rank_flg);
	}

	/**
	 * 順位ＦＬＧ .<p>
	 *
	 */
	public void rank_flg(boolean value) {
		setConstBoolean(offset + 6, $rank_flg, value);
	}


	/**
	 * 順位ソート区分 .<p>
	 *
	 */
	public String rank_typ() {
		return getConstString(offset + 7, $rank_typ);
	}

	/**
	 * 順位ソート区分 .<p>
	 *
	 */
	public void rank_typ(String value) {
		setConstString(offset + 7, $rank_typ, value);
	}


	/**
	 * 有効順位 .<p>
	 *
	 */
	public MCNumber rank_size() {
		return getConstNumber(offset + 8, $rank_size);
	}

	/**
	 * 有効順位 .<p>
	 *
	 */
	public void rank_size(MCNumber value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 * 有効順位 .<p>
	 *
	 */
	public void rank_size(int value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 * 有効順位 .<p>
	 *
	 */
	public void rank_size(long value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 * 有効順位 .<p>
	 *
	 */
	public void rank_size(float value) {
		setConstNumber(offset + 8, $rank_size, value);
	}

	/**
	 * 有効順位 .<p>
	 *
	 */
	public void rank_size(double value) {
		setConstNumber(offset + 8, $rank_size, value);
	}


	/**
	 * 日時書式 .<p>
	 *
	 */
	public String date_fmt() {
		return getConstString(offset + 9, $date_fmt);
	}

	/**
	 * 日時書式 .<p>
	 *
	 */
	public void date_fmt(String value) {
		setConstString(offset + 9, $date_fmt, value);
	}


	/**
	 * 日時補完ＦＬＧ .<p>
	 *
	 */
	public boolean fill_dt_flg() {
		return getConstBoolean(offset + 10, $fill_dt_flg);
	}

	/**
	 * 日時補完ＦＬＧ .<p>
	 *
	 */
	public void fill_dt_flg(boolean value) {
		setConstBoolean(offset + 10, $fill_dt_flg, value);
	}


	/**
	 * 日時補完開始日時 .<p>
	 *
	 */
	public MCTimestamp fill_dt_fm() {
		return getConstTimestamp(offset + 11, $fill_dt_fm);
	}

	/**
	 * 日時補完開始日時 .<p>
	 *
	 */
	public void fill_dt_fm(MCTimestamp value) {
		setConstTimestamp(offset + 11, $fill_dt_fm, value);
	}


	/**
	 * 日時補完終了日時 .<p>
	 *
	 */
	public MCTimestamp fill_dt_to() {
		return getConstTimestamp(offset + 12, $fill_dt_to);
	}

	/**
	 * 日時補完終了日時 .<p>
	 *
	 */
	public void fill_dt_to(MCTimestamp value) {
		setConstTimestamp(offset + 12, $fill_dt_to, value);
	}


	/**
	 * 計算式 .<p>
	 *
	 */
	public String formula() {
		return getConstString(offset + 13, $formula);
	}

	/**
	 * 計算式 .<p>
	 *
	 */
	public void formula(String value) {
		setConstString(offset + 13, $formula, value);
	}


	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public MCNumber dec_place() {
		return getConstNumber(offset + 14, $dec_place);
	}

	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public void dec_place(MCNumber value) {
		setConstNumber(offset + 14, $dec_place, value);
	}

	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public void dec_place(int value) {
		setConstNumber(offset + 14, $dec_place, value);
	}

	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public void dec_place(long value) {
		setConstNumber(offset + 14, $dec_place, value);
	}

	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public void dec_place(float value) {
		setConstNumber(offset + 14, $dec_place, value);
	}

	/**
	 * 小数部有効桁数 .<p>
	 *
	 */
	public void dec_place(double value) {
		setConstNumber(offset + 14, $dec_place, value);
	}


	/**
	 * 端数処理区分 .<p>
	 *
	 */
	public String round_mode_typ() {
		return getConstString(offset + 15, $round_mode_typ);
	}

	/**
	 * 端数処理区分 .<p>
	 *
	 */
	public void round_mode_typ(String value) {
		setConstString(offset + 15, $round_mode_typ, value);
	}


	/**
	 * NULL集計0変換 .<p>
	 *
	 */
	public boolean null_zero() {
		return getConstBoolean(offset + 16, $null_zero);
	}

	/**
	 * NULL集計0変換 .<p>
	 *
	 */
	public void null_zero(boolean value) {
		setConstBoolean(offset + 16, $null_zero, value);
	}


	/**
	 * ソート順 .<p>
	 *
	 */
	public MCNumber sort_order() {
		return getConstNumber(offset + 17, $sort_order);
	}

	/**
	 * ソート順 .<p>
	 *
	 */
	public void sort_order(MCNumber value) {
		setConstNumber(offset + 17, $sort_order, value);
	}

	/**
	 * ソート順 .<p>
	 *
	 */
	public void sort_order(int value) {
		setConstNumber(offset + 17, $sort_order, value);
	}

	/**
	 * ソート順 .<p>
	 *
	 */
	public void sort_order(long value) {
		setConstNumber(offset + 17, $sort_order, value);
	}

	/**
	 * ソート順 .<p>
	 *
	 */
	public void sort_order(float value) {
		setConstNumber(offset + 17, $sort_order, value);
	}

	/**
	 * ソート順 .<p>
	 *
	 */
	public void sort_order(double value) {
		setConstNumber(offset + 17, $sort_order, value);
	}


	/**
	 * ソート区分 .<p>
	 *
	 */
	public String sort_typ() {
		return getConstString(offset + 18, $sort_typ);
	}

	/**
	 * ソート区分 .<p>
	 *
	 */
	public void sort_typ(String value) {
		setConstString(offset + 18, $sort_typ, value);
	}


	/**
	 * グラフ種類 .<p>
	 *
	 */
	public MCNumber graph_typ() {
		return getConstNumber(offset + 19, $graph_typ);
	}

	/**
	 * グラフ種類 .<p>
	 *
	 */
	public void graph_typ(MCNumber value) {
		setConstNumber(offset + 19, $graph_typ, value);
	}

	/**
	 * グラフ種類 .<p>
	 *
	 */
	public void graph_typ(int value) {
		setConstNumber(offset + 19, $graph_typ, value);
	}

	/**
	 * グラフ種類 .<p>
	 *
	 */
	public void graph_typ(long value) {
		setConstNumber(offset + 19, $graph_typ, value);
	}

	/**
	 * グラフ種類 .<p>
	 *
	 */
	public void graph_typ(float value) {
		setConstNumber(offset + 19, $graph_typ, value);
	}

	/**
	 * グラフ種類 .<p>
	 *
	 */
	public void graph_typ(double value) {
		setConstNumber(offset + 19, $graph_typ, value);
	}


	/**
	 * グラフ行ラベルＦＬＧ .<p>
	 *
	 */
	public boolean graph_label_flg() {
		return getConstBoolean(offset + 20, $graph_label_flg);
	}

	/**
	 * グラフ行ラベルＦＬＧ .<p>
	 *
	 */
	public void graph_label_flg(boolean value) {
		setConstBoolean(offset + 20, $graph_label_flg, value);
	}


	/**
	 * グラフ色 .<p>
	 *
	 */
	public String graph_color() {
		return getConstString(offset + 21, $graph_color);
	}

	/**
	 * グラフ色 .<p>
	 *
	 */
	public void graph_color(String value) {
		setConstString(offset + 21, $graph_color, value);
	}


	/**
	 * 無効ＦＬＧ .<p>
	 *
	 */
	public boolean inv_flg() {
		return getConstBoolean(offset + 22, $inv_flg);
	}

	/**
	 * 無効ＦＬＧ .<p>
	 *
	 */
	public void inv_flg(boolean value) {
		setConstBoolean(offset + 22, $inv_flg, value);
	}


	public String getString(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($col_id.equalsIgnoreCase(name)) {
			return col_id();
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			return col_nm();
		}
		if ($sum_info_typ.equalsIgnoreCase(name)) {
			return sum_info_typ();
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			return sumcond();
		}
		if ($rank_typ.equalsIgnoreCase(name)) {
			return rank_typ();
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			return date_fmt();
		}
		if ($formula.equalsIgnoreCase(name)) {
			return formula();
		}
		if ($round_mode_typ.equalsIgnoreCase(name)) {
			return round_mode_typ();
		}
		if ($sort_typ.equalsIgnoreCase(name)) {
			return sort_typ();
		}
		if ($graph_color.equalsIgnoreCase(name)) {
			return graph_color();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			return rank_size();
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			return dec_place();
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			return sort_order();
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			return graph_typ();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			return fill_dt_fm();
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			return fill_dt_to();
		}
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		if ($rank_flg.equalsIgnoreCase(name)) {
			return rank_flg();
		}
		if ($fill_dt_flg.equalsIgnoreCase(name)) {
			return fill_dt_flg();
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			return null_zero();
		}
		if ($graph_label_flg.equalsIgnoreCase(name)) {
			return graph_label_flg();
		}
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($mining_id.equalsIgnoreCase(name)) {
			return mining_id();
		}
		if ($col_id.equalsIgnoreCase(name)) {
			return col_id();
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			return col_nm();
		}
		if ($sum_info_typ.equalsIgnoreCase(name)) {
			return sum_info_typ();
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			return sumcond();
		}
		if ($rank_typ.equalsIgnoreCase(name)) {
			return rank_typ();
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			return date_fmt();
		}
		if ($formula.equalsIgnoreCase(name)) {
			return formula();
		}
		if ($round_mode_typ.equalsIgnoreCase(name)) {
			return round_mode_typ();
		}
		if ($sort_typ.equalsIgnoreCase(name)) {
			return sort_typ();
		}
		if ($graph_color.equalsIgnoreCase(name)) {
			return graph_color();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($list_order.equalsIgnoreCase(name)) {
			return list_order();
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			return rank_size();
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			return dec_place();
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			return sort_order();
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			return graph_typ();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			return fill_dt_fm();
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			return fill_dt_to();
		}
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($rank_flg.equalsIgnoreCase(name)) {
			return rank_flg();
		}
		if ($fill_dt_flg.equalsIgnoreCase(name)) {
			return fill_dt_flg();
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			return null_zero();
		}
		if ($graph_label_flg.equalsIgnoreCase(name)) {
			return graph_label_flg();
		}
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($col_id.equalsIgnoreCase(name)) {
			col_id(value);
			return;
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			col_nm(value);
			return;
		}
		if ($sum_info_typ.equalsIgnoreCase(name)) {
			sum_info_typ(value);
			return;
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			sumcond(value);
			return;
		}
		if ($rank_typ.equalsIgnoreCase(name)) {
			rank_typ(value);
			return;
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			date_fmt(value);
			return;
		}
		if ($formula.equalsIgnoreCase(name)) {
			formula(value);
			return;
		}
		if ($round_mode_typ.equalsIgnoreCase(name)) {
			round_mode_typ(value);
			return;
		}
		if ($sort_typ.equalsIgnoreCase(name)) {
			sort_typ(value);
			return;
		}
		if ($graph_color.equalsIgnoreCase(name)) {
			graph_color(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			fill_dt_fm(value);
			return;
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			fill_dt_to(value);
			return;
		}
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($rank_flg.equalsIgnoreCase(name)) {
			rank_flg(value);
			return;
		}
		if ($fill_dt_flg.equalsIgnoreCase(name)) {
			fill_dt_flg(value);
			return;
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			null_zero(value);
			return;
		}
		if ($graph_label_flg.equalsIgnoreCase(name)) {
			graph_label_flg(value);
			return;
		}
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($mining_id.equalsIgnoreCase(name)) {
			mining_id(value);
			return;
		}
		if ($col_id.equalsIgnoreCase(name)) {
			col_id(value);
			return;
		}
		if ($col_nm.equalsIgnoreCase(name)) {
			col_nm(value);
			return;
		}
		if ($sum_info_typ.equalsIgnoreCase(name)) {
			sum_info_typ(value);
			return;
		}
		if ($sumcond.equalsIgnoreCase(name)) {
			sumcond(value);
			return;
		}
		if ($rank_typ.equalsIgnoreCase(name)) {
			rank_typ(value);
			return;
		}
		if ($date_fmt.equalsIgnoreCase(name)) {
			date_fmt(value);
			return;
		}
		if ($formula.equalsIgnoreCase(name)) {
			formula(value);
			return;
		}
		if ($round_mode_typ.equalsIgnoreCase(name)) {
			round_mode_typ(value);
			return;
		}
		if ($sort_typ.equalsIgnoreCase(name)) {
			sort_typ(value);
			return;
		}
		if ($graph_color.equalsIgnoreCase(name)) {
			graph_color(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($list_order.equalsIgnoreCase(name)) {
			list_order(value);
			return;
		}
		if ($rank_size.equalsIgnoreCase(name)) {
			rank_size(value);
			return;
		}
		if ($dec_place.equalsIgnoreCase(name)) {
			dec_place(value);
			return;
		}
		if ($sort_order.equalsIgnoreCase(name)) {
			sort_order(value);
			return;
		}
		if ($graph_typ.equalsIgnoreCase(name)) {
			graph_typ(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($fill_dt_fm.equalsIgnoreCase(name)) {
			fill_dt_fm(value);
			return;
		}
		if ($fill_dt_to.equalsIgnoreCase(name)) {
			fill_dt_to(value);
			return;
		}
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($rank_flg.equalsIgnoreCase(name)) {
			rank_flg(value);
			return;
		}
		if ($fill_dt_flg.equalsIgnoreCase(name)) {
			fill_dt_flg(value);
			return;
		}
		if ($null_zero.equalsIgnoreCase(name)) {
			null_zero(value);
			return;
		}
		if ($graph_label_flg.equalsIgnoreCase(name)) {
			graph_label_flg(value);
			return;
		}
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

