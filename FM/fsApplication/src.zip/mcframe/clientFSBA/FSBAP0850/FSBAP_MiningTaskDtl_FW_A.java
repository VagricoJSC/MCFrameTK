package mcframe.clientFSBA.FSBAP0850;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0850.FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Srch11Caller;
import mcframe.clientFSBA.FSBAP0850.FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Ins01Caller;
import mcframe.clientFSBA.FSBAP0850.FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Upd01Caller;

/**
 * 画面"FSBAP_MiningTaskDtl"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_MiningTaskDtl_FW_A extends mcframe.clientFSUC.FSUCP0100.FSUCP_ConditionSettingBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0850";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [TaskTab]ブロック関連のField定義
	public MCPanel TaskTabPanel = null;
	public MCTabbedPane TaskTabTab = null;
	// [TaskTab]ブロックの項目のField定義
	// [Prop]ブロック関連のField定義
	public MCPanel PropPanel = null;
	// [Prop]ブロックの項目のField定義
	// [PropDtl]ブロック関連のField定義
	public MCPanel PropDtlPanel = null;
	// [PropDtl]ブロックの項目のField定義
	public MCLabel PropDtl_task_nm_Label = null;
	/**
	 *  タスク名.<p>
	 *
	 */
	public MCTextField PropDtl_task_nm = null;
	/**
	 *  無効.<p>
	 *
	 */
	public MCCheckBox PropDtl_inv_flg = null;
	/**
	 *  タスク種別.<p>
	 *
	 */
	public MCTextField PropDtl_task_type = null;
	public MCLabel PropDtl_task_type_nm_Label = null;
	/**
	 *  タスク種別名.<p>
	 *
	 */
	public MCTextComboBox PropDtl_task_type_nm = null;
	public MCLabel PropDtl_co_cd_Label = null;
	/**
	 *  会社ＣＤ.<p>
	 *
	 */
	public MCTextComboBox PropDtl_co_cd = null;
	/**
	 *  会社名.<p>
	 *
	 */
	public MCTextField PropDtl_co_nm = null;
	public MCLabel PropDtl_user_id_Label = null;
	/**
	 *  実行ユーザＩＤ.<p>
	 *
	 */
	public MCTextComboBox PropDtl_user_id = null;
	/**
	 *  実行ユーザ名.<p>
	 *
	 */
	public MCTextField PropDtl_user_nm = null;
	/**
	 *  マイニングＩＤ.<p>
	 *
	 */
	public MCTextField PropDtl_mining_id = null;
	public MCLabel PropDtl_mining_nm_Label = null;
	/**
	 *  マイニング名.<p>
	 *
	 */
	public MCTextComboBox PropDtl_mining_nm = null;
	// [Sche]ブロック関連のField定義
	public MCPanel SchePanel = null;
	// [Sche]ブロックの項目のField定義
	// [ScheDtl]ブロック関連のField定義
	public MCPanel ScheDtlPanel = null;
	public MCScrollPane ScheDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0850.ScheDtlR> ScheDtlTable = null;
	// [ScheDtl]ブロックの項目のField定義
	/**
	 *  無効.<p>
	 *
	 */
	public MCColumnConfig columnScheDtl_inv_flg = null;
	/**
	 *  実行時刻.<p>
	 *
	 */
	public MCColumnConfig columnScheDtl_time = null;
	/**
	 *  説明.<p>
	 *
	 */
	public MCColumnConfig columnScheDtl_desc = null;
	// [ScheCtrl]ブロック関連のField定義
	public MCPanel ScheCtrlPanel = null;
	// [ScheCtrl]ブロックの項目のField定義
	/**
	 *  追加.<p>
	 *
	 */
	public MCButton ScheCtrl_add = null;
	/**
	 *  コピー.<p>
	 *
	 */
	public MCButton ScheCtrl_cpy = null;
	/**
	 *  編集.<p>
	 *
	 */
	public MCButton ScheCtrl_mod = null;
	/**
	 *  削除.<p>
	 *
	 */
	public MCButton ScheCtrl_del = null;
	// [Cond]ブロック関連のField定義
	public MCPanel CondPanel = null;
	// [Cond]ブロックの項目のField定義
	// [Param]ブロック関連のField定義
	public MCPanel ParamPanel = null;
	// [Param]ブロックの項目のField定義
	// [Push]ブロック関連のField定義
	public MCPanel PushPanel = null;
	// [Push]ブロックの項目のField定義
	// [PushDtl]ブロック関連のField定義
	public MCPanel PushDtlPanel = null;
	// [PushDtl]ブロックの項目のField定義
	/**
	 *  id,ＩＤ指定;edit,直接入力.<p>
	 *
	 */
	public MCButtonGroup PushDtl_msg_type_Group = null;
	public MCRadioButton PushDtl_msg_type_id = null;
	public MCRadioButton PushDtl_msg_type_edit = null;
	public MCLabel PushDtl_msg_id_Label = null;
	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public MCTextField PushDtl_msg_id = null;
	public MCLabel PushDtl_msg_Label = null;
	public MCScrollPane PushDtl_msgScrollPane = null;
	/**
	 *  メッセージ.<p>
	 *
	 */
	public MCTextArea PushDtl_msg = null;
	public MCLabel PushDtl_push_type_Label = null;
	/**
	 *  通知方法種別.<p>
	 *
	 */
	public MCTextField PushDtl_push_type = null;
	public MCLabel PushDtl_push_type_nm_Label = null;
	/**
	 *  通知方法.<p>
	 *
	 */
	public MCTextComboBox PushDtl_push_type_nm = null;
	/**
	 *  重要で送信.<p>
	 *
	 */
	public MCCheckBox PushDtl_push_imp = null;
	// [DestTab]ブロック関連のField定義
	public MCPanel DestTabPanel = null;
	public MCTabbedPane DestTabTab = null;
	// [DestTab]ブロックの項目のField定義
	// [Ctrl]ブロック関連のField定義
	public MCPanel CtrlPanel = null;
	// [Ctrl]ブロックの項目のField定義
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton Ctrl_upd = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [ENTRY]モードを表す定数 */
	public static final String ENTRY = "ENTRY";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, ENTRY, READ_ONLY};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0820_Srch11]のCallerの作成 */
	protected FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Srch11Caller createFS_FSBAL0820_Srch11() {
		FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Srch11Caller<FSBAP_MiningTaskDtl, FS_FSBAL0820_Srch11Bridge>
		caller = ((FSBAP_MiningTaskDtl_FW)this).new FS_FSBAL0820_Srch11Caller<FSBAP_MiningTaskDtl, FS_FSBAL0820_Srch11Bridge>(
					(FSBAP_MiningTaskDtl)this, new FS_FSBAL0820_Srch11Bridge());
		return caller;
	}
	/** [FS_FSBAL0820_Srch11]の呼び出し */
	protected void callFS_FSBAL0820_Srch11() {
		MCCaller caller = createFS_FSBAL0820_Srch11();
		caller.exec();
	}
	/** [FS_FSBAL0820_Ins01]のCallerの作成 */
	protected FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Ins01Caller createFS_FSBAL0820_Ins01() {
		FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Ins01Caller<FSBAP_MiningTaskDtl, FS_FSBAL0820_Ins01Bridge>
		caller = ((FSBAP_MiningTaskDtl_FW)this).new FS_FSBAL0820_Ins01Caller<FSBAP_MiningTaskDtl, FS_FSBAL0820_Ins01Bridge>(
					(FSBAP_MiningTaskDtl)this, new FS_FSBAL0820_Ins01Bridge());
		return caller;
	}
	/** [FS_FSBAL0820_Ins01]の呼び出し */
	protected void callFS_FSBAL0820_Ins01() {
		MCCaller caller = createFS_FSBAL0820_Ins01();
		caller.exec();
	}
	/** [FS_FSBAL0820_Upd01]のCallerの作成 */
	protected FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Upd01Caller createFS_FSBAL0820_Upd01() {
		FSBAP_MiningTaskDtl_FW.FS_FSBAL0820_Upd01Caller<FSBAP_MiningTaskDtl, FS_FSBAL0820_Upd01Bridge>
		caller = ((FSBAP_MiningTaskDtl_FW)this).new FS_FSBAL0820_Upd01Caller<FSBAP_MiningTaskDtl, FS_FSBAL0820_Upd01Bridge>(
					(FSBAP_MiningTaskDtl)this, new FS_FSBAL0820_Upd01Bridge());
		return caller;
	}
	/** [FS_FSBAL0820_Upd01]の呼び出し */
	protected void callFS_FSBAL0820_Upd01() {
		MCCaller caller = createFS_FSBAL0820_Upd01();
		caller.exec();
	}
	/** [PropDtl]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0820.TaskR aPropDtlR;
	/** [ScheDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> aScheDtlL;
	/** [CondDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR> aCondDtlL;
	/** [MethodDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR> aMethodDtlL;
	/** [PushDtl]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0850.PushDtlR aPushDtlR;
	/** [ParamProp]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> aParamPropL;
	/** [ParamDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> aParamDtlL;

	/**
	 * 項目コピーによってaPropDtlRを設定します。
	 *
	 * aPropDtlRのインスタンスは変更されません。
	 *
	 * @param row PropDtlR
	 */
	public void setPropDtlR(mcframe.clientFSBA.FSBAP0820.TaskR row) {
		if (row != null) {
			MCRow.copyall(getPropDtlR(), row);
		}
	}

	/**
	 * [PropDtl]ブロックのコンテナaPropDtlRを返します。
	 *
	 * @return PropDtlR
	 */
	public mcframe.clientFSBA.FSBAP0820.TaskR getPropDtlR() {
		return aPropDtlR;
	}

	/**
	 * aPropDtlRを作成します。
	 *
	 * @return PropDtlR
	 */
	public mcframe.clientFSBA.FSBAP0820.TaskR createPropDtlR() {
		return mcframe.clientFSBA.FSBAP0820.TaskR.create();
	}

	/**
	 * コピーによってaScheDtlLを設定します。
	 *
	 * aScheDtlLのインスタンスは変更されません。
	 *
	 * @param dataset ScheDtlL
	 */
	public void setScheDtlL(MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> aList) {
		if (getScheDtlL() != aList) {
			getScheDtlL().setAll(aList);
		}
	}

	/**
	 * [ScheDtl]ブロックのコンテナaScheDtlLを返します。
	 *
	 * @return ScheDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> getScheDtlL() {
		return aScheDtlL;
	}

	/**
	 * aScheDtlRを作成します。
	 *
	 * @return ScheDtlR
	 */
	public mcframe.clientFSBA.FSBAP0850.ScheDtlR createScheDtlR() {
		return mcframe.clientFSBA.FSBAP0850.ScheDtlR.create();
	}

	/**
	 * aScheDtlLを作成します。
	 *
	 * @return ScheDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> createScheDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0850.ScheDtlR.class);
	}

	/**
	 * ScheDtlTableを初期化します。
	 */
	protected void createScheDtlTable(){
		if(ScheDtlTable == null){
			ScheDtlTable = beansFactory.createTable2("ScheDtl.table");
		}
	}

	/**
	 * コピーによってaCondDtlLを設定します。
	 *
	 * aCondDtlLのインスタンスは変更されません。
	 *
	 * @param dataset CondDtlL
	 */
	public void setCondDtlL(MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR> aList) {
		if (getCondDtlL() != aList) {
			getCondDtlL().setAll(aList);
		}
	}

	/**
	 * [CondDtl]ブロックのコンテナaCondDtlLを返します。
	 *
	 * @return CondDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR> getCondDtlL() {
		return aCondDtlL;
	}

	/**
	 * aCondDtlRを作成します。
	 *
	 * @return CondDtlR
	 */
	public mcframe.clientFSBA.FSBAP0850.CondDtlR createCondDtlR() {
		return mcframe.clientFSBA.FSBAP0850.CondDtlR.create();
	}

	/**
	 * aCondDtlLを作成します。
	 *
	 * @return CondDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR> createCondDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0850.CondDtlR.class);
	}

	/**
	 * コピーによってaMethodDtlLを設定します。
	 *
	 * aMethodDtlLのインスタンスは変更されません。
	 *
	 * @param dataset MethodDtlL
	 */
	public void setMethodDtlL(MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR> aList) {
		if (getMethodDtlL() != aList) {
			getMethodDtlL().setAll(aList);
		}
	}

	/**
	 * [MethodDtl]ブロックのコンテナaMethodDtlLを返します。
	 *
	 * @return MethodDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR> getMethodDtlL() {
		return aMethodDtlL;
	}

	/**
	 * aMethodDtlRを作成します。
	 *
	 * @return MethodDtlR
	 */
	public mcframe.clientFSBA.FSBAP0850.MethodDtlR createMethodDtlR() {
		return mcframe.clientFSBA.FSBAP0850.MethodDtlR.create();
	}

	/**
	 * aMethodDtlLを作成します。
	 *
	 * @return MethodDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR> createMethodDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0850.MethodDtlR.class);
	}

	/**
	 * 項目コピーによってaPushDtlRを設定します。
	 *
	 * aPushDtlRのインスタンスは変更されません。
	 *
	 * @param row PushDtlR
	 */
	public void setPushDtlR(mcframe.clientFSBA.FSBAP0850.PushDtlR row) {
		if (row != null) {
			MCRow.copyall(getPushDtlR(), row);
		}
	}

	/**
	 * [PushDtl]ブロックのコンテナaPushDtlRを返します。
	 *
	 * @return PushDtlR
	 */
	public mcframe.clientFSBA.FSBAP0850.PushDtlR getPushDtlR() {
		return aPushDtlR;
	}

	/**
	 * aPushDtlRを作成します。
	 *
	 * @return PushDtlR
	 */
	public mcframe.clientFSBA.FSBAP0850.PushDtlR createPushDtlR() {
		return mcframe.clientFSBA.FSBAP0850.PushDtlR.create();
	}

	/**
	 * コピーによってaParamPropLを設定します。
	 *
	 * aParamPropLのインスタンスは変更されません。
	 *
	 * @param dataset ParamPropL
	 */
	public void setParamPropL(MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> aList) {
		if (getParamPropL() != aList) {
			getParamPropL().setAll(aList);
		}
	}

	/**
	 * [ParamProp]ブロックのコンテナaParamPropLを返します。
	 *
	 * @return ParamPropL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> getParamPropL() {
		return aParamPropL;
	}

	/**
	 * aParamPropRを作成します。
	 *
	 * @return ParamPropR
	 */
	public mcframe.clientFSBA.FSBAP0850.ParamDtlR createParamPropR() {
		return mcframe.clientFSBA.FSBAP0850.ParamDtlR.create();
	}

	/**
	 * aParamPropLを作成します。
	 *
	 * @return ParamPropL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> createParamPropL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class);
	}

	/**
	 * コピーによってaParamDtlLを設定します。
	 *
	 * aParamDtlLのインスタンスは変更されません。
	 *
	 * @param dataset ParamDtlL
	 */
	public void setParamDtlL(MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> aList) {
		if (getParamDtlL() != aList) {
			getParamDtlL().setAll(aList);
		}
	}

	/**
	 * [ParamDtl]ブロックのコンテナaParamDtlLを返します。
	 *
	 * @return ParamDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> getParamDtlL() {
		return aParamDtlL;
	}

	/**
	 * aParamDtlRを作成します。
	 *
	 * @return ParamDtlR
	 */
	public mcframe.clientFSBA.FSBAP0850.ParamDtlR createParamDtlR() {
		return mcframe.clientFSBA.FSBAP0850.ParamDtlR.create();
	}

	/**
	 * aParamDtlLを作成します。
	 *
	 * @return ParamDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> createParamDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getPropDtlR())) ret.add(getPropDtlR());
		if(!MCCollectionUtil.contains(ret, getScheDtlL())) ret.add(getScheDtlL());
		if(!MCCollectionUtil.contains(ret, getCondDtlL())) ret.add(getCondDtlL());
		if(!MCCollectionUtil.contains(ret, getMethodDtlL())) ret.add(getMethodDtlL());
		if(!MCCollectionUtil.contains(ret, getPushDtlR())) ret.add(getPushDtlR());
		if(!MCCollectionUtil.contains(ret, getParamPropL())) ret.add(getParamPropL());
		if(!MCCollectionUtil.contains(ret, getParamDtlL())) ret.add(getParamDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getPropDtlR()) return "PropDtl";
		if(aCnt == getScheDtlL()) return "ScheDtl";
		if(aCnt == getCondDtlL()) return "CondDtl";
		if(aCnt == getMethodDtlL()) return "MethodDtl";
		if(aCnt == getPushDtlR()) return "PushDtl";
		if(aCnt == getParamPropL()) return "ParamProp";
		if(aCnt == getParamDtlL()) return "ParamDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("PropDtl")) return getPropDtlR();
		if(bId.equals("ScheDtl")) return getScheDtlL();
		if(bId.equals("CondDtl")) return getCondDtlL();
		if(bId.equals("MethodDtl")) return getMethodDtlL();
		if(bId.equals("PushDtl")) return getPushDtlR();
		if(bId.equals("ParamProp")) return getParamPropL();
		if(bId.equals("ParamDtl")) return getParamDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(TaskTabPanel);
		ret.add(PropPanel);
		ret.add(PropDtlPanel);
		ret.add(SchePanel);
		ret.add(ScheDtlPanel);
		ret.add(ScheCtrlPanel);
		ret.add(CondPanel);
		ret.add(ParamPanel);
		ret.add(PushPanel);
		ret.add(PushDtlPanel);
		ret.add(DestTabPanel);
		ret.add(CtrlPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTaskDtl_FW_A() {
		aPropDtlR = createPropDtlR();
		aScheDtlL = createScheDtlL();
		aCondDtlL = createCondDtlL();
		aMethodDtlL = createMethodDtlL();
		aPushDtlR = createPushDtlR();
		aParamPropL = createParamPropL();
		aParamDtlL = createParamDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningTaskDtl_FW_A(String name) {
		aPropDtlR = createPropDtlR();
		aScheDtlL = createScheDtlL();
		createScheDtlTable();
		ScheDtlTable.setRowName(name);
		aCondDtlL = createCondDtlL();
		aMethodDtlL = createMethodDtlL();
		aPushDtlR = createPushDtlR();
		aParamPropL = createParamPropL();
		aParamDtlL = createParamDtlL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_MiningTaskDtl_FW.jbCreateTaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreatePropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateSche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateCond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateParam((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreatePush((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreatePushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateDestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbCreateCtrl((FSBAP_MiningTaskDtl)this);
	}

	/**
	 * [TaskTab]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTaskTab(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [Prop]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateProp(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [PropDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePropDtl(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [Sche]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSche(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [ScheDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateScheDtl(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [ScheCtrl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateScheCtrl(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [Cond]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCond(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [Param]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateParam(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [Push]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePush(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [PushDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePushDtl(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [DestTab]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDestTab(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * [Ctrl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCtrl(FSBAP_MiningTaskDtl p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [PropDtl_task_type_nm_ListPutter]の定義 */
	private MCListPutter PropDtl_task_type_nm_p = null;

	/**
	 * [PropDtl_task_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getPropDtl_task_type_nm_ListPutter() {
		if (PropDtl_task_type_nm_p == null) {
			PropDtl_task_type_nm_p = createPropDtl_task_type_nm_ListPutter(PropDtl_task_type_nm, "task_type_nm", "task_type");

		}
		return PropDtl_task_type_nm_p;
	}
	
	
	/** [PropDtl_co_cd_ListPutter]の定義 */
	private MCListPutter PropDtl_co_cd_p = null;

	/**
	 * [PropDtl_co_cd_ListPutter]の取得
	 */
	protected MCListPutter getPropDtl_co_cd_ListPutter() {
		if (PropDtl_co_cd_p == null) {
			PropDtl_co_cd_p = createPropDtl_co_cd_ListPutter(PropDtl_co_cd, "co_cd", "co_nm");

		}
		return PropDtl_co_cd_p;
	}
	
	
	/** [PropDtl_user_id_ListPutter]の定義 */
	private MCListPutter PropDtl_user_id_p = null;

	/**
	 * [PropDtl_user_id_ListPutter]の取得
	 */
	protected MCListPutter getPropDtl_user_id_ListPutter() {
		if (PropDtl_user_id_p == null) {
			PropDtl_user_id_p = createPropDtl_user_id_ListPutter(PropDtl_user_id, "user_id", "user_nm");

		}
		return PropDtl_user_id_p;
	}
	
	
	/** [PropDtl_mining_nm_ListPutter]の定義 */
	private MCListPutter PropDtl_mining_nm_p = null;

	/**
	 * [PropDtl_mining_nm_ListPutter]の取得
	 */
	protected MCListPutter getPropDtl_mining_nm_ListPutter() {
		if (PropDtl_mining_nm_p == null) {
			PropDtl_mining_nm_p = createPropDtl_mining_nm_ListPutter(PropDtl_mining_nm, "mining_nm", "mining_id");

		}
		return PropDtl_mining_nm_p;
	}
	
	
	/** [PushDtl_push_type_nm_ListPutter]の定義 */
	private MCListPutter PushDtl_push_type_nm_p = null;

	/**
	 * [PushDtl_push_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getPushDtl_push_type_nm_ListPutter() {
		if (PushDtl_push_type_nm_p == null) {
			PushDtl_push_type_nm_p = createPushDtl_push_type_nm_ListPutter(PushDtl_push_type_nm, "push_type_nm", "push_type");

		}
		return PushDtl_push_type_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTaskDtl create(){
		FSBAP_MiningTaskDtl p = new FSBAP_MiningTaskDtl();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTaskDtl create(String name){
		FSBAP_MiningTaskDtl p = new FSBAP_MiningTaskDtl(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_MiningTaskDtl_FW.jbfInitTaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitPropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitSche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitCond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitParam((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitPush((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitPushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitDestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbfInitCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitTaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitPropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitSche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitCond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitParam((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitPush((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitPushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitDestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.jbInitCtrl((FSBAP_MiningTaskDtl)this);
	}

	/**
	 * [TaskTab]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTaskTab(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.TaskTabPanel = p.beansFactory.createPanel("TaskTab");
		p.TaskTabTab = p.beansFactory.createTabbedPane("TaskTab.tab");
		// ブロックの項目の初期化
	}

	/**
	 * [Prop]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitProp(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PropPanel = p.beansFactory.createPanel("Prop");
		// ブロックの項目の初期化
	}

	/**
	 * [PropDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPropDtl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PropDtlPanel = p.beansFactory.createPanel("PropDtl");
		// ブロックの項目の初期化
		p.PropDtl_task_nm_Label = p.beansFactory.createLabel("PropDtl.task_nm_Label");
		p.PropDtl_task_nm = p.beansFactory.createTextField("PropDtl.task_nm");
		p.PropDtl_task_nm.setLabel(p.PropDtl_task_nm_Label);
		p.PropDtl_inv_flg = p.beansFactory.createCheckBox("PropDtl.inv_flg");
		p.PropDtl_task_type = p.beansFactory.createTextField("PropDtl.task_type");
		p.PropDtl_task_type_nm_Label = p.beansFactory.createLabel("PropDtl.task_type_nm_Label");
		p.PropDtl_task_type_nm = p.beansFactory.createTextComboBox("PropDtl.task_type_nm");
		p.PropDtl_task_type_nm.setLabel(p.PropDtl_task_type_nm_Label);
		p.PropDtl_co_cd_Label = p.beansFactory.createLabel("PropDtl.co_cd_Label");
		p.PropDtl_co_cd = p.beansFactory.createTextComboBox("PropDtl.co_cd");
		p.PropDtl_co_cd.setLabel(p.PropDtl_co_cd_Label);
		p.PropDtl_co_nm = p.beansFactory.createTextField("PropDtl.co_nm");
		p.PropDtl_user_id_Label = p.beansFactory.createLabel("PropDtl.user_id_Label");
		p.PropDtl_user_id = p.beansFactory.createTextComboBox("PropDtl.user_id");
		p.PropDtl_user_id.setLabel(p.PropDtl_user_id_Label);
		p.PropDtl_user_nm = p.beansFactory.createTextField("PropDtl.user_nm");
		p.PropDtl_mining_id = p.beansFactory.createTextField("PropDtl.mining_id");
		p.PropDtl_mining_nm_Label = p.beansFactory.createLabel("PropDtl.mining_nm_Label");
		p.PropDtl_mining_nm = p.beansFactory.createTextComboBox("PropDtl.mining_nm");
		p.PropDtl_mining_nm.setLabel(p.PropDtl_mining_nm_Label);
	}

	/**
	 * [Sche]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSche(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.SchePanel = p.beansFactory.createPanel("Sche");
		// ブロックの項目の初期化
	}

	/**
	 * [ScheDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitScheDtl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.ScheDtlPanel = p.beansFactory.createPanel("ScheDtl");
		p.ScheDtlScrollPane = p.beansFactory.createScrollPane("ScheDtl.scroll");
		p.createScheDtlTable();
		// ブロックの項目の初期化
		p.columnScheDtl_inv_flg = p.beansFactory.createTableColumn("ScheDtl.inv_flg", MCColumnType.CHECK);
		p.columnScheDtl_time = p.beansFactory.createTableColumn("ScheDtl.time", MCColumnType.DATE);
		p.columnScheDtl_desc = p.beansFactory.createTableColumn("ScheDtl.desc", MCColumnType.TEXT);
	}

	/**
	 * [ScheCtrl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitScheCtrl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.ScheCtrlPanel = p.beansFactory.createPanel("ScheCtrl");
		// ブロックの項目の初期化
		p.ScheCtrl_add = p.beansFactory.createButton("ScheCtrl.add");
		p.ScheCtrl_cpy = p.beansFactory.createButton("ScheCtrl.cpy");
		p.ScheCtrl_mod = p.beansFactory.createButton("ScheCtrl.mod");
		p.ScheCtrl_del = p.beansFactory.createButton("ScheCtrl.del");
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCond(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.CondPanel = p.beansFactory.createPanel("Cond");
		// ブロックの項目の初期化
	}

	/**
	 * [Param]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitParam(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.ParamPanel = p.beansFactory.createPanel("Param");
		// ブロックの項目の初期化
	}

	/**
	 * [Push]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPush(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PushPanel = p.beansFactory.createPanel("Push");
		// ブロックの項目の初期化
	}

	/**
	 * [PushDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPushDtl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PushDtlPanel = p.beansFactory.createPanel("PushDtl");
		// ブロックの項目の初期化
		p.PushDtl_msg_type_Group = p.beansFactory.createButtonGroup("PushDtl.msg_type");
		p.PushDtl_msg_type_id = p.beansFactory.createRadioButton("PushDtl.msg_type_id");
		p.PushDtl_msg_type_edit = p.beansFactory.createRadioButton("PushDtl.msg_type_edit");
		p.PushDtl_msg_id_Label = p.beansFactory.createLabel("PushDtl.msg_id_Label");
		p.PushDtl_msg_id = p.beansFactory.createTextField("PushDtl.msg_id");
		p.PushDtl_msg_id.setLabel(p.PushDtl_msg_id_Label);
		p.PushDtl_msg_Label = p.beansFactory.createLabel("PushDtl.msg_Label");
		p.PushDtl_msgScrollPane = p.beansFactory.createScrollPane("PushDtl.msgscroll");
		p.PushDtl_msg = p.beansFactory.createTextArea("PushDtl.msg");
		p.PushDtl_msg.setLabel(p.PushDtl_msg_Label);
		p.PushDtl_push_type_Label = p.beansFactory.createLabel("PushDtl.push_type_Label");
		p.PushDtl_push_type = p.beansFactory.createTextField("PushDtl.push_type");
		p.PushDtl_push_type.setLabel(p.PushDtl_push_type_Label);
		p.PushDtl_push_type_nm_Label = p.beansFactory.createLabel("PushDtl.push_type_nm_Label");
		p.PushDtl_push_type_nm = p.beansFactory.createTextComboBox("PushDtl.push_type_nm");
		p.PushDtl_push_type_nm.setLabel(p.PushDtl_push_type_nm_Label);
		p.PushDtl_push_imp = p.beansFactory.createCheckBox("PushDtl.push_imp");
	}

	/**
	 * [DestTab]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDestTab(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.DestTabPanel = p.beansFactory.createPanel("DestTab");
		p.DestTabTab = p.beansFactory.createTabbedPane("DestTab.tab");
		// ブロックの項目の初期化
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCtrl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.CtrlPanel = p.beansFactory.createPanel("Ctrl");
		// ブロックの項目の初期化
		p.Ctrl_upd = p.beansFactory.createButton("Ctrl.upd", "upd");
	}

	/**
	 * [TaskTab]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTaskTab(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.add(p.TaskTabPanel);
		p.setLastBeans(p.TaskTabPanel);
		p.TaskTabPanel.setNextBeans(p.CtrlPanel);
		p.TaskTabPanel.add(p.TaskTabTab);
		p.TaskTabPanel.setLastBeans(p.TaskTabTab);
		p.TaskTabPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.TaskTabTab.add(p.PropPanel, "TaskTab.prop");
		p.TaskTabTab.setLastBeans(p.PropPanel);
		p.PropPanel.setNextBeans(p.SchePanel);
		p.TaskTabTab.add(p.SchePanel, "TaskTab.sche");
		p.SchePanel.setNextBeans(p.CondPanel);
		p.TaskTabTab.add(p.CondPanel, "TaskTab.cond");
		p.CondPanel.setNextBeans(p.ParamPanel);
		p.TaskTabTab.add(p.ParamPanel, "TaskTab.param");
		p.ParamPanel.setNextBeans(p.PushPanel);
		p.TaskTabTab.add(p.PushPanel, "TaskTab.push");
	}

	/**
	 * [Prop]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitProp(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PropPanel.setNextBeans(p.SchePanel);
		p.PropPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.PropPanel.add(p.PropDtlPanel, null);
		p.PropPanel.setLastBeans(p.PropDtlPanel);
	}

	/**
	 * [PropDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPropDtl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PropDtlPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.PropDtlPanel.add(p.PropDtl_task_nm_Label);
		p.PropDtlPanel.add(p.PropDtl_task_nm);
		p.PropDtlPanel.setLastBeans(p.PropDtl_task_nm);
		p.PropDtl_task_nm.setNextBeans(p.PropDtl_inv_flg);
		p.PropDtl_task_nm.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.task_nm_META);
		p.PropDtlPanel.add(p.PropDtl_inv_flg);
		p.PropDtl_inv_flg.setNextBeans(p.PropDtl_task_type);
		p.PropDtl_inv_flg.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.inv_flg_META);
		p.PropDtlPanel.add(p.PropDtl_task_type);
		p.PropDtl_task_type.setNextBeans(p.PropDtl_task_type_nm);
		p.PropDtl_task_type.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.task_type_META);
		p.PropDtl_task_type_nm.setListType(MCListType.STRICT);
		p.PropDtl_task_type_nm.setLinkBeans(p.PropDtl_task_type);
		p.PropDtlPanel.add(p.PropDtl_task_type_nm_Label);
		p.PropDtlPanel.add(p.PropDtl_task_type_nm);
		p.PropDtl_task_type_nm.setNextBeans(p.PropDtl_co_cd);
		p.PropDtl_task_type_nm.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.task_type_nm_META);
		p.PropDtl_co_cd.setListType(MCListType.STRICT);
		p.PropDtl_co_cd.setLinkBeans(p.PropDtl_co_nm);
		p.PropDtlPanel.add(p.PropDtl_co_cd_Label);
		p.PropDtlPanel.add(p.PropDtl_co_cd);
		p.PropDtl_co_cd.setNextBeans(p.PropDtl_co_nm);
		p.PropDtl_co_cd.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.co_cd_META);
		p.PropDtlPanel.add(p.PropDtl_co_nm);
		p.PropDtl_co_nm.setNextBeans(p.PropDtl_user_id);
		p.PropDtl_co_nm.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.co_nm_META);
		p.PropDtl_user_id.setListType(MCListType.STRICT);
		p.PropDtl_user_id.setLinkBeans(p.PropDtl_user_nm);
		p.PropDtlPanel.add(p.PropDtl_user_id_Label);
		p.PropDtlPanel.add(p.PropDtl_user_id);
		p.PropDtl_user_id.setNextBeans(p.PropDtl_user_nm);
		p.PropDtl_user_id.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.user_id_META);
		p.PropDtlPanel.add(p.PropDtl_user_nm);
		p.PropDtl_user_nm.setNextBeans(p.PropDtl_mining_id);
		p.PropDtl_user_nm.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.user_nm_META);
		p.PropDtlPanel.add(p.PropDtl_mining_id);
		p.PropDtl_mining_id.setNextBeans(p.PropDtl_mining_nm);
		p.PropDtl_mining_id.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.mining_id_META);
		p.PropDtl_mining_nm.setListType(MCListType.STRICT);
		p.PropDtl_mining_nm.setLinkBeans(p.PropDtl_mining_id);
		p.PropDtlPanel.add(p.PropDtl_mining_nm_Label);
		p.PropDtlPanel.add(p.PropDtl_mining_nm);
		p.PropDtl_mining_nm.setRow(p.getPropDtlR(), mcframe.clientFSBA.FSBAP0820.TaskR.mining_nm_META);
	}

	/**
	 * [Sche]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSche(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.SchePanel.setNextBeans(p.CondPanel);
		p.SchePanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.SchePanel.add(p.ScheDtlPanel, null);
		p.SchePanel.setLastBeans(p.ScheDtlPanel);
		p.ScheDtlPanel.setNextBeans(p.ScheCtrlPanel);
		p.SchePanel.add(p.ScheCtrlPanel, null);
	}

	/**
	 * [ScheDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitScheDtl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.ScheDtlPanel.add(p.ScheDtlScrollPane);
		p.ScheDtlPanel.setLastBeans(p.ScheDtlTable);
		p.ScheDtlScrollPane.setViewportView(p.ScheDtlTable);
		p.ScheDtlTable.setList(p.getScheDtlL());
		p.ScheDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ScheCtrl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitScheCtrl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.ScheCtrlPanel.setValueCheck(false);
		p.ScheCtrlPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.ScheCtrl_add.setFunctionKey(MCFunctionKey.F5);
		p.ScheCtrlPanel.add(p.ScheCtrl_add);
		p.ScheCtrlPanel.setLastBeans(p.ScheCtrl_add);
		p.ScheCtrl_add.setNextBeans(p.ScheCtrl_cpy);
		p.ScheCtrl_cpy.setFunctionKey(MCFunctionKey.F6);
		p.ScheCtrlPanel.add(p.ScheCtrl_cpy);
		p.ScheCtrl_cpy.setNextBeans(p.ScheCtrl_mod);
		p.ScheCtrl_mod.setFunctionKey(MCFunctionKey.F7);
		p.ScheCtrlPanel.add(p.ScheCtrl_mod);
		p.ScheCtrl_mod.setNextBeans(p.ScheCtrl_del);
		p.ScheCtrl_del.setFunctionKey(MCFunctionKey.F17);
		p.ScheCtrlPanel.add(p.ScheCtrl_del);
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCond(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.CondPanel.setNextBeans(p.ParamPanel);
		p.CondPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
	}

	/**
	 * [Param]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitParam(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.ParamPanel.setNextBeans(p.PushPanel);
		p.ParamPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
	}

	/**
	 * [Push]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPush(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PushPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.PushPanel.add(p.PushDtlPanel, null);
		p.PushPanel.setLastBeans(p.PushDtlPanel);
		p.PushDtlPanel.setNextBeans(p.DestTabPanel);
		p.PushPanel.add(p.DestTabPanel, null);
	}

	/**
	 * [PushDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPushDtl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.PushDtlPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.PushDtlPanel.setLastBeans(p.PushDtl_msg_type_Group);
		p.PushDtl_msg_type_Group.setFirstBeans(p.PushDtl_msg_type_id);
		p.PushDtl_msg_type_id.setActionCommand("0");
		p.PushDtl_msg_type_Group.add(p.PushDtl_msg_type_id);
		p.PushDtlPanel.add(p.PushDtl_msg_type_id);
		p.PushDtl_msg_type_id.setNextBeans(p.PushDtl_msg_type_edit);
		p.PushDtl_msg_type_edit.setActionCommand("1");
		p.PushDtl_msg_type_Group.add(p.PushDtl_msg_type_edit);
		p.PushDtlPanel.add(p.PushDtl_msg_type_edit);
		p.PushDtl_msg_type_Group.setRow(p.getPushDtlR(), mcframe.clientFSBA.FSBAP0850.PushDtlR.msg_type_META);
		p.PushDtl_msg_type_Group.setNextBeans(p.PushDtl_msg_id);
		p.PushDtlPanel.add(p.PushDtl_msg_id_Label);
		p.PushDtlPanel.add(p.PushDtl_msg_id);
		p.PushDtl_msg_id.setNextBeans(p.PushDtl_msg);
		p.PushDtl_msg_id.setRow(p.getPushDtlR(), mcframe.clientFSBA.FSBAP0850.PushDtlR.msg_id_META);
		p.PushDtlPanel.add(p.PushDtl_msg_Label);
		p.PushDtl_msgScrollPane.getViewport().add(p.PushDtl_msg);
		p.PushDtlPanel.add(p.PushDtl_msgScrollPane);
		p.PushDtl_msg.setNextBeans(p.PushDtl_push_type);
		p.PushDtl_msg.setRow(p.getPushDtlR(), mcframe.clientFSBA.FSBAP0850.PushDtlR.msg_META);
		p.PushDtlPanel.add(p.PushDtl_push_type_Label);
		p.PushDtlPanel.add(p.PushDtl_push_type);
		p.PushDtl_push_type.setNextBeans(p.PushDtl_push_type_nm);
		p.PushDtl_push_type.setRow(p.getPushDtlR(), mcframe.clientFSBA.FSBAP0850.PushDtlR.push_type_META);
		p.PushDtl_push_type_nm.setListType(MCListType.STRICT);
		p.PushDtl_push_type_nm.setLinkBeans(p.PushDtl_push_type);
		p.PushDtlPanel.add(p.PushDtl_push_type_nm_Label);
		p.PushDtlPanel.add(p.PushDtl_push_type_nm);
		p.PushDtl_push_type_nm.setNextBeans(p.PushDtl_push_imp);
		p.PushDtl_push_type_nm.setRow(p.getPushDtlR(), mcframe.clientFSBA.FSBAP0850.PushDtlR.push_type_nm_META);
		p.PushDtlPanel.add(p.PushDtl_push_imp);
		p.PushDtl_push_imp.setRow(p.getPushDtlR(), mcframe.clientFSBA.FSBAP0850.PushDtlR.push_imp_META);
	}

	/**
	 * [DestTab]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDestTab(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.DestTabPanel.add(p.DestTabTab);
		p.DestTabPanel.setLastBeans(p.DestTabTab);
		p.DestTabPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCtrl(FSBAP_MiningTaskDtl p) {
		// ブロック関連の初期化
		p.add(p.CtrlPanel);
		p.CtrlPanel.setValueCheck(false);
		p.CtrlPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Ctrl_upd.setIcon("REGISTER");
		p.Ctrl_upd.setFunctionKey(MCFunctionKey.F9);
		p.CtrlPanel.add(p.Ctrl_upd);
		p.CtrlPanel.setLastBeans(p.Ctrl_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_MiningTaskDtl_FW.mcInitTaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitPropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitSche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitCond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitParam((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitPush((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitPushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitDestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.mcInitCtrl((FSBAP_MiningTaskDtl)this);

		// [ENABLE]ステータスのモードの設定
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_TaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_Prop((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_PropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_Sche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_ScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_ScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_Cond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_CondDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_MethodDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_Param((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_Push((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_PushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_DestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_Ctrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_ParamProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENABLE_ParamDtl((FSBAP_MiningTaskDtl)this);

		// [ENTRY]ステータスのモードの設定
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_TaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_Prop((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_PropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_Sche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_ScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_ScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_Cond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_CondDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_MethodDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_Param((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_Push((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_PushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_DestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_Ctrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_ParamProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitENTRY_ParamDtl((FSBAP_MiningTaskDtl)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_TaskTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_Prop((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_PropDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_Sche((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_ScheDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_ScheCtrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_Cond((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_CondDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_MethodDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_Param((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_Push((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_PushDtl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_DestTab((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_Ctrl((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_ParamProp((FSBAP_MiningTaskDtl)this);
		FSBAP_MiningTaskDtl_FW.statusInitREAD__ONLY_ParamDtl((FSBAP_MiningTaskDtl)this);

	}

	/**
	 *  [TaskTab]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTaskTab(FSBAP_MiningTaskDtl p) {
		p.TaskTabTab.addAllListener(p);
	}

	/**
	 *  [Prop]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitProp(FSBAP_MiningTaskDtl p) {
	}

	/**
	 *  [PropDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPropDtl(FSBAP_MiningTaskDtl p) {
		p.PropDtl_task_nm.setListListener(p);
		p.PropDtl_task_nm.addAllListener(p);
		p.PropDtl_inv_flg.addAllListener(p);
		p.PropDtl_task_type.setListListener(p);
		p.PropDtl_task_type.addAllListener(p);
		p.PropDtl_task_type_nm.setListListener(p);
		p.PropDtl_task_type_nm.addAllListener(p);
		p.PropDtl_co_cd.setListListener(p);
		p.PropDtl_co_cd.addAllListener(p);
		p.PropDtl_co_nm.setListListener(p);
		p.PropDtl_co_nm.addAllListener(p);
		p.PropDtl_user_id.setListListener(p);
		p.PropDtl_user_id.addAllListener(p);
		p.PropDtl_user_nm.setListListener(p);
		p.PropDtl_user_nm.addAllListener(p);
		p.PropDtl_mining_id.setListListener(p);
		p.PropDtl_mining_id.addAllListener(p);
		p.PropDtl_mining_nm.setListListener(p);
		p.PropDtl_mining_nm.addAllListener(p);
	}

	/**
	 *  [Sche]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSche(FSBAP_MiningTaskDtl p) {
	}

	/**
	 *  [ScheDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitScheDtl(FSBAP_MiningTaskDtl p) {
		p.ScheDtlTable.addAllListener(p);
		p.columnScheDtl_inv_flg.addAllListener(p);
		p.columnScheDtl_time.addAllListener(p);
		p.columnScheDtl_time.setListListener(p);
		p.columnScheDtl_desc.addAllListener(p);
		p.columnScheDtl_desc.setListListener(p);
	}

	/**
	 *  [ScheCtrl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitScheCtrl(FSBAP_MiningTaskDtl p) {
		p.ScheCtrl_add.addAllListener(p);
		p.ScheCtrl_add.setAPMethodName("doScheCtrl_add");
		p.ScheCtrl_cpy.addAllListener(p);
		p.ScheCtrl_cpy.setAPMethodName("doScheCtrl_cpy");
		p.ScheCtrl_mod.addAllListener(p);
		p.ScheCtrl_mod.setAPMethodName("doScheCtrl_mod");
		p.ScheCtrl_del.addAllListener(p);
		p.ScheCtrl_del.setAPMethodName("doScheCtrl_del");
	}

	/**
	 *  [Cond]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCond(FSBAP_MiningTaskDtl p) {
	}

	/**
	 *  [Param]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitParam(FSBAP_MiningTaskDtl p) {
	}

	/**
	 *  [Push]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPush(FSBAP_MiningTaskDtl p) {
	}

	/**
	 *  [PushDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPushDtl(FSBAP_MiningTaskDtl p) {
		p.PushDtl_msg_type_Group.addAllListener(p);
		p.PushDtl_msg_type_id.addAllListener(p);
		p.PushDtl_msg_type_edit.addAllListener(p);
		p.PushDtl_msg_id.setListListener(p);
		p.PushDtl_msg_id.addAllListener(p);
		p.PushDtl_msg.addAllListener(p);
		p.PushDtl_push_type.setListListener(p);
		p.PushDtl_push_type.addAllListener(p);
		p.PushDtl_push_type_nm.setListListener(p);
		p.PushDtl_push_type_nm.addAllListener(p);
		p.PushDtl_push_imp.addAllListener(p);
	}

	/**
	 *  [DestTab]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDestTab(FSBAP_MiningTaskDtl p) {
		p.DestTabTab.addAllListener(p);
	}

	/**
	 *  [Ctrl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCtrl(FSBAP_MiningTaskDtl p) {
		p.Ctrl_upd.addAllListener(p);
		p.Ctrl_upd.setAPMethodName("doCtrl_upd");
	}

	/**
	 * [ENABLE]ステータスの[TaskTab]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_TaskTab(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[Prop]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Prop(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[PropDtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_PropDtl(FSBAP_MiningTaskDtl p){
		p.PropDtl_task_nm.putMode(p, ENABLE, MCMode.REQUIRED);
		p.PropDtl_inv_flg.putMode(p, ENABLE, MCMode.REQUIRED);
		p.PropDtl_task_type.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.PropDtl_task_type_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.PropDtl_co_cd.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.PropDtl_co_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.PropDtl_user_id.putMode(p, ENABLE, MCMode.REQUIRED);
		p.PropDtl_user_nm.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.PropDtl_mining_id.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.PropDtl_mining_nm.putMode(p, ENABLE, MCMode.READ_ONLY);

	}

	/**
	 * [ENABLE]ステータスの[Sche]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Sche(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[ScheDtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_ScheDtl(FSBAP_MiningTaskDtl p){
		p.columnScheDtl_inv_flg.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnScheDtl_time.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnScheDtl_desc.putMode(p, ENABLE, MCMode.READ_ONLY);

	}

	/**
	 * [ENABLE]ステータスの[ScheCtrl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_ScheCtrl(FSBAP_MiningTaskDtl p){
		p.ScheCtrl_add.putMode(p, ENABLE, MCMode.ENABLE);
		p.ScheCtrl_cpy.putMode(p, ENABLE, MCMode.ENABLE);
		p.ScheCtrl_mod.putMode(p, ENABLE, MCMode.ENABLE);
		p.ScheCtrl_del.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Cond(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[CondDtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_CondDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[MethodDtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_MethodDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[Param]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Param(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[Push]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Push(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[PushDtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_PushDtl(FSBAP_MiningTaskDtl p){
		p.PushDtl_msg_type_Group.putMode(p, ENABLE, MCMode.REQUIRED);
		p.PushDtl_msg_id.putMode(p, ENABLE, MCMode.ENABLE);
		p.PushDtl_msg.putMode(p, ENABLE, MCMode.ENABLE);
		p.PushDtl_push_type.putMode(p, ENABLE, MCMode.INVISIBLE);
		p.PushDtl_push_type_nm.putMode(p, ENABLE, MCMode.REQUIRED);
		p.PushDtl_push_imp.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[DestTab]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_DestTab(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Ctrl(FSBAP_MiningTaskDtl p){
		p.Ctrl_upd.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[ParamProp]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_ParamProp(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENABLE]ステータスの[ParamDtl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_ParamDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[TaskTab]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_TaskTab(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[Prop]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Prop(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[PropDtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_PropDtl(FSBAP_MiningTaskDtl p){
		p.PropDtl_task_nm.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PropDtl_inv_flg.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PropDtl_task_type.putMode(p, ENTRY, MCMode.INVISIBLE);
		p.PropDtl_task_type_nm.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PropDtl_co_cd.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PropDtl_co_nm.putMode(p, ENTRY, MCMode.READ_ONLY);
		p.PropDtl_user_id.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PropDtl_user_nm.putMode(p, ENTRY, MCMode.READ_ONLY);
		p.PropDtl_mining_id.putMode(p, ENTRY, MCMode.INVISIBLE);
		p.PropDtl_mining_nm.putMode(p, ENTRY, MCMode.REQUIRED);

	}

	/**
	 * [ENTRY]ステータスの[Sche]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Sche(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[ScheDtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_ScheDtl(FSBAP_MiningTaskDtl p){
		p.columnScheDtl_inv_flg.putMode(p, ENTRY, MCMode.READ_ONLY);
		p.columnScheDtl_time.putMode(p, ENTRY, MCMode.READ_ONLY);
		p.columnScheDtl_desc.putMode(p, ENTRY, MCMode.READ_ONLY);

	}

	/**
	 * [ENTRY]ステータスの[ScheCtrl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_ScheCtrl(FSBAP_MiningTaskDtl p){
		p.ScheCtrl_add.putMode(p, ENTRY, MCMode.ENABLE);
		p.ScheCtrl_cpy.putMode(p, ENTRY, MCMode.ENABLE);
		p.ScheCtrl_mod.putMode(p, ENTRY, MCMode.ENABLE);
		p.ScheCtrl_del.putMode(p, ENTRY, MCMode.ENABLE);

	}

	/**
	 * [ENTRY]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Cond(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[CondDtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_CondDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[MethodDtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_MethodDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[Param]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Param(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[Push]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Push(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[PushDtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_PushDtl(FSBAP_MiningTaskDtl p){
		p.PushDtl_msg_type_Group.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PushDtl_msg_id.putMode(p, ENTRY, MCMode.ENABLE);
		p.PushDtl_msg.putMode(p, ENTRY, MCMode.ENABLE);
		p.PushDtl_push_type.putMode(p, ENTRY, MCMode.INVISIBLE);
		p.PushDtl_push_type_nm.putMode(p, ENTRY, MCMode.REQUIRED);
		p.PushDtl_push_imp.putMode(p, ENTRY, MCMode.ENABLE);

	}

	/**
	 * [ENTRY]ステータスの[DestTab]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_DestTab(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_Ctrl(FSBAP_MiningTaskDtl p){
		p.Ctrl_upd.putMode(p, ENTRY, MCMode.ENABLE);

	}

	/**
	 * [ENTRY]ステータスの[ParamProp]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_ParamProp(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [ENTRY]ステータスの[ParamDtl]ブロックのモードの設定
	 */
	protected static void statusInitENTRY_ParamDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[TaskTab]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_TaskTab(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Prop]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Prop(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[PropDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_PropDtl(FSBAP_MiningTaskDtl p){
		p.PropDtl_task_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_inv_flg.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_task_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.PropDtl_task_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_co_cd.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_co_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_user_id.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_user_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PropDtl_mining_id.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.PropDtl_mining_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[Sche]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Sche(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[ScheDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_ScheDtl(FSBAP_MiningTaskDtl p){
		p.columnScheDtl_inv_flg.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnScheDtl_time.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.columnScheDtl_desc.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[ScheCtrl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_ScheCtrl(FSBAP_MiningTaskDtl p){
		p.ScheCtrl_add.putMode(p, READ_ONLY, MCMode.DISABLE);
		p.ScheCtrl_cpy.putMode(p, READ_ONLY, MCMode.DISABLE);
		p.ScheCtrl_mod.putMode(p, READ_ONLY, MCMode.DISABLE);
		p.ScheCtrl_del.putMode(p, READ_ONLY, MCMode.DISABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Cond(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[CondDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_CondDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[MethodDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MethodDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Param]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Param(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Push]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Push(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[PushDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_PushDtl(FSBAP_MiningTaskDtl p){
		p.PushDtl_msg_type_Group.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PushDtl_msg_id.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PushDtl_msg.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PushDtl_push_type.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.PushDtl_push_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.PushDtl_push_imp.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[DestTab]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_DestTab(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Ctrl(FSBAP_MiningTaskDtl p){
		p.Ctrl_upd.putMode(p, READ_ONLY, MCMode.DISABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[ParamProp]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_ParamProp(FSBAP_MiningTaskDtl p){

	}

	/**
	 * [READ_ONLY]ステータスの[ParamDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_ParamDtl(FSBAP_MiningTaskDtl p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return READ_ONLY;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_MiningTaskDtl_FW.setTableConfigScheDtl((FSBAP_MiningTaskDtl)this);
	}

	/**
	 * [ScheDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigScheDtl(FSBAP_MiningTaskDtl p) {
		p.columnScheDtl_inv_flg.setMeta(mcframe.clientFSBA.FSBAP0850.ScheDtlR.inv_flg_META);
		p.ScheDtlTable.addColumnConfig(p.columnScheDtl_inv_flg);
		p.columnScheDtl_time.setMeta(mcframe.clientFSBA.FSBAP0850.ScheDtlR.time_META);
		p.columnScheDtl_time.setFormatID("HM");
		p.ScheDtlTable.addColumnConfig(p.columnScheDtl_time);
		p.columnScheDtl_desc.setMeta(mcframe.clientFSBA.FSBAP0850.ScheDtlR.desc_META);
		p.ScheDtlTable.addColumnConfig(p.columnScheDtl_desc);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		PropDtl_task_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		PropDtl_task_type_nm.getListConfig().setPutter(getPropDtl_task_type_nm_ListPutter());
		PropDtl_co_cd.setListVisibleColumn(MCListLogic.getViewColumnName());
		PropDtl_co_cd.getListConfig().setPutter(getPropDtl_co_cd_ListPutter());
		PropDtl_user_id.setListVisibleColumn(MCListLogic.getViewColumnName());
		PropDtl_user_id.getListConfig().setPutter(getPropDtl_user_id_ListPutter());
		PropDtl_mining_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		PropDtl_mining_nm.getListConfig().setPutter(getPropDtl_mining_nm_ListPutter());
		PushDtl_push_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		PushDtl_push_type_nm.getListConfig().setPutter(getPushDtl_push_type_nm_ListPutter());
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[ENTRY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENTRYStatus() {
		status = ENTRY;
		setAllStatus(status);
	}

	/**
	 * この画面を[READ_ONLY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setREAD_ONLYStatus() {
		status = READ_ONLY;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (ENTRY.equals(status)) {
			setENTRYStatus();
		}
		else if (READ_ONLY.equals(status)) {
			setREAD_ONLYStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [PropDtl_task_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createPropDtl_task_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.MiningTaskType");
		return lp;
	}
	 
	/**
	 * [PropDtl_co_cd_ListPutter]の作成
	 */
	protected MCListPutter createPropDtl_co_cd_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.Co");
		return lp;
	}
	 
	/**
	 * [PropDtl_user_id_ListPutter]の作成
	 */
	protected MCListPutter createPropDtl_user_id_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.User");
		return lp;
	}
	 
	/**
	 * [PropDtl_mining_nm_ListPutter]の作成
	 */
	protected MCListPutter createPropDtl_mining_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.MiningInfo");
		return lp;
	}
	 
	/**
	 * [PushDtl_push_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createPushDtl_push_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.PushType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == PropDtl_task_type_nm) return getPropDtl_task_type_nm(row, info);
		if(combo == PropDtl_co_cd) return getPropDtl_co_cd(row, info);
		if(combo == PropDtl_user_id) return getPropDtl_user_id(row, info);
		if(combo == PropDtl_mining_nm) return getPropDtl_mining_nm(row, info);
		if(combo == PushDtl_push_type_nm) return getPushDtl_push_type_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == ScheCtrl_add) doScheCtrl_add(info);
		else if (ap == ScheCtrl_cpy) doScheCtrl_cpy(info);
		else if (ap == ScheCtrl_mod) doScheCtrl_mod(info);
		else if (ap == ScheCtrl_del) doScheCtrl_del(info);
		else if (ap == Ctrl_upd) doCtrl_upd(info);
	}

	/**
	 * [ScheCtrl]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScheCtrl_add(MCEventInfo info);

	/**
	 * [ScheCtrl]パネルの[cpy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScheCtrl_cpy(MCEventInfo info);

	/**
	 * [ScheCtrl]パネルの[mod]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScheCtrl_mod(MCEventInfo info);

	/**
	 * [ScheCtrl]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScheCtrl_del(MCEventInfo info);

	/**
	 * [Ctrl]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCtrl_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == TaskTabTab) return doTaskTab_VC(info);
		if (vc == ScheDtlTable) return doScheDtl_VC(info);
		if (vc == DestTabTab) return doDestTab_VC(info);
		if (vc == PropDtl_task_nm) return doPropDtl_task_nm_VC(info);
		if (vc == PropDtl_inv_flg) return doPropDtl_inv_flg_VC(info);
		if (vc == PropDtl_task_type) return doPropDtl_task_type_VC(info);
		if (vc == PropDtl_task_type_nm) return doPropDtl_task_type_nm_VC(info);
		if (vc == PropDtl_co_cd) return doPropDtl_co_cd_VC(info);
		if (vc == PropDtl_co_nm) return doPropDtl_co_nm_VC(info);
		if (vc == PropDtl_user_id) return doPropDtl_user_id_VC(info);
		if (vc == PropDtl_user_nm) return doPropDtl_user_nm_VC(info);
		if (vc == PropDtl_mining_id) return doPropDtl_mining_id_VC(info);
		if (vc == PropDtl_mining_nm) return doPropDtl_mining_nm_VC(info);
		if (vc == columnScheDtl_inv_flg) return doScheDtl_inv_flg_VC(info);
		if (vc == columnScheDtl_time) return doScheDtl_time_VC(info);
		if (vc == columnScheDtl_desc) return doScheDtl_desc_VC(info);
		if (vc == PushDtl_msg_type_Group) return doPushDtl_msg_type_VC(info);
		if (vc == PushDtl_msg_id) return doPushDtl_msg_id_VC(info);
		if (vc == PushDtl_msg) return doPushDtl_msg_VC(info);
		if (vc == PushDtl_push_type) return doPushDtl_push_type_VC(info);
		if (vc == PushDtl_push_type_nm) return doPushDtl_push_type_nm_VC(info);
		if (vc == PushDtl_push_imp) return doPushDtl_push_imp_VC(info);
		return true;
	}

	/**
	 * [TaskTab]Tabの選択Tabが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTaskTab_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ScheDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScheDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [DestTab]Tabの選択Tabが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDestTab_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[task_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_task_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[inv_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_inv_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[task_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_task_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[task_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_task_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[co_cd]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_co_cd_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[co_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_co_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[user_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_user_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[user_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_user_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[mining_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_mining_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PropDtl]パネルの[mining_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPropDtl_mining_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ScheDtl]パネルの[inv_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScheDtl_inv_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ScheDtl]パネルの[time]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScheDtl_time_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ScheDtl]パネルの[desc]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScheDtl_desc_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PushDtl]パネルの[msg_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPushDtl_msg_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PushDtl]パネルの[msg_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPushDtl_msg_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PushDtl]パネルの[msg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPushDtl_msg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PushDtl]パネルの[push_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPushDtl_push_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PushDtl]パネルの[push_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPushDtl_push_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PushDtl]パネルの[push_imp]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPushDtl_push_imp_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == TaskTabTab) doTaskTab_NC(info);
		else if (nc == ScheDtlTable) doScheDtl_NC(info);
		else if (nc == DestTabTab) doDestTab_NC(info);
		else if (nc == PropDtl_task_nm) doPropDtl_task_nm_NC(info);
		else if (nc == PropDtl_inv_flg) doPropDtl_inv_flg_NC(info);
		else if (nc == PropDtl_task_type) doPropDtl_task_type_NC(info);
		else if (nc == PropDtl_task_type_nm) doPropDtl_task_type_nm_NC(info);
		else if (nc == PropDtl_co_cd) doPropDtl_co_cd_NC(info);
		else if (nc == PropDtl_co_nm) doPropDtl_co_nm_NC(info);
		else if (nc == PropDtl_user_id) doPropDtl_user_id_NC(info);
		else if (nc == PropDtl_user_nm) doPropDtl_user_nm_NC(info);
		else if (nc == PropDtl_mining_id) doPropDtl_mining_id_NC(info);
		else if (nc == PropDtl_mining_nm) doPropDtl_mining_nm_NC(info);
		else if (nc == columnScheDtl_inv_flg) doScheDtl_inv_flg_NC(info);
		else if (nc == columnScheDtl_time) doScheDtl_time_NC(info);
		else if (nc == columnScheDtl_desc) doScheDtl_desc_NC(info);
		else if (nc == PushDtl_msg_type_Group) doPushDtl_msg_type_NC(info);
		else if (nc == PushDtl_msg_id) doPushDtl_msg_id_NC(info);
		else if (nc == PushDtl_msg) doPushDtl_msg_NC(info);
		else if (nc == PushDtl_push_type) doPushDtl_push_type_NC(info);
		else if (nc == PushDtl_push_type_nm) doPushDtl_push_type_nm_NC(info);
		else if (nc == PushDtl_push_imp) doPushDtl_push_imp_NC(info);
	}

	/**
	 * [TaskTab]Tabの選択Tabが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTaskTab_NC(MCEventInfo info){
	}

	/**
	 * [ScheDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_NC(MCEventInfo info){
	}

	/**
	 * [DestTab]Tabの選択Tabが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDestTab_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_nm_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[inv_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_inv_flg_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_cd]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_cd_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_nm_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_id_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_nm_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_id_NC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_nm_NC(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[inv_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_inv_flg_NC(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[time]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_time_NC(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[desc]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_desc_NC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_type_NC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_id_NC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_NC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_NC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_imp]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_imp_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == TaskTabTab) doTaskTab_NE(info);
		else if (ne == ScheDtlTable) doScheDtl_NE(info);
		else if (ne == DestTabTab) doDestTab_NE(info);
		else if (ne == PropDtl_task_nm) doPropDtl_task_nm_NE(info);
		else if (ne == PropDtl_inv_flg) doPropDtl_inv_flg_NE(info);
		else if (ne == PropDtl_task_type) doPropDtl_task_type_NE(info);
		else if (ne == PropDtl_task_type_nm) doPropDtl_task_type_nm_NE(info);
		else if (ne == PropDtl_co_cd) doPropDtl_co_cd_NE(info);
		else if (ne == PropDtl_co_nm) doPropDtl_co_nm_NE(info);
		else if (ne == PropDtl_user_id) doPropDtl_user_id_NE(info);
		else if (ne == PropDtl_user_nm) doPropDtl_user_nm_NE(info);
		else if (ne == PropDtl_mining_id) doPropDtl_mining_id_NE(info);
		else if (ne == PropDtl_mining_nm) doPropDtl_mining_nm_NE(info);
		else if (ne == columnScheDtl_inv_flg) doScheDtl_inv_flg_NE(info);
		else if (ne == columnScheDtl_time) doScheDtl_time_NE(info);
		else if (ne == columnScheDtl_desc) doScheDtl_desc_NE(info);
		else if (ne == PushDtl_msg_type_Group) doPushDtl_msg_type_NE(info);
		else if (ne == PushDtl_msg_id) doPushDtl_msg_id_NE(info);
		else if (ne == PushDtl_msg) doPushDtl_msg_NE(info);
		else if (ne == PushDtl_push_type) doPushDtl_push_type_NE(info);
		else if (ne == PushDtl_push_type_nm) doPushDtl_push_type_nm_NE(info);
		else if (ne == PushDtl_push_imp) doPushDtl_push_imp_NE(info);
	}

	/**
	 * [TaskTab]TabのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTaskTab_NE(MCEventInfo info){
	}

	/**
	 * [ScheDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_NE(MCEventInfo info){
	}

	/**
	 * [DestTab]TabのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDestTab_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_nm_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[inv_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_inv_flg_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_cd]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_cd_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_nm_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_id_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_nm_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_id_NE(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_nm_NE(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[inv_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_inv_flg_NE(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[time]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_time_NE(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[desc]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_desc_NE(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_type_NE(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_id_NE(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_NE(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_NE(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_imp]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_imp_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == TaskTabTab) doTaskTab_NX(info);
		else if (nx == ScheDtlTable) doScheDtl_NX(info);
		else if (nx == DestTabTab) doDestTab_NX(info);
		else if (nx == PropDtl_task_nm) doPropDtl_task_nm_NX(info);
		else if (nx == PropDtl_inv_flg) doPropDtl_inv_flg_NX(info);
		else if (nx == PropDtl_task_type) doPropDtl_task_type_NX(info);
		else if (nx == PropDtl_task_type_nm) doPropDtl_task_type_nm_NX(info);
		else if (nx == PropDtl_co_cd) doPropDtl_co_cd_NX(info);
		else if (nx == PropDtl_co_nm) doPropDtl_co_nm_NX(info);
		else if (nx == PropDtl_user_id) doPropDtl_user_id_NX(info);
		else if (nx == PropDtl_user_nm) doPropDtl_user_nm_NX(info);
		else if (nx == PropDtl_mining_id) doPropDtl_mining_id_NX(info);
		else if (nx == PropDtl_mining_nm) doPropDtl_mining_nm_NX(info);
		else if (nx == columnScheDtl_inv_flg) doScheDtl_inv_flg_NX(info);
		else if (nx == columnScheDtl_time) doScheDtl_time_NX(info);
		else if (nx == columnScheDtl_desc) doScheDtl_desc_NX(info);
		else if (nx == PushDtl_msg_type_Group) doPushDtl_msg_type_NX(info);
		else if (nx == PushDtl_msg_id) doPushDtl_msg_id_NX(info);
		else if (nx == PushDtl_msg) doPushDtl_msg_NX(info);
		else if (nx == PushDtl_push_type) doPushDtl_push_type_NX(info);
		else if (nx == PushDtl_push_type_nm) doPushDtl_push_type_nm_NX(info);
		else if (nx == PushDtl_push_imp) doPushDtl_push_imp_NX(info);
	}

	/**
	 * [TaskTab]TabのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTaskTab_NX(MCEventInfo info){
	}

	/**
	 * [ScheDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_NX(MCEventInfo info){
	}

	/**
	 * [DestTab]TabのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDestTab_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_nm_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[inv_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_inv_flg_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_cd]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_cd_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_nm_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_id_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_nm_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_id_NX(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_nm_NX(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[inv_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_inv_flg_NX(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[time]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_time_NX(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[desc]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_desc_NX(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_type_NX(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_id_NX(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_NX(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_NX(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_imp]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_imp_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == PropDtl_task_nm) doPropDtl_task_nm_LC(info);
		else if (lc == PropDtl_task_type) doPropDtl_task_type_LC(info);
		else if (lc == PropDtl_task_type_nm) doPropDtl_task_type_nm_LC(info);
		else if (lc == PropDtl_co_cd) doPropDtl_co_cd_LC(info);
		else if (lc == PropDtl_co_nm) doPropDtl_co_nm_LC(info);
		else if (lc == PropDtl_user_id) doPropDtl_user_id_LC(info);
		else if (lc == PropDtl_user_nm) doPropDtl_user_nm_LC(info);
		else if (lc == PropDtl_mining_id) doPropDtl_mining_id_LC(info);
		else if (lc == PropDtl_mining_nm) doPropDtl_mining_nm_LC(info);
		else if (lc == columnScheDtl_time) doScheDtl_time_LC(info);
		else if (lc == columnScheDtl_desc) doScheDtl_desc_LC(info);
		else if (lc == PushDtl_msg_id) doPushDtl_msg_id_LC(info);
		else if (lc == PushDtl_push_type) doPushDtl_push_type_LC(info);
		else if (lc == PushDtl_push_type_nm) doPushDtl_push_type_nm_LC(info);
	}

	/**
	 * [PropDtl]パネルの[task_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_nm_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[task_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_task_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_cd]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_cd_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[co_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_co_nm_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_id_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[user_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_user_nm_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_id_LC(MCEventInfo info){
	}

	/**
	 * [PropDtl]パネルの[mining_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPropDtl_mining_nm_LC(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[time]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_time_LC(MCEventInfo info){
	}

	/**
	 * [ScheDtl]パネルの[desc]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScheDtl_desc_LC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[msg_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_msg_id_LC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_LC(MCEventInfo info){
	}

	/**
	 * [PushDtl]パネルの[push_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPushDtl_push_type_nm_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[PropDtl_task_type_nm]の作成メソッド
	 */
	public MCList getPropDtl_task_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getMiningTaskType(row, info);
	}

	/**
	 * コンボ／リストのリスト[PropDtl_co_cd]の作成メソッド
	 */
	public MCList getPropDtl_co_cd(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getCo(row, info);
	}

	/**
	 * コンボ／リストのリスト[PropDtl_user_id]の作成メソッド
	 */
	public MCList getPropDtl_user_id(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getUser(row, info);
	}

	/**
	 * コンボ／リストのリスト[PropDtl_mining_nm]の作成メソッド
	 */
	public MCList getPropDtl_mining_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getMiningInfo(row, info);
	}

	/**
	 * コンボ／リストのリスト[PushDtl_push_type_nm]の作成メソッド
	 */
	public MCList getPushDtl_push_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getPushType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0820.Srch11")) {
			return new FS_FSBAL0820_Srch11Bridge();
		}
		if (id.equals("FS.FSBAL0820.Ins01")) {
			return new FS_FSBAL0820_Ins01Bridge();
		}
		if (id.equals("FS.FSBAL0820.Upd01")) {
			return new FS_FSBAL0820_Upd01Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0820_Srch11]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Srch11Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0820_Srch11;

		/** コンストラクタ */
		protected FS_FSBAL0820_Srch11Bridge() {
			p_FS_FSBAL0820_Srch11 = new MCParam(PDef.FS_FSBAL0820_Srch11_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0820_Srch11_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ScheDtlR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.CondDtlR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.MethodDtlR.class));

			p_FS_FSBAL0820_Srch11 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0820_Srch11.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0820_Srch11.addUpBlock(getPropDtlR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0820_Srch11.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0820_Srch11.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0820.TaskR up0() {
			return (mcframe.clientFSBA.FSBAP0820.TaskR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR>)down(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> down1() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR>)down(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> down2() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR>)down(2);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR> down3() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR>)down(3);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR> down4() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR>)down(4);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0820_Srch11.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ScheDtlR.class));
			p_FS_FSBAL0820_Srch11.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class));
			p_FS_FSBAL0820_Srch11.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class));
			p_FS_FSBAL0820_Srch11.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.CondDtlR.class));
			p_FS_FSBAL0820_Srch11.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.MethodDtlR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0820_Srch11;
		}

		protected void show() {
			setScheDtlL((MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR>)p_FS_FSBAL0820_Srch11.getContainerParam().getDownBlock(0));
			setParamPropL((MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR>)p_FS_FSBAL0820_Srch11.getContainerParam().getDownBlock(1));
			setParamDtlL((MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR>)p_FS_FSBAL0820_Srch11.getContainerParam().getDownBlock(2));
			setCondDtlL((MCList<mcframe.clientFSBA.FSBAP0850.CondDtlR>)p_FS_FSBAL0820_Srch11.getContainerParam().getDownBlock(3));
			setMethodDtlL((MCList<mcframe.clientFSBA.FSBAP0850.MethodDtlR>)p_FS_FSBAL0820_Srch11.getContainerParam().getDownBlock(4));
		}

		protected void clear() {
			getScheDtlL().clear();
			getParamPropL().clear();
			getParamDtlL().clear();
			getCondDtlL().clear();
			getMethodDtlL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getPropDtlR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getScheDtlL());
			result.add(getParamPropL());
			result.add(getParamDtlL());
			result.add(getCondDtlL());
			result.add(getMethodDtlL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0820_Ins01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Ins01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0820_Ins01;

		/** コンストラクタ */
		protected FS_FSBAL0820_Ins01Bridge() {
			p_FS_FSBAL0820_Ins01 = new MCParam(PDef.FS_FSBAL0820_Ins01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0820_Ins01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ScheDtlR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class));
			// Down
			param.addDownBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());

			p_FS_FSBAL0820_Ins01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0820_Ins01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0820_Ins01.addUpBlock(getPropDtlR());
			p_FS_FSBAL0820_Ins01.addUpBlock(getScheDtlL().shallowClone());
			p_FS_FSBAL0820_Ins01.addUpBlock(getParamDtlL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0820_Ins01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0820_Ins01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0820.TaskR up0() {
			return (mcframe.clientFSBA.FSBAP0820.TaskR)up(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> up1() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR>)up(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> up2() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR>)up(2);
		}

		protected mcframe.clientFSBA.FSBAP0820.TaskR down0() {
			return (mcframe.clientFSBA.FSBAP0820.TaskR)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0820_Ins01.addDownBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());
		}
		protected MCParam param() {
			return p_FS_FSBAL0820_Ins01;
		}

		protected void show() {
			setPropDtlR((mcframe.clientFSBA.FSBAP0820.TaskR)p_FS_FSBAL0820_Ins01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getPropDtlR().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getPropDtlR());
			result.add(getScheDtlL());
			result.add(getParamDtlL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getPropDtlR());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0820_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Upd01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0820_Upd01;

		/** コンストラクタ */
		protected FS_FSBAL0820_Upd01Bridge() {
			p_FS_FSBAL0820_Upd01 = new MCParam(PDef.FS_FSBAL0820_Upd01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0820_Upd01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ScheDtlR.class));
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0850.ParamDtlR.class));
			// Down
			param.addDownBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());

			p_FS_FSBAL0820_Upd01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0820_Upd01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0820_Upd01.addUpBlock(getPropDtlR());
			p_FS_FSBAL0820_Upd01.addUpBlock(getScheDtlL().shallowClone());
			p_FS_FSBAL0820_Upd01.addUpBlock(getParamDtlL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0820_Upd01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0820_Upd01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0820.TaskR up0() {
			return (mcframe.clientFSBA.FSBAP0820.TaskR)up(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR> up1() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ScheDtlR>)up(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR> up2() {
			return (MCList<mcframe.clientFSBA.FSBAP0850.ParamDtlR>)up(2);
		}

		protected mcframe.clientFSBA.FSBAP0820.TaskR down0() {
			return (mcframe.clientFSBA.FSBAP0820.TaskR)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0820_Upd01.addDownBlock(mcframe.clientFSBA.FSBAP0820.TaskR.create());
		}
		protected MCParam param() {
			return p_FS_FSBAL0820_Upd01;
		}

		protected void show() {
			setPropDtlR((mcframe.clientFSBA.FSBAP0820.TaskR)p_FS_FSBAL0820_Upd01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getPropDtlR().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getPropDtlR());
			result.add(getScheDtlL());
			result.add(getParamDtlL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getPropDtlR());
			return result;
		}
	}
}