package mcframe.clientFSBA.FSBAP0850;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_MiningTaskDtl]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0820.Srch11.UP.BLOCK0")){
			return FS_FSBAL0820_Srch11_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Srch11.DOWN.BLOCK0")){
			return FS_FSBAL0820_Srch11_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Srch11.DOWN.BLOCK1")){
			return FS_FSBAL0820_Srch11_DOWN_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0820.Srch11.DOWN.BLOCK2")){
			return FS_FSBAL0820_Srch11_DOWN_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0820.Srch11.DOWN.BLOCK3")){
			return FS_FSBAL0820_Srch11_DOWN_BLOCK3();
		}
		else if (id.equals("FS.FSBAL0820.Srch11.DOWN.BLOCK4")){
			return FS_FSBAL0820_Srch11_DOWN_BLOCK4();
		}
		else if (id.equals("FS.FSBAL0820.Ins01.UP.BLOCK0")){
			return FS_FSBAL0820_Ins01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Ins01.UP.BLOCK1")){
			return FS_FSBAL0820_Ins01_UP_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0820.Ins01.UP.BLOCK2")){
			return FS_FSBAL0820_Ins01_UP_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0820.Ins01.DOWN.BLOCK0")){
			return FS_FSBAL0820_Ins01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Upd01.UP.BLOCK0")){
			return FS_FSBAL0820_Upd01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0820.Upd01.UP.BLOCK1")){
			return FS_FSBAL0820_Upd01_UP_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0820.Upd01.UP.BLOCK2")){
			return FS_FSBAL0820_Upd01_UP_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0820.Upd01.DOWN.BLOCK0")){
			return FS_FSBAL0820_Upd01_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
			
	
	static final MCOperationInfo FS_FSBAL0820_Srch11_INFO = new MCOperationInfo("FS", "FSBAL0820", "Srch11", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0820_Srch11_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch11",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id")
			}
			,
			MCBlockDef.create("PropDtl")
		);
	}


	public static MCContainerDef FS_FSBAL0820_Srch11_DOWN_BLOCK0() {
	/** Ope.のBlock [Sche] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch11",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("sche_no", "sche_no"),
				MCItemDef.create("desc", "description"),
				MCItemDef.create("hour", "sche_hour"),
				MCItemDef.create("minute", "sche_minute"),
				MCItemDef.create("month", "sche_month"),
				MCItemDef.create("day", "sche_day"),
				MCItemDef.create("week_no", "sche_week_no"),
				MCItemDef.create("week_day", "sche_week_day"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("ScheDtl")
		);
	}
	public static MCContainerDef FS_FSBAL0820_Srch11_DOWN_BLOCK1() {
	/** Ope.のBlock [Prop] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch11",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("key", "param_key"),
				MCItemDef.create("value", "param_val")
			}
			,
			MCBlockDef.create("ParamProp")
		);
	}
	public static MCContainerDef FS_FSBAL0820_Srch11_DOWN_BLOCK2() {
	/** Ope.のBlock [Param] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch11",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("key", "param_key"),
				MCItemDef.create("value", "param_val")
			}
			,
			MCBlockDef.create("ParamDtl")
		);
	}
	public static MCContainerDef FS_FSBAL0820_Srch11_DOWN_BLOCK3() {
	/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch11",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("col_nm", "col_nm"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("scr_itm_id", "scr_itm_id"),
				MCItemDef.create("md_itm_id", "md_itm_id"),
				MCItemDef.create("data_typ", "data_typ"),
				MCItemDef.create("require_flg", "require_flg"),
				MCItemDef.create("init_val", "init_val"),
				MCItemDef.create("editable_flg", "editable_flg")
			}
			,
			MCBlockDef.create("CondDtl")
		);
	}
	public static MCContainerDef FS_FSBAL0820_Srch11_DOWN_BLOCK4() {
	/** Ope.のBlock [Method] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Srch11",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("col_id", "col_id"),
				MCItemDef.create("col_nm", "col_nm"),
				MCItemDef.create("list_order", "list_order"),
				MCItemDef.create("sum_info_typ", "sum_info_typ"),
				MCItemDef.create("sumcond", "sumcond"),
				MCItemDef.create("rank_flg", "rank_flg"),
				MCItemDef.create("rank_typ", "rank_typ"),
				MCItemDef.create("rank_size", "rank_size"),
				MCItemDef.create("date_fmt", "date_fmt"),
				MCItemDef.create("fill_dt_flg", "fill_dt_flg"),
				MCItemDef.create("fill_dt_fm", "fill_dt_fm"),
				MCItemDef.create("fill_dt_to", "fill_dt_to"),
				MCItemDef.create("formula", "formula"),
				MCItemDef.create("dec_place", "dec_place"),
				MCItemDef.create("round_mode_typ", "round_mode_typ"),
				MCItemDef.create("null_zero", "null_zero"),
				MCItemDef.create("sort_order", "sort_order"),
				MCItemDef.create("sort_typ", "sort_typ"),
				MCItemDef.create("graph_typ", "graph_typ"),
				MCItemDef.create("graph_label_flg", "graph_label_flg"),
				MCItemDef.create("graph_color", "graph_color"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("MethodDtl")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0820_Ins01_INFO = new MCOperationInfo("FS", "FSBAL0820", "Ins01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0820_Ins01_UP_BLOCK0() {
		/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("task_nm", "task_nm"),
				MCItemDef.create("task_type", "task_typ"),
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("PropDtl")
		);
	}

	public static MCContainerDef FS_FSBAL0820_Ins01_UP_BLOCK1() {
		/** Ope.のBlock [Sche] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("sche_no", "sche_no"),
				MCItemDef.create("desc", "description"),
				MCItemDef.create("hour", "sche_hour"),
				MCItemDef.create("minute", "sche_minute"),
				MCItemDef.create("month", "sche_month"),
				MCItemDef.create("day", "sche_day"),
				MCItemDef.create("week_no", "sche_week_no"),
				MCItemDef.create("week_day", "sche_week_day"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("ScheDtl")
		);
	}

	public static MCContainerDef FS_FSBAL0820_Ins01_UP_BLOCK2() {
		/** Ope.のBlock [Param] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("key", "param_key"),
				MCItemDef.create("value", "param_val")
			}
			,
			MCBlockDef.create("ParamDtl")
		);
	}


	public static MCContainerDef FS_FSBAL0820_Ins01_DOWN_BLOCK0() {
	/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Ins01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("sche_dt", "sche_dt"),
				MCItemDef.create("start_dt", "start_dt"),
				MCItemDef.create("end_dt", "end_dt"),
				MCItemDef.create("msg_id", "msg_id"),
				MCItemDef.create("msg_bind", "msg_bind"),
				MCItemDef.create("msg_lv", "msg_lv"),
				MCItemDef.create("msg", "msg"),
				MCItemDef.create("srv_id", "srv_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("PropDtl")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0820_Upd01_INFO = new MCOperationInfo("FS", "FSBAL0820", "Upd01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0820_Upd01_UP_BLOCK0() {
		/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("task_nm", "task_nm"),
				MCItemDef.create("task_type", "task_typ"),
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("inv_flg", "inv_flg"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("PropDtl")
		);
	}

	public static MCContainerDef FS_FSBAL0820_Upd01_UP_BLOCK1() {
		/** Ope.のBlock [Sche] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("sche_no", "sche_no"),
				MCItemDef.create("desc", "description"),
				MCItemDef.create("hour", "sche_hour"),
				MCItemDef.create("minute", "sche_minute"),
				MCItemDef.create("month", "sche_month"),
				MCItemDef.create("day", "sche_day"),
				MCItemDef.create("week_no", "sche_week_no"),
				MCItemDef.create("week_day", "sche_week_day"),
				MCItemDef.create("inv_flg", "inv_flg")
			}
			,
			MCBlockDef.create("ScheDtl")
		);
	}

	public static MCContainerDef FS_FSBAL0820_Upd01_UP_BLOCK2() {
		/** Ope.のBlock [Param] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("task_id", "task_id"),
				MCItemDef.create("key", "param_key"),
				MCItemDef.create("value", "param_val")
			}
			,
			MCBlockDef.create("ParamDtl")
		);
	}


	public static MCContainerDef FS_FSBAL0820_Upd01_DOWN_BLOCK0() {
	/** Ope.のBlock [Task] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0820", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("sche_dt", "sche_dt"),
				MCItemDef.create("start_dt", "start_dt"),
				MCItemDef.create("end_dt", "end_dt"),
				MCItemDef.create("msg_id", "msg_id"),
				MCItemDef.create("msg_bind", "msg_bind"),
				MCItemDef.create("msg_lv", "msg_lv"),
				MCItemDef.create("msg", "msg"),
				MCItemDef.create("srv_id", "srv_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("PropDtl")
		);
	}
	//FMCB DEF_CLASSES END
}

