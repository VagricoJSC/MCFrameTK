package mcframe.clientFSBA.FSBAP0850;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0820.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.clientCore.mining.MCMiningUtil;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.dashboard.MCDashboardUtil;
import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.commonCore.sys.MCFactory;

import mcframe.clientFSBA.FSBAP0880.DtlR;
import mcframe.clientFSBA.FSBAP0880.FSBAP_MiningTaskDtlDest;
import mcframe.clientFXBA.FXBAP0150.ConditionEditor;
import mcframe.commonFS.constant.FSC_MINING_TASK_TYPE;
import mcframe.commonFS.constant.FSC_PUSH_TYPE;
import mcframe.commonFS.constant.FSC_SEARCH_TYPE;

import java.util.LinkedHashMap;
import java.util.Map;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_MiningTaskDtl"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_MiningTaskDtl_FW extends FSBAP_MiningTaskDtl_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * コピーの場合 true
	 */
	protected boolean _copy = false;
	/**
	 * 会社コード指定（管理者用以外からの呼び出し時）
	 */
	protected String _co_cd = null;
	/**
	 * 呼び出し元のタスクデータ
	 * このRowのtask_idが未設定の場合、新規扱い
	 */
	protected TaskR _taskR;
	/**
	 * 呼び出し元のタスク一覧テーブル
	 */
	protected MCTable _taskTable;


	/**
	 * 検索条件部品を配置するパネル
	 */
	protected MCPanel CondListPanel = null;
	/**
	 * 詳細設定部品を配置するパネル
	 */
	protected MCPanel ParamListPanel = null;
	/**
	 * エディタ部品のリスト
	 */
	protected List<ConditionEditor> _condParts = new ArrayList<>();
	/**
	 * エディタ部品配置時のマージン
	 */
	protected int _margin = 5;


	/**
	 * タスク別設定部品：モジュールID
	 */
	protected String _pref_mod_id = null;
	/**
	 * タスク別設定部品：画面ID
	 */
	protected String _pref_scr_id = null;
	/**
	 * 通知利用
	 */
	protected boolean _push_use = false;
	/**
	 * 通知メッセージ設定種別：メッセージID
	 */
	protected String MSG_ID;
	/**
	 * 通知メッセージ設定種別：直接入力
	 */
	protected String MSG_EDIT;


	/**
	 * 通知先部品のマップ
	 * キー：通知先種別
	 * 値：通知先部品
	 */
	protected Map<String, FSBAP_MiningTaskDtlDest> _destPartsMap = new LinkedHashMap<>();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTaskDtl_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningTaskDtl_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FS_FSBAL0820_Srch11]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Srch11Caller<P extends FSBAP_MiningTaskDtl, B extends FS_FSBAL0820_Srch11Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FS_FSBAL0820_Srch11Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void afterCall() {
			super.afterCall();

			// スケジュール
			bridge.down0().forEach(down0R -> {
				// 時刻
				down0R.time(
						MCDate.valueOf(MCDateFieldType.HOUR,
								down0R.hour().intValue(),
								down0R.minute().intValue(),
								0)
				);
			});

			// プロパティ
			for (ParamDtlR propR : bridge.down1()) {
				switch (propR.key()) {
				case MCMiningUtil.KEY_PREFERENCE:
					// タスク別設定部品
					String pref = propR.value();
					if (pref != null) {
						int pos = pref.indexOf('.');
						if (pos >= 0) {
							_pref_mod_id = pref.substring(0, pos);
							_pref_scr_id = pref.substring(pos + 1);
						}
						else {
							_pref_mod_id = null;
							_pref_scr_id = null;
						}
					}
					break;
				case MCMiningUtil.KEY_PUSHUSE:
					// プッシュ通知利用
					String push = propR.value();
					_push_use = Boolean.parseBoolean(push);
					break;
				}
			}

			// 検索条件（編集可のみにする）
			bridge.down3().removeAll(
					bridge.down3().subList(CondDtlR.$editable_flg, false));
			// 集計情報（無効＆グループ化は除く）
			bridge.down4().removeAll(
					bridge.down4().subList(
						new MCRowMatcher<MethodDtlR>() {
							@Override
							public boolean match(MethodDtlR row) {
								// 除外対象を抽出
								return row.inv_flg() ||
										isSame(row.sum_info_typ(), MCMiningUtil.SUM_INFO_GROUP);
							}
						}
					)
			);
		}

		@Override
		protected void show() {
			super.show();

			// 検索条件タブを構成
			initCondPanel();
			// 詳細設定タブを構成
			initParamPanel();
			// 通知タブを構成
			initPushPanel();

			// 各タブの部品が揃ったので、初期ステータス再設定
			mcInitStatus();

			if (isCopyEntry()) {
				// コピー時は検索後に"新規"にする
				_taskR.task_id(null);
				getPropDtlR().task_id(null);
			}

			// FillSpace
			fillSpaceForOpen();

			// コンテナステータス初期化
			initContainerStatus();
		}

		@Override
		protected void setMode() {
			super.setMode();

			// 編集モード
			setStatus(ENABLE);
		}

		@Override
		protected void setModeNoDown() {
			super.setModeNoDown();

			// 編集モード
			setStatus(ENABLE);
		}

		@Override
		protected void showNoDownDataMsg() { 
			// メッセージ表示なし
		}
	}
	/**
	 * [FS_FSBAL0820_Ins01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Ins01Caller<P extends FSBAP_MiningTaskDtl, B extends FS_FSBAL0820_Ins01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected FS_FSBAL0820_Ins01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected boolean checkUpListParamEmpty() {
			return true;
		}

		@Override
		protected void show() {
			super.show();

			// 削除データを削除
			removeDeleteStatusRow();

			// タスクID反映
			String task_id = getPropDtlR().task_id();
			getScheDtlL().setString(ScheDtlR.$task_id, task_id);
			getParamDtlL().setString(ParamDtlR.$task_id, task_id);
		}

		@Override
		protected void statusClear() {
			super.statusClear();

			// 全ステータスクリア
			getRootPanel().statusClear();
		}

		@Override
		protected void showDownMsg() {
			// 7012-2447 システムモーダル表示（実装はFXBAP_Updater#showDownMsgに合わせる）
			MCMessageList msgList = getMessages();
			panel.sortMessageList(msgList);
			MCMessage msg = msgUpdatedWithMessages();
			if (msg != null) {
				msgList.add(0, msg);
			}
			panel.messageNoSort(msgList, MCFrameType.SYSTEM_MODAL);
		}

		@Override
		protected void resultSuccess() {
			// 呼び出し元データ更新
			MCRow.copyvalue(_taskR, getPropDtlR());// task_idが設定される

			if (isCopyEntry()) {
				// 7012-2890 miyake パラメータを通信対象に追加
				// コピー時は画面クローズ
				requestCloseWindow();
			}
			else {
				// 新規時は処理継続確認
				if (confirm(FSBAC0092) == MCMessageBox.YES_OPTION) {
					// 基本情報以外の検索
					callFS_FSBAL0820_Srch11();
				}
				else {
					// 画面クローズ
					requestCloseWindow();
				}
			}
		}

	}

	/**
	 * [FS_FSBAL0820_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0820_Upd01Caller<P extends FSBAP_MiningTaskDtl, B extends FS_FSBAL0820_Upd01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		protected FS_FSBAL0820_Upd01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected boolean execConfirm() {
			if (isCopyEntry()) {
				// コピーの登録では確認をしない
				// INS01で確認済み
				return true;
			}
			return super.execConfirm();
		}		

		@Override
		protected boolean checkUpListParamEmpty() {
			return true;
		}

		@Override
		protected void show() {
			super.show();

			// 削除データを削除
			removeDeleteStatusRow();
		}

		@Override
		protected void statusClear() {
			super.statusClear();

			// 全ステータスクリア
			getRootPanel().statusClear();
		}

		@Override
		protected void showDownMsg() {
			// 7012-2447 システムモーダル表示（実装はFXBAP_Updater#showDownMsgに合わせる）
			MCMessageList msgList = getMessages();
			panel.sortMessageList(msgList);
			MCMessage msg = msgUpdatedWithMessages();
			if (msg != null) {
				msgList.add(0, msg);
			}
			panel.messageNoSort(msgList, MCFrameType.SYSTEM_MODAL);
		}

		@Override
		protected void resultSuccess() {
			// 呼び出し元データ更新
			MCRow.copyvalue(_taskR, getPropDtlR());

			// 画面クローズ
			getRootPanel().statusClear();
			requestCloseWindow();
		}

	}


	/**
	 * 画面初期化時のコンテナのステータスを設定します。
	 *
	 */
	protected void initContainerStatus() {
		// 全ステータスクリア
		statusClear();

		// 呼び出し元で設定されているステータスをコピー
		// 呼び出し元のステータスはクリア
		getPropDtlR().setStatus(_taskR.getStatus());
		_taskR.setStatus(Status.NONE);
	}

	/**
	 * 削除ステータスのRowをListから削除します。
	 *
	 */
	protected void removeDeleteStatusRow() {
		// スケジュール
		getScheDtlL().removeAll(getScheDtlL().subList(Status.DELETE));
		// 通知先
		for (FSBAP_MiningTaskDtlDest p : _destPartsMap.values()) {
			MCList<DtlR> destL = p.getDtlL();
			destL.removeAll(destL.subList(Status.DELETE));
			p.DtlTable.sort();
		}
	}


	/**
	 * Panel[ScheCtrl]のボタン[add]の押下時の処理
	 */
	@Override
	public void doScheCtrl_add(MCEventInfo info) {
		ScheDtlR scheR = insertRow(ScheDtlTable);
		openScheEditor(scheR);
	}
	/**
	 * Panel[ScheCtrl]のボタン[cpy]の押下時の処理
	 */
	@Override
	public void doScheCtrl_cpy(MCEventInfo info) {
		ScheDtlR scheR = copyRow(ScheDtlTable);
		if (scheR == null) {
			// 未選択チェック
			throw new MCAppException(FXBAP0035);
		}
		scheR.sche_no(null);// コピーなのでスケジュール番号はリセット
		scheR.setStatus(Status.CREATE);// コピーのステータスはCREATE、新規はNONE
		openScheEditor(scheR);
	}
	/**
	 * Panel[ScheCtrl]のボタン[mod]の押下時の処理
	 */
	@Override
	public void doScheCtrl_mod(MCEventInfo info) {
		ScheDtlR scheR = ScheDtlTable.getSelectedMCRow();
		if (scheR == null) {
			// 未選択チェック
			throw new MCAppException(FXBAP0035);
		}
		openScheEditor(scheR);
	}
	/**
	 * Panel[ScheCtrl]のボタン[del]の押下時の処理
	 */
	@Override
	public void doScheCtrl_del(MCEventInfo info) {
		deleteRow(ScheDtlTable);
	}
	/**
	 * Panel[Ctrl]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doCtrl_upd(MCEventInfo info) {
		// 必須入力チェック（Row）
		MCMessageList m = checkReq(
					getPropDtlR(),
					(_push_use) ? getPushDtlR() : null
		);
		if (!m.isEmpty()) {
			message(m);
			return;
		}

		// 通知先重複チェック
		MCList<ParamDtlR> destL = MCList.create(ParamDtlR.class);// チェック済み通知先
		String task_id = getPropDtlR().task_id();
		for (FSBAP_MiningTaskDtlDest parts : _destPartsMap.values()) {
			MCList<ParamDtlR> chkL = parts.checkPushDest(task_id);
			if (chkL == null) {
				return;
			}
			destL.addAll(chkL);
		}

		// パラメータの必須入力チェックと値の確定
		commitConditionEditor(_condParts);

		MCList<ParamDtlR>  paramL = getParamDtlL();
		paramL.clear();

		// 各種パラメータ
		for (ConditionEditor editor : _condParts) {
			// UpdateCallerの修正箇所チェック対策（コピー時は常に修正）
			MCRootPanel rp = (MCRootPanel) editor;
			boolean change = (isCopyEntry()) ? true : rp.isChanged();
			// パラメータに追加
			for (MCValueSupply param : editor.getParam()) {
				String key = param.column();
				String val = param.saveParamValue();
				ParamDtlR paramR = paramL.add();
				paramR.task_id(getPropDtlR().task_id());
				paramR.key(key);
				paramR.value(val);
				if (change) {
					// UpdateCallerの修正箇所チェック対策
					paramR.setStatus(MCRow.MODIFY);
				}
			}
		}

		// 通知設定
		if (_push_use) {
			PushDtlR pushR = getPushDtlR();
			TaskR propR = getPropDtlR();
			ParamDtlR paramR;
			// UpdateCallerの修正箇所チェック対策（コピー時は常に修正）
			Status status = (isCopyEntry()) ? MCRow.MODIFY : pushR.getStatus();

			// メッセージID
			paramR = paramL.add();
			paramR.task_id(propR.task_id());
			paramR.key(MCMiningUtil.KEY_PUSH_MSGID);
			paramR.value(pushR.msg_id());
			paramR.setStatus(status);
			// メッセージ
			paramR = paramL.add();
			paramR.task_id(propR.task_id());
			paramR.key(MCMiningUtil.KEY_PUSH_MSGEDIT);
			paramR.value(pushR.msg());
			paramR.setStatus(status);
			// 通知方法
			paramR = paramL.add();
			paramR.task_id(propR.task_id());
			paramR.key(MCMiningUtil.KEY_PUSHTYPE);
			paramR.value(pushR.push_type());
			paramR.setStatus(status);
			// 重要
			paramR = paramL.add();
			paramR.task_id(propR.task_id());
			paramR.key(MCMiningUtil.KEY_PUSHIMP);
			paramR.value(Boolean.toString(pushR.push_imp()));
			paramR.setStatus(status);

			// 通知先
			paramL.addAll(destL);
		}

		if (isNewEntry()) {
			callFS_FSBAL0820_Ins01();
		}
		else {
			callFS_FSBAL0820_Upd01();
		}
	}


	@Override
	public void doPushDtl_msg_type_NC(MCEventInfo info){
		super.doPushDtl_msg_type_NC(info);

		// メッセージクリア
		getPushDtlR().msg_id(null);
		getPushDtlR().msg(null);
		// モード変更
		setStatus(getStatus());
	}

	@Override
	public void doPushDtl_msg_id_NC(MCEventInfo info){
		super.doPushDtl_msg_id_NC(info);

		String msgid = getPushDtlR().msg_id();
		String msg = (msgid == null) ? null : new MCMessage(msgid).toString();
		getPushDtlR().msg(msg);
	}

	/**
	 * 編集中のデータが新規またはコピーの場合 true を返します。
	 *
	 * @return 新規またはコピー以外の場合 false
	 */
	protected boolean isNewEntry() {
		return isNull(_taskR.task_id());
	}

	/**
	 * 編集中のデータがコピーの場合 true を返します。
	 *
	 * @return コピー以外の場合 false
	 */
	protected boolean isCopyEntry() {
		return _copy;
	}

	/**
	 * スケジュール編集画面を開きます。
	 *
	 * @param scheR 編集するスケジュール
	 */
	protected void openScheEditor(ScheDtlR scheR) {
		MCRootPanel p = createPanel("FS", "FSBAP0840", MCRootPanel.SCREEN_MODAL,
				"T1", null, _taskR, scheR, ScheDtlTable);
		showChildPanel(p, MCRootPanel.SCREEN_SINGLE);
	}

	@Override
	public MCList getPropDtl_user_id(MCRow row, MCEventInfo info) {
		row.setStringNE("co_cd", getPropDtlR().co_cd());
		row.setStringNE("search_type", FSC_SEARCH_TYPE.EXT_ATTR_EQ.value());
		return super.getPropDtl_user_id(row, info);
	}

	@Override
	public MCList getPropDtl_mining_nm(MCRow row, MCEventInfo info) {
		if (isNull(getPropDtlR().task_type())) {
			return null;
		}
		// 会社共通・システム共通を検索
		row.setStringNE("user_id", MCGroupResource.EXT_ATTR_USER_ID);
		row.setStringNE("co_cd", getPropDtlR().co_cd());
		MCList list = super.getPropDtl_mining_nm(row, info);
		MCRowMatcher<?> matcher = new MCRowMatcher<MCRow>() {
			boolean cache = FSC_MINING_TASK_TYPE.isTASK_GADGET_CACHE(
												getPropDtlR().task_type());
			@Override
			public boolean match(MCRow row) {
				// キャッシュフラグチェック
				if (cache && !row.getBoolean("gadget_cache_flg")) {
					return false;
				}

				String pub = row.getString("public_lv");
				if (isSame(MCGroupResource.EXT_ATTR_USER_ID, pub)
							|| isSame(MCGroupResource.SYSTEM_USER_ID, pub)) {
					return true;
				}
				return false;
			}
		};
		return list.subList(matcher);
	}


	@Override
	public void layoutInit() {
		super.layoutInit();

		// 検索条件タブ
		CondListPanel = addConditionEditorPanel(CondPanel);

		// 詳細設定タブ
		ParamListPanel = addConditionEditorPanel(ParamPanel);

		// 通知先タブ
		String[] ids = MCMiningUtil.getValidDestIDs();
		for (String id : ids) {
			addDestTab(id);
		}
	}

	/**
	 * 通知先タブを追加します。
	 *
	 * @param key 通知先種別
	 */
	protected void addDestTab(String key) {
		// 通知部品生成
		FSBAP_MiningTaskDtlDest dest_PPanel = FSBAP_MiningTaskDtlDest.create();
		dest_PPanel.setName(key + ".dest");
		// ステータス設定
		dest_PPanel.putStatus(ENABLE, FSBAP_MiningTaskDtlDest.ENABLE);
		dest_PPanel.putStatus(ENTRY, FSBAP_MiningTaskDtlDest.ENTRY);
		dest_PPanel.putStatus(READ_ONLY, FSBAP_MiningTaskDtlDest.READ_ONLY);

		// tabのpanel生成
		MCPanel destPanel = beansFactory.createPanel(key);
		destPanel.setValueCheck(true);
// これだとBorderLayooutが追加されない
//		destPanel.setLayoutPosition("C");
//		destPanel.add(dest_PPanel);
		destPanel.setLayout(new BorderLayout());
		destPanel.add(dest_PPanel, BorderLayout.CENTER);
		destPanel.setLastBeans(dest_PPanel);

		// tabに追加
		MCPanel before = (DestTabTab.getComponentCount() == 0)
							? null
							: (MCPanel) DestTabTab.getComponentAt(
											DestTabTab.getComponentCount() - 1);
		if (before != null) {
			// タブ移動順設定（末尾のタブに追加）
			before.setNextBeans(destPanel);
		}
		DestTabTab.add(destPanel, "DestTab." + key);
		if (before == null) {
			// タブ移動順設定（先頭のタブのみ）
			DestTabTab.setLastBeans(destPanel);
		}

		// キャッシュ
		_destPartsMap.put(key, dest_PPanel);

		// 部品設定
		dest_PPanel.initDestParts(key);
		int pos = DestTabTab.getTabCount() - 1;
		DestTabTab.setTitleAt(pos, dest_PPanel.getTabLabelText());
	}

	@Override
	public List<MCPanel> getMCPanels(){
		List<MCPanel> list = super.getMCPanels();
		// 通知先タブのパネルを追加
		for (Component comp : DestTabTab.getComponents()) {
			list.add((MCPanel) comp);
		}
		return list;
	}

	/**
	 * 検索条件タブを初期化します。
	 * 
	 * <p>
	 * エディタ部品を生成し検索条件パネルに配置します。
	 * 配置したエディタ部品はエディター部品のリスト(_condParts)に追加されます。
	 *
	 */
	protected void initCondPanel() {
		List<ConditionEditor> editorList = new ArrayList<>();
		for (CondDtlR condR : getCondDtlL()) {
			// パラメータ作成
			MCValueSupply param = createConditionParam(condR);

			// エディタ部品作成
			ConditionEditor editor = createConditionEditor(param.type());
			
			initConditionEditor(editor, null, param);

			editorList.add(editor);
		}

		// パネルに追加
		ConditionEditor[] editors = editorList.toArray(
									new ConditionEditor[editorList.size()]);
		addConditionEditor(CondListPanel, editors);
		// リストに追加
		_condParts.addAll(editorList);
	}

	/**
	 * 検索条件オブジェクトを生成します。
	 *
	 * @param defR 項目定義
	 * @param cond 初期検索条件
	 * @return 検索条件オブジェクト
	 */
	protected MCValueSupply createConditionParam(CondDtlR condR) {
		return createParam(
				MCMiningUtil.createTaskCondKey(condR.col_id()),
				condR.col_nm(), condR.data_typ(),
				condR.require_flg(), true);

	}

	/**
	 * 値設定用のパラメータオブジェクトを生成します。
	 *
	 * <p>
	 * サーバから設定を取得済みの場合は、値を設定します。
	 *
	 * <p>
	 * データ型は{@link MCDashboardUtil}の定数です。
	 *
	 * @param key キー
	 * @param name 表示
	 * @param type データ型
	 * @param required 入力必須の場合 true
	 * @param editable 編集可の場合 true
	 * @return 生成したパラメータ
	 */
	protected MCValueSupply createParam(String key, String name, String type,
											boolean required, boolean editable) {
		// 7012-1327 運用日付は画面から渡す
		MCValueSupply param = MCValueSupply.create(
										key, name, type, required, editable, getToday());
		if (param == null) {
			return null;
		}

		// 設定値の反映
		ParamDtlR paramR = getParamDtlL().getFirst(ParamDtlR.$key, key);
		if (paramR != null) {
			param.loadParamValue(paramR.value());
		}

		return param;
	}

	/**
	 * 詳細設定タブを初期化します。
	 * 
	 * <p>
	 * エディタ部品を作成し詳細設定パネルに配置します。
	 * 配置したエディタ部品はエディター部品のリスト(_condParts)に追加されます。
	 * 
	 */
	protected void initParamPanel() {
		List<ConditionEditor> editorList = new ArrayList<>();

		// タスク固有設定
		if (_pref_mod_id != null && _pref_scr_id != null) {
			Class<? extends TaskParamEditor> cl =
							MCConst.screen.getClass(
											_pref_mod_id, _pref_scr_id,
											TaskParamEditor.class);
			TaskParamEditor editor =
					(TaskParamEditor) MCFactory.invokeStatic(cl, "create", null, null);
			MCValueSupply[] params = editor.createParam();
			for (MCValueSupply param : params) {
				ParamDtlR paramR = getParamDtlL().getFirst(ParamDtlR.$key, param.column());
				if (paramR != null) {
					param.loadParamValue(paramR.value());
				}
			}
			MCList<ListR> comboL = editor.createComboList(params,
								getCondDtlL(), getMethodDtlL(), getParamDtlL());
			initConditionEditor(editor, comboL, params);

			editorList.add(editor);
		}

		// パネルに追加
		ConditionEditor[] editors = editorList.toArray(
									new ConditionEditor[editorList.size()]);
		addConditionEditor(ParamListPanel, editors);
		// リストに追加
		_condParts.addAll(editorList);
	}

	/**
	 * 通知タブを初期化します。
	 *
	 */
	protected void initPushPanel() {
		if (!_push_use) {
			// 通知タブ使用不可
			return;
		}

		ParamDtlR paramR;
		MCList<ParamDtlR> paramL = getParamDtlL();
		MCIndexKey idx = paramL.createIndex(ParamDtlR.$key);

		// メッセージID
		paramR = paramL.getFirst(idx, MCMiningUtil.KEY_PUSH_MSGID);
		if (paramR != null) {
			getPushDtlR().msg_id(paramR.value());
		}

		// メッセージ入力
		paramR = paramL.getFirst(idx, MCMiningUtil.KEY_PUSH_MSGEDIT);
		if (paramR != null) {
			getPushDtlR().msg(paramR.value());
		}

		// 通知方法
		paramR = paramL.getFirst(idx, MCMiningUtil.KEY_PUSHTYPE);
		if (paramR != null) {
			getPushDtlR().push_type(paramR.value());
			FSC_PUSH_TYPE.putName(getPushDtlR(),
							PushDtlR.$push_type, PushDtlR.$push_type_nm);
		}

		// 重要
		paramR = paramL.getFirst(idx, MCMiningUtil.KEY_PUSHIMP);
		if (paramR != null) {
			getPushDtlR().push_imp(Boolean.parseBoolean(paramR.value()));
		}

		// メッセージ設定種別
		getPushDtlR().msg_type(
						isNull(getPushDtlR().msg_id()) ? MSG_EDIT : MSG_ID);

		// 通知先
		for (FSBAP_MiningTaskDtlDest parts : _destPartsMap.values()) {
			parts.setDestList(getPropDtlR().co_cd(), paramL, idx);
		}
	}

	@Override
	protected void setSortColumn() {
		super.setSortColumn();

		// スケジュール
		ScheDtlTable.addSortColumn(columnScheDtl_time, MCList.SortType.ASC);
		ScheDtlTable.addSortColumn(columnScheDtl_desc, MCList.SortType.ASC);

		// 通知先部品
		for (FSBAP_MiningTaskDtlDest p : _destPartsMap.values()) {
			p.DtlTable.addSortColumn(p.columnDtl_id, MCList.SortType.ASC);
		}
	}


	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			if (args == null || args.length < 2) {
				// 引数不正
				throw new MCAppException(msgUnknownOpenParam());
			}

			_taskR = (TaskR) args[0];
			_taskTable = (MCTable) args[1];
			_co_cd = (String) args[2];
			_copy = (_taskR.getStatus() == Status.CREATE);// StatusがCREATEだとCOPY

			// メッセージ設定種別の値
			MSG_ID = PushDtl_msg_type_id.getActionCommand();
			MSG_EDIT = PushDtl_msg_type_edit.getActionCommand();
		}
		else {
			// タイプ不正
			throw new MCAppException(msgUnknownOpenParam());
		}
		valueInit();
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		// 呼び出し元画面の値を設定
		MCRow.copyvalue(getPropDtlR(), _taskR);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();

		// 通知先部品
		for (FSBAP_MiningTaskDtlDest p : _destPartsMap.values()) {
			p.DtlTable.fillSpace();
		}
	}

	@Override
	protected void screenOpenStatusClear() {
		super.screenOpenStatusClear();

		statusClear();
	}

	@Override
	public void afterOpenByInitParam() {
		if (isNewEntry()) {
			// 新規
			// 詳細検索後の手順と合わせる

			// コンテナステータス初期化
			initContainerStatus();

			// 画面モード
			setStatus(ENTRY);
		}
		else {
			// 基本情報以外の検索
			callFS_FSBAL0820_Srch11();
		}
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);

		// プッシュ通知利用
		TaskTabTab.setEnabledAt(
				TaskTabTab.indexOfComponent(PushPanel),
				_push_use);

		// メッセージ設定種別
		if (getPushDtlR().msg_type().equals(MSG_ID)) {
			PushDtl_msg_id.setMode(MCMode.REQUIRED);
			PushDtl_msg.setMode(MCMode.READ_ONLY);
		}
		if (getPushDtlR().msg_type().equals(MSG_EDIT)) {
			PushDtl_msg_id.setMode(MCMode.DISABLE);
			PushDtl_msg.setMode(MCMode.REQUIRED);
		}

		if (!isNull(_co_cd)) {
			// 会社固定検索
			setValueEx(PropDtl_co_cd, _co_cd);
			PropDtl_co_cd.setMode(MCMode.READ_ONLY);
		}
	}

	@Override
	public void setENTRYStatus() {
		super.setENTRYStatus();

		// 新規時は検索条件選択不可
		TaskTabTab.setEnabledAt(
				TaskTabTab.indexOfComponent(CondPanel),
				false);

		// 新規時は詳細設定選択不可
		TaskTabTab.setEnabledAt(
				TaskTabTab.indexOfComponent(ParamPanel),
				false);
	}

	@Override
	public void setENABLEStatus() {
		super.setENABLEStatus();

		// 編集時は検索条件選択可（検索条件がある場合のみ）
		TaskTabTab.setEnabledAt(
				TaskTabTab.indexOfComponent(CondPanel),
				!getCondDtlL().isEmpty());

		// 編集時は詳細設定選択可（詳細設定がある場合のみ）
		TaskTabTab.setEnabledAt(
				TaskTabTab.indexOfComponent(ParamPanel),
				(_pref_mod_id != null && _pref_scr_id != null));
	}

	@Override
	public boolean isChanged(MCTable<?> tbl) {
		// スケジュール
		// 全カラム READ_ONLEなので、デフォルトのチェックは使えない
		if (tbl == ScheDtlTable) {
			return (ScheDtlTable.getList().isStatusNone()) ? false : true;
		}

		// 通知先部品
		for (FSBAP_MiningTaskDtlDest p : _destPartsMap.values()) {
			if (tbl == p.DtlTable) {
				return (p.DtlTable.getList().isStatusNone()) ? false : true;
			}
		}

		return super.isChanged(tbl);
	}

	@Override
	public void panelClosed() {
		super.panelClosed();

		// 呼び出し元画面の選択行
		int index = _taskTable.getMCSelectedRow();

		// 新規作成・コピーでキャンセルの場合、Rowを破棄
		if (isNewEntry()) {
			_taskTable.getList().remove(_taskR);
			if (index > 0) {
				index--;
			}
		}

		// フォーカスの調整
		if (_taskTable.getRowCount() <= index) {
			index = _taskTable.getRowCount() - 1;
		}
		if (index < 0) {
			_taskTable.transferFocus();
		}
		else {
			_taskTable.selectLeftmostColumn(index);
		}

		_taskTable.sort();
	}

}