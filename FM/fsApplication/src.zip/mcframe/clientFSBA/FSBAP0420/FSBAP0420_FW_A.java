package mcframe.clientFSBA.FSBAP0420;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0420"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0420_FW_A extends mcframe.clientFSUC.FSUCP0100.FSUCP_ConditionSettingBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0420";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Tab]ブロック関連のField定義
	public MCPanel TabPanel = null;
	public MCTabbedPane TabTab = null;
	// [Tab]ブロックの項目のField定義
	// [Cond]ブロック関連のField定義
	public MCPanel CondPanel = null;
	// [Cond]ブロックの項目のField定義
	// [Attr]ブロック関連のField定義
	public MCPanel AttrPanel = null;
	// [Attr]ブロックの項目のField定義
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  適用する.<p>
	 *
	 */
	public MCButton Btn_apply = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(TabPanel);
		ret.add(CondPanel);
		ret.add(AttrPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0420_FW_A() {

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0420_FW_A(String name) {
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0420_FW.jbCreateTab((FSBAP0420)this);
		FSBAP0420_FW.jbCreateCond((FSBAP0420)this);
		FSBAP0420_FW.jbCreateAttr((FSBAP0420)this);
		FSBAP0420_FW.jbCreateBtn((FSBAP0420)this);
	}

	/**
	 * [Tab]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTab(FSBAP0420 p) {
	}

	/**
	 * [Cond]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCond(FSBAP0420 p) {
	}

	/**
	 * [Attr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateAttr(FSBAP0420 p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP0420 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0420 create(){
		FSBAP0420 p = new FSBAP0420();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0420 create(String name){
		FSBAP0420 p = new FSBAP0420(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0420_FW.jbfInitTab((FSBAP0420)this);
		FSBAP0420_FW.jbfInitCond((FSBAP0420)this);
		FSBAP0420_FW.jbfInitAttr((FSBAP0420)this);
		FSBAP0420_FW.jbfInitBtn((FSBAP0420)this);
		FSBAP0420_FW.jbInitTab((FSBAP0420)this);
		FSBAP0420_FW.jbInitCond((FSBAP0420)this);
		FSBAP0420_FW.jbInitAttr((FSBAP0420)this);
		FSBAP0420_FW.jbInitBtn((FSBAP0420)this);
	}

	/**
	 * [Tab]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTab(FSBAP0420 p) {
		// ブロック関連の初期化
		p.TabPanel = p.beansFactory.createPanel("Tab");
		p.TabTab = p.beansFactory.createTabbedPane("Tab.tab");
		// ブロックの項目の初期化
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCond(FSBAP0420 p) {
		// ブロック関連の初期化
		p.CondPanel = p.beansFactory.createPanel("Cond");
		// ブロックの項目の初期化
	}

	/**
	 * [Attr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitAttr(FSBAP0420 p) {
		// ブロック関連の初期化
		p.AttrPanel = p.beansFactory.createPanel("Attr");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP0420 p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_apply = p.beansFactory.createButton("Btn.apply", "upd");
	}

	/**
	 * [Tab]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTab(FSBAP0420 p) {
		// ブロック関連の初期化
		p.add(p.TabPanel);
		p.setLastBeans(p.TabPanel);
		p.TabPanel.setNextBeans(p.BtnPanel);
		p.TabPanel.add(p.TabTab);
		p.TabPanel.setLastBeans(p.TabTab);
		p.TabPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.TabTab.add(p.CondPanel, "Tab.cond");
		p.TabTab.setLastBeans(p.CondPanel);
		p.CondPanel.setNextBeans(p.AttrPanel);
		p.TabTab.add(p.AttrPanel, "Tab.attr");
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCond(FSBAP0420 p) {
		// ブロック関連の初期化
		p.CondPanel.setNextBeans(p.AttrPanel);
		p.CondPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Attr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitAttr(FSBAP0420 p) {
		// ブロック関連の初期化
		p.AttrPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP0420 p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setValueCheck(false);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_apply.setIcon("REGISTER");
		p.Btn_apply.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_apply);
		p.BtnPanel.setLastBeans(p.Btn_apply);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0420_FW.mcInitTab((FSBAP0420)this);
		FSBAP0420_FW.mcInitCond((FSBAP0420)this);
		FSBAP0420_FW.mcInitAttr((FSBAP0420)this);
		FSBAP0420_FW.mcInitBtn((FSBAP0420)this);

		// [INIT]ステータスのモードの設定
		FSBAP0420_FW.statusInitINIT_Tab((FSBAP0420)this);
		FSBAP0420_FW.statusInitINIT_Cond((FSBAP0420)this);
		FSBAP0420_FW.statusInitINIT_Attr((FSBAP0420)this);
		FSBAP0420_FW.statusInitINIT_Btn((FSBAP0420)this);

	}

	/**
	 *  [Tab]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTab(FSBAP0420 p) {
		p.TabTab.addAllListener(p);
	}

	/**
	 *  [Cond]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCond(FSBAP0420 p) {
	}

	/**
	 *  [Attr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitAttr(FSBAP0420 p) {
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP0420 p) {
		p.Btn_apply.addAllListener(p);
		p.Btn_apply.setAPMethodName("doBtn_apply");
	}

	/**
	 * [INIT]ステータスの[Tab]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Tab(FSBAP0420 p){

	}

	/**
	 * [INIT]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Cond(FSBAP0420 p){

	}

	/**
	 * [INIT]ステータスの[Attr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Attr(FSBAP0420 p){

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP0420 p){
		p.Btn_apply.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_apply) doBtn_apply(info);
	}

	/**
	 * [Btn]パネルの[apply]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_apply(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == TabTab) return doTab_VC(info);
		return true;
	}

	/**
	 * [Tab]Tabの選択Tabが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTab_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == TabTab) doTab_NC(info);
	}

	/**
	 * [Tab]Tabの選択Tabが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTab_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == TabTab) doTab_NE(info);
	}

	/**
	 * [Tab]TabのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTab_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == TabTab) doTab_NX(info);
	}

	/**
	 * [Tab]TabのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTab_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}