package mcframe.clientFSBA.FSBAP0420;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Map;

import mcframe.clientCore.beans.dashboard.MCDashboardUtil;
import mcframe.clientCore.beans.fxgraph.MCFXGraphData;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.dashboard.CndR;
import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.commonCore.param.MCParam;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.clientFXBA.FXBAP0150.ConditionEditor;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFSBA.FSBAP0430.FSBAP0430;
import mcframe.commonFS.constant.FSC_GADGET_CHART_TYPE;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0420"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0420_FW extends FSBAP0420_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 検索条件部品を配置するパネル
	 */
	protected MCPanel CondListPanel = null;

	/**
	 * 属性部品を配置するパネル
	 */
	protected MCPanel AttrListPanel = null;

	/**
	 * エディタ部品のリスト
	 */
	protected List<ConditionEditor> _condParts = new ArrayList<>();

	/**
	 * エディタ部品配置時のマージン
	 */
	protected int _margin = 5;

	/**
	 * 設定対象のガジェット
	 */
	protected MCGadget _gadget = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0420_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0420_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[apply]の押下時の処理
	 */
	@Override
	public void doBtn_apply(MCEventInfo info) {
		// 入力の確定
		commitConditionEditor(_condParts);

		// 設定を保存～反映（変更の有無問わず）
		_gadget.updateByParam();
		_gadget.saveResource(false);

		statusClear();
		requestCloseWindow();
	}


	@Override
	public void layoutInit() {
		super.layoutInit();

		// 検索条件
		CondListPanel = addConditionEditorPanel(CondPanel);
		// 属性
		AttrListPanel = addConditionEditorPanel(AttrPanel);
	}

	/**
	 * 画面表示パラメータに基づいて初期化を行います。
	 *
	 * <li>
	 * 起動タイプ：T1 ガジェット検索条件を表示します。<br>
	 * </li>
	 * <p>
	 * パラメータは共通です。
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td colspan=3>Rowは使用しない</td>
	 * </tr>
	 * </table><br>
	 * その他の引数：
	 * <table border = 1>
	 * <tr>
	 * <th>位置</th><th>値</th>
	 * </tr>
	 * <tr>
	 * <td>0</td><td>
	 * ガジェット
	 * </td></tr>
	 * </table>
	 *
	 * @param openTyp "T1"
	 * @param bind 未使用
	 * @param args 説明を参照
	 * @see mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase_FW#initByScreenParam(java.lang.String, mcframe.commonCore.container.MCRow, java.lang.Object[])
	 */
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if ("T1".equals(openTyp)) {
			if (args.length > 0) {
				_gadget = (MCGadget) args[0];

				// タブ生成
				initTabbedPane(_gadget);

				// 初期ステータス
				mcInitStatus();
			}
		}
	}

	/**
	 * タブを初期化します。
	 *
	 * @param gadget ガジェット
	 */
	protected void initTabbedPane(MCGadget gadget) {
		// 検索タブ 
		MCList<ListR> condL = getCondComboListData(gadget);
		Map<String, MCValueSupply> condMap = gadget.getConditionMap();
		initCondPanel(condMap, CondListPanel, condL);

		// 属性タブ
		MCList<ListR> attrL = getAttrComboListData(gadget);
		Map<String, MCValueSupply[]> attrMap = gadget.getAttributeMap();
		initAttrPanel(attrMap, AttrListPanel, attrL);

		// 検索条件がない場合
		if (condMap.size() <= 0) {
			int idx = TabTab.indexOfComponent(CondPanel);
			TabTab.setEnabledAt(idx, false);
			TabTab.setSelectedComponent(AttrPanel);
		}
	}

	/**
	 * 検索条件用のコンボリストのデータを取得します。
	 *
	 * @param gadget ガジェット
	 * @return コンボリストデータ
	 */
	protected MCList<ListR> getCondComboListData(MCGadget gadget) {
		// 検索条件コンボリストの検索
		MCList<CndR> cndL = MCList.create(CndR.class);
		Map<String, MCValueSupply> condMap = gadget.getConditionMap();
		for (MCValueSupply cond : condMap.values()) {
			MCDashboardUtil.addParamSrchRow(cndL, gadget, cond);
		}

		// 検索
		MCParam param = MCDashboardUtil.callListOperation(cndL);
		return MCDashboardUtil.getListList(param);
	}

	/**
	 * 属性用のコンボリストのデータを取得します。
	 *
	 * @param gadget ガジェット
	 * @return コンボリストデータ
	 */
	public MCList<ListR> getAttrComboListData(MCGadget gadget) {
		MCList<ListR> list = MCList.create(ListR.class);
		Map<String, MCValueSupply[]> attrMap = gadget.getAttributeMap();
		for (Map.Entry<String, MCValueSupply[]> entry : attrMap.entrySet()) {
			MCValueSupply[] attrs = entry.getValue();
			switch (entry.getKey()) {
			case MCDashboardUtil.KEY_CHART_TYPE:
				for (MCValueSupply attr : attrs) {
					for (FSC_GADGET_CHART_TYPE chart : FSC_GADGET_CHART_TYPE.array()) {
						MCDashboardUtil.addParamComboListRow(
								list, gadget, attr,
								chart.value().toSimpleString(),
								chart.name());
					}
				}
				break;
			case MCDashboardUtil.KEY_THRESHOLD:
				// グラフガジェットの積み上げ系グラフの場合、列指定不可
				boolean stack = false;
				String gadtype = gadget.getType();
				if (MCDashboardUtil.GADGET_CHART.equals(gadtype) ||
						MCDashboardUtil.GADGET_MINING.equals(gadtype)) {
					MCValueSupply[] types = attrMap.get(MCDashboardUtil.KEY_CHART_TYPE);
					for (MCValueSupply type : types) {
						int typeval = Integer.parseInt((String) type.value());
						if (typeval == MCFXGraphData.GraphType_StackedBar
								|| typeval == MCFXGraphData.GraphType_StackedArea) {
							stack = true;
						}
					}
					if (stack) {
						break;
					}
				}

				// 列数固定の場合、列指定可能
				String coltext = gadget.getDefaultProperty(
											MCDashboardUtil.KEY_LABEL_COLUMN);
				if (coltext != null) {
					String[] cols = coltext.split(",");
					for (int i = 0; i < cols.length; i++) {
						String colval = String.valueOf(i);
						String colnm = cols[i];
						MCDashboardUtil.addParamComboListRow(
								list, gadget, attrs[0], colval, colnm);
					}
				}
				break;
			}
		}
		return list;
	}

	/**
	 * エディタ部品を生成し検索条件パネルに配置します。
	 *
	 * 配置したエディタ部品はエディター部品のリスト(_condParts)に追加されます。
	 *
	 * @param map エディタ部品を配置する検索条件のMap
	 * @param parent エディタ部品を配置するパネル
	 * @param comboL コンボリスト用のデータ
	 */
	protected void initCondPanel(Map<String, MCValueSupply> map,
										MCPanel parent, MCList<ListR> comboL) {
		List<ConditionEditor> editorList = new ArrayList<>();
		for (MCValueSupply item : map.values()) {
			// エディタ部品作成
			ConditionEditor editor = createConditionEditor(item.type());
			initConditionEditor(editor, comboL, item);

			editorList.add(editor);
		}

		// パネルに追加
		ConditionEditor[] editors = editorList.toArray(
									new ConditionEditor[editorList.size()]);
		addConditionEditor(parent, editors);
		// リストに追加
		_condParts.addAll(editorList);
	}

	/**
	 * エディタ部品を生成し属性パネルに配置します。
	 *
	 * 配置したエディタ部品はエディター部品のリスト(_condParts)に追加されます。
	 *
	 * @param map エディタ部品を配置する属性のMap
	 * @param parent エディタ部品を配置するパネル
	 * @param comboL コンボリスト用のデータ
	 */
	protected void initAttrPanel(Map<String, MCValueSupply[]> map,
										MCPanel parent, MCList<ListR> comboL) {
		List<ConditionEditor> editorList = new ArrayList<>();
		ConditionEditor editor = null;
		for (Map.Entry<String, MCValueSupply[]> entry : map.entrySet()) {
			MCValueSupply[] attrs = entry.getValue();
			switch (entry.getKey()) {
			case MCDashboardUtil.KEY_THRESHOLD:
				// 専用エディタ部品作成
				editor = FSBAP0430.create();
				initConditionEditor(editor, comboL, attrs);

				editorList.add(editor);

				break;
			case MCDashboardUtil.KEY_TITLE:
				// エディタ部品作成
				editor = createConditionEditor(attrs[0].type());

				// ヘルプ文字列＝デフォルトタイトル
				// デフォルトタイトルの取得方法はMCGadgetと同じ
				MCValueSupply help = attrs[0].clone();
				String title = _gadget.getDefaultProperty(MCDashboardUtil.KEY_TITLE);
				if (title == null) {
					title = _gadget.getDefaultProperty(MCDashboardUtil.KEY_NAME);
				}
				help.value(title);
				attrs = MCCollectionUtil.concat(attrs, new MCValueSupply[] { help });

				initConditionEditor(editor, comboL, attrs);
				editorList.add(editor);
				break;
			case MCDashboardUtil.KEY_CHART_TYPE:
			default:
				for (MCValueSupply attr : attrs) {
					// エディタ部品作成
					editor = createConditionEditor(attr.type());
					initConditionEditor(editor, comboL, attr);

					editorList.add(editor);
				}
				break;
			}
		}

		// パネルに追加
		ConditionEditor[] editors = editorList.toArray(
									new ConditionEditor[editorList.size()]);
		addConditionEditor(parent, editors);
		// リストに追加
		_condParts.addAll(editorList);
	}

	@Override
	public void panelClosed() {
		super.panelClosed();

		if (!_gadget.isSaved()) {
			// 新規で設定画面で保存しなかった場合はガジェットを削除する
			MCDashboard.Board board = _gadget.getBoard();
			board.removeGadget(_gadget);
			board.updateGrid();
		}
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}
	
	@Override
	public void setOpenFocus() {
		super.setOpenFocus();
		
		TabTab.focusActiveFirstComponent();
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	/**
	 *  フォント比率が変更された直後に呼ばれるメソッド
	 * @param before フォント比率前
	 * @param after フォント比率後
	 */
	// パネルの高さ調整などをここに実装可能
	@Override
	public void afterFontLayoutChange(int before, int after) {
		MCPanel list[] = {
			CondListPanel, AttrListPanel
		};

		//CondListPanel, AttrListPanel の高さを調整する。
		for(MCPanel p1 : list) {
			p1.validate();
			int h = 0;
			// フォント比率変更後の全ての部品が収まる高さを算出
			for (Component c : p1.getComponents()) {
				h = Math.max(h, c.getY() + c.getSize().height);
			}

			p1.setSize(p1.getSize().width, h);
			p1.setPreferredSize(new Dimension(p1.getSize().width, h));
		}
	}
}