package mcframe.clientFSBA.FSBAP0390;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0390"パネルクラスです。<p>
 *
 * 非表示対象カの検索を行います。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0390_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0390";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Rslt]ブロック関連のField定義
	public MCPanel RsltPanel = null;
	public MCScrollPane RsltScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0390.RsltR> RsltTable = null;
	// [Rslt]ブロックの項目のField定義
	/**
	 *  非表示（現在値）.<p>
	 *
	 */
	public MCColumnConfig columnRslt_visible_flg = null;
	/**
	 *  ユーザ非表示.<p>
	 *
	 */
	public MCColumnConfig columnRslt_hide_flg = null;
	/**
	 *  カラムキー.<p>
	 *
	 */
	public MCColumnConfig columnRslt_column_key = null;
	/**
	 *  カラム名.<p>
	 *
	 */
	public MCColumnConfig columnRslt_column_nm = null;
	/**
	 *  非表示にする.<p>
	 *
	 */
	public MCColumnConfig columnRslt_select = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  最新情報を取得.<p>
	 *
	 */
	public MCButton Btn_search = null;
	/**
	 *  全選択.<p>
	 *
	 */
	public MCButton Btn_select_all = null;
	/**
	 *  全解除.<p>
	 *
	 */
	public MCButton Btn_deselect_all = null;
	/**
	 *  決定する.<p>
	 *
	 */
	public MCButton Btn_accept = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Rslt]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0390.RsltR> aRsltL;

	/**
	 * コピーによってaRsltLを設定します。
	 *
	 * aRsltLのインスタンスは変更されません。
	 *
	 * @param dataset RsltL
	 */
	public void setRsltL(MCList<mcframe.clientFSBA.FSBAP0390.RsltR> aList) {
		if (getRsltL() != aList) {
			getRsltL().setAll(aList);
		}
	}

	/**
	 * [Rslt]ブロックのコンテナaRsltLを返します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0390.RsltR> getRsltL() {
		return aRsltL;
	}

	/**
	 * aRsltRを作成します。
	 *
	 * @return RsltR
	 */
	public mcframe.clientFSBA.FSBAP0390.RsltR createRsltR() {
		return mcframe.clientFSBA.FSBAP0390.RsltR.create();
	}

	/**
	 * aRsltLを作成します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0390.RsltR> createRsltL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0390.RsltR.class);
	}

	/**
	 * RsltTableを初期化します。
	 */
	protected void createRsltTable(){
		if(RsltTable == null){
			RsltTable = beansFactory.createTable2("Rslt.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getRsltL())) ret.add(getRsltL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getRsltL()) return "Rslt";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Rslt")) return getRsltL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(RsltPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0390_FW_A() {
		aRsltL = createRsltL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0390_FW_A(String name) {
		aRsltL = createRsltL();
		createRsltTable();
		RsltTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0390_FW.jbCreateRslt((FSBAP0390)this);
		FSBAP0390_FW.jbCreateBtn((FSBAP0390)this);
	}

	/**
	 * [Rslt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateRslt(FSBAP0390 p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP0390 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0390 create(){
		FSBAP0390 p = new FSBAP0390();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0390 create(String name){
		FSBAP0390 p = new FSBAP0390(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0390_FW.jbfInitRslt((FSBAP0390)this);
		FSBAP0390_FW.jbfInitBtn((FSBAP0390)this);
		FSBAP0390_FW.jbInitRslt((FSBAP0390)this);
		FSBAP0390_FW.jbInitBtn((FSBAP0390)this);
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitRslt(FSBAP0390 p) {
		// ブロック関連の初期化
		p.RsltPanel = p.beansFactory.createPanel("Rslt");
		p.RsltScrollPane = p.beansFactory.createScrollPane("Rslt.scroll");
		p.createRsltTable();
		// ブロックの項目の初期化
		p.columnRslt_visible_flg = p.beansFactory.createTableColumn("Rslt.visible_flg", MCColumnType.CHECK);
		p.columnRslt_hide_flg = p.beansFactory.createTableColumn("Rslt.hide_flg", MCColumnType.CHECK);
		p.columnRslt_column_key = p.beansFactory.createTableColumn("Rslt.column_key", MCColumnType.TEXT);
		p.columnRslt_column_nm = p.beansFactory.createTableColumn("Rslt.column_nm", MCColumnType.TEXT);
		p.columnRslt_select = p.beansFactory.createTableColumn("Rslt.select", MCColumnType.CHECK);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP0390 p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_search = p.beansFactory.createButton("Btn.search", "no_border");
		p.Btn_select_all = p.beansFactory.createButton("Btn.select_all", "no_border");
		p.Btn_deselect_all = p.beansFactory.createButton("Btn.deselect_all", "no_border");
		p.Btn_accept = p.beansFactory.createButton("Btn.accept", "upd");
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitRslt(FSBAP0390 p) {
		// ブロック関連の初期化
		p.add(p.RsltPanel);
		p.setLastBeans(p.RsltPanel);
		p.RsltPanel.setNextBeans(p.BtnPanel);
		p.RsltPanel.add(p.RsltScrollPane);
		p.RsltPanel.setLastBeans(p.RsltTable);
		p.RsltScrollPane.setViewportView(p.RsltTable);
		p.RsltTable.setList(p.getRsltL());
		p.RsltTable.setStatusColumnVisible(false);
		p.RsltPanel.setValueCheck(false);
		p.RsltPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP0390 p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_search.setIcon("RELOAD");
		p.Btn_search.setFunctionKey(MCFunctionKey.F1);
		p.BtnPanel.add(p.Btn_search);
		p.BtnPanel.setLastBeans(p.Btn_search);
		p.Btn_search.setNextBeans(p.Btn_select_all);
		p.Btn_select_all.setIcon("SELECT_ALL");
		p.Btn_select_all.setFunctionKey(MCFunctionKey.F13);
		p.BtnPanel.add(p.Btn_select_all);
		p.Btn_select_all.setNextBeans(p.Btn_deselect_all);
		p.Btn_deselect_all.setIcon("DESELECT_ALL");
		p.Btn_deselect_all.setFunctionKey(MCFunctionKey.F14);
		p.BtnPanel.add(p.Btn_deselect_all);
		p.Btn_deselect_all.setNextBeans(p.Btn_accept);
		p.Btn_accept.setIcon("REGISTER");
		p.Btn_accept.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_accept);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0390_FW.mcInitRslt((FSBAP0390)this);
		FSBAP0390_FW.mcInitBtn((FSBAP0390)this);

		// [INIT]ステータスのモードの設定
		FSBAP0390_FW.statusInitINIT_Rslt((FSBAP0390)this);
		FSBAP0390_FW.statusInitINIT_Btn((FSBAP0390)this);

	}

	/**
	 *  [Rslt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitRslt(FSBAP0390 p) {
		p.RsltTable.addAllListener(p);
		p.columnRslt_visible_flg.addAllListener(p);
		p.columnRslt_hide_flg.addAllListener(p);
		p.columnRslt_column_key.addAllListener(p);
		p.columnRslt_column_key.setListListener(p);
		p.columnRslt_column_nm.addAllListener(p);
		p.columnRslt_column_nm.setListListener(p);
		p.columnRslt_select.addAllListener(p);
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP0390 p) {
		p.Btn_search.addAllListener(p);
		p.Btn_search.setAPMethodName("doBtn_search");
		p.Btn_select_all.addAllListener(p);
		p.Btn_select_all.setAPMethodName("doBtn_select_all");
		p.Btn_deselect_all.addAllListener(p);
		p.Btn_deselect_all.setAPMethodName("doBtn_deselect_all");
		p.Btn_accept.addAllListener(p);
		p.Btn_accept.setAPMethodName("doBtn_accept");
	}

	/**
	 * [INIT]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Rslt(FSBAP0390 p){
		p.columnRslt_visible_flg.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnRslt_hide_flg.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnRslt_column_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnRslt_column_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnRslt_select.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP0390 p){
		p.Btn_search.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_select_all.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_deselect_all.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_accept.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0390_FW.setTableConfigRslt((FSBAP0390)this);
	}

	/**
	 * [Rslt]ブロックのTableの設定
	 */
	protected static void setTableConfigRslt(FSBAP0390 p) {
		p.columnRslt_visible_flg.setMeta(mcframe.clientFSBA.FSBAP0390.RsltR.visible_flg_META);
		p.RsltTable.addColumnConfig(p.columnRslt_visible_flg);
		p.columnRslt_hide_flg.setMeta(mcframe.clientFSBA.FSBAP0390.RsltR.hide_flg_META);
		p.RsltTable.addColumnConfig(p.columnRslt_hide_flg);
		p.columnRslt_column_key.setMeta(mcframe.clientFSBA.FSBAP0390.RsltR.column_key_META);
		p.RsltTable.addColumnConfig(p.columnRslt_column_key);
		p.columnRslt_column_nm.setMeta(mcframe.clientFSBA.FSBAP0390.RsltR.column_nm_META);
		p.RsltTable.addColumnConfig(p.columnRslt_column_nm);
		p.columnRslt_select.setMeta(mcframe.clientFSBA.FSBAP0390.RsltR.select_META);
		p.RsltTable.addColumnConfig(p.columnRslt_select);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_search) doBtn_search(info);
		else if (ap == Btn_select_all) doBtn_select_all(info);
		else if (ap == Btn_deselect_all) doBtn_deselect_all(info);
		else if (ap == Btn_accept) doBtn_accept(info);
	}

	/**
	 * [Btn]パネルの[search]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_search(MCEventInfo info);

	/**
	 * [Btn]パネルの[select_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_select_all(MCEventInfo info);

	/**
	 * [Btn]パネルの[deselect_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_deselect_all(MCEventInfo info);

	/**
	 * [Btn]パネルの[accept]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_accept(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == RsltTable) return doRslt_VC(info);
		if (vc == columnRslt_visible_flg) return doRslt_visible_flg_VC(info);
		if (vc == columnRslt_hide_flg) return doRslt_hide_flg_VC(info);
		if (vc == columnRslt_column_key) return doRslt_column_key_VC(info);
		if (vc == columnRslt_column_nm) return doRslt_column_nm_VC(info);
		if (vc == columnRslt_select) return doRslt_select_VC(info);
		return true;
	}

	/**
	 * [Rslt]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[visible_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_visible_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[hide_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_hide_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[column_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_column_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[column_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_column_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[select]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_select_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == RsltTable) doRslt_NC(info);
		else if (nc == columnRslt_visible_flg) doRslt_visible_flg_NC(info);
		else if (nc == columnRslt_hide_flg) doRslt_hide_flg_NC(info);
		else if (nc == columnRslt_column_key) doRslt_column_key_NC(info);
		else if (nc == columnRslt_column_nm) doRslt_column_nm_NC(info);
		else if (nc == columnRslt_select) doRslt_select_NC(info);
	}

	/**
	 * [Rslt]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[visible_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_visible_flg_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[hide_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_hide_flg_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_key_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_nm_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[select]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_select_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == RsltTable) doRslt_NE(info);
		else if (ne == columnRslt_visible_flg) doRslt_visible_flg_NE(info);
		else if (ne == columnRslt_hide_flg) doRslt_hide_flg_NE(info);
		else if (ne == columnRslt_column_key) doRslt_column_key_NE(info);
		else if (ne == columnRslt_column_nm) doRslt_column_nm_NE(info);
		else if (ne == columnRslt_select) doRslt_select_NE(info);
	}

	/**
	 * [Rslt]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[visible_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_visible_flg_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[hide_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_hide_flg_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_key_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_nm_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[select]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_select_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == RsltTable) doRslt_NX(info);
		else if (nx == columnRslt_visible_flg) doRslt_visible_flg_NX(info);
		else if (nx == columnRslt_hide_flg) doRslt_hide_flg_NX(info);
		else if (nx == columnRslt_column_key) doRslt_column_key_NX(info);
		else if (nx == columnRslt_column_nm) doRslt_column_nm_NX(info);
		else if (nx == columnRslt_select) doRslt_select_NX(info);
	}

	/**
	 * [Rslt]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[visible_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_visible_flg_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[hide_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_hide_flg_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_key_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_nm_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[select]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_select_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnRslt_column_key) doRslt_column_key_LC(info);
		else if (lc == columnRslt_column_nm) doRslt_column_nm_LC(info);
	}

	/**
	 * [Rslt]パネルの[column_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_key_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[column_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_column_nm_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}