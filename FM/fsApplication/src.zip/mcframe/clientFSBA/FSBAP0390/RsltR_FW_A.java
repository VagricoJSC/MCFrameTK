package mcframe.clientFSBA.FSBAP0390;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Rslt"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class RsltR_FW_A extends MCConstRow {

	/**
	 *  非表示（現在値）.<p>
	 *
	 */
	public static final String $visible_flg = "visible_flg";
	/**
	 *  ユーザ非表示.<p>
	 *
	 */
	public static final String $hide_flg = "hide_flg";
	/**
	 *  カラムキー.<p>
	 *
	 */
	public static final String $column_key = "column_key";
	/**
	 *  カラム名.<p>
	 *
	 */
	public static final String $column_nm = "column_nm";
	/**
	 *  非表示にする.<p>
	 *
	 */
	public static final String $select = "select";


	public static final MCMeta visible_flg_META = createCommonMeta($visible_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta hide_flg_META = createCommonMeta($hide_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta column_key_META = createStringMeta($column_key);
	public static final MCMeta column_nm_META = createStringMeta($column_nm);
	public static final MCMeta select_META = createCommonMeta($select, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<RsltR> constMetas = new ConstMetaList<RsltR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			visible_flg_META,
			hide_flg_META,
			column_key_META,
			column_nm_META,
			select_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected RsltR_FW_A(ConstMetaList<? extends RsltR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR clone() {
		return (RsltR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR createInstance() {
		return (RsltR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR getValues(String... names) {
		return (RsltR) super.getValues(names);
	}



	/**
	 *  非表示（現在値）.<p>
	 *
	 */
	public boolean visible_flg() {
		return getConstBoolean(offset + 0, $visible_flg);
	}

	/**
	 *  非表示（現在値）.<p>
	 *
	 */
	public void visible_flg(boolean value) {
		setConstBoolean(offset + 0, $visible_flg, value);
	}


	/**
	 *  ユーザ非表示.<p>
	 *
	 */
	public boolean hide_flg() {
		return getConstBoolean(offset + 1, $hide_flg);
	}

	/**
	 *  ユーザ非表示.<p>
	 *
	 */
	public void hide_flg(boolean value) {
		setConstBoolean(offset + 1, $hide_flg, value);
	}


	/**
	 *  カラムキー.<p>
	 *
	 */
	public String column_key() {
		return getConstString(offset + 2, $column_key);
	}

	/**
	 *  カラムキー.<p>
	 *
	 */
	public void column_key(String value) {
		setConstString(offset + 2, $column_key, value);
	}


	/**
	 *  カラム名.<p>
	 *
	 */
	public String column_nm() {
		return getConstString(offset + 3, $column_nm);
	}

	/**
	 *  カラム名.<p>
	 *
	 */
	public void column_nm(String value) {
		setConstString(offset + 3, $column_nm, value);
	}


	/**
	 *  非表示にする.<p>
	 *
	 */
	public boolean select() {
		return getConstBoolean(offset + 4, $select);
	}

	/**
	 *  非表示にする.<p>
	 *
	 */
	public void select(boolean value) {
		setConstBoolean(offset + 4, $select, value);
	}


	public String getString(String name) {
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			return visible_flg();
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			return hide_flg();
		}
		if ($select.equalsIgnoreCase(name)) {
			return select();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			return visible_flg();
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			return hide_flg();
		}
		if ($select.equalsIgnoreCase(name)) {
			return select();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			visible_flg(value);
			return;
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			hide_flg(value);
			return;
		}
		if ($select.equalsIgnoreCase(name)) {
			select(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($visible_flg.equalsIgnoreCase(name)) {
			visible_flg(value);
			return;
		}
		if ($hide_flg.equalsIgnoreCase(name)) {
			hide_flg(value);
			return;
		}
		if ($select.equalsIgnoreCase(name)) {
			select(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

