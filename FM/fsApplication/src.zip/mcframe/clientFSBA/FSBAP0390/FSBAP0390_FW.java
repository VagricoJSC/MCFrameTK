package mcframe.clientFSBA.FSBAP0390;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.util.HashMap;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0390"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0390_FW extends FSBAP0390_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 対象のテーブルです。
	 */
	protected MCTable<?> _target_table = null;

	/**
	 * 対象のカラムです。
	 */
	protected MCTableColumn _target_column = null;

	/**
	 * 対象のテーブルカラムの配列です。
	 */
	protected MCColumnConfig[] _target_column_configs = null;

	/**
	 * RsltRとMCColumnConfigの対応マップ
	 */
	protected HashMap<String, MCColumnConfig> _map = new HashMap<>();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0390_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0390_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[search]の押下時の処理
	 */
	@Override
	public void doBtn_search(MCEventInfo info) {
		setInitData();
	}
	/**
	 * Panel[Btn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doBtn_select_all(MCEventInfo info) {
		for (RsltR r : RsltTable.getViewRows()) {
			RsltTable.setValue(true, r.getGUIIndex(), columnRslt_select);
		}
	}
	/**
	 * Panel[Btn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doBtn_deselect_all(MCEventInfo info) {
		for (RsltR r : RsltTable.getViewRows()) {
			RsltTable.setValue(false, r.getGUIIndex(), columnRslt_select);
		}
	}
	/**
	 * Panel[Btn]のボタン[accept]の押下時の処理
	 */
	@Override
	public void doBtn_accept(MCEventInfo info) {
		MCList<RsltR> cl = getRsltL();
		for (RsltR r : cl) {
			MCColumnConfig c = _map.get(r.column_key());

			// setVisibleFromUserでカラムを非表示
			if (r.select()) {
				if (c.isVisibleFromUser() == true) {
					c.setVisibleFromUser(false);
				}
			} else {
				if (c.isVisibleFromUser() == false) {
					c.setVisibleFromUser(true);
				}
			}
		}

		requestCloseWindow();
	}

	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			boolean open = false;
			if (args.length >= 1) {
				Object o1 = args[0];
				if (o1 != null && o1 instanceof MCTable<?>) {
					MCTable<?> t = (MCTable<?>) o1;
					_target_table = t;
					open = true;
				}
			}
			if (args.length >= 2) {
				Object o2 = args[1];
				if (o2 != null && o2 instanceof MCTableColumn) {
					_target_column = (MCTableColumn) o2;
				}
			}
			if (open) {
				valueInit();
			}
		} else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	public void valueInit() {
		super.valueInit();
		setInitData();
	}

	/**
	 * 一覧データ設定
	 */
	protected void setInitData() {
		RsltTable.clear();
		_map.clear();
		_target_column_configs = null;

		MCTable<?> t = _target_table;

		MCRootPanel rp = t.getRootPanel();
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(rp);

		MCList<RsltR> cl = createRsltL();

		int n = 0;
		int findRow = -1;
		for (MCColumnConfig c : getTargetColumnConfigs()) {
			if (c == _target_column) {
				findRow = n;
			}

			RsltR r = createRsltR(c);

			_map.put(r.column_key(), c);

			boolean b = false;
			for (RsltR r1 : cl) {
				if (r1.column_key().equals(r.column_key())) {
					b = true;
					break;
				}
			}
			if (b == false) {
				// システム非表示チェック 7.0.1
				if (util.isVisibleColumn(t, c)) {
					cl.add(r);
				}
			}
			n++;
		}

		setRsltL(cl);
		RsltTable.adjustWidth();

		// 初期の行選択
		if (findRow >= 0) {
			RsltTable.selectRow(findRow);
		}
	}

	/**
	 *  カラム情報から一覧のrowに変換
	 * @param column MCColumnConfig
	 * @return RsltR
	 */
	protected RsltR createRsltR(MCColumnConfig column) {
		RsltR o = getRsltL().createRow();

		o.column_key(column.getBaseTableColumnName());
		o.column_nm(column.getMessageByLocale());

		if (column.getModeInfo().getStatus() != MCMode.INVISIBLE_STATUS) {
			o.visible_flg(false);
		} else {
			o.visible_flg(true);
		}

		if (column.isVisibleFromUser() == false) {
			o.hide_flg(true);
			o.select(true);
		} else {
			o.hide_flg(false);
			o.select(false);
		}

		return o;
	}

	/**
	 * 対象のテーブルカラムを配列にして返します。
	 *
	 * @return MCColumnConfigの配列
	 */
	protected MCColumnConfig[] getTargetColumnConfigs() {
		if (_target_column_configs != null) {
			return _target_column_configs;
		}
		_target_column_configs = _target_table.getPersonalizedTargetColumnConfigs(COLUMN_WIDTH_PANEL);

		// システム非表示
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(_target_table.getRootPanel());

		List<MCColumnConfig> list = new ArrayList<MCColumnConfig>();
		for (MCColumnConfig c : _target_column_configs) {
			// システム非表示チェック
			if (util.isVisibleColumn(_target_table, c)) {
				list.add(c);
			}
		}

		MCColumnConfig[] array = (MCColumnConfig[]) list.toArray(new MCColumnConfig[0]);
		_target_column_configs = array;

		return _target_column_configs;
	}

}