package mcframe.clientFSBA.FSBAP0840;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Week"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class WeekR_FW_A extends MCConstRow {

	/**
	 *  第1.<p>
	 *
	 */
	public static final String $week01 = "week01";
	/**
	 *  第2.<p>
	 *
	 */
	public static final String $week02 = "week02";
	/**
	 *  第3.<p>
	 *
	 */
	public static final String $week03 = "week03";
	/**
	 *  第4.<p>
	 *
	 */
	public static final String $week04 = "week04";
	/**
	 *  最終.<p>
	 *
	 */
	public static final String $lastweek = "lastweek";


	public static final MCMeta week01_META = createCommonMeta($week01, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta week02_META = createCommonMeta($week02, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta week03_META = createCommonMeta($week03, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta week04_META = createCommonMeta($week04, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta lastweek_META = createCommonMeta($lastweek, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<WeekR> constMetas = new ConstMetaList<WeekR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			week01_META,
			week02_META,
			week03_META,
			week04_META,
			lastweek_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected WeekR_FW_A(ConstMetaList<? extends WeekR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public WeekR clone() {
		return (WeekR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public WeekR createInstance() {
		return (WeekR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public WeekR getValues(String... names) {
		return (WeekR) super.getValues(names);
	}



	/**
	 *  第1.<p>
	 *
	 */
	public boolean week01() {
		return getConstBoolean(offset + 0, $week01);
	}

	/**
	 *  第1.<p>
	 *
	 */
	public void week01(boolean value) {
		setConstBoolean(offset + 0, $week01, value);
	}


	/**
	 *  第2.<p>
	 *
	 */
	public boolean week02() {
		return getConstBoolean(offset + 1, $week02);
	}

	/**
	 *  第2.<p>
	 *
	 */
	public void week02(boolean value) {
		setConstBoolean(offset + 1, $week02, value);
	}


	/**
	 *  第3.<p>
	 *
	 */
	public boolean week03() {
		return getConstBoolean(offset + 2, $week03);
	}

	/**
	 *  第3.<p>
	 *
	 */
	public void week03(boolean value) {
		setConstBoolean(offset + 2, $week03, value);
	}


	/**
	 *  第4.<p>
	 *
	 */
	public boolean week04() {
		return getConstBoolean(offset + 3, $week04);
	}

	/**
	 *  第4.<p>
	 *
	 */
	public void week04(boolean value) {
		setConstBoolean(offset + 3, $week04, value);
	}


	/**
	 *  最終.<p>
	 *
	 */
	public boolean lastweek() {
		return getConstBoolean(offset + 4, $lastweek);
	}

	/**
	 *  最終.<p>
	 *
	 */
	public void lastweek(boolean value) {
		setConstBoolean(offset + 4, $lastweek, value);
	}


	public boolean getBoolean(String name) {
		if ($week01.equalsIgnoreCase(name)) {
			return week01();
		}
		if ($week02.equalsIgnoreCase(name)) {
			return week02();
		}
		if ($week03.equalsIgnoreCase(name)) {
			return week03();
		}
		if ($week04.equalsIgnoreCase(name)) {
			return week04();
		}
		if ($lastweek.equalsIgnoreCase(name)) {
			return lastweek();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($week01.equalsIgnoreCase(name)) {
			return week01();
		}
		if ($week02.equalsIgnoreCase(name)) {
			return week02();
		}
		if ($week03.equalsIgnoreCase(name)) {
			return week03();
		}
		if ($week04.equalsIgnoreCase(name)) {
			return week04();
		}
		if ($lastweek.equalsIgnoreCase(name)) {
			return lastweek();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($week01.equalsIgnoreCase(name)) {
			week01(value);
			return;
		}
		if ($week02.equalsIgnoreCase(name)) {
			week02(value);
			return;
		}
		if ($week03.equalsIgnoreCase(name)) {
			week03(value);
			return;
		}
		if ($week04.equalsIgnoreCase(name)) {
			week04(value);
			return;
		}
		if ($lastweek.equalsIgnoreCase(name)) {
			lastweek(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($week01.equalsIgnoreCase(name)) {
			week01(value);
			return;
		}
		if ($week02.equalsIgnoreCase(name)) {
			week02(value);
			return;
		}
		if ($week03.equalsIgnoreCase(name)) {
			week03(value);
			return;
		}
		if ($week04.equalsIgnoreCase(name)) {
			week04(value);
			return;
		}
		if ($lastweek.equalsIgnoreCase(name)) {
			lastweek(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

