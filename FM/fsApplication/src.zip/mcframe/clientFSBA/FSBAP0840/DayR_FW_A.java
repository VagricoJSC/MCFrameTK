package mcframe.clientFSBA.FSBAP0840;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Day"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class DayR_FW_A extends MCConstRow {

	/**
	 *  1.<p>
	 *
	 */
	public static final String $day01 = "day01";
	/**
	 *  2.<p>
	 *
	 */
	public static final String $day02 = "day02";
	/**
	 *  3.<p>
	 *
	 */
	public static final String $day03 = "day03";
	/**
	 *  4.<p>
	 *
	 */
	public static final String $day04 = "day04";
	/**
	 *  5.<p>
	 *
	 */
	public static final String $day05 = "day05";
	/**
	 *  6.<p>
	 *
	 */
	public static final String $day06 = "day06";
	/**
	 *  7.<p>
	 *
	 */
	public static final String $day07 = "day07";
	/**
	 *  8.<p>
	 *
	 */
	public static final String $day08 = "day08";
	/**
	 *  9.<p>
	 *
	 */
	public static final String $day09 = "day09";
	/**
	 *  10.<p>
	 *
	 */
	public static final String $day10 = "day10";
	/**
	 *  11.<p>
	 *
	 */
	public static final String $day11 = "day11";
	/**
	 *  12.<p>
	 *
	 */
	public static final String $day12 = "day12";
	/**
	 *  13.<p>
	 *
	 */
	public static final String $day13 = "day13";
	/**
	 *  14.<p>
	 *
	 */
	public static final String $day14 = "day14";
	/**
	 *  15.<p>
	 *
	 */
	public static final String $day15 = "day15";
	/**
	 *  16.<p>
	 *
	 */
	public static final String $day16 = "day16";
	/**
	 *  17.<p>
	 *
	 */
	public static final String $day17 = "day17";
	/**
	 *  18.<p>
	 *
	 */
	public static final String $day18 = "day18";
	/**
	 *  19.<p>
	 *
	 */
	public static final String $day19 = "day19";
	/**
	 *  20.<p>
	 *
	 */
	public static final String $day20 = "day20";
	/**
	 *  21.<p>
	 *
	 */
	public static final String $day21 = "day21";
	/**
	 *  22.<p>
	 *
	 */
	public static final String $day22 = "day22";
	/**
	 *  23.<p>
	 *
	 */
	public static final String $day23 = "day23";
	/**
	 *  24.<p>
	 *
	 */
	public static final String $day24 = "day24";
	/**
	 *  25.<p>
	 *
	 */
	public static final String $day25 = "day25";
	/**
	 *  26.<p>
	 *
	 */
	public static final String $day26 = "day26";
	/**
	 *  27.<p>
	 *
	 */
	public static final String $day27 = "day27";
	/**
	 *  28.<p>
	 *
	 */
	public static final String $day28 = "day28";
	/**
	 *  29.<p>
	 *
	 */
	public static final String $day29 = "day29";
	/**
	 *  30.<p>
	 *
	 */
	public static final String $day30 = "day30";
	/**
	 *  31.<p>
	 *
	 */
	public static final String $day31 = "day31";
	/**
	 *  最終日.<p>
	 *
	 */
	public static final String $lastday = "lastday";


	public static final MCMeta day01_META = createCommonMeta($day01, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day02_META = createCommonMeta($day02, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day03_META = createCommonMeta($day03, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day04_META = createCommonMeta($day04, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day05_META = createCommonMeta($day05, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day06_META = createCommonMeta($day06, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day07_META = createCommonMeta($day07, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day08_META = createCommonMeta($day08, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day09_META = createCommonMeta($day09, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day10_META = createCommonMeta($day10, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day11_META = createCommonMeta($day11, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day12_META = createCommonMeta($day12, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day13_META = createCommonMeta($day13, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day14_META = createCommonMeta($day14, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day15_META = createCommonMeta($day15, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day16_META = createCommonMeta($day16, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day17_META = createCommonMeta($day17, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day18_META = createCommonMeta($day18, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day19_META = createCommonMeta($day19, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day20_META = createCommonMeta($day20, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day21_META = createCommonMeta($day21, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day22_META = createCommonMeta($day22, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day23_META = createCommonMeta($day23, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day24_META = createCommonMeta($day24, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day25_META = createCommonMeta($day25, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day26_META = createCommonMeta($day26, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day27_META = createCommonMeta($day27, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day28_META = createCommonMeta($day28, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day29_META = createCommonMeta($day29, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day30_META = createCommonMeta($day30, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta day31_META = createCommonMeta($day31, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta lastday_META = createCommonMeta($lastday, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<DayR> constMetas = new ConstMetaList<DayR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			day01_META,
			day02_META,
			day03_META,
			day04_META,
			day05_META,
			day06_META,
			day07_META,
			day08_META,
			day09_META,
			day10_META,
			day11_META,
			day12_META,
			day13_META,
			day14_META,
			day15_META,
			day16_META,
			day17_META,
			day18_META,
			day19_META,
			day20_META,
			day21_META,
			day22_META,
			day23_META,
			day24_META,
			day25_META,
			day26_META,
			day27_META,
			day28_META,
			day29_META,
			day30_META,
			day31_META,
			lastday_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected DayR_FW_A(ConstMetaList<? extends DayR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DayR clone() {
		return (DayR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DayR createInstance() {
		return (DayR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DayR getValues(String... names) {
		return (DayR) super.getValues(names);
	}



	/**
	 *  1.<p>
	 *
	 */
	public boolean day01() {
		return getConstBoolean(offset + 0, $day01);
	}

	/**
	 *  1.<p>
	 *
	 */
	public void day01(boolean value) {
		setConstBoolean(offset + 0, $day01, value);
	}


	/**
	 *  2.<p>
	 *
	 */
	public boolean day02() {
		return getConstBoolean(offset + 1, $day02);
	}

	/**
	 *  2.<p>
	 *
	 */
	public void day02(boolean value) {
		setConstBoolean(offset + 1, $day02, value);
	}


	/**
	 *  3.<p>
	 *
	 */
	public boolean day03() {
		return getConstBoolean(offset + 2, $day03);
	}

	/**
	 *  3.<p>
	 *
	 */
	public void day03(boolean value) {
		setConstBoolean(offset + 2, $day03, value);
	}


	/**
	 *  4.<p>
	 *
	 */
	public boolean day04() {
		return getConstBoolean(offset + 3, $day04);
	}

	/**
	 *  4.<p>
	 *
	 */
	public void day04(boolean value) {
		setConstBoolean(offset + 3, $day04, value);
	}


	/**
	 *  5.<p>
	 *
	 */
	public boolean day05() {
		return getConstBoolean(offset + 4, $day05);
	}

	/**
	 *  5.<p>
	 *
	 */
	public void day05(boolean value) {
		setConstBoolean(offset + 4, $day05, value);
	}


	/**
	 *  6.<p>
	 *
	 */
	public boolean day06() {
		return getConstBoolean(offset + 5, $day06);
	}

	/**
	 *  6.<p>
	 *
	 */
	public void day06(boolean value) {
		setConstBoolean(offset + 5, $day06, value);
	}


	/**
	 *  7.<p>
	 *
	 */
	public boolean day07() {
		return getConstBoolean(offset + 6, $day07);
	}

	/**
	 *  7.<p>
	 *
	 */
	public void day07(boolean value) {
		setConstBoolean(offset + 6, $day07, value);
	}


	/**
	 *  8.<p>
	 *
	 */
	public boolean day08() {
		return getConstBoolean(offset + 7, $day08);
	}

	/**
	 *  8.<p>
	 *
	 */
	public void day08(boolean value) {
		setConstBoolean(offset + 7, $day08, value);
	}


	/**
	 *  9.<p>
	 *
	 */
	public boolean day09() {
		return getConstBoolean(offset + 8, $day09);
	}

	/**
	 *  9.<p>
	 *
	 */
	public void day09(boolean value) {
		setConstBoolean(offset + 8, $day09, value);
	}


	/**
	 *  10.<p>
	 *
	 */
	public boolean day10() {
		return getConstBoolean(offset + 9, $day10);
	}

	/**
	 *  10.<p>
	 *
	 */
	public void day10(boolean value) {
		setConstBoolean(offset + 9, $day10, value);
	}


	/**
	 *  11.<p>
	 *
	 */
	public boolean day11() {
		return getConstBoolean(offset + 10, $day11);
	}

	/**
	 *  11.<p>
	 *
	 */
	public void day11(boolean value) {
		setConstBoolean(offset + 10, $day11, value);
	}


	/**
	 *  12.<p>
	 *
	 */
	public boolean day12() {
		return getConstBoolean(offset + 11, $day12);
	}

	/**
	 *  12.<p>
	 *
	 */
	public void day12(boolean value) {
		setConstBoolean(offset + 11, $day12, value);
	}


	/**
	 *  13.<p>
	 *
	 */
	public boolean day13() {
		return getConstBoolean(offset + 12, $day13);
	}

	/**
	 *  13.<p>
	 *
	 */
	public void day13(boolean value) {
		setConstBoolean(offset + 12, $day13, value);
	}


	/**
	 *  14.<p>
	 *
	 */
	public boolean day14() {
		return getConstBoolean(offset + 13, $day14);
	}

	/**
	 *  14.<p>
	 *
	 */
	public void day14(boolean value) {
		setConstBoolean(offset + 13, $day14, value);
	}


	/**
	 *  15.<p>
	 *
	 */
	public boolean day15() {
		return getConstBoolean(offset + 14, $day15);
	}

	/**
	 *  15.<p>
	 *
	 */
	public void day15(boolean value) {
		setConstBoolean(offset + 14, $day15, value);
	}


	/**
	 *  16.<p>
	 *
	 */
	public boolean day16() {
		return getConstBoolean(offset + 15, $day16);
	}

	/**
	 *  16.<p>
	 *
	 */
	public void day16(boolean value) {
		setConstBoolean(offset + 15, $day16, value);
	}


	/**
	 *  17.<p>
	 *
	 */
	public boolean day17() {
		return getConstBoolean(offset + 16, $day17);
	}

	/**
	 *  17.<p>
	 *
	 */
	public void day17(boolean value) {
		setConstBoolean(offset + 16, $day17, value);
	}


	/**
	 *  18.<p>
	 *
	 */
	public boolean day18() {
		return getConstBoolean(offset + 17, $day18);
	}

	/**
	 *  18.<p>
	 *
	 */
	public void day18(boolean value) {
		setConstBoolean(offset + 17, $day18, value);
	}


	/**
	 *  19.<p>
	 *
	 */
	public boolean day19() {
		return getConstBoolean(offset + 18, $day19);
	}

	/**
	 *  19.<p>
	 *
	 */
	public void day19(boolean value) {
		setConstBoolean(offset + 18, $day19, value);
	}


	/**
	 *  20.<p>
	 *
	 */
	public boolean day20() {
		return getConstBoolean(offset + 19, $day20);
	}

	/**
	 *  20.<p>
	 *
	 */
	public void day20(boolean value) {
		setConstBoolean(offset + 19, $day20, value);
	}


	/**
	 *  21.<p>
	 *
	 */
	public boolean day21() {
		return getConstBoolean(offset + 20, $day21);
	}

	/**
	 *  21.<p>
	 *
	 */
	public void day21(boolean value) {
		setConstBoolean(offset + 20, $day21, value);
	}


	/**
	 *  22.<p>
	 *
	 */
	public boolean day22() {
		return getConstBoolean(offset + 21, $day22);
	}

	/**
	 *  22.<p>
	 *
	 */
	public void day22(boolean value) {
		setConstBoolean(offset + 21, $day22, value);
	}


	/**
	 *  23.<p>
	 *
	 */
	public boolean day23() {
		return getConstBoolean(offset + 22, $day23);
	}

	/**
	 *  23.<p>
	 *
	 */
	public void day23(boolean value) {
		setConstBoolean(offset + 22, $day23, value);
	}


	/**
	 *  24.<p>
	 *
	 */
	public boolean day24() {
		return getConstBoolean(offset + 23, $day24);
	}

	/**
	 *  24.<p>
	 *
	 */
	public void day24(boolean value) {
		setConstBoolean(offset + 23, $day24, value);
	}


	/**
	 *  25.<p>
	 *
	 */
	public boolean day25() {
		return getConstBoolean(offset + 24, $day25);
	}

	/**
	 *  25.<p>
	 *
	 */
	public void day25(boolean value) {
		setConstBoolean(offset + 24, $day25, value);
	}


	/**
	 *  26.<p>
	 *
	 */
	public boolean day26() {
		return getConstBoolean(offset + 25, $day26);
	}

	/**
	 *  26.<p>
	 *
	 */
	public void day26(boolean value) {
		setConstBoolean(offset + 25, $day26, value);
	}


	/**
	 *  27.<p>
	 *
	 */
	public boolean day27() {
		return getConstBoolean(offset + 26, $day27);
	}

	/**
	 *  27.<p>
	 *
	 */
	public void day27(boolean value) {
		setConstBoolean(offset + 26, $day27, value);
	}


	/**
	 *  28.<p>
	 *
	 */
	public boolean day28() {
		return getConstBoolean(offset + 27, $day28);
	}

	/**
	 *  28.<p>
	 *
	 */
	public void day28(boolean value) {
		setConstBoolean(offset + 27, $day28, value);
	}


	/**
	 *  29.<p>
	 *
	 */
	public boolean day29() {
		return getConstBoolean(offset + 28, $day29);
	}

	/**
	 *  29.<p>
	 *
	 */
	public void day29(boolean value) {
		setConstBoolean(offset + 28, $day29, value);
	}


	/**
	 *  30.<p>
	 *
	 */
	public boolean day30() {
		return getConstBoolean(offset + 29, $day30);
	}

	/**
	 *  30.<p>
	 *
	 */
	public void day30(boolean value) {
		setConstBoolean(offset + 29, $day30, value);
	}


	/**
	 *  31.<p>
	 *
	 */
	public boolean day31() {
		return getConstBoolean(offset + 30, $day31);
	}

	/**
	 *  31.<p>
	 *
	 */
	public void day31(boolean value) {
		setConstBoolean(offset + 30, $day31, value);
	}


	/**
	 *  最終日.<p>
	 *
	 */
	public boolean lastday() {
		return getConstBoolean(offset + 31, $lastday);
	}

	/**
	 *  最終日.<p>
	 *
	 */
	public void lastday(boolean value) {
		setConstBoolean(offset + 31, $lastday, value);
	}


	public boolean getBoolean(String name) {
		if ($day01.equalsIgnoreCase(name)) {
			return day01();
		}
		if ($day02.equalsIgnoreCase(name)) {
			return day02();
		}
		if ($day03.equalsIgnoreCase(name)) {
			return day03();
		}
		if ($day04.equalsIgnoreCase(name)) {
			return day04();
		}
		if ($day05.equalsIgnoreCase(name)) {
			return day05();
		}
		if ($day06.equalsIgnoreCase(name)) {
			return day06();
		}
		if ($day07.equalsIgnoreCase(name)) {
			return day07();
		}
		if ($day08.equalsIgnoreCase(name)) {
			return day08();
		}
		if ($day09.equalsIgnoreCase(name)) {
			return day09();
		}
		if ($day10.equalsIgnoreCase(name)) {
			return day10();
		}
		if ($day11.equalsIgnoreCase(name)) {
			return day11();
		}
		if ($day12.equalsIgnoreCase(name)) {
			return day12();
		}
		if ($day13.equalsIgnoreCase(name)) {
			return day13();
		}
		if ($day14.equalsIgnoreCase(name)) {
			return day14();
		}
		if ($day15.equalsIgnoreCase(name)) {
			return day15();
		}
		if ($day16.equalsIgnoreCase(name)) {
			return day16();
		}
		if ($day17.equalsIgnoreCase(name)) {
			return day17();
		}
		if ($day18.equalsIgnoreCase(name)) {
			return day18();
		}
		if ($day19.equalsIgnoreCase(name)) {
			return day19();
		}
		if ($day20.equalsIgnoreCase(name)) {
			return day20();
		}
		if ($day21.equalsIgnoreCase(name)) {
			return day21();
		}
		if ($day22.equalsIgnoreCase(name)) {
			return day22();
		}
		if ($day23.equalsIgnoreCase(name)) {
			return day23();
		}
		if ($day24.equalsIgnoreCase(name)) {
			return day24();
		}
		if ($day25.equalsIgnoreCase(name)) {
			return day25();
		}
		if ($day26.equalsIgnoreCase(name)) {
			return day26();
		}
		if ($day27.equalsIgnoreCase(name)) {
			return day27();
		}
		if ($day28.equalsIgnoreCase(name)) {
			return day28();
		}
		if ($day29.equalsIgnoreCase(name)) {
			return day29();
		}
		if ($day30.equalsIgnoreCase(name)) {
			return day30();
		}
		if ($day31.equalsIgnoreCase(name)) {
			return day31();
		}
		if ($lastday.equalsIgnoreCase(name)) {
			return lastday();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($day01.equalsIgnoreCase(name)) {
			return day01();
		}
		if ($day02.equalsIgnoreCase(name)) {
			return day02();
		}
		if ($day03.equalsIgnoreCase(name)) {
			return day03();
		}
		if ($day04.equalsIgnoreCase(name)) {
			return day04();
		}
		if ($day05.equalsIgnoreCase(name)) {
			return day05();
		}
		if ($day06.equalsIgnoreCase(name)) {
			return day06();
		}
		if ($day07.equalsIgnoreCase(name)) {
			return day07();
		}
		if ($day08.equalsIgnoreCase(name)) {
			return day08();
		}
		if ($day09.equalsIgnoreCase(name)) {
			return day09();
		}
		if ($day10.equalsIgnoreCase(name)) {
			return day10();
		}
		if ($day11.equalsIgnoreCase(name)) {
			return day11();
		}
		if ($day12.equalsIgnoreCase(name)) {
			return day12();
		}
		if ($day13.equalsIgnoreCase(name)) {
			return day13();
		}
		if ($day14.equalsIgnoreCase(name)) {
			return day14();
		}
		if ($day15.equalsIgnoreCase(name)) {
			return day15();
		}
		if ($day16.equalsIgnoreCase(name)) {
			return day16();
		}
		if ($day17.equalsIgnoreCase(name)) {
			return day17();
		}
		if ($day18.equalsIgnoreCase(name)) {
			return day18();
		}
		if ($day19.equalsIgnoreCase(name)) {
			return day19();
		}
		if ($day20.equalsIgnoreCase(name)) {
			return day20();
		}
		if ($day21.equalsIgnoreCase(name)) {
			return day21();
		}
		if ($day22.equalsIgnoreCase(name)) {
			return day22();
		}
		if ($day23.equalsIgnoreCase(name)) {
			return day23();
		}
		if ($day24.equalsIgnoreCase(name)) {
			return day24();
		}
		if ($day25.equalsIgnoreCase(name)) {
			return day25();
		}
		if ($day26.equalsIgnoreCase(name)) {
			return day26();
		}
		if ($day27.equalsIgnoreCase(name)) {
			return day27();
		}
		if ($day28.equalsIgnoreCase(name)) {
			return day28();
		}
		if ($day29.equalsIgnoreCase(name)) {
			return day29();
		}
		if ($day30.equalsIgnoreCase(name)) {
			return day30();
		}
		if ($day31.equalsIgnoreCase(name)) {
			return day31();
		}
		if ($lastday.equalsIgnoreCase(name)) {
			return lastday();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($day01.equalsIgnoreCase(name)) {
			day01(value);
			return;
		}
		if ($day02.equalsIgnoreCase(name)) {
			day02(value);
			return;
		}
		if ($day03.equalsIgnoreCase(name)) {
			day03(value);
			return;
		}
		if ($day04.equalsIgnoreCase(name)) {
			day04(value);
			return;
		}
		if ($day05.equalsIgnoreCase(name)) {
			day05(value);
			return;
		}
		if ($day06.equalsIgnoreCase(name)) {
			day06(value);
			return;
		}
		if ($day07.equalsIgnoreCase(name)) {
			day07(value);
			return;
		}
		if ($day08.equalsIgnoreCase(name)) {
			day08(value);
			return;
		}
		if ($day09.equalsIgnoreCase(name)) {
			day09(value);
			return;
		}
		if ($day10.equalsIgnoreCase(name)) {
			day10(value);
			return;
		}
		if ($day11.equalsIgnoreCase(name)) {
			day11(value);
			return;
		}
		if ($day12.equalsIgnoreCase(name)) {
			day12(value);
			return;
		}
		if ($day13.equalsIgnoreCase(name)) {
			day13(value);
			return;
		}
		if ($day14.equalsIgnoreCase(name)) {
			day14(value);
			return;
		}
		if ($day15.equalsIgnoreCase(name)) {
			day15(value);
			return;
		}
		if ($day16.equalsIgnoreCase(name)) {
			day16(value);
			return;
		}
		if ($day17.equalsIgnoreCase(name)) {
			day17(value);
			return;
		}
		if ($day18.equalsIgnoreCase(name)) {
			day18(value);
			return;
		}
		if ($day19.equalsIgnoreCase(name)) {
			day19(value);
			return;
		}
		if ($day20.equalsIgnoreCase(name)) {
			day20(value);
			return;
		}
		if ($day21.equalsIgnoreCase(name)) {
			day21(value);
			return;
		}
		if ($day22.equalsIgnoreCase(name)) {
			day22(value);
			return;
		}
		if ($day23.equalsIgnoreCase(name)) {
			day23(value);
			return;
		}
		if ($day24.equalsIgnoreCase(name)) {
			day24(value);
			return;
		}
		if ($day25.equalsIgnoreCase(name)) {
			day25(value);
			return;
		}
		if ($day26.equalsIgnoreCase(name)) {
			day26(value);
			return;
		}
		if ($day27.equalsIgnoreCase(name)) {
			day27(value);
			return;
		}
		if ($day28.equalsIgnoreCase(name)) {
			day28(value);
			return;
		}
		if ($day29.equalsIgnoreCase(name)) {
			day29(value);
			return;
		}
		if ($day30.equalsIgnoreCase(name)) {
			day30(value);
			return;
		}
		if ($day31.equalsIgnoreCase(name)) {
			day31(value);
			return;
		}
		if ($lastday.equalsIgnoreCase(name)) {
			lastday(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($day01.equalsIgnoreCase(name)) {
			day01(value);
			return;
		}
		if ($day02.equalsIgnoreCase(name)) {
			day02(value);
			return;
		}
		if ($day03.equalsIgnoreCase(name)) {
			day03(value);
			return;
		}
		if ($day04.equalsIgnoreCase(name)) {
			day04(value);
			return;
		}
		if ($day05.equalsIgnoreCase(name)) {
			day05(value);
			return;
		}
		if ($day06.equalsIgnoreCase(name)) {
			day06(value);
			return;
		}
		if ($day07.equalsIgnoreCase(name)) {
			day07(value);
			return;
		}
		if ($day08.equalsIgnoreCase(name)) {
			day08(value);
			return;
		}
		if ($day09.equalsIgnoreCase(name)) {
			day09(value);
			return;
		}
		if ($day10.equalsIgnoreCase(name)) {
			day10(value);
			return;
		}
		if ($day11.equalsIgnoreCase(name)) {
			day11(value);
			return;
		}
		if ($day12.equalsIgnoreCase(name)) {
			day12(value);
			return;
		}
		if ($day13.equalsIgnoreCase(name)) {
			day13(value);
			return;
		}
		if ($day14.equalsIgnoreCase(name)) {
			day14(value);
			return;
		}
		if ($day15.equalsIgnoreCase(name)) {
			day15(value);
			return;
		}
		if ($day16.equalsIgnoreCase(name)) {
			day16(value);
			return;
		}
		if ($day17.equalsIgnoreCase(name)) {
			day17(value);
			return;
		}
		if ($day18.equalsIgnoreCase(name)) {
			day18(value);
			return;
		}
		if ($day19.equalsIgnoreCase(name)) {
			day19(value);
			return;
		}
		if ($day20.equalsIgnoreCase(name)) {
			day20(value);
			return;
		}
		if ($day21.equalsIgnoreCase(name)) {
			day21(value);
			return;
		}
		if ($day22.equalsIgnoreCase(name)) {
			day22(value);
			return;
		}
		if ($day23.equalsIgnoreCase(name)) {
			day23(value);
			return;
		}
		if ($day24.equalsIgnoreCase(name)) {
			day24(value);
			return;
		}
		if ($day25.equalsIgnoreCase(name)) {
			day25(value);
			return;
		}
		if ($day26.equalsIgnoreCase(name)) {
			day26(value);
			return;
		}
		if ($day27.equalsIgnoreCase(name)) {
			day27(value);
			return;
		}
		if ($day28.equalsIgnoreCase(name)) {
			day28(value);
			return;
		}
		if ($day29.equalsIgnoreCase(name)) {
			day29(value);
			return;
		}
		if ($day30.equalsIgnoreCase(name)) {
			day30(value);
			return;
		}
		if ($day31.equalsIgnoreCase(name)) {
			day31(value);
			return;
		}
		if ($lastday.equalsIgnoreCase(name)) {
			lastday(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

