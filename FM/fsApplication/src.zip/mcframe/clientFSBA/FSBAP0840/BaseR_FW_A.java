package mcframe.clientFSBA.FSBAP0840;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Base"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BaseR_FW_A extends MCConstRow {

	/**
	 *  説明.<p>
	 *
	 */
	public static final String $desc = "desc";
	/**
	 *  無効.<p>
	 *
	 */
	public static final String $inv_flg = "inv_flg";
	/**
	 *  実行時.<p>
	 *
	 */
	public static final String $hour = "hour";
	/**
	 *  実行分.<p>
	 *
	 */
	public static final String $minute = "minute";


	public static final MCMeta desc_META = createStringMeta($desc);
	public static final MCMeta inv_flg_META = createCommonMeta($inv_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta hour_META = createNumberMeta($hour, 2, 0, false);
	public static final MCMeta minute_META = createNumberMeta($minute, 2, 0, false);

	protected static final ConstMetaList<BaseR> constMetas = new ConstMetaList<BaseR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			desc_META,
			inv_flg_META,
			hour_META,
			minute_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BaseR_FW_A(ConstMetaList<? extends BaseR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BaseR clone() {
		return (BaseR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BaseR createInstance() {
		return (BaseR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BaseR getValues(String... names) {
		return (BaseR) super.getValues(names);
	}



	/**
	 *  説明.<p>
	 *
	 */
	public String desc() {
		return getConstString(offset + 0, $desc);
	}

	/**
	 *  説明.<p>
	 *
	 */
	public void desc(String value) {
		setConstString(offset + 0, $desc, value);
	}


	/**
	 *  無効.<p>
	 *
	 */
	public boolean inv_flg() {
		return getConstBoolean(offset + 1, $inv_flg);
	}

	/**
	 *  無効.<p>
	 *
	 */
	public void inv_flg(boolean value) {
		setConstBoolean(offset + 1, $inv_flg, value);
	}


	/**
	 *  実行時.<p>
	 *
	 */
	public MCNumber hour() {
		return getConstNumber(offset + 2, $hour);
	}

	/**
	 *  実行時.<p>
	 *
	 */
	public void hour(MCNumber value) {
		setConstNumber(offset + 2, $hour, value);
	}

	/**
	 *  実行時.<p>
	 *
	 */
	public void hour(int value) {
		setConstNumber(offset + 2, $hour, value);
	}

	/**
	 *  実行時.<p>
	 *
	 */
	public void hour(long value) {
		setConstNumber(offset + 2, $hour, value);
	}

	/**
	 *  実行時.<p>
	 *
	 */
	public void hour(float value) {
		setConstNumber(offset + 2, $hour, value);
	}

	/**
	 *  実行時.<p>
	 *
	 */
	public void hour(double value) {
		setConstNumber(offset + 2, $hour, value);
	}


	/**
	 *  実行分.<p>
	 *
	 */
	public MCNumber minute() {
		return getConstNumber(offset + 3, $minute);
	}

	/**
	 *  実行分.<p>
	 *
	 */
	public void minute(MCNumber value) {
		setConstNumber(offset + 3, $minute, value);
	}

	/**
	 *  実行分.<p>
	 *
	 */
	public void minute(int value) {
		setConstNumber(offset + 3, $minute, value);
	}

	/**
	 *  実行分.<p>
	 *
	 */
	public void minute(long value) {
		setConstNumber(offset + 3, $minute, value);
	}

	/**
	 *  実行分.<p>
	 *
	 */
	public void minute(float value) {
		setConstNumber(offset + 3, $minute, value);
	}

	/**
	 *  実行分.<p>
	 *
	 */
	public void minute(double value) {
		setConstNumber(offset + 3, $minute, value);
	}


	public String getString(String name) {
		if ($desc.equalsIgnoreCase(name)) {
			return desc();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($desc.equalsIgnoreCase(name)) {
			return desc();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			return inv_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($desc.equalsIgnoreCase(name)) {
			desc(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($desc.equalsIgnoreCase(name)) {
			desc(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($inv_flg.equalsIgnoreCase(name)) {
			inv_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

