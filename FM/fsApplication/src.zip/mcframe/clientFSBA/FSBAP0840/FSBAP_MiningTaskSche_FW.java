package mcframe.clientFSBA.FSBAP0840;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSBA.FSBAP0820.TaskR;
import mcframe.clientFSBA.FSBAP0850.ScheDtlR;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_MiningTaskSche"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_MiningTaskSche_FW extends FSBAP_MiningTaskSche_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * フラグ抽出用フィルタ
	 */
	private final long FILTER = 1L;
	/**
	 * フラグ値：ON
	 */
	private final long ON = 1L;
	/**
	 * フラグ値：OFF
	 */
	private final long OFF = 0L;

	/**
	 * 呼び出し元のタスクデータ
	 */
	protected TaskR _taskR;
	/**
	 * 呼び出し元のスケジュールデータ
	 */
	protected ScheDtlR _scheR;
	/**
	 * 呼び出し元のスケジュール一覧テーブル
	 */
	protected MCTable _scheTable;
	/**
	 * 新規スケジュールの場合 true
	 */
	protected boolean _newSche = false;

	/**
	 * 設定種別：日
	 */
	protected String TYPE_DAY;
	/**
	 * 設定種別：曜日
	 */
	protected String TYPE_WEEK;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTaskSche_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Ctrl]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doCtrl_upd(MCEventInfo info) {
		BaseR baseR = getBaseR();

		// 必須チェック（xAppsに合わせる）
		// パネルのラベルを使うため FXUCP_ValidaterUtil.msgNoDataAtReq は使用しない
		String msgid = FXUCC0046;
		MCMessageList msgList = new MCMessageList();
		if (MCStringUtil.isNull(baseR.desc())) {
			// 説明
			msgList.add(new MCMessage(msgid, Base_desc.getLabelByLocale()));
		}
		if (baseR.hour() == null || baseR.minute() == null) {
			// 実行時刻
			msgList.add(new MCMessage(msgid, Base_hour.getLabelByLocale()));
		}
		if (getMonthR().isEmpty()) {
			// 月
			msgList.add(new MCMessage(msgid, MonthPanel.getLabelByLocale()));
		}
		if (isSame(getTypeR().type(), TYPE_DAY)) {
			if (getDayR().isEmpty()) {
				// 日
				msgList.add(new MCMessage(msgid, DayPanel.getLabelByLocale()));
			}
		}
		else if (isSame(getTypeR().type(), TYPE_WEEK)) {
			if (getWeekR().isEmpty()) {
				// 週
				msgList.add(new MCMessage(msgid, DayOfWeekPanel.getLabelByLocale()));
			}
			if (getWeekdayR().isEmpty()) {
				// 曜日
				msgList.add(new MCMessage(msgid, DayOfWeekPanel.getLabelByLocale()));
			}
		}
		if (msgList.size() > 0) {
			message(msgList);
			return;
		}

		// 画面のRowから呼び出し元のRowに変換
		convTo();

		// 画面クローズ
		statusClear();
		requestCloseWindow();
	}

	@Override
	public boolean doBase_hour_VC(MCEventInfo info){
		MCNumber num = (MCNumber) info.getNewValue();
		if (num != null) {
			if (num.lt(0)) {
				// マイナス不可
				return false;
			}
			if (num.gt(23)) {
				// 23より大きい
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean doBase_minute_VC(MCEventInfo info){
		MCNumber num = (MCNumber) info.getNewValue();
		if (num != null) {
			if (num.lt(0)) {
				// マイナス不可
				return false;
			}
			if (num.gt(59)) {
				// 59より大きい
				return false;
			}
		}
		return true;
	}

	@Override
	public void doType_type_NC(MCEventInfo info){
		MCRadioButton select = Type_type_Group.getSelectedButton();
		if (select == Type_type_day) {
			setStatus(DAY);
		}
		else if (select == Type_type_week) {
			setStatus(WEEKDAY);
		}
		resetItems();
	}

	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			if (args == null || args.length < 1) {
				// 引数不正
				throw new MCAppException(msgUnknownOpenParam());
			}

			_taskR = (TaskR) args[0];
			_scheR = (ScheDtlR) args[1];
			_scheTable = (MCTable) args[2];
			_newSche = isNull(_scheR.sche_no());

			// タイプの値
			TYPE_DAY = Type_type_day.getActionCommand();
			TYPE_WEEK = Type_type_week.getActionCommand();
		}
		else {
			// タイプ不正
			throw new MCAppException(msgUnknownOpenParam());
		}
		valueInit();
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		// タイプ
		long weekno = (_scheR.week_no() != null)
									? _scheR.week_no().longValue() : OFF;
		long weekday = (_scheR.week_day() != null)
									? _scheR.week_day().longValue() : OFF;
		Type_type_Group.setValue(
						(weekno == 0 && weekday == 0) ? TYPE_DAY : TYPE_WEEK);

		// 呼び出し元のRowから画面のRowに変換
		convFrom();
	}

	@Override
	public void panelClosed() {
		super.panelClosed();

		int index = _scheTable.getMCSelectedRow();

		// 新規作成・コピーでキャンセルの場合、Rowを破棄
		if (isNull(_scheR.sche_no())) {
			_scheTable.getList().remove(_scheR);
			if (index > 0) {
				index--;
			}
		}

		// フォーカスの調整
		if (_scheTable.getRowCount() <= index) {
			index = _scheTable.getRowCount() - 1;
		}
		if (index < 0) {
			_scheTable.transferFocus();
		}
		else {
			_scheTable.selectLeftmostColumn(index);
		}

		_scheTable.sort();
	}

	/**
	 * 呼び出し元画面のデータをこの画面に設定します。
	 *
	 */
	protected void convFrom() {
		// 時刻
		BaseR baseR = getBaseR();
		baseR.desc(_scheR.desc());
		baseR.inv_flg(_scheR.inv_flg());
		baseR.hour(_scheR.hour());
		baseR.minute(_scheR.minute());

		long month = (_scheR.month() != null)
									? _scheR.month().longValue() : OFF;
		long day = (_scheR.day() != null)
									? _scheR.day().longValue() : OFF;
		long weekno = (_scheR.week_no() != null)
									? _scheR.week_no().longValue() : OFF;
		long weekday = (_scheR.week_day() != null)
									? _scheR.week_day().longValue() : OFF;

		// 月
		MonthR monthR = getMonthR();
		monthR.month01((month & FILTER) == ON); month >>>= 1;
		monthR.month02((month & FILTER) == ON); month >>>= 1;
		monthR.month03((month & FILTER) == ON); month >>>= 1;
		monthR.month04((month & FILTER) == ON); month >>>= 1;
		monthR.month05((month & FILTER) == ON); month >>>= 1;
		monthR.month06((month & FILTER) == ON); month >>>= 1;
		monthR.month07((month & FILTER) == ON); month >>>= 1;
		monthR.month08((month & FILTER) == ON); month >>>= 1;
		monthR.month09((month & FILTER) == ON); month >>>= 1;
		monthR.month10((month & FILTER) == ON); month >>>= 1;
		monthR.month11((month & FILTER) == ON); month >>>= 1;
		monthR.month12((month & FILTER) == ON);
		if (weekno == OFF && weekday == OFF) {
			// 日
			DayR dayR = getDayR();
			dayR.day01((day & FILTER) == ON); day >>>= 1;
			dayR.day02((day & FILTER) == ON); day >>>= 1;
			dayR.day03((day & FILTER) == ON); day >>>= 1;
			dayR.day04((day & FILTER) == ON); day >>>= 1;
			dayR.day05((day & FILTER) == ON); day >>>= 1;
			dayR.day06((day & FILTER) == ON); day >>>= 1;
			dayR.day07((day & FILTER) == ON); day >>>= 1;
			dayR.day08((day & FILTER) == ON); day >>>= 1;
			dayR.day09((day & FILTER) == ON); day >>>= 1;
			dayR.day10((day & FILTER) == ON); day >>>= 1;
			dayR.day11((day & FILTER) == ON); day >>>= 1;
			dayR.day12((day & FILTER) == ON); day >>>= 1;
			dayR.day13((day & FILTER) == ON); day >>>= 1;
			dayR.day14((day & FILTER) == ON); day >>>= 1;
			dayR.day15((day & FILTER) == ON); day >>>= 1;
			dayR.day16((day & FILTER) == ON); day >>>= 1;
			dayR.day17((day & FILTER) == ON); day >>>= 1;
			dayR.day18((day & FILTER) == ON); day >>>= 1;
			dayR.day19((day & FILTER) == ON); day >>>= 1;
			dayR.day20((day & FILTER) == ON); day >>>= 1;
			dayR.day21((day & FILTER) == ON); day >>>= 1;
			dayR.day22((day & FILTER) == ON); day >>>= 1;
			dayR.day23((day & FILTER) == ON); day >>>= 1;
			dayR.day24((day & FILTER) == ON); day >>>= 1;
			dayR.day25((day & FILTER) == ON); day >>>= 1;
			dayR.day26((day & FILTER) == ON); day >>>= 1;
			dayR.day27((day & FILTER) == ON); day >>>= 1;
			dayR.day28((day & FILTER) == ON); day >>>= 1;
			dayR.day29((day & FILTER) == ON); day >>>= 1;
			dayR.day30((day & FILTER) == ON); day >>>= 1;
			dayR.day31((day & FILTER) == ON); day >>>= 1;
			dayR.lastday((day & FILTER) == ON);
		}
		if (day == OFF) {
			// 曜日
			WeekR weekR = getWeekR();
			weekR.week01((weekno & FILTER) == ON); weekno >>>= 1;
			weekR.week02((weekno & FILTER) == ON); weekno >>>= 1;
			weekR.week03((weekno & FILTER) == ON); weekno >>>= 1;
			weekR.week04((weekno & FILTER) == ON); weekno >>>= 1;
			weekR.lastweek((weekno & FILTER) == ON);
			WeekdayR weekdayR = getWeekdayR();
			weekdayR.weekday01((weekday & FILTER) == ON); weekday >>>= 1;
			weekdayR.weekday02((weekday & FILTER) == ON); weekday >>>= 1;
			weekdayR.weekday03((weekday & FILTER) == ON); weekday >>>= 1;
			weekdayR.weekday04((weekday & FILTER) == ON); weekday >>>= 1;
			weekdayR.weekday05((weekday & FILTER) == ON); weekday >>>= 1;
			weekdayR.weekday06((weekday & FILTER) == ON); weekday >>>= 1;
			weekdayR.weekday07((weekday & FILTER) == ON);
		}
	}

	/**
	 * この画面のデータを呼び出し元の画面に設定します。
	 * 
	 */
	protected void convTo() {
		// 新規の場合タスクIDとスケジュールNoを設定
		if (_newSche) {
			int scheno = 0;
			MCList<ScheDtlR> scheL = _scheTable.getList().shallowClone();
			scheL.sort(ScheDtlR.$sche_no);
			for (; scheno < scheL.size(); scheno++) {
				ScheDtlR scheR = scheL.get(scheno);
				MCNumber no = scheR.sche_no();
				if (no == null || !no.eq(scheno)) {
					break;
				}
			}
			_scheR.task_id(_taskR.task_id());
			_scheR.sche_no(scheno);
		}

		// 時刻
		BaseR baseR = getBaseR();
		_scheR.desc(baseR.desc());
		_scheR.inv_flg(baseR.inv_flg());
		_scheR.hour(baseR.hour());
		_scheR.minute(baseR.minute());
		_scheR.time(
				MCDate.valueOf(MCDateFieldType.HOUR,
						_scheR.hour().intValue(),
						_scheR.minute().intValue(),
						0)
		);
		// 月
		MonthR monthR = getMonthR();
		long month = OFF;
		month += (monthR.month12()) ? ON : OFF; month <<= 1;
		month += (monthR.month11()) ? ON : OFF; month <<= 1;
		month += (monthR.month10()) ? ON : OFF; month <<= 1;
		month += (monthR.month09()) ? ON : OFF; month <<= 1;
		month += (monthR.month08()) ? ON : OFF; month <<= 1;
		month += (monthR.month07()) ? ON : OFF; month <<= 1;
		month += (monthR.month06()) ? ON : OFF; month <<= 1;
		month += (monthR.month05()) ? ON : OFF; month <<= 1;
		month += (monthR.month04()) ? ON : OFF; month <<= 1;
		month += (monthR.month03()) ? ON : OFF; month <<= 1;
		month += (monthR.month02()) ? ON : OFF; month <<= 1;
		month += (monthR.month01()) ? ON : OFF;
		_scheR.month(month);
		long day = OFF;
		long weekno = OFF;
		long weekday = OFF;
		if (isSame(getTypeR().type(), TYPE_DAY)) {
			// 日
			DayR dayR = getDayR();
			day += (dayR.lastday()) ? ON : OFF; day <<= 1;
			day += (dayR.day31()) ? ON : OFF; day <<= 1;
			day += (dayR.day30()) ? ON : OFF; day <<= 1;
			day += (dayR.day29()) ? ON : OFF; day <<= 1;
			day += (dayR.day28()) ? ON : OFF; day <<= 1;
			day += (dayR.day27()) ? ON : OFF; day <<= 1;
			day += (dayR.day26()) ? ON : OFF; day <<= 1;
			day += (dayR.day25()) ? ON : OFF; day <<= 1;
			day += (dayR.day24()) ? ON : OFF; day <<= 1;
			day += (dayR.day23()) ? ON : OFF; day <<= 1;
			day += (dayR.day22()) ? ON : OFF; day <<= 1;
			day += (dayR.day21()) ? ON : OFF; day <<= 1;
			day += (dayR.day20()) ? ON : OFF; day <<= 1;
			day += (dayR.day19()) ? ON : OFF; day <<= 1;
			day += (dayR.day18()) ? ON : OFF; day <<= 1;
			day += (dayR.day17()) ? ON : OFF; day <<= 1;
			day += (dayR.day16()) ? ON : OFF; day <<= 1;
			day += (dayR.day15()) ? ON : OFF; day <<= 1;
			day += (dayR.day14()) ? ON : OFF; day <<= 1;
			day += (dayR.day13()) ? ON : OFF; day <<= 1;
			day += (dayR.day12()) ? ON : OFF; day <<= 1;
			day += (dayR.day11()) ? ON : OFF; day <<= 1;
			day += (dayR.day10()) ? ON : OFF; day <<= 1;
			day += (dayR.day09()) ? ON : OFF; day <<= 1;
			day += (dayR.day08()) ? ON : OFF; day <<= 1;
			day += (dayR.day07()) ? ON : OFF; day <<= 1;
			day += (dayR.day06()) ? ON : OFF; day <<= 1;
			day += (dayR.day05()) ? ON : OFF; day <<= 1;
			day += (dayR.day04()) ? ON : OFF; day <<= 1;
			day += (dayR.day03()) ? ON : OFF; day <<= 1;
			day += (dayR.day02()) ? ON : OFF; day <<= 1;
			day += (dayR.day01()) ? ON : OFF;
		}
		else if (isSame(getTypeR().type(), TYPE_WEEK)) {
			// 曜日
			WeekR weekR = getWeekR();
			weekno += (weekR.lastweek()) ? ON : OFF; weekno <<= 1;
			weekno += (weekR.week04()) ? ON : OFF; weekno <<= 1;
			weekno += (weekR.week03()) ? ON : OFF; weekno <<= 1;
			weekno += (weekR.week02()) ? ON : OFF; weekno <<= 1;
			weekno += (weekR.week01()) ? ON : OFF;
			WeekdayR weekdayR = getWeekdayR();
			weekday += (weekdayR.weekday07()) ? ON : OFF; weekday <<= 1;
			weekday += (weekdayR.weekday06()) ? ON : OFF; weekday <<= 1;
			weekday += (weekdayR.weekday05()) ? ON : OFF; weekday <<= 1;
			weekday += (weekdayR.weekday04()) ? ON : OFF; weekday <<= 1;
			weekday += (weekdayR.weekday03()) ? ON : OFF; weekday <<= 1;
			weekday += (weekdayR.weekday02()) ? ON : OFF; weekday <<= 1;
			weekday += (weekdayR.weekday01()) ? ON : OFF;
		}
		_scheR.day(day);
		_scheR.week_no(weekno);
		_scheR.week_day(weekday);

		// ステータスの変更
		_scheR.setStatus(_newSche ? Status.CREATE : Status.MODIFY);
	}

	/**
	 * 日と曜日をリセットします。
	 * 
	 */
	protected void resetItems() {
		// 日
		DayR dayR = getDayR();
		dayR.day01(false);
		dayR.day02(false);
		dayR.day03(false);
		dayR.day04(false);
		dayR.day05(false);
		dayR.day06(false);
		dayR.day07(false);
		dayR.day08(false);
		dayR.day09(false);
		dayR.day10(false);
		dayR.day11(false);
		dayR.day12(false);
		dayR.day13(false);
		dayR.day14(false);
		dayR.day15(false);
		dayR.day16(false);
		dayR.day17(false);
		dayR.day18(false);
		dayR.day19(false);
		dayR.day20(false);
		dayR.day21(false);
		dayR.day22(false);
		dayR.day23(false);
		dayR.day24(false);
		dayR.day25(false);
		dayR.day26(false);
		dayR.day27(false);
		dayR.day28(false);
		dayR.day29(false);
		dayR.day30(false);
		dayR.day31(false);
		dayR.lastday(false);

		// 曜日
		WeekR weekR = getWeekR();
		weekR.week01(false);
		weekR.week02(false);
		weekR.week03(false);
		weekR.week04(false);
		weekR.lastweek(false);
		WeekdayR weekdayR = getWeekdayR();
		weekdayR.weekday01(false);
		weekdayR.weekday02(false);
		weekdayR.weekday03(false);
		weekdayR.weekday04(false);
		weekdayR.weekday05(false);
		weekdayR.weekday06(false);
		weekdayR.weekday07(false);
	}

}