package mcframe.clientFSBA.FSBAP0840;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.annotation.EI;

/**
 * ブロック"Weekday"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * <table border=1 cellspacing=0 cellpadding=2 >
 *  <caption>[項目定義]</caption>
 * 	<tr bgcolor="#cccccc">
 *  	<th>alias</th>
 *  	<th>項目名</th>
 *  	<th>フルネーム</th>
 *  	<th>型</th>
 *  	<th>桁</th>
 *  	<th>INNERROW/COLUMNPATH</th>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>weekday01</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>weekday02</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>weekday03</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>weekday04</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>weekday05</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>weekday06</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>weekday07</td>
 *  	<td><br></td>
 *  	<td>Boolean</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#FLG FLG}]</td>
 *  	<td><br></td>
 *  </tr>
 * </table>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class WeekdayR extends WeekdayR_FW_A {

	/**
	 * 新しいRowを生成します。
	 *
	 * @return 新しいインスタンス
	 */
	public static WeekdayR create() {
		WeekdayR row = new WeekdayR(constMetas);
		return row;
	}

	/**
	 * 新しいRowを生成し別のRowの内容を設定します。
	 *
	 * @param proto 設定するRow
	 * @return 内容を設定した新しいインスタンス
	 */
	public static <T extends MCRow> WeekdayR createByName(T proto) {
		WeekdayR row = WeekdayR.create();
		copyByName(row, proto);
		return row;
	}

	/**
	 * コンストラクタです。
	 */
	public WeekdayR(ConstMetaList<? extends WeekdayR> metas) {
		super(metas);
	}
}