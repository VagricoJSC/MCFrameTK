package mcframe.clientFSBA.FSBAP0840;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_MiningTaskSche"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_MiningTaskSche_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0840";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Base]ブロック関連のField定義
	public MCPanel BasePanel = null;
	// [Base]ブロックの項目のField定義
	public MCLabel Base_desc_Label = null;
	public MCScrollPane Base_descScrollPane = null;
	/**
	 *  説明.<p>
	 *
	 */
	public MCTextArea Base_desc = null;
	/**
	 *  無効.<p>
	 *
	 */
	public MCCheckBox Base_inv_flg = null;
	public MCLabel Base_hour_Label = null;
	/**
	 *  実行時.<p>
	 *
	 */
	public MCNumberField Base_hour = null;
	public MCLabel Base_minute_Label = null;
	/**
	 *  実行分.<p>
	 *
	 */
	public MCNumberField Base_minute = null;
	// [Prop]ブロック関連のField定義
	public MCPanel PropPanel = null;
	// [Prop]ブロックの項目のField定義
	// [Time]ブロック関連のField定義
	public MCPanel TimePanel = null;
	// [Time]ブロックの項目のField定義
	// [Month]ブロック関連のField定義
	public MCPanel MonthPanel = null;
	public MCTitledBorder MonthTitledBorder = null;
	// [Month]ブロックの項目のField定義
	/**
	 *  1月.<p>
	 *
	 */
	public MCCheckBox Month_month01 = null;
	/**
	 *  2月.<p>
	 *
	 */
	public MCCheckBox Month_month02 = null;
	/**
	 *  3月.<p>
	 *
	 */
	public MCCheckBox Month_month03 = null;
	/**
	 *  4月.<p>
	 *
	 */
	public MCCheckBox Month_month04 = null;
	/**
	 *  5月.<p>
	 *
	 */
	public MCCheckBox Month_month05 = null;
	/**
	 *  6月.<p>
	 *
	 */
	public MCCheckBox Month_month06 = null;
	/**
	 *  7月.<p>
	 *
	 */
	public MCCheckBox Month_month07 = null;
	/**
	 *  8月.<p>
	 *
	 */
	public MCCheckBox Month_month08 = null;
	/**
	 *  9月.<p>
	 *
	 */
	public MCCheckBox Month_month09 = null;
	/**
	 *  10月.<p>
	 *
	 */
	public MCCheckBox Month_month10 = null;
	/**
	 *  11月.<p>
	 *
	 */
	public MCCheckBox Month_month11 = null;
	/**
	 *  12月.<p>
	 *
	 */
	public MCCheckBox Month_month12 = null;
	// [Type]ブロック関連のField定義
	public MCPanel TypePanel = null;
	// [Type]ブロックの項目のField定義
	/**
	 *  day,日;week,曜日.<p>
	 *
	 */
	public MCButtonGroup Type_type_Group = null;
	public MCRadioButton Type_type_day = null;
	public MCRadioButton Type_type_week = null;
	// [Day]ブロック関連のField定義
	public MCPanel DayPanel = null;
	public MCTitledBorder DayTitledBorder = null;
	// [Day]ブロックの項目のField定義
	/**
	 *  1.<p>
	 *
	 */
	public MCCheckBox Day_day01 = null;
	/**
	 *  2.<p>
	 *
	 */
	public MCCheckBox Day_day02 = null;
	/**
	 *  3.<p>
	 *
	 */
	public MCCheckBox Day_day03 = null;
	/**
	 *  4.<p>
	 *
	 */
	public MCCheckBox Day_day04 = null;
	/**
	 *  5.<p>
	 *
	 */
	public MCCheckBox Day_day05 = null;
	/**
	 *  6.<p>
	 *
	 */
	public MCCheckBox Day_day06 = null;
	/**
	 *  7.<p>
	 *
	 */
	public MCCheckBox Day_day07 = null;
	/**
	 *  8.<p>
	 *
	 */
	public MCCheckBox Day_day08 = null;
	/**
	 *  9.<p>
	 *
	 */
	public MCCheckBox Day_day09 = null;
	/**
	 *  10.<p>
	 *
	 */
	public MCCheckBox Day_day10 = null;
	/**
	 *  11.<p>
	 *
	 */
	public MCCheckBox Day_day11 = null;
	/**
	 *  12.<p>
	 *
	 */
	public MCCheckBox Day_day12 = null;
	/**
	 *  13.<p>
	 *
	 */
	public MCCheckBox Day_day13 = null;
	/**
	 *  14.<p>
	 *
	 */
	public MCCheckBox Day_day14 = null;
	/**
	 *  15.<p>
	 *
	 */
	public MCCheckBox Day_day15 = null;
	/**
	 *  16.<p>
	 *
	 */
	public MCCheckBox Day_day16 = null;
	/**
	 *  17.<p>
	 *
	 */
	public MCCheckBox Day_day17 = null;
	/**
	 *  18.<p>
	 *
	 */
	public MCCheckBox Day_day18 = null;
	/**
	 *  19.<p>
	 *
	 */
	public MCCheckBox Day_day19 = null;
	/**
	 *  20.<p>
	 *
	 */
	public MCCheckBox Day_day20 = null;
	/**
	 *  21.<p>
	 *
	 */
	public MCCheckBox Day_day21 = null;
	/**
	 *  22.<p>
	 *
	 */
	public MCCheckBox Day_day22 = null;
	/**
	 *  23.<p>
	 *
	 */
	public MCCheckBox Day_day23 = null;
	/**
	 *  24.<p>
	 *
	 */
	public MCCheckBox Day_day24 = null;
	/**
	 *  25.<p>
	 *
	 */
	public MCCheckBox Day_day25 = null;
	/**
	 *  26.<p>
	 *
	 */
	public MCCheckBox Day_day26 = null;
	/**
	 *  27.<p>
	 *
	 */
	public MCCheckBox Day_day27 = null;
	/**
	 *  28.<p>
	 *
	 */
	public MCCheckBox Day_day28 = null;
	/**
	 *  29.<p>
	 *
	 */
	public MCCheckBox Day_day29 = null;
	/**
	 *  30.<p>
	 *
	 */
	public MCCheckBox Day_day30 = null;
	/**
	 *  31.<p>
	 *
	 */
	public MCCheckBox Day_day31 = null;
	/**
	 *  最終日.<p>
	 *
	 */
	public MCCheckBox Day_lastday = null;
	// [DayOfWeek]ブロック関連のField定義
	public MCPanel DayOfWeekPanel = null;
	public MCTitledBorder DayOfWeekTitledBorder = null;
	// [DayOfWeek]ブロックの項目のField定義
	// [Week]ブロック関連のField定義
	public MCPanel WeekPanel = null;
	// [Week]ブロックの項目のField定義
	/**
	 *  第1.<p>
	 *
	 */
	public MCCheckBox Week_week01 = null;
	/**
	 *  第2.<p>
	 *
	 */
	public MCCheckBox Week_week02 = null;
	/**
	 *  第3.<p>
	 *
	 */
	public MCCheckBox Week_week03 = null;
	/**
	 *  第4.<p>
	 *
	 */
	public MCCheckBox Week_week04 = null;
	/**
	 *  最終.<p>
	 *
	 */
	public MCCheckBox Week_lastweek = null;
	// [Weekday]ブロック関連のField定義
	public MCPanel WeekdayPanel = null;
	// [Weekday]ブロックの項目のField定義
	/**
	 *  日.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday01 = null;
	/**
	 *  月.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday02 = null;
	/**
	 *  火.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday03 = null;
	/**
	 *  水.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday04 = null;
	/**
	 *  木.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday05 = null;
	/**
	 *  金.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday06 = null;
	/**
	 *  土.<p>
	 *
	 */
	public MCCheckBox Weekday_weekday07 = null;
	// [Ctrl]ブロック関連のField定義
	public MCPanel CtrlPanel = null;
	// [Ctrl]ブロックの項目のField定義
	/**
	 *  OK.<p>
	 *
	 */
	public MCButton Ctrl_upd = null;
	/** [DAY]モードを表す定数 */
	public static final String DAY = "DAY";
	/** [WEEKDAY]モードを表す定数 */
	public static final String WEEKDAY = "WEEKDAY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{DAY, WEEKDAY};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Base]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0840.BaseR aBaseR;
	/** [Month]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0840.MonthR aMonthR;
	/** [Type]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0840.TypeR aTypeR;
	/** [Day]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0840.DayR aDayR;
	/** [Week]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0840.WeekR aWeekR;
	/** [Weekday]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0840.WeekdayR aWeekdayR;

	/**
	 * 項目コピーによってaBaseRを設定します。
	 *
	 * aBaseRのインスタンスは変更されません。
	 *
	 * @param row BaseR
	 */
	public void setBaseR(mcframe.clientFSBA.FSBAP0840.BaseR row) {
		if (row != null) {
			MCRow.copyall(getBaseR(), row);
		}
	}

	/**
	 * [Base]ブロックのコンテナaBaseRを返します。
	 *
	 * @return BaseR
	 */
	public mcframe.clientFSBA.FSBAP0840.BaseR getBaseR() {
		return aBaseR;
	}

	/**
	 * aBaseRを作成します。
	 *
	 * @return BaseR
	 */
	public mcframe.clientFSBA.FSBAP0840.BaseR createBaseR() {
		return mcframe.clientFSBA.FSBAP0840.BaseR.create();
	}

	/**
	 * 項目コピーによってaMonthRを設定します。
	 *
	 * aMonthRのインスタンスは変更されません。
	 *
	 * @param row MonthR
	 */
	public void setMonthR(mcframe.clientFSBA.FSBAP0840.MonthR row) {
		if (row != null) {
			MCRow.copyall(getMonthR(), row);
		}
	}

	/**
	 * [Month]ブロックのコンテナaMonthRを返します。
	 *
	 * @return MonthR
	 */
	public mcframe.clientFSBA.FSBAP0840.MonthR getMonthR() {
		return aMonthR;
	}

	/**
	 * aMonthRを作成します。
	 *
	 * @return MonthR
	 */
	public mcframe.clientFSBA.FSBAP0840.MonthR createMonthR() {
		return mcframe.clientFSBA.FSBAP0840.MonthR.create();
	}

	/**
	 * 項目コピーによってaTypeRを設定します。
	 *
	 * aTypeRのインスタンスは変更されません。
	 *
	 * @param row TypeR
	 */
	public void setTypeR(mcframe.clientFSBA.FSBAP0840.TypeR row) {
		if (row != null) {
			MCRow.copyall(getTypeR(), row);
		}
	}

	/**
	 * [Type]ブロックのコンテナaTypeRを返します。
	 *
	 * @return TypeR
	 */
	public mcframe.clientFSBA.FSBAP0840.TypeR getTypeR() {
		return aTypeR;
	}

	/**
	 * aTypeRを作成します。
	 *
	 * @return TypeR
	 */
	public mcframe.clientFSBA.FSBAP0840.TypeR createTypeR() {
		return mcframe.clientFSBA.FSBAP0840.TypeR.create();
	}

	/**
	 * 項目コピーによってaDayRを設定します。
	 *
	 * aDayRのインスタンスは変更されません。
	 *
	 * @param row DayR
	 */
	public void setDayR(mcframe.clientFSBA.FSBAP0840.DayR row) {
		if (row != null) {
			MCRow.copyall(getDayR(), row);
		}
	}

	/**
	 * [Day]ブロックのコンテナaDayRを返します。
	 *
	 * @return DayR
	 */
	public mcframe.clientFSBA.FSBAP0840.DayR getDayR() {
		return aDayR;
	}

	/**
	 * aDayRを作成します。
	 *
	 * @return DayR
	 */
	public mcframe.clientFSBA.FSBAP0840.DayR createDayR() {
		return mcframe.clientFSBA.FSBAP0840.DayR.create();
	}

	/**
	 * 項目コピーによってaWeekRを設定します。
	 *
	 * aWeekRのインスタンスは変更されません。
	 *
	 * @param row WeekR
	 */
	public void setWeekR(mcframe.clientFSBA.FSBAP0840.WeekR row) {
		if (row != null) {
			MCRow.copyall(getWeekR(), row);
		}
	}

	/**
	 * [Week]ブロックのコンテナaWeekRを返します。
	 *
	 * @return WeekR
	 */
	public mcframe.clientFSBA.FSBAP0840.WeekR getWeekR() {
		return aWeekR;
	}

	/**
	 * aWeekRを作成します。
	 *
	 * @return WeekR
	 */
	public mcframe.clientFSBA.FSBAP0840.WeekR createWeekR() {
		return mcframe.clientFSBA.FSBAP0840.WeekR.create();
	}

	/**
	 * 項目コピーによってaWeekdayRを設定します。
	 *
	 * aWeekdayRのインスタンスは変更されません。
	 *
	 * @param row WeekdayR
	 */
	public void setWeekdayR(mcframe.clientFSBA.FSBAP0840.WeekdayR row) {
		if (row != null) {
			MCRow.copyall(getWeekdayR(), row);
		}
	}

	/**
	 * [Weekday]ブロックのコンテナaWeekdayRを返します。
	 *
	 * @return WeekdayR
	 */
	public mcframe.clientFSBA.FSBAP0840.WeekdayR getWeekdayR() {
		return aWeekdayR;
	}

	/**
	 * aWeekdayRを作成します。
	 *
	 * @return WeekdayR
	 */
	public mcframe.clientFSBA.FSBAP0840.WeekdayR createWeekdayR() {
		return mcframe.clientFSBA.FSBAP0840.WeekdayR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getBaseR())) ret.add(getBaseR());
		if(!MCCollectionUtil.contains(ret, getMonthR())) ret.add(getMonthR());
		if(!MCCollectionUtil.contains(ret, getTypeR())) ret.add(getTypeR());
		if(!MCCollectionUtil.contains(ret, getDayR())) ret.add(getDayR());
		if(!MCCollectionUtil.contains(ret, getWeekR())) ret.add(getWeekR());
		if(!MCCollectionUtil.contains(ret, getWeekdayR())) ret.add(getWeekdayR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getBaseR()) return "Base";
		if(aCnt == getMonthR()) return "Month";
		if(aCnt == getTypeR()) return "Type";
		if(aCnt == getDayR()) return "Day";
		if(aCnt == getWeekR()) return "Week";
		if(aCnt == getWeekdayR()) return "Weekday";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Base")) return getBaseR();
		if(bId.equals("Month")) return getMonthR();
		if(bId.equals("Type")) return getTypeR();
		if(bId.equals("Day")) return getDayR();
		if(bId.equals("Week")) return getWeekR();
		if(bId.equals("Weekday")) return getWeekdayR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(BasePanel);
		ret.add(PropPanel);
		ret.add(TimePanel);
		ret.add(MonthPanel);
		ret.add(TypePanel);
		ret.add(DayPanel);
		ret.add(DayOfWeekPanel);
		ret.add(WeekPanel);
		ret.add(WeekdayPanel);
		ret.add(CtrlPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningTaskSche_FW_A() {
		aBaseR = createBaseR();
		aMonthR = createMonthR();
		aTypeR = createTypeR();
		aDayR = createDayR();
		aWeekR = createWeekR();
		aWeekdayR = createWeekdayR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_MiningTaskSche_FW.jbCreateBase((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateProp((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateTime((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateMonth((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateType((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateDay((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateDayOfWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateWeekday((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbCreateCtrl((FSBAP_MiningTaskSche)this);
	}

	/**
	 * [Base]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBase(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Prop]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateProp(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Time]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTime(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Month]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMonth(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Type]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateType(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Day]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDay(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [DayOfWeek]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDayOfWeek(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Week]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateWeek(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Weekday]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateWeekday(FSBAP_MiningTaskSche p) {
	}

	/**
	 * [Ctrl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCtrl(FSBAP_MiningTaskSche p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningTaskSche create(){
		FSBAP_MiningTaskSche p = new FSBAP_MiningTaskSche();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_MiningTaskSche_FW.jbfInitBase((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitProp((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitTime((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitMonth((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitType((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitDay((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitDayOfWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitWeekday((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbfInitCtrl((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitBase((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitProp((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitTime((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitMonth((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitType((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitDay((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitDayOfWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitWeekday((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.jbInitCtrl((FSBAP_MiningTaskSche)this);
	}

	/**
	 * [Base]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBase(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.BasePanel = p.beansFactory.createPanel("Base");
		// ブロックの項目の初期化
		p.Base_desc_Label = p.beansFactory.createLabel("Base.desc_Label");
		p.Base_descScrollPane = p.beansFactory.createScrollPane("Base.descscroll");
		p.Base_desc = p.beansFactory.createTextArea("Base.desc");
		p.Base_desc.setLabel(p.Base_desc_Label);
		p.Base_inv_flg = p.beansFactory.createCheckBox("Base.inv_flg");
		p.Base_hour_Label = p.beansFactory.createLabel("Base.hour_Label");
		p.Base_hour = p.beansFactory.createNumberField("Base.hour");
		p.Base_hour.setLabel(p.Base_hour_Label);
		p.Base_minute_Label = p.beansFactory.createLabel("Base.minute_Label");
		p.Base_minute = p.beansFactory.createNumberField("Base.minute");
		p.Base_minute.setLabel(p.Base_minute_Label);
	}

	/**
	 * [Prop]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitProp(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.PropPanel = p.beansFactory.createPanel("Prop");
		// ブロックの項目の初期化
	}

	/**
	 * [Time]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTime(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.TimePanel = p.beansFactory.createPanel("Time");
		// ブロックの項目の初期化
	}

	/**
	 * [Month]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMonth(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.MonthPanel = p.beansFactory.createPanel("Month");
		p.MonthTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Month_month01 = p.beansFactory.createCheckBox("Month.month01");
		p.Month_month02 = p.beansFactory.createCheckBox("Month.month02");
		p.Month_month03 = p.beansFactory.createCheckBox("Month.month03");
		p.Month_month04 = p.beansFactory.createCheckBox("Month.month04");
		p.Month_month05 = p.beansFactory.createCheckBox("Month.month05");
		p.Month_month06 = p.beansFactory.createCheckBox("Month.month06");
		p.Month_month07 = p.beansFactory.createCheckBox("Month.month07");
		p.Month_month08 = p.beansFactory.createCheckBox("Month.month08");
		p.Month_month09 = p.beansFactory.createCheckBox("Month.month09");
		p.Month_month10 = p.beansFactory.createCheckBox("Month.month10");
		p.Month_month11 = p.beansFactory.createCheckBox("Month.month11");
		p.Month_month12 = p.beansFactory.createCheckBox("Month.month12");
	}

	/**
	 * [Type]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitType(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.TypePanel = p.beansFactory.createPanel("Type");
		// ブロックの項目の初期化
		p.Type_type_Group = p.beansFactory.createButtonGroup("Type.type");
		p.Type_type_day = p.beansFactory.createRadioButton("Type.type_day");
		p.Type_type_week = p.beansFactory.createRadioButton("Type.type_week");
	}

	/**
	 * [Day]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDay(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.DayPanel = p.beansFactory.createPanel("Day");
		p.DayTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Day_day01 = p.beansFactory.createCheckBox("Day.day01");
		p.Day_day02 = p.beansFactory.createCheckBox("Day.day02");
		p.Day_day03 = p.beansFactory.createCheckBox("Day.day03");
		p.Day_day04 = p.beansFactory.createCheckBox("Day.day04");
		p.Day_day05 = p.beansFactory.createCheckBox("Day.day05");
		p.Day_day06 = p.beansFactory.createCheckBox("Day.day06");
		p.Day_day07 = p.beansFactory.createCheckBox("Day.day07");
		p.Day_day08 = p.beansFactory.createCheckBox("Day.day08");
		p.Day_day09 = p.beansFactory.createCheckBox("Day.day09");
		p.Day_day10 = p.beansFactory.createCheckBox("Day.day10");
		p.Day_day11 = p.beansFactory.createCheckBox("Day.day11");
		p.Day_day12 = p.beansFactory.createCheckBox("Day.day12");
		p.Day_day13 = p.beansFactory.createCheckBox("Day.day13");
		p.Day_day14 = p.beansFactory.createCheckBox("Day.day14");
		p.Day_day15 = p.beansFactory.createCheckBox("Day.day15");
		p.Day_day16 = p.beansFactory.createCheckBox("Day.day16");
		p.Day_day17 = p.beansFactory.createCheckBox("Day.day17");
		p.Day_day18 = p.beansFactory.createCheckBox("Day.day18");
		p.Day_day19 = p.beansFactory.createCheckBox("Day.day19");
		p.Day_day20 = p.beansFactory.createCheckBox("Day.day20");
		p.Day_day21 = p.beansFactory.createCheckBox("Day.day21");
		p.Day_day22 = p.beansFactory.createCheckBox("Day.day22");
		p.Day_day23 = p.beansFactory.createCheckBox("Day.day23");
		p.Day_day24 = p.beansFactory.createCheckBox("Day.day24");
		p.Day_day25 = p.beansFactory.createCheckBox("Day.day25");
		p.Day_day26 = p.beansFactory.createCheckBox("Day.day26");
		p.Day_day27 = p.beansFactory.createCheckBox("Day.day27");
		p.Day_day28 = p.beansFactory.createCheckBox("Day.day28");
		p.Day_day29 = p.beansFactory.createCheckBox("Day.day29");
		p.Day_day30 = p.beansFactory.createCheckBox("Day.day30");
		p.Day_day31 = p.beansFactory.createCheckBox("Day.day31");
		p.Day_lastday = p.beansFactory.createCheckBox("Day.lastday");
	}

	/**
	 * [DayOfWeek]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDayOfWeek(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.DayOfWeekPanel = p.beansFactory.createPanel("DayOfWeek");
		p.DayOfWeekTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [Week]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitWeek(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.WeekPanel = p.beansFactory.createPanel("Week");
		// ブロックの項目の初期化
		p.Week_week01 = p.beansFactory.createCheckBox("Week.week01");
		p.Week_week02 = p.beansFactory.createCheckBox("Week.week02");
		p.Week_week03 = p.beansFactory.createCheckBox("Week.week03");
		p.Week_week04 = p.beansFactory.createCheckBox("Week.week04");
		p.Week_lastweek = p.beansFactory.createCheckBox("Week.lastweek");
	}

	/**
	 * [Weekday]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitWeekday(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.WeekdayPanel = p.beansFactory.createPanel("Weekday");
		// ブロックの項目の初期化
		p.Weekday_weekday01 = p.beansFactory.createCheckBox("Weekday.weekday01");
		p.Weekday_weekday02 = p.beansFactory.createCheckBox("Weekday.weekday02");
		p.Weekday_weekday03 = p.beansFactory.createCheckBox("Weekday.weekday03");
		p.Weekday_weekday04 = p.beansFactory.createCheckBox("Weekday.weekday04");
		p.Weekday_weekday05 = p.beansFactory.createCheckBox("Weekday.weekday05");
		p.Weekday_weekday06 = p.beansFactory.createCheckBox("Weekday.weekday06");
		p.Weekday_weekday07 = p.beansFactory.createCheckBox("Weekday.weekday07");
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCtrl(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.CtrlPanel = p.beansFactory.createPanel("Ctrl");
		// ブロックの項目の初期化
		p.Ctrl_upd = p.beansFactory.createButton("Ctrl.upd");
	}

	/**
	 * [Base]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBase(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.add(p.BasePanel);
		p.setLastBeans(p.BasePanel);
		p.BasePanel.setNextBeans(p.PropPanel);
		p.BasePanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.BasePanel.add(p.Base_desc_Label);
		p.Base_descScrollPane.getViewport().add(p.Base_desc);
		p.BasePanel.add(p.Base_descScrollPane);
		p.BasePanel.setLastBeans(p.Base_desc);
		p.Base_desc.setRow(p.getBaseR(), mcframe.clientFSBA.FSBAP0840.BaseR.desc_META);
		p.PropPanel.add(p.Base_inv_flg);
		p.PropPanel.setLastBeans(p.Base_inv_flg);
		p.Base_inv_flg.setRow(p.getBaseR(), mcframe.clientFSBA.FSBAP0840.BaseR.inv_flg_META);
		p.TimePanel.add(p.Base_hour_Label);
		p.TimePanel.add(p.Base_hour);
		p.TimePanel.setLastBeans(p.Base_hour);
		p.Base_hour.setNextBeans(p.Base_minute);
		p.Base_hour.setRow(p.getBaseR(), mcframe.clientFSBA.FSBAP0840.BaseR.hour_META);
		p.TimePanel.add(p.Base_minute_Label);
		p.TimePanel.add(p.Base_minute);
		p.Base_minute.setRow(p.getBaseR(), mcframe.clientFSBA.FSBAP0840.BaseR.minute_META);
	}

	/**
	 * [Prop]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitProp(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.add(p.PropPanel);
		p.PropPanel.setNextBeans(p.TimePanel);
		p.PropPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
	}

	/**
	 * [Time]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTime(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.add(p.TimePanel);
		p.TimePanel.setNextBeans(p.MonthPanel);
		p.TimePanel.setLayoutPosition("N");
		// ブロックの項目の初期化
	}

	/**
	 * [Month]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMonth(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.MonthPanel.setBorder(p.MonthTitledBorder);
		p.add(p.MonthPanel);
		p.MonthPanel.setNextBeans(p.TypePanel);
		p.MonthPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.MonthPanel.add(p.Month_month01);
		p.MonthPanel.setLastBeans(p.Month_month01);
		p.Month_month01.setNextBeans(p.Month_month02);
		p.Month_month01.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month01_META);
		p.MonthPanel.add(p.Month_month02);
		p.Month_month02.setNextBeans(p.Month_month03);
		p.Month_month02.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month02_META);
		p.MonthPanel.add(p.Month_month03);
		p.Month_month03.setNextBeans(p.Month_month04);
		p.Month_month03.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month03_META);
		p.MonthPanel.add(p.Month_month04);
		p.Month_month04.setNextBeans(p.Month_month05);
		p.Month_month04.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month04_META);
		p.MonthPanel.add(p.Month_month05);
		p.Month_month05.setNextBeans(p.Month_month06);
		p.Month_month05.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month05_META);
		p.MonthPanel.add(p.Month_month06);
		p.Month_month06.setNextBeans(p.Month_month07);
		p.Month_month06.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month06_META);
		p.MonthPanel.add(p.Month_month07);
		p.Month_month07.setNextBeans(p.Month_month08);
		p.Month_month07.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month07_META);
		p.MonthPanel.add(p.Month_month08);
		p.Month_month08.setNextBeans(p.Month_month09);
		p.Month_month08.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month08_META);
		p.MonthPanel.add(p.Month_month09);
		p.Month_month09.setNextBeans(p.Month_month10);
		p.Month_month09.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month09_META);
		p.MonthPanel.add(p.Month_month10);
		p.Month_month10.setNextBeans(p.Month_month11);
		p.Month_month10.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month10_META);
		p.MonthPanel.add(p.Month_month11);
		p.Month_month11.setNextBeans(p.Month_month12);
		p.Month_month11.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month11_META);
		p.MonthPanel.add(p.Month_month12);
		p.Month_month12.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0840.MonthR.month12_META);
	}

	/**
	 * [Type]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitType(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.add(p.TypePanel);
		p.TypePanel.setNextBeans(p.DayPanel);
		p.TypePanel.setValueCheck(false);
		p.TypePanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.TypePanel.setLastBeans(p.Type_type_Group);
		p.Type_type_Group.setFirstBeans(p.Type_type_day);
		p.Type_type_day.setActionCommand("0");
		p.Type_type_Group.add(p.Type_type_day);
		p.TypePanel.add(p.Type_type_day);
		p.Type_type_day.setNextBeans(p.Type_type_week);
		p.Type_type_week.setActionCommand("1");
		p.Type_type_Group.add(p.Type_type_week);
		p.TypePanel.add(p.Type_type_week);
		p.Type_type_Group.setRow(p.getTypeR(), mcframe.clientFSBA.FSBAP0840.TypeR.type_META);
	}

	/**
	 * [Day]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDay(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.DayPanel.setBorder(p.DayTitledBorder);
		p.add(p.DayPanel);
		p.DayPanel.setNextBeans(p.DayOfWeekPanel);
		p.DayPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.DayPanel.add(p.Day_day01);
		p.DayPanel.setLastBeans(p.Day_day01);
		p.Day_day01.setNextBeans(p.Day_day02);
		p.Day_day01.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day01_META);
		p.DayPanel.add(p.Day_day02);
		p.Day_day02.setNextBeans(p.Day_day03);
		p.Day_day02.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day02_META);
		p.DayPanel.add(p.Day_day03);
		p.Day_day03.setNextBeans(p.Day_day04);
		p.Day_day03.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day03_META);
		p.DayPanel.add(p.Day_day04);
		p.Day_day04.setNextBeans(p.Day_day05);
		p.Day_day04.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day04_META);
		p.DayPanel.add(p.Day_day05);
		p.Day_day05.setNextBeans(p.Day_day06);
		p.Day_day05.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day05_META);
		p.DayPanel.add(p.Day_day06);
		p.Day_day06.setNextBeans(p.Day_day07);
		p.Day_day06.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day06_META);
		p.DayPanel.add(p.Day_day07);
		p.Day_day07.setNextBeans(p.Day_day08);
		p.Day_day07.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day07_META);
		p.DayPanel.add(p.Day_day08);
		p.Day_day08.setNextBeans(p.Day_day09);
		p.Day_day08.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day08_META);
		p.DayPanel.add(p.Day_day09);
		p.Day_day09.setNextBeans(p.Day_day10);
		p.Day_day09.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day09_META);
		p.DayPanel.add(p.Day_day10);
		p.Day_day10.setNextBeans(p.Day_day11);
		p.Day_day10.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day10_META);
		p.DayPanel.add(p.Day_day11);
		p.Day_day11.setNextBeans(p.Day_day12);
		p.Day_day11.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day11_META);
		p.DayPanel.add(p.Day_day12);
		p.Day_day12.setNextBeans(p.Day_day13);
		p.Day_day12.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day12_META);
		p.DayPanel.add(p.Day_day13);
		p.Day_day13.setNextBeans(p.Day_day14);
		p.Day_day13.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day13_META);
		p.DayPanel.add(p.Day_day14);
		p.Day_day14.setNextBeans(p.Day_day15);
		p.Day_day14.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day14_META);
		p.DayPanel.add(p.Day_day15);
		p.Day_day15.setNextBeans(p.Day_day16);
		p.Day_day15.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day15_META);
		p.DayPanel.add(p.Day_day16);
		p.Day_day16.setNextBeans(p.Day_day17);
		p.Day_day16.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day16_META);
		p.DayPanel.add(p.Day_day17);
		p.Day_day17.setNextBeans(p.Day_day18);
		p.Day_day17.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day17_META);
		p.DayPanel.add(p.Day_day18);
		p.Day_day18.setNextBeans(p.Day_day19);
		p.Day_day18.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day18_META);
		p.DayPanel.add(p.Day_day19);
		p.Day_day19.setNextBeans(p.Day_day20);
		p.Day_day19.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day19_META);
		p.DayPanel.add(p.Day_day20);
		p.Day_day20.setNextBeans(p.Day_day21);
		p.Day_day20.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day20_META);
		p.DayPanel.add(p.Day_day21);
		p.Day_day21.setNextBeans(p.Day_day22);
		p.Day_day21.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day21_META);
		p.DayPanel.add(p.Day_day22);
		p.Day_day22.setNextBeans(p.Day_day23);
		p.Day_day22.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day22_META);
		p.DayPanel.add(p.Day_day23);
		p.Day_day23.setNextBeans(p.Day_day24);
		p.Day_day23.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day23_META);
		p.DayPanel.add(p.Day_day24);
		p.Day_day24.setNextBeans(p.Day_day25);
		p.Day_day24.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day24_META);
		p.DayPanel.add(p.Day_day25);
		p.Day_day25.setNextBeans(p.Day_day26);
		p.Day_day25.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day25_META);
		p.DayPanel.add(p.Day_day26);
		p.Day_day26.setNextBeans(p.Day_day27);
		p.Day_day26.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day26_META);
		p.DayPanel.add(p.Day_day27);
		p.Day_day27.setNextBeans(p.Day_day28);
		p.Day_day27.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day27_META);
		p.DayPanel.add(p.Day_day28);
		p.Day_day28.setNextBeans(p.Day_day29);
		p.Day_day28.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day28_META);
		p.DayPanel.add(p.Day_day29);
		p.Day_day29.setNextBeans(p.Day_day30);
		p.Day_day29.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day29_META);
		p.DayPanel.add(p.Day_day30);
		p.Day_day30.setNextBeans(p.Day_day31);
		p.Day_day30.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day30_META);
		p.DayPanel.add(p.Day_day31);
		p.Day_day31.setNextBeans(p.Day_lastday);
		p.Day_day31.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.day31_META);
		p.DayPanel.add(p.Day_lastday);
		p.Day_lastday.setRow(p.getDayR(), mcframe.clientFSBA.FSBAP0840.DayR.lastday_META);
	}

	/**
	 * [DayOfWeek]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDayOfWeek(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.DayOfWeekPanel.setBorder(p.DayOfWeekTitledBorder);
		p.add(p.DayOfWeekPanel);
		p.DayOfWeekPanel.setNextBeans(p.CtrlPanel);
		p.DayOfWeekPanel.setLayoutPosition("N+");
		// ブロックの項目の初期化
		p.DayOfWeekPanel.add(p.WeekPanel, null);
		p.DayOfWeekPanel.setLastBeans(p.WeekPanel);
		p.WeekPanel.setNextBeans(p.WeekdayPanel);
		p.DayOfWeekPanel.add(p.WeekdayPanel, null);
	}

	/**
	 * [Week]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitWeek(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.WeekPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.WeekPanel.add(p.Week_week01);
		p.WeekPanel.setLastBeans(p.Week_week01);
		p.Week_week01.setNextBeans(p.Week_week02);
		p.Week_week01.setRow(p.getWeekR(), mcframe.clientFSBA.FSBAP0840.WeekR.week01_META);
		p.WeekPanel.add(p.Week_week02);
		p.Week_week02.setNextBeans(p.Week_week03);
		p.Week_week02.setRow(p.getWeekR(), mcframe.clientFSBA.FSBAP0840.WeekR.week02_META);
		p.WeekPanel.add(p.Week_week03);
		p.Week_week03.setNextBeans(p.Week_week04);
		p.Week_week03.setRow(p.getWeekR(), mcframe.clientFSBA.FSBAP0840.WeekR.week03_META);
		p.WeekPanel.add(p.Week_week04);
		p.Week_week04.setNextBeans(p.Week_lastweek);
		p.Week_week04.setRow(p.getWeekR(), mcframe.clientFSBA.FSBAP0840.WeekR.week04_META);
		p.WeekPanel.add(p.Week_lastweek);
		p.Week_lastweek.setRow(p.getWeekR(), mcframe.clientFSBA.FSBAP0840.WeekR.lastweek_META);
	}

	/**
	 * [Weekday]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitWeekday(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.WeekdayPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.WeekdayPanel.add(p.Weekday_weekday01);
		p.WeekdayPanel.setLastBeans(p.Weekday_weekday01);
		p.Weekday_weekday01.setNextBeans(p.Weekday_weekday02);
		p.Weekday_weekday01.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday01_META);
		p.WeekdayPanel.add(p.Weekday_weekday02);
		p.Weekday_weekday02.setNextBeans(p.Weekday_weekday03);
		p.Weekday_weekday02.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday02_META);
		p.WeekdayPanel.add(p.Weekday_weekday03);
		p.Weekday_weekday03.setNextBeans(p.Weekday_weekday04);
		p.Weekday_weekday03.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday03_META);
		p.WeekdayPanel.add(p.Weekday_weekday04);
		p.Weekday_weekday04.setNextBeans(p.Weekday_weekday05);
		p.Weekday_weekday04.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday04_META);
		p.WeekdayPanel.add(p.Weekday_weekday05);
		p.Weekday_weekday05.setNextBeans(p.Weekday_weekday06);
		p.Weekday_weekday05.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday05_META);
		p.WeekdayPanel.add(p.Weekday_weekday06);
		p.Weekday_weekday06.setNextBeans(p.Weekday_weekday07);
		p.Weekday_weekday06.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday06_META);
		p.WeekdayPanel.add(p.Weekday_weekday07);
		p.Weekday_weekday07.setRow(p.getWeekdayR(), mcframe.clientFSBA.FSBAP0840.WeekdayR.weekday07_META);
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCtrl(FSBAP_MiningTaskSche p) {
		// ブロック関連の初期化
		p.add(p.CtrlPanel);
		p.CtrlPanel.setValueCheck(false);
		p.CtrlPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Ctrl_upd.setFunctionKey(MCFunctionKey.F9);
		p.CtrlPanel.add(p.Ctrl_upd);
		p.CtrlPanel.setLastBeans(p.Ctrl_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_MiningTaskSche_FW.mcInitBase((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitProp((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitTime((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitMonth((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitType((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitDay((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitDayOfWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitWeekday((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.mcInitCtrl((FSBAP_MiningTaskSche)this);

		// [DAY]ステータスのモードの設定
		FSBAP_MiningTaskSche_FW.statusInitDAY_Base((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Prop((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Time((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Month((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Type((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Day((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_DayOfWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Week((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Weekday((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitDAY_Ctrl((FSBAP_MiningTaskSche)this);

		// [WEEKDAY]ステータスのモードの設定
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Base((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Prop((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Time((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Month((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Type((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Day((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_DayOfWeek((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Week((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Weekday((FSBAP_MiningTaskSche)this);
		FSBAP_MiningTaskSche_FW.statusInitWEEKDAY_Ctrl((FSBAP_MiningTaskSche)this);

	}

	/**
	 *  [Base]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBase(FSBAP_MiningTaskSche p) {
		p.Base_desc.addAllListener(p);
		p.Base_inv_flg.addAllListener(p);
		p.Base_hour.setListListener(p);
		p.Base_hour.addAllListener(p);
		p.Base_minute.setListListener(p);
		p.Base_minute.addAllListener(p);
	}

	/**
	 *  [Prop]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitProp(FSBAP_MiningTaskSche p) {
	}

	/**
	 *  [Time]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTime(FSBAP_MiningTaskSche p) {
	}

	/**
	 *  [Month]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMonth(FSBAP_MiningTaskSche p) {
		p.Month_month01.addAllListener(p);
		p.Month_month02.addAllListener(p);
		p.Month_month03.addAllListener(p);
		p.Month_month04.addAllListener(p);
		p.Month_month05.addAllListener(p);
		p.Month_month06.addAllListener(p);
		p.Month_month07.addAllListener(p);
		p.Month_month08.addAllListener(p);
		p.Month_month09.addAllListener(p);
		p.Month_month10.addAllListener(p);
		p.Month_month11.addAllListener(p);
		p.Month_month12.addAllListener(p);
	}

	/**
	 *  [Type]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitType(FSBAP_MiningTaskSche p) {
		p.Type_type_Group.addAllListener(p);
		p.Type_type_day.addAllListener(p);
		p.Type_type_week.addAllListener(p);
	}

	/**
	 *  [Day]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDay(FSBAP_MiningTaskSche p) {
		p.Day_day01.addAllListener(p);
		p.Day_day02.addAllListener(p);
		p.Day_day03.addAllListener(p);
		p.Day_day04.addAllListener(p);
		p.Day_day05.addAllListener(p);
		p.Day_day06.addAllListener(p);
		p.Day_day07.addAllListener(p);
		p.Day_day08.addAllListener(p);
		p.Day_day09.addAllListener(p);
		p.Day_day10.addAllListener(p);
		p.Day_day11.addAllListener(p);
		p.Day_day12.addAllListener(p);
		p.Day_day13.addAllListener(p);
		p.Day_day14.addAllListener(p);
		p.Day_day15.addAllListener(p);
		p.Day_day16.addAllListener(p);
		p.Day_day17.addAllListener(p);
		p.Day_day18.addAllListener(p);
		p.Day_day19.addAllListener(p);
		p.Day_day20.addAllListener(p);
		p.Day_day21.addAllListener(p);
		p.Day_day22.addAllListener(p);
		p.Day_day23.addAllListener(p);
		p.Day_day24.addAllListener(p);
		p.Day_day25.addAllListener(p);
		p.Day_day26.addAllListener(p);
		p.Day_day27.addAllListener(p);
		p.Day_day28.addAllListener(p);
		p.Day_day29.addAllListener(p);
		p.Day_day30.addAllListener(p);
		p.Day_day31.addAllListener(p);
		p.Day_lastday.addAllListener(p);
	}

	/**
	 *  [DayOfWeek]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDayOfWeek(FSBAP_MiningTaskSche p) {
	}

	/**
	 *  [Week]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitWeek(FSBAP_MiningTaskSche p) {
		p.Week_week01.addAllListener(p);
		p.Week_week02.addAllListener(p);
		p.Week_week03.addAllListener(p);
		p.Week_week04.addAllListener(p);
		p.Week_lastweek.addAllListener(p);
	}

	/**
	 *  [Weekday]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitWeekday(FSBAP_MiningTaskSche p) {
		p.Weekday_weekday01.addAllListener(p);
		p.Weekday_weekday02.addAllListener(p);
		p.Weekday_weekday03.addAllListener(p);
		p.Weekday_weekday04.addAllListener(p);
		p.Weekday_weekday05.addAllListener(p);
		p.Weekday_weekday06.addAllListener(p);
		p.Weekday_weekday07.addAllListener(p);
	}

	/**
	 *  [Ctrl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCtrl(FSBAP_MiningTaskSche p) {
		p.Ctrl_upd.addAllListener(p);
		p.Ctrl_upd.setAPMethodName("doCtrl_upd");
	}

	/**
	 * [DAY]ステータスの[Base]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Base(FSBAP_MiningTaskSche p){
		p.Base_desc.putMode(p, DAY, MCMode.REQUIRED);
		p.Base_inv_flg.putMode(p, DAY, MCMode.REQUIRED);
		p.Base_hour.putMode(p, DAY, MCMode.REQUIRED);
		p.Base_minute.putMode(p, DAY, MCMode.REQUIRED);

	}

	/**
	 * [DAY]ステータスの[Prop]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Prop(FSBAP_MiningTaskSche p){

	}

	/**
	 * [DAY]ステータスの[Time]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Time(FSBAP_MiningTaskSche p){

	}

	/**
	 * [DAY]ステータスの[Month]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Month(FSBAP_MiningTaskSche p){
		p.Month_month01.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month02.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month03.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month04.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month05.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month06.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month07.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month08.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month09.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month10.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month11.putMode(p, DAY, MCMode.ENABLE);
		p.Month_month12.putMode(p, DAY, MCMode.ENABLE);

	}

	/**
	 * [DAY]ステータスの[Type]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Type(FSBAP_MiningTaskSche p){
		p.Type_type_Group.putMode(p, DAY, MCMode.ENABLE);

	}

	/**
	 * [DAY]ステータスの[Day]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Day(FSBAP_MiningTaskSche p){
		p.Day_day01.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day02.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day03.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day04.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day05.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day06.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day07.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day08.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day09.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day10.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day11.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day12.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day13.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day14.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day15.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day16.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day17.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day18.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day19.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day20.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day21.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day22.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day23.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day24.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day25.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day26.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day27.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day28.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day29.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day30.putMode(p, DAY, MCMode.ENABLE);
		p.Day_day31.putMode(p, DAY, MCMode.ENABLE);
		p.Day_lastday.putMode(p, DAY, MCMode.ENABLE);

	}

	/**
	 * [DAY]ステータスの[DayOfWeek]ブロックのモードの設定
	 */
	protected static void statusInitDAY_DayOfWeek(FSBAP_MiningTaskSche p){

	}

	/**
	 * [DAY]ステータスの[Week]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Week(FSBAP_MiningTaskSche p){
		p.Week_week01.putMode(p, DAY, MCMode.DISABLE);
		p.Week_week02.putMode(p, DAY, MCMode.DISABLE);
		p.Week_week03.putMode(p, DAY, MCMode.DISABLE);
		p.Week_week04.putMode(p, DAY, MCMode.DISABLE);
		p.Week_lastweek.putMode(p, DAY, MCMode.DISABLE);

	}

	/**
	 * [DAY]ステータスの[Weekday]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Weekday(FSBAP_MiningTaskSche p){
		p.Weekday_weekday01.putMode(p, DAY, MCMode.DISABLE);
		p.Weekday_weekday02.putMode(p, DAY, MCMode.DISABLE);
		p.Weekday_weekday03.putMode(p, DAY, MCMode.DISABLE);
		p.Weekday_weekday04.putMode(p, DAY, MCMode.DISABLE);
		p.Weekday_weekday05.putMode(p, DAY, MCMode.DISABLE);
		p.Weekday_weekday06.putMode(p, DAY, MCMode.DISABLE);
		p.Weekday_weekday07.putMode(p, DAY, MCMode.DISABLE);

	}

	/**
	 * [DAY]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitDAY_Ctrl(FSBAP_MiningTaskSche p){
		p.Ctrl_upd.putMode(p, DAY, MCMode.ENABLE);

	}

	/**
	 * [WEEKDAY]ステータスの[Base]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Base(FSBAP_MiningTaskSche p){
		p.Base_desc.putMode(p, WEEKDAY, MCMode.REQUIRED);
		p.Base_inv_flg.putMode(p, WEEKDAY, MCMode.REQUIRED);
		p.Base_hour.putMode(p, WEEKDAY, MCMode.REQUIRED);
		p.Base_minute.putMode(p, WEEKDAY, MCMode.REQUIRED);

	}

	/**
	 * [WEEKDAY]ステータスの[Prop]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Prop(FSBAP_MiningTaskSche p){

	}

	/**
	 * [WEEKDAY]ステータスの[Time]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Time(FSBAP_MiningTaskSche p){

	}

	/**
	 * [WEEKDAY]ステータスの[Month]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Month(FSBAP_MiningTaskSche p){
		p.Month_month01.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month02.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month03.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month04.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month05.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month06.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month07.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month08.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month09.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month10.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month11.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Month_month12.putMode(p, WEEKDAY, MCMode.ENABLE);

	}

	/**
	 * [WEEKDAY]ステータスの[Type]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Type(FSBAP_MiningTaskSche p){
		p.Type_type_Group.putMode(p, WEEKDAY, MCMode.ENABLE);

	}

	/**
	 * [WEEKDAY]ステータスの[Day]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Day(FSBAP_MiningTaskSche p){
		p.Day_day01.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day02.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day03.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day04.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day05.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day06.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day07.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day08.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day09.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day10.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day11.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day12.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day13.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day14.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day15.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day16.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day17.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day18.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day19.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day20.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day21.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day22.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day23.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day24.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day25.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day26.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day27.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day28.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day29.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day30.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_day31.putMode(p, WEEKDAY, MCMode.DISABLE);
		p.Day_lastday.putMode(p, WEEKDAY, MCMode.DISABLE);

	}

	/**
	 * [WEEKDAY]ステータスの[DayOfWeek]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_DayOfWeek(FSBAP_MiningTaskSche p){

	}

	/**
	 * [WEEKDAY]ステータスの[Week]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Week(FSBAP_MiningTaskSche p){
		p.Week_week01.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Week_week02.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Week_week03.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Week_week04.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Week_lastweek.putMode(p, WEEKDAY, MCMode.ENABLE);

	}

	/**
	 * [WEEKDAY]ステータスの[Weekday]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Weekday(FSBAP_MiningTaskSche p){
		p.Weekday_weekday01.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Weekday_weekday02.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Weekday_weekday03.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Weekday_weekday04.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Weekday_weekday05.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Weekday_weekday06.putMode(p, WEEKDAY, MCMode.ENABLE);
		p.Weekday_weekday07.putMode(p, WEEKDAY, MCMode.ENABLE);

	}

	/**
	 * [WEEKDAY]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitWEEKDAY_Ctrl(FSBAP_MiningTaskSche p){
		p.Ctrl_upd.putMode(p, WEEKDAY, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return DAY;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[DAY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDAYStatus() {
		status = DAY;
		setAllStatus(status);
	}

	/**
	 * この画面を[WEEKDAY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setWEEKDAYStatus() {
		status = WEEKDAY;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (DAY.equals(status)) {
			setDAYStatus();
		}
		else if (WEEKDAY.equals(status)) {
			setWEEKDAYStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Ctrl_upd) doCtrl_upd(info);
	}

	/**
	 * [Ctrl]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCtrl_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Base_desc) return doBase_desc_VC(info);
		if (vc == Base_inv_flg) return doBase_inv_flg_VC(info);
		if (vc == Base_hour) return doBase_hour_VC(info);
		if (vc == Base_minute) return doBase_minute_VC(info);
		if (vc == Month_month01) return doMonth_month01_VC(info);
		if (vc == Month_month02) return doMonth_month02_VC(info);
		if (vc == Month_month03) return doMonth_month03_VC(info);
		if (vc == Month_month04) return doMonth_month04_VC(info);
		if (vc == Month_month05) return doMonth_month05_VC(info);
		if (vc == Month_month06) return doMonth_month06_VC(info);
		if (vc == Month_month07) return doMonth_month07_VC(info);
		if (vc == Month_month08) return doMonth_month08_VC(info);
		if (vc == Month_month09) return doMonth_month09_VC(info);
		if (vc == Month_month10) return doMonth_month10_VC(info);
		if (vc == Month_month11) return doMonth_month11_VC(info);
		if (vc == Month_month12) return doMonth_month12_VC(info);
		if (vc == Type_type_Group) return doType_type_VC(info);
		if (vc == Day_day01) return doDay_day01_VC(info);
		if (vc == Day_day02) return doDay_day02_VC(info);
		if (vc == Day_day03) return doDay_day03_VC(info);
		if (vc == Day_day04) return doDay_day04_VC(info);
		if (vc == Day_day05) return doDay_day05_VC(info);
		if (vc == Day_day06) return doDay_day06_VC(info);
		if (vc == Day_day07) return doDay_day07_VC(info);
		if (vc == Day_day08) return doDay_day08_VC(info);
		if (vc == Day_day09) return doDay_day09_VC(info);
		if (vc == Day_day10) return doDay_day10_VC(info);
		if (vc == Day_day11) return doDay_day11_VC(info);
		if (vc == Day_day12) return doDay_day12_VC(info);
		if (vc == Day_day13) return doDay_day13_VC(info);
		if (vc == Day_day14) return doDay_day14_VC(info);
		if (vc == Day_day15) return doDay_day15_VC(info);
		if (vc == Day_day16) return doDay_day16_VC(info);
		if (vc == Day_day17) return doDay_day17_VC(info);
		if (vc == Day_day18) return doDay_day18_VC(info);
		if (vc == Day_day19) return doDay_day19_VC(info);
		if (vc == Day_day20) return doDay_day20_VC(info);
		if (vc == Day_day21) return doDay_day21_VC(info);
		if (vc == Day_day22) return doDay_day22_VC(info);
		if (vc == Day_day23) return doDay_day23_VC(info);
		if (vc == Day_day24) return doDay_day24_VC(info);
		if (vc == Day_day25) return doDay_day25_VC(info);
		if (vc == Day_day26) return doDay_day26_VC(info);
		if (vc == Day_day27) return doDay_day27_VC(info);
		if (vc == Day_day28) return doDay_day28_VC(info);
		if (vc == Day_day29) return doDay_day29_VC(info);
		if (vc == Day_day30) return doDay_day30_VC(info);
		if (vc == Day_day31) return doDay_day31_VC(info);
		if (vc == Day_lastday) return doDay_lastday_VC(info);
		if (vc == Week_week01) return doWeek_week01_VC(info);
		if (vc == Week_week02) return doWeek_week02_VC(info);
		if (vc == Week_week03) return doWeek_week03_VC(info);
		if (vc == Week_week04) return doWeek_week04_VC(info);
		if (vc == Week_lastweek) return doWeek_lastweek_VC(info);
		if (vc == Weekday_weekday01) return doWeekday_weekday01_VC(info);
		if (vc == Weekday_weekday02) return doWeekday_weekday02_VC(info);
		if (vc == Weekday_weekday03) return doWeekday_weekday03_VC(info);
		if (vc == Weekday_weekday04) return doWeekday_weekday04_VC(info);
		if (vc == Weekday_weekday05) return doWeekday_weekday05_VC(info);
		if (vc == Weekday_weekday06) return doWeekday_weekday06_VC(info);
		if (vc == Weekday_weekday07) return doWeekday_weekday07_VC(info);
		return true;
	}

	/**
	 * [Base]パネルの[desc]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBase_desc_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Base]パネルの[inv_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBase_inv_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Base]パネルの[hour]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBase_hour_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Base]パネルの[minute]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBase_minute_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month01]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month01_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month02]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month02_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month03]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month03_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month04]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month04_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month05]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month05_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month06]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month06_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month07]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month07_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month08]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month08_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month09]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month09_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month10]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month10_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month11]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month11_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Month]パネルの[month12]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_month12_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Type]パネルの[type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doType_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day01]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day01_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day02]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day02_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day03]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day03_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day04]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day04_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day05]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day05_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day06]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day06_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day07]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day07_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day08]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day08_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day09]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day09_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day10]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day10_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day11]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day11_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day12]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day12_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day13]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day13_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day14]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day14_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day15]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day15_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day16]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day16_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day17]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day17_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day18]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day18_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day19]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day19_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day20]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day20_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day21]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day21_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day22]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day22_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day23]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day23_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day24]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day24_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day25]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day25_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day26]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day26_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day27]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day27_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day28]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day28_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day29]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day29_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day30]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day30_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[day31]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_day31_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Day]パネルの[lastday]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDay_lastday_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Week]パネルの[week01]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeek_week01_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Week]パネルの[week02]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeek_week02_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Week]パネルの[week03]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeek_week03_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Week]パネルの[week04]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeek_week04_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Week]パネルの[lastweek]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeek_lastweek_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday01]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday01_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday02]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday02_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday03]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday03_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday04]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday04_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday05]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday05_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday06]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday06_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Weekday]パネルの[weekday07]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doWeekday_weekday07_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Base_desc) doBase_desc_NC(info);
		else if (nc == Base_inv_flg) doBase_inv_flg_NC(info);
		else if (nc == Base_hour) doBase_hour_NC(info);
		else if (nc == Base_minute) doBase_minute_NC(info);
		else if (nc == Month_month01) doMonth_month01_NC(info);
		else if (nc == Month_month02) doMonth_month02_NC(info);
		else if (nc == Month_month03) doMonth_month03_NC(info);
		else if (nc == Month_month04) doMonth_month04_NC(info);
		else if (nc == Month_month05) doMonth_month05_NC(info);
		else if (nc == Month_month06) doMonth_month06_NC(info);
		else if (nc == Month_month07) doMonth_month07_NC(info);
		else if (nc == Month_month08) doMonth_month08_NC(info);
		else if (nc == Month_month09) doMonth_month09_NC(info);
		else if (nc == Month_month10) doMonth_month10_NC(info);
		else if (nc == Month_month11) doMonth_month11_NC(info);
		else if (nc == Month_month12) doMonth_month12_NC(info);
		else if (nc == Type_type_Group) doType_type_NC(info);
		else if (nc == Day_day01) doDay_day01_NC(info);
		else if (nc == Day_day02) doDay_day02_NC(info);
		else if (nc == Day_day03) doDay_day03_NC(info);
		else if (nc == Day_day04) doDay_day04_NC(info);
		else if (nc == Day_day05) doDay_day05_NC(info);
		else if (nc == Day_day06) doDay_day06_NC(info);
		else if (nc == Day_day07) doDay_day07_NC(info);
		else if (nc == Day_day08) doDay_day08_NC(info);
		else if (nc == Day_day09) doDay_day09_NC(info);
		else if (nc == Day_day10) doDay_day10_NC(info);
		else if (nc == Day_day11) doDay_day11_NC(info);
		else if (nc == Day_day12) doDay_day12_NC(info);
		else if (nc == Day_day13) doDay_day13_NC(info);
		else if (nc == Day_day14) doDay_day14_NC(info);
		else if (nc == Day_day15) doDay_day15_NC(info);
		else if (nc == Day_day16) doDay_day16_NC(info);
		else if (nc == Day_day17) doDay_day17_NC(info);
		else if (nc == Day_day18) doDay_day18_NC(info);
		else if (nc == Day_day19) doDay_day19_NC(info);
		else if (nc == Day_day20) doDay_day20_NC(info);
		else if (nc == Day_day21) doDay_day21_NC(info);
		else if (nc == Day_day22) doDay_day22_NC(info);
		else if (nc == Day_day23) doDay_day23_NC(info);
		else if (nc == Day_day24) doDay_day24_NC(info);
		else if (nc == Day_day25) doDay_day25_NC(info);
		else if (nc == Day_day26) doDay_day26_NC(info);
		else if (nc == Day_day27) doDay_day27_NC(info);
		else if (nc == Day_day28) doDay_day28_NC(info);
		else if (nc == Day_day29) doDay_day29_NC(info);
		else if (nc == Day_day30) doDay_day30_NC(info);
		else if (nc == Day_day31) doDay_day31_NC(info);
		else if (nc == Day_lastday) doDay_lastday_NC(info);
		else if (nc == Week_week01) doWeek_week01_NC(info);
		else if (nc == Week_week02) doWeek_week02_NC(info);
		else if (nc == Week_week03) doWeek_week03_NC(info);
		else if (nc == Week_week04) doWeek_week04_NC(info);
		else if (nc == Week_lastweek) doWeek_lastweek_NC(info);
		else if (nc == Weekday_weekday01) doWeekday_weekday01_NC(info);
		else if (nc == Weekday_weekday02) doWeekday_weekday02_NC(info);
		else if (nc == Weekday_weekday03) doWeekday_weekday03_NC(info);
		else if (nc == Weekday_weekday04) doWeekday_weekday04_NC(info);
		else if (nc == Weekday_weekday05) doWeekday_weekday05_NC(info);
		else if (nc == Weekday_weekday06) doWeekday_weekday06_NC(info);
		else if (nc == Weekday_weekday07) doWeekday_weekday07_NC(info);
	}

	/**
	 * [Base]パネルの[desc]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_desc_NC(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[inv_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_inv_flg_NC(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[hour]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_hour_NC(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[minute]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_minute_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month01]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month01_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month02]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month02_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month03]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month03_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month04]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month04_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month05]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month05_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month06]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month06_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month07]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month07_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month08]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month08_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month09]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month09_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month10]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month10_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month11]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month11_NC(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month12]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month12_NC(MCEventInfo info){
	}

	/**
	 * [Type]パネルの[type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doType_type_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day01]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day01_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day02]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day02_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day03]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day03_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day04]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day04_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day05]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day05_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day06]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day06_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day07]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day07_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day08]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day08_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day09]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day09_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day10]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day10_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day11]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day11_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day12]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day12_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day13]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day13_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day14]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day14_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day15]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day15_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day16]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day16_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day17]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day17_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day18]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day18_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day19]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day19_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day20]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day20_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day21]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day21_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day22]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day22_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day23]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day23_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day24]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day24_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day25]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day25_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day26]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day26_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day27]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day27_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day28]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day28_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day29]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day29_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day30]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day30_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day31]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day31_NC(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[lastday]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_lastday_NC(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week01]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week01_NC(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week02]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week02_NC(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week03]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week03_NC(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week04]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week04_NC(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[lastweek]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_lastweek_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday01]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday01_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday02]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday02_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday03]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday03_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday04]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday04_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday05]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday05_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday06]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday06_NC(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday07]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday07_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Base_desc) doBase_desc_NE(info);
		else if (ne == Base_inv_flg) doBase_inv_flg_NE(info);
		else if (ne == Base_hour) doBase_hour_NE(info);
		else if (ne == Base_minute) doBase_minute_NE(info);
		else if (ne == Month_month01) doMonth_month01_NE(info);
		else if (ne == Month_month02) doMonth_month02_NE(info);
		else if (ne == Month_month03) doMonth_month03_NE(info);
		else if (ne == Month_month04) doMonth_month04_NE(info);
		else if (ne == Month_month05) doMonth_month05_NE(info);
		else if (ne == Month_month06) doMonth_month06_NE(info);
		else if (ne == Month_month07) doMonth_month07_NE(info);
		else if (ne == Month_month08) doMonth_month08_NE(info);
		else if (ne == Month_month09) doMonth_month09_NE(info);
		else if (ne == Month_month10) doMonth_month10_NE(info);
		else if (ne == Month_month11) doMonth_month11_NE(info);
		else if (ne == Month_month12) doMonth_month12_NE(info);
		else if (ne == Type_type_Group) doType_type_NE(info);
		else if (ne == Day_day01) doDay_day01_NE(info);
		else if (ne == Day_day02) doDay_day02_NE(info);
		else if (ne == Day_day03) doDay_day03_NE(info);
		else if (ne == Day_day04) doDay_day04_NE(info);
		else if (ne == Day_day05) doDay_day05_NE(info);
		else if (ne == Day_day06) doDay_day06_NE(info);
		else if (ne == Day_day07) doDay_day07_NE(info);
		else if (ne == Day_day08) doDay_day08_NE(info);
		else if (ne == Day_day09) doDay_day09_NE(info);
		else if (ne == Day_day10) doDay_day10_NE(info);
		else if (ne == Day_day11) doDay_day11_NE(info);
		else if (ne == Day_day12) doDay_day12_NE(info);
		else if (ne == Day_day13) doDay_day13_NE(info);
		else if (ne == Day_day14) doDay_day14_NE(info);
		else if (ne == Day_day15) doDay_day15_NE(info);
		else if (ne == Day_day16) doDay_day16_NE(info);
		else if (ne == Day_day17) doDay_day17_NE(info);
		else if (ne == Day_day18) doDay_day18_NE(info);
		else if (ne == Day_day19) doDay_day19_NE(info);
		else if (ne == Day_day20) doDay_day20_NE(info);
		else if (ne == Day_day21) doDay_day21_NE(info);
		else if (ne == Day_day22) doDay_day22_NE(info);
		else if (ne == Day_day23) doDay_day23_NE(info);
		else if (ne == Day_day24) doDay_day24_NE(info);
		else if (ne == Day_day25) doDay_day25_NE(info);
		else if (ne == Day_day26) doDay_day26_NE(info);
		else if (ne == Day_day27) doDay_day27_NE(info);
		else if (ne == Day_day28) doDay_day28_NE(info);
		else if (ne == Day_day29) doDay_day29_NE(info);
		else if (ne == Day_day30) doDay_day30_NE(info);
		else if (ne == Day_day31) doDay_day31_NE(info);
		else if (ne == Day_lastday) doDay_lastday_NE(info);
		else if (ne == Week_week01) doWeek_week01_NE(info);
		else if (ne == Week_week02) doWeek_week02_NE(info);
		else if (ne == Week_week03) doWeek_week03_NE(info);
		else if (ne == Week_week04) doWeek_week04_NE(info);
		else if (ne == Week_lastweek) doWeek_lastweek_NE(info);
		else if (ne == Weekday_weekday01) doWeekday_weekday01_NE(info);
		else if (ne == Weekday_weekday02) doWeekday_weekday02_NE(info);
		else if (ne == Weekday_weekday03) doWeekday_weekday03_NE(info);
		else if (ne == Weekday_weekday04) doWeekday_weekday04_NE(info);
		else if (ne == Weekday_weekday05) doWeekday_weekday05_NE(info);
		else if (ne == Weekday_weekday06) doWeekday_weekday06_NE(info);
		else if (ne == Weekday_weekday07) doWeekday_weekday07_NE(info);
	}

	/**
	 * [Base]パネルの[desc]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_desc_NE(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[inv_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_inv_flg_NE(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[hour]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_hour_NE(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[minute]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_minute_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month01]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month01_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month02]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month02_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month03]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month03_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month04]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month04_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month05]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month05_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month06]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month06_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month07]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month07_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month08]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month08_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month09]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month09_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month10]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month10_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month11]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month11_NE(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month12]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month12_NE(MCEventInfo info){
	}

	/**
	 * [Type]パネルの[type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doType_type_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day01]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day01_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day02]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day02_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day03]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day03_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day04]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day04_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day05]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day05_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day06]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day06_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day07]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day07_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day08]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day08_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day09]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day09_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day10]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day10_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day11]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day11_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day12]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day12_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day13]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day13_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day14]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day14_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day15]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day15_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day16]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day16_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day17]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day17_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day18]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day18_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day19]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day19_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day20]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day20_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day21]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day21_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day22]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day22_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day23]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day23_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day24]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day24_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day25]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day25_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day26]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day26_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day27]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day27_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day28]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day28_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day29]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day29_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day30]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day30_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day31]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day31_NE(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[lastday]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_lastday_NE(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week01]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week01_NE(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week02]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week02_NE(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week03]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week03_NE(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week04]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week04_NE(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[lastweek]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_lastweek_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday01]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday01_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday02]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday02_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday03]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday03_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday04]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday04_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday05]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday05_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday06]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday06_NE(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday07]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday07_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Base_desc) doBase_desc_NX(info);
		else if (nx == Base_inv_flg) doBase_inv_flg_NX(info);
		else if (nx == Base_hour) doBase_hour_NX(info);
		else if (nx == Base_minute) doBase_minute_NX(info);
		else if (nx == Month_month01) doMonth_month01_NX(info);
		else if (nx == Month_month02) doMonth_month02_NX(info);
		else if (nx == Month_month03) doMonth_month03_NX(info);
		else if (nx == Month_month04) doMonth_month04_NX(info);
		else if (nx == Month_month05) doMonth_month05_NX(info);
		else if (nx == Month_month06) doMonth_month06_NX(info);
		else if (nx == Month_month07) doMonth_month07_NX(info);
		else if (nx == Month_month08) doMonth_month08_NX(info);
		else if (nx == Month_month09) doMonth_month09_NX(info);
		else if (nx == Month_month10) doMonth_month10_NX(info);
		else if (nx == Month_month11) doMonth_month11_NX(info);
		else if (nx == Month_month12) doMonth_month12_NX(info);
		else if (nx == Type_type_Group) doType_type_NX(info);
		else if (nx == Day_day01) doDay_day01_NX(info);
		else if (nx == Day_day02) doDay_day02_NX(info);
		else if (nx == Day_day03) doDay_day03_NX(info);
		else if (nx == Day_day04) doDay_day04_NX(info);
		else if (nx == Day_day05) doDay_day05_NX(info);
		else if (nx == Day_day06) doDay_day06_NX(info);
		else if (nx == Day_day07) doDay_day07_NX(info);
		else if (nx == Day_day08) doDay_day08_NX(info);
		else if (nx == Day_day09) doDay_day09_NX(info);
		else if (nx == Day_day10) doDay_day10_NX(info);
		else if (nx == Day_day11) doDay_day11_NX(info);
		else if (nx == Day_day12) doDay_day12_NX(info);
		else if (nx == Day_day13) doDay_day13_NX(info);
		else if (nx == Day_day14) doDay_day14_NX(info);
		else if (nx == Day_day15) doDay_day15_NX(info);
		else if (nx == Day_day16) doDay_day16_NX(info);
		else if (nx == Day_day17) doDay_day17_NX(info);
		else if (nx == Day_day18) doDay_day18_NX(info);
		else if (nx == Day_day19) doDay_day19_NX(info);
		else if (nx == Day_day20) doDay_day20_NX(info);
		else if (nx == Day_day21) doDay_day21_NX(info);
		else if (nx == Day_day22) doDay_day22_NX(info);
		else if (nx == Day_day23) doDay_day23_NX(info);
		else if (nx == Day_day24) doDay_day24_NX(info);
		else if (nx == Day_day25) doDay_day25_NX(info);
		else if (nx == Day_day26) doDay_day26_NX(info);
		else if (nx == Day_day27) doDay_day27_NX(info);
		else if (nx == Day_day28) doDay_day28_NX(info);
		else if (nx == Day_day29) doDay_day29_NX(info);
		else if (nx == Day_day30) doDay_day30_NX(info);
		else if (nx == Day_day31) doDay_day31_NX(info);
		else if (nx == Day_lastday) doDay_lastday_NX(info);
		else if (nx == Week_week01) doWeek_week01_NX(info);
		else if (nx == Week_week02) doWeek_week02_NX(info);
		else if (nx == Week_week03) doWeek_week03_NX(info);
		else if (nx == Week_week04) doWeek_week04_NX(info);
		else if (nx == Week_lastweek) doWeek_lastweek_NX(info);
		else if (nx == Weekday_weekday01) doWeekday_weekday01_NX(info);
		else if (nx == Weekday_weekday02) doWeekday_weekday02_NX(info);
		else if (nx == Weekday_weekday03) doWeekday_weekday03_NX(info);
		else if (nx == Weekday_weekday04) doWeekday_weekday04_NX(info);
		else if (nx == Weekday_weekday05) doWeekday_weekday05_NX(info);
		else if (nx == Weekday_weekday06) doWeekday_weekday06_NX(info);
		else if (nx == Weekday_weekday07) doWeekday_weekday07_NX(info);
	}

	/**
	 * [Base]パネルの[desc]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_desc_NX(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[inv_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_inv_flg_NX(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[hour]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_hour_NX(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[minute]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_minute_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month01]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month01_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month02]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month02_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month03]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month03_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month04]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month04_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month05]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month05_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month06]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month06_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month07]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month07_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month08]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month08_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month09]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month09_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month10]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month10_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month11]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month11_NX(MCEventInfo info){
	}

	/**
	 * [Month]パネルの[month12]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_month12_NX(MCEventInfo info){
	}

	/**
	 * [Type]パネルの[type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doType_type_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day01]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day01_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day02]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day02_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day03]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day03_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day04]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day04_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day05]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day05_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day06]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day06_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day07]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day07_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day08]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day08_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day09]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day09_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day10]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day10_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day11]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day11_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day12]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day12_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day13]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day13_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day14]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day14_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day15]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day15_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day16]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day16_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day17]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day17_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day18]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day18_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day19]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day19_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day20]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day20_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day21]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day21_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day22]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day22_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day23]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day23_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day24]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day24_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day25]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day25_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day26]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day26_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day27]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day27_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day28]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day28_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day29]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day29_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day30]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day30_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[day31]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_day31_NX(MCEventInfo info){
	}

	/**
	 * [Day]パネルの[lastday]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDay_lastday_NX(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week01]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week01_NX(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week02]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week02_NX(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week03]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week03_NX(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[week04]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_week04_NX(MCEventInfo info){
	}

	/**
	 * [Week]パネルの[lastweek]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeek_lastweek_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday01]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday01_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday02]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday02_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday03]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday03_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday04]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday04_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday05]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday05_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday06]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday06_NX(MCEventInfo info){
	}

	/**
	 * [Weekday]パネルの[weekday07]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doWeekday_weekday07_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Base_hour) doBase_hour_LC(info);
		else if (lc == Base_minute) doBase_minute_LC(info);
	}

	/**
	 * [Base]パネルの[hour]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_hour_LC(MCEventInfo info){
	}

	/**
	 * [Base]パネルの[minute]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBase_minute_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}