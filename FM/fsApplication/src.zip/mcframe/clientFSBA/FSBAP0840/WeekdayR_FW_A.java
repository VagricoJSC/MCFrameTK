package mcframe.clientFSBA.FSBAP0840;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Weekday"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class WeekdayR_FW_A extends MCConstRow {

	/**
	 *  日.<p>
	 *
	 */
	public static final String $weekday01 = "weekday01";
	/**
	 *  月.<p>
	 *
	 */
	public static final String $weekday02 = "weekday02";
	/**
	 *  火.<p>
	 *
	 */
	public static final String $weekday03 = "weekday03";
	/**
	 *  水.<p>
	 *
	 */
	public static final String $weekday04 = "weekday04";
	/**
	 *  木.<p>
	 *
	 */
	public static final String $weekday05 = "weekday05";
	/**
	 *  金.<p>
	 *
	 */
	public static final String $weekday06 = "weekday06";
	/**
	 *  土.<p>
	 *
	 */
	public static final String $weekday07 = "weekday07";


	public static final MCMeta weekday01_META = createCommonMeta($weekday01, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta weekday02_META = createCommonMeta($weekday02, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta weekday03_META = createCommonMeta($weekday03, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta weekday04_META = createCommonMeta($weekday04, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta weekday05_META = createCommonMeta($weekday05, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta weekday06_META = createCommonMeta($weekday06, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta weekday07_META = createCommonMeta($weekday07, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<WeekdayR> constMetas = new ConstMetaList<WeekdayR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			weekday01_META,
			weekday02_META,
			weekday03_META,
			weekday04_META,
			weekday05_META,
			weekday06_META,
			weekday07_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected WeekdayR_FW_A(ConstMetaList<? extends WeekdayR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public WeekdayR clone() {
		return (WeekdayR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public WeekdayR createInstance() {
		return (WeekdayR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public WeekdayR getValues(String... names) {
		return (WeekdayR) super.getValues(names);
	}



	/**
	 *  日.<p>
	 *
	 */
	public boolean weekday01() {
		return getConstBoolean(offset + 0, $weekday01);
	}

	/**
	 *  日.<p>
	 *
	 */
	public void weekday01(boolean value) {
		setConstBoolean(offset + 0, $weekday01, value);
	}


	/**
	 *  月.<p>
	 *
	 */
	public boolean weekday02() {
		return getConstBoolean(offset + 1, $weekday02);
	}

	/**
	 *  月.<p>
	 *
	 */
	public void weekday02(boolean value) {
		setConstBoolean(offset + 1, $weekday02, value);
	}


	/**
	 *  火.<p>
	 *
	 */
	public boolean weekday03() {
		return getConstBoolean(offset + 2, $weekday03);
	}

	/**
	 *  火.<p>
	 *
	 */
	public void weekday03(boolean value) {
		setConstBoolean(offset + 2, $weekday03, value);
	}


	/**
	 *  水.<p>
	 *
	 */
	public boolean weekday04() {
		return getConstBoolean(offset + 3, $weekday04);
	}

	/**
	 *  水.<p>
	 *
	 */
	public void weekday04(boolean value) {
		setConstBoolean(offset + 3, $weekday04, value);
	}


	/**
	 *  木.<p>
	 *
	 */
	public boolean weekday05() {
		return getConstBoolean(offset + 4, $weekday05);
	}

	/**
	 *  木.<p>
	 *
	 */
	public void weekday05(boolean value) {
		setConstBoolean(offset + 4, $weekday05, value);
	}


	/**
	 *  金.<p>
	 *
	 */
	public boolean weekday06() {
		return getConstBoolean(offset + 5, $weekday06);
	}

	/**
	 *  金.<p>
	 *
	 */
	public void weekday06(boolean value) {
		setConstBoolean(offset + 5, $weekday06, value);
	}


	/**
	 *  土.<p>
	 *
	 */
	public boolean weekday07() {
		return getConstBoolean(offset + 6, $weekday07);
	}

	/**
	 *  土.<p>
	 *
	 */
	public void weekday07(boolean value) {
		setConstBoolean(offset + 6, $weekday07, value);
	}


	public boolean getBoolean(String name) {
		if ($weekday01.equalsIgnoreCase(name)) {
			return weekday01();
		}
		if ($weekday02.equalsIgnoreCase(name)) {
			return weekday02();
		}
		if ($weekday03.equalsIgnoreCase(name)) {
			return weekday03();
		}
		if ($weekday04.equalsIgnoreCase(name)) {
			return weekday04();
		}
		if ($weekday05.equalsIgnoreCase(name)) {
			return weekday05();
		}
		if ($weekday06.equalsIgnoreCase(name)) {
			return weekday06();
		}
		if ($weekday07.equalsIgnoreCase(name)) {
			return weekday07();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($weekday01.equalsIgnoreCase(name)) {
			return weekday01();
		}
		if ($weekday02.equalsIgnoreCase(name)) {
			return weekday02();
		}
		if ($weekday03.equalsIgnoreCase(name)) {
			return weekday03();
		}
		if ($weekday04.equalsIgnoreCase(name)) {
			return weekday04();
		}
		if ($weekday05.equalsIgnoreCase(name)) {
			return weekday05();
		}
		if ($weekday06.equalsIgnoreCase(name)) {
			return weekday06();
		}
		if ($weekday07.equalsIgnoreCase(name)) {
			return weekday07();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($weekday01.equalsIgnoreCase(name)) {
			weekday01(value);
			return;
		}
		if ($weekday02.equalsIgnoreCase(name)) {
			weekday02(value);
			return;
		}
		if ($weekday03.equalsIgnoreCase(name)) {
			weekday03(value);
			return;
		}
		if ($weekday04.equalsIgnoreCase(name)) {
			weekday04(value);
			return;
		}
		if ($weekday05.equalsIgnoreCase(name)) {
			weekday05(value);
			return;
		}
		if ($weekday06.equalsIgnoreCase(name)) {
			weekday06(value);
			return;
		}
		if ($weekday07.equalsIgnoreCase(name)) {
			weekday07(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($weekday01.equalsIgnoreCase(name)) {
			weekday01(value);
			return;
		}
		if ($weekday02.equalsIgnoreCase(name)) {
			weekday02(value);
			return;
		}
		if ($weekday03.equalsIgnoreCase(name)) {
			weekday03(value);
			return;
		}
		if ($weekday04.equalsIgnoreCase(name)) {
			weekday04(value);
			return;
		}
		if ($weekday05.equalsIgnoreCase(name)) {
			weekday05(value);
			return;
		}
		if ($weekday06.equalsIgnoreCase(name)) {
			weekday06(value);
			return;
		}
		if ($weekday07.equalsIgnoreCase(name)) {
			weekday07(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

