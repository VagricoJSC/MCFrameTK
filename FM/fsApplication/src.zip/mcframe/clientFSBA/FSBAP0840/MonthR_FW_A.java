package mcframe.clientFSBA.FSBAP0840;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Month"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MonthR_FW_A extends MCConstRow {

	/**
	 *  1月.<p>
	 *
	 */
	public static final String $month01 = "month01";
	/**
	 *  2月.<p>
	 *
	 */
	public static final String $month02 = "month02";
	/**
	 *  3月.<p>
	 *
	 */
	public static final String $month03 = "month03";
	/**
	 *  4月.<p>
	 *
	 */
	public static final String $month04 = "month04";
	/**
	 *  5月.<p>
	 *
	 */
	public static final String $month05 = "month05";
	/**
	 *  6月.<p>
	 *
	 */
	public static final String $month06 = "month06";
	/**
	 *  7月.<p>
	 *
	 */
	public static final String $month07 = "month07";
	/**
	 *  8月.<p>
	 *
	 */
	public static final String $month08 = "month08";
	/**
	 *  9月.<p>
	 *
	 */
	public static final String $month09 = "month09";
	/**
	 *  10月.<p>
	 *
	 */
	public static final String $month10 = "month10";
	/**
	 *  11月.<p>
	 *
	 */
	public static final String $month11 = "month11";
	/**
	 *  12月.<p>
	 *
	 */
	public static final String $month12 = "month12";


	public static final MCMeta month01_META = createCommonMeta($month01, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month02_META = createCommonMeta($month02, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month03_META = createCommonMeta($month03, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month04_META = createCommonMeta($month04, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month05_META = createCommonMeta($month05, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month06_META = createCommonMeta($month06, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month07_META = createCommonMeta($month07, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month08_META = createCommonMeta($month08, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month09_META = createCommonMeta($month09, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month10_META = createCommonMeta($month10, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month11_META = createCommonMeta($month11, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta month12_META = createCommonMeta($month12, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<MonthR> constMetas = new ConstMetaList<MonthR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			month01_META,
			month02_META,
			month03_META,
			month04_META,
			month05_META,
			month06_META,
			month07_META,
			month08_META,
			month09_META,
			month10_META,
			month11_META,
			month12_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MonthR_FW_A(ConstMetaList<? extends MonthR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MonthR clone() {
		return (MonthR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MonthR createInstance() {
		return (MonthR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MonthR getValues(String... names) {
		return (MonthR) super.getValues(names);
	}



	/**
	 *  1月.<p>
	 *
	 */
	public boolean month01() {
		return getConstBoolean(offset + 0, $month01);
	}

	/**
	 *  1月.<p>
	 *
	 */
	public void month01(boolean value) {
		setConstBoolean(offset + 0, $month01, value);
	}


	/**
	 *  2月.<p>
	 *
	 */
	public boolean month02() {
		return getConstBoolean(offset + 1, $month02);
	}

	/**
	 *  2月.<p>
	 *
	 */
	public void month02(boolean value) {
		setConstBoolean(offset + 1, $month02, value);
	}


	/**
	 *  3月.<p>
	 *
	 */
	public boolean month03() {
		return getConstBoolean(offset + 2, $month03);
	}

	/**
	 *  3月.<p>
	 *
	 */
	public void month03(boolean value) {
		setConstBoolean(offset + 2, $month03, value);
	}


	/**
	 *  4月.<p>
	 *
	 */
	public boolean month04() {
		return getConstBoolean(offset + 3, $month04);
	}

	/**
	 *  4月.<p>
	 *
	 */
	public void month04(boolean value) {
		setConstBoolean(offset + 3, $month04, value);
	}


	/**
	 *  5月.<p>
	 *
	 */
	public boolean month05() {
		return getConstBoolean(offset + 4, $month05);
	}

	/**
	 *  5月.<p>
	 *
	 */
	public void month05(boolean value) {
		setConstBoolean(offset + 4, $month05, value);
	}


	/**
	 *  6月.<p>
	 *
	 */
	public boolean month06() {
		return getConstBoolean(offset + 5, $month06);
	}

	/**
	 *  6月.<p>
	 *
	 */
	public void month06(boolean value) {
		setConstBoolean(offset + 5, $month06, value);
	}


	/**
	 *  7月.<p>
	 *
	 */
	public boolean month07() {
		return getConstBoolean(offset + 6, $month07);
	}

	/**
	 *  7月.<p>
	 *
	 */
	public void month07(boolean value) {
		setConstBoolean(offset + 6, $month07, value);
	}


	/**
	 *  8月.<p>
	 *
	 */
	public boolean month08() {
		return getConstBoolean(offset + 7, $month08);
	}

	/**
	 *  8月.<p>
	 *
	 */
	public void month08(boolean value) {
		setConstBoolean(offset + 7, $month08, value);
	}


	/**
	 *  9月.<p>
	 *
	 */
	public boolean month09() {
		return getConstBoolean(offset + 8, $month09);
	}

	/**
	 *  9月.<p>
	 *
	 */
	public void month09(boolean value) {
		setConstBoolean(offset + 8, $month09, value);
	}


	/**
	 *  10月.<p>
	 *
	 */
	public boolean month10() {
		return getConstBoolean(offset + 9, $month10);
	}

	/**
	 *  10月.<p>
	 *
	 */
	public void month10(boolean value) {
		setConstBoolean(offset + 9, $month10, value);
	}


	/**
	 *  11月.<p>
	 *
	 */
	public boolean month11() {
		return getConstBoolean(offset + 10, $month11);
	}

	/**
	 *  11月.<p>
	 *
	 */
	public void month11(boolean value) {
		setConstBoolean(offset + 10, $month11, value);
	}


	/**
	 *  12月.<p>
	 *
	 */
	public boolean month12() {
		return getConstBoolean(offset + 11, $month12);
	}

	/**
	 *  12月.<p>
	 *
	 */
	public void month12(boolean value) {
		setConstBoolean(offset + 11, $month12, value);
	}


	public boolean getBoolean(String name) {
		if ($month01.equalsIgnoreCase(name)) {
			return month01();
		}
		if ($month02.equalsIgnoreCase(name)) {
			return month02();
		}
		if ($month03.equalsIgnoreCase(name)) {
			return month03();
		}
		if ($month04.equalsIgnoreCase(name)) {
			return month04();
		}
		if ($month05.equalsIgnoreCase(name)) {
			return month05();
		}
		if ($month06.equalsIgnoreCase(name)) {
			return month06();
		}
		if ($month07.equalsIgnoreCase(name)) {
			return month07();
		}
		if ($month08.equalsIgnoreCase(name)) {
			return month08();
		}
		if ($month09.equalsIgnoreCase(name)) {
			return month09();
		}
		if ($month10.equalsIgnoreCase(name)) {
			return month10();
		}
		if ($month11.equalsIgnoreCase(name)) {
			return month11();
		}
		if ($month12.equalsIgnoreCase(name)) {
			return month12();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($month01.equalsIgnoreCase(name)) {
			return month01();
		}
		if ($month02.equalsIgnoreCase(name)) {
			return month02();
		}
		if ($month03.equalsIgnoreCase(name)) {
			return month03();
		}
		if ($month04.equalsIgnoreCase(name)) {
			return month04();
		}
		if ($month05.equalsIgnoreCase(name)) {
			return month05();
		}
		if ($month06.equalsIgnoreCase(name)) {
			return month06();
		}
		if ($month07.equalsIgnoreCase(name)) {
			return month07();
		}
		if ($month08.equalsIgnoreCase(name)) {
			return month08();
		}
		if ($month09.equalsIgnoreCase(name)) {
			return month09();
		}
		if ($month10.equalsIgnoreCase(name)) {
			return month10();
		}
		if ($month11.equalsIgnoreCase(name)) {
			return month11();
		}
		if ($month12.equalsIgnoreCase(name)) {
			return month12();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($month01.equalsIgnoreCase(name)) {
			month01(value);
			return;
		}
		if ($month02.equalsIgnoreCase(name)) {
			month02(value);
			return;
		}
		if ($month03.equalsIgnoreCase(name)) {
			month03(value);
			return;
		}
		if ($month04.equalsIgnoreCase(name)) {
			month04(value);
			return;
		}
		if ($month05.equalsIgnoreCase(name)) {
			month05(value);
			return;
		}
		if ($month06.equalsIgnoreCase(name)) {
			month06(value);
			return;
		}
		if ($month07.equalsIgnoreCase(name)) {
			month07(value);
			return;
		}
		if ($month08.equalsIgnoreCase(name)) {
			month08(value);
			return;
		}
		if ($month09.equalsIgnoreCase(name)) {
			month09(value);
			return;
		}
		if ($month10.equalsIgnoreCase(name)) {
			month10(value);
			return;
		}
		if ($month11.equalsIgnoreCase(name)) {
			month11(value);
			return;
		}
		if ($month12.equalsIgnoreCase(name)) {
			month12(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($month01.equalsIgnoreCase(name)) {
			month01(value);
			return;
		}
		if ($month02.equalsIgnoreCase(name)) {
			month02(value);
			return;
		}
		if ($month03.equalsIgnoreCase(name)) {
			month03(value);
			return;
		}
		if ($month04.equalsIgnoreCase(name)) {
			month04(value);
			return;
		}
		if ($month05.equalsIgnoreCase(name)) {
			month05(value);
			return;
		}
		if ($month06.equalsIgnoreCase(name)) {
			month06(value);
			return;
		}
		if ($month07.equalsIgnoreCase(name)) {
			month07(value);
			return;
		}
		if ($month08.equalsIgnoreCase(name)) {
			month08(value);
			return;
		}
		if ($month09.equalsIgnoreCase(name)) {
			month09(value);
			return;
		}
		if ($month10.equalsIgnoreCase(name)) {
			month10(value);
			return;
		}
		if ($month11.equalsIgnoreCase(name)) {
			month11(value);
			return;
		}
		if ($month12.equalsIgnoreCase(name)) {
			month12(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

