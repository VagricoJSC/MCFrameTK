package mcframe.clientFSBA.FSBAP0330;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0170.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.HashMap;
import java.util.Map;

import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

import mcframe.clientCore.beans.resource.MCRowFilterData;
import mcframe.clientCore.beans.resource.MCRowFilterInfo;
import mcframe.clientCore.beans.resource.MCRowFilterResourceIO;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSUB.FSUBP0000.IfCompCondBase;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import mcframe.clientFSUB.FSUBP0170.FSUBP_CompCond_D_FW.FSUBP_InfoDtlCellConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_RowFilter"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_RowFilter_FW extends FSBAP_RowFilter_FW_A implements IfCompCondBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * フィルタ設定対象のテーブルです。
	 */
	protected MCTable<?> _target_table = null;

	/**
	 * 登録時のメッセージを格納するためのリストです。
	 */
	protected MCMessageList _message_list = new MCMessageList();

	/**
	 * 設定情報ＩＤのシーケンス番号のマップです。
	 */
	protected Map<String, Integer> _setting_info_no_map = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_RowFilter_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_RowFilter_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[InfoBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_radd(MCEventInfo info) {
		insertRow(InfoDtlTable);

		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}
	/**
	 * Panel[InfoBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doInfoBtn_rdel(MCEventInfo info) {
		deleteRow(InfoDtlTable);

		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}
	/**
	 * Panel[InfoBtn]のボタン[rcopy]の押下時の処理
	 */
	@Override
	public void doInfoBtn_rcopy(MCEventInfo info) {
		InfoDtlR o = copyRow(InfoDtlTable);
		if (isNull(o)) {
			return;
		}
		int i = o.getGUIIndex();
		for (MCColumnConfig c : InfoDtl_cond_p_PPanel.getConditionValueColumnConfigs()) {
			setValueEx(c, i, null);
		}
	}
	/**
	 * Panel[InfoBtn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_select_all(MCEventInfo info) {
		InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(false);
		try {
			setValueEx(columnInfoDtl_disable, true);
		}
		finally {
			InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(true);
			InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
		}
	}
	/**
	 * Panel[InfoBtn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_deselect_all(MCEventInfo info) {
		InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(false);
		try {
			setValueEx(columnInfoDtl_disable, false);
		}
		finally {
			InfoDtl_cond_p_PPanel.enableUpdateFirstEnableRowIndex(true);
			InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
		}
	}

	@Override
	public MCList<ListDtlR> getListDtlL() {
		return super.getListDtlL();
	}

	/**
	 * ソート順設定対象のテーブルを設定します。
	 *
	 * @param table ソート順設定対象のテーブル
	 */
	protected void setTargetTable(MCTable<?> table) {
		_target_table = table;

		// 計算式の初期化
		InfoDtl_cond_p_PPanel.initExpressionBuilder();
	}

	/**
	 * ソート順設定対象のテーブルを返します。<p>
	 * ソート順設定対象のテーブルが設定されていない場合は null を返します。
	 *
	 * @return ソート順設定対象のテーブル、または null
	 */
	@Override
	public MCTable<?> getTargetTable() {
		return _target_table;
	}

	@Override
	public String getPersonalizedType() {
		return ROW_FILTER_PANEL;
	}


	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);

		// 登録済みの行が選択された場合
		FSBAP_RowFilterInfo fi = getSettingInfo(data);
		if (fi != null) {
			setListHdrR(fi.getSettingInfo());

			MCList<InfoDtlR> l = fi.getRowFilterList();
			if (l != null) {
				setInfoDtlL(l.clone());
			}
			else {
				setInfoDtlL(null);
			}

			getListHdrR().setStatus(MCRow.NONE);
			getInfoDtlL().setStatus(MCRow.NONE);

			InfoDtlTable.fillSpace();
			InfoDtlTable.adjustWidth();
			// adjustWidthでテーブルの横スクロールバーが消える。
			// 横スクロールバーが消えた後に１行分の隙間ができる可能性があるため、
			// 再度fillSpaceを実行する。
			InfoDtlTable.fillSpace();

			return;
		}

		// 新規行が選択された場合
		getInfoDtlL().clear();
		getListHdrR().clearAll();
		InfoDtlTable.fillSpace();
		InfoDtlTable.adjustWidth();
		// adjustWidthでテーブルの横スクロールバーが消える。
		// 横スクロールバーが消えた後に１行分の隙間ができる可能性があるため、
		// 再度fillSpaceを実行する。
		InfoDtlTable.fillSpace();

	}

	@Override
	protected boolean isInfoDataChanged() {
		return !getInfoDtlL().isStatusNone();
	}

	@Override
	protected void removeResource(boolean doSave) {
		MCTable<?> t = getTargetTable();

		MCRowFilterResourceIO rio = new MCRowFilterResourceIO();

		String u = getSettingR().setting_unit();

		String pfx = t.getPersonalizedKeyPrefix(ROW_FILTER_PANEL, null);
		String pfx2 = t.getPersonalizedKeyPrefix(ROW_FILTER_PANEL,
				MCResourceLayerType.BARCODE);

		Map<String, Integer> m = rio.readSettingInfoNOMap(pfx, pfx2);

		// リソースを削除する
		MCRowFilterResourceIO.removeNoSave(u, pfx);

		// 設定情報ＩＤのシーケンスを再設定する
		if (m.containsKey(u) && isRemainedAfterDel(u)) {
			Map<String, Integer> nm = new HashMap<String, Integer>();
			nm.put(u, m.get(u));
			rio.writeNoSave(pfx, nm);
		}

		if (doSave) {
			MCRowFilterResourceIO.saveResource();
		}
		t._setRowFilterInfo(null);
		t._setRowFilterInfoList(null);
	}

	/**
	 * リソースから指定したIDのみを削除するメソッド。
	 * 
	 * @param doSave 保存するかどうかのフラグ
	 * @param setting_info_id 設定情報ID
	 */
	protected void removeResourceById(boolean doSave, String setting_info_id) {
		MCTable<?> t = getTargetTable();
		if (setting_info_id != null) {
			MCRowFilterResourceIO rio = new MCRowFilterResourceIO();
	
			String u = getSettingR().setting_unit();
	
			String pfx = t.getPersonalizedKeyPrefix(ROW_FILTER_PANEL, null);
			String pfx2 = t.getPersonalizedKeyPrefix(ROW_FILTER_PANEL,
					MCResourceLayerType.BARCODE);
	
			Map<String, Integer> m = rio.readSettingInfoNOMap(pfx, pfx2);
	
			// リソースを削除する
			MCRowFilterResourceIO.removeNoSaveById(u, pfx, setting_info_id);
			// 初期設定のリソースが引数のIDと一致する場合は削除
//			rio.removeInitResourceById(u, pfx, setting_info_id);
	
			// 設定情報ＩＤのシーケンスを再設定する
			if (m.containsKey(u) && isRemainedAfterDel(u)) {
				Map<String, Integer> nm = new HashMap<String, Integer>();
				nm.put(u, m.get(u));
				rio.writeNoSave(pfx, nm);
			}
	
			if (doSave) {
				MCRowFilterResourceIO.saveResource();
			}
		}
		t._setRowFilterInfo(null);
		t._setRowFilterInfoList(null);
	}

	@Override
	protected void setInitData() {
		super.setInitData();

		getInfoDtlL().clear();

		MCTable<?> t = getTargetTable();

		List<MCRowFilterInfo> l = new ArrayList<MCRowFilterInfo>();

		// デフォルトのフィルタ情報を追加する
		MCRowFilterList<MCRowFilter> df = t.getDefaultRowFilterList();
		if (df != null) {
			List<MCRowFilterData> dl = new ArrayList<MCRowFilterData>();
			for (MCRowFilter f : df) {
				MCRowFilterData d = t.toRowFilterData(f);
				if (d != null) {
					dl.add(d);
				}
			}
			if (dl.size() > 0) {
				MCRowFilterInfo i = MCRowFilterInfo.create();
				i.setSettingUnitType(FXC_RESOURCE_SETTING_UNIT.TYPE_PGM.value());
				i.setSettingInfoID(getPgmSettingInfoID());
				i.setSettingInfoName(getDefaultSettingName());
				i.setRowFilterList(dl);
				l.add(i);
			}
		}

		List<MCRowFilterInfo> sl = new ArrayList<MCRowFilterInfo>();
		List<MCRowFilterInfo> el = new ArrayList<MCRowFilterInfo>();
		List<MCRowFilterInfo> ul = new ArrayList<MCRowFilterInfo>();

		for (MCRowFilterInfo i : t.getRowFilterInfoList()) {
			String y = i.getSettingUnitType();
			if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
				sl.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
				el.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
				ul.add(i);
			}
		}

		String u = getSettingR().setting_unit();
		l.addAll(0, sl);
		if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
			l.addAll(0, el);
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
				l.addAll(0, ul);
			}
		}

		MCTable<?> tbl = getTargetTable();

		// BARCODEの場合にpfxが異なる。
		String pfx = tbl.getPersonalizedKeyPrefix(ROW_FILTER_PANEL, null);
		String pfx2 = tbl.getPersonalizedKeyPrefix(ROW_FILTER_PANEL, MCResourceLayerType.BARCODE);
		_setting_info_no_map = new MCRowFilterResourceIO().readSettingInfoNOMap(pfx, pfx2);

		// 設定情報一覧のリスト
		MCList<ListDtlR> il = createListDtlL();
		// 旧仕様の設定情報名の接尾語
		int pi = 0;
		for (MCRowFilterInfo i : l) {
			FSBAP_RowFilterInfo fi = new FSBAP_RowFilterInfo();

			// 設定情報
			ListDtlR lo = il.createRow();

			lo.setting_unit_type(i.getSettingUnitType());
			FXC_RESOURCE_SETTING_UNIT.putName(lo,
					ListDtlR.$setting_unit_type,
					ListDtlR.$setting_unit_type_nm);

			lo.setting_info_id(i.getSettingInfoID());
			lo.setting_info_nm(i.getSettingInfoName());
			if (isNull(lo.setting_info_nm())) {
				lo.setting_info_nm(
						getPreviousSettingNamePrefix() + String.valueOf(++pi));
			}
			lo.remark(i.getRemark());
			il.add(lo);

			fi.setSettingInfo(lo.clone());

			// フィルタ情報
			MCList<InfoDtlR> dl = createInfoDtlL();
			List<MCRowFilterData> fdl = i.getRowFilterList();
			for (MCRowFilterData fd : fdl) {
				MCRowFilter f = t.toRowFilter(fd);
				if (f == null) {
					continue;
				}

				InfoDtlR o = dl.createRow();
				InfoDtl_cond_p_PPanel.addConditionRow(o.cond_p(), f);
				dl.add(o);
			}

			fi.setRowFilterList(dl);

			getSettingInfoMap().put(MCConst.createKey(
					i.getSettingUnitType(), i.getSettingInfoID()), fi);
		}

		setListDtlL(il);

		ListDtlTable.adjustWidth();
	}

	@Override
	protected FSBAP_RowFilterInfo getSettingInfo(ListDtlR data) {
		return (FSBAP_RowFilterInfo)super.getSettingInfo(data);
	}

	@Override
	protected void setTargetPanelDefault() {
		MCTable<?> t = getTargetTable();
		t._applyRowFilterInfo(null);
		t._setRowFilterInfoList(null);
	}

	@Override
	protected void updateTargetPanel() {
		_message_list.clear();

		ListDtlR s = ListDtlTable.getSelectedMCRow();
		MCTable<?> t = getTargetTable();

		for (MCRowFilterInfo i : t.getRowFilterInfoList()) {
			if (isSame(s.setting_unit_type(), i.getSettingUnitType())
					&& isSame(s.setting_info_id(), i.getSettingInfoID())) {
				MCMessageList m = t._applyRowFilterInfo(i);
				if (m.size() > 0) {
					_message_list.addAll(m);
				}
				break;
			}
		}
	}

	@Override
	protected void writeResource() {
		// 既存データを削除する
//		removeResource(false);

		// 汎用テーブル編集以外の場合、既存データを削除する
		if (!isTargetGeneralTable()) {
			removeResource(false);
		}

		MCTable<?> tbl = getTargetTable();
		String pfx = tbl.getPersonalizedKeyPrefix(
				ROW_FILTER_PANEL, null);

		MCRowFilterResourceIO fio = new MCRowFilterResourceIO();

		ListDtlR s = ListDtlTable.getSelectedMCRow();

		String u = getSettingR().setting_unit();
		Integer no = _setting_info_no_map.get(u);
		if (no == null) {
			no = Math.max(getMaxSettingInfoNO(), 0);
		}

		for (ListDtlR o : getListDtlL()) {
			if (o.isEmpty() || (o.isStatusDelete() && !isTargetGeneralTable())) {
				continue;
			}

			ListDtlR c1;
			MCList<InfoDtlR> c2;

			String y = o.setting_unit_type();

			// 選択行ではない場合
			if (s != o) {
				if (!u.equals(y)) {
					continue;
				}

				FSBAP_RowFilterInfo fi = getSettingInfo(o);
				if (fi == null) {
					continue;
				}

				c1 = fi.getSettingInfo().clone();
				c1.init_flg(o.init_flg());
				c2 = fi.getRowFilterList().clone();
			}
			// 選択行の場合
			else {
				if (isNull(y)) {
					o.setting_unit_type(u);
					FXC_RESOURCE_SETTING_UNIT.putNameNE(o,
							ListDtlR.$setting_unit_type,
							ListDtlR.$setting_unit_type_nm);
					y = o.setting_unit_type();
				}

				if (!u.equals(y)) {
					continue;
				}

				c1 = createListDtlR();
				c2 = createInfoDtlL();
				c1.setValues(ListDtlR.colnames(),
						getListHdrR(), ListDtlR.colnames());
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				for (InfoDtlR d : getInfoDtlL()) {
					if (d.isEmpty() || d.isStatusDelete()) {
						continue;
					}
					InfoDtlR f = c2.createRow();
					f.setValues(InfoDtlR.colnames(), d, InfoDtlR.colnames());
					c2.add(f);
				}

				// 汎用テーブル編集の場合
				if (isTargetGeneralTable()) {
					String id = c1.setting_info_id();
					// 新規の場合
					if (isNull(id)) {
						c1.setting_info_id(fio.createSettingInfoID(c1.setting_unit_type(), no++));
						removeResourceById(false, null);
					}
					// 更新または削除の場合、対象のIDのみを削除する
					else {
						removeResourceById(false, id);
					}
					// 削除の場合は追加しない
					if (!s.isStatusDelete()) {
						MCRowFilterInfo fi = MCRowFilterInfo.create();

						fi.setSettingUnitType(c1.setting_unit_type());
						fi.setSettingInfoID(c1.setting_info_id());
						fi.setSettingInfoName(c1.setting_info_nm());
						fi.setRemark(c1.remark());

						List<MCRowFilterData> dl = new ArrayList<MCRowFilterData>();
						for (InfoDtlR t : c2) {
							if (t.isEmpty() || t.isStatusDelete()) {
								continue;
							}

							MCDataType dy = MCDataType.valueOf(t.data_type());
							Comparable<?> v = InfoDtl_cond_p_PPanel.getConditionValue(t.cond_p());

							MCRowFilter f = new MCRowFilter();
							f.setDisable(t.disable());
							f.setConditionNoCheck(
									t.column_key(),
									dy,
									v,
									t.relative_type(),
									t.logic_type());

							MCRowFilterData d = tbl.toRowFilterData(f);
							if (d != null) {
								dl.add(d);
							}
						}
						fi.setRowFilterList(dl);

						fio.addInfo(fi);
					}
				}
			}

			// 汎用テーブル編集以外の場合
			if (!isTargetGeneralTable()) {
				MCRowFilterInfo fi = MCRowFilterInfo.create();

				String id = c1.setting_info_id();
				if (isNull(id)) {
					c1.setting_info_id(fio.createSettingInfoID(c1.setting_unit_type(), no++));
				}
				fi.setSettingUnitType(c1.setting_unit_type());
				fi.setSettingInfoID(c1.setting_info_id());
				fi.setSettingInfoName(c1.setting_info_nm());
				fi.setRemark(c1.remark());

				List<MCRowFilterData> dl = new ArrayList<MCRowFilterData>();
				for (InfoDtlR t : c2) {
					if (t.isEmpty() || t.isStatusDelete()) {
						continue;
					}

					MCDataType dy = MCDataType.valueOf(t.data_type());
					Comparable<?> v = InfoDtl_cond_p_PPanel.getConditionValue(t.cond_p());

					MCRowFilter f = new MCRowFilter();
					f.setDisable(t.disable());
					f.setConditionNoCheck(
						t.column_key(),
						dy,
						v,
						t.relative_type(),
						t.logic_type());

					MCRowFilterData d = tbl.toRowFilterData(f);
					if (d != null) {
						dl.add(d);
					}
				}
				fi.setRowFilterList(dl);

				fio.addInfo(fi);
			}
		}

		boolean isNotEmpty = fio.getInfoList().size() > 0 ? true : false;
		if (isNotEmpty) {
			Map<String, Integer> m = new HashMap<String, Integer>();
			m.put(u, no);
			fio.writeNoSave(pfx, m);
		}
		MCRowFilterResourceIO.saveResource();

	}

	@Override
	protected void showUpdEndMsg() {
		MCMessageList l = _message_list;

		if (l.size() > 0) {
			MCMessage m = new MCMessage(
					FXBAP0031, new MCMessage(FXBAP0021).toString());
			l.add(0, m);

			sortMessageList(l);
			MCMessageBox.message(
					this, MCFrameType.SYSTEM_MODAL, null, l);
		}
		else {
			super.showUpdEndMsg();
		}

	}

	@Override
	protected boolean checkForApply() {
		if (!super.checkForApply()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		MCList<InfoDtlR> l = exceptEmpty(getInfoDtlL());

		// フィルタ情報の必須項目をチェックする
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			ListDtlR o = ListDtlTable.getSelectedMCRow();
			setInitListData(o);
			setInitInfoData(o);
		}

		return true;

	}

	@Override
	protected void doApply() {
		super.doApply();

		if (_message_list.size() > 0) {
			MCMessageList l = _message_list;
			sortMessageList(l);
			MCMessageBox.message(
					this, MCFrameType.SYSTEM_MODAL, null, l);
		}

	}

	@Override
	protected void afterCopyRow() {
		super.afterCopyRow();

		for (InfoDtlR o : getInfoDtlL()) {
			if (!o.isEmpty()) {
				o.setStatus(MCRow.CREATE);
			}
		}

		getListHdrR().init_flg(false);
		getListHdrR().setting_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		getListHdrR().setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(getListHdrR(),
				ListDtlR.$setting_unit_type,
				ListDtlR.$setting_unit_type_nm);
// 2017/01/05 登録名も複製する
//		getListHdrR().setting_info_nm(null);

		setStatus(EDIT);

	}

	@Override
	protected boolean checkForUpd() {
		if (!super.checkForUpd()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		// フィルタ情報の必須項目をチェックする
		MCMessageList m = new MCMessageList();
		MCRowFilter f = getTargetTable().createRowFilter();

		MCList<InfoDtlR> l = exceptEmpty(getInfoDtlL());
		for (InfoDtlR o : l) {
			if (o.isEmpty() || o.isStatusDelete()) {
				continue;
			}

			// 必須入力チェック
			MCMessageList g = checkReq(InfoDtlTable, o);
			if (g.size() > 0) {
				m.addAll(g);
				continue;
			}

			// 判断条件チェック
			g = InfoDtl_cond_p_PPanel.checkCondition(f, o.cond_p());
			if (g.size() > 0) {
				m.addAll(g);
			}

		}

		if (m.size() > 0) {
			message(m);
			return false;
		}

		return true;

	}

	@Override
	protected void afterUpd() {
		super.afterUpd();

		getTargetTable()._setRowFilterInfoList(null);
	}

	@Override
	protected void afterDel() {
		super.afterDel();

		getTargetTable()._setRowFilterInfoList(null);
	}

	@Override
	protected void afterDef() {
		super.afterDef();

		getTargetTable()._setRowFilterInfoList(null);
	}

	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * フィルタ対象のテーブルを指定してください。
	 * </li>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0048] 引数の指定に誤りがあった場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ]
	 * 起動タイプに {@link T1} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			Object o = args[0];
			if (o == null || !(o instanceof MCTable<?>)) {
				throw new MCAppException(FSBAC0048);
			}

			setTargetTable((MCTable<?>)o);
			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	public void screenClearSetDefault() {
		super.screenClearSetDefault();

		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
		columnInfoDtl_text.setTrimPattern(MCBeansConsts.TRIM_NONE);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();

		InfoDtlTable.fillSpace();
		InfoDtl_cond_p_PPanel.updateFirstEnableRowIndex();
	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);

		ListDtlR o = ListDtlTable.getSelectedMCRow();
		// 行が選択されなかった場合
		if (o == null) {
			getInfoDtlL().clear();
			getListHdrR().clearAll();
			setStatus(INIT);
			return;
		}

		setInitListData(o);
		setInitInfoData(o);

		setStatus(EDIT);
	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!super.doListDtl_VC(info)) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone() || !getListHdrR().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			setInitListData(ListDtlTable.getSelectedMCRow());
		}

		return true;
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);

		setInitFlgMode();
	}

	protected void setInitFlgMode() {
		ListHdr_init_flg.setMode(MCMode.INVISIBLE);
		columnListDtl_init_flg.setMode(MCMode.INVISIBLE);
	}


	protected MCDateFieldType[] getDateFieldTypes(MCColumnConfig column) {
		String p = null;
		if (MCDataType.DATE.equals(column.getDataType())) {
			p = column.getDateFormat().getOutputPattern();
		}
		else if (MCDataType.TIMESTAMP.equals(column.getDataType())) {
			p = column.getTimestampFormat().getOutputPattern();
		}

		if (p == null) {
			return null;
		}

		boolean[] ea = new boolean[7];

		for (char c : p.toCharArray()) {
			switch (c) {
				case 'y':
					ea[0] = true;
					break;
				case 'M':
					ea[1] = true;
					break;
				case 'd':
					ea[2] = true;
					break;
				case 'H':
					ea[3] = true;
					break;
				case 'm':
					ea[4] = true;
					break;
				case 's':
					ea[5] = true;
					break;
				case 'S':
					ea[6] = true;
					break;
				default:
					break;
			}
		}

		List<MCDateFieldType> l = new ArrayList<MCDateFieldType>();
		if (ea[0]) {
			l.add(MCDateFieldType.YEAR);
		}
		if (ea[1]) {
			l.add(MCDateFieldType.MONTH);
		}
		if (ea[2]) {
			l.add(MCDateFieldType.DAY);
		}
		if (ea[3]) {
			l.add(MCDateFieldType.HOUR);
		}
		if (ea[4]) {
			l.add(MCDateFieldType.MINUTE);
		}
		if (ea[5]) {
			l.add(MCDateFieldType.SECOND);
		}
		if (ea[6]) {
			l.add(MCDateFieldType.MILLISECOND);
		}

		return l.toArray(new MCDateFieldType[0]);
	}

	@Override
	protected boolean isSearchedProgram(String type, String pgmid) {
		return MCRowFilterResourceIO.isSearchedProgram(type, pgmid);
	}

	@Override
	protected int getSettingInfoNO(ListDtlR data) {
		return MCRowFilterResourceIO.getSettingInfoNO(data.setting_unit_type(), data.setting_info_id());
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		InfoDtlTable.setCellConfig(createInfoDtlCellConfig());
	}

	/**
	 * フィルタ情報テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return フィルタ情報テーブルに設定するセルコンフィグ
	 */
	protected MCCellConfig createInfoDtlCellConfig() {
		return new FSBAP_InfoDtlCellConfig();
	}

	/**
	 * フィルタ情報テーブルに設定するセルコンフィグです。
	 */
	public class FSBAP_InfoDtlCellConfig extends FSUBP_InfoDtlCellConfig {
		FSBAP_InfoDtlCellConfig() {
			super(InfoDtl_cond_p_PPanel);
		}
	}

	/**
	 * 削除処理を実行します。
	 */
	@Override
	protected void doDel() {
		// 汎用テーブル編集の場合、ステータスをDELETEにする
		// リソース更新後にリストから対象行を削除する
		if (isTargetGeneralTable()) {
			// 選択中の行を取得
			ListDtlR s = ListDtlTable.getSelectedMCRow();
			if (s != null) {
				s.setStatus(Status.DELETE);
				writeResource();
				getListDtlL().remove(s);
				clearSelection(ListDtlTable);
			}
		}
		// 汎用テーブル編集以外の場合、親クラスのメソッドを呼び出す。
		else {
			super.doDel();
		}
	}

	/**
	 * 対象画面が汎用テーブル編集かどうかを返します。
	 * 
	 * @return 汎用テーブル編集の場合はtrue、それ以外の場合はfalse
	 */
	private boolean isTargetGeneralTable() {
		MCTable<?> t = getTargetTable();
		if (t != null) {
			MCRootPanel p = t.getBaseRootPanel();

			if (p != null && p.isGeneralTable()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 設定情報を格納します。
	 */
	public class FSBAP_RowFilterInfo extends WBP_PersonalizeInfo {

		/**
		 * フィルタ情報のリストです。
		 */
		protected MCList<InfoDtlR> _row_filter_list = null;

		/**
		 * コンストラクタです。
		 */
		public FSBAP_RowFilterInfo() {}

		/**
		 * フィルタ情報のリストを設定します。
		 *
		 * @param list フィルタ情報のリスト
		 */
		public void setRowFilterList(MCList<InfoDtlR> list) {
			_row_filter_list = list;
		}

		/**
		 * フィルタ情報のリストを返します。
		 *
		 * @return フィルタ情報のリスト
		 */
		public MCList<InfoDtlR> getRowFilterList() {
			return _row_filter_list;
		}

	}

}