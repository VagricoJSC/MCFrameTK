package mcframe.clientFSBA.FSBAP0770;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_MiningRegister"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_MiningRegister_FW_A extends mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0770";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cond]ブロック関連のField定義
	// [Cond]ブロックの項目のField定義
	/**
	 *  枠名.<p>
	 *
	 */
	public MCColumnConfig columnCond_panel_name = null;
	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public MCColumnConfig columnCond_radio = null;
	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public MCColumnConfig columnCond_radio_nm = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton Btn_apply = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE};
	
	/** [Cond]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0770.CondR> aCondL;

	/**
	 * コピーによってaCondLを設定します。
	 *
	 * aCondLのインスタンスは変更されません。
	 *
	 * @param dataset CondL
	 */
	public void setCondL(MCList aList) {
		if (getCondL() != aList) {
			getCondL().setAll(aList);
		}
	}

	/**
	 * [Cond]ブロックのコンテナaCondLを返します。
	 *
	 * @return CondL
	 */
	public MCList getCondL() {
		return aCondL;
	}

	/**
	 * aCondRを作成します。
	 *
	 * @return CondR
	 */
	public mcframe.clientFSBA.FSBAP0770.CondR createCondR() {
		return mcframe.clientFSBA.FSBAP0770.CondR.create();
	}

	/**
	 * aCondLを作成します。
	 *
	 * @return CondL
	 */
	public MCList createCondL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0770.CondR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCondL())) ret.add(getCondL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCondL()) return "Cond";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cond")) return getCondL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningRegister_FW_A() {
		aCondL = createCondL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningRegister_FW_A(String name) {
		aCondL = createCondL();
		createCondTable();
		CondTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_MiningRegister_FW.jbCreateCond((FSBAP_MiningRegister)this);
		FSBAP_MiningRegister_FW.jbCreateBtn((FSBAP_MiningRegister)this);
	}

	/**
	 * [Cond]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCond(FSBAP_MiningRegister p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP_MiningRegister p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Cond_radio_ListPutter]の定義 */
	private MCListPutter Cond_radio_p = null;

	/**
	 * [Cond_radio_ListPutter]の取得
	 */
	protected MCListPutter getCond_radio_ListPutter() {
		if (Cond_radio_p == null) {
			Cond_radio_p = createCond_radio_ListPutter(columnCond_radio, "radio", "radio_nm");

		}
		return Cond_radio_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningRegister create(){
		FSBAP_MiningRegister p = new FSBAP_MiningRegister();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_MiningRegister create(String name){
		FSBAP_MiningRegister p = new FSBAP_MiningRegister(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_MiningRegister_FW.jbfInitCond((FSBAP_MiningRegister)this);
		FSBAP_MiningRegister_FW.jbfInitBtn((FSBAP_MiningRegister)this);
		FSBAP_MiningRegister_FW.jbInitCond((FSBAP_MiningRegister)this);
		FSBAP_MiningRegister_FW.jbInitBtn((FSBAP_MiningRegister)this);
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCond(FSBAP_MiningRegister p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.columnCond_panel_name = p.beansFactory.createTableColumn("Cond.panel_name", MCColumnType.TEXT);
		p.columnCond_radio = p.beansFactory.createTableColumn("Cond.radio", MCColumnType.TEXT_COMBO);
		p.columnCond_radio_nm = p.beansFactory.createTableColumn("Cond.radio_nm", MCColumnType.TEXT);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP_MiningRegister p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_apply = p.beansFactory.createButton("Btn.apply", "upd");
	}

	/**
	 * [Cond]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCond(FSBAP_MiningRegister p) {
		// ブロック関連の初期化
		p.CondPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP_MiningRegister p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.setLastBeans(p.BtnPanel);
		p.BtnPanel.setValueCheck(false);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_apply.setIcon("REGISTER");
		p.Btn_apply.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_apply);
		p.BtnPanel.setLastBeans(p.Btn_apply);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_MiningRegister_FW.mcInitCond((FSBAP_MiningRegister)this);
		FSBAP_MiningRegister_FW.mcInitBtn((FSBAP_MiningRegister)this);

		// [ENABLE]ステータスのモードの設定
		FSBAP_MiningRegister_FW.statusInitENABLE_Cond((FSBAP_MiningRegister)this);
		FSBAP_MiningRegister_FW.statusInitENABLE_Btn((FSBAP_MiningRegister)this);

	}

	/**
	 *  [Cond]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCond(FSBAP_MiningRegister p) {
		p.columnCond_panel_name.addAllListener(p);
		p.columnCond_panel_name.setListListener(p);
		p.columnCond_radio.addAllListener(p);
		p.columnCond_radio.setListListener(p);
		p.columnCond_radio_nm.addAllListener(p);
		p.columnCond_radio_nm.setListListener(p);
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP_MiningRegister p) {
		p.Btn_apply.addAllListener(p);
		p.Btn_apply.setAPMethodName("doBtn_apply");
	}

	/**
	 * [ENABLE]ステータスの[Cond]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Cond(FSBAP_MiningRegister p){
		p.columnCond_panel_name.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.columnCond_radio.putMode(p, ENABLE, MCMode.ENABLE);
		p.columnCond_radio_nm.putMode(p, ENABLE, MCMode.READ_ONLY);

	}

	/**
	 * [ENABLE]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Btn(FSBAP_MiningRegister p){
		p.Btn_apply.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return ENABLE;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_MiningRegister_FW.setTableConfigCond((FSBAP_MiningRegister)this);
	}

	/**
	 * [Cond]ブロックのTableの設定
	 */
	protected static void setTableConfigCond(FSBAP_MiningRegister p) {
		p.columnCond_panel_name.setMeta(mcframe.clientFSBA.FSBAP0770.CondR.panel_name_META);
		p.CondTable.addColumnConfig(p.columnCond_panel_name);
		p.columnCond_radio.setMeta(mcframe.clientFSBA.FSBAP0770.CondR.radio_META);
		p.columnCond_radio.addLinkBeans(p.columnCond_radio_nm);
		p.CondTable.addColumnConfig(p.columnCond_radio);
		p.columnCond_radio_nm.setMeta(mcframe.clientFSBA.FSBAP0770.CondR.radio_nm_META);
		p.CondTable.addColumnConfig(p.columnCond_radio_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnCond_radio.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnCond_radio.getListConfig().setPutter(getCond_radio_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [Cond_radio_ListPutter]の作成
	 */
	protected MCListPutter createCond_radio_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnCond_radio) return getCond_radio(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_apply) doBtn_apply(info);
	}

	/**
	 * [Btn]パネルの[apply]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_apply(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == columnCond_panel_name) return doCond_panel_name_VC(info);
		if (vc == columnCond_radio) return doCond_radio_VC(info);
		if (vc == columnCond_radio_nm) return doCond_radio_nm_VC(info);
		return true;
	}

	/**
	 * [Cond]パネルの[panel_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_panel_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[radio]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_radio_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cond]パネルの[radio_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCond_radio_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == columnCond_panel_name) doCond_panel_name_NC(info);
		else if (nc == columnCond_radio) doCond_radio_NC(info);
		else if (nc == columnCond_radio_nm) doCond_radio_nm_NC(info);
	}

	/**
	 * [Cond]パネルの[panel_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_panel_name_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_NC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == columnCond_panel_name) doCond_panel_name_NE(info);
		else if (ne == columnCond_radio) doCond_radio_NE(info);
		else if (ne == columnCond_radio_nm) doCond_radio_nm_NE(info);
	}

	/**
	 * [Cond]パネルの[panel_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_panel_name_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_NE(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == columnCond_panel_name) doCond_panel_name_NX(info);
		else if (nx == columnCond_radio) doCond_radio_NX(info);
		else if (nx == columnCond_radio_nm) doCond_radio_nm_NX(info);
	}

	/**
	 * [Cond]パネルの[panel_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_panel_name_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_NX(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnCond_panel_name) doCond_panel_name_LC(info);
		else if (lc == columnCond_radio) doCond_radio_LC(info);
		else if (lc == columnCond_radio_nm) doCond_radio_nm_LC(info);
	}

	/**
	 * [Cond]パネルの[panel_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_panel_name_LC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_LC(MCEventInfo info){
	}

	/**
	 * [Cond]パネルの[radio_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCond_radio_nm_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnCond_radio]の作成メソッド
	 */
	public MCList getCond_radio(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}