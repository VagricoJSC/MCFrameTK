package mcframe.clientFSBA.FSBAP0770;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSBA.FSBAP0360.FSBAP_SumInfo;
import mcframe.clientFSBA.FSBAP0360.InfoDtlR;
import mcframe.clientFSBA.FSBAP0780.MethodOptR;
import mcframe.clientFSBA.FSBAP0780.MethodR;
import mcframe.clientFSBA.FSBAP0780.MiningR;
import mcframe.clientFSBA.FSBAP0780.SumCondParamR;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil;
import mcframe.commonFS.constant.FSC_DATA_TYPE;
import mcframe.commonFS.constant.FSC_SUM_INFO_TYPE;

import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.resource.MCRowFilterData;
import mcframe.clientCore.expression.MCExpressionBuilder;
import mcframe.clientCore.mining.IfMCMiningBase;
import mcframe.clientCore.mining.MCMiningUtil;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.sys.MCSys;
import mcframe.commonCore.expression.MCAggregateFunctions;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCParam;

import java.util.HashMap;
import java.util.Map;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_MiningRegister"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_MiningRegister_FW extends FSBAP_MiningRegister_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 登録成功時のモード
	 */
	protected static final String MODE_INS_SUCCESS = "INS_SUCCESS";

	/**
	 * 集計情報画面
	 */
	protected FSBAP_SumInfo _sumInfo = null;

	/**
	 * 集計対象の画面
	 */
	protected MCRootPanel _scr = null;

	/**
	 * 集計対象オペレーションのモジュールID
	 */
	protected String _opeModuleID = null;
	/**
	 * 集計対象オペレーションのロジックID
	 */
	protected String _opeLogicID = null;
	/**
	 * 集計対象オペレーションのオペレーションID
	 */
	protected String _opeOperationID = null;

	/**
	 * 集計対象の通信項目
	 * キー：リソースキー、値：インデックス項目名
	 */
	protected Map<String, String> _colMap = null;

	/**
	 * 集計対象の検索枠の GUI 部品のリスト
	 * 第一要素：String（枠名）、第二要素：MCRowBeans（GUI部品）
	 */
	protected List<Object[]> _compos = new ArrayList<Object[]>();

	/**
	 * 集計対象の検索枠の GUI 部品とリソースキーのリスト
	 * 第一要素：MCRowBeans（GUI部品）、第二要素：String（リソースキー）
	 */
	protected List<Object[]> _field_key_list = new ArrayList<Object[]>();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_MiningRegister_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_MiningRegister_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[apply]の押下時の処理
	 */
	@Override
	public void doBtn_apply(MCEventInfo info) {
		callFS_FSBAL0760_Ins01();
	}

	@Override
	protected void setInitValueFromInput(mcframe.clientFSBA.FSBAP0780.CondR condR) {
		CondR r = (CondR) condR;
		if (!condR.editable_flg()) {
			MCRowBeans c = getRowBeans(r);
			if (c != null && c instanceof MCButtonGroup) {
				r.init_val(r.radio());
				return;
			}
		}
		super.setInitValueFromInput(condR);
	}

	@Override
	public void doCond_editable_flg_NC(MCEventInfo info){
		CondR o = (CondR) getCondL().get(info.getEventIndex());
		if (o == null) {
			return;
		}
		MCRowBeans c = getRowBeans(o);

		// ラジオボタンとチェックボックスは編集可の場合必須項目
		if (c instanceof MCButtonGroup) {
			o.require_flg(o.editable_flg());
		}
		else if (c instanceof MCCheckBox) {
			o.require_flg(o.editable_flg());
		}

		// 編集可にした場合も値を残しておく（ON/OFF切替を見越して）
	}

	@Override
	public MCList<?> getCond_radio(MCRow row, MCEventInfo info) {
		return getRadioList(row, info);
	}

	// FSBAP0310がベース
	/**
	 * ラジオボタンのコンボリストに表示するリストを返します。
	 *
	 * @param row
	 * @param info
	 * @return コンボリスト
	 */
	protected MCList<MCRow> getRadioList(MCRow row, MCEventInfo info) {
		int index = info.getEventIndex();
		if (getCondL().size() <= index) {
			return null;
		}

		MCRowBeans c = getRowBeans((CondR) getCondL().get(index));
		if (!(c instanceof MCButtonGroup)) {
			return null;
		}

		MCList<MCRow> list = MCList.create(MCRow.class);
		for (MCRadioButton b : ((MCButtonGroup)c).getRadioButtons()) {
			MCModeInfo i = b.getModeInfo();
			if (i != null && i.getStatus() == MCMode.ENABLE_STATUS) {
				MCRow d = MCRow.create();
				d.addStringColumn(CondR.$radio, b.getActionCommand());
				d.addStringColumn(CondR.$radio_nm, getRadioButtonName(b));
				list.add(d);
			}
		}
		return list;
	}

	// FSBAP0310がベース
	/**
	 * ラジオボタンのコンボリストに表示するラジオボタン名を返します。
	 *
	 * @param compo ラジオボタン
	 * @return ラジオボタン名
	 */
	protected String getRadioButtonName(MCRadioButton compo) {
		String n = compo.getLabelByLocale();
		if (!isNull(n)) {
			return n;
		}
		n = compo.getMessageByLocale();
		if (!isNull(n)) {
			return n;
		}
		return null;
	}

	// FSBAP0310がベース
	/**
	 * 検索条件に対応する画面部品を返します。
	 *
	 * @param data 検索条件
	 * @return 画面部品
	 */
	protected MCRowBeans getRowBeans(CondR data) {
		List<Object[]> oal = _compos;
		List<Object[]> okl = _field_key_list;
		if (oal == null || okl == null) {
			return null;
		}
		for (Object[] oa : oal) {
			MCRowBeans c = (MCRowBeans)oa[1];

			String k = null;
			for (Object[] ka : _field_key_list) {
				if (c.equals(ka[0])) {
					k = (String)ka[1];
					break;
				}
			}

			if (MCStringUtil.eq(k, data.field_key())) {
				return c;
			}
		}
		return null;
	}


	@Override
	protected void beansAttrInit() {
		super.beansAttrInit();

		setModeForFS_FSBAL0760_Ins01(MODE_INS_SUCCESS);
	}

	@Override
	public void layoutInit() {
		// 使用しないので取り除く
		MethodPanel.getParent().remove(MethodPanel);
		MethodOptPanel.getParent().remove(MethodOptPanel);

		// タブ移動順調整
		CondPanel.setNextBeans(BtnPanel);

		super.layoutInit();
	}


	@Override
	protected void listInit() {
		super.listInit();

		columnCond_radio.setListVisibleColumn(CondR.$radio, CondR.$radio_nm);
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		// カラム順調整
		CondTable.moveColumns(CondTable.getStatusColumn(), columnCond_panel_name);
		CondTable.moveColumns(columnCond_text, columnCond_radio, columnCond_radio_nm);

// 2016/11/17 SplitPaneで分割しているため消えない -> MethodPanelを取り除く
//		// テーブル非表示
//		MethodTable.setMode(MCMode.INVISIBLE);
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		// ポップアップはなし
		return FSUCP_PopupConfig.REMOVE_ALL;
	}

	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			if (args == null || args.length < 1) {
				// 引数不正
				throw new MCAppException(msgUnknownOpenParam());
			}
// 2016/09/20 エラー時に呼び出し元に返せないため対応を保留
//			// アプリ共通層でCallerを取得する都合上、イベントディスパッチスレッドでの実行を保証
//			SwingUtilities.invokeLater(() -> {
//				sumInfoInit((FSBAP_SumInfo) args[0]);
//				valueInit();
//			});
			sumInfoInit((FSBAP_SumInfo) args[0]);
		}
		else {
			// タイプ不正
			throw new MCAppException(msgUnknownOpenParam());
		}
		valueInit();
	}

	// FSBAP0310のsetInitDataがベース
	/**
	 * 集計情報を初期化します。
	 *
	 * @param sumInfo 集計情報画面
	 * @throws MCException [FSBAC0044]
	 *                     sumInfo が IfSrchCndBase インターフェースを実装していない場合
	 * @throws MCException [FSBAC0070] sumInfo がマイニングに対応していない場合
	 * @throws MCException [FSBAC0083]
	 *                     マイニング用Callerに検索条件のRowが設定されていない場合
	 * @throws MCException [FSBAC0091] カラムが通信項目にない場合
	 * @throws MCException [FCBEC0059] 計算式に文法エラーがある場合
	 */
	protected void sumInfoInit(FSBAP_SumInfo sumInfo) {
		_sumInfo = sumInfo;
		_compos.clear();
		_field_key_list.clear();

		_scr = _sumInfo.getParentPanel();
		if (_scr == null) {
			throw new MCAppException(FSBAC0044, null, null);
		}
		if (!(_scr instanceof IfSrchCndBase)) {
			throw new MCAppException(
					FSBAC0044, _scr.getModuleID(), _scr.getScreenID());
		}
		if (!(_scr instanceof IfMCMiningBase)) {
			// マイニング非対応画面
			throw new MCAppException(
					FSBAC0070, _scr.getModuleID(), _scr.getScreenID());
		}

		// 通信定義
		MCContainerDef[] cdefs = getMiningDef((IfMCMiningBase) _scr);
		if (cdefs == null) {
			// マイニング非対応画面
			throw new MCAppException(
					FSBAC0070, _scr.getModuleID(), _scr.getScreenID());
		}
		// 検索条件はない場合があるので、下り定義から取得
		_opeModuleID = cdefs[1].moduleId();
		_opeLogicID = cdefs[1].logicId();
		_opeOperationID = cdefs[1].operationId();

		// 検索条件
		List<Object[]> actives = new ArrayList<>();
		MCRow condRow = MCMiningUtil.getConditionRow((IfMCMiningBase) _scr);
		if (condRow == null) {
			// 検索条件Rowなし
			if (cdefs[0] != null) {
				// 通信定義には検索条件あり
				throw new MCAppException(FSBAC0083,
										_scr.getModuleID(), _scr.getScreenID(),
										_opeModuleID, _opeLogicID, _opeOperationID);
			}
		}
		else {
			// 検索条件Rowあり -> 検索条件にあるBeanのみ採用
			_compos = FXUCP_SrchCndUtil.getSrchCndBeans((IfSrchCndBase) _scr, true);
			for (Object[] compo : _compos) {
				MCRowBeans c = (MCRowBeans) compo[1];
				MCRow beanRow = c.getRow().getRootRow();// 701-04159 InnerRowの場合ルートで判定
				if (condRow.getClass() == beanRow.getClass()) {
					// 同じクラスなら検索用
					actives.add(compo);
				}
			}
		}
		_compos = actives;
		_field_key_list = FXUCP_SrchCndUtil.createGUIKeyList(_compos);
		_colMap = createKeyIndexMap(cdefs[0]);

		// 集計情報
		try {
			setMethodLFromSumInfo(_sumInfo, cdefs[1]);
		}
		catch (MCException e) {
 			((IfMCMiningBase) _scr).handleInitError(e);
		}
	}

	/**
	 * マイニング用のコンテナの電文定義を取得します。
	 *
	 * 戻り値の配列には次の定義が格納されています。<br>
	 * <dl>
	 * <dt>インデックス0</dt>
	 * <dd>検索オペレーションの上り第１ブロックの電文定義</dd>
	 * <dd>検索条件がないオペレーションの場合は null</dd>
	 * <dt>インデックス1</dt>
	 * <dd>検索オペレーションの下り第１ブロックの電文定義</dd>
	 * </dl>
	 *
	 * @param _scr 検索画面
	 * @return 電文定義。マイニング非対応の場合は null
	 */
	protected MCContainerDef[] getMiningDef(IfMCMiningBase _scr) {
		MCCaller<?, ?> caller = _scr.getMiningCaller();
		if (caller == null) {
			return null;
		}
		MCCallerPanelBridge bridge = caller.getBridge();
		MCParam param = bridge.createAsyncParam();
		MCContainerDef[] cdefs = new MCContainerDef[2];
		cdefs[0] = MCMiningUtil.getCondDef(param);
		cdefs[1] = MCMiningUtil.getMethodDef(param);
		return cdefs;
	}

	/**
	 * GUI部品のリソースキーと電文インデックス項目のマップを作成します。
	 *
	 * @param updef 上り電文定義
	 * @return マップ
	 */
	protected Map<String, String> createKeyIndexMap(MCContainerDef updef) {
		Map<String, String> colMap = new HashMap<>();
		for (Object[] ka : _field_key_list) {
			String col = ((MCRowBeans) ka[0]).getBaseRowColumnName();
			String index = MCMiningUtil.getIndexForDefID(updef, col);
			if (index != null) {
				// インデックスあり -> 通信項目
				// インデックスなし -> 通信対象外（エラーではない）
				colMap.put((String) ka[1], index);
			}
		}
		return colMap;
	}

	/**
	 * 集計情報画面から集計情報を設定します。
	 *
	 * @param sumInfo 集計情報画面
	 * @param downdef 下り電文定義
	 * @throws MCException [FSBAC0091] カラムが通信項目にない場合
	 */
	protected void setMethodLFromSumInfo(FSBAP_SumInfo sumInfo, MCContainerDef downdef) {
		// 登録時にサーバ側で項目IDを取得するため、画面のコンテナ項目を電文INDEXに修正する。
		List<String> idList = new ArrayList<>();	// コンテナ項目
		List<String> indexList = new ArrayList<>();	// インデックス項目
		for (MCItemDef def : downdef.transItems()) {
			if (def.isIgnore()) {
				continue;
			}
			idList.add(def.id);
			indexList.add(MCMiningUtil.getIndexForDefID(downdef, def.id));
		}
		// 集計後計算式変換用
		List<String> sumnameList = new ArrayList<>();	// 表示集計項目
		List<String> sumindexList = new ArrayList<>();	// インデックス項目
		MCList<InfoDtlR> suminfoL = _sumInfo.getInfoDtlL();
		// 集計条件名の重複チェック
		MCMessageList results = new MCMessageList();
		checkDuplicate(results, suminfoL.subList(r -> !isNull(r.sumcond())),
				_sumInfo.InfoDtlTable, InfoDtlR.$sumcond);
		if (results.size() != 0) {
			MCAppException e = new MCAppException(FSBAC0093);
			e.setCauseMessageList(results);
			throw e;
		}

		suminfoL.forEach(suminfoR -> {
			FSC_SUM_INFO_TYPE type = FSC_SUM_INFO_TYPE.getNE(suminfoR.sum_info_type());
			if (!(type == null
					|| FSC_SUM_INFO_TYPE.isTYPE_GROUP(type)
					|| FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type))
			) {
				String sumcond = suminfoR.sumcond();
				if (FSC_SUM_INFO_TYPE.isTYPE_COUNT(type)) {
					// 件数 は電文ではないが、変換処理で存在する必要があるため変換前後で同じ文字列を設定する
					String sumindex = MCMiningUtil.createSumColumnId(
							MCMiningUtil.COUNT_GROUP, sumcond, type.value());
					sumnameList.add(sumindex);
					sumindexList.add(sumindex);
				}
				else {
					// 集計結果
					String sumname = _sumInfo.createRsltColumnName(
								suminfoR.column_key(), sumcond, type);
					sumnameList.add(sumname);
					String index = MCMiningUtil.getIndexForDefID(
												downdef, suminfoR.column_key());
					String colid = (index != null) ? index : suminfoR.column_key();
					String sumindex = MCMiningUtil.createSumColumnId(
												colid, sumcond, type.value());
					sumindexList.add(sumindex);
				}

			}
		});


		MCList<MethodR> methodL = getMethodL();
		suminfoL.forEach(infoR -> {
			if (infoR.isEmpty() || infoR.isStatusDelete()) {
				// 空行は除外
				return;
			}
			MethodR methodR = methodL.createRow();
			methodR.setValuesByName(infoR);
			FSC_SUM_INFO_TYPE type = FSC_SUM_INFO_TYPE.getNE(methodR.sum_info_type());

			// 小数点桁数の補完
			if (FSC_SUM_INFO_TYPE.isTYPE_AVG(type)) {
				if (isNull(methodR.dec_place())) {
					// 小数桁数未設定の場合は画面の定義を使用
					MCNumber num =
							_sumInfo.getTargetColumnDecPlace(methodR.column_key());
					methodR.dec_place(num);
				}
			}

			// コンテナ項目名を電文インデックス項目に変換
			String index = MCMiningUtil.getIndexForDefID(downdef, methodR.column_key());
			if (index != null) {
				// インデックスあり -> 通信項目
				methodR.column_key(index);
			}
			else {
				// インデックスなし -> そのまま（集計時用の一時カラムとみなす）

				// 計算式の項目変換
				String formula = methodR.formula_calc();
				if (!isNull(formula)) {
					// 計算式あり
					MCExpressionBuilder eb = new MCExpressionBuilder();
					if (FSC_SUM_INFO_TYPE.isTYPE_AFTER_CALC(type)) {
						// 集計後計算
						// リストはダミー
						eb.addFunctions(new MCAggregateFunctions(MCList.create(MCRow.class)));
						formula = convInitFormula(eb, formula, sumnameList, sumindexList);
					}
					else {
						// 計算式
						formula = convInitFormula(eb, formula, idList, indexList);
					}
					methodR.formula(formula);
				}
				else {
					// 計算式なし
					if (isSame(MCMiningUtil.COUNT_GROUP, methodR.column_key())) {
						// 件数 -> そのまま
					}
					else {
						// 通信項目にないカラム
						throw new MCAppException(FSBAC0091, methodR.column_nm());
					}
				}
			}

			methodL.add(methodR);

			// オプション
			// 登録時はMethodOptRからMethodRへ補完が働くため設定する必要がある
			MethodOptR optR = getMethodOptR();
			if (methodR.rank()) {
				optR.rank_type(methodR.rank_type());
				optR.rank_size(methodR.rank_size());
			}
			if (methodR.fill_dt()) {
				optR.fill_dt_fm(methodR.fill_dt_fm());
				optR.fill_dt_to(methodR.fill_dt_to());
			}

			// 集計条件
			setSumCondFromSumInfo(infoR, downdef, idList, indexList);
		});
	}

	/**
	 * 集計条件を設定します。
	 *
	 * @param infoR 集計情報
	 * @param downdef 下り電文定義
	 * @param idList コンテナ項目
	 * @param indexList インデックス項目
	 * @throws MCException [FSBAC0091] カラムが通信項目にない場合
	 */
	protected void setSumCondFromSumInfo(
								InfoDtlR infoR, MCContainerDef downdef,
								List<String> idList, List<String> indexList
	) {
		// 2016/12/08 RowFilterからの変換は、MCSumInfoResourceIO#writeSumCond参照

		String sumcond = infoR.sumcond();
		List<MCRowFilter> filters = _sumInfo.getSumCondList(infoR);
		if (sumcond == null || filters == null) {
			return;
		}

		MCTable<?> targetTable = _sumInfo.getTargetTable();
		int cnt = 0;
		for (MCRowFilter filter : filters) {
			MCRowFilterData data = targetTable.toRowFilterData(filter);
			MCDataType type = data.getDataType();
			String value = data.getConditionValue();

			// 集計条件のコンテナ項目名を電文インデックス項目に変換
			MCExpressionBuilder eb = new MCExpressionBuilder();
			String index = convInitFormula(eb, data.getColumnName(), idList, indexList);
			data.setColumnName(index);
			if (type == MCDataType.DATE || type == MCDataType.TIMESTAMP) {
				// 日付型条件値内のコンテナ項目名をインデックス項目名に変換
				value = MCMiningUtil.convSumCondDateForIndex(value, downdef);
			}

			SumCondParamR condR = getSumCondParamL().add();
			condR.sumcond(sumcond);
			condR.list_order(cnt++);
			condR.col_id(data.getColumnName());
			condR.data_typ(FSC_DATA_TYPE.db_key(type.toString()));
			condR.cond_val(value);
			condR.relative_ope(data.getRelativeOperator());
			condR.logic_ope(data.getLogicOperator());
			condR.inv_flg(data.isDisable());
		}
	}

	/**
	 * 画面初期化用に、計算式中のカラム名を通信項目に変換します。
	 *
	 * @param eb 変換用のExpressionBuilder
	 * @param formula 計算式（カラム名のみの場合あり）
	 * @param fromList 変換前カラム名リスト（画面項目）
	 * @param toList 変換後カラム名リスト（通信項目）
	 * @return 変換した計算式
	 * @throws MCException [FSBAC0091] カラムが通信項目にない場合
	 */
	private String convInitFormula(MCExpressionBuilder eb, String formula, List<String> fromList, List<String> toList) {
		try {
			return eb.convertVariables(formula, fromList, toList);
		}
		catch (MCException e) {
			// コンテナ項目が通信項目になければエラー
			if (FCBEC0059.equals(e.getID())) {
				String col = e.getBind(1);
				throw new MCAppException(e, FSBAC0091, col);
			}
			throw e;
		}
	}

	@Override
	protected void valueInit() {
		// 基本情報
		initMiningR();

		// 検索条件
		setCondLFromSrchCndBase((IfSrchCndBase) _scr);

		super.valueInit();
	}

	/**
	 * マイニング情報を初期化します。
	 *
	 */
	protected void initMiningR() {
		MiningR miningR = getMiningR();
		miningR.mining_nm(_sumInfo.ListDtlTable.getSelectedMCRow().sum_info_nm());
		miningR.user_id(MCSys.user.ID());
		miningR.co_cd(MCSys.user.coCD());
		miningR.public_lv(MCSys.user.ID());
		miningR.module_id(_opeModuleID);
		miningR.logic_id(_opeLogicID);
		miningR.operation_id(_opeOperationID);
		miningR.scr_module_id(_scr.getModuleID());
		miningR.screen_id(_scr.getScreenID());
		miningR.screen_nm(_scr.getScreenName());
		miningR.description_text(_sumInfo.ListDtlTable.getSelectedMCRow().remark());
		String size = MCConst.app.getString(MCConst.createKey("FS", "FSBAP0770", "gadget", "size"));
		miningR.gadget_size(size);
		miningR.md_gadget_size(size);

		// 表示用データ補完
		setDisplayData(miningR);
	}

	/**
	 * 入力値設定から検索条件を設定します。
	 *
	 * @param bp 入力値設定
	 */
	protected void setCondLFromSrchCndBase(IfSrchCndBase bp) {
		List<Object[]> pnl = MCBeansUtil.getPanelNameList((MCRootPanel) bp);
		MCList<CondR> nl = createCondL();
		for (Object[] oa : _compos) {
			MCRowBeans c = (MCRowBeans) oa[1];
			String k = null;
			for (Object[] ka : _field_key_list) {
				if (c.equals(ka[0])) {
					k = (String) ka[1];
					break;
				}
			}
			if (!_colMap.containsKey(k)) {
				// 非通信項目
				continue;
			}

			CondR n = nl.createRow();
			//n.mining_id();
			n.panel_name(getPanelLabelName(c, pnl));
			n.col_id(_colMap.get(k));
			n.col_nm(FXUCP_SrchCndUtil.getMessageName(c));
			n.field_key(k);
			//n.list_order();
			n.scr_itm_id(MCScreenOpener.createGUIKey(c));
			//n.md_itm_id();
			n.data_typ(FSC_DATA_TYPE.db_key(c.getDataType().toString()));
			n.editable_flg(false);
			n.require_flg(false);
			//n.init_val();

			// 画面の値を設定
			setCondValue(c, n);

			n.setStatus(MCRow.GUICREATE);
			nl.add(n);
		}
		setCondL(nl);
		validateList(nl);
	}

	// FSBAP0310がベース
	/**
	 * 枠のラベル名を返します。
	 *
	 * @param compo GUI 部品
	 * @param list リスト（第一要素：GUI 部品、第二要素：MCRootPanel、または MCPanel、第三要素：枠名、または null）
	 * @return 枠のラベル名、または null
	 */
	protected String getPanelLabelName(MCRowBeans compo, List<Object[]> list) {
		if (compo instanceof MCButtonGroup) {
			MCRadioButton o = ((MCButtonGroup)compo).getSelectedButton();
			if (o != null) {
				for (Object[] a : list) {
					if (o.equals(a[0])) {
						return (String)a[2];
					}
				}
			}
		}
		else {
			for (Object[] a : list) {
				if (compo.equals(a[0])) {
					return (String)a[2];
				}
			}
		}
		return null;
	}

	// FXUCP0070がベース
	/**
	 * 検索条件に関する情報を設定します。
	 *
	 * @param prefix リソースキーの接頭辞
	 * @param panel 画面
	 * @param name 枠名
	 * @param label 枠のラベル名
	 * @param compo GUI 部品
	 * @param field_key GUI 部品のリソースキー
	 * @param data 設定する情報を格納したコンテナ
	 * @return 情報を設定したコンテナ
	 */
	protected void setCondValue(MCRowBeans compo, CondR condR) {
		if (compo == null || condR == null) {
			return;
		}

		MCDataType y = compo.getDataType();
		if (y == null) {
			return;
		}

		switch (y) {
		case STRING:
			if (compo instanceof MCButtonGroup) {
				setRadioValue((MCButtonGroup) compo, condR);
			}
			else {
				setTextValue(compo, condR);
			}
			break;
		case BOOLEAN:
			setCheckValue(compo, condR);
			break;
		case DATE:
			setDateValue(compo, condR);
			break;
		case TIMESTAMP:
			setTimestampValue(compo, condR);
			break;
		case NUMBER:
			setNumberValue(compo, condR);
			break;
		default:
			break;
		}
	}
	/**
	 * 検索条件に関する情報（ラジオボタン項目）を設定します。
	 *
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setRadioValue(MCButtonGroup compo, CondR condR) {
		MCRadioButton rb = compo.getSelectedButton();
		if (rb == null) {
			return;
		}
		condR.radio(rb.getActionCommand());
		condR.radio_nm(getRadioButtonName(rb));
	}
	/**
	 * 検索条件に関する情報（文字列項目）をコンテナに設定します。
	 *
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setTextValue(MCRowBeans compo, CondR condR) {
		if (!MCDataType.STRING.equals(compo.getDataType())) {
			return;
		}
		condR.text((String) compo.getRowValue());
	}
	/**
	 * 検索条件に関する情報（チェックボックス項目）をコンテナに設定します。
	 *
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setCheckValue(MCRowBeans compo, CondR condR) {
		if (!MCDataType.BOOLEAN.equals(compo.getDataType())) {
			return;
		}
		condR.check((Boolean) compo.getRowValue());
	}
	/**
	 * 検索条件に関する情報（日付項目）をコンテナに設定します。
	 *
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setDateValue(MCRowBeans compo, CondR condR) {
		if (!MCDataType.DATE.equals(compo.getDataType())) {
			return;
		}
		MCDate v = (MCDate) compo.getRowValue();
		condR.date(v != null ? v.toMCTimestamp() : null);
	}
	/**
	 * 検索条件に関する情報（タイムスタンプ項目）をコンテナに設定します。
	 *
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setTimestampValue(MCRowBeans compo, CondR condR) {
		if (!MCDataType.TIMESTAMP.equals(compo.getDataType())) {
			return;
		}
		MCTimestamp v = (MCTimestamp) compo.getRowValue();
		condR.date(v);
	}
	/**
	 * 検索条件に関する情報（数値項目）をコンテナに設定します。
	 *
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setNumberValue(MCRowBeans compo, CondR condR) {
		if (!MCDataType.NUMBER.equals(compo.getDataType())) {
			return;
		}
		condR.num((MCNumber) compo.getRowValue());
	}

	// FSBAP0310がベース
	/**
	 * 検索条件の内容を検証します。
	 *
	 * @param nl 検索条件リスト
	 */
	protected void validateList(MCList<CondR> nl) {
		MCMessageList ml = nl.validate(CondR.$text);
		for (int i = 0; i < ml.size(); i++) {
			MCMessage m = ml.get(i);
			if (m.getID().equals(FCBBC0063)) {
				CondR r = (CondR) m.getCauseRow();
				ml.set(i,
						new MCMessage(r, CondR.$text, FSBAC0014,
								r.getGUIIndex() + 1, columnCond_text
										.getLabelByLocale(), r.text(), r.text()
										.length(), CondR.text_META.length()));
				r.text(null);// 桁あふれの場合はnullに変更
			}
		}
		if (ml.size() > 0) {
			message(ml);
		}
	}

	@Override
	public void setStatus(String status) {
		if (MODE_INS_SUCCESS.equals(status)) {
			requestCloseWindow();
			return;
		}

		super.setStatus(status);

		// ユーザに登録するので、権限は空固定
		Mining_func_typ.setMode(MCMode.READ_ONLY);
	}


	/**
	 * 検索条件テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 検索条件テーブルに設定するセルコンフィグ
	 */
	@Override
	protected FXBAP_CellConfig createCondCellConfig() {
		return new FSBAP_Register_CellConfig();
	}

	// FSBAP0310がベース
	/**
	 * 検索条件一覧のカラムコンフィグです。
	 *
	 */
	public class FSBAP_Register_CellConfig extends FSBAP_Cond_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			// 画面コンポーネントの基づく制御のみ
			// それ以外の制御はスーパークラスに委ねる
			CondR o = (CondR) getCondL().get(index);

			if (!isDefaultModeEditable(column)) {
				if (column == columnCond_radio_nm) {
					if (o.editable_flg()) {
						return MCMode.DISABLE;
					}
				}
				return super.getPriorMode(index, column, table);
			}

			List<Object[]> a = _compos;
			if (a == null || a.size() <= index) {
				return super.getPriorMode(index, column, table);
			}

			MCRowBeans c = getRowBeans(o);
			if(c == null) {
				// 一覧にない場合
				return MCMode.READ_ONLY;
			}

			// 701-06574 変更不可項目
 			String[] fixes = ((IfMCMiningBase) _scr).getFixedColumns();
 			if (fixes != null) {
 	 			for (String fix : fixes) {
 	 				if (isSame(o.scr_itm_id(), fix)) {
 	 					return MCMode.READ_ONLY;
 	 				}
 	 			}
 			}

			if (column == columnCond_require_flg) {
				if (!o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (c instanceof MCButtonGroup) {
					return MCMode.READ_ONLY;
				}
				else if (c instanceof MCCheckBox) {
					return MCMode.READ_ONLY;
				}
				else if (c instanceof MCModeBeans) {
					if (!c.getRequiredFlg()
							&& isReqMode(((MCModeBeans)c).getMode())) {
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnCond_radio) {
				if (o.editable_flg()) {
					return MCMode.DISABLE;
				}

				if (!(c instanceof MCButtonGroup)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnCond_text) {
				if (c instanceof MCButtonGroup) {
					return MCMode.READ_ONLY;
				}
			}

			return super.getPriorMode(index, column, table);
		}
	}

}