package mcframe.clientFSBA.FSBAP0770;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cond"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CondR_FW_A extends mcframe.clientFSBA.FSBAP0780.CondR {

	/**
	 *  枠名.<p>
	 *
	 */
	public static final String $panel_name = "panel_name";
	/**
	 *  項目リソースキー.<p>
	 *
	 */
	public static final String $field_key = "field_key";
	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public static final String $radio = "radio";
	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public static final String $radio_nm = "radio_nm";


	public static final MCMeta panel_name_META = createStringMeta($panel_name);
	public static final MCMeta field_key_META = createStringMeta($field_key);
	public static final MCMeta radio_META = createStringMeta($radio);
	public static final MCMeta radio_nm_META = createStringMeta($radio_nm);

	protected static final ConstMetaList<CondR> constMetas = new ConstMetaList<CondR>(
		mcframe.clientFSBA.FSBAP0780.CondR.constMetas,
		new MCMeta[]{
			panel_name_META,
			field_key_META,
			radio_META,
			radio_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		mcframe.clientFSBA.FSBAP0780.CondR.KEYS,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		mcframe.clientFSBA.FSBAP0780.CondR.EXTMAP
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CondR_FW_A(ConstMetaList<? extends CondR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CondR clone() {
		return (CondR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CondR createInstance() {
		return (CondR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CondR getValues(String... names) {
		return (CondR) super.getValues(names);
	}



	/**
	 *  枠名.<p>
	 *
	 */
	public String panel_name() {
		return getConstString(offset + 0, $panel_name);
	}

	/**
	 *  枠名.<p>
	 *
	 */
	public void panel_name(String value) {
		setConstString(offset + 0, $panel_name, value);
	}


	/**
	 *  項目リソースキー.<p>
	 *
	 */
	public String field_key() {
		return getConstString(offset + 1, $field_key);
	}

	/**
	 *  項目リソースキー.<p>
	 *
	 */
	public void field_key(String value) {
		setConstString(offset + 1, $field_key, value);
	}


	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public String radio() {
		return getConstString(offset + 2, $radio);
	}

	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public void radio(String value) {
		setConstString(offset + 2, $radio, value);
	}


	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public String radio_nm() {
		return getConstString(offset + 3, $radio_nm);
	}

	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public void radio_nm(String value) {
		setConstString(offset + 3, $radio_nm, value);
	}


	public String getString(String name) {
		if ($panel_name.equalsIgnoreCase(name)) {
			return panel_name();
		}
		if ($field_key.equalsIgnoreCase(name)) {
			return field_key();
		}
		if ($radio.equalsIgnoreCase(name)) {
			return radio();
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			return radio_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($panel_name.equalsIgnoreCase(name)) {
			return panel_name();
		}
		if ($field_key.equalsIgnoreCase(name)) {
			return field_key();
		}
		if ($radio.equalsIgnoreCase(name)) {
			return radio();
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			return radio_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($panel_name.equalsIgnoreCase(name)) {
			panel_name(value);
			return;
		}
		if ($field_key.equalsIgnoreCase(name)) {
			field_key(value);
			return;
		}
		if ($radio.equalsIgnoreCase(name)) {
			radio(value);
			return;
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			radio_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($panel_name.equalsIgnoreCase(name)) {
			panel_name(value);
			return;
		}
		if ($field_key.equalsIgnoreCase(name)) {
			field_key(value);
			return;
		}
		if ($radio.equalsIgnoreCase(name)) {
			radio(value);
			return;
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			radio_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

