package mcframe.clientFSBA.FSBAP0080;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0080"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0080_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0080";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Font]ブロック関連のField定義
	public MCPanel FontPanel = null;
	// [Font]ブロックの項目のField定義
	public MCLabel Font_FontRatio_Label = null;
	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public MCNumberField Font_FontRatio = null;
	public MCLabel Font_NewFontRatio_Label = null;
	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public MCNumberComboBox Font_NewFontRatio = null;
	/**
	 * 画面サイズを合わせて調整する 画面サイズを合わせて調整する.<p>
	 *
	 */
	public MCCheckBox Font_AdjustFrameSize = null;
	// [Command]ブロック関連のField定義
	public MCPanel CommandPanel = null;
	// [Command]ブロックの項目のField定義
	/**
	 * デフォルト デフォルトに戻す.<p>
	 *
	 */
	public MCButton Command_Default = null;
	/**
	 * 設定 設定する.<p>
	 *
	 */
	public MCButton Command_OK = null;
	/**
	 * キャンセル キャンセル.<p>
	 *
	 */
	public MCButton Command_Cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Font]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0080.FontR aFontR;

	/**
	 * 項目コピーによってaFontRを設定します。
	 *
	 * aFontRのインスタンスは変更されません。
	 *
	 * @param row FontR
	 */
	public void setFontR(mcframe.clientFSBA.FSBAP0080.FontR row) {
		if (row != null) {
			MCRow.copyall(getFontR(), row);
		}
	}

	/**
	 * [Font]ブロックのコンテナaFontRを返します。
	 *
	 * @return FontR
	 */
	public mcframe.clientFSBA.FSBAP0080.FontR getFontR() {
		return aFontR;
	}

	/**
	 * aFontRを作成します。
	 *
	 * @return FontR
	 */
	public mcframe.clientFSBA.FSBAP0080.FontR createFontR() {
		return mcframe.clientFSBA.FSBAP0080.FontR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getFontR())) ret.add(getFontR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getFontR()) return "Font";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Font")) return getFontR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(FontPanel);
		ret.add(CommandPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0080_FW_A() {
		aFontR = createFontR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0080_FW.jbCreateFont((FSBAP0080)this);
		FSBAP0080_FW.jbCreateCommand((FSBAP0080)this);
	}

	/**
	 * [Font]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateFont(FSBAP0080 p) {
	}

	/**
	 * [Command]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommand(FSBAP0080 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Font_NewFontRatio_ListPutter]の定義 */
	private MCListPutter Font_NewFontRatio_p = null;

	/**
	 * [Font_NewFontRatio_ListPutter]の取得
	 */
	protected MCListPutter getFont_NewFontRatio_ListPutter() {
		if (Font_NewFontRatio_p == null) {
			Font_NewFontRatio_p = createFont_NewFontRatio_ListPutter(Font_NewFontRatio, "NewFontRatio");

		}
		return Font_NewFontRatio_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0080 create(){
		FSBAP0080 p = new FSBAP0080();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0080_FW.jbfInitFont((FSBAP0080)this);
		FSBAP0080_FW.jbfInitCommand((FSBAP0080)this);
		FSBAP0080_FW.jbInitFont((FSBAP0080)this);
		FSBAP0080_FW.jbInitCommand((FSBAP0080)this);
	}

	/**
	 * [Font]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitFont(FSBAP0080 p) {
		// ブロック関連の初期化
		p.FontPanel = p.beansFactory.createPanel("Font");
		// ブロックの項目の初期化
		p.Font_FontRatio_Label = p.beansFactory.createLabel("Font.FontRatio_Label");
		p.Font_FontRatio = p.beansFactory.createNumberField("Font.FontRatio");
		p.Font_FontRatio.setLabel(p.Font_FontRatio_Label);
		p.Font_NewFontRatio_Label = p.beansFactory.createLabel("Font.NewFontRatio_Label");
		p.Font_NewFontRatio = p.beansFactory.createNumberComboBox("Font.NewFontRatio");
		p.Font_NewFontRatio.setLabel(p.Font_NewFontRatio_Label);
		p.Font_AdjustFrameSize = p.beansFactory.createCheckBox("Font.AdjustFrameSize");
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommand(FSBAP0080 p) {
		// ブロック関連の初期化
		p.CommandPanel = p.beansFactory.createPanel("Command");
		// ブロックの項目の初期化
		p.Command_Default = p.beansFactory.createButton("Command.Default");
		p.Command_OK = p.beansFactory.createButton("Command.OK");
		p.Command_Cancel = p.beansFactory.createButton("Command.Cancel");
	}

	/**
	 * [Font]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitFont(FSBAP0080 p) {
		// ブロック関連の初期化
		p.add(p.FontPanel);
		p.setLastBeans(p.FontPanel);
		p.FontPanel.setNextBeans(p.CommandPanel);
		p.FontPanel.setValueCheck(false);
		// ブロックの項目の初期化
		p.FontPanel.add(p.Font_FontRatio_Label);
		p.FontPanel.add(p.Font_FontRatio);
		p.FontPanel.setLastBeans(p.Font_FontRatio);
		p.Font_FontRatio.setNextBeans(p.Font_NewFontRatio);
		p.Font_FontRatio.setRow(p.getFontR(), mcframe.clientFSBA.FSBAP0080.FontR.FontRatio_META);
		p.Font_NewFontRatio.setListType(MCListType.FREE);
		p.FontPanel.add(p.Font_NewFontRatio_Label);
		p.FontPanel.add(p.Font_NewFontRatio);
		p.Font_NewFontRatio.setNextBeans(p.Font_AdjustFrameSize);
		p.Font_NewFontRatio.setRow(p.getFontR(), mcframe.clientFSBA.FSBAP0080.FontR.NewFontRatio_META);
		p.FontPanel.add(p.Font_AdjustFrameSize);
		p.Font_AdjustFrameSize.setRow(p.getFontR(), mcframe.clientFSBA.FSBAP0080.FontR.AdjustFrameSize_META);
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommand(FSBAP0080 p) {
		// ブロック関連の初期化
		p.add(p.CommandPanel);
		// ブロックの項目の初期化
		p.Command_Default.setFunctionKey(MCFunctionKey.F3);
		p.CommandPanel.add(p.Command_Default);
		p.CommandPanel.setLastBeans(p.Command_Default);
		p.Command_Default.setNextBeans(p.Command_OK);
		p.Command_OK.setFunctionKey(MCFunctionKey.F9);
		p.CommandPanel.add(p.Command_OK);
		p.Command_OK.setNextBeans(p.Command_Cancel);
		p.Command_Cancel.setFunctionKey(MCFunctionKey.F11);
		p.CommandPanel.add(p.Command_Cancel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0080_FW.mcInitFont((FSBAP0080)this);
		FSBAP0080_FW.mcInitCommand((FSBAP0080)this);

		// [INIT]ステータスのモードの設定
		FSBAP0080_FW.statusInitINIT_Font((FSBAP0080)this);
		FSBAP0080_FW.statusInitINIT_Command((FSBAP0080)this);

	}

	/**
	 *  [Font]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitFont(FSBAP0080 p) {
		p.Font_FontRatio.setListListener(p);
		p.Font_FontRatio.addAllListener(p);
		p.Font_NewFontRatio.setListListener(p);
		p.Font_NewFontRatio.addAllListener(p);
		p.Font_AdjustFrameSize.addAllListener(p);
	}

	/**
	 *  [Command]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommand(FSBAP0080 p) {
		p.Command_Default.addAllListener(p);
		p.Command_Default.setAPMethodName("doCommand_Default");
		p.Command_OK.addAllListener(p);
		p.Command_OK.setAPMethodName("doCommand_OK");
		p.Command_Cancel.addAllListener(p);
		p.Command_Cancel.setAPMethodName("doCommand_Cancel");
	}

	/**
	 * [INIT]ステータスの[Font]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Font(FSBAP0080 p){
		p.Font_FontRatio.putMode(p, INIT, MCMode.READ_ONLY);
		p.Font_NewFontRatio.putMode(p, INIT, MCMode.REQUIRED);
		p.Font_AdjustFrameSize.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Command(FSBAP0080 p){
		p.Command_Default.putMode(p, INIT, MCMode.ENABLE);
		p.Command_OK.putMode(p, INIT, MCMode.ENABLE);
		p.Command_Cancel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Font_NewFontRatio.setListVisibleColumn(MCListLogic.getViewColumnName());
		Font_NewFontRatio.getListConfig().setPutter(getFont_NewFontRatio_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Font_NewFontRatio_ListPutter]の作成
	 */
	protected MCListPutter createFont_NewFontRatio_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.FontRatio");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Font_NewFontRatio) return getFont_NewFontRatio(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Command_Default) doCommand_Default(info);
		else if (ap == Command_OK) doCommand_OK(info);
		else if (ap == Command_Cancel) doCommand_Cancel(info);
	}

	/**
	 * [Command]パネルの[Default]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Default(MCEventInfo info);

	/**
	 * [Command]パネルの[OK]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_OK(MCEventInfo info);

	/**
	 * [Command]パネルの[Cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Font_FontRatio) return doFont_FontRatio_VC(info);
		if (vc == Font_NewFontRatio) return doFont_NewFontRatio_VC(info);
		if (vc == Font_AdjustFrameSize) return doFont_AdjustFrameSize_VC(info);
		return true;
	}

	/**
	 * [Font]パネルの[FontRatio]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doFont_FontRatio_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Font]パネルの[NewFontRatio]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doFont_NewFontRatio_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Font]パネルの[AdjustFrameSize]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doFont_AdjustFrameSize_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Font_FontRatio) doFont_FontRatio_NC(info);
		else if (nc == Font_NewFontRatio) doFont_NewFontRatio_NC(info);
		else if (nc == Font_AdjustFrameSize) doFont_AdjustFrameSize_NC(info);
	}

	/**
	 * [Font]パネルの[FontRatio]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_FontRatio_NC(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[NewFontRatio]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_NewFontRatio_NC(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[AdjustFrameSize]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_AdjustFrameSize_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Font_FontRatio) doFont_FontRatio_NE(info);
		else if (ne == Font_NewFontRatio) doFont_NewFontRatio_NE(info);
		else if (ne == Font_AdjustFrameSize) doFont_AdjustFrameSize_NE(info);
	}

	/**
	 * [Font]パネルの[FontRatio]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_FontRatio_NE(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[NewFontRatio]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_NewFontRatio_NE(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[AdjustFrameSize]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_AdjustFrameSize_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Font_FontRatio) doFont_FontRatio_NX(info);
		else if (nx == Font_NewFontRatio) doFont_NewFontRatio_NX(info);
		else if (nx == Font_AdjustFrameSize) doFont_AdjustFrameSize_NX(info);
	}

	/**
	 * [Font]パネルの[FontRatio]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_FontRatio_NX(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[NewFontRatio]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_NewFontRatio_NX(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[AdjustFrameSize]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_AdjustFrameSize_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Font_FontRatio) doFont_FontRatio_LC(info);
		else if (lc == Font_NewFontRatio) doFont_NewFontRatio_LC(info);
	}

	/**
	 * [Font]パネルの[FontRatio]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_FontRatio_LC(MCEventInfo info){
	}

	/**
	 * [Font]パネルの[NewFontRatio]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFont_NewFontRatio_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Font_NewFontRatio]の作成メソッド
	 */
	public MCList getFont_NewFontRatio(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getFontRatio(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}