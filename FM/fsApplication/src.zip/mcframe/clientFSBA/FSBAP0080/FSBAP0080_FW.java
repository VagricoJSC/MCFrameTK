package mcframe.clientFSBA.FSBAP0080;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.beans.resource.MCFontRatioResourceIO;
import mcframe.clientCore.beans.resource.MCPersonalizeResourceIO;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0080"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0080_FW extends FSBAP0080_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0080_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Command]のボタン[Default]の押下時の処理
	 */
	@Override
	public void doCommand_Default(MCEventInfo info) {
		doDefaultAction();
	}

	/**
	 * Panel[Command]のボタン[Cancel]の押下時の処理
	 */
	@Override
	public void doCommand_Cancel(MCEventInfo info) {
		doCancelAction();
	}

	/**
	 * Panel[Command]のボタン[OK]の押下時の処理
	 */
	@Override
	public void doCommand_OK(MCEventInfo info) {
		doDecisionAction();
	}

	@Override
	protected void listInit() {
		super.listInit();

		getFont_NewFontRatio_ListPutter().setColumns("font_ratio");
	}

	/**
	 * 画面を表示する前に実行されます。
	 * 画面を表示できる場合は true を返します。
	 *
	 * @return 画面を表示できない場合は false
	 * @throws MCAppException [FSBAC0001] フォント比率変更の対象となる画面が存在しない場合
	 */
	@Override
	public boolean beforeOpen() {
		boolean e = super.beforeOpen();
		if (getTargetPanel() == null) {
			throw new MCAppException(FSBAC0001, getModuleID(), getScreenID());
		}

		setInitData();

		setArrangementCenter();
		return e;
	}

	@Override
	public void mcInitStatus() {
		super.mcInitStatus();

		setInitFocus();
	}

	/**
	 * 初期値を設定します。
	 */
	protected void setInitData() {
		MCRootPanel p = getTargetPanel();
		if (p != null) {
			getFontR().FontRatio(p.getFontRatio());
			getFontR().AdjustFrameSize(true);
		}
	}

	/**
	 * 初期フォーカスを設定します。
	 */
	protected void setInitFocus() {}

	/**
	 * [決定] ボタンのアクションを実行します。
	 */
	protected void doDecisionAction() {
		if (beforeCommit()) {
			if (commitConfirm()) {
				doCommit();
				showCommitEndMsg();
				requestCloseWindow();
			}
		}
	}

	/**
	 * 登録前チェックを行います。
	 * 登録処理を実行できる場合は true を返します。
	 *
	 * @return 登録処理を実行できない場合は false
	 */
	protected boolean beforeCommit() {
		MCNumber v = getFontR().NewFontRatio();
		if (v == null) {
			dialog(FSBAC0018);
			Font_NewFontRatio.mcRequestFocus();
			return false;
		}
		int i = v.intValue();
		MCRootPanel p = getTargetPanel();
		if (p != null) {
			if (i < p.getMinRatio() || i > p.getMaxRatio()) {
				dialog(FSBAC0019, p.getMinRatio(), p.getMaxRatio());
				Font_NewFontRatio.mcRequestFocus();
				return false;
			}
		}
		return true;
	}

	/**
	 * 登録処理を実行する場合は true を返します。
	 *
	 * @return 登録処理を実行しない場合は false
	 */
	protected boolean commitConfirm() {
		return confirm(FCBAC0100) == MCMessageBox.YES_OPTION;
	}

	/**
	 * 変更内容をリソースに保存します。
	 * 親画面のフォント比率を変更します。
	 */
	protected void doCommit() {
		// 最大化を解除する
		// JRW-5-016-05909 2008/08/22
		restoreFrame();
		writeResource();
		updatePanel();
	}

	/**
	 * フレームが最大化されている場合は最大化を解除します。
	 */
	protected void restoreFrame() {
		MCRootPanel p = getTargetPanel();
		MCFrame f = p.getFrame();
		if (f != null && f.isMaximum()) {
			f.setMaximum(false);
		}
	}

	/**
	 * 変更内容をリソースに保存します。
	 */
	protected void writeResource() {

		removeResource(false);

		MCRootPanel p = getTargetPanel();
		if (p != null) {
			FontR o = getFontR();
			MCFontRatioResourceIO fio = new MCFontRatioResourceIO();
			fio.setFontRatio(o.NewFontRatio().intValue());
			fio.setAdjustScreenSize(o.AdjustFrameSize());
			String pfx = MCConst.createKey(p.getModuleID(), p.getScreenID());
			fio.writeNoSave(pfx);
		}
		MCPersonalizeResourceIO.saveResource();
	}

	// RootPanelのupdatePanelメソッドで処理するかどうか。
//	protected boolean useRootPanelUpdatePanel = true;

	/**
	 * 親画面のフォント比率を更新します。
	 */
	protected void updatePanel() {
		// MCRootPanelのupdatePanel参照

		MCRootPanel p = getTargetPanel();
		if (p == null) {
			return;
		}

		// 7.0.1
//		if (useRootPanelUpdatePanel) {
		int new_ratio = 100;
		int old_ratio = 100;

		FontR o = getFontR();
		if (o.NewFontRatio() != null) {
			new_ratio = o.NewFontRatio().intValue();
//			old_ratio = o.FontRatio().intValue();
		}
		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		old_ratio = o.FontRatio().intValue();
		p.updatePanel(new_ratio, old_ratio);

		// 7.0.1 SplitPaneの位置を戻し。
		// _setDefault_divider_locationメソッドで初期設定された値に戻す。
		if (o.NewFontRatio() == null || o.NewFontRatio().intValue() == 100) {
			MCSplitPane[] a = MCBeansUtil.getAllComponents(MCSplitPane.class, getTargetPanel());
			for (MCSplitPane sp : a) {
				if (sp.isExpandSplitPane() == false) { // 検索枠用は再設定不要
					sp.setDefault();
				}
			}
		}
		// 旧ロジックは廃止
/*		}
		else
		{
			// このブロックは廃止
			// divder位置を正確に戻すことができない。
			FontR o = getFontR();
			if (o.NewFontRatio() == null) {
				MCLayouter.fontRatioChange(p, 100);
			} else {
				MCLayouter.fontRatioChange(p, o.NewFontRatio().intValue());
			}

			if (!o.AdjustFrameSize()) {
				return;
			}

			MCFrame f = p.getFrame();
			if (f == null) {
				return;
			}

			int lr = p.getLayoutRatio();

			f.getScrollPane().setPreferredSize(null);

			// 上部パネルが検索枠の場合にSplitPaneの位置を調整
			// 7.0.1 引数追加
			// MCBeansUtil.setInitSplitPane(p, true, o.FontRatio().intValue(),
			// o.NewFontRatio().intValue());

			HashMap<MCSplitPane, Integer> map = new HashMap<MCSplitPane, Integer>();

			// フォント比率の変更でSplitPaneを探し出しdividerの位置を初期化させる
			MCSplitPane[] components = MCBeansUtil.getAllComponents(MCSplitPane.class, p);
			for (MCSplitPane s : components) {
				if (o.NewFontRatio() == null) {
					int dividerLocation = s.getDividerLocation();
					map.put(s, dividerLocation);
				} else {
					int dividerLocation = s.getDividerLocation();
					map.put(s, dividerLocation);
				}
			}

			// フォント比率とサイズ設定を同時に行うと画面サイズが一時的に戻ってしまう対応。
			Dimension ds = p.getUserResourceBounds();
			if (ds != null) {
				// ユーザが指定したサイズをそのまま採用するため変更しない。
			} else {

				// Dimension ds = f.getDefaultSize();
				ds = f.getDefaultSize();
				Insets i = f.getInsets();

				int ow = ds.width - (i.left + i.right);
				int oh = ds.height - (i.top + i.bottom);
				int w = MCBeansUtil.adjust(ow, 100, lr) + i.left + i.right;
				int h = MCBeansUtil.adjust(oh, 100, lr) + i.top + i.bottom;
				f.setSize(w, h);
			}

			for (MCSplitPane s : map.keySet()) {
				Integer dividerLocation = map.get(s);
				s.setDividerLocation(dividerLocation);
			}
			if (o.NewFontRatio() == null) {
				MCBeansUtil.setInitSplitPane(p, true, 100, 100);
			} else {
				MCBeansUtil.setInitSplitPane(p, true, o.FontRatio().intValue(), o.NewFontRatio().intValue());
			}
		} */
	}

	/**
	 * 登録完了メッセージを表示します。
	 */
	protected void showCommitEndMsg() {
		dialog(FCBAC0101);
	}

	/**
	 * [キャンセル] ボタンのアクションを実行します。
	 */
	protected void doCancelAction() {
		requestCloseWindow();
	}

	/**
	 * [デフォルト] ボタンのアクションを実行します。
	 */
	protected void doDefaultAction() {
		if (defaultComfirm()) {
			//TODO 後でtrunkでパッチ化する。
			getFontR().NewFontRatio(null);

			setDefault();
			showDefaultEndMsg();
			requestCloseWindow();
		}
	}

	/**
	 * デフォルトに戻す処理を実行する場合は true を返します。
	 *
	 * @return デフォルトに戻す処理を実行しない場合は false
	 */
	protected boolean defaultComfirm() {
		return confirm(FSBAC0004) == MCMessageBox.YES_OPTION;
	}

	/**
	 * ユーザ設定を破棄します。
	 */
	protected void setDefault() {
		restoreFrame();
		removeResource(true);
		setPanelDefault();
	}

	/**
	 * リソース情報を削除します。
	 */
	protected void removeResource(boolean doSave) {
		MCRootPanel p = getTargetPanel();
		if (p != null) {
			String pfx = MCConst.createKey(
					p.getModuleID(), p.getScreenID());
			MCFontRatioResourceIO.removeNoSave(pfx);
			if (doSave) {
				MCPersonalizeResourceIO.saveResource();
			}
		}
	}

	/**
	 * 親画面の情報をデフォルトに戻します。
	 */
	protected void setPanelDefault() {
		MCRootPanel p = getTargetPanel();
		if (p == null) {
			return;
		}

		// 100に戻した場合にも画面の更新が必要 6.4.0
//		if (p.getFontRatio() == 100) {
//			return;
//		}

		MCLayouter.fontRatioChange(p, 100);

		updatePanel();

//		MCFrame f = p.getFrame();
//		if (f == null) {
//			return;
//		}
//		f.setBoundsDefault();
	}

	/**
	 * デフォルトに戻す処理が完了したメッセージを表示します。
	 */
	protected void showDefaultEndMsg() {
		dialog(FSBAC0005);
	}

	/**
	 * フォント比率変更の対象となる画面を返します。
	 * この画面が埋込画面の場合は土台の画面を返します。
	 * この画面が子画面の場合は親画面を返します。
	 * それ以外の場合は null を返します。
	 *
	 * @return 画面または null
	 */
	protected MCRootPanel getTargetPanel() {
		MCRootPanel p = getBaseRootPanel();
		if (p == this) {
			p = getParentPanel();
		}
		return p;
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	// 7013-0007 ここまで
}