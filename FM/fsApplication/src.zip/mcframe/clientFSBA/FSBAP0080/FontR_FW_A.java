package mcframe.clientFSBA.FSBAP0080;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Font"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class FontR_FW_A extends MCConstRow {

	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public static final String $FontRatio = "FontRatio";
	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public static final String $NewFontRatio = "NewFontRatio";
	/**
	 * 画面サイズを合わせて調整する 画面サイズを合わせて調整する.<p>
	 *
	 */
	public static final String $AdjustFrameSize = "AdjustFrameSize";


	public static final MCMeta FontRatio_META = createNumberMeta($FontRatio, 5, 0, false);
	public static final MCMeta NewFontRatio_META = createNumberMeta($NewFontRatio, 3, 0, false);
	public static final MCMeta AdjustFrameSize_META = createCommonMeta($AdjustFrameSize, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<FontR> constMetas = new ConstMetaList<FontR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			FontRatio_META,
			NewFontRatio_META,
			AdjustFrameSize_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected FontR_FW_A(ConstMetaList<? extends FontR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public FontR clone() {
		return (FontR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public FontR createInstance() {
		return (FontR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public FontR getValues(String... names) {
		return (FontR) super.getValues(names);
	}



	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public MCNumber FontRatio() {
		return getConstNumber(offset + 0, $FontRatio);
	}

	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public void FontRatio(MCNumber value) {
		setConstNumber(offset + 0, $FontRatio, value);
	}

	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public void FontRatio(int value) {
		setConstNumber(offset + 0, $FontRatio, value);
	}

	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public void FontRatio(long value) {
		setConstNumber(offset + 0, $FontRatio, value);
	}

	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public void FontRatio(float value) {
		setConstNumber(offset + 0, $FontRatio, value);
	}

	/**
	 * 現在のフォント比率 現在のフォント比率.<p>
	 *
	 */
	public void FontRatio(double value) {
		setConstNumber(offset + 0, $FontRatio, value);
	}


	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public MCNumber NewFontRatio() {
		return getConstNumber(offset + 1, $NewFontRatio);
	}

	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public void NewFontRatio(MCNumber value) {
		setConstNumber(offset + 1, $NewFontRatio, value);
	}

	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public void NewFontRatio(int value) {
		setConstNumber(offset + 1, $NewFontRatio, value);
	}

	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public void NewFontRatio(long value) {
		setConstNumber(offset + 1, $NewFontRatio, value);
	}

	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public void NewFontRatio(float value) {
		setConstNumber(offset + 1, $NewFontRatio, value);
	}

	/**
	 * フォント比率 フォント比率.<p>
	 *
	 */
	public void NewFontRatio(double value) {
		setConstNumber(offset + 1, $NewFontRatio, value);
	}


	/**
	 * 画面サイズを合わせて調整する 画面サイズを合わせて調整する.<p>
	 *
	 */
	public boolean AdjustFrameSize() {
		return getConstBoolean(offset + 2, $AdjustFrameSize);
	}

	/**
	 * 画面サイズを合わせて調整する 画面サイズを合わせて調整する.<p>
	 *
	 */
	public void AdjustFrameSize(boolean value) {
		setConstBoolean(offset + 2, $AdjustFrameSize, value);
	}


	public MCNumber getNumber(String name) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			return FontRatio();
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			return NewFontRatio();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($AdjustFrameSize.equalsIgnoreCase(name)) {
			return AdjustFrameSize();
		}
		return super.getBoolean(name);
	}

	public MCNumber getNumberNE(String name) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			return FontRatio();
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			return NewFontRatio();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($AdjustFrameSize.equalsIgnoreCase(name)) {
			return AdjustFrameSize();
		}
		return super.getBooleanNE(name);
	}

	public void setNumber(String name, MCNumber value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($AdjustFrameSize.equalsIgnoreCase(name)) {
			AdjustFrameSize(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setNumberNE(String name, MCNumber value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($FontRatio.equalsIgnoreCase(name)) {
			FontRatio(value);
			return;
		}
		if ($NewFontRatio.equalsIgnoreCase(name)) {
			NewFontRatio(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($AdjustFrameSize.equalsIgnoreCase(name)) {
			AdjustFrameSize(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

