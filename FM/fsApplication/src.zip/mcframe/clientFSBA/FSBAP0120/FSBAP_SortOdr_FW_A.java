package mcframe.clientFSBA.FSBAP0120;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_SortOdr"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_SortOdr_FW_A extends mcframe.clientFSBA.FSBAP0030.FSBAP_PersonalizeBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0120";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [ListDtlBtn]ブロック関連のField定義
	// [ListDtlBtn]ブロックの項目のField定義
	// [Info]ブロック関連のField定義
	// [Info]ブロックの項目のField定義
	// [InfoHdr]ブロック関連のField定義
	public MCPanel InfoHdrPanel = null;
	// [InfoHdr]ブロックの項目のField定義
	public MCLabel InfoHdr_sort_type_Label = null;
	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public MCTextComboBox InfoHdr_sort_type = null;
	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public MCTextField InfoHdr_sort_type_nm = null;
	// [InfoDtl]ブロック関連のField定義
	public MCPanel InfoDtlPanel = null;
	public MCScrollPane InfoDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0120.InfoDtlR> InfoDtlTable = null;
	// [InfoDtl]ブロックの項目のField定義
	/**
	 *  キー.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_column_key = null;
	/**
	 *  カラム名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_column_nm = null;
	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sort_type = null;
	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_sort_type_nm = null;
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton InfoBtn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton InfoBtn_rdel = null;
	public mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H InfoBtn_row_move_p_PPanel;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};
	
	/** [InfoHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0120.InfoHdrR aInfoHdrR;
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0120.InfoDtlR> aInfoDtlL;

	/**
	 * 項目コピーによってaInfoHdrRを設定します。
	 *
	 * aInfoHdrRのインスタンスは変更されません。
	 *
	 * @param row InfoHdrR
	 */
	public void setInfoHdrR(mcframe.clientFSBA.FSBAP0120.InfoHdrR row) {
		if (row != null) {
			MCRow.copyall(getInfoHdrR(), row);
		}
	}

	/**
	 * [InfoHdr]ブロックのコンテナaInfoHdrRを返します。
	 *
	 * @return InfoHdrR
	 */
	public mcframe.clientFSBA.FSBAP0120.InfoHdrR getInfoHdrR() {
		return aInfoHdrR;
	}

	/**
	 * aInfoHdrRを作成します。
	 *
	 * @return InfoHdrR
	 */
	public mcframe.clientFSBA.FSBAP0120.InfoHdrR createInfoHdrR() {
		return mcframe.clientFSBA.FSBAP0120.InfoHdrR.create();
	}

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFSBA.FSBAP0120.InfoDtlR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0120.InfoDtlR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0120.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0120.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0120.InfoDtlR> createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0120.InfoDtlR.class);
	}

	/**
	 * InfoDtlTableを初期化します。
	 */
	protected void createInfoDtlTable(){
		if(InfoDtlTable == null){
			InfoDtlTable = beansFactory.createTable2("InfoDtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoHdrR())) ret.add(getInfoHdrR());
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoHdrR()) return "InfoHdr";
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("InfoHdr")) return getInfoHdrR();
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(InfoHdrPanel);
		ret.add(InfoDtlPanel);
		ret.add(InfoBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SortOdr_FW_A() {
		aInfoHdrR = createInfoHdrR();
		aInfoDtlL = createInfoDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SortOdr_FW_A(String name) {
		aInfoHdrR = createInfoHdrR();
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_SortOdr_FW.jbCreateListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbCreateInfo((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbCreateInfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbCreateInfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbCreateInfoBtn((FSBAP_SortOdr)this);
	}

	/**
	 * [ListDtlBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtlBtn(FSBAP_SortOdr p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP_SortOdr p) {
	}

	/**
	 * [InfoHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoHdr(FSBAP_SortOdr p) {
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP_SortOdr p) {
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP_SortOdr p) {
		p.InfoBtn_row_move_p_PPanel = mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.create();
		p.InfoBtn_row_move_p_PPanel.setName("InfoBtn.row_move_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [InfoHdr_sort_type_ListPutter]の定義 */
	private MCListPutter InfoHdr_sort_type_p = null;

	/**
	 * [InfoHdr_sort_type_ListPutter]の取得
	 */
	protected MCListPutter getInfoHdr_sort_type_ListPutter() {
		if (InfoHdr_sort_type_p == null) {
			InfoHdr_sort_type_p = createInfoHdr_sort_type_ListPutter(InfoHdr_sort_type, "sort_type", "sort_type_nm");

		}
		return InfoHdr_sort_type_p;
	}
	
	
	/** [InfoDtl_column_nm_ListPutter]の定義 */
	private MCListPutter InfoDtl_column_nm_p = null;

	/**
	 * [InfoDtl_column_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_column_nm_ListPutter() {
		if (InfoDtl_column_nm_p == null) {
			InfoDtl_column_nm_p = createInfoDtl_column_nm_ListPutter(columnInfoDtl_column_nm, "column_nm", "column_key");

		}
		return InfoDtl_column_nm_p;
	}
	
	
	/** [InfoDtl_sort_type_ListPutter]の定義 */
	private MCListPutter InfoDtl_sort_type_p = null;

	/**
	 * [InfoDtl_sort_type_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_sort_type_ListPutter() {
		if (InfoDtl_sort_type_p == null) {
			InfoDtl_sort_type_p = createInfoDtl_sort_type_ListPutter(columnInfoDtl_sort_type, "sort_type", "sort_type_nm");

		}
		return InfoDtl_sort_type_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SortOdr create(){
		FSBAP_SortOdr p = new FSBAP_SortOdr();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SortOdr create(String name){
		FSBAP_SortOdr p = new FSBAP_SortOdr(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_SortOdr_FW.jbfInitListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbfInitInfo((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbfInitInfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbfInitInfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbfInitInfoBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbInitListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbInitInfo((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbInitInfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbInitInfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.jbInitInfoBtn((FSBAP_SortOdr)this);
	}

	/**
	 * [ListDtlBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtlBtn(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [InfoHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoHdr(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		p.InfoHdrPanel = p.beansFactory.createPanel("InfoHdr");
		// ブロックの項目の初期化
		p.InfoHdr_sort_type_Label = p.beansFactory.createLabel("InfoHdr.sort_type_Label");
		p.InfoHdr_sort_type = p.beansFactory.createTextComboBox("InfoHdr.sort_type");
		p.InfoHdr_sort_type.setLabel(p.InfoHdr_sort_type_Label);
		p.InfoHdr_sort_type_nm = p.beansFactory.createTextField("InfoHdr.sort_type_nm");
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		p.InfoDtlPanel = p.beansFactory.createPanel("InfoDtl");
		p.InfoDtlScrollPane = p.beansFactory.createScrollPane("InfoDtl.scroll");
		p.createInfoDtlTable();
		// ブロックの項目の初期化
		p.columnInfoDtl_column_key = p.beansFactory.createTableColumn("InfoDtl.column_key", MCColumnType.TEXT);
		p.columnInfoDtl_column_nm = p.beansFactory.createTableColumn("InfoDtl.column_nm", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_sort_type = p.beansFactory.createTableColumn("InfoDtl.sort_type", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_sort_type_nm = p.beansFactory.createTableColumn("InfoDtl.sort_type_nm", MCColumnType.TEXT);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_radd = p.beansFactory.createButton("InfoBtn.radd", "no_border");
		p.InfoBtn_rdel = p.beansFactory.createButton("InfoBtn.rdel", "no_border");
	}

	/**
	 * [ListDtlBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtlBtn(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.InfoPanel.add(p.InfoHdrPanel, null);
		p.InfoPanel.setLastBeans(p.InfoHdrPanel);
		p.InfoHdrPanel.setNextBeans(p.InfoDtlPanel);
		p.InfoPanel.add(p.InfoDtlPanel, null);
		p.InfoDtlPanel.setNextBeans(p.InfoBtnPanel);
		p.InfoPanel.add(p.InfoBtnPanel, null);
	}

	/**
	 * [InfoHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoHdr(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		p.InfoHdrPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.InfoHdr_sort_type.setListType(MCListType.STRICT);
		p.InfoHdr_sort_type.setLinkBeans(p.InfoHdr_sort_type_nm);
		p.InfoHdrPanel.add(p.InfoHdr_sort_type_Label);
		p.InfoHdrPanel.add(p.InfoHdr_sort_type);
		p.InfoHdrPanel.setLastBeans(p.InfoHdr_sort_type);
		p.InfoHdr_sort_type.setNextBeans(p.InfoHdr_sort_type_nm);
		p.InfoHdr_sort_type.setRow(p.getInfoHdrR(), mcframe.clientFSBA.FSBAP0120.InfoHdrR.sort_type_META);
		p.InfoHdrPanel.add(p.InfoHdr_sort_type_nm);
		p.InfoHdr_sort_type_nm.setRow(p.getInfoHdrR(), mcframe.clientFSBA.FSBAP0120.InfoHdrR.sort_type_nm_META);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		p.InfoDtlPanel.add(p.InfoDtlScrollPane);
		p.InfoDtlPanel.setLastBeans(p.InfoDtlTable);
		p.InfoDtlScrollPane.setViewportView(p.InfoDtlTable);
		p.InfoDtlTable.setList(p.getInfoDtlL());
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP_SortOdr p) {
		// ブロック関連の初期化
		p.InfoBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoBtn_radd.setIcon("INSERT_RECORD");
		p.InfoBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.InfoBtnPanel.add(p.InfoBtn_radd);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_radd);
		p.InfoBtn_radd.setNextBeans(p.InfoBtn_rdel);
		p.InfoBtn_rdel.setIcon("DELETE_RECORD");
		p.InfoBtn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.InfoBtnPanel.add(p.InfoBtn_rdel);
		p.InfoBtn_rdel.setNextBeans(p.InfoBtn_row_move_p_PPanel);
		p.InfoBtnPanel.add(p.InfoBtn_row_move_p_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_SortOdr_FW.mcInitListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.mcInitInfo((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.mcInitInfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.mcInitInfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.mcInitInfoBtn((FSBAP_SortOdr)this);

		// [INIT]ステータスのモードの設定
		FSBAP_SortOdr_FW.statusInitINIT_ListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitINIT_Info((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitINIT_InfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitINIT_InfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitINIT_InfoBtn((FSBAP_SortOdr)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_SortOdr_FW.statusInitEDIT_ListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitEDIT_Info((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitEDIT_InfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitEDIT_InfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitEDIT_InfoBtn((FSBAP_SortOdr)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_SortOdr_FW.statusInitDISABLE_ListDtlBtn((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitDISABLE_Info((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitDISABLE_InfoHdr((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitDISABLE_InfoDtl((FSBAP_SortOdr)this);
		FSBAP_SortOdr_FW.statusInitDISABLE_InfoBtn((FSBAP_SortOdr)this);

	}

	/**
	 *  [ListDtlBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtlBtn(FSBAP_SortOdr p) {
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP_SortOdr p) {
	}

	/**
	 *  [InfoHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoHdr(FSBAP_SortOdr p) {
		p.InfoHdr_sort_type.setListListener(p);
		p.InfoHdr_sort_type.addAllListener(p);
		p.InfoHdr_sort_type_nm.setListListener(p);
		p.InfoHdr_sort_type_nm.addAllListener(p);
	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP_SortOdr p) {
		p.InfoDtlTable.addAllListener(p);
		p.columnInfoDtl_column_key.addAllListener(p);
		p.columnInfoDtl_column_key.setListListener(p);
		p.columnInfoDtl_column_nm.addAllListener(p);
		p.columnInfoDtl_column_nm.setListListener(p);
		p.columnInfoDtl_sort_type.addAllListener(p);
		p.columnInfoDtl_sort_type.setListListener(p);
		p.columnInfoDtl_sort_type_nm.addAllListener(p);
		p.columnInfoDtl_sort_type_nm.setListListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP_SortOdr p) {
		p.InfoBtn_radd.addAllListener(p);
		p.InfoBtn_radd.setAPMethodName("doInfoBtn_radd");
		p.InfoBtn_rdel.addAllListener(p);
		p.InfoBtn_rdel.setAPMethodName("doInfoBtn_rdel");
	}

	/**
	 * [INIT]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ListDtlBtn(FSBAP_SortOdr p){
		p.ListDtlBtn_load.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP_SortOdr p){

	}

	/**
	 * [INIT]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoHdr(FSBAP_SortOdr p){
		p.InfoHdr_sort_type.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoHdr_sort_type_nm.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP_SortOdr p){
		p.columnInfoDtl_column_key.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnInfoDtl_column_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type_nm.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP_SortOdr p){
		p.InfoBtn_radd.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_row_move_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.DISABLE);

	}

	/**
	 * [EDIT]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_ListDtlBtn(FSBAP_SortOdr p){
		p.ListDtlBtn_load.putMode(p, EDIT, MCMode.INVISIBLE);

	}

	/**
	 * [EDIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Info(FSBAP_SortOdr p){

	}

	/**
	 * [EDIT]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoHdr(FSBAP_SortOdr p){
		p.InfoHdr_sort_type.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoHdr_sort_type_nm.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP_SortOdr p){
		p.columnInfoDtl_column_key.putMode(p, EDIT, MCMode.INVISIBLE);
		p.columnInfoDtl_column_nm.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_sort_type.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_sort_type_nm.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoBtn(FSBAP_SortOdr p){
		p.InfoBtn_radd.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_rdel.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_row_move_p_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.ENABLE);

	}

	/**
	 * [DISABLE]ステータスの[ListDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_ListDtlBtn(FSBAP_SortOdr p){
		p.ListDtlBtn_load.putMode(p, DISABLE, MCMode.INVISIBLE);

	}

	/**
	 * [DISABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Info(FSBAP_SortOdr p){

	}

	/**
	 * [DISABLE]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoHdr(FSBAP_SortOdr p){
		p.InfoHdr_sort_type.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoHdr_sort_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP_SortOdr p){
		p.columnInfoDtl_column_key.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnInfoDtl_column_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_sort_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoBtn(FSBAP_SortOdr p){
		p.InfoBtn_radd.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_rdel.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_row_move_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_SortOdr_FW.setTableConfigInfoDtl((FSBAP_SortOdr)this);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP_SortOdr p) {
		p.columnInfoDtl_column_key.setMeta(mcframe.clientFSBA.FSBAP0120.InfoDtlR.column_key_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_column_key);
		p.columnInfoDtl_column_nm.setMeta(mcframe.clientFSBA.FSBAP0120.InfoDtlR.column_nm_META);
		p.columnInfoDtl_column_nm.addLinkBeans(p.columnInfoDtl_column_key);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_column_nm);
		p.columnInfoDtl_sort_type.setMeta(mcframe.clientFSBA.FSBAP0120.InfoDtlR.sort_type_META);
		p.columnInfoDtl_sort_type.addLinkBeans(p.columnInfoDtl_sort_type_nm);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sort_type);
		p.columnInfoDtl_sort_type_nm.setMeta(mcframe.clientFSBA.FSBAP0120.InfoDtlR.sort_type_nm_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_sort_type_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		InfoHdr_sort_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		InfoHdr_sort_type.getListConfig().setPutter(getInfoHdr_sort_type_ListPutter());
		columnInfoDtl_column_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_column_nm.getListConfig().setPutter(getInfoDtl_column_nm_ListPutter());
		columnInfoDtl_sort_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_sort_type.getListConfig().setPutter(getInfoDtl_sort_type_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [InfoHdr_sort_type_ListPutter]の作成
	 */
	protected MCListPutter createInfoHdr_sort_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SortTypeAll");
		return lp;
	}
	 
	/**
	 * [InfoDtl_column_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_column_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [InfoDtl_sort_type_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_sort_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SortType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == InfoHdr_sort_type) return getInfoHdr_sort_type(row, info);
		if(combo == columnInfoDtl_column_nm) return getInfoDtl_column_nm(row, info);
		if(combo == columnInfoDtl_sort_type) return getInfoDtl_sort_type(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == InfoBtn_radd) doInfoBtn_radd(info);
		else if (ap == InfoBtn_rdel) doInfoBtn_rdel(info);
	}

	/**
	 * [InfoBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_radd(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_rdel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == InfoDtlTable) return doInfoDtl_VC(info);
		if (vc == InfoHdr_sort_type) return doInfoHdr_sort_type_VC(info);
		if (vc == InfoHdr_sort_type_nm) return doInfoHdr_sort_type_nm_VC(info);
		if (vc == columnInfoDtl_column_key) return doInfoDtl_column_key_VC(info);
		if (vc == columnInfoDtl_column_nm) return doInfoDtl_column_nm_VC(info);
		if (vc == columnInfoDtl_sort_type) return doInfoDtl_sort_type_VC(info);
		if (vc == columnInfoDtl_sort_type_nm) return doInfoDtl_sort_type_nm_VC(info);
		return true;
	}

	/**
	 * [InfoDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoHdr]パネルの[sort_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoHdr_sort_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoHdr]パネルの[sort_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoHdr_sort_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[column_key]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_column_key_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_column_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sort_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_sort_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == InfoDtlTable) doInfoDtl_NC(info);
		else if (nc == InfoHdr_sort_type) doInfoHdr_sort_type_NC(info);
		else if (nc == InfoHdr_sort_type_nm) doInfoHdr_sort_type_nm_NC(info);
		else if (nc == columnInfoDtl_column_key) doInfoDtl_column_key_NC(info);
		else if (nc == columnInfoDtl_column_nm) doInfoDtl_column_nm_NC(info);
		else if (nc == columnInfoDtl_sort_type) doInfoDtl_sort_type_NC(info);
		else if (nc == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_NC(info);
	}

	/**
	 * [InfoDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == InfoDtlTable) doInfoDtl_NE(info);
		else if (ne == InfoHdr_sort_type) doInfoHdr_sort_type_NE(info);
		else if (ne == InfoHdr_sort_type_nm) doInfoHdr_sort_type_nm_NE(info);
		else if (ne == columnInfoDtl_column_key) doInfoDtl_column_key_NE(info);
		else if (ne == columnInfoDtl_column_nm) doInfoDtl_column_nm_NE(info);
		else if (ne == columnInfoDtl_sort_type) doInfoDtl_sort_type_NE(info);
		else if (ne == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_NE(info);
	}

	/**
	 * [InfoDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NE(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == InfoDtlTable) doInfoDtl_NX(info);
		else if (nx == InfoHdr_sort_type) doInfoHdr_sort_type_NX(info);
		else if (nx == InfoHdr_sort_type_nm) doInfoHdr_sort_type_nm_NX(info);
		else if (nx == columnInfoDtl_column_key) doInfoDtl_column_key_NX(info);
		else if (nx == columnInfoDtl_column_nm) doInfoDtl_column_nm_NX(info);
		else if (nx == columnInfoDtl_sort_type) doInfoDtl_sort_type_NX(info);
		else if (nx == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_NX(info);
	}

	/**
	 * [InfoDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NX(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == InfoHdr_sort_type) doInfoHdr_sort_type_LC(info);
		else if (lc == InfoHdr_sort_type_nm) doInfoHdr_sort_type_nm_LC(info);
		else if (lc == columnInfoDtl_column_key) doInfoDtl_column_key_LC(info);
		else if (lc == columnInfoDtl_column_nm) doInfoDtl_column_nm_LC(info);
		else if (lc == columnInfoDtl_sort_type) doInfoDtl_sort_type_LC(info);
		else if (lc == columnInfoDtl_sort_type_nm) doInfoDtl_sort_type_nm_LC(info);
	}

	/**
	 * [InfoHdr]パネルの[sort_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[sort_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_sort_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_key]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_key_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[sort_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_sort_type_nm_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[InfoHdr_sort_type]の作成メソッド
	 */
	public MCList getInfoHdr_sort_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSortTypeAll(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_column_nm]の作成メソッド
	 */
	public MCList getInfoDtl_column_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_sort_type]の作成メソッド
	 */
	public MCList getInfoDtl_sort_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSortType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}