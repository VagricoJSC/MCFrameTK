package mcframe.clientFSBA.FSBAP0120;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoDtlR_FW_A extends MCConstRow {

	/**
	 *  キー.<p>
	 *
	 */
	public static final String $column_key = "column_key";
	/**
	 *  カラム名.<p>
	 *
	 */
	public static final String $column_nm = "column_nm";
	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public static final String $sort_type = "sort_type";
	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public static final String $sort_type_nm = "sort_type_nm";


	public static final MCMeta column_key_META = createStringMeta($column_key);
	public static final MCMeta column_nm_META = createCommonMeta($column_nm, mcframe.commonCore.meta.M_META.LABEL);
	public static final MCMeta sort_type_META = createStringMeta($sort_type);
	public static final MCMeta sort_type_nm_META = createStringMeta($sort_type_nm);

	protected static final ConstMetaList<InfoDtlR> constMetas = new ConstMetaList<InfoDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			column_key_META,
			column_nm_META,
			sort_type_META,
			sort_type_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoDtlR_FW_A(ConstMetaList<? extends InfoDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR clone() {
		return (InfoDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR createInstance() {
		return (InfoDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR getValues(String... names) {
		return (InfoDtlR) super.getValues(names);
	}



	/**
	 *  キー.<p>
	 *
	 */
	public String column_key() {
		return getConstString(offset + 0, $column_key);
	}

	/**
	 *  キー.<p>
	 *
	 */
	public void column_key(String value) {
		setConstString(offset + 0, $column_key, value);
	}


	/**
	 *  カラム名.<p>
	 *
	 */
	public String column_nm() {
		return getConstString(offset + 1, $column_nm);
	}

	/**
	 *  カラム名.<p>
	 *
	 */
	public void column_nm(String value) {
		setConstString(offset + 1, $column_nm, value);
	}


	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public String sort_type() {
		return getConstString(offset + 2, $sort_type);
	}

	/**
	 *  ソートタイプ.<p>
	 *
	 */
	public void sort_type(String value) {
		setConstString(offset + 2, $sort_type, value);
	}


	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public String sort_type_nm() {
		return getConstString(offset + 3, $sort_type_nm);
	}

	/**
	 *  ソートタイプ名.<p>
	 *
	 */
	public void sort_type_nm(String value) {
		setConstString(offset + 3, $sort_type_nm, value);
	}


	public String getString(String name) {
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			return sort_type();
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			return sort_type_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($column_key.equalsIgnoreCase(name)) {
			return column_key();
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			return column_nm();
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			return sort_type();
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			return sort_type_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			sort_type(value);
			return;
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			sort_type_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($column_key.equalsIgnoreCase(name)) {
			column_key(value);
			return;
		}
		if ($column_nm.equalsIgnoreCase(name)) {
			column_nm(value);
			return;
		}
		if ($sort_type.equalsIgnoreCase(name)) {
			sort_type(value);
			return;
		}
		if ($sort_type_nm.equalsIgnoreCase(name)) {
			sort_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

