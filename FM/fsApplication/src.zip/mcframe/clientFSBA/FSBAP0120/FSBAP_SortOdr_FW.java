package mcframe.clientFSBA.FSBAP0120;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0060.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.HashMap;
import java.util.Map;

import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

import mcframe.clientCore.beans.resource.MCSortOrderInfo;
import mcframe.clientCore.beans.resource.MCSortOrderResourceIO;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSUB.FSUBP0000.IfRowMoveBase;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.commonFS.constant.FSC_SORT_TYPE;
import mcframe.commonFSUA.FSUAC0010.FSUAC_List;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_SortOdr"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_SortOdr_FW extends FSBAP_SortOdr_FW_A implements IfRowMoveBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * ソート順設定対象のテーブルです。
	 */
	protected MCTable<?> _target_table = null;

	/**
	 * ソート順設定対象のテーブルカラムの配列です。
	 */
	protected MCColumnConfig[] _target_column_configs = null;

	/**
	 * 設定情報ＩＤのシーケンス番号のマップです。
	 */
	protected Map<String, Integer> _setting_info_no_map = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SortOdr_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SortOdr_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[InfoBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_radd(MCEventInfo info) {
		insertRow(InfoDtlTable);
	}
	/**
	 * Panel[InfoBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doInfoBtn_rdel(MCEventInfo info) {
		deleteRow(InfoDtlTable);
	}

	/**
	 * ソート順設定対象のテーブルを設定します。
	 *
	 * @param table ソート順設定対象のテーブル
	 */
	protected void setTargetTable(MCTable<?> table) {
		_target_table = table;
	}

	/**
	 * ソート順設定対象のテーブルを返します。<p>
	 * ソート順設定対象のテーブルが設定されていない場合は null を返します。
	 *
	 * @return ソート順設定対象のテーブル、または null
	 */
	protected MCTable<?> getTargetTable() {
		return _target_table;
	}

	/**
	 * ソート順設定対象のテーブルカラムを配列にして返します。
	 *
	 * @return ソート順設定対象のテーブルカラムの配列
	 */
	public MCColumnConfig[] getTargetColumnConfigs() {
		if (_target_column_configs != null) {
			return _target_column_configs;
		}
		_target_column_configs
				= getTargetTable().getPersonalizedTargetColumnConfigs(
						SORT_ORDER_PANEL);
		return _target_column_configs;
	}

	/**
	 * ソート順設定対象のテーブルカラムを返します。<p>
	 * テーブルカラムが見つからなかった場合は null を返します。
	 *
	 * @param name {@link MCColumnConfig#getBaseRowColumnName()}
	 * @return ソート順設定対象のテーブルカラム、または null
	 */
	public MCColumnConfig getTargetColumnConfig(String name) {
		for (MCColumnConfig c : getTargetColumnConfigs()) {
			if (isSame(name, c.getBaseRowColumnName())) {
				return c;
			}
		}
		return null;
	}

	@Override
	public MCTable<?> getRowMoveTable() {
		return InfoDtlTable;
	}

	@Override
	public boolean isStatusChange() {
		return true;
	}

	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);

		// 登録済みの行が選択された場合
		FSBAP_SortOdrInfo si = getSettingInfo(data);
		if (si != null) {
			setListHdrR(si.getSettingInfo());
			MCList<InfoDtlR> c1 = si.getSortOdrList();
			MCList<InfoDtlR> ll = createInfoDtlL();
			List<FSC_SORT_TYPE> tl = new ArrayList<FSC_SORT_TYPE>();
			for (InfoDtlR c : c1) {
				InfoDtlR nc = c.clone();
				tl.add(FSC_SORT_TYPE.get(nc.sort_type()));
				nc.sort_type(null);
				ll.add(nc);
			}
			setInfoDtlL(ll);
			for (int i = 0; i < tl.size(); i++) {
				FSC_SORT_TYPE y = tl.get(i);
				columnInfoDtl_sort_type.setValue(i, y.value());
			}
			getInfoDtlL().setStatus(MCRow.NONE);

			InfoDtlTable.fillSpace();
			InfoDtlTable.adjustWidth();

			return;
		}

		// 新規行が選択された場合
		getInfoDtlL().clear();
		getListHdrR().clearAll();

		InfoDtlTable.fillSpace();
		InfoDtlTable.adjustWidth();
	}

	@Override
	protected boolean isInfoDataChanged() {
		return !getInfoDtlL().isStatusNone();
	}

	@Override
	protected void removeResource(boolean doSave) {
		MCTable<?> t = getTargetTable();

		MCSortOrderResourceIO sio = new MCSortOrderResourceIO();

		String u = getSettingR().setting_unit();
		String pfx = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL, null);
		String pfx2 = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL,
				MCResourceLayerType.BARCODE);

		Map<String, Integer> m = sio.readSettingInfoNOMap(pfx, pfx2);

		// リソースを削除する
		MCSortOrderResourceIO.removeNoSave(u, pfx);

		// 設定情報ＩＤのシーケンスを再設定する
		if (m.containsKey(u) && isRemainedAfterDel(u)) {
			Map<String, Integer> nm = new HashMap<String, Integer>();
			nm.put(u, m.get(u));
			sio.writeNoSave(pfx, nm);
		}
		if (doSave) {
			MCSortOrderResourceIO.saveResource();
		}
		t._setSortOrderInfo(null);
		t._setSortOrderInfoList(null);
	}

	/**
	 * リソースから指定したIDのみを削除するメソッド。
	 * 
	 * @param doSave 保存するかどうかのフラグ
	 * @param setting_info_id 設定情報ID
	 */
	protected void removeResourceById(boolean doSave, String setting_info_id) {
		MCTable<?> t = getTargetTable();
		if (setting_info_id != null) {
			MCSortOrderResourceIO sio = new MCSortOrderResourceIO();
	
			String u = getSettingR().setting_unit();
			String pfx = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL, null);
			String pfx2 = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL,
					MCResourceLayerType.BARCODE);
	
			Map<String, Integer> m = sio.readSettingInfoNOMap(pfx, pfx2);
	
			// リソースを削除する
			MCSortOrderResourceIO.removeNoSaveById(u, pfx, setting_info_id);
			// 初期設定のリソースが引数のIDと一致する場合は削除
			sio.removeInitResourceById(u, pfx, setting_info_id);
	
			// 設定情報ＩＤのシーケンスを再設定する
			if (m.containsKey(u) && isRemainedAfterDel(u)) {
				Map<String, Integer> nm = new HashMap<String, Integer>();
				nm.put(u, m.get(u));
				sio.writeNoSave(pfx, nm);
			}
			if (doSave) {
				MCSortOrderResourceIO.saveResource();
			}
		}
		t._setSortOrderInfo(null);
		t._setSortOrderInfoList(null);
	}

	@Override
	protected void setTargetPanelDefault() {
		MCTable<?> t = getTargetTable();
		t._applySortOrderInfo(null);
		t._setSortOrderInfoList(null);
	}

	@Override
	protected void updateTargetPanel() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		MCTable<?> t = getTargetTable();

		for (MCSortOrderInfo i : t.getSortOrderInfoList()) {
			if (isSame(s.setting_unit_type(), i.getSettingUnitType())
					&& isSame(s.setting_info_id(), i.getSettingInfoID())) {
				t._applySortOrderInfo(i);
				break;
			}
		}
	}

	@Override
	protected void writeResource() {
		// 既存データを削除する
//		removeResource(false);

		// 汎用テーブル編集以外の場合、既存データを削除する
		if (!isTargetGeneralTable()) {
			removeResource(false);
		}

		MCTable<?> t = getTargetTable();

		MCSortOrderResourceIO sio = new MCSortOrderResourceIO();

		ListDtlR s = ListDtlTable.getSelectedMCRow();

		String u = getSettingR().setting_unit();
		MCResourceLayerType type = MCSortOrderResourceIO.toResourceLayerType(u);

		String pfx = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL, type);

		Integer no = _setting_info_no_map.get(u);
		if (no == null) {
			no = Math.max(getMaxSettingInfoNO(), 0);
		}

		for (ListDtlR o : getListDtlL()) {
			if (o.isEmpty() || (o.isStatusDelete() && !isTargetGeneralTable())) {
				continue;
			}

			ListDtlR c1;
			MCList<InfoDtlR> c2;

			String y = o.setting_unit_type();

			// 選択行ではない場合
			if (s != o) {
				if (!u.equals(y)) {
					continue;
				}

				FSBAP_SortOdrInfo si = getSettingInfo(o);
				if (si == null) {
					continue;
				}

				c1 = si.getSettingInfo().clone();
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				c2 = si.getSortOdrList().clone();
			}
			// 選択行の場合
			else {
				if (isNull(y)) {
					o.setting_unit_type(u);
					FXC_RESOURCE_SETTING_UNIT.putNameNE(o,
							ListDtlR.$setting_unit_type,
							ListDtlR.$setting_unit_type_nm);
					y = o.setting_unit_type();
				}

				if (!u.equals(y)) {
					continue;
				}

				c1 = createListDtlR();
				c2 = createInfoDtlL();
				c1.setValues(ListDtlR.colnames(),
						getListHdrR(), ListDtlR.colnames());
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				for (InfoDtlR d : getInfoDtlL()) {
					if (d.isEmpty() || d.isStatusDelete()) {
						continue;
					}
					InfoDtlR f = c2.createRow();
					f.setValues(InfoDtlR.colnames(), d, InfoDtlR.colnames());
					c2.add(f);
				}

				// 汎用テーブル編集の場合
				if (isTargetGeneralTable()) {
					String id = c1.setting_info_id();
					// 新規の場合
					if (isNull(id)) {
						c1.setting_info_id(sio.createSettingInfoID(c1.setting_unit_type(), no++));
						removeResourceById(false, null);
					}
					// 更新または削除の場合、対象のIDのみを削除する
					else {
						removeResourceById(false, id);
					}
					// 削除の場合は追加しない
					if (!s.isStatusDelete()) {
						MCSortOrderInfo si = MCSortOrderInfo.create();
						si.setInitFlg(c1.init_flg());
						si.setSettingUnitType(c1.setting_unit_type());
						si.setSettingInfoID(c1.setting_info_id());
						si.setSettingInfoName(c1.setting_info_nm());
						si.setRemark(c1.remark());

						MCSortPolicy sp = new MCSortPolicy();
						for (InfoDtlR d : c2) {
							if (d.isEmpty() || d.isStatusDelete()) {
								continue;
							}
							sp.add(FSC_SORT_TYPE.toSortType(d.sort_type()), d.column_key());
						}
						si.setSortPolicy(sp);

						sio.addInfo(si);
					}
				}
			}

			// 汎用テーブル編集以外の場合
			if (!isTargetGeneralTable()) {
				MCSortOrderInfo si = MCSortOrderInfo.create();
	
				String id = c1.setting_info_id();
				if (isNull(id)) {
					c1.setting_info_id(sio.createSettingInfoID(c1.setting_unit_type(), no++));
				}
	
				si.setInitFlg(c1.init_flg());
				si.setSettingUnitType(c1.setting_unit_type());
				si.setSettingInfoID(c1.setting_info_id());
				si.setSettingInfoName(c1.setting_info_nm());
				si.setRemark(c1.remark());
	
				MCSortPolicy sp = new MCSortPolicy();
				for (InfoDtlR d : c2) {
					if (d.isEmpty() || d.isStatusDelete()) {
						continue;
					}
					sp.add(FSC_SORT_TYPE.toSortType(d.sort_type()), d.column_key());
				}
				si.setSortPolicy(sp);
	
				sio.addInfo(si);
			}
		}

		boolean isNotEmpty = sio.getInfoList().size() > 0 ? true : false;
		if (isNotEmpty) {
			Map<String, Integer> m = new HashMap<String, Integer>();
			m.put(u, no);
			sio.writeNoSave(pfx, m);
		}
		MCSortOrderResourceIO.saveResource();
	}

	@Override
	protected void setInitData() {
		super.setInitData();

		getInfoHdrR().clearAll();
		getInfoDtlL().clear();

		MCTable<?> t = getTargetTable();

		List<MCSortOrderInfo> l = new ArrayList<MCSortOrderInfo>();

		// デフォルトのソート順を追加する
		MCSortPolicy dp = t.getDefaultSortPolicy();
		if (dp.size() > 0) {
			MCSortOrderInfo d = MCSortOrderInfo.create();
			d.setInitFlg(true);
			d.setSettingUnitType(FXC_RESOURCE_SETTING_UNIT.TYPE_PGM.value());
			d.setSettingInfoID(getPgmSettingInfoID());
			d.setSettingInfoName(getDefaultSettingName());
			d.setSortPolicy(t.getDefaultSortPolicy());
			l.add(d);
		}

		List<MCSortOrderInfo> sl = new ArrayList<MCSortOrderInfo>();
		List<MCSortOrderInfo> el = new ArrayList<MCSortOrderInfo>();
		List<MCSortOrderInfo> ul = new ArrayList<MCSortOrderInfo>();
		for (MCSortOrderInfo i : t.getSortOrderInfoList()) {
			String y = i.getSettingUnitType();
			if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
				sl.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
				el.add(i);
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
				ul.add(i);
			}
		}

		String u = getSettingR().setting_unit();
		l.addAll(0, sl);
		if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
			l.addAll(0, el);
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
				l.addAll(0, ul);
			}
		}

		// BARCODEの場合にpfxが異なる。
		String pfx = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL, null);
		String pfx2 = t.getPersonalizedKeyPrefix(SORT_ORDER_PANEL, MCResourceLayerType.BARCODE);
		_setting_info_no_map = new MCSortOrderResourceIO().readSettingInfoNOMap(pfx, pfx2);

		//システム非表示対応 7.0.1
		MCRootPanel rp = t.getRootPanel();
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(rp);

		// 設定情報一覧リスト
		MCList<ListDtlR> ll = createListDtlL();
		// 旧仕様の設定情報名の接尾語
		int pi = 0;
		for (MCSortOrderInfo i : l) {
			FSBAP_SortOdrInfo si = new FSBAP_SortOdrInfo();

			ListDtlR lo = createListDtlR();
			lo.init_flg(i.getInitFlg());

			lo.setting_unit_type(i.getSettingUnitType());
			FXC_RESOURCE_SETTING_UNIT.putName(lo,
					ListDtlR.$setting_unit_type,
					ListDtlR.$setting_unit_type_nm);

			lo.setting_info_id(i.getSettingInfoID());
			lo.setting_info_nm(i.getSettingInfoName());
			if (isNull(lo.setting_info_nm())) {
				lo.setting_info_nm(
						getPreviousSettingNamePrefix() + String.valueOf(++pi));
			}
			lo.remark(i.getRemark());
			ll.add(lo);

			si.setSettingInfo(lo.clone());

			MCList<InfoDtlR> il = createInfoDtlL();
			MCSortPolicy sp = i.getSortPolicy();
			if (sp != null) {
				String[] na = sp.nameArray();
				SortType[] ya = sp.typeArray();
				for (int j = 0; j < sp.size(); j++) {
					MCColumnConfig c = getTargetColumnConfig(na[j]);
					if (c != null) {
						// システム非表示対応 7.0.1
						if(util.isVisibleColumn(t, c) == false) {
							continue;
						}

						InfoDtlR io = il.createRow();
						io.column_key(c.getBaseRowColumnName());
						io.column_nm(c.getMessageByLocale());
						io.sort_type(FSC_SORT_TYPE.toFSC_SORT_TYPE(
								ya[j]).value());
						il.add(io);
					}
				}
			}

			si.setSortOdrList(il);

			getSettingInfoMap().put(MCConst.createKey(i.getSettingUnitType(), i.getSettingInfoID()), si);
		}

		setListDtlL(ll);

		ListDtlTable.adjustWidth();
	}

	@Override
	protected FSBAP_SortOdrInfo getSettingInfo(ListDtlR data) {
		return (FSBAP_SortOdrInfo)super.getSettingInfo(data);
	}

	@Override
	protected boolean checkForApply() {
		if (!super.checkForApply()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		MCList<InfoDtlR> l = exceptEmpty(getInfoDtlL());

		// ソート情報の必須項目をチェックする
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			ListDtlR o = ListDtlTable.getSelectedMCRow();
			setInitListData(o);
			setInitInfoData(o);
		}

		return true;
	}

	@Override
	protected void afterCopyRow() {
		super.afterCopyRow();

		for (InfoDtlR o : getInfoDtlL()) {
			if (!o.isEmpty()) {
				o.setStatus(MCRow.CREATE);
			}
		}

		getListHdrR().init_flg(false);
		getListHdrR().setting_info_id(null);
		// 画面で現在アクティブになっている設定単位を設定
		getListHdrR().setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(getListHdrR(), 
				ListDtlR.$setting_unit_type, 
				ListDtlR.$setting_unit_type_nm);
// 2017/01/05 登録名も複製する
//		getListHdrR().setting_info_nm(null);

		setStatus(EDIT);
	}

	@Override
	protected boolean checkForUpd() {
		if (!super.checkForUpd()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		// ソート情報の必須項目をチェックする
		MCList<InfoDtlR> l = exceptEmpty(getInfoDtlL());
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		// ソート情報の重複をチェックする
		checkDuplicate(m, InfoDtlTable, InfoDtlR.$column_nm);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		return true;

	}

	@Override
	protected void afterUpd() {
		super.afterUpd();

		getTargetTable()._setSortOrderInfoList(null);
	}

	@Override
	protected void afterDel() {
		super.afterDel();

		getTargetTable()._setSortOrderInfoList(null);
	}

	@Override
	protected void afterDef() {
		super.afterDef();

		getTargetTable()._setSortOrderInfoList(null);
	}

	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * 設定対象のテーブルを指定してください。
	 * </li>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0048] 引数の指定に誤りがあった場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ]
	 * 起動タイプに {@link T1} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			Object o = args[0];
			if (o == null || !(o instanceof MCTable<?>)) {
				throw new MCAppException(FSBAC0049);
			}

			setTargetTable((MCTable<?>)o);
			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}

	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();

		InfoDtlTable.fillSpace();
	}


	@Override
	protected void listInit() {
		super.listInit();

		getInfoHdr_sort_type_ListPutter().setColumns(
				FSUAC_List.SortTypeAllCols.outAll());
		getInfoDtl_sort_type_ListPutter().setColumns(
				FSUAC_List.SortTypeCols.outAll());

		columnInfoDtl_column_nm.setListVisibleColumn(InfoDtlR.$column_nm);
	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);

		ListDtlR o = ListDtlTable.getSelectedMCRow();
		// 行が選択されなかった場合
		if (o == null) {
			getInfoDtlL().clear();
			getListHdrR().clearAll();
			setStatus(INIT);
			return;
		}

		setInitListData(o);
		setInitInfoData(o);
		setStatus(EDIT);

	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!super.doListDtl_VC(info)) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone() || !getListHdrR().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			setInitListData(ListDtlTable.getSelectedMCRow());
		}

		return true;

	}

	@Override
	public void doInfoHdr_sort_type_LC(MCEventInfo info) {
		super.doInfoHdr_sort_type_LC(info);

		String v = getInfoHdrR().sort_type();
		if (isNull(v)) {
			return;
		}

		for (InfoDtlR o : getInfoDtlL()) {
			if (isNull(o.column_key())) {
				continue;
			}
			columnInfoDtl_sort_type.setValue(o.getGUIIndex(), v);
		}

	}

	@Override
	public MCList getInfoDtl_column_nm(MCRow row, MCEventInfo info) {
		MCList<InfoDtlR> l = createInfoDtlL();

		//システム非表示対応 7.0.1
		MCRootPanel rp = _target_table.getRootPanel();
		MCSystemLocationUtil util = new MCSystemLocationUtil();
		util.initSystemInvisible(rp);

		for (MCColumnConfig c : getTargetColumnConfigs()) {
			if (!c.isSortable()) {
				continue;
			}

			String m = c.getMessageByLocale();
			if (isNull(m)) {
				continue;
			}

			// システム非表示対応 7.0.1
			if(util.isVisibleColumn(_target_table, c) == false) {
				continue;
			}

			InfoDtlR o = createInfoDtlR();
			o.column_key(c.getBaseRowColumnName());
			o.column_nm(m);
			l.add(o);
		}

		return l;
	}

	@Override
	protected boolean isSearchedProgram(String type, String pgmid) {
		return MCSortOrderResourceIO.isSearchedProgram(type, pgmid);
	}

	@Override
	protected int getSettingInfoNO(ListDtlR data) {
		return MCSortOrderResourceIO.getSettingInfoNO(data.setting_unit_type(), data.setting_info_id());
	}

	/**
	 * 削除処理を実行します。
	 */
	@Override
	protected void doDel() {
		// 汎用テーブル編集の場合、ステータスをDELETEにする
		// リソース更新後にリストから対象行を削除する
		if (isTargetGeneralTable()) {
			// 選択中の行を取得
			ListDtlR s = ListDtlTable.getSelectedMCRow();
			if (s != null) {
				s.setStatus(Status.DELETE);
				writeResource();
				getListDtlL().remove(s);
				clearSelection(ListDtlTable);
			}
		}
		// 汎用テーブル編集以外の場合、親クラスのメソッドを呼び出す。
		else {
			super.doDel();
		}
	}

	/**
	 * 対象画面が汎用テーブル編集かどうかを返します。
	 * 
	 * @return 汎用テーブル編集の場合はtrue、それ以外の場合はfalse
	 */
	private boolean isTargetGeneralTable() {
		MCTable<?> t = getTargetTable();
		if (t != null) {
			MCRootPanel p = t.getBaseRootPanel();

			if (p != null && p.isGeneralTable()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 設定情報を格納します。
	 */
	public class FSBAP_SortOdrInfo extends WBP_PersonalizeInfo {

		/**
		 * ソート情報のリストです。
		 */
		protected MCList<InfoDtlR> _sort_odr_list = null;

		/**
		 * コンストラクタです。
		 */
		public FSBAP_SortOdrInfo() {}

		/**
		 * ソート情報のリストを設定します。
		 *
		 * @param list ソート情報のリスト
		 */
		public void setSortOdrList(MCList<InfoDtlR> list) {
			_sort_odr_list = list;
		}

		/**
		 * ソート情報のリストを返します。
		 *
		 * @return ソート情報のリスト
		 */
		public MCList<InfoDtlR> getSortOdrList() {
			return _sort_odr_list;
		}

	}

}