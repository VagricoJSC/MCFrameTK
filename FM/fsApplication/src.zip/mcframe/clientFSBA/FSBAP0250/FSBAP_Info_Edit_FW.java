package mcframe.clientFSBA.FSBAP0250;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBF.FSBFP0100.*;
import mcframe.clientFSBF.FSBFP0120.*;
import mcframe.clientFSBF.FSBFP0130.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSUA.FSUAP0010.FSUAP_List;
import mcframe.clientCore.resource.MCConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_Info_Edit"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_Info_Edit_FW extends FSBAP_Info_Edit_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Info_Edit_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Info_Edit_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[InfoBtn]のボタン[copy]の押下時の処理
	 */
	public void doInfoBtn_copy(MCEventInfo info) {
		InfoR r = InfoTable.getSelectedMCRow();
		if (r != null) {
			InfoR cp = r.clone();
			if (!r.isStatusGUICreate()) {
				cp.setStatus(MCRow.CREATE);
			}
			insertRow(InfoTable, cp);
			setEDITStatus();
		}
	}

	/**
	 * Panel[Search]のボタン[search]の押下時の処理
	 */
	public void doSearch_search(MCEventInfo info) {
		callFS_FSBAL0250_Srch01();
	}
	/**
	 * Panel[InfoBtn]のボタン[upd]の押下時の処理
	 */
	public void doInfoBtn_upd(MCEventInfo info) {
		callFS_FSBAL0250_Upd01();
	}
	/**
	 * Panel[InfoBtn]のボタン[add]の押下時の処理
	 */
	public void doInfoBtn_add(MCEventInfo info) {
		InfoR r = createAddInfoRow();
		insertRow(InfoTable, r);
		setEDITStatus();
	}

	/**
	 * 行追加を行うInfoRを作成します。 
	 *
	 * @return 行追加を行うInfoR
	 */
	protected InfoR createAddInfoRow() {
		InfoR r = createInfoR();
		return r;
	}
	
	/**
	 * Panel[InfoBtn]のボタン[del]の押下時の処理
	 */
	public void doInfoBtn_del(MCEventInfo info) {
		InfoR r = deleteRow(InfoTable);
		if (r != null && r == InfoTable.getSelectedMCRow()) {
			if (r.isStatusDelete()) {
				setEDIT_DELStatus();
			}else{
				if (getInfoL().isEmpty()) {
					setINITStatus();
				}
				else{
					setEDITStatus();
					getEditR().setStatus(r.getStatus());
				}
			}
		}
	}
	/**
	 * [FS_FSBAL0250_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0250_Srch01Caller<P extends FSBAP_Info_Edit, B extends FS_FSBAL0250_Srch01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FS_FSBAL0250_Srch01Caller(P p, B b) {
			super(p, b);
		}
		
		@Override
		protected void clear() {
			super.clear();
			getEditR().clearAll();
			getEditR().setGUIIndex(-1);
		}

		@Override
		protected boolean isDownBlockChanged() {
			boolean rtn = super.isDownBlockChanged();
			if (!rtn) {
				rtn = InfoPanel.isChanged();
			}
			return rtn;
		}
		
		/**
		 * 複数のチェックを行い、エラーがあった場合のメッセージを msgList に格納します。
		 * <P>
		 * デフォルト実装：{@link #checkReq(MCMessageList) checkReq(MCMessageList)}を呼び出す。
		 * </P>
		 * 
		 * @param msgList
		 */
		@Override
		protected void checkForCallStack(MCMessageList msgList) {
			super.checkForCallStack(msgList);
			checkDTM(msgList);
		}
		
		/**
		 * 検索結果がある場合のＧＵＩ部品のモード設定
		 */
		@Override
		protected void setMode() {
			super.setMode();
			if (getInfoL().size() > 0) {
				setLocaleAndSetKey(getInfoL());
				InfoTable.selectLeftmostColumn(0);
				setEDITStatus();
			}else{
				setINITStatus();
			}
		}
		@Override
		protected void moveFocus() {
			super.moveFocus();
			InfoTable.selectLeftmostColumn(0);
		}
		
		@Override
		protected void moveFocusNoDown() {
			super.moveFocusNoDown();
			Search_dtm_fm.mcRequestFocus();
		}

		@Override
		protected void show() {
			super.show();
			InfoTable.fillSpace();
		}
		
		@Override
		protected void setModeNoDown() {
			super.setModeNoDown();
			InfoTable.fillSpace();
			setINITStatus();
		}		
	}
	

	/**
	 * [FS_FSBAL0250_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0250_Upd01Caller<P extends FSBAP_Info_Edit, B extends FS_FSBAL0250_Upd01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		MCList<InfoR> _up0 = createInfoL();
		
		protected FS_FSBAL0250_Upd01Caller(P p, B b) {
			super(p, b);
		}
		
		@Override
		protected void initCaller() {
			super.initCaller();
			_up0 = getInfoL().subList(new MCRowMatcher<InfoR>() {

				@Override
				public boolean match(InfoR row) {
					if (row.isStatusNone()) {
						return false;
					}
					if (row.isStatusCreate() && 
							isViewEmpty(InfoTable, row)) {
						return false;
					}
					return true;
				}
				
			});
		}
		@Override
		protected void setupParam() {
			super.setupParam();
			bridge.up0().setAll(_up0);
		}
		
		
		/**
		 * 複数のチェックを行い、エラーがあった場合のメッセージを msgList に格納します。
		 * <P>
		 * デフォルト実装：{@link #checkReq(MCMessageList) checkReq(MCMessageList)}を呼び出す。
		 * </P>
		 * 
		 * @param msgList
		 */
		@Override
		protected void checkForCallStack(MCMessageList msgList) {
			super.checkForCallStack(msgList);
			checkInfo(msgList);
		}	
		
		@Override
		protected void statusClear() {
			getInfoL().setRefTime(bridge.p_FS_FSBAL0250_Upd01.getCommitTime());
			getInfoL().statusChangedList().setStatus(MCRow.NONE);
			if (getInfoL().size() == 0) {
				getEditR().clear();
				setINITStatus();
			}
		}
		
		@Override
		protected void moveFocus() {
			super.moveFocus();
			if (getInfoL().size() > 0) {
				InfoTable.selectLeftmostColumn(0);
			}else{
				SearchPanel.focusFirstComponent();
			}
			selectRowView();
		}
		@Override
		protected void show() {
			getInfoL().removeAll(getInfoL().subList(MCRow.DELETE));
			super.show();
			InfoTable.sort();
			InfoTable.fillSpace();
		}
		
		
	}

	@Override
	protected void listInit() {
		super.listInit();
		
		// ロケール
		getEdit_locale_cd_ListPutter().setColumns(
										FSUAP_List.LocaleCols.$o_lcl_cd,
										FSUAP_List.LocaleCols.$o_lcl_nm);
	}	
	/**
	 * ソート順の設定
	 */
	protected void setSortColumn() {
		super.setSortColumn();
		InfoTable.addSortColumn(columnInfo_start_dt, MCList.SortType.ASC);
		InfoTable.addSortColumn(columnInfo_end_dt, MCList.SortType.ASC);
		InfoTable.addSortColumn(columnInfo_notice_title, MCList.SortType.ASC);
		
	}
	
	@Override
	public void setINITStatus() {
		super.setINITStatus();
		SearchPanel.focusFirstComponent();
	}

	
	/**
	 * 日時のチェック処理<P>
	 *
	 * @param ls
	 */
	protected void checkDTM(MCMessageList ls) {
		ls.addAll(checkBeforeAfter(Search_dtm_fm, Search_dtm_to));
	}
	/**
	 * 更新前のチェック処理<P>
	 *
	 * @param ls メッセージリスト
	 */
	protected void checkInfo(MCMessageList ls) {
		
		for (int i = 0; i < getInfoL().size(); i++) {
			InfoR r = getInfoL().get(i);
			if (r.isStatusNone() || r.isStatusDelete()) {
				continue;
			}
			if (r.isStatusCreate() && 
					isViewEmpty(InfoTable, r)) {
				continue;
			}
			if (r.start_dt() == null) {
				MCMessage msg = new MCMessage(FSBAC0015,
										Edit_start_dt.getMessageByLocale(),
										r.getGUIIndex() + 1);
				msg.setCauseRow(r, InfoR.$start_dt);
				ls.add(msg);
			}
			if (r.end_dt() == null) {
				MCMessage msg = new MCMessage(FSBAC0015,
											Edit_end_dt.getMessageByLocale(),
											r.getGUIIndex() + 1);
				msg.setCauseRow(r, InfoR.$end_dt);
				ls.add(msg);
			}
			if (r.start_dt() != null && r.end_dt() != null &&
					r.start_dt().gt(r.end_dt())) {
				MCMessage msg = new MCMessage(FSBAC0036);
				msg.setCauseRow(r, InfoR.$end_dt);
				ls.add(msg);
			}
			//必須
			if (r.notice_title() == null) {
				MCMessage msg = new MCMessage(FSBAC0015,
										Edit_notice_title.getMessageByLocale(),
										r.getGUIIndex() + 1);
				msg.setCauseRow(r, InfoR.$notice_title);
				ls.add(msg);
			}
		}
	}
	
	@Override
	public void doInfo_NC(MCEventInfo info){
		selectRowView();
	}
	
	/**
	 * 選択されている行を見出しに表示します。<P>
	 */		
	protected void selectRowView() {
		int index = InfoTable.getMCSelectedRow();
		if (index >= 0) {
			InfoR row = InfoTable.getSelectedMCRow();
			copy(getEditR(), row, createMap_EditR_InfoR());
			if (row.isStatusDelete()) {
				setEDIT_DELStatus();
			}else{
				setEDITStatus();
			}
		}else{
			setEditR(null);
			if (!getInfoL().isEmpty() && !getInfoL().isStatusNone()) {
				setEDIT_DELStatus();
			}else{
				setINITStatus();
			}
		}
	}
	
	
	/**
	 * 見出し枠で変更した内容を一覧に戻します。<P>
	 */
	protected void reverceRow() {
		InfoR lr = InfoTable.getSelectedMCRow();
		if (lr != null) {
			copy(lr, getEditR(), createMap_InfoR_EditR());
		}
	}

	@Override
	public void doEdit_start_dt_NC(MCEventInfo info){
		reverceRow();
	}

	@Override
	public void doEdit_end_dt_NC(MCEventInfo info){
		reverceRow();
	}

	@Override
	public void doEdit_Locale_NC(MCEventInfo info){
		reverceRow();
	}

	@Override
	public void doEdit_locale_cd_NC(MCEventInfo info){
		reverceRow();
	}

	@Override
	public void doEdit_notice_title_NC(MCEventInfo info){
		reverceRow();
	}

	@Override
	public void doEdit_text_line_NC(MCEventInfo info){
		reverceRow();
	}

	@Override
	protected void listenerInit() {
		super.listenerInit();
		Edit_ext_PPanel.addNCListener(this);
	}
	
	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Edit_ext_PPanel) {
			doEdit_ext_PPanel_NC(info);
		}
	}
	
	/**
	 * [Edit_ext_PPanel]が変更された際のNotificationChangeイベント
	 *
	 * @param info イベント情報
	 */
	public void doEdit_ext_PPanel_NC(MCEventInfo info){
		reverceRow();
	}
	

	/**
	 * ロケールの名称をセットと内部キーの設定を行います。<P>
	 */
	protected void setLocaleAndSetKey(MCList<InfoR> infoL) {
		MCList<MCRow> ls = MCConfig.client.getEntryLocaleList(
										InfoR.$locale_cd, InfoR.$Locale);
		for (int i = 0; i < infoL.size(); i++) {
			InfoR r = infoL.get(i);
			MCList<MCRow> sub = ls.subList(InfoR.$locale_cd, r.locale_cd());
			if (sub.size() > 0) {
				r.Locale(sub.getString(0, InfoR.$Locale));
			}
		}
	}
	
	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		InfoTable.fillSpace();
	}
	
	@Override
	public boolean isChanged(MCTable<?> tbl) {
		// 全カラム読み取り専用のテーブルで閉確を表示させるためオーバーライド
		if (tbl == null) {
			return false;
		}
		MCList<?> list = tbl.getList();
		if (list == null) {
			return false;
		}

		MCModeInfo mi = tbl.getModeInfo();
		if (mi != null && MCMode.INVISIBLE_STATUS == mi.getStatus()) {
			return false;
		}
		return !list.isStatusNone();
	}

	/**
	 * EditRにInfoRから項目コピーを行うRowMapperを生成します。
	 *
	 * このメソッドはRowMapperAssistを利用して生成されました。
	 */
	protected Map_EditR_InfoR<EditR,InfoR> createMap_EditR_InfoR() {
		return new Map_EditR_InfoR<EditR, InfoR>();
	}

	/**
	 * EditRにInfoRから項目コピーを行うRowMapperクラスです。
	 *
	 * このクラスはRowMapperAssistを利用して生成されました。
	 */
	public class Map_EditR_InfoR<D extends EditR, S extends InfoR> extends MCRowMapper<D,S>{
		/**
		 * EditRにInfoRから項目コピーを行います。
		 *
		 * このメソッドはRowMapperAssistを利用して生成されました。
		 */
		@Override
		public void valueCopy(D dest, S src){
			dest.notice_id(src.notice_id());
			dest.start_dt(src.start_dt());
			dest.end_dt(src.end_dt());
			dest.Locale(src.Locale());
			dest.locale_cd(src.locale_cd());
			dest.co_cd(src.co_cd());
			dest.co_nm(src.co_nm());
			dest.attr1(src.attr1());
			dest.attr2(src.attr2());
			dest.attr3(src.attr3());
			dest.notice_title(src.notice_title());
			dest.text_line(src.text_line());
		}
	}	

	
	/**
	 * InfoRにEditRから項目コピーを行うRowMapperを生成します。
	 *
	 * このメソッドはRowMapperAssistを利用して生成されました。
	 */
	protected Map_InfoR_EditR<InfoR,EditR> createMap_InfoR_EditR() {
		return new Map_InfoR_EditR<InfoR, EditR>();
	}

	/**
	 * InfoRにEditRから項目コピーを行うRowMapperクラスです。
	 *
	 * このクラスはRowMapperAssistを利用して生成されました。
	 */
	public class Map_InfoR_EditR<D extends InfoR, S extends EditR> extends MCRowMapper<D,S>{
		/**
		 * InfoRにEditRから項目コピーを行います。
		 *
		 * このメソッドはRowMapperAssistを利用して生成されました。
		 */
		@Override
		public void valueCopy(D dest, S src){
			dest.notice_id(src.notice_id());
			dest.start_dt(src.start_dt());
			dest.end_dt(src.end_dt());
			dest.Locale(src.Locale());
			dest.locale_cd(src.locale_cd());
			dest.co_cd(src.co_cd());
			dest.co_nm(src.co_nm());
			dest.attr1(src.attr1());
			dest.attr2(src.attr2());
			dest.attr3(src.attr3());
			dest.notice_title(src.notice_title());
			dest.text_line(src.text_line());
		}
	}	

}