package mcframe.clientFSBA.FSBAP0250;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Edit"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class EditR_FW_A extends MCConstRow {

	/**
	 *  情報ＩＤ.<p>
	 *
	 */
	public static final String $notice_id = "notice_id";
	/**
	 *  通知開始日.<p>
	 *
	 */
	public static final String $start_dt = "start_dt";
	/**
	 *  通知終了日.<p>
	 *
	 */
	public static final String $end_dt = "end_dt";
	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public static final String $locale_cd = "locale_cd";
	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public static final String $Locale = "Locale";
	public static final String $ext = "ext";
	/**
	 *  情報タイトル.<p>
	 *
	 */
	public static final String $notice_title = "notice_title";
	/**
	 *  情報内容.<p>
	 *
	 */
	public static final String $text_line = "text_line";

	public static final String $co_cd = $ext + ".co_cd";
	public static final String $co_nm = $ext + ".co_nm";
	public static final String $attr1 = $ext + ".attr1";
	public static final String $attr2 = $ext + ".attr2";
	public static final String $attr3 = $ext + ".attr3";

	public static final MCMeta notice_id_META = createCommonMeta($notice_id, mcframe.commonCore.meta.M_META.NUM_STR);
	public static final MCMeta start_dt_META = createCommonMeta($start_dt, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta end_dt_META = createCommonMeta($end_dt, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta locale_cd_META = createCommonMeta($locale_cd, mcframe.commonCore.meta.M_META.LOCALE_CD);
	public static final MCMeta Locale_META = createCommonMeta($Locale, mcframe.commonCore.meta.M_META.LOCALE_NM);
	public static final MCMeta ext_META = createInnerRowMeta($ext, mcframe.clientFSBF.FSBFP0100.ExtR.class);
	public static final MCMeta notice_title_META = createCommonMeta($notice_title, mcframe.commonCore.meta.M_META.NOTICE_TITLE);
	public static final MCMeta text_line_META = createCommonMeta($text_line, mcframe.commonCore.meta.M_META.TEXT_LINE);

	protected static final ConstMetaList<EditR> constMetas = new ConstMetaList<EditR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			notice_id_META,
			start_dt_META,
			end_dt_META,
			locale_cd_META,
			Locale_META,
			ext_META,
			notice_title_META,
			text_line_META
		},
		new String[][]{
			{
				"co_cd",
				"co_nm",
				"attr1",
				"attr2",
				"attr3"
			},
			{
				$co_cd,
				$co_nm,
				$attr1,
				$attr2,
				$attr3
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected EditR_FW_A(ConstMetaList<? extends EditR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public EditR clone() {
		return (EditR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public EditR createInstance() {
		return (EditR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public EditR getValues(String... names) {
		return (EditR) super.getValues(names);
	}



	/**
	 *  情報ＩＤ.<p>
	 *
	 */
	public String notice_id() {
		return getConstString(offset + 0, $notice_id);
	}

	/**
	 *  情報ＩＤ.<p>
	 *
	 */
	public void notice_id(String value) {
		setConstString(offset + 0, $notice_id, value);
	}


	/**
	 *  通知開始日.<p>
	 *
	 */
	public MCDate start_dt() {
		return getConstDate(offset + 1, $start_dt);
	}

	/**
	 *  通知開始日.<p>
	 *
	 */
	public void start_dt(MCDate value) {
		setConstDate(offset + 1, $start_dt, value);
	}


	/**
	 *  通知終了日.<p>
	 *
	 */
	public MCDate end_dt() {
		return getConstDate(offset + 2, $end_dt);
	}

	/**
	 *  通知終了日.<p>
	 *
	 */
	public void end_dt(MCDate value) {
		setConstDate(offset + 2, $end_dt, value);
	}


	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public String locale_cd() {
		return getConstString(offset + 3, $locale_cd);
	}

	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public void locale_cd(String value) {
		setConstString(offset + 3, $locale_cd, value);
	}


	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public String Locale() {
		return getConstString(offset + 4, $Locale);
	}

	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public void Locale(String value) {
		setConstString(offset + 4, $Locale, value);
	}


	public mcframe.clientFSBF.FSBFP0100.ExtR ext(){
		return (mcframe.clientFSBF.FSBFP0100.ExtR) getConstInnerRow(offset + 5, $ext);
	}
	
	public void ext(mcframe.clientFSBF.FSBFP0100.ExtR row){
		setConstInnerRow(offset + 5, $ext, row);
	}


	/**
	 *  情報タイトル.<p>
	 *
	 */
	public String notice_title() {
		return getConstString(offset + 6, $notice_title);
	}

	/**
	 *  情報タイトル.<p>
	 *
	 */
	public void notice_title(String value) {
		setConstString(offset + 6, $notice_title, value);
	}


	/**
	 *  情報内容.<p>
	 *
	 */
	public String text_line() {
		return getConstString(offset + 7, $text_line);
	}

	/**
	 *  情報内容.<p>
	 *
	 */
	public void text_line(String value) {
		setConstString(offset + 7, $text_line, value);
	}


	public String getString(String name) {
		if ($notice_id.equalsIgnoreCase(name)) {
			return notice_id();
		}
		if ($locale_cd.equalsIgnoreCase(name)) {
			return locale_cd();
		}
		if ($Locale.equalsIgnoreCase(name)) {
			return Locale();
		}
		if ($notice_title.equalsIgnoreCase(name)) {
			return notice_title();
		}
		if ($text_line.equalsIgnoreCase(name)) {
			return text_line();
		}
		return super.getString(name);
	}
	public MCDate getDate(String name) {
		if ($start_dt.equalsIgnoreCase(name)) {
			return start_dt();
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			return end_dt();
		}
		return super.getDate(name);
	}

	public String getStringNE(String name) {
		if ($notice_id.equalsIgnoreCase(name)) {
			return notice_id();
		}
		if ($locale_cd.equalsIgnoreCase(name)) {
			return locale_cd();
		}
		if ($Locale.equalsIgnoreCase(name)) {
			return Locale();
		}
		if ($notice_title.equalsIgnoreCase(name)) {
			return notice_title();
		}
		if ($text_line.equalsIgnoreCase(name)) {
			return text_line();
		}
		return super.getStringNE(name);
	}
	public MCDate getDateNE(String name) {
		if ($start_dt.equalsIgnoreCase(name)) {
			return start_dt();
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			return end_dt();
		}
		return super.getDateNE(name);
	}

	public void setString(String name, String value) {
		if ($notice_id.equalsIgnoreCase(name)) {
			notice_id(value);
			return;
		}
		if ($locale_cd.equalsIgnoreCase(name)) {
			locale_cd(value);
			return;
		}
		if ($Locale.equalsIgnoreCase(name)) {
			Locale(value);
			return;
		}
		if ($notice_title.equalsIgnoreCase(name)) {
			notice_title(value);
			return;
		}
		if ($text_line.equalsIgnoreCase(name)) {
			text_line(value);
			return;
		}
		super.setString(name, value);
	}
	public void setDate(String name, MCDate value) {
		if ($start_dt.equalsIgnoreCase(name)) {
			start_dt(value);
			return;
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			end_dt(value);
			return;
		}
		super.setDate(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($notice_id.equalsIgnoreCase(name)) {
			notice_id(value);
			return;
		}
		if ($locale_cd.equalsIgnoreCase(name)) {
			locale_cd(value);
			return;
		}
		if ($Locale.equalsIgnoreCase(name)) {
			Locale(value);
			return;
		}
		if ($notice_title.equalsIgnoreCase(name)) {
			notice_title(value);
			return;
		}
		if ($text_line.equalsIgnoreCase(name)) {
			text_line(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setDateNE(String name, MCDate value) {
		if ($start_dt.equalsIgnoreCase(name)) {
			start_dt(value);
			return;
		}
		if ($end_dt.equalsIgnoreCase(name)) {
			end_dt(value);
			return;
		}
		super.setDateNE(name, value);
	}

	public MCRow getInnerRow(String name) {
		if ($ext.equalsIgnoreCase(name)) {
			return ext();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($ext.equalsIgnoreCase(name)) {
			ext(
				((MCContainerMeta) ext_META).castInnerRow(mcframe.clientFSBF.FSBFP0100.ExtR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public String co_cd() {
		return ext().co_cd();
	}

	public void co_cd(String value) {
		ext().co_cd(value);
	}

	public String co_nm() {
		return ext().co_nm();
	}

	public void co_nm(String value) {
		ext().co_nm(value);
	}

	public String attr1() {
		return ext().attr1();
	}

	public void attr1(String value) {
		ext().attr1(value);
	}

	public String attr2() {
		return ext().attr2();
	}

	public void attr2(String value) {
		ext().attr2(value);
	}

	public String attr3() {
		return ext().attr3();
	}

	public void attr3(String value) {
		ext().attr3(value);
	}

}

