package mcframe.clientFSBA.FSBAP0250;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_Info_Edit]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0250.Srch01.UP.BLOCK0")){
			return FS_FSBAL0250_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0250.Srch01.DOWN.BLOCK0")){
			return FS_FSBAL0250_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0250.Upd01.UP.BLOCK0")){
			return FS_FSBAL0250_Upd01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0250.Upd01.DOWN.BLOCK0")){
			return FS_FSBAL0250_Upd01_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
		
	
	static final MCOperationInfo FS_FSBAL0250_Srch01_INFO = new MCOperationInfo("FS", "FSBAL0250", "Srch01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0250_Srch01_UP_BLOCK0() {
		/** Ope.のBlock [Srch01_Cnd] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0250", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("dtm_fm", "dtm_fm"),
				MCItemDef.create("dtm_to", "dtm_to"),
				MCItemDef.create("ext" + ".co_cd", "co_cd"),
				MCItemDef.create("ext" + ".attr1", "ext_attr1"),
				MCItemDef.create("ext" + ".attr2", "ext_attr2"),
				MCItemDef.create("ext" + ".attr3", "ext_attr3"),
				MCItemDef.create("ext_flg", "ext_flg")
			}
			,
			MCBlockDef.create("Search")
		);
	}


	public static MCContainerDef FS_FSBAL0250_Srch01_DOWN_BLOCK0() {
	/** Ope.のBlock [Srch01_Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0250", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("notice_id", "notice_id"),
				MCItemDef.create("start_dt", "start_dt"),
				MCItemDef.create("end_dt", "end_dt"),
				MCItemDef.create("locale_cd", "locale_cd"),
				MCItemDef.create("notice_title", "notice_title"),
				MCItemDef.create("text_line", "text_line"),
				MCItemDef.create("extL" + ".co_cd", "co_cd"),
				MCItemDef.create("extL" + ".co_nm", "co_nm"),
				MCItemDef.create("extL" + ".attr1", "ext_attr1"),
				MCItemDef.create("extL" + ".attr2", "ext_attr2"),
				MCItemDef.create("extL" + ".attr3", "ext_attr3"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Info")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0250_Upd01_INFO = new MCOperationInfo("FS", "FSBAL0250", "Upd01", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0250_Upd01_UP_BLOCK0() {
		/** Ope.のBlock [Upd01_Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0250", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("notice_id", "notice_id"),
				MCItemDef.create("start_dt", "start_dt"),
				MCItemDef.create("end_dt", "end_dt"),
				MCItemDef.create("locale_cd", "locale_cd"),
				MCItemDef.create("notice_title", "notice_title"),
				MCItemDef.create("text_line", "text_line"),
				MCItemDef.create("extL" + ".co_cd", "co_cd"),
				MCItemDef.create("extL" + ".attr1", "ext_attr1"),
				MCItemDef.create("extL" + ".attr2", "ext_attr2"),
				MCItemDef.create("extL" + ".attr3", "ext_attr3"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Info")
		);
	}


	public static MCContainerDef FS_FSBAL0250_Upd01_DOWN_BLOCK0() {
	/** Ope.のBlock [Upd01_Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0250", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("notice_id", "notice_id"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Info")
		);
	}
	//FMCB DEF_CLASSES END
}

