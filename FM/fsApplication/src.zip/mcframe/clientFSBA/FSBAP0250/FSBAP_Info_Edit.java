// FMSE PANEL_EI
package mcframe.clientFSBA.FSBAP0250;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.commonCore.annotation.EI;
import mcframe.clientFSBF.FSBFP0100.*;
import mcframe.clientFSBF.FSBFP0120.*;
import mcframe.clientFSBF.FSBFP0130.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

/**
 * 画面"FSBAP_Info_Edit"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FSBAP_Info_Edit extends FSBAP_Info_Edit_FW {

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Info_Edit() {
		super();
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Info_Edit(String name) {
		super(name);
	}

	public class FS_FSBAL0250_Srch01Bridge extends FSBAP_Info_Edit_FW.FS_FSBAL0250_Srch01Bridge {
	}
	public class FS_FSBAL0250_Upd01Bridge extends FSBAP_Info_Edit_FW.FS_FSBAL0250_Upd01Bridge {
	}

}