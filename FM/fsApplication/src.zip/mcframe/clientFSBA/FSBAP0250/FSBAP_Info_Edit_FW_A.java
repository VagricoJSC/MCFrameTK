package mcframe.clientFSBA.FSBAP0250;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0250.FSBAP_Info_Edit_FW.FS_FSBAL0250_Srch01Caller;
import mcframe.clientFSBA.FSBAP0250.FSBAP_Info_Edit_FW.FS_FSBAL0250_Upd01Caller;

/**
 * 画面"FSBAP_Info_Edit"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_Info_Edit_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0250";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Search]ブロック関連のField定義
	public MCPanel SearchPanel = null;
	public MCTitledBorder SearchTitledBorder = null;
	// [Search]ブロックの項目のField定義
	public MCLabel Search_dtm_fm_Label = null;
	/**
	 *  通知開始日.<p>
	 *
	 */
	public MCDateField Search_dtm_fm = null;
	public MCLabel Search_dtm_to_Label = null;
	/**
	 *  通知終了日.<p>
	 *
	 */
	public MCDateField Search_dtm_to = null;
	public mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY Search_ext_PPanel;
	public MCTextComboBox Search_co_cd;	// [Search]の[ext.co_cd]を[Search_co_cd]としてエイリアス定義。
	public MCTextField Search_attr1;	// [Search]の[ext.attr1]を[Search_attr1]としてエイリアス定義。
	public MCTextField Search_attr2;	// [Search]の[ext.attr2]を[Search_attr2]としてエイリアス定義。
	public MCTextField Search_attr3;	// [Search]の[ext.attr3]を[Search_attr3]としてエイリアス定義。
	/**
	 *  検索する.<p>
	 *
	 */
	public MCButton Search_search = null;
	// [Info]ブロック関連のField定義
	public MCPanel InfoPanel = null;
	public MCScrollPane InfoScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0250.InfoR> InfoTable = null;
	// [Info]ブロックの項目のField定義
	/**
	 *  通知開始日.<p>
	 *
	 */
	public MCColumnConfig columnInfo_start_dt = null;
	/**
	 *  通知終了日.<p>
	 *
	 */
	public MCColumnConfig columnInfo_end_dt = null;
	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_locale_cd = null;
	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public MCColumnConfig columnInfo_Locale = null;
	public mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL Info_extL_PPanel;
	public MCColumnConfig columnInfo_co_cd;// [Info]の[extL.co_cd]を[columnInfo_co_cd]としてエイリアス定義。
	public MCColumnConfig columnInfo_co_nm;// [Info]の[extL.co_nm]を[columnInfo_co_nm]としてエイリアス定義。
	public MCColumnConfig columnInfo_attr1;// [Info]の[extL.attr1]を[columnInfo_attr1]としてエイリアス定義。
	public MCColumnConfig columnInfo_attr2;// [Info]の[extL.attr2]を[columnInfo_attr2]としてエイリアス定義。
	public MCColumnConfig columnInfo_attr3;// [Info]の[extL.attr3]を[columnInfo_attr3]としてエイリアス定義。
	/**
	 *  情報タイトル.<p>
	 *
	 */
	public MCColumnConfig columnInfo_notice_title = null;
	/**
	 *  情報内容.<p>
	 *
	 */
	public MCColumnConfig columnInfo_text_line = null;
	// [Edit]ブロック関連のField定義
	public MCPanel EditPanel = null;
	// [Edit]ブロックの項目のField定義
	public MCLabel Edit_start_dt_Label = null;
	/**
	 *  通知開始日.<p>
	 *
	 */
	public MCDateField Edit_start_dt = null;
	public MCLabel Edit_end_dt_Label = null;
	/**
	 *  通知終了日.<p>
	 *
	 */
	public MCDateField Edit_end_dt = null;
	public MCLabel Edit_locale_cd_Label = null;
	/**
	 *  ロケールＣＤ.<p>
	 *
	 */
	public MCTextComboBox Edit_locale_cd = null;
	/**
	 * Ｌｏｃａｌｅ ロケール名.<p>
	 *
	 */
	public MCTextField Edit_Locale = null;
	public mcframe.clientFSBF.FSBFP0100.FSBFP_Ext Edit_ext_PPanel;
	public MCTextComboBox Edit_co_cd;	// [Edit]の[ext.co_cd]を[Edit_co_cd]としてエイリアス定義。
	public MCTextField Edit_co_nm;	// [Edit]の[ext.co_nm]を[Edit_co_nm]としてエイリアス定義。
	public MCTextField Edit_attr1;	// [Edit]の[ext.attr1]を[Edit_attr1]としてエイリアス定義。
	public MCTextField Edit_attr2;	// [Edit]の[ext.attr2]を[Edit_attr2]としてエイリアス定義。
	public MCTextField Edit_attr3;	// [Edit]の[ext.attr3]を[Edit_attr3]としてエイリアス定義。
	public MCLabel Edit_notice_title_Label = null;
	/**
	 *  情報タイトル.<p>
	 *
	 */
	public MCTextField Edit_notice_title = null;
	public MCLabel Edit_text_line_Label = null;
	public MCScrollPane Edit_text_lineScrollPane = null;
	/**
	 *  情報内容.<p>
	 *
	 */
	public MCTextArea Edit_text_line = null;
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 * 追加 追加.<p>
	 *
	 */
	public MCButton InfoBtn_add = null;
	/**
	 * 削除 削除.<p>
	 *
	 */
	public MCButton InfoBtn_del = null;
	/**
	 * 行コピー 行コピー.<p>
	 *
	 */
	public MCButton InfoBtn_copy = null;
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton InfoBtn_upd = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [EDIT_DEL]モードを表す定数 */
	public static final String EDIT_DEL = "EDIT_DEL";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, EDIT_DEL};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0250_Srch01]のCallerの作成 */
	protected FSBAP_Info_Edit_FW.FS_FSBAL0250_Srch01Caller createFS_FSBAL0250_Srch01() {
		FSBAP_Info_Edit_FW.FS_FSBAL0250_Srch01Caller<FSBAP_Info_Edit, FS_FSBAL0250_Srch01Bridge>
		caller = ((FSBAP_Info_Edit_FW)this).new FS_FSBAL0250_Srch01Caller<FSBAP_Info_Edit, FS_FSBAL0250_Srch01Bridge>(
					(FSBAP_Info_Edit)this, new FS_FSBAL0250_Srch01Bridge());
		return caller;
	}
	/** [FS_FSBAL0250_Srch01]の呼び出し */
	protected void callFS_FSBAL0250_Srch01() {
		MCCaller caller = createFS_FSBAL0250_Srch01();
		caller.exec();
	}
	/** [FS_FSBAL0250_Upd01]のCallerの作成 */
	protected FSBAP_Info_Edit_FW.FS_FSBAL0250_Upd01Caller createFS_FSBAL0250_Upd01() {
		FSBAP_Info_Edit_FW.FS_FSBAL0250_Upd01Caller<FSBAP_Info_Edit, FS_FSBAL0250_Upd01Bridge>
		caller = ((FSBAP_Info_Edit_FW)this).new FS_FSBAL0250_Upd01Caller<FSBAP_Info_Edit, FS_FSBAL0250_Upd01Bridge>(
					(FSBAP_Info_Edit)this, new FS_FSBAL0250_Upd01Bridge());
		return caller;
	}
	/** [FS_FSBAL0250_Upd01]の呼び出し */
	protected void callFS_FSBAL0250_Upd01() {
		MCCaller caller = createFS_FSBAL0250_Upd01();
		caller.exec();
	}
	/** [Search]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0250.SearchR aSearchR;
	/** [Info]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0250.InfoR> aInfoL;
	/** [Edit]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0250.EditR aEditR;

	/**
	 * 項目コピーによってaSearchRを設定します。
	 *
	 * aSearchRのインスタンスは変更されません。
	 *
	 * @param row SearchR
	 */
	public void setSearchR(mcframe.clientFSBA.FSBAP0250.SearchR row) {
		if (row != null) {
			MCRow.copyall(getSearchR(), row);
		}
	}

	/**
	 * [Search]ブロックのコンテナaSearchRを返します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0250.SearchR getSearchR() {
		return aSearchR;
	}

	/**
	 * aSearchRを作成します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0250.SearchR createSearchR() {
		return mcframe.clientFSBA.FSBAP0250.SearchR.create();
	}

	/**
	 * コピーによってaInfoLを設定します。
	 *
	 * aInfoLのインスタンスは変更されません。
	 *
	 * @param dataset InfoL
	 */
	public void setInfoL(MCList<mcframe.clientFSBA.FSBAP0250.InfoR> aList) {
		if (getInfoL() != aList) {
			getInfoL().setAll(aList);
		}
	}

	/**
	 * [Info]ブロックのコンテナaInfoLを返します。
	 *
	 * @return InfoL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0250.InfoR> getInfoL() {
		return aInfoL;
	}

	/**
	 * aInfoRを作成します。
	 *
	 * @return InfoR
	 */
	public mcframe.clientFSBA.FSBAP0250.InfoR createInfoR() {
		return mcframe.clientFSBA.FSBAP0250.InfoR.create();
	}

	/**
	 * aInfoLを作成します。
	 *
	 * @return InfoL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0250.InfoR> createInfoL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0250.InfoR.class);
	}

	/**
	 * InfoTableを初期化します。
	 */
	protected void createInfoTable(){
		if(InfoTable == null){
			InfoTable = beansFactory.createTable2("Info.table");
		}
	}

	/**
	 * 項目コピーによってaEditRを設定します。
	 *
	 * aEditRのインスタンスは変更されません。
	 *
	 * @param row EditR
	 */
	public void setEditR(mcframe.clientFSBA.FSBAP0250.EditR row) {
		if (row != null) {
			MCRow.copyall(getEditR(), row);
		}
	}

	/**
	 * [Edit]ブロックのコンテナaEditRを返します。
	 *
	 * @return EditR
	 */
	public mcframe.clientFSBA.FSBAP0250.EditR getEditR() {
		return aEditR;
	}

	/**
	 * aEditRを作成します。
	 *
	 * @return EditR
	 */
	public mcframe.clientFSBA.FSBAP0250.EditR createEditR() {
		return mcframe.clientFSBA.FSBAP0250.EditR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getSearchR())) ret.add(getSearchR());
		if(!MCCollectionUtil.contains(ret, getInfoL())) ret.add(getInfoL());
		if(!MCCollectionUtil.contains(ret, getEditR())) ret.add(getEditR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getSearchR()) return "Search";
		if(aCnt == getInfoL()) return "Info";
		if(aCnt == getEditR()) return "Edit";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Search")) return getSearchR();
		if(bId.equals("Info")) return getInfoL();
		if(bId.equals("Edit")) return getEditR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(SearchPanel);
		ret.add(InfoPanel);
		ret.add(EditPanel);
		ret.add(InfoBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Info_Edit_FW_A() {
		aSearchR = createSearchR();
		aInfoL = createInfoL();
		aEditR = createEditR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Info_Edit_FW_A(String name) {
		aSearchR = createSearchR();
		aInfoL = createInfoL();
		createInfoTable();
		InfoTable.setRowName(name);
		aEditR = createEditR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_Info_Edit_FW.jbCreateSearch((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbCreateInfo((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbCreateEdit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbCreateInfoBtn((FSBAP_Info_Edit)this);
	}

	/**
	 * [Search]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSearch(FSBAP_Info_Edit p) {
		p.Search_ext_PPanel = mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.create(p.getSearchR().ext());
		p.Search_ext_PPanel.setName("Search.ext");
		p.Search_co_cd = p.Search_ext_PPanel.Ext_co_cd;
		p.Search_co_cd.addAliasName("Search.co_cd", p);
		p.Search_attr1 = p.Search_ext_PPanel.Ext_attr1;
		p.Search_attr1.addAliasName("Search.attr1", p);
		p.Search_attr2 = p.Search_ext_PPanel.Ext_attr2;
		p.Search_attr2.addAliasName("Search.attr2", p);
		p.Search_attr3 = p.Search_ext_PPanel.Ext_attr3;
		p.Search_attr3.addAliasName("Search.attr3", p);
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP_Info_Edit p) {
		p.Info_extL_PPanel = mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.create(mcframe.clientFSBA.FSBAP0250.InfoR.$extL);
		p.Info_extL_PPanel.setName("Info.extL");
		p.columnInfo_co_cd = p.Info_extL_PPanel.columnExtL_co_cd;
		p.columnInfo_co_cd.addAliasName("Info.co_cd", p);
		p.columnInfo_co_nm = p.Info_extL_PPanel.columnExtL_co_nm;
		p.columnInfo_co_nm.addAliasName("Info.co_nm", p);
		p.columnInfo_attr1 = p.Info_extL_PPanel.columnExtL_attr1;
		p.columnInfo_attr1.addAliasName("Info.attr1", p);
		p.columnInfo_attr2 = p.Info_extL_PPanel.columnExtL_attr2;
		p.columnInfo_attr2.addAliasName("Info.attr2", p);
		p.columnInfo_attr3 = p.Info_extL_PPanel.columnExtL_attr3;
		p.columnInfo_attr3.addAliasName("Info.attr3", p);
	}

	/**
	 * [Edit]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateEdit(FSBAP_Info_Edit p) {
		p.Edit_ext_PPanel = mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.create(p.getEditR().ext());
		p.Edit_ext_PPanel.setName("Edit.ext");
		p.Edit_co_cd = p.Edit_ext_PPanel.Ext_co_cd;
		p.Edit_co_cd.addAliasName("Edit.co_cd", p);
		p.Edit_co_nm = p.Edit_ext_PPanel.Ext_co_nm;
		p.Edit_co_nm.addAliasName("Edit.co_nm", p);
		p.Edit_attr1 = p.Edit_ext_PPanel.Ext_attr1;
		p.Edit_attr1.addAliasName("Edit.attr1", p);
		p.Edit_attr2 = p.Edit_ext_PPanel.Ext_attr2;
		p.Edit_attr2.addAliasName("Edit.attr2", p);
		p.Edit_attr3 = p.Edit_ext_PPanel.Ext_attr3;
		p.Edit_attr3.addAliasName("Edit.attr3", p);
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP_Info_Edit p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Edit_locale_cd_ListPutter]の定義 */
	private MCListPutter Edit_locale_cd_p = null;

	/**
	 * [Edit_locale_cd_ListPutter]の取得
	 */
	protected MCListPutter getEdit_locale_cd_ListPutter() {
		if (Edit_locale_cd_p == null) {
			Edit_locale_cd_p = createEdit_locale_cd_ListPutter(Edit_locale_cd, "locale_cd", "Locale");

		}
		return Edit_locale_cd_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_Info_Edit create(){
		FSBAP_Info_Edit p = new FSBAP_Info_Edit();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_Info_Edit create(String name){
		FSBAP_Info_Edit p = new FSBAP_Info_Edit(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_Info_Edit_FW.jbfInitSearch((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbfInitInfo((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbfInitEdit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbfInitInfoBtn((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbInitSearch((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbInitInfo((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbInitEdit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.jbInitInfoBtn((FSBAP_Info_Edit)this);
	}

	/**
	 * [Search]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSearch(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.SearchPanel = p.beansFactory.createPanel("Search");
		p.SearchTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Search_dtm_fm_Label = p.beansFactory.createLabel("Search.dtm_fm_Label");
		p.Search_dtm_fm = p.beansFactory.createDateField("Search.dtm_fm");
		p.Search_dtm_fm.setLabel(p.Search_dtm_fm_Label);
		p.Search_dtm_to_Label = p.beansFactory.createLabel("Search.dtm_to_Label");
		p.Search_dtm_to = p.beansFactory.createDateField("Search.dtm_to");
		p.Search_dtm_to.setLabel(p.Search_dtm_to_Label);
		p.Search_search = p.beansFactory.createButton("Search.search", "srch");
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.InfoPanel = p.beansFactory.createPanel("Info");
		p.InfoScrollPane = p.beansFactory.createScrollPane("Info.scroll");
		p.createInfoTable();
		// ブロックの項目の初期化
		p.columnInfo_start_dt = p.beansFactory.createTableColumn("Info.start_dt", MCColumnType.DATE);
		p.columnInfo_end_dt = p.beansFactory.createTableColumn("Info.end_dt", MCColumnType.DATE);
		p.columnInfo_locale_cd = p.beansFactory.createTableColumn("Info.locale_cd", MCColumnType.TEXT);
		p.columnInfo_Locale = p.beansFactory.createTableColumn("Info.Locale", MCColumnType.TEXT);
		p.columnInfo_notice_title = p.beansFactory.createTableColumn("Info.notice_title", MCColumnType.TEXT);
		p.columnInfo_text_line = p.beansFactory.createTableColumn("Info.text_line", MCColumnType.TEXT);
	}

	/**
	 * [Edit]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitEdit(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.EditPanel = p.beansFactory.createPanel("Edit");
		// ブロックの項目の初期化
		p.Edit_start_dt_Label = p.beansFactory.createLabel("Edit.start_dt_Label");
		p.Edit_start_dt = p.beansFactory.createDateField("Edit.start_dt");
		p.Edit_start_dt.setLabel(p.Edit_start_dt_Label);
		p.Edit_end_dt_Label = p.beansFactory.createLabel("Edit.end_dt_Label");
		p.Edit_end_dt = p.beansFactory.createDateField("Edit.end_dt");
		p.Edit_end_dt.setLabel(p.Edit_end_dt_Label);
		p.Edit_locale_cd_Label = p.beansFactory.createLabel("Edit.locale_cd_Label");
		p.Edit_locale_cd = p.beansFactory.createTextComboBox("Edit.locale_cd");
		p.Edit_locale_cd.setLabel(p.Edit_locale_cd_Label);
		p.Edit_Locale = p.beansFactory.createTextField("Edit.Locale");
		p.Edit_notice_title_Label = p.beansFactory.createLabel("Edit.notice_title_Label");
		p.Edit_notice_title = p.beansFactory.createTextField("Edit.notice_title");
		p.Edit_notice_title.setLabel(p.Edit_notice_title_Label);
		p.Edit_text_line_Label = p.beansFactory.createLabel("Edit.text_line_Label");
		p.Edit_text_lineScrollPane = p.beansFactory.createScrollPane("Edit.text_linescroll");
		p.Edit_text_line = p.beansFactory.createTextArea("Edit.text_line");
		p.Edit_text_line.setLabel(p.Edit_text_line_Label);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_add = p.beansFactory.createButton("InfoBtn.add", "no_border");
		p.InfoBtn_del = p.beansFactory.createButton("InfoBtn.del", "no_border");
		p.InfoBtn_copy = p.beansFactory.createButton("InfoBtn.copy", "no_border");
		p.InfoBtn_upd = p.beansFactory.createButton("InfoBtn.upd", "upd");
	}

	/**
	 * [Search]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSearch(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.SearchPanel.setBorder(p.SearchTitledBorder);
		p.add(p.SearchPanel);
		p.setLastBeans(p.SearchPanel);
		p.SearchPanel.setNextBeans(p.InfoPanel);
		p.SearchPanel.setValueCheck(false);
		p.SearchPanel.setExtValue(MCPanel.SRCH_CND_SETTING_PANEL, true);
		p.SearchPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.SearchPanel.add(p.Search_dtm_fm_Label);
		p.SearchPanel.add(p.Search_dtm_fm);
		p.SearchPanel.setLastBeans(p.Search_dtm_fm);
		p.Search_dtm_fm.setNextBeans(p.Search_dtm_to);
		p.Search_dtm_fm.setRow(p.getSearchR(), mcframe.clientFSBA.FSBAP0250.SearchR.dtm_fm_META);
		p.Search_dtm_fm.setFormatID("YMD");
		p.SearchPanel.add(p.Search_dtm_to_Label);
		p.SearchPanel.add(p.Search_dtm_to);
		p.Search_dtm_to.setNextBeans(p.Search_ext_PPanel);
		p.Search_dtm_to.setRow(p.getSearchR(), mcframe.clientFSBA.FSBAP0250.SearchR.dtm_to_META);
		p.Search_dtm_to.setFormatID("YMD");
		p.SearchPanel.add(p.Search_ext_PPanel);
		p.Search_ext_PPanel.setNextBeans(p.Search_search);
		p.Search_search.setIcon("SEARCH");
		p.Search_search.setFunctionKey(MCFunctionKey.F1);
		p.SearchPanel.add(p.Search_search);
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.add(p.InfoPanel);
		p.InfoPanel.setNextBeans(p.EditPanel);
		p.InfoPanel.add(p.InfoScrollPane);
		p.InfoPanel.setLastBeans(p.InfoTable);
		p.InfoScrollPane.setViewportView(p.InfoTable);
		p.InfoTable.setList(p.getInfoL());
		p.InfoPanel.setLayoutPosition("CLC");
		// ブロックの項目の初期化
	}

	/**
	 * [Edit]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitEdit(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.add(p.EditPanel);
		p.EditPanel.setNextBeans(p.InfoBtnPanel);
		p.EditPanel.setLayoutPosition("CRC");
		// ブロックの項目の初期化
		p.EditPanel.add(p.Edit_start_dt_Label);
		p.EditPanel.add(p.Edit_start_dt);
		p.EditPanel.setLastBeans(p.Edit_start_dt);
		p.Edit_start_dt.setNextBeans(p.Edit_end_dt);
		p.Edit_start_dt.setRow(p.getEditR(), mcframe.clientFSBA.FSBAP0250.EditR.start_dt_META);
		p.Edit_start_dt.setFormatID("YMD");
		p.EditPanel.add(p.Edit_end_dt_Label);
		p.EditPanel.add(p.Edit_end_dt);
		p.Edit_end_dt.setNextBeans(p.Edit_locale_cd);
		p.Edit_end_dt.setRow(p.getEditR(), mcframe.clientFSBA.FSBAP0250.EditR.end_dt_META);
		p.Edit_end_dt.setFormatID("YMD");
		p.Edit_locale_cd.setListType(MCListType.STRICT);
		p.Edit_locale_cd.setLinkBeans(p.Edit_Locale);
		p.EditPanel.add(p.Edit_locale_cd_Label);
		p.EditPanel.add(p.Edit_locale_cd);
		p.Edit_locale_cd.setNextBeans(p.Edit_Locale);
		p.Edit_locale_cd.setRow(p.getEditR(), mcframe.clientFSBA.FSBAP0250.EditR.locale_cd_META);
		p.EditPanel.add(p.Edit_Locale);
		p.Edit_Locale.setNextBeans(p.Edit_ext_PPanel);
		p.Edit_Locale.setRow(p.getEditR(), mcframe.clientFSBA.FSBAP0250.EditR.Locale_META);
		p.EditPanel.add(p.Edit_ext_PPanel);
		p.Edit_ext_PPanel.setNextBeans(p.Edit_notice_title);
		p.EditPanel.add(p.Edit_notice_title_Label);
		p.EditPanel.add(p.Edit_notice_title);
		p.Edit_notice_title.setNextBeans(p.Edit_text_line);
		p.Edit_notice_title.setRow(p.getEditR(), mcframe.clientFSBA.FSBAP0250.EditR.notice_title_META);
		p.EditPanel.add(p.Edit_text_line_Label);
		p.Edit_text_lineScrollPane.getViewport().add(p.Edit_text_line);
		p.EditPanel.add(p.Edit_text_lineScrollPane);
		p.Edit_text_line.setRow(p.getEditR(), mcframe.clientFSBA.FSBAP0250.EditR.text_line_META);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP_Info_Edit p) {
		// ブロック関連の初期化
		p.add(p.InfoBtnPanel);
		p.InfoBtnPanel.setValueCheck(false);
		p.InfoBtnPanel.setLayoutPosition("CRS");
		// ブロックの項目の初期化
		p.InfoBtn_add.setIcon("INSERT_RECORD");
		p.InfoBtn_add.setFunctionKey(MCFunctionKey.F5);
		p.InfoBtnPanel.add(p.InfoBtn_add);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_add);
		p.InfoBtn_add.setNextBeans(p.InfoBtn_del);
		p.InfoBtn_del.setIcon("DELETE_RECORD");
		p.InfoBtn_del.setFunctionKey(MCFunctionKey.F6);
		p.InfoBtnPanel.add(p.InfoBtn_del);
		p.InfoBtn_del.setNextBeans(p.InfoBtn_copy);
		p.InfoBtn_copy.setIcon("COPY_RECORD");
		p.InfoBtn_copy.setFunctionKey(MCFunctionKey.F17);
		p.InfoBtnPanel.add(p.InfoBtn_copy);
		p.InfoBtn_copy.setNextBeans(p.InfoBtn_upd);
		p.InfoBtn_upd.setIcon("REGISTER");
		p.InfoBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_Info_Edit_FW.mcInitSearch((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.mcInitInfo((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.mcInitEdit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.mcInitInfoBtn((FSBAP_Info_Edit)this);

		// [INIT]ステータスのモードの設定
		FSBAP_Info_Edit_FW.statusInitINIT_Search((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitINIT_Info((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitINIT_Edit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitINIT_InfoBtn((FSBAP_Info_Edit)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_Info_Edit_FW.statusInitEDIT_Search((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitEDIT_Info((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitEDIT_Edit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitEDIT_InfoBtn((FSBAP_Info_Edit)this);

		// [EDIT_DEL]ステータスのモードの設定
		FSBAP_Info_Edit_FW.statusInitEDIT__DEL_Search((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitEDIT__DEL_Info((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitEDIT__DEL_Edit((FSBAP_Info_Edit)this);
		FSBAP_Info_Edit_FW.statusInitEDIT__DEL_InfoBtn((FSBAP_Info_Edit)this);

	}

	/**
	 *  [Search]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSearch(FSBAP_Info_Edit p) {
		p.Search_dtm_fm.setListListener(p);
		p.Search_dtm_fm.addAllListener(p);
		p.Search_dtm_to.setListListener(p);
		p.Search_dtm_to.addAllListener(p);
		p.Search_search.addAllListener(p);
		p.Search_search.setAPMethodName("doSearch_search");
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP_Info_Edit p) {
		p.InfoTable.addAllListener(p);
		p.columnInfo_start_dt.addAllListener(p);
		p.columnInfo_start_dt.setListListener(p);
		p.columnInfo_end_dt.addAllListener(p);
		p.columnInfo_end_dt.setListListener(p);
		p.columnInfo_locale_cd.addAllListener(p);
		p.columnInfo_locale_cd.setListListener(p);
		p.columnInfo_Locale.addAllListener(p);
		p.columnInfo_Locale.setListListener(p);
		p.columnInfo_notice_title.addAllListener(p);
		p.columnInfo_notice_title.setListListener(p);
		p.columnInfo_text_line.addAllListener(p);
		p.columnInfo_text_line.setListListener(p);
	}

	/**
	 *  [Edit]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitEdit(FSBAP_Info_Edit p) {
		p.Edit_start_dt.setListListener(p);
		p.Edit_start_dt.addAllListener(p);
		p.Edit_end_dt.setListListener(p);
		p.Edit_end_dt.addAllListener(p);
		p.Edit_locale_cd.setListListener(p);
		p.Edit_locale_cd.addAllListener(p);
		p.Edit_Locale.setListListener(p);
		p.Edit_Locale.addAllListener(p);
		p.Edit_notice_title.setListListener(p);
		p.Edit_notice_title.addAllListener(p);
		p.Edit_text_line.addAllListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP_Info_Edit p) {
		p.InfoBtn_add.addAllListener(p);
		p.InfoBtn_add.setAPMethodName("doInfoBtn_add");
		p.InfoBtn_del.addAllListener(p);
		p.InfoBtn_del.setAPMethodName("doInfoBtn_del");
		p.InfoBtn_copy.addAllListener(p);
		p.InfoBtn_copy.setAPMethodName("doInfoBtn_copy");
		p.InfoBtn_upd.addAllListener(p);
		p.InfoBtn_upd.setAPMethodName("doInfoBtn_upd");
	}

	/**
	 * [INIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Search(FSBAP_Info_Edit p){
		p.Search_dtm_to.putMode(p, INIT, MCMode.ENABLE);
		p.Search_ext_PPanel.putStatus(INIT, mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.EDT);
		p.Search_search.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP_Info_Edit p){
		p.columnInfo_start_dt.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfo_end_dt.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfo_locale_cd.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfo_Locale.putMode(p, INIT, MCMode.READ_ONLY);
		p.Info_extL_PPanel.putStatus(INIT, mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.REF);
		p.columnInfo_notice_title.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfo_text_line.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Edit]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Edit(FSBAP_Info_Edit p){
		p.Edit_start_dt.putMode(p, INIT, MCMode.READ_ONLY);
		p.Edit_end_dt.putMode(p, INIT, MCMode.READ_ONLY);
		p.Edit_locale_cd.putMode(p, INIT, MCMode.READ_ONLY);
		p.Edit_Locale.putMode(p, INIT, MCMode.READ_ONLY);
		p.Edit_ext_PPanel.putStatus(INIT, mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.REF);
		p.Edit_notice_title.putMode(p, INIT, MCMode.READ_ONLY);
		p.Edit_text_line.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP_Info_Edit p){
		p.InfoBtn_add.putMode(p, INIT, MCMode.ENABLE);
		p.InfoBtn_del.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoBtn_copy.putMode(p, INIT, MCMode.ENABLE);
		p.InfoBtn_upd.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Search(FSBAP_Info_Edit p){
		p.Search_dtm_to.putMode(p, EDIT, MCMode.ENABLE);
		p.Search_ext_PPanel.putStatus(EDIT, mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.EDT);
		p.Search_search.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Info(FSBAP_Info_Edit p){
		p.columnInfo_start_dt.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfo_end_dt.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfo_locale_cd.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfo_Locale.putMode(p, EDIT, MCMode.READ_ONLY);
		p.Info_extL_PPanel.putStatus(EDIT, mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.REF);
		p.columnInfo_notice_title.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfo_text_line.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[Edit]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Edit(FSBAP_Info_Edit p){
		p.Edit_start_dt.putMode(p, EDIT, MCMode.REQUIRED);
		p.Edit_end_dt.putMode(p, EDIT, MCMode.REQUIRED);
		p.Edit_locale_cd.putMode(p, EDIT, MCMode.ENABLE);
		p.Edit_Locale.putMode(p, EDIT, MCMode.READ_ONLY);
		p.Edit_ext_PPanel.putStatus(EDIT, mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.EDT);
		p.Edit_notice_title.putMode(p, EDIT, MCMode.REQUIRED);
		p.Edit_text_line.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoBtn(FSBAP_Info_Edit p){
		p.InfoBtn_add.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_del.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_copy.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_upd.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT_DEL]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitEDIT__DEL_Search(FSBAP_Info_Edit p){
		p.Search_dtm_to.putMode(p, EDIT_DEL, MCMode.ENABLE);
		p.Search_ext_PPanel.putStatus(EDIT_DEL, mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.EDT);
		p.Search_search.putMode(p, EDIT_DEL, MCMode.ENABLE);

	}

	/**
	 * [EDIT_DEL]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT__DEL_Info(FSBAP_Info_Edit p){
		p.columnInfo_start_dt.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.columnInfo_end_dt.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.columnInfo_locale_cd.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.columnInfo_Locale.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.Info_extL_PPanel.putStatus(EDIT_DEL, mcframe.clientFSBF.FSBFP0130.FSBFP_ExtL.REF);
		p.columnInfo_notice_title.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.columnInfo_text_line.putMode(p, EDIT_DEL, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT_DEL]ステータスの[Edit]ブロックのモードの設定
	 */
	protected static void statusInitEDIT__DEL_Edit(FSBAP_Info_Edit p){
		p.Edit_start_dt.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.Edit_end_dt.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.Edit_locale_cd.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.Edit_Locale.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.Edit_ext_PPanel.putStatus(EDIT_DEL, mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.REF);
		p.Edit_notice_title.putMode(p, EDIT_DEL, MCMode.READ_ONLY);
		p.Edit_text_line.putMode(p, EDIT_DEL, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT_DEL]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT__DEL_InfoBtn(FSBAP_Info_Edit p){
		p.InfoBtn_add.putMode(p, EDIT_DEL, MCMode.ENABLE);
		p.InfoBtn_del.putMode(p, EDIT_DEL, MCMode.ENABLE);
		p.InfoBtn_copy.putMode(p, EDIT_DEL, MCMode.ENABLE);
		p.InfoBtn_upd.putMode(p, EDIT_DEL, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_Info_Edit_FW.setTableConfigInfo((FSBAP_Info_Edit)this);
	}

	/**
	 * [Info]ブロックのTableの設定
	 */
	protected static void setTableConfigInfo(FSBAP_Info_Edit p) {
		p.columnInfo_start_dt.setMeta(mcframe.clientFSBA.FSBAP0250.InfoR.start_dt_META);
		p.columnInfo_start_dt.setFormatID("YMD");
		p.InfoTable.addColumnConfig(p.columnInfo_start_dt);
		p.columnInfo_end_dt.setMeta(mcframe.clientFSBA.FSBAP0250.InfoR.end_dt_META);
		p.columnInfo_end_dt.setFormatID("YMD");
		p.InfoTable.addColumnConfig(p.columnInfo_end_dt);
		p.columnInfo_locale_cd.setMeta(mcframe.clientFSBA.FSBAP0250.InfoR.locale_cd_META);
		p.InfoTable.addColumnConfig(p.columnInfo_locale_cd);
		p.columnInfo_Locale.setMeta(mcframe.clientFSBA.FSBAP0250.InfoR.Locale_META);
		p.InfoTable.addColumnConfig(p.columnInfo_Locale);
		p.InfoTable.addTable(p.Info_extL_PPanel.ExtLTable);
		p.columnInfo_notice_title.setMeta(mcframe.clientFSBA.FSBAP0250.InfoR.notice_title_META);
		p.InfoTable.addColumnConfig(p.columnInfo_notice_title);
		p.columnInfo_text_line.setMeta(mcframe.clientFSBA.FSBAP0250.InfoR.text_line_META);
		p.InfoTable.addColumnConfig(p.columnInfo_text_line);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Edit_locale_cd.setListVisibleColumn(MCListLogic.getViewColumnName());
		Edit_locale_cd.getListConfig().setPutter(getEdit_locale_cd_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT_DEL]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDIT_DELStatus() {
		status = EDIT_DEL;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (EDIT_DEL.equals(status)) {
			setEDIT_DELStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Edit_locale_cd_ListPutter]の作成
	 */
	protected MCListPutter createEdit_locale_cd_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.Locale");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Edit_locale_cd) return getEdit_locale_cd(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Search_search) doSearch_search(info);
		else if (ap == InfoBtn_add) doInfoBtn_add(info);
		else if (ap == InfoBtn_del) doInfoBtn_del(info);
		else if (ap == InfoBtn_copy) doInfoBtn_copy(info);
		else if (ap == InfoBtn_upd) doInfoBtn_upd(info);
	}

	/**
	 * [Search]パネルの[search]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doSearch_search(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_add(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_del(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[copy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_copy(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == InfoTable) return doInfo_VC(info);
		if (vc == Search_dtm_fm) return doSearch_dtm_fm_VC(info);
		if (vc == Search_dtm_to) return doSearch_dtm_to_VC(info);
		if (vc == columnInfo_start_dt) return doInfo_start_dt_VC(info);
		if (vc == columnInfo_end_dt) return doInfo_end_dt_VC(info);
		if (vc == columnInfo_locale_cd) return doInfo_locale_cd_VC(info);
		if (vc == columnInfo_Locale) return doInfo_Locale_VC(info);
		if (vc == columnInfo_notice_title) return doInfo_notice_title_VC(info);
		if (vc == columnInfo_text_line) return doInfo_text_line_VC(info);
		if (vc == Edit_start_dt) return doEdit_start_dt_VC(info);
		if (vc == Edit_end_dt) return doEdit_end_dt_VC(info);
		if (vc == Edit_locale_cd) return doEdit_locale_cd_VC(info);
		if (vc == Edit_Locale) return doEdit_Locale_VC(info);
		if (vc == Edit_notice_title) return doEdit_notice_title_VC(info);
		if (vc == Edit_text_line) return doEdit_text_line_VC(info);
		return true;
	}

	/**
	 * [Info]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Search]パネルの[dtm_fm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doSearch_dtm_fm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Search]パネルの[dtm_to]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doSearch_dtm_to_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[start_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_start_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[end_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_end_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[locale_cd]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_locale_cd_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[Locale]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_Locale_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[notice_title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_notice_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[text_line]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_text_line_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Edit]パネルの[start_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doEdit_start_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Edit]パネルの[end_dt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doEdit_end_dt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Edit]パネルの[locale_cd]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doEdit_locale_cd_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Edit]パネルの[Locale]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doEdit_Locale_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Edit]パネルの[notice_title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doEdit_notice_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Edit]パネルの[text_line]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doEdit_text_line_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == InfoTable) doInfo_NC(info);
		else if (nc == Search_dtm_fm) doSearch_dtm_fm_NC(info);
		else if (nc == Search_dtm_to) doSearch_dtm_to_NC(info);
		else if (nc == columnInfo_start_dt) doInfo_start_dt_NC(info);
		else if (nc == columnInfo_end_dt) doInfo_end_dt_NC(info);
		else if (nc == columnInfo_locale_cd) doInfo_locale_cd_NC(info);
		else if (nc == columnInfo_Locale) doInfo_Locale_NC(info);
		else if (nc == columnInfo_notice_title) doInfo_notice_title_NC(info);
		else if (nc == columnInfo_text_line) doInfo_text_line_NC(info);
		else if (nc == Edit_start_dt) doEdit_start_dt_NC(info);
		else if (nc == Edit_end_dt) doEdit_end_dt_NC(info);
		else if (nc == Edit_locale_cd) doEdit_locale_cd_NC(info);
		else if (nc == Edit_Locale) doEdit_Locale_NC(info);
		else if (nc == Edit_notice_title) doEdit_notice_title_NC(info);
		else if (nc == Edit_text_line) doEdit_text_line_NC(info);
	}

	/**
	 * [Info]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_NC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_fm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_fm_NC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_to]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_to_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_dt_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[end_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_end_dt_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[locale_cd]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_locale_cd_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[Locale]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_Locale_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[notice_title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_notice_title_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[text_line]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_text_line_NC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[start_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_start_dt_NC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[end_dt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_end_dt_NC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[locale_cd]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_locale_cd_NC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[Locale]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_Locale_NC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[notice_title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_notice_title_NC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[text_line]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_text_line_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == InfoTable) doInfo_NE(info);
		else if (ne == Search_dtm_fm) doSearch_dtm_fm_NE(info);
		else if (ne == Search_dtm_to) doSearch_dtm_to_NE(info);
		else if (ne == columnInfo_start_dt) doInfo_start_dt_NE(info);
		else if (ne == columnInfo_end_dt) doInfo_end_dt_NE(info);
		else if (ne == columnInfo_locale_cd) doInfo_locale_cd_NE(info);
		else if (ne == columnInfo_Locale) doInfo_Locale_NE(info);
		else if (ne == columnInfo_notice_title) doInfo_notice_title_NE(info);
		else if (ne == columnInfo_text_line) doInfo_text_line_NE(info);
		else if (ne == Edit_start_dt) doEdit_start_dt_NE(info);
		else if (ne == Edit_end_dt) doEdit_end_dt_NE(info);
		else if (ne == Edit_locale_cd) doEdit_locale_cd_NE(info);
		else if (ne == Edit_Locale) doEdit_Locale_NE(info);
		else if (ne == Edit_notice_title) doEdit_notice_title_NE(info);
		else if (ne == Edit_text_line) doEdit_text_line_NE(info);
	}

	/**
	 * [Info]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_NE(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_fm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_fm_NE(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_to]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_to_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_dt_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[end_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_end_dt_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[locale_cd]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_locale_cd_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[Locale]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_Locale_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[notice_title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_notice_title_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[text_line]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_text_line_NE(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[start_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_start_dt_NE(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[end_dt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_end_dt_NE(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[locale_cd]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_locale_cd_NE(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[Locale]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_Locale_NE(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[notice_title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_notice_title_NE(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[text_line]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_text_line_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == InfoTable) doInfo_NX(info);
		else if (nx == Search_dtm_fm) doSearch_dtm_fm_NX(info);
		else if (nx == Search_dtm_to) doSearch_dtm_to_NX(info);
		else if (nx == columnInfo_start_dt) doInfo_start_dt_NX(info);
		else if (nx == columnInfo_end_dt) doInfo_end_dt_NX(info);
		else if (nx == columnInfo_locale_cd) doInfo_locale_cd_NX(info);
		else if (nx == columnInfo_Locale) doInfo_Locale_NX(info);
		else if (nx == columnInfo_notice_title) doInfo_notice_title_NX(info);
		else if (nx == columnInfo_text_line) doInfo_text_line_NX(info);
		else if (nx == Edit_start_dt) doEdit_start_dt_NX(info);
		else if (nx == Edit_end_dt) doEdit_end_dt_NX(info);
		else if (nx == Edit_locale_cd) doEdit_locale_cd_NX(info);
		else if (nx == Edit_Locale) doEdit_Locale_NX(info);
		else if (nx == Edit_notice_title) doEdit_notice_title_NX(info);
		else if (nx == Edit_text_line) doEdit_text_line_NX(info);
	}

	/**
	 * [Info]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_NX(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_fm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_fm_NX(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_to]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_to_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_dt_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[end_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_end_dt_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[locale_cd]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_locale_cd_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[Locale]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_Locale_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[notice_title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_notice_title_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[text_line]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_text_line_NX(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[start_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_start_dt_NX(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[end_dt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_end_dt_NX(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[locale_cd]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_locale_cd_NX(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[Locale]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_Locale_NX(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[notice_title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_notice_title_NX(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[text_line]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_text_line_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Search_dtm_fm) doSearch_dtm_fm_LC(info);
		else if (lc == Search_dtm_to) doSearch_dtm_to_LC(info);
		else if (lc == columnInfo_start_dt) doInfo_start_dt_LC(info);
		else if (lc == columnInfo_end_dt) doInfo_end_dt_LC(info);
		else if (lc == columnInfo_locale_cd) doInfo_locale_cd_LC(info);
		else if (lc == columnInfo_Locale) doInfo_Locale_LC(info);
		else if (lc == columnInfo_notice_title) doInfo_notice_title_LC(info);
		else if (lc == columnInfo_text_line) doInfo_text_line_LC(info);
		else if (lc == Edit_start_dt) doEdit_start_dt_LC(info);
		else if (lc == Edit_end_dt) doEdit_end_dt_LC(info);
		else if (lc == Edit_locale_cd) doEdit_locale_cd_LC(info);
		else if (lc == Edit_Locale) doEdit_Locale_LC(info);
		else if (lc == Edit_notice_title) doEdit_notice_title_LC(info);
	}

	/**
	 * [Search]パネルの[dtm_fm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_fm_LC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[dtm_to]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_dtm_to_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_dt_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[end_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_end_dt_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[locale_cd]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_locale_cd_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[Locale]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_Locale_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[notice_title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_notice_title_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[text_line]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_text_line_LC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[start_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_start_dt_LC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[end_dt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_end_dt_LC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[locale_cd]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_locale_cd_LC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[Locale]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_Locale_LC(MCEventInfo info){
	}

	/**
	 * [Edit]パネルの[notice_title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doEdit_notice_title_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Edit_locale_cd]の作成メソッド
	 */
	public MCList getEdit_locale_cd(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getLocale(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0250.Srch01")) {
			return new FS_FSBAL0250_Srch01Bridge();
		}
		if (id.equals("FS.FSBAL0250.Upd01")) {
			return new FS_FSBAL0250_Upd01Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0250_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0250_Srch01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0250_Srch01;

		/** コンストラクタ */
		protected FS_FSBAL0250_Srch01Bridge() {
			p_FS_FSBAL0250_Srch01 = new MCParam(PDef.FS_FSBAL0250_Srch01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0250_Srch01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0250.SearchR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0250.InfoR.class));

			p_FS_FSBAL0250_Srch01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0250_Srch01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0250_Srch01.addUpBlock(getSearchR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0250_Srch01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0250_Srch01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0250.SearchR up0() {
			return (mcframe.clientFSBA.FSBAP0250.SearchR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0250.InfoR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0250.InfoR>)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0250_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0250.InfoR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0250_Srch01;
		}

		protected void show() {
			setInfoL((MCList<mcframe.clientFSBA.FSBAP0250.InfoR>)p_FS_FSBAL0250_Srch01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getInfoL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getSearchR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0250_Upd01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0250_Upd01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0250_Upd01;

		/** コンストラクタ */
		protected FS_FSBAL0250_Upd01Bridge() {
			p_FS_FSBAL0250_Upd01 = new MCParam(PDef.FS_FSBAL0250_Upd01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0250_Upd01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0250.InfoR.class));
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0250.InfoR.class));

			p_FS_FSBAL0250_Upd01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0250_Upd01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0250_Upd01.addUpBlock(getInfoL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0250_Upd01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0250_Upd01.getContainerParam().getDownBlock(i);
		}
		
		protected MCList<mcframe.clientFSBA.FSBAP0250.InfoR> up0() {
			return (MCList<mcframe.clientFSBA.FSBAP0250.InfoR>)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0250.InfoR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0250.InfoR>)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0250_Upd01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0250.InfoR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0250_Upd01;
		}

		protected void show() {
			setInfoL((MCList<mcframe.clientFSBA.FSBAP0250.InfoR>)p_FS_FSBAL0250_Upd01.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getInfoL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoL());
			return result;
		}
	}
}