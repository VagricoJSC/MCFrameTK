package mcframe.clientFSBA.FSBAP0250;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Search"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class SearchR_FW_A extends MCConstRow {

	/**
	 *  通知開始日.<p>
	 *
	 */
	public static final String $dtm_fm = "dtm_fm";
	/**
	 *  通知終了日.<p>
	 *
	 */
	public static final String $dtm_to = "dtm_to";
	public static final String $ext = "ext";
	public static final String $ext_flg = "ext_flg";

	public static final String $co_cd = $ext + ".co_cd";
	public static final String $attr1 = $ext + ".attr1";
	public static final String $attr2 = $ext + ".attr2";
	public static final String $attr3 = $ext + ".attr3";

	public static final MCMeta dtm_fm_META = createCommonMeta($dtm_fm, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta dtm_to_META = createCommonMeta($dtm_to, mcframe.commonCore.meta.M_META.DT);
	public static final MCMeta ext_META = createInnerRowMeta($ext, mcframe.clientFSBF.FSBFP0120.ExtR.class);
	public static final MCMeta ext_flg_META = createCommonMeta($ext_flg, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<SearchR> constMetas = new ConstMetaList<SearchR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			dtm_fm_META,
			dtm_to_META,
			ext_META,
			ext_flg_META
		},
		new String[][]{
			{
				"co_cd",
				"attr1",
				"attr2",
				"attr3"
			},
			{
				$co_cd,
				$attr1,
				$attr2,
				$attr3
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected SearchR_FW_A(ConstMetaList<? extends SearchR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR clone() {
		return (SearchR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR createInstance() {
		return (SearchR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR getValues(String... names) {
		return (SearchR) super.getValues(names);
	}



	/**
	 *  通知開始日.<p>
	 *
	 */
	public MCDate dtm_fm() {
		return getConstDate(offset + 0, $dtm_fm);
	}

	/**
	 *  通知開始日.<p>
	 *
	 */
	public void dtm_fm(MCDate value) {
		setConstDate(offset + 0, $dtm_fm, value);
	}


	/**
	 *  通知終了日.<p>
	 *
	 */
	public MCDate dtm_to() {
		return getConstDate(offset + 1, $dtm_to);
	}

	/**
	 *  通知終了日.<p>
	 *
	 */
	public void dtm_to(MCDate value) {
		setConstDate(offset + 1, $dtm_to, value);
	}


	public mcframe.clientFSBF.FSBFP0120.ExtR ext(){
		return (mcframe.clientFSBF.FSBFP0120.ExtR) getConstInnerRow(offset + 2, $ext);
	}
	
	public void ext(mcframe.clientFSBF.FSBFP0120.ExtR row){
		setConstInnerRow(offset + 2, $ext, row);
	}


	public boolean ext_flg() {
		return getConstBoolean(offset + 3, $ext_flg);
	}

	public void ext_flg(boolean value) {
		setConstBoolean(offset + 3, $ext_flg, value);
	}


	public MCDate getDate(String name) {
		if ($dtm_fm.equalsIgnoreCase(name)) {
			return dtm_fm();
		}
		if ($dtm_to.equalsIgnoreCase(name)) {
			return dtm_to();
		}
		return super.getDate(name);
	}
	public boolean getBoolean(String name) {
		if ($ext_flg.equalsIgnoreCase(name)) {
			return ext_flg();
		}
		return super.getBoolean(name);
	}

	public MCDate getDateNE(String name) {
		if ($dtm_fm.equalsIgnoreCase(name)) {
			return dtm_fm();
		}
		if ($dtm_to.equalsIgnoreCase(name)) {
			return dtm_to();
		}
		return super.getDateNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($ext_flg.equalsIgnoreCase(name)) {
			return ext_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setDate(String name, MCDate value) {
		if ($dtm_fm.equalsIgnoreCase(name)) {
			dtm_fm(value);
			return;
		}
		if ($dtm_to.equalsIgnoreCase(name)) {
			dtm_to(value);
			return;
		}
		super.setDate(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($ext_flg.equalsIgnoreCase(name)) {
			ext_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setDateNE(String name, MCDate value) {
		if ($dtm_fm.equalsIgnoreCase(name)) {
			dtm_fm(value);
			return;
		}
		if ($dtm_to.equalsIgnoreCase(name)) {
			dtm_to(value);
			return;
		}
		super.setDateNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($ext_flg.equalsIgnoreCase(name)) {
			ext_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}

	public MCRow getInnerRow(String name) {
		if ($ext.equalsIgnoreCase(name)) {
			return ext();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($ext.equalsIgnoreCase(name)) {
			ext(
				((MCContainerMeta) ext_META).castInnerRow(mcframe.clientFSBF.FSBFP0120.ExtR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public String co_cd() {
		return ext().co_cd();
	}

	public void co_cd(String value) {
		ext().co_cd(value);
	}

	public String attr1() {
		return ext().attr1();
	}

	public void attr1(String value) {
		ext().attr1(value);
	}

	public String attr2() {
		return ext().attr2();
	}

	public void attr2(String value) {
		ext().attr2(value);
	}

	public String attr3() {
		return ext().attr3();
	}

	public void attr3(String value) {
		ext().attr3(value);
	}

}

