package mcframe.commonFXBA.FXBAC0020;

import java.util.Map;
import java.util.SortedMap;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;

public class FXBAC_ListLogicBase_FW {
	
	//初期表示フラグ格納カラム名
	public static final String $DEF_FLG = "__ _def_flg_ __";
	//手入力データ格納カラム名
	public static final String $INPUT_VAL = "__ _input_ __";
	//toArrayの引数用
	public static final String[]  $DUMMY_ARRAY = new String[0];
	
	
	//表示用カラムメソッド----------------------------------------
	public static void addDefFlgColumn(MCList l) {
		l.addBooleanColumn($DEF_FLG);
	}
	public static void setDefFlgNE(MCRow r, boolean c) {
		r.setBooleanNE($DEF_FLG, c);
	}

}