package mcframe.commonFXBA.FXBAC0020;

public class FXBAC_ListSortInfo extends FXBAC_ListSortInfo_FW {

}
