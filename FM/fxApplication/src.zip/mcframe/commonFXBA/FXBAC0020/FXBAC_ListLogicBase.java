package mcframe.commonFXBA.FXBAC0020;

import mcframe.commonCore.annotation.EI;

@EI
public class FXBAC_ListLogicBase extends FXBAC_ListLogicBase_FW{
}