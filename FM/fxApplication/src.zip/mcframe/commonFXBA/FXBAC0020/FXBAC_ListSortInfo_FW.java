package mcframe.commonFXBA.FXBAC0020;

import java.util.Map;
import java.util.TreeMap;

import mcframe.commonCore.container.MCSortPolicy;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.lang.MCNumber;

/**
 * リストロジック用のソート情報クラスです。
 *
 */
class FXBAC_ListSortInfo_FW {

	TreeMap<MCNumber, Object[]> map;
	public FXBAC_ListSortInfo_FW(){
		super();
		map = new TreeMap<MCNumber, Object[]>();
	}
	
	/**
	 * 指定した優先順位のソート方法を設定します。<p>
	 * @param priorityOrder 優先順位
	 * @param itemName
	 * @param type
	 */
	public void put(MCNumber priorityOrder, String itemName, SortType type){
		map.put(priorityOrder, new Object[]{itemName, type});
	}

	/**
	 * 指定した優先順位のソート方法を設定します。<p>
	 * @param info ソート情報
	 */
	public void putAll(FXBAC_ListSortInfo info){
		for(Map.Entry<MCNumber, Object[]> e: info.map.entrySet()){
			map.put(e.getKey(), e.getValue());
		}
	}
	/**
	 * 指定した優先順位のソート方法を削除します。<p>
	 * @param priorityOrder 優先順位
	 */
	public void remove(MCNumber priorityOrder, String itemName, SortType type){
		map.remove(priorityOrder);
	}
	
	/**
	 * ソート情報をもとに、MCSortPolicyを返します。<p>
	 * @return MCSortPolicy
	 */
	public MCSortPolicy createSortPolicy(){
		MCSortPolicy p = new MCSortPolicy();
		for(Object[] o : map.values()){
			p.add((SortType)o[1], (String)o[0]);
		}
		return p;
	}
		
}
