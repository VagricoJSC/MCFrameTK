package mcframe.commonFXBA.FXBAC0140;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.io.DefaultContainerColumnMapper;
import mcframe.commonCore.container.io.MCContainerColumnInfo;
import mcframe.commonCore.container.io.MCContainerIOConfig;
import mcframe.commonCore.lang.MCBinary;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.meta.MCMeta;


/**
 * カラム名とコンテナに対する操作を結びつけるマッピング情報です。
 * 
 * <p>
 * 汎用テーブル編集用にバイナリに対応しています。
 * 
 */
public class FXBAC_ContainerColumnMapper<R extends MCRow>
											extends DefaultContainerColumnMapper<R> {

	@Override
	protected MCContainerColumnInfo makeConstColumnInfo(String column, MCMeta meta,
			MCContainerIOConfig config) {
		// バイナリ用のカラム情報をカスタマイズ
		if (meta.type() == MCDataType.BINARY) {
			return new MCContainerColumnInfo(column, meta.type(), "", config) {
				/**
				 * カラム名
				 */
				private final String _col = column;

				@Override
				public String get(MCRow row) {
					if (getType() == MCDataType.BINARY && row != null) {
						MCBinary bin = (MCBinary) MCDataType.BINARY.getValueNE(row, _col);
						if (bin != null) {
							// DBのデータなので、必ずDBポインタ
							return bin.toString();
						}
					}
					return super.get(row);
				}

				@Override
				public void map(MCRow row, String value) {
					if (value != null && row != null) {
						// DBのデータなので、必ずDBポインタ
						long val = Long.parseLong(value);
						MCBinary bin = (value.equals("")) ? null : MCBinary.valueOf(val);
						MCDataType.BINARY.setValueNE(row, _col, bin);
					}
					else {
						super.map(row, value);

					}
				}
			};
		}
		return super.makeConstColumnInfo(column, meta, config);
	}

}