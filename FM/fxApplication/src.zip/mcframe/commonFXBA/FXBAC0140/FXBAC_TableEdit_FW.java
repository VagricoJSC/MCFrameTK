package mcframe.commonFXBA.FXBAC0140;


/**
 * 汎用テーブル編集の共通機能です。
 * 
 */
public class FXBAC_TableEdit_FW {

	/**
	 * 定義情報：オプション：区切り文字
	 */
	public static final String DEFOPT_SEP = "^";

	/**
	 * 定義情報：オプション：コンボボックス
	 */
	public static final String DEFOPT_COMBO = "COMBO";
	/**
	 * 定義情報：オプション：コンボボックス適用箇所：検索枠
	 */
	public static final String DEFOPT_COMBO_USE_COND = "cond";
	/**
	 * 定義情報：オプション：コンボボックス適用箇所：一覧枠
	 */
	public static final String DEFOPT_COMBO_USE_DTL = "dtl";
	/**
	 * 定義情報：オプション：コンボボックス適用箇所：両方
	 */
	public static final String DEFOPT_COMBO_USE_BOTH = "both";
	/**
	 * 定義情報：オプション：コンボボックス リストロジック抽出条件 区切り文字
	 */
	public static final String DEFOPT_COMBO_CONDS_SEP = ",";
	/**
	 * 定義情報：オプション：コンボボックス リストロジック抽出条件 項目区切り文字
	 */
	public static final String DEFOPT_COMBO_CONDS_ITEMSEP = "@";

	/**
	 * 定義情報：オプション：日時検索条件：開始日
	 */
	public static final String DEFOPT_DATE_FROM = "FROM";
	/**
	 * 定義情報：オプション：日時検索条件：終了日
	 */
	public static final String DEFOPT_DATE_TO = "TO";

	/**
	 * 定義情報：オプション：選択カラム
	 */
	public static final String DEFOPT_SELECTOR = "DEFOPT_SELECTOR";
	/**
	 * 定義情報：オプション：名称連携用カラム
	 */
	public static final String DEFOPT_LINKNAME = "DEFOPT_LINKNAME";


	/**
	 * 定義情報：オプション：コンボボックス インデックス：適用箇所
	 */
	public static final int DEFOPT_COMBO_USE = 0;
	/**
	 * 定義情報：オプション：コンボボックス インデックス：リストロジック
	 */
	public static final int DEFOPT_COMBO_LOGIC = 1;
	/**
	 * 定義情報：オプション：コンボボックス インデックス：連携項目（画面項目）
	 */
	public static final int DEFOPT_COMBO_LINK = 2;
	/**
	 * 定義情報：オプション：コンボボックス インデックス：連携項目（別名＝リスト項目）
	 */
	public static final int DEFOPT_COMBO_ALIAS = 3;
	/**
	 * 定義情報：オプション：コンボボックス インデックス：リスト絞込み条件
	 */
	public static final int DEFOPT_COMBO_CONDS = 4;

	/**
	 * 定義情報：オプション：コンボボックス 連携項目インデックス：ID
	 */
	public static final int DEFOPT_COMBO_COL_ID = 0;
	/**
	 * 定義情報：オプション：コンボボックス 連携項目インデックス：名称
	 */
	public static final int DEFOPT_COMBO_COL_NAME = 1;


	/**
	 * 検索条件：日時検索条件 終了日項目接尾辞
	 */
	public static  final String COND_DATE_TO = "@to";
}
