package mcframe.commonFXBA.FXBAC0140;

import mcframe.commonCore.annotation.EI;


@EI
public class FXBAC_TableEdit extends FXBAC_TableEdit_FW {
	
}