package mcframe.commonFXBA.FXBAC0050;
public class FXBAC_RLBase extends FXBAC_RLBase_FW{
}