package mcframe.commonFXBA.FXBAC0050;

public class FXBAC_RLBase_FW {

	protected static FXBAC_RLBase me() {
		return new FXBAC_RLBase();
	}

	/**画面、ロジック共通のカラムパスのドット*/
	public static final String $PARTS_DOT = ".";

	/**画面、ロジック共通の変更前キーカラム名接尾辞*/
	protected static final String $BK_SUF = "_key";

	/**画面、ロジック共通の更新日時カラム名*/
	protected static final String $UPD_TS = "upd_ts";

	/**画面、ロジック(ＤＢコンテナ含む)共通の登録日時カラム名*/
	protected static final String $INS_TS = "ins_ts";

	/**画面、ロジック(ＤＢコンテナ含む)共通の更新カウンタカラム名*/
	protected static final String $UPD_CNTR = "upd_cntr";

	/**画面、ロジック(ＤＢコンテナ含む)共通の登録担当者ＣＤカラム名*/
	protected static final String $INS_USR_CD = "ins_usr_cd";

	/**画面、ロジック(ＤＢコンテナ含む)共通の更新担当者ＣＤカラム名*/
	protected static final String $UPD_USR_CD = "upd_usr_cd";

	/**画面、ロジック共通の変更前キーカラム名接尾辞を取得します。*/
	public static String getBkSuffix() {
		return me()._getBkSuffix();
	}

	/**画面、ロジック共通の変更前キーカラム名接尾辞を取得します。*/
	protected String _getBkSuffix() {
		return $BK_SUF;
	}

	/**
	 * 画面、ロジック共通の更新日時カラム名を取得します。<p>
	 * 画面、ロジックではそれぞれFXBAP_RLUtil、FXBAL_RLUtilの同名メソッドを使用して下さい。
	 */
	public static String getUpdTsColumn() {
		return me()._getUpdTsColumn();
	}

	/**
	 * 画面、ロジック共通の更新日時カラム名を取得します。<p>
	 */
	protected String _getUpdTsColumn() {
		return $UPD_TS;
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の登録日時カラム名を取得します。<p>
	 * 画面、ロジックではそれぞれFXBAP_RLUtil、FXBAL_RLUtilの同名メソッドを使用して下さい。
	 */
	public static String getInsTsColumn() {
		return me()._getInsTsColumn();
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の登録日時カラム名を取得します。<p>
	 */
	protected String _getInsTsColumn() {
		return $INS_TS;
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の更新カウンタカラム名を取得します。<p>
	 * 画面、ロジックではそれぞれFXBAP_RLUtil、FXBAL_RLUtilの同名メソッドを使用して下さい。
	 */
	public static String getUpdCntrColumn() {
		return me()._getUpdCntrColumn();
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の更新カウンタカラム名を取得します。<p>
	 */
	protected String _getUpdCntrColumn() {
		return $UPD_CNTR;
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の登録担当者ＣＤカラム名を取得します。<p>
	 * 画面、ロジックではそれぞれFXBAP_RLUtil、FXBAL_RLUtilの同名メソッドを使用して下さい。
	 */
	public static String getInsUsrCdColumn() {
		return me()._getInsUsrCdColumn();
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の登録担当者ＣＤカラム名を取得します。<p>
	 */
	protected String _getInsUsrCdColumn() {
		return $INS_USR_CD;
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の更新担当者ＣＤカラム名を取得します。<p>
	 * 画面、ロジックではそれぞれFXBAP_RLUtil、FXBAL_RLUtilの同名メソッドを使用して下さい。
	 */
	public static String getUpdUsrCdColumn() {
		return me()._getUpdUsrCdColumn();
	}

	/**
	 * 画面、ロジック(ＤＢコンテナ含む)共通の更新担当者ＣＤカラム名を取得します。<p>
	 */
	protected String _getUpdUsrCdColumn() {
		return $UPD_USR_CD;
	}

}