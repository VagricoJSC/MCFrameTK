package mcframe.serverFXBA.FXBAL0020;

import mcframe.commonCore.annotation.EI;

@EI
public abstract class FXBAL_MCSimpleSearcher extends FXBAL_MCSimpleSearcher_FW {

}