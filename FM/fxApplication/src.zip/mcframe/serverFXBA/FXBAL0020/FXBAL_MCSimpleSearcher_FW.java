package mcframe.serverFXBA.FXBAL0020;

import static mcframe.serverCore.queryapi.IFMCSQL.*;
import mcframe.commonCore.container.MCRow;
import mcframe.serverCore.logic.MCController;
import mcframe.serverCore.logic.MCDBSubOperation;
import mcframe.serverCore.logic.MCOperation;
import mcframe.serverCore.queryapi.MCDBContainer;

public abstract class FXBAL_MCSimpleSearcher_FW extends MCOperation {
	protected static final String SELECT = "SELECT";

	// 上り項目設定
	protected void up() {
		mapUpContainers(SELECT);
	}

	// 連携ロジック実行
	// MCDBController のジェネリクス
	protected void doIt() {
		for (MCController ctrl : getSubOpes(SELECT)) {
			if (ctrl instanceof MCDBSubOperation) {
				MCRow cond = ((MCDBSubOperation<?>) ctrl).up0;
				MCDBContainer dbc =  ((MCDBSubOperation<?>) ctrl).dbc();
				sql()
					.mainQuery()
					.select(dbc.getBaseColumns$())
					.from(dbc)
					.executeQuery(cond,  ((MCDBSubOperation<?>) ctrl).down0);
			}
			else if (ctrl instanceof MCOperation) {
				((MCOperation) ctrl).exec();
			}
		}
	}

	// 下り項目設定
	protected void down() {
		mapDownContainers(SELECT);
	}

	// 実行I/F
	@Override
	protected void call() {
		up();
		doIt();
		down();
	}

}