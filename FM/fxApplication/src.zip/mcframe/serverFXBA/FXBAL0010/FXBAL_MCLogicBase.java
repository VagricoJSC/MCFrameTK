package mcframe.serverFXBA.FXBAL0010;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;

/**
 * "FXBAL_MCLogicBase"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
abstract public class FXBAL_MCLogicBase extends FXBAL_MCLogicBase_FW {

}