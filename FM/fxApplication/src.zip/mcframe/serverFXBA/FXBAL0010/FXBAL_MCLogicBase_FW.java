package mcframe.serverFXBA.FXBAL0010;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.logic.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

//手修正によるカスタマイズで必要なimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import mcframe.commonCore.meta.MCMeta;
import mcframe.serverCore.requester.MCLogicUtil;
import mcframe.commonCore.report.container.MCReportMeta;
import mcframe.commonCore.report.container.MCReportSet;
import mcframe.commonCore.resource.MCFormatConst;
import mcframe.commonCore.resource.MCFormatConst.MCZeroType;
import mcframe.commonCore.resource.MCLocaleConst;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.serverCore.resource.MCConst;
import mcframe.commonFXUC.FXUCC0020.FXUCC_ResourceUtil;
import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;
import static mcframe.commonFX.notice.FX_Msg.*;
//FMCB CUSTOM_IMPORT END

/**
 * "FXBAL_MCLogicBase"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class FXBAL_MCLogicBase_FW extends FXBAL_MCLogicBase_FW_A{
	//FMCB CUSTOM START
	// 目次
	// ・ユーティリティ
	// ・帳票関連
	// ・ＤＢ関連
	// ・発番
	// ・コンテナコピー
	// ・WT_LOGS
	// ・チェック処理

	// ユーティリティ(START) ====================================

	/**
	 * オペレーションから、そのオペレーションのロジッククラスを取得する
	 * 為に使用することを想定しています。
	 */
	public FXBAL_MCLogicBase getLogic() {
		return (FXBAL_MCLogicBase) this;
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（文字列）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public String getPgmSettingString(FXBAL_MCLogicBase logic, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getString(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（文字列）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param def デフォルト値
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public String getPgmSettingStringNE(FXBAL_MCLogicBase logic, String def,
			String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getString(key);
			}
		}
		return def;
	}

	/**
	 * MCAppConst から設定値（文字列）を取得します。
	 * <br><B>
	 * オペレーションクラスではなく、ロジッククラスを渡してください。
	 * </B>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @deprecated できれば FXBAL_LogicBase が引数の方を使ってください
	 * @return リソース値
	 */
	@Deprecated
	public String getPgmSettingString(Class<? extends Object> clazz, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(clazz);

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getString(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（数値）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public MCNumber getPgmSettingNumber(FXBAL_MCLogicBase logic, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getNumber(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（数値）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * 最上位のモジュールＩＤとロジックＩＤのリソースキーが存在しない場合は、引数のデフォルト値を返します。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param def デフォルト値
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public MCNumber getPgmSettingNumberNE(FXBAL_MCLogicBase logic, MCNumber def,
			String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getNumber(key);
			}
		}
		return def;
	}

	/**
	 * MCAppConst から設定値(数値)を取得します。
	 * <br><B>
	 * オペレーションクラスではなく、ロジッククラスを渡してください。
	 * </B>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @deprecated できれば FXBAL_LogicBase が引数の方を使ってください
	 * @return リソース値
	 */
	@Deprecated
	public MCNumber getPgmSettingNumber(Class<?> clazz, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(clazz);

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getNumber(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（int）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public int getPgmSettingInt(FXBAL_MCLogicBase logic, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				MCNumber ret = MCConst.app.getNumber(key);
				return (ret == null) ? null : ret.intValue();
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（int）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * 最上位のモジュールＩＤとロジックＩＤのリソースキーが存在しない場合は、引数のデフォルト値を返します。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param def デフォルト値
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public int getPgmSettingIntNE(FXBAL_MCLogicBase logic, int def, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				MCNumber ret = MCConst.app.getNumber(key);
				return (ret == null) ? null : ret.intValue();
			}
		}
		return def;
	}

	/**
	 * MCAppConst から設定値(int)を取得します。
	 * <br><B>
	 * オペレーションクラスではなく、ロジッククラスを渡してください。
	 * </B>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @deprecated できれば FXBAL_LogicBase が引数の方を使ってください
	 * @return リソース値
	 */
	@Deprecated
	public int getPgmSettingInt(Class<?> clazz, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(clazz);

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				MCNumber ret = MCConst.app.getNumber(key);
				return (ret == null) ? null : ret.intValue();
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（boolean）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public boolean getPgmSettingBoolean(FXBAL_MCLogicBase logic, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getBoolean(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（boolean）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * 最上位のモジュールＩＤとロジックＩＤのリソースキーが存在しない場合は、引数のデフォルト値を返します。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param def デフォルト値
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public boolean getPgmSettingBooleanNE(FXBAL_MCLogicBase logic, boolean def,
			String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getBoolean(key);
			}
		}
		return def;
	}

	/**
	 * MCAppConst から設定値を取得します。
	 * <br><B>
	 * オペレーションクラスではなく、ロジッククラスを渡してください。
	 * </B>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @deprecated できれば FXBAL_LogicBase が引数の方を使ってください
	 * @return リソース値
	 */
	@Deprecated
	public boolean getPgmSettingBoolean(Class<?> clazz, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(clazz);

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getBoolean(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（char）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public Character getPgmSettingChar(FXBAL_MCLogicBase logic, String... keys) {
		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getCharacter(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * {@link mcframe.serverCore.resource.MCAppConst} から設定値（char）を取得します。
	 * <p>
	 * 取得するリソースキーは[logicのモジュールＩＤ.logicのロジックＩＤ.keys]になります。
	 * 引数のlogicでモジュールＩＤ及びロジックＩＤ でリソースキーが存在しない場合は、
	 * 継承関係の上位のモジュールＩＤとロジックＩＤのリソースキーを検索していきます。
	 * 最上位のモジュールＩＤとロジックＩＤのリソースキーが存在しない場合は、引数のデフォルト値を返します。
	 * </p>
	 *
	 * @param logic リソース取得対象のロジック
	 * @param def デフォルト値
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return リソース値
	 */
	public Character getPgmSettingCharNE(FXBAL_MCLogicBase logic, Character def,
			String... keys) {
		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(logic.getClass());

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getCharacter(key);
			}
		}
		return def;
	}

	/**
	 * MCAppConst から設定値(Character)を取得します。
	 * <br><B>
	 * オペレーションクラスではなく、ロジッククラスを渡してください。
	 * </B>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @deprecated できれば FXBAL_LogicBase が引数の方を使ってください
	 * @return リソース値
	 */
	@Deprecated
	public Character getPgmSettingChar(Class<?> clazz, String... keys) {
		String[][] masiArray = MCLogicUtil.getModuleAndLogicIDs(clazz);

		for (String[] masi : masiArray) {
			String[] keyArray = MCCollectionUtil.concat(masi, keys);
			String key = MCConst.createKey(keyArray);

			if (MCConst.app.containsKey(key)) {
				return MCConst.app.getCharacter(key);
			}
		}
		String[] k = new String[] {
				masiArray[0][0], masiArray[0][1]
		};
		String[] keyArray = MCCollectionUtil.concat(k, keys);
		String key = MCConst.createKey(keyArray);
		throw new MCAppException(FXBAL0023, key);
	}

	/**
	 * 各grpColの値のグループ で maxColumnの値 が最大のものを集めたlistを返します。
	 * <P>
	 * 戻り値のリストの順番は、対象のリストの並び順を加味しません
	 * </P>
	 * @param list subList対象のリスト
	 * @param maxColumn 比較対象のカラム名
	 * @param grpColumn グループのカラム名
	 */
	protected <R extends MCRow, L extends MCList<R>> L subListMax(L list, String maxCol,
			String... grpColumn) {
		return subListMaxOrMin(list, MCList.SortType.DESC, maxCol, grpColumn);
	}

	/**
	 * 各grpColの値のグループ で maxColumnの値 が最小のものを集めたlistを返します。
	 * <P>
	 * 戻り値のリストの順番は、対象のリストの並び順を加味しません
	 * </P>
	 * @param list subList対象のリスト
	 * @param minColumn 比較対象のカラム名
	 * @param grpColumn グループのカラム名
	 */
	protected <R extends MCRow, L extends MCList<R>> L subListMin(L list, String minCol,
			String... grpColumn) {
		return subListMaxOrMin(list, MCList.SortType.ASC, minCol, grpColumn);
	}

	/**
	 *
	 * @param list subList対象のリスト
	 * @param type ソート条件
	 * @param minColumn 比較対象のカラム名
	 * @param grpColumn グループのカラム名
	 * @deprecated 共通親クラスのみでの使用を想定。{@link #subListMin(MCList, String, String...)}
	 * 又は {@link #subListMax(MCList, String, String...)}を使用してください。
	 */
	@Deprecated
	@SuppressWarnings("unchecked")
	// listのcreateInstance
	protected <R extends MCRow, L extends MCList<R>> L subListMaxOrMin(L list,
			MCList.SortType type, String minOrMaxCol, String... grpColumn) {
		if (list == null) return null;
		L down = (L) list.createInstance();

		if (minOrMaxCol == null && list.size() == 0) return down;
		String[] cols;
		if (grpColumn == null) {
			cols = new String[] {
					minOrMaxCol
			};
		}
		else {
			cols = new String[grpColumn.length + 1];
			for (int i = 0; i < grpColumn.length; i++) {
				cols[i] = grpColumn[i];
			}
			cols[grpColumn.length] = minOrMaxCol;
		}

		MCRow prevRow = null;
		if (type == null) {
			throw new MCAppException("");
		}
		MCRowComparator<R> comparator = type.getComparator(cols);
		MCIndexKey idx = list.createIndex(comparator);
		if (grpColumn == null) {
			down.add(list.get(0));
		}
		else {
			for (Iterator<R> itr = list.iterator(idx); itr.hasNext();) {
				R r = itr.next();
				if (!isColSame(prevRow, r, grpColumn)) {
					down.add(r);
				}
				prevRow = r;
			}
		}
		return down;
	}

	/**
	 * cmlColで指定したカラムに、listのcolの値を累積した値をセットする。
	 * <li>listがnullまたは空の場合は何もしない。</li>
	 * <li>list中のすべてのrowにカラムcol, cmlColが存在すること。かつNUMBER型であること。</li>
	 * <li>colがnullの場合は0を加算する。</li>
	 *
	 * @param list 対象のリスト
	 * @param col 累積するカラム
	 * @param cmlCol 累積値をセットするカラム
	 */
	public <R extends MCRow> void setCmlValue(MCList<R> list, String col, String cmlCol) {
		// cml : cumulative 累積的な
		if (list == null || list.isEmpty()) {
			return;
		}
		setCmlValue(list, col, cmlCol, 0, list.size() - 1);
	}

	/**
	 * cmlColで指定したカラムに、listのcolの値を累積した値をセットする（frIdx～toIdxの範囲）。
	 * <li>listがnullまたは空の場合は何もしない。</li>
	 * <li>list中のすべてのrowにカラムcol, cmlColが存在すること。かつNUMBER型であること。</li>
	 * <li>colがnullの場合は0を加算する。</li>
	 *
	 * @param list 対象のリスト
	 * @param col 累積するカラム
	 * @param cmlCol 累積値をセットするカラム
	 * @param frIdx 累積計算開始行（0以上をセットする）
	 * @param toIdx 累積計算終了行（この行を含む）
	 */
	public <R extends MCRow> void setCmlValue(MCList<R> list, String col, String cmlCol,
			int frIdx, int toIdx) {
		if (list == null || list.isEmpty()) {
			return;
		}

		MCNumber sum;
		if (frIdx < 1) {
			sum = MCNumber.ZERO;
		}
		else {
			sum = list.get(frIdx - 1).getNumber(cmlCol);
			if (sum == null) {
				sum = MCNumber.ZERO;
			}
		}
		for (int i = frIdx; i <= toIdx; i++) {
			if (list.get(i).getNumber(col) != null) {
				sum = sum.add(list.get(i).getNumber(col));
			}
			list.get(i).setNumber(cmlCol, sum);
		}
	}

	/**
	 * リストの中から条件に合致したデータのリストを返します。
	 * 条件はOracleの like 演算子の右辺と同じ物が使えます。
	 * つまり、「A%Z」を指定した場合は、「A」で始まり「Z」で終了する
	 * 文字列のリストが返ります。
	 *
	 * @param list リスト
	 * @param condition 条件
	 */
	public List<String> subListByLike(List<String> list, String condition) {
		List<String> ret = new ArrayList<>();
		if (list == null || list.size() == 0 || condition == null) return ret;
		String regex = toRegexForOracleLike(condition);
		for (String s : list) {
			if (s.matches(regex)) {
				ret.add(s);
			}
		}
		return ret;
	}

	/**
	 * リストの比較対象のカラムのデータが条件に合致した
	 * 行のリストを返します。
	 * 条件はOracleの like 演算子の右辺と同じ物が使えます。
	 * つまり、「A%Z」を指定した場合は、「A」で始まり「Z」で終了する
	 * 文字列のリストが返ります。
	 *
	 * @param list リスト
	 * @param column 比較対象のカラム
	 * @param condition 条件
	 */
	public <E extends MCRow> MCList<E> subListByLike(MCList<E> list, String column,
			String condition) {
		MCList<E> ret = list.createInstance();
		if (list.size() == 0 || condition == null) return ret;
		String regex = toRegexForOracleLike(condition);
		for (E r : list) {
			if (r.getString(column).matches(regex)) {
				ret.add(r);
			}
		}
		return ret;
	}

	/**
	 * MCPgmSettingから設定値を取得します。
	 *
	 * @param moduleId
	 * @param logicId
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return
	 */
	public String getPgmSettingString(String moduleId, String logicId, String... keys) {
		// メモ：リソースは基本的に必ず必要。よって「NE(No Error)」メソッドは作らない
		// （状況をみて対応を変更するかも知れないが）

		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[] keyArray = new String[] {
				moduleId, logicId
		};
		keyArray = MCCollectionUtil.concat(keyArray, keys);
		String key = MCConst.createKey(keyArray);

		if (MCConst.app.containsKey(key)) {
			return MCConst.app.getString(key);
		}
		throw new MCAppException(FXBAL0015, key);
	}

	/**
	 * MCPgmSettingから設定値を取得します。
	 *
	 * @param moduleId
	 * @param logicId
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return
	 */
	public MCNumber getPgmSettingNumber(String moduleId, String logicId, String... keys) {
		// メモ：リソースは基本的に必ず必要。よって「NE(No Error)」メソッドは作らない
		// （状況をみて対応を変更するかも知れないが）

		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[] keyArray = new String[] {
				moduleId, logicId
		};
		keyArray = MCCollectionUtil.concat(keyArray, keys);
		String key = MCConst.createKey(keyArray);

		if (MCConst.app.containsKey(key)) {
			return MCConst.app.getNumber(key);
		}
		throw new MCAppException(FXBAL0015, key);
	}

	/**
	 * MCPgmSettingから設定値を取得します。
	 *
	 * @param moduleId
	 * @param logicId
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return
	 */
	public int getPgmSettingInt(String moduleId, String logicId, String... keys) {
		// メモ：リソースは基本的に必ず必要。よって「NE(No Error)」メソッドは作らない
		// （状況をみて対応を変更するかも知れないが）

		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[] keyArray = new String[] {
				moduleId, logicId
		};
		keyArray = MCCollectionUtil.concat(keyArray, keys);
		String key = MCConst.createKey(keyArray);

		if (MCConst.app.containsKey(key)) {
			return MCConst.app.getInteger(key);
		}
		throw new MCAppException(FXBAL0015, key);
	}

	/**
	 * MCPgmSettingから設定値を取得します。
	 *
	 * @param moduleId
	 * @param logicId
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return
	 */
	public boolean getPgmSettingBoolean(String moduleId, String logicId, String... keys) {
		// メモ：リソースは基本的に必ず必要。よって「NE(No Error)」メソッドは作らない
		// （状況をみて対応を変更するかも知れないが）

		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[] keyArray = new String[] {
				moduleId, logicId
		};
		keyArray = MCCollectionUtil.concat(keyArray, keys);
		String key = MCConst.createKey(keyArray);

		if (MCConst.app.containsKey(key)) {
			return MCConst.app.getBoolean(key);
		}
		throw new MCAppException(FXBAL0015, key);
	}

	/**
	 * MCPgmSettingから設定値を取得します。
	 *
	 * @param moduleId
	 * @param logicId
	 * @param keys moduleId , logicId 以降のタグの配列
	 * @return
	 */
	public Character getPgmSettingChar(String moduleId, String logicId, String... keys) {
		// メモ：リソースは基本的に必ず必要。よって「NE(No Error)」メソッドは作らない
		// （状況をみて対応を変更するかも知れないが）

		// メモ：keysがnullは、ありえない（タグの設計として必須）
		String[] keyArray = new String[] {
				moduleId, logicId
		};
		keyArray = MCCollectionUtil.concat(keyArray, keys);
		String key = MCConst.createKey(keyArray);

		if (MCConst.app.containsKey(key)) {
			return MCConst.app.getCharacter(key);
		}
		throw new MCAppException(FXBAL0015, key);
	}

	// ユーティリティ(END) ====================================
	// 帳票関連(START) ====================================
	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param list 変換対象のlist。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlaceCol 変換時に使用する数値の小数部有効桁数を格納しているカラム
	 */
	protected <R extends MCRow, L extends MCList<R>> void putNumStr(MCReportSet rpt,
			L list, String strCol, String numCol, String decPlaceCol) {
		putNumStr(rpt, list, strCol, numCol, decPlaceCol, null);
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param list 変換対象のlist。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlaceCol 変換時に使用する数値の小数部有効桁数を格納しているカラム
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected <R extends MCRow, L extends MCList<R>> void putNumStr(MCReportSet rpt,
			L list, String strCol, String numCol, String decPlaceCol,
			RoundingMode roundingMode) {
		if (list == null || list.size() == 0) {
			return;
		}

		Locale lcl = rpt.getLocale();
		R proto = list.get(0);
		String fmtId = getRptFormatId(rpt, proto, numCol);
		DecimalFormat decFmt = createDecimalFormat(lcl, fmtId);

		if (decFmt != null) {
			MCZeroType zeroType = getNumberZeroType(lcl, fmtId);
			for (R r : list) {
				MCNumber num = r.getNumber(numCol);
				if (isNull(num)) {
					r.setString(strCol, null);
				}
				else {
					MCNumber decPlace = r.getNumber(decPlaceCol);
					int scale = (decPlace == null) ? -1 : decPlace.intValue();
					String t;
					t = doFormat(num, scale, decFmt, zeroType, roundingMode);
					r.setString(strCol, t);
				}
			}
		}
		else {
			// formatが取れない場合
			for (R r : list) {
				MCNumber num = r.getNumber(numCol);
				if (isNull(num)) {
					r.setString(strCol, null);
				}
				else {
					r.setString(strCol, num.toString());
				}
			}
		}
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param list 変換対象のlist。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するメタ
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected <R extends MCRow, L extends MCList<R>> void putNumStr(MCReportSet rpt,
			L list, String strCol, String numCol, MCMeta decPlace,
			RoundingMode roundingMode) {
		int p = (decPlace == null) ? -1 : decPlace.scale();
		putNumStr(rpt, list, strCol, numCol, new MCNumber(p), roundingMode);
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param list 変換対象のlist。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するメタ
	 */
	protected <R extends MCRow, L extends MCList<R>> void putNumStr(MCReportSet rpt,
			L list, String strCol, String numCol, MCMeta decPlace) {
		int p = (decPlace == null) ? -1 : decPlace.scale();
		putNumStr(rpt, list, strCol, numCol, new MCNumber(p));
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param list 変換対象のlist。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数
	 */
	protected <R extends MCRow, L extends MCList<R>> void putNumStr(MCReportSet rpt,
			L list, String strCol, String numCol, MCNumber decPlace) {
		putNumStr(rpt, list, strCol, numCol, decPlace, null);
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param list 変換対象のlist。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected <R extends MCRow, L extends MCList<R>> void putNumStr(MCReportSet rpt,
			L list, String strCol, String numCol, MCNumber decPlace,
			RoundingMode roundingMode) {
		if (list == null || list.size() == 0) {
			return;
		}

		Locale lcl = rpt.getLocale();
		R proto = list.get(0);
		String fmtId = getRptFormatId(rpt, proto, numCol);
		DecimalFormat decFmt = createDecimalFormat(lcl, fmtId);

		if (decFmt != null) {
			MCZeroType zeroType = getNumberZeroType(lcl, fmtId);
			for (R r : list) {
				MCNumber num = r.getNumber(numCol);
				if (isNull(num)) {
					r.setString(strCol, null);
				}
				else {
					int scale = (decPlace == null) ? -1 : decPlace.intValue();
					String t;
					t = doFormat(num, scale, decFmt, zeroType, roundingMode);
					r.setString(strCol, t);
				}
			}
		}
		else {
			// formatが取れない場合
			for (R r : list) {
				MCNumber num = r.getNumber(numCol);
				if (isNull(num)) {
					r.setString(strCol, null);
				}
				else {
					r.setString(strCol, num.toString());
				}
			}
		}
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param row 変換対象のRow。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するメタ
	 */
	protected <R extends MCRow> void putNumStr(MCReportSet rpt, R row, String strCol,
			String numCol, MCMeta decPlace) {
		putNumStr(rpt, row, strCol, numCol, decPlace, null);
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param row 変換対象のRow。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するメタ
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected <R extends MCRow> void putNumStr(MCReportSet rpt, R row, String strCol,
			String numCol, MCMeta decPlace, RoundingMode roundingMode) {
		int p = (decPlace == null) ? -1 : decPlace.scale();
		putNumStr(rpt, row, strCol, numCol, new MCNumber(p), roundingMode);
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param row 変換対象のRow。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数
	 */
	protected <R extends MCRow> void putNumStr(MCReportSet rpt, R row, String strCol,
			String numCol, MCNumber decPlace) {
		putNumStr(rpt, row, strCol, numCol, decPlace, null);
	}

	/**
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param <R>
	 * @param rpt レポートセット
	 * @param row 変換対象のRow。レポートセットに格納可能なRowであること。
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected <R extends MCRow> void putNumStr(MCReportSet rpt, R row, String strCol,
			String numCol, MCNumber decPlace, RoundingMode roundingMode) {

		MCNumber num = row.getNumber(numCol);
		if (num == null) {
			row.setString(strCol, null);
			return;
		}

		Locale lcl = rpt.getLocale();

		String fmtId = getRptFormatId(rpt, row, numCol);
		DecimalFormat decFmt = createDecimalFormat(lcl, fmtId);

		if (decFmt != null) {
			MCZeroType zeroType = getNumberZeroType(lcl, fmtId);
			int scale = (decPlace == null) ? -1 : decPlace.intValue();
			String t;
			t = doFormat(num, scale, decFmt, zeroType, roundingMode);
			row.setString(strCol, t);
		}
		else {
			// formatが取れない場合
			row.setString(strCol, num.toString());
		}
	}

	/**
	 * レポートセットに存在する全てのRowのうち、指定された数値カラムと
	 * 文字列カラムがあるRowに対して、
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param rpt レポートセット
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するメタ
	 */
	protected void putNumStr(MCReportSet rpt, String strCol, String numCol,
			MCMeta decPlace) {
		putNumStr(rpt, strCol, numCol, decPlace, null);
	}

	/**
	 * レポートセットに存在する全てのRowのうち、指定された数値カラムと
	 * 文字列カラムがあるRowに対して、
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param rpt レポートセット
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するメタ
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected void putNumStr(MCReportSet rpt, String strCol, String numCol,
			MCMeta decPlace, RoundingMode roundingMode) {
		int p = (decPlace == null) ? -1 : decPlace.scale();
		putNumStr(rpt, strCol, numCol, new MCNumber(p), roundingMode);
	}

	/**
	 * レポートセットに存在する全てのRowのうち、指定された数値カラムと
	 * 文字列カラムがあるRowに対して、
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param rpt レポートセット
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数
	 */
	protected void putNumStr(MCReportSet rpt, String strCol, String numCol,
			MCNumber decPlace) {
		putNumStr(rpt, strCol, numCol, decPlace, null);
	}

	/**
	 * レポートセットに存在する全てのRowのうち、指定された数値カラムと
	 * 文字列カラムがあるRowに対して、
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param rpt レポートセット
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected void putNumStr(MCReportSet rpt, String strCol, String numCol,
			MCNumber decPlace, RoundingMode roundingMode) {
		MCList list = rpt.getAll();
		for (int i = 0; i < list.size(); i++) {
			MCRow row = list.get(i);
			if (row.contains(strCol)) {
				if (row.contains(numCol)) {
					putNumStr(rpt, row, strCol, numCol, decPlace, roundingMode);
				}
			}
		}
	}

	/**
	 * レポートセットに存在する全てのRowのうち、指定された数値カラムと
	 * 文字列カラムと小数部有効桁数があるRowに対して、
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param rpt レポートセット
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するカラム
	 */
	protected void putNumStr(MCReportSet rpt, String strCol, String numCol,
			String decPlace) {
		putNumStr(rpt, strCol, numCol, decPlace, null);
	}

	/**
	 * レポートセットに存在する全てのRowのうち、指定された数値カラムと
	 * 文字列カラムと小数部有効桁数があるRowに対して、
	 * 「コンテナに持っている数値の表示形式」と引数の「小数部有効桁数」を元に
	 * 数値の文字列表現を指定のカラムにセットします。
	 *
	 * @param rpt レポートセット
	 * @param strCol 数値の文字列表現を格納するためのカラム
	 * @param numCol 変換対象の数値が格納されているカラム
	 * @param decPlace 変換時に使用する数値の小数部有効桁数を保持するカラム
	 * @param roundingMode 有効桁数以下の丸め方法
	 */
	protected void putNumStr(MCReportSet rpt, String strCol, String numCol,
			String decPlace, RoundingMode roundingMode) {
		MCList list = rpt.getAll();
		for (int i = 0; i < list.size(); i++) {
			MCRow row = list.get(i);
			if (row.contains(strCol)) {
				if (row.contains(numCol)) {
					if (row.contains(decPlace)) {
						putNumStr(rpt, row, strCol, numCol, row.getNumber(decPlace),
								roundingMode);
					}
				}
			}
		}
	}

	/**
	 *
	 * @param lcl
	 * @param fmtId
	 * @deprecated 共通親クラスのみ使用、オーバーライド可
	 * @return
	 */
	@Deprecated
	protected MCZeroType getNumberZeroType(Locale lcl, String fmtId) {
		if (fmtId != null && !isSame(MCFormatConst.NOFORMAT, fmtId)) {
			MCFormatConst fmt = MCLocaleConst.format(lcl);
			return fmt.getNumberZeroType(fmtId);
		}
		return null;
	}

	/**
	 * 帳票用のフォーマットＩＤを取得する
	 * @param row
	 * @param colName
	 * @deprecated 共通親クラスのみ使用、オーバーライド可
	 * @return
	 */
	@Deprecated
	protected String getRptFormatId(MCReportSet rpt, MCRow row, String colName) {
		MCReportMeta rptMeta = rpt.getReportMeta(row, colName);

		String fmtId = rptMeta.getFormat();

		return fmtId;
	}

	/**
	 * リソースから、ロケールで有効なフォーマットＩＤのフォーマットから、
	 * DecimalFormatを作成する
	 * @param lcl ロケール
	 * @param fmtId フォーマットＩＤ
	 * @deprecated 共通親クラスのみ使用、オーバーライド可
	 * @return 対応するフォーマットパターンが存在しない場合は null
	 */
	@Deprecated
	protected DecimalFormat createDecimalFormat(Locale lcl, String fmtId) {
		DecimalFormat ret = null;
		if (fmtId != null && !isSame(MCFormatConst.NOFORMAT, fmtId)) {
			MCFormatConst fmt = MCLocaleConst.format(lcl);
			String fmtPtn = fmt.getNumberOutputPattern(fmtId);
			if (fmtPtn != null) {
				ret = new DecimalFormat(fmtPtn);
			}
		}
		return ret;
	}

	/**
	 *
	 * @param value
	 * @param scale 小数部有効桁数。負の値の場合で、このscaleを使用する場合はvalueのscaleを使用する
	 * @param format
	 * @param zeroType
	 * @deprecated 共通親クラスのみ使用、オーバーライド可
	 * @return
	 */
	@Deprecated
	protected String doFormat(MCNumber value, int scale, DecimalFormat format,
			MCZeroType zeroType, RoundingMode roundMode) {
		if (value != null) {
			int myScale = (scale < 0) ? value.scale() : scale;
			MCNumber temp;
			if (myScale < value.scale()) {
				if (roundMode == null) {
					temp = value;
				}
				else {
					temp = value.setScale(myScale, roundMode);
				}
			}
			else {
				temp = value;
			}

			temp = temp.stripTrailingZeros();
			switch (zeroType) {
				case CUT:
					myScale = temp.scale();
					break;
				case PADDING:
					if (temp.scale() > myScale) {
						myScale = temp.scale();
					}
					break;
				default:
					myScale = temp.scale();
					break;
			}

			format.setMinimumFractionDigits(myScale);
			return format.format(temp);
		}
		return null;
	}

	// 帳票関連(END) ======================================

	// コンテナコピー(START) ====================================
	/**
	 * Rowの内容をコピーします。 値と属性をコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCRowMapper#copy(MCRow, MCRow)
	 */
	protected <D extends MCRow, S extends MCRow> void copy(D dest, S src,
			MCRowMapper<D, S> rm) {
		rm.copy(dest, src);
	}

	/**
	 * Rowの内容をコピーします。 値のみコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCRowMapper#copyValue(MCRow, MCRow)
	 */
	protected <D extends MCRow, S extends MCRow> void copyValue(D dest, S src,
			MCRowMapper<D, S> rm) {
		rm.copyValue(dest, src);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void setAll(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAll((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void setAllValue(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void setAll(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAll((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void setAllValue(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void addAll(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAll((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void addAllValue(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * JOINされているListの内容をコピーします。
	 * <p>
	 * 引数 dest、引数 key のいずれかまたは両方が null の場合は何も行いません。 <br>
	 * RowMapper の中で明示的にコピーしない限り、RowのAttributeはコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param key JOINキー
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#join(MCList, MCJoinKey)
	 */
	@SuppressWarnings("unchecked")
	// joinメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void join(
			D dest, MCJoinKey<S> key, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.join((MCList<DR>) dest, (MCJoinKey<MCList<SR>>) key);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void addAll(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAll((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void addAllValue(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * JOINされているListの内容をコピーします。
	 * <p>
	 * 引数 dest、引数 key のいずれかまたは両方が null の場合は何も行いません。 <br>
	 * RowMapper の中で明示的にコピーしない限り、RowのAttributeはコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param key JOINキー
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#join(MCList, MCJoinKey)
	 */
	@SuppressWarnings("unchecked")
	// joinメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void join(
			D dest, MCJoinKey<S> key, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.join((MCList<DR>) dest, (MCJoinKey<MCList<SR>>) key);
	}

	/**
	 * Rowの内容をコピーします。 値と属性をコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * @param dest コピー先
	 * @param src1 コピー元1(valueCopyメソッドの引数になる)
	 * @param src2 コピー元2(RowMapperのフィールドにセットされる)
	 * @param rm RowMapper
	 */
	protected <D extends MCRow, S extends MCRow, W extends Object> void copy(D dest,
			S src1, W src2, FXUCC_RowMapperWith<D, S, W> rm) {
		rm.setWith(src2);
		rm.copy(dest, src1);
	}

	/**
	 * Rowの内容をコピーします。 値のみコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * @param dest コピー先
	 * @param src1 コピー元1(valueCopyメソッドの引数になる)
	 * @param src2 コピー元2(RowMapperのフィールドにセットされる)
	 * @param rm RowMapper
	 */
	protected <D extends MCRow, S extends MCRow, W extends Object> void copyValue(D dest,
			S src1, W src2, FXUCC_RowMapperWith<D, S, W> rm) {
		rm.setWith(src2);
		rm.copyValue(dest, src1);
	}

	// コンテナコピー(END) ====================================

	// WT_LOGS(START) ====================================

	/**
	 * カスタマイズ用に作成されたMCConst.dblbl.getLabelのラッパーです。
	 *
	 * データベーステーブルまたは項目のユーザロケールラベル文字列を返します。
	 *
	 * テーブル名のみ指定した場合、テーブル名のラベル文字列を検索します。<br>
	 * テーブル名と項目名とを指定した場合、項目名のラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param tblName テーブル名
	 * @param colName 項目名
	 * @return テーブル名または項目名のラベル文字列。テーブル名未指定の場合はnull。キーがない場合は null
	 */
	public String getDBLabel(String tblName, String colName) {
		return FXUCC_ResourceUtil.getDBLabel(tblName, colName);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.dblbl.getLabelのラッパーです。
	 *
	 * データベーステーブルまたは項目のラベル文字列を返します。
	 *
	 * テーブル名のみ指定した場合、テーブル名のラベル文字列を検索します。<br>
	 * テーブル名と項目名とを指定した場合、項目名のラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param tblName テーブル名
	 * @param colName 項目名
	 * @param locale ロケール
	 * @return テーブル名または項目名のラベル文字列。テーブル名未指定の場合はnull。キーがない場合は null
	 */
	public String getDBLabel(String tblName, String colName, Locale locale) {
		return FXUCC_ResourceUtil.getDBLabel(tblName, colName, locale);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.lgclbl.getLabelのラッパーです。
	 *
	 * ロジックＩＤまたはオペレーションＩＤのユーザロケールラベル文字列を返します。
	 *
	 * ロジックＩＤのみ指定した場合、ロジックＩＤのラベル文字列を検索します。<br>
	 * ロジックＩＤとオペレーションＩＤとを指定した場合、オペレーションＩＤのラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param mod モジュールＩＤ
	 * @param lgc ロジックＩＤ
	 * @param ope オペレーションＩＤ
	 * @return ロジックＩＤまたはオペレーションＩＤのラベル文字列。モジュールＩＤとロジックＩＤが未指定の場合はnull。キーがない場合は null
	 */
	public String getLogicLabel(String mod, String lgc, String ope) {
		return FXUCC_ResourceUtil.getLogicLabel(mod, lgc, ope);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.lgclbl.getLabelのラッパーです。
	 *
	 * ロジックＩＤまたはオペレーションＩＤのラベル文字列を返します。
	 *
	 * ロジックＩＤのみ指定した場合、ロジックＩＤのラベル文字列を検索します。<br>
	 * ロジックＩＤとオペレーションＩＤとを指定した場合、オペレーションＩＤのラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param mod モジュールＩＤ
	 * @param lgc ロジックＩＤ
	 * @param ope オペレーションＩＤ
	 * @param locale ロケール
	 * @return ロジックＩＤまたはオペレーションＩＤのラベル文字列。モジュールＩＤとロジックＩＤが未指定の場合はnull。キーがない場合は null
	 */
	public String getLogicLabel(String mod, String lgc, String ope, Locale locale) {
		return FXUCC_ResourceUtil.getLogicLabel(mod, lgc, ope, locale);
	}

	// WT_LOGS(END) ====================================

	/**
	 * リストロジックメソッド用のDBコンテナ設定共通処理です。
	 *
	 * @param row　条件
	 * @param d DBコンテナ
	 * @param listLogicId リストロジックＩＤ
	 */
	protected void listlogicCommon_Set(
			MCRow row, MCQueryApiBuilder builder, String listLogicId) {
	}

	/**
	 * リストロジックメソッド用の検索結果の加工共通処理です。
	 *
	 * @param row　条件
	 * @param d DBコンテナ
	 * @param rd 戻り値候補のコンテナ
	 * @param listLogicId リストロジックＩＤ
	 * @return 加工後のコンテナ
	 */
	protected <R extends MCDBContainer, DR extends MCRow, DL extends MCList<DR>> DL listlogicCommon_AfterSelect(
			MCRow row, MCList<? extends R> d, DL rd, String listLogicId) {
		return rd;
	}
	//FMCB CUSTOM END
}