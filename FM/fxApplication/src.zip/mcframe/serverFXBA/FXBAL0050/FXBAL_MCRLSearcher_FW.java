package mcframe.serverFXBA.FXBAL0050;

import java.util.List;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.serverCore.logic.MCController;
import mcframe.serverCore.logic.MCDBSubOperation;
import mcframe.serverFXBA.FXBAL0050.FXBAL_MCSimpleRLSearcher;

public abstract class FXBAL_MCRLSearcher_FW extends FXBAL_MCSimpleRLSearcher {

	// //////////////////////////////////////////
	// 検索前処理（ここから）
	// //////////////////////////////////////////

	// //////////////////////////////////////////
	// 検索前処理（ここまで）
	// //////////////////////////////////////////

	// //////////////////////////////////////////
	// 検索後処理（ここから）
	// //////////////////////////////////////////
	@Override
	protected void down() {
		super.down();
		downColumnsData();
	}

	/** 
	 * 実装仕様書で定義できない下り電文へのデータコピー処理を行います。<p>
	 * SELECTサブオペレーションでコピーできない項目は、
	 * できるだけdown_SELECT_[コントローラ名]_[番号]メソッドを継承して実装してください。
	 */
	protected void downColumnsData() {
		MCList<?> dbc = null;

		// 検索結果を持つdbcの取得
		List<MCController> ctrls = getSubOpes(SELECT);
		MCController ctrl = ctrls.get(0);
		if (ctrl instanceof MCDBSubOperation) {
			dbc = ((MCDBSubOperation<?>) ctrl).down0;
		}
		else {
			return;
		}

		MCContainer c = down(0);
		if (c instanceof MCList) {
			@SuppressWarnings("unchecked")
			MCList<MCRow> down = (MCList<MCRow>) c;

			for (int i = 0; i < down.size(); i++) {

				downColumnsData(down.get(i), dbc.get(i));

			}
		}
	}
	/** 
	 * 下り電文のRowのカラムに DBコンテナのRow の値を設定します。<p>
	 * SELECTサブオペレーションでコピーできない項目は、
	 * できるだけdown_SELECT_[コントローラ名]_[番号]メソッドを継承して実装してください。
	 * 
	 */
	protected void downColumnsData(MCRow r_dest, MCRow r_src) {
		downAttribute(r_dest, r_src);
	}

	/** 
	 * 下り電文のRowのカラムに DBコンテナのRow の属性値を設定します。<p>
	 * SELECTサブオペレーションでコピーできない項目は、
	 * できるだけdown_SELECT_[コントローラ名]_[番号]メソッドを継承して実装してください。
	 */
	protected void downAttribute(MCRow r_dest, MCRow r_src) {
	}
	// //////////////////////////////////////////
	// 検索後処理（ここまで）
	// //////////////////////////////////////////
}
