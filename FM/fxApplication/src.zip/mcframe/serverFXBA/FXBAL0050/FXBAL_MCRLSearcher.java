package mcframe.serverFXBA.FXBAL0050;

import mcframe.commonCore.annotation.EI;

@EI
public abstract class FXBAL_MCRLSearcher extends FXBAL_MCRLSearcher_FW {

}
