package mcframe.serverFXBA.FXBAL0050;
import mcframe.commonCore.annotation.EI;

@EI
public abstract class FXBAL_MCRLUpdater extends FXBAL_MCRLUpdater_FW {

}
