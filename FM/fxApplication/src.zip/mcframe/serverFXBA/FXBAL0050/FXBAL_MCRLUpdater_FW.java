package mcframe.serverFXBA.FXBAL0050;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.database.MCSQLClause.*;
import static mcframe.serverCore.queryapi.IFMCSQL.*;
import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;
import static mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil.*;

import java.util.HashMap;
import java.util.List;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCJoinKey;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCRowMatcher;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCLog;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonCore.sys.MCFactory;
import mcframe.serverCore.database.MCDBExpr;
import mcframe.serverCore.logic.MCController;
import mcframe.serverCore.logic.MCDBSubOperation;
import mcframe.serverCore.logic.MCOperation;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import mcframe.serverCore.resource.MCConst;
import mcframe.serverFXBA.FXBAL0060.FXBAL_MCRLUtil;
import mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil;

/**
 * 利用方法
 * UPDATE サブオペレーショングループのＤＢコンテナのキー項目名に対応する
 * 電文の項目名を同じにすること。
 * 変更前キー項目として、上記項目名の最後に"_key"を追加した項目を
 * 作成しておくこと。
 */

public abstract class FXBAL_MCRLUpdater_FW extends MCOperation {
	/** 
	 * モジュールID<p>
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * ロジックID<p>
	 *
	 * ロジックはモジュールIDとロジックIDで一意に特定できます。<br>
	 */
	public static final String LOGIC_ID = "FXBAL0050";


	// 実行I/F
	@Override
	protected void call() {
		up();
		lockTable();
		defCheck();
		doIt();
		afterDefCheck();
		down();

	}

	// [サブオペレーショングループのタイプ] //
	// UPDATE: 更新を行う
	// MAIN: 更新対象のテーブルのキー重複チェックを行う
	// OTHER: 削除されるデータを利用している可能性のあるテーブルのチェックを行う

	protected static final String UPDATE = "UPDATE";

	protected static final String MAIN = "MAIN";

	protected static final String OTHER = "OTHER";

	/** 最初に見つけたUPDATE サブオペレーショングループのDBCのRowを返します。 */
	protected MCDBContainer getUpdDbcRow(int paramRowIndex) {
		if (_updDbcRowMap == null) {

			_updDbcRowMap = new HashMap<Integer, MCDBContainer>();
			addBeforeKeyColumns(getUpdDbc(), getUpdUp1());

			for (MCDBContainer r : getUpdUp1()) {
				_updDbcRowMap.put(r.getParamRowIndex(), r);
			}

		}
		return _updDbcRowMap.get(paramRowIndex);

	}

	protected HashMap<Integer, MCDBContainer> _updDbcRowMap;

	/** 最初に見つけたUPDATE サブオペレーショングループのDBCを返します。 */
	protected MCDBContainer getUpdDbc() {
		if (_updDbc == null) {
			for (MCController ctrl : getSubOpes(UPDATE)) {
				if (ctrl instanceof MCDBSubOperation) {
					MCDBContainer d = ((MCDBSubOperation<?>) ctrl).dbc();
					if (d instanceof MCDBContainer) {
						_updDbc = (MCDBContainer) d;
						_updUp1 = (MCList<? extends MCDBContainer>)  ((MCDBSubOperation<?>) ctrl).up1;
						break;
					}
				}
			}
		}
		if (_updDbc != null) {
			return _updDbc;
		}
		else {
			throw new MCAppException(FXBAL0016);
		}
	}

	protected MCDBContainer _updDbc;

	/** 最初に見つけたUPDATE サブオペレーショングループのUP1を返します。 */
	protected MCList<? extends MCDBContainer> getUpdUp1() {
		getUpdDbc();
		return _updUp1;
	}

	protected MCList<? extends MCDBContainer> _updUp1;

	/** ＤＢコンテナに変更前キー項目のカラムを追加します。 */
	protected void addBeforeKeyColumns(MCDBContainer dbc, MCList<?> list) {

		String[] keyCols = dbc.getKeyColumn();
		String[] bKeyCols = FXBAL_MCRLUtil.getBeforeKeyColumns(keyCols);

		for (int i = 0; i < keyCols.length; i++) {
			String kc = keyCols[i];
			String bkc = bKeyCols[i];

			MCDataType typ = dbc.getDataType(kc);

			/* src.getValue(c)がnullでもカラムを作成する。 */
			if (typ == MCDataType.STRING) {
				list.addStringColumn(bkc);
			}
			else if (typ == MCDataType.NUMBER) {
				list.addNumberColumn(bkc);
			}
			else if (typ == MCDataType.DATE) {
				list.addDateColumn(bkc);
			}
			else if (typ == MCDataType.BOOLEAN) {
				list.addBooleanColumn(bkc);
			}
			else if (typ == MCDataType.TIMESTAMP) {
				list.addTimestampColumn(bkc);
			}
		}
	}

	// ////////////////////////////////////////////////////////////////
	// /上り///////////////////////////////////////////////////////////
	// ////////////////////////////////////////////////////////////////
	/**
	 * サブオペレーションにデータをコピーします。
	 * <p>
	 * UPDATE サブオペレーショングループのＤＢコンテナへのコピー処理は、通常のコピー処理に加え、次の処理が行われます。<br>
	 * <li>ＤＢコンテナに上り電文の変更前キー項目の値をコピーする
	 * <li>電文のRowがdeleteステータスの場合、変更前キー項目の値を、ＤＢコンテナのキー項目にコピーする
	 * 
	 */
	protected void up() {
		mapUpContainers(UPDATE);
		copyBeforeKeyToUpd();
		mapUpContainers(MAIN);
		mapUpContainers(OTHER);
	}

	/** 
	 * 電文の変更前キー値 を更新用ＤＢコンテナにコピーします。<p> 
	 * @see #copyBeforeKeyToUpd(MCDBRow, MCRow)
	 * @see #copyBeforeKeyToUpdDelKey(MCDBRow, MCRow)
	 */
	protected void copyBeforeKeyToUpd() {

		MCContainer upC = up(0);
		if (upC instanceof MCList) {
			for (Object o : (MCList<?>) upC) {
				if (o instanceof MCRow) {
					MCRow upR = (MCRow) o;
					MCDBContainer updR = getUpdDbcRow(upR.getParamRowIndex());
					copyBeforeKeyToUpd(updR, upR);
					copyBeforeKeyToUpdDelKey(updR, upR);
				}
			}
		}
	}

	/**  更新用ＤＢコンテナの変更前キーカラムに電文の変更前キー値 をコピーします。 */
	public void copyBeforeKeyToUpd(MCDBContainer dest, MCRow src) {
		for (String c : FXBAL_MCRLUtil.getBeforeKeyColumns(dest.getKeyColumn())) {

			dest.setValue(c, src.getValue(c));
		}
	}

	/** 引数srcが削除ステータスの場合、変更前キー値を更新用ＤＢコンテナのキー項目にコピーさせます。 */
	public void copyBeforeKeyToUpdDelKey(MCDBContainer dest, MCRow src) {
		if (src.isStatusDelete()) {
			String[] kcs = dest.getKeyColumn();
			String[] bkcs = FXBAL_MCRLUtil.getBeforeKeyColumns(kcs);
			for (int i = 0; i < bkcs.length; i++) {
				String kc = kcs[i];
				String bkc = bkcs[i];
				dest.setValue(kc, src.getValue(bkc));
			}
		}
	}

	// ////////////////////////////////////////////////////////////////
	// /テーブルロック/////////////////////////////////////////////////
	// ////////////////////////////////////////////////////////////////
	/**テーブルをロックする場合、このメソッド内で行ってください。*/
	protected void lockTable() {
		// 何もしない
	}

	// ////////////////////////////////////////////////////////////////
	// /チェック///////////////////////////////////////////////////////
	// ////////////////////////////////////////////////////////////////
	/**
	 * チェックのメッセージを格納するリストを返します。
	 * <p>
	 * このリストにメッセージが格納されている場合、[@link #throwMsgList()}によってthrowされます。<br>
	 * throwMsgList()が呼び出されるタイミングは、下記メソッドの直後です。
	 * <li>{@link #defCheck()}
	 * <li>{@link #beforeUpdate(FX_DBCBase_L)}
	 * <li>{@link #afterUpdate(FX_DBCBase_L)}
	 * <li>{@link #afterDefCheck()}
	 * 
	 */
	protected MCMessageList getMsgList() {
		return _m;
	}

	/** チェックのメッセージを格納するリストの内容を初期化します。 */
	protected void initMsgList() {
		_m.clear();
	}

	/** メッセージリストにメッセージがある場合、それをthrowします。 */
	protected void throwMsgList() {
		if (!getMsgList().isEmpty()) {
			MCAppException ex = new MCAppException(FXBAL_MCRLUtil.getHeaderMsgId());
			ex.setCauseMessageList(getMsgList());
			throw ex;
		}
	}

	protected final MCMessageList _m = new MCMessageList();

	/**
	 * デフォルトで実装されているチェックを行います。
	 * <p>
	 * @see #beforeDefChk(MCMessageList)
	 * @see #chkMainTable(MCMessageList)
	 * @see #throwMsgList()
	 */
	protected void defCheck() {
		initMsgList();
		MCMessageList msgList = getMsgList();

		beforeDefChk(msgList);

		MCLog.write(new MCMessage(FXBAL0018));
		chkMainTable(msgList);
		throwMsgList();
	}

	/**defCheck()の始めに呼ばれます。*/
	protected void beforeDefChk(MCMessageList msgList) {
		// 何もしない
	}


	/**
	 * デフォルトで実装されている更新後チェックを行います。
	 * <p>
	 * @see #afterDefChk(MCMessageList)
	 * @see #chkOtherTable(MCMessageList)
	 * @see #throwMsgList()
	 */
	protected void afterDefCheck() {
		MCMessageList msgList = getMsgList();

		afterDefChk(msgList);
		
		MCLog.write(new MCMessage(FXBAL0019));
		chkOtherTable(msgList);
		throwMsgList();
	}

	/**afterDefCheck()の始めに呼ばれます。*/
	protected void afterDefChk(MCMessageList msgList){
		// 何もしない
	}
	
	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * 登録対象のテーブルに、新規（キー変更含む）行がすでに存在する場合、そのメッセージを引数のMCMessageListに格納します。
	 */
	protected void chkMainTable(MCMessageList m) {

		List<MCController> ms = getSubOpes(MAIN);
		for (int i = 0; i < ms.size(); i++) {
			MCController ctrl = ms.get(i);

			if (ctrl instanceof MCDBSubOperation<?>) {
				if (((MCDBSubOperation<?>) ctrl).dbc() instanceof MCDBContainer) {
					@SuppressWarnings("unchecked")
					MCList<MCDBContainer> mainDbc = (MCList<MCDBContainer>)  ((MCDBSubOperation<?>) ctrl).up1;

					chkMainList(mainDbc, m, ctrl);

				}
			}
		}
	}

	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * 新規（キー変更含む）行がすでに存在する場合そのメッセージを引数のMCMessageListに格納します。<br>
	 */
	protected <R extends MCDBContainer> void chkMainList(
			MCList<R> mainDbc, MCMessageList m, MCController ctrl) {

		for (MCDBContainer mainRow : mainDbc) {
			chkMainRow(mainRow, m, ctrl);

		}
	}

	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * 引数 condの検索条件で、1件以上データが取得された場合、<br>
	 * そのメッセージを引数のMCMessageListに格納します。<br>
	 * サブオペレーションのコントローラごとにメッセージを変更したい場合、<br>
	 * このクラスをオーバーライドしてください。
	 * 
	 * @return 検索条件を含む更新対象テーブルのＤＢコンテナ
	 */
	protected void chkMainRow(MCDBContainer cond, MCMessageList m, MCController ctrl) {
		if (alreadyExists(cond)) {
			m.add(getMainErrMsg(cond));

		}
	}

	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * MAINサブオペレーショングループのエラーメッセージを返します。
	 * @param cond チェック対象のＤＢコンテナ
	 * @return 
	 */
	protected MCMessage getMainErrMsg(MCDBContainer cond) {
		return new MCMessage(cond, null, FXBAL0013, cond.tableName());
	}

	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * 更新対象の行のキーがすでに存在している場合trueを返します。<br>
	 * 引数columnが渡された場合は、そこにあるカラムのデータで<b>UNIQUE制約と同様な</b>のチェックを行います。
	 * 
	 * @return すでに存在している場合true
	 */
	protected boolean alreadyExists(MCDBContainer r, String... column) {
		if (column == null || column.length <= 0) {
			return alreadyExistKey(r);
		}
		else {
			return alreadyExistUnique(r, column);
		}

	}
	
	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * 更新対象の行のキーがすでに存在している場合trueを返します。<br>
	 * 
	 * @return 更新対象の行のキーがすでに存在している場合true
	 */
	protected boolean alreadyExistKey(MCDBContainer r) {
		MCDBContainer upd = getUpdDbcRow(r.getParamRowIndex());
		MCDBContainer c = (MCDBContainer) r.createInstance();
		
		//キー追加行でなければ重複なしと判断する
		if(r.isStatusCreate() || isKeyUpd(upd)){
			sql().mainQuery().select(FXUCL_MCDbUtil.COUNT_COL).from(upd).where(createWhere(r, r.getKeyColumn())).executeQuery(r, c);
			MCNumber n = c.getNumber(FXUCL_MCDbUtil.COUNT_NAME);
			return n.gt(0);
		}
		
		return false;
	}
	
	/**
	 * MAIN サブオペレーショングループの処理
	 * <p>
	 * 引数column の値が重複する可能性がある場合trueを返します。<br>
	 * ただし、引数column の値がすべてnullの場合はfalseを返します。
	 * 
	 * @return すでに存在している場合true
	 */
	protected boolean alreadyExistUnique(MCDBContainer r, String... column) {
		MCDBContainer upd = getUpdDbcRow(r.getParamRowIndex());
		
		//削除行であれば重複なしと判断する
		if(r.isStatusDelete()){
			return false;
		}			
		
		// 値がすべてnullの場合は重複なしと判断する
		boolean isAllNull = true;
		for (String cp : column) {
			if (!isNull(r.getValue(cp))) {
				isAllNull = false;
				break;
			}
		}
		if (isAllNull) {
			return false;
		}
		
		String[] kc = r.getKeyColumn();
		MCDBContainer chk = (MCDBContainer) r.createInstance();
		int i = sql().mainQuery().select(r.getKeyColumn$()).from(chk).where(createWhere(r, column)).executeQuery(r, chk);
		
		//0件の場合
		if(i <= 0){
			return false;
		}
		//1件の場合
		else{
			//新規の場合
			if(r.isStatusCreate()){
				return true;
			}
			
			//変更の場合
			else{
				//変更前のキー項目と同じ値が取得されていれば重複なし
				return !isColSame(upd, FXBAL_MCRLUtil.getBeforeKeyColumns(kc), chk, kc);
						
			}
		}
	}	
	/**
	 * OTHER サブオペレーショングループの処理
	 * <p>
	 * 削除（キー変更含む）行が他テーブルで使用されている場合、そのメッセージを引数のMCMessageListに格納します。
	 */
	protected void chkOtherTable(MCMessageList m) {
		
		chkOtherTableSameModule(m);
		chkOtherTableDiffModule(m);
	}
	
	/**
	 * 実装仕様書で定義されたOTHERサブオペレーショングループのdbコンテナでチェックを行います。
	 */
	protected void chkOtherTableSameModule(MCMessageList m) {

		List<MCController> os = getSubOpes(OTHER);
		if (os != null) {
			for (int i = 0; i < os.size(); i++) {
				MCController ctrl = os.get(i);

				if (ctrl instanceof MCDBSubOperation<?>) {
					if (((MCDBSubOperation<?>) ctrl).dbc() instanceof MCDBContainer) {
						@SuppressWarnings("unchecked")
						MCList<MCDBContainer> dbc = (MCList<MCDBContainer>) ((MCDBSubOperation<?>) ctrl).up1;

						chkOtherList(dbc, m, ctrl);
					}
				}
			}
		}
	}
	/**
	 * リソースで定義されたOTHERサブオペレーショングループのdbコンテナでチェックを行います。
	 * <p>
	 * キーは以下の通りです。
	 * ＤＢコンテナ指定：<br>
	 * [moduleID].[LogicID].[OperationID].OTHER.[moduleID].[任意の文字列].dbc = ＤＢコンテナ名
	 * カラムマッピング指定：<br>
	 * [moduleID].[LogicID].[OperationID].OTHER.[moduleID].[任意の文字列].map = dest1:src1,dest2:src2,... 
	 */
	protected void chkOtherTableDiffModule(MCMessageList m) {

		String key = MCConst.createKey(getOperationInfo().moduleId, getOperationInfo().logicId, getOperationID(), OTHER);
		for(String mod : MCConst.app.findPattern(MCConst.createKey(key, "*"))) {
			String[] smod = MCConst.splitKey(mod);
			String modId = smod[smod.length - 1];
			for(String u : MCConst.app.findPattern(MCConst.createKey(mod, "*"))) {
				String dbckey = MCConst.createKey(u, DBC_KEY);
				String dbcStr = MCConst.app.getString(dbckey);
				
				if (dbcStr != null) {
					String mapkey = MCConst.createKey(u, MAP_KEY);
					String[] maps = MCConst.app.getStringArray(mapkey);
					if(maps != null) {
						String dbcp ="mcframe.server" + modId.toUpperCase() + ".db." + dbcStr;
						String dbcr = dbcp + "_R";
	
						@SuppressWarnings("unchecked")
						Class<MCDBContainer> cr = (Class<MCDBContainer>) MCFactory.getClass(MCDBContainer.class, dbcr);
						MCList<MCDBContainer> dbc = MCList.create(cr);
						for (MCDBContainer src : getUpdUp1()) {
							MCDBContainer dest = dbc.createRow();
							for(String map : maps) {
								String[] destSrc = map.split(":", 2);
								String destc = destSrc[0];
								String srcc = destSrc[1];
								if (isNull(destc) || isNull(srcc)) {
									throw new MCAppException(FXBAL0026, mapkey, map);
								}
								
								dest.setValue(destc, src.getValue(srcc));
							}
							dest.setAttributes(src);
							dbc.add(dest);
						}
						chkOtherList(dbc, m, null);
					}
				}
			}
		}
	}
	
	private static final String DBC_KEY = "dbc";
	private static final String MAP_KEY = "map";
	
	
	/**
	 * OTHER サブオペレーショングループの処理
	 * <p>
	 * 削除（キー変更含む）行のキーが使用されている場合、そのメッセージを引数のMCMessageListに格納します。
	 * <p>
	 */
	protected <R extends MCDBContainer> void chkOtherList(
			MCList<R> list, MCMessageList m, MCController ctrl) {

		MCList<R> d = getChkOtherList(list);

		for (MCDBContainer r : d) {
			chkOtherRow(r, m, ctrl);

		}
	}
	
	/**
	 * OTHERサブオペレーショングループチェック対象のRowを持つListを返します。
	 */
	protected <R extends MCDBContainer> MCList<R> getChkOtherList(MCList<R> list){
		return (MCList<R>) list.subList(createDeleteKeyRowMatcher(list.createRow()));
	}
	
	/**
	 * OTHER サブオペレーショングループの処理
	 * <p>
	 * 引数 condの検索条件で、1件以上データが取得された場合、<br>
	 * そのメッセージを引数のMCMessageListに格納します。<br>
	 * サブオペレーションのコントローラごとにメッセージを変更したい場合、<br>
	 * このクラスをオーバーライドしてください。
	 * 
	 * @param cond 検索条件を含むキー利用テーブルのＤＢコンテナ
	 * @param m メッセージを格納するためのMCMessageList
	 * @param ctrl コントローラ
	 */
	protected void chkOtherRow(MCDBContainer cond, MCMessageList m, MCController ctrl) {
		if (alreadyUsed(cond)) {
			m.add(getOtherErrMsg(cond));

		}
	}

	/**
	 * OTHER サブオペレーショングループの処理
	 * <p>
	 * OTHERサブオペレーショングループのエラーメッセージを返します。
	 * @param cond チェック対象のＤＢコンテナ
	 * @return 
	 */
	protected MCMessage getOtherErrMsg(MCDBContainer cond) {
		return new MCMessage(cond, null, FXBAL0014, cond.tableName());
	}

	/**
	 * OTHER サブオペレーショングループの処理
	 * <p>
	 * 更新対象の行のキーがすでに使用されている場合trueを返します。<br>
	 * 
	 * @param r 検索条件を含むキー利用テーブルのＤＢコンテナ
	 */
	protected boolean alreadyUsed(MCDBContainer r) {

		MCDBContainer c = (MCDBContainer) r.createInstance();
		sql().mainQuery().select(FXUCL_MCDbUtil.COUNT_COL).from(r).where(allWhere(r)).executeQuery(r, c);
		MCNumber n = c.getNumber(FXUCL_MCDbUtil.COUNT_NAME);

		return n.gt(0);

	}

	/** defCheck用Where句始まり */
	protected void appendWhereSt(StringBuilder sb) {
		sb.append(AND).append(PAREN_L);
	}

	/** defCheck用Where句途中(nullの場合はtrue) */
	protected void appendNullWhere(StringBuilder sb, String tableAlias, String col,
			String bindName) {
		sb.append(PAREN_L).append(tableAlias).append(TABLE_COLUMN_DELIMITERER)
				.append(col).append(SP).append(MCDBExpr.ISNULL).append(SP).append(AND)
				.append(BIND_MK).append(bindName).append(SP).append(MCDBExpr.ISNULL)
				.append(PAREN_R).append(OR);
	}

	/** defCheck用Where句終わり */
	protected void appendWhereEnd(StringBuilder sb, String tableAlias, String col,
			String bindName) {
		sb.append(tableAlias).append(TABLE_COLUMN_DELIMITERER).append(col).append(SP)
				.append(MCDBExpr.EQ).append(BIND_MK).append(bindName).append(PAREN_R)
				.append(LF);
	}

	// ////////////////////////////////////////////////////////////////
	// /更新///////////////////////////////////////////////////////////
	// ////////////////////////////////////////////////////////////////

	/** UPDATE サブオペレーショングループ による更新を行います。 */
	@SuppressWarnings("unchecked")
	protected void doIt() {
		for (MCController ctrl : getSubOpes(UPDATE)) {
			if (ctrl instanceof MCDBSubOperation) {
				MCDBContainer dbc = ((MCDBSubOperation<?>) ctrl).dbc();
				if (dbc instanceof MCDBContainer) {
					dbUpdate( ((MCDBSubOperation<?>) ctrl).builder(),  (MCList<MCDBContainer>) ((MCDBSubOperation<?>) ctrl).up1);
				}
			}
			else if (ctrl instanceof MCOperation) {
				((MCOperation) ctrl).exec();
			}

		}
	}

	/**
	 * マスタの更新を行います。
	 * <p>
	 * 更新前処理、更新、更新後処理 を行います。
	 * 
	 * @param dbc
	 */
	protected <R extends MCDBContainer> void dbUpdate(MCQueryApiBuilder builder, MCList<R> list) {

		beforeUpdate(list);
		throwMsgList();

		MCList<R> u = list.clone();
		MCList<R>su = keyUpdToInsAndDel(u);

		updDbcCustomize(builder, su);
		updateMain(builder, su);

		afterUpdate(list);
		throwMsgList();
	}

	@SuppressWarnings("unchecked")
	protected <R extends MCDBContainer> void dbLockDelUpdInsByStatusCheck(MCQueryApiBuilder builder,
			MCList<R> list, boolean updChk) {
		MCList<R> ins = list.subList(Status.CREATE);
		MCList<R> upd = list.subList(Status.MODIFY);
		MCList<R> del = list.subList(Status.DELETE);

		if (!isSame(list.size(), sum(ins.size(), upd.size(), del.size()))) {
			// try catchされることを考慮するとインスタンスそのものを操作してはいけない
			MCList<R> c = list.clone();
			c.removeAll(ins);
			c.removeAll(upd);
			c.removeAll(del);
			throw new MCAppException(c.get(0), null, FXUDL0004, c.get(0));
		}

		// Delete処理
		MCList<R> delLocked = del.createInstance();
		MCList<R>delNotLocked = del.createInstance();
		if (updChk) {
			dbSortLockDivide(createSqlId(LOGIC_ID, builder.getBaseDbc(), "S01"), builder, del, delLocked, delNotLocked);
		}
		else {
			dbSortLockDivideNoCheck(createSqlId(LOGIC_ID, builder.getBaseDbc(), "S02"), builder, del, delLocked, delNotLocked);
		}
		// 削除できなかった行がキー変更元行の場合はエラーとする
		checkDelExclusion(delNotLocked, (R)builder.getBaseDbc(), (MCList<R>)getUpdUp1());
		dbDeleteKey(createSqlId(LOGIC_ID, builder.getBaseDbc(), "D01"), delLocked, builder);

		// Update処理
		dbSortLockUpdEx(builder, upd, updChk);

		// Insert処理
		ins.sort(builder.getBaseDbc().getKeyColumn());
		dbInsertEx(createSqlId(LOGIC_ID, builder.getBaseDbc(), "I01"), ins, builder, FXUDL0005);

	}
	
	protected <R extends MCDBContainer> void dbSortLockUpdEx(MCQueryApiBuilder builder,
			MCList<R> upd, boolean updChk) {

		try {
			if (updChk) {
				dbSortLockUpd(createSqlId(LOGIC_ID, builder.getBaseDbc(), "S03"), upd, builder);
			}
			else {
				dbSortLockUpdNoCheck(createSqlId(LOGIC_ID, builder.getBaseDbc(), "S04"), upd, builder);
			}
		}
		catch (MCException ex) {
			if (isDupValOnIndex(ex)) {
				MCLog.write(ex);
				throw new MCAppException(FXBAL0021);
			}
			else {
				// それ以外はそのままthrow
				throw ex;
			}
		}
	}

	/**
	 * 削除（キー変更含む）時の排他エラーを設定します。<p>
	 * <li>通常の削除処理の場合はエラーとはしない
	 * <li>{@link #keyUpdToInsAndDel(FX_DBCBase_L)}で分割されてできた行の場合はエラーにする
	 * @param delNotLocked ロックできなかった削除対象行リスト
	 * @param dbc ＤＢコンテナ
	 * @param list 更新対象のコンテナ
	 */
	protected <R extends MCDBContainer> void checkDelExclusion(
			MCList<R> delNotLocked, R dbc, MCList<R> list) {

		@SuppressWarnings("unchecked")
		R proto = (R) dbc.createInstance();
		MCList<R> ku = (MCList<R>) list.subList(createKeyUpdRowMatcher(proto));

		String[] kc = FXBAL_MCRLUtil.getBeforeKeyColumns(dbc.getKeyColumn());
		delNotLocked.sort(kc);
		ku.sort(kc);

		int i = 0;
		for (R nlr : delNotLocked) {
			if (nlr.getBooleanNE(_KEY_SPLIT_ROW_FLG_COLUMN)) {

				// causeRowをサーバで取り出された場合に分割前のrowが取得できるようにするための処理
				for (; i < ku.size(); i++) {
					R k = ku.get(i);
					if (isSame(k.getParamRowIndex(), nlr.getParamRowIndex())) {
						getMsgList().add(new MCMessage(k, null, FXBAL0009));
					}
				}
			}
			else {
				MCMessagePool.add(new MCMessage(nlr, null, FXUDL0006, nlr));
			}
		}
	}

	/**
	 * 更新直前の処理です。
	 * <p>
	 * 引数のクエリAPIビルダーで更新処理が行われます。<br>
	 * 
	 * @param builder クエリAPIビルダー
	 * @param list キー変更行がinsertとdeleteの2行に分割されて格納されている上り電文
	 */
	protected <R extends MCDBContainer> void updDbcCustomize(
			MCQueryApiBuilder builder, MCList<R> list) {
		// defaultでは何もしない

	}

	/**
	 * 引数のＤＢコンテナで更新します。
	 * 
	 * @param builder クエリAPIビルダー
	 * @param list キー変更行がinsertとdeleteの2行に分割されて格納されているＤＢコンテナ
	 */
	protected <R extends MCDBContainer> void updateMain(MCQueryApiBuilder builder,
			MCList<R> list) {
		dbLockDelUpdInsByStatusCheck(builder, list, true);

	}

	/**
	 * 更新前処理を追加できます。
	 * <p>
	 * このメソッドの直後にthrowMsgList()が呼ばれます。<br>
	 * 引数のＤＢＣでＳＱＬ文をカスタマイズはできません。<br>
	 * ＳＱＬ文のカスタマイズはupdDbcCustomize()で行ってください。<br>
	 * 
	 * @param dbc 更新対象行を含むＤＢコンテナ
	 * @see #updDbcCustomize(FX_DBCBase_L)
	 * @see #throwMsgList()
	 */
	protected <R extends MCDBContainer> void beforeUpdate(
			MCList<R> dbc) {
	}

	/**
	 * 更新後処理を追加できます。
	 * <p>
	 * このメソッドの直後にthrowMsgList()が呼ばれます。
	 * 
	 * @param dbc 更新対象行を含むＤＢコンテナ
	 * @see #throwMsgList()
	 */
	protected <R extends MCDBContainer> void afterUpdate(
			MCList<R> dbc) {
		//何もしない
	}

	/**
	 * キー変更行を{@link #keyUpdToInsAndDel(FX_DBCBase_L)}で分割する際、分割後のrowに追加されるＦＬＧ型のカラム名
	 */
	protected static String _KEY_SPLIT_ROW_FLG_COLUMN = "___split_mod_key_row_flg_column_";

	/**キー更新行を新規行と削除行に分けたリストを返します。<p>
	 * 分けられた行には {@link #_KEY_SPLIT_ROW_FLG_COLUMN}変数の保持する文字列の名称でカラムが追加され、trueが設定されます。
	 */
	protected <R extends MCDBContainer> MCList<R> keyUpdToInsAndDel(
			MCList<R> mainDbc) {
		MCList<R> d = (MCList<R>) mainDbc.createInstance();

		for (R r : mainDbc) {
			if (isKeyUpd(r)) {
				R ir = (R) r.clone();
				ir.addBooleanColumn(_KEY_SPLIT_ROW_FLG_COLUMN, true);
				ir.setStatus(MCRow.CREATE);
				d.add(ir);
				R ur = (R) r.clone();
				ur.addBooleanColumn(_KEY_SPLIT_ROW_FLG_COLUMN, true);
				ur.setStatus(MCRow.DELETE);
				for (String c : ur.getKeyColumn()) {
					ur.setValue(c, ur.getValue(FXBAL_MCRLUtil.getBeforeKeyColumn(c)));
				}
				d.add(ur);

			}
			else {
				d.add(r);

			}

		}
		return d;

	}

	// ////////////////////////////////////////////////////////////////
	// /下り///////////////////////////////////////////////////////////
	// ////////////////////////////////////////////////////////////////
	// 下り項目設定
	protected void down() {
		mapDownContainers(UPDATE);
	}

	// ////////////////////////////////////////////////////////////////
	// /その他/////////////////////////////////////////////////////////
	// ////////////////////////////////////////////////////////////////

	/**
	 * 新規（キー変更含む）のrowを返すMCRowMathcerを返します。
	 */
	protected <R extends MCDBContainer> MCRowMatcher<R> createCreateKeyRowMatcher(R row) {
		return new CreateKeyRowMatcher<R>();
	}

	protected CreateKeyRowMatcher<MCDBContainer> _CreateKeyRowMatcher;

	public class CreateKeyRowMatcher<R extends MCDBContainer> implements MCRowMatcher<R> {

		public boolean match(R row) {
			MCDBContainer mr = getUpdDbcRow(row.getParamRowIndex());

			if (mr.isStatusCreate()) {
				return true;
			}
			if (isKeyUpd(mr)) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	/**
	 * 削除（キー変更含む）のrowを返すMCRowMathcerを返します。
	 */
	protected <R extends MCDBContainer> MCRowMatcher<R> createDeleteKeyRowMatcher(R row) {
		return new DeleteKeyRowMatcher<R>();
	}

	protected DeleteKeyRowMatcher<MCDBContainer> _DeleteKeyRowMatcher;

	public class DeleteKeyRowMatcher<R extends MCDBContainer> implements MCRowMatcher<R> {

		public boolean match(R row) {

			MCDBContainer mr = getUpdDbcRow(row.getParamRowIndex());

			if (mr.isStatusDelete()) {
				return true;
			}
			if (isKeyUpd(mr)) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	/**
	 * キー変更のない登録対象のrowを返すMCRowMathcerを返します。
	 */
	protected NmrlModifyRowMatcher<MCDBContainer> createNmrlModifyRowMatcher() {
		if (_NmrlModifyRowMatcher == null) {
			_NmrlModifyRowMatcher = new NmrlModifyRowMatcher<MCDBContainer>();
		}
		return _NmrlModifyRowMatcher;
	}

	protected NmrlModifyRowMatcher<MCDBContainer> _NmrlModifyRowMatcher;

	public class NmrlModifyRowMatcher<R extends MCDBContainer> implements
			MCRowMatcher<R> {

		public boolean match(R row) {
			MCDBContainer r = getUpdDbcRow(row.getParamRowIndex());

			return !isKeyDiffered(r);

		}
	}

	/**
	 * DELETE,CREATEステータス もしくは変更前と変更後のキーが同じMODIFYのrowを返すMCRowMathcerを返します。
	 * <p>
	 */
	protected <R extends MCDBContainer> MCRowMatcher<R> createNrmlUpdRowMatcher(R row) {
		return new NrmlUpdRowMatcher<R>();
	}

	public class NrmlUpdRowMatcher<R extends MCDBContainer> implements MCRowMatcher<R> {

		public boolean match(R row) {
			MCDBContainer r = getUpdDbcRow(row.getParamRowIndex());

			if (r.isStatusCreate()) {
				return true;
			}
			if (r.isStatusDelete()) {
				return true;
			}
			if (r.isStatusModify() && !isKeyDiffered(r)) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	/**
	 * キー変更のあるMODIFYのrowを返すMCRowMathcerを返します。
	 */
	protected <R extends MCDBContainer> MCRowMatcher<R> createKeyUpdRowMatcher(R row) {
		return new KeyUpdRowMatcher<R>();
	}

	protected KeyUpdRowMatcher<MCDBContainer> _KeyUpdRowMatcher;

	public class KeyUpdRowMatcher<R extends MCDBContainer> implements MCRowMatcher<R> {

		public boolean match(R row) {
			MCDBContainer r = getUpdDbcRow(row.getParamRowIndex());

			return isKeyUpd(r);

		}
	}

	/** キーの変更がある場合trueを返します。 */
	protected boolean isKeyUpd(MCDBContainer r) {
		return r.isStatusModify() && isKeyDiffered(r);

	}

	/** 変更前キーを保持するカラムの値と変更後キーを保持するカラムの値が異なる場合trueを返します。 */
	protected boolean isKeyDiffered(MCDBContainer r) {
		String[] cols = r.getKeyColumn();
		return !isColSame(r, FXBAL_MCRLUtil.getBeforeKeyColumns(cols), r, cols);

	}

}
