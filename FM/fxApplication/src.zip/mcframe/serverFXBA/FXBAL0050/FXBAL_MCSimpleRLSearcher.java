package mcframe.serverFXBA.FXBAL0050;

import mcframe.commonCore.annotation.EI;

@EI
public abstract class FXBAL_MCSimpleRLSearcher extends FXBAL_MCSimpleRLSearcher_FW {
}
