package mcframe.serverFXBA.FXBAL0050;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.notice.MCLog;
import mcframe.serverCore.queryapi.MCForeignInfo;
import mcframe.serverCore.logic.MCController;
import mcframe.serverCore.logic.MCDBSubOperation;
import mcframe.serverCore.logic.MCOperation;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import mcframe.serverFXBA.FXBAL0020.FXBAL_MCSimpleSearcher;
import mcframe.serverFXBA.FXBAL0060.FXBAL_MCRLUtil;

public abstract class FXBAL_MCSimpleRLSearcher_FW extends FXBAL_MCSimpleSearcher {
	
	protected MCController _ctrl;
	/**現在処理中のコントローラを返す。*/
	protected MCController getCurrentController(){
		return _ctrl;
	}
	// 連携ロジック実行
	@Override
	protected void doIt() {

		for (MCController ctrl : getSubOpes(SELECT)) {
			if (ctrl instanceof MCDBSubOperation) {
				_ctrl = ctrl;
				
				MCRow cond = getCond(ctrl);

				MCQueryApiBuilder builder =  ((MCDBSubOperation<?>) ctrl).builder();
				@SuppressWarnings("unchecked")
				MCList<MCDBContainer> rslt = (MCList<MCDBContainer>) ((MCDBSubOperation<?>) ctrl).down(0);

				dbSelect(builder, cond, rslt, ctrl);

			}
			else if (ctrl instanceof MCOperation) {
				((MCOperation) ctrl).exec();
			}
		}
	}

	/**検索を中断する場合true*/
	protected boolean _canceled;

	/**
	 * 検索を中断するかしないかを設定します。<p>
	 * @param b 検索しない場合trueを設定してください。
	 */
	protected void setCanceled(boolean b) {
		MCLog.write(FXBAL0011, b);
		_canceled = b;
	}

	protected boolean getCanceled() {
		return _canceled;
	}

	/** 検索条件のRow を取得します。<p>
	 *  上り電文のRow を返します。
	 */
	protected MCRow getCond(MCController ctrl) {
		MCContainer c = up(0);
		if (c instanceof MCRow) {
			return (MCRow) c;
		}
		return null;
	}
	
	/** 下り電文のMCListを取得します。
	 * 
	 */
	@SuppressWarnings("unchecked")
	protected MCList<MCRow> getDown(MCController ctrl) {
		MCContainer c = ctrl.down(0);
		if (c instanceof MCList){
			return (MCList<MCRow>)c;
		}
		return null;
		
	}
	
	/** 引数dbcで、引数condを条件にして検索処理を実行します。 */
	protected <R extends MCDBContainer> void dbSelect(
			MCQueryApiBuilder builder, MCRow cond, MCList<R> rslt, MCController ctrl) {

		setCanceled(false);
		condCustomize(cond);
		dbcCustomize(builder, rslt);

		if (!getCanceled()) {
			MCList<MCRow> binds = MCList.create(MCRow.class);
			binds.add(builder.getMergeBind());
			builder.buildSelect().executeQuery(cond, binds, rslt);
		}
		else {
			MCLog.write(FXBAL0017);

		}

		afterSelect(rslt);
	}

	/** 検索条件をカスタマイズします。 */
	protected void condCustomize(MCRow cond) {
		// defaultでは何もしません。
	}

	/** DBCをカスタマイズします。 */
	protected <R extends MCDBContainer> void dbcCustomize(MCQueryApiBuilder builder, MCList<R> rslt) {
		setSelectAndFrom(builder);
		setWhere(builder);
	}

	/** 検索後処理を追加します。 */
	protected <R extends MCDBContainer> void afterSelect(
			MCList<R> rslt) {
		// defaultでは何もしません。

	}
	
	/** 
	 * select,from句を設定します。<p>
	 * dbcの固定カラム名と一致する、下り電文のカラム名をselect句に設定します。<br>
	 * さらに、そのカラム名から結合情報が取得できる場合はFrom句に結合条件を追加します。<br>
	 */
	protected void setSelectAndFrom(
			MCQueryApiBuilder dbc) {
		MCContainer c = getDown(getCurrentController());

		if (c instanceof MCList) {
			@SuppressWarnings("unchecked")
			MCList<MCRow> downL = (MCList<MCRow>) c;

			String[] downC = downL.createRow().getConstColumnPathArray();
			FXBAL_MCRLUtil.setSelectAndFrom(dbc, downC, isForeignEQ());

		}
	}

	/** 結合を等価結合で設定したい場合trueを返すように実装してください。 */
	protected boolean isForeignEQ() {
		return false;
	}

	/** 
	 * 上り電文コンテナの項目名を使用し、where句を追加します。<p>
	 * 
	 * where句追加対象は、isAddWhereTypメソッドでtrueが返るデータ型の項目で、
	 * 演算子は getExprメソッドの戻り値に従います。<br>
	 * DBコンテナに対応する項目名が存在しない場合はwhere句を設定しません。<br>
	 * where句設定対象外の項目でも、結合先の項目の場合、JOIN句は追加されます。<br>
	 * @see #isAddWhereTyp(MCDataType typ)
	 * @see #getExpr(MCDataType typ)
	 */
	protected void setWhere(MCQueryApiBuilder builder) {
		MCRow upR = getCond(getCurrentController());

		if (upR != null) {

			String[] upC = upR.getConstColumnPathArray();
			MCDBContainer dbc = builder.getBaseDbc();

			for (int i = 0; i < upC.length; i++) {
				String bindCol = upC[i];
				if (FXBAL_MCRLUtil.isLinkedToTableColumn(dbc, bindCol)) {
					/* 外部参照先の項目の場合は結合します。 */
					MCForeignInfo f = dbc.getForeignInfoByColumn(bindCol);
					if (f != null) {
						if (isForeignEQ()) {
							builder.activeForeignEQ(f);
						}
						else {
							builder.activeForeign(f);
						}
					}

					/* String,Number以外の項目はwhere句を設定しません。 */
					MCDataType typ = dbc.getMeta(bindCol).type();
					if (!isAddWhereTyp(typ)) {
						continue;
					}
					
					/* WHERE句を取得します。 */
					MCPermColumn col = dbc.getColumn$(bindCol);
					MCPredicate where = getWhere(typ, col, bindCol);

					/* WHERE句を設定します。 */
					builder.addWhereWithCutOffAnd(where);
				}
			}
		}
	}

	/** 型に対応するWhere句を返します。*/
	protected MCPredicate getWhere(MCDataType typ, MCPermColumn col, String bindCol) {
		if (MCDataType.STRING.equals(typ)) {
			return ((MCStringExpr)col).like(bind(bindCol));
		}
		return MCQueryApiBuilder.makeEq(col, bind(bindCol));

	}

	/**WHERE句を追加する型の場合trueを返します。*/
	protected boolean isAddWhereTyp(MCDataType typ) {

		return MCDataType.STRING.equals(typ) || MCDataType.NUMBER.equals(typ);
	}
}
