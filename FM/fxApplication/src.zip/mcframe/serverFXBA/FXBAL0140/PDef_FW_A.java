package mcframe.serverFXBA.FXBAL0140;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cn;

/**
 * [FXBAL0140]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FX.FXBAL0140.Srch01.UP.BLOCK0")){
			return FX_FXBAL0140_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch01.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.UP.BLOCK0")){
			return FX_FXBAL0140_Srch02_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch02_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.DOWN.BLOCK1")){
			return FX_FXBAL0140_Srch02_DOWN_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.DOWN.BLOCK2")){
			return FX_FXBAL0140_Srch02_DOWN_BLOCK2();
		}
		else if (id.equals("FX.FXBAL0140.Srch03.UP.BLOCK0")){
			return FX_FXBAL0140_Srch03_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch03.UP.BLOCK1")){
			return FX_FXBAL0140_Srch03_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch03.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch03_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch13.UP.BLOCK0")){
			return FX_FXBAL0140_Srch13_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch13.UP.BLOCK1")){
			return FX_FXBAL0140_Srch13_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch13.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch13_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Upd01.UP.BLOCK0")){
			return FX_FXBAL0140_Upd01_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Upd01.UP.BLOCK1")){
			return FX_FXBAL0140_Upd01_UP_BLOCK1();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
					
	
	static final MCOperationInfo FX_FXBAL0140_Srch01_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch01", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch01_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid")
			}
			,
			MCBlockDef.create("Info")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch01_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid"),
				MCItemDef.create("table", true, "table"),
				MCItemDef.create("name", "name")
			}
			,
			MCBlockDef.create("List")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Srch02_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch02", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch02_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid"),
				MCItemDef.create("table", true, "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch02_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid"),
				MCItemDef.create("table", true, "table"),
				MCItemDef.create("upd", true, "upd"),
				MCItemDef.create("duplicate", true, "duplicate"),
				MCItemDef.create("cell", "cell")
			}
			,
			MCBlockDef.create("Info")
		);
	}
	public static MCContainerDef FX_FXBAL0140_Srch02_DOWN_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("id", true, "id"),
				MCItemDef.create("name", true, "name"),
				MCItemDef.create("key", true, "key"),
				MCItemDef.create("meta", "meta"),
				MCItemDef.create("type", "type"),
				MCItemDef.create("format", "format"),
				MCItemDef.create("mode", "mode"),
				MCItemDef.create("cond", true, "cond"),
				MCItemDef.create("opt", "opt")
			}
			,
			MCBlockDef.create("Def")
		);
	}
	public static MCContainerDef FX_FXBAL0140_Srch02_DOWN_BLOCK2() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("key", true, "key"),
				MCItemDef.create("val", "val")
			}
			,
			MCBlockDef.create("App")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Srch03_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch03", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch03_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid"),
				MCItemDef.create("table", true, "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}

	public static MCContainerDef FX_FXBAL0140_Srch03_UP_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("id", true, "id"),
				MCItemDef.create("type", true, "type"),
				MCItemDef.create("opt", "opt"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Cond")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch03_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("rowno", true, "rowno"),
				MCItemDef.create("id", true, "id"),
				MCItemDef.create("type", true, "type"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Rslt")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Srch13_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch13", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch13_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch13",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid"),
				MCItemDef.create("table", true, "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}

	public static MCContainerDef FX_FXBAL0140_Srch13_UP_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch13",
			new MCItemDef[]{
				MCItemDef.create("id", true, "id"),
				MCItemDef.create("type", true, "type"),
				MCItemDef.create("opt", "opt"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Cond")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch13_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch13",
			new MCItemDef[]{
				MCItemDef.create("BINARY", true, "BINARY")
			}
			,
			MCBlockDef.create("Rslt")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Upd01_INFO = new MCOperationInfo("FX", "FXBAL0140", "Upd01", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Upd01_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("moduleid", true, "moduleid"),
				MCItemDef.create("screenid", true, "screenid"),
				MCItemDef.create("table", true, "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}

	public static MCContainerDef FX_FXBAL0140_Upd01_UP_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0140", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("rowno", true, "rowno"),
				MCItemDef.create("id", true, "id"),
				MCItemDef.create("type", true, "type"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Rslt")
		);
	}


	//FMCB DEF_CLASSES END
}

