package mcframe.serverFXBA.FXBAL0140;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.commonCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"App"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class AppR_FW_A extends MCConstRow {

	/**
	 *  キー.<p>
	 *
	 */
	public static final String $key = "key";
	/**
	 *  値.<p>
	 *
	 */
	public static final String $val = "val";


	public static final MCMeta key_META = createStringMeta($key);
	public static final MCMeta val_META = createStringMeta($val);

	protected static final ConstMetaList<AppR> constMetas = new ConstMetaList<AppR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			key_META,
			val_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public List<String> getKeys(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.getKeyList(aGroup);
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected AppR_FW_A(ConstMetaList<? extends AppR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public AppR clone() {
		return (AppR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public AppR createInstance() {
		return (AppR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public AppR getValues(String... names) {
		return (AppR) super.getValues(names);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	protected void fireValueChanged(String column,
							Comparable<?> newvalue, Comparable<?> oldvalue) {
	}


	/**
	 *  キー.<p>
	 *
	 */
	public String key() {
		return getConstString(offset + 0, $key);
	}

	/**
	 *  キー.<p>
	 *
	 */
	public void key(String value) {
		setConstString(offset + 0, $key, value);
	}


	/**
	 *  値.<p>
	 *
	 */
	public String val() {
		return getConstString(offset + 1, $val);
	}

	/**
	 *  値.<p>
	 *
	 */
	public void val(String value) {
		setConstString(offset + 1, $val, value);
	}


	public String getString(String name) {
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($val.equalsIgnoreCase(name)) {
			return val();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($val.equalsIgnoreCase(name)) {
			return val();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($val.equalsIgnoreCase(name)) {
			val(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($val.equalsIgnoreCase(name)) {
			val(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

