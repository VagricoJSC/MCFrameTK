package mcframe.serverFXBA.FXBAL0140;

import java.util.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.param.*;
import mcframe.serverCore.logic.*;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
//FMCB IMPORT START
//FMCB IMPORT END
import static mcframe.serverCore.logic.MCLogicUtil.*;

/**
 * "FXBAL0140"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXBAL0140_FW_A extends mcframe.serverFXBA.FXBAL0010.FXBAL_MCLogicBase {
	/** 
	 * モジュールID<p>
	 *
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * ロジックID<p>
	 *
	 * ロジックはモジュールIDとロジックIDで一意に特定できます。<br>
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getLogicID()}を使用してください。
	 */
	public static final String LOGIC_ID = "FXBAL0140";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** ロジックIDを取得します。 */
	public String getLogicID(){ return LOGIC_ID; }

	//FMCB CTRL_FIELD_METHOD START

	protected FXBAL0140.Srch01 aSrch01;

	protected void initSrch01() {
		this.info = PDef.FX_FXBAL0140_Srch01_INFO;
		this.aSrch01 = ((FXBAL0140)this).new Srch01();
	}

	public static FXBAL0140.Srch01 crtSrch01() {
		FXBAL0140 lgc = new FXBAL0140();
		lgc.initSrch01();
		return lgc.aSrch01;
	}

	protected void paramSrch01(MCParam p) {
		if (this.aSrch01 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch01.up0());
		p.addDownBlock(aSrch01.down0());
	}

	protected void doSrch01() {
		aSrch01.call();
	};

	/**
	 * InfoブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0140.InfoR createInfoR(){
		return mcframe.serverFXBA.FXBAL0140.InfoR.create();
	}

	/**
	 * ListブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0140.InfoR createListR(){
		return mcframe.serverFXBA.FXBAL0140.InfoR.create();
	}

	/**
	 * ListブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0140.InfoR> createListL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0140.InfoR.class);
	}
	protected FXBAL0140.Srch02 aSrch02;

	protected void initSrch02() {
		this.info = PDef.FX_FXBAL0140_Srch02_INFO;
		this.aSrch02 = ((FXBAL0140)this).new Srch02();
	}

	public static FXBAL0140.Srch02 crtSrch02() {
		FXBAL0140 lgc = new FXBAL0140();
		lgc.initSrch02();
		return lgc.aSrch02;
	}

	protected void paramSrch02(MCParam p) {
		if (this.aSrch02 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch02.up0());
		p.addDownBlock(aSrch02.down0());
		p.addDownBlock(aSrch02.down1());
		p.addDownBlock(aSrch02.down2());
	}

	protected void doSrch02() {
		aSrch02.call();
	};

	/**
	 * DefブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0140.DefR createDefR(){
		return mcframe.serverFXBA.FXBAL0140.DefR.create();
	}

	/**
	 * DefブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0140.DefR> createDefL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0140.DefR.class);
	}

	/**
	 * AppブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0140.AppR createAppR(){
		return mcframe.serverFXBA.FXBAL0140.AppR.create();
	}

	/**
	 * AppブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0140.AppR> createAppL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0140.AppR.class);
	}
	protected FXBAL0140.Srch03 aSrch03;

	protected void initSrch03() {
		this.info = PDef.FX_FXBAL0140_Srch03_INFO;
		this.aSrch03 = ((FXBAL0140)this).new Srch03();
	}

	public static FXBAL0140.Srch03 crtSrch03() {
		FXBAL0140 lgc = new FXBAL0140();
		lgc.initSrch03();
		return lgc.aSrch03;
	}

	protected void paramSrch03(MCParam p) {
		if (this.aSrch03 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch03.up0());
		p.addUpBlock(aSrch03.up1());
		p.addDownBlock(aSrch03.down0());
	}

	protected void doSrch03() {
		aSrch03.call();
	};

	/**
	 * CondブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0140.CondR createCondR(){
		return mcframe.serverFXBA.FXBAL0140.CondR.create();
	}

	/**
	 * CondブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0140.CondR> createCondL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0140.CondR.class);
	}

	/**
	 * RsltブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0140.RsltR createRsltR(){
		return mcframe.serverFXBA.FXBAL0140.RsltR.create();
	}

	/**
	 * RsltブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> createRsltL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);
	}
	protected FXBAL0140.Srch13 aSrch13;

	protected void initSrch13() {
		this.info = PDef.FX_FXBAL0140_Srch13_INFO;
		this.aSrch13 = ((FXBAL0140)this).new Srch13();
	}

	public static FXBAL0140.Srch13 crtSrch13() {
		FXBAL0140 lgc = new FXBAL0140();
		lgc.initSrch13();
		return lgc.aSrch13;
	}

	protected void paramSrch13(MCParam p) {
		if (this.aSrch13 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch13.up0());
		p.addUpBlock(aSrch13.up1());
		p.addDownBlock(aSrch13.down0());
	}

	protected void doSrch13() {
		aSrch13.call();
	};
	protected FXBAL0140.Upd01 aUpd01;

	protected void initUpd01() {
		this.info = PDef.FX_FXBAL0140_Upd01_INFO;
		this.aUpd01 = ((FXBAL0140)this).new Upd01();
	}

	public static FXBAL0140.Upd01 crtUpd01() {
		FXBAL0140 lgc = new FXBAL0140();
		lgc.initUpd01();
		return lgc.aUpd01;
	}

	protected void paramUpd01(MCParam p) {
		if (this.aUpd01 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aUpd01.up0());
		p.addUpBlock(aUpd01.up1());
	}

	protected void doUpd01() {
		aUpd01.call();
	};

	//FMCB CTRL_FIELD_METHOD END

	//FMCB LOGIC_CONTROLLER START

	/**
	 * Srch01オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	abstract public class Srch01 extends MCOperation {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch01";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverFXBA.FXBAL0140.InfoR up0;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.InfoR> down0;
		
		
		// コンストラクタ
		protected Srch01() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverFXBA.FXBAL0140.InfoR.create();
			down0 = MCList.create(mcframe.serverFXBA.FXBAL0140.InfoR.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL0140)FXBAL0140_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
		}
		/**
		 * InfoブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR createInfoR(){
			return mcframe.serverFXBA.FXBAL0140.InfoR.create();
		}

		/**
		 * ListブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR createListR(){
			return mcframe.serverFXBA.FXBAL0140.InfoR.create();
		}

		/**
		 * ListブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.InfoR> createListL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.InfoR.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverFXBA.FXBAL0140.InfoR
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR up0() {
			return up0;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>table</td></tr>
		 * 	<tr><td><br></td><td>name</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.InfoR> down0() {
			return down0;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL0140)FXBAL0140_FW_A.this).info;
		}


	}
	/**
	 * Srch02オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	abstract public class Srch02 extends MCOperation {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch02";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverFXBA.FXBAL0140.InfoR up0;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverFXBA.FXBAL0140.InfoR down0;
		/** このオペレーションからの下り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.DefR> down1;
		/** このオペレーションからの下り電文パラメータの第2ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.AppR> down2;
		
		
		// コンストラクタ
		protected Srch02() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverFXBA.FXBAL0140.InfoR.create();
			down0 = mcframe.serverFXBA.FXBAL0140.InfoR.create();
			down1 = MCList.create(mcframe.serverFXBA.FXBAL0140.DefR.class);
			down2 = MCList.create(mcframe.serverFXBA.FXBAL0140.AppR.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			if (i == 1) return down1();
			if (i == 2) return down2();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL0140)FXBAL0140_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
			down1().clear();
			down2().clear();
		}
		/**
		 * InfoブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR createInfoR(){
			return mcframe.serverFXBA.FXBAL0140.InfoR.create();
		}

		/**
		 * DefブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.DefR createDefR(){
			return mcframe.serverFXBA.FXBAL0140.DefR.create();
		}

		/**
		 * DefブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.DefR> createDefL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.DefR.class);
		}

		/**
		 * AppブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.AppR createAppR(){
			return mcframe.serverFXBA.FXBAL0140.AppR.create();
		}

		/**
		 * AppブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.AppR> createAppL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.AppR.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>table</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverFXBA.FXBAL0140.InfoR
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR up0() {
			return up0;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>table</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>upd</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>duplicate</td></tr>
		 * 	<tr><td><br></td><td>cell</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverFXBA.FXBAL0140.InfoR
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR down0() {
			return down0;
		}

		/**
		 * 下り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>id</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>name</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>key</td></tr>
		 * 	<tr><td><br></td><td>meta</td></tr>
		 * 	<tr><td><br></td><td>type</td></tr>
		 * 	<tr><td><br></td><td>format</td></tr>
		 * 	<tr><td><br></td><td>mode</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>cond</td></tr>
		 * 	<tr><td><br></td><td>opt</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.DefR> down1() {
			return down1;
		}

		/**
		 * 下り電文の第2ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第2ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>key</td></tr>
		 * 	<tr><td><br></td><td>val</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.AppR> down2() {
			return down2;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL0140)FXBAL0140_FW_A.this).info;
		}


	}
	/**
	 * Srch03オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	abstract public class Srch03 extends MCOperation {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch03";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverFXBA.FXBAL0140.InfoR up0;
		/** このオペレーションへの上り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.CondR> up1;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.RsltR> down0;
		
		
		// コンストラクタ
		protected Srch03() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverFXBA.FXBAL0140.InfoR.create();
			up1 = MCList.create(mcframe.serverFXBA.FXBAL0140.CondR.class);
			down0 = MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			if (i == 1) return up1();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL0140)FXBAL0140_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
		}
		/**
		 * InfoブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR createInfoR(){
			return mcframe.serverFXBA.FXBAL0140.InfoR.create();
		}

		/**
		 * CondブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.CondR createCondR(){
			return mcframe.serverFXBA.FXBAL0140.CondR.create();
		}

		/**
		 * CondブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.CondR> createCondL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.CondR.class);
		}

		/**
		 * RsltブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.RsltR createRsltR(){
			return mcframe.serverFXBA.FXBAL0140.RsltR.create();
		}

		/**
		 * RsltブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> createRsltL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>table</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverFXBA.FXBAL0140.InfoR
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR up0() {
			return up0;
		}

		/**
		 * 上り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>id</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>type</td></tr>
		 * 	<tr><td><br></td><td>opt</td></tr>
		 * 	<tr><td><br></td><td>STRING</td></tr>
		 * 	<tr><td><br></td><td>NUMBER</td></tr>
		 * 	<tr><td><br></td><td>BOOLEAN</td></tr>
		 * 	<tr><td><br></td><td>DATE</td></tr>
		 * 	<tr><td><br></td><td>TIMESTAMP</td></tr>
		 * 	<tr><td><br></td><td>BINARY</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.CondR> up1() {
			return up1;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>rowno</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>id</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>type</td></tr>
		 * 	<tr><td><br></td><td>STRING</td></tr>
		 * 	<tr><td><br></td><td>NUMBER</td></tr>
		 * 	<tr><td><br></td><td>BOOLEAN</td></tr>
		 * 	<tr><td><br></td><td>DATE</td></tr>
		 * 	<tr><td><br></td><td>TIMESTAMP</td></tr>
		 * 	<tr><td><br></td><td>BINARY</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> down0() {
			return down0;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL0140)FXBAL0140_FW_A.this).info;
		}


	}
	/**
	 * Srch13オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	abstract public class Srch13 extends MCOperation {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch13";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverFXBA.FXBAL0140.InfoR up0;
		/** このオペレーションへの上り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.CondR> up1;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.RsltR> down0;
		
		
		// コンストラクタ
		protected Srch13() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverFXBA.FXBAL0140.InfoR.create();
			up1 = MCList.create(mcframe.serverFXBA.FXBAL0140.CondR.class);
			down0 = MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			if (i == 1) return up1();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL0140)FXBAL0140_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
		}
		/**
		 * InfoブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR createInfoR(){
			return mcframe.serverFXBA.FXBAL0140.InfoR.create();
		}

		/**
		 * CondブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.CondR createCondR(){
			return mcframe.serverFXBA.FXBAL0140.CondR.create();
		}

		/**
		 * CondブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.CondR> createCondL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.CondR.class);
		}

		/**
		 * RsltブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.RsltR createRsltR(){
			return mcframe.serverFXBA.FXBAL0140.RsltR.create();
		}

		/**
		 * RsltブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> createRsltL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>table</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverFXBA.FXBAL0140.InfoR
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR up0() {
			return up0;
		}

		/**
		 * 上り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>id</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>type</td></tr>
		 * 	<tr><td><br></td><td>opt</td></tr>
		 * 	<tr><td><br></td><td>STRING</td></tr>
		 * 	<tr><td><br></td><td>NUMBER</td></tr>
		 * 	<tr><td><br></td><td>BOOLEAN</td></tr>
		 * 	<tr><td><br></td><td>DATE</td></tr>
		 * 	<tr><td><br></td><td>TIMESTAMP</td></tr>
		 * 	<tr><td><br></td><td>BINARY</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.CondR> up1() {
			return up1;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>BINARY</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> down0() {
			return down0;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL0140)FXBAL0140_FW_A.this).info;
		}


	}
	/**
	 * Upd01オペレーション.<p>
	 *
	 */
	abstract public class Upd01 extends MCOperation {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Upd01";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverFXBA.FXBAL0140.InfoR up0;
		/** このオペレーションへの上り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0140.RsltR> up1;
		
		
		// コンストラクタ
		protected Upd01() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverFXBA.FXBAL0140.InfoR.create();
			up1 = MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			if (i == 1) return up1();
			return null;
		}
		
		public MCContainer down(int i) {
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL0140)FXBAL0140_FW_A.this);
		}
		
		protected void clear() {
		}
		/**
		 * InfoブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR createInfoR(){
			return mcframe.serverFXBA.FXBAL0140.InfoR.create();
		}

		/**
		 * RsltブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0140.RsltR createRsltR(){
			return mcframe.serverFXBA.FXBAL0140.RsltR.create();
		}

		/**
		 * RsltブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> createRsltL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0140.RsltR.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>moduleid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>screenid</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>table</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverFXBA.FXBAL0140.InfoR
		 */
		public mcframe.serverFXBA.FXBAL0140.InfoR up0() {
			return up0;
		}

		/**
		 * 上り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>rowno</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>id</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>type</td></tr>
		 * 	<tr><td><br></td><td>STRING</td></tr>
		 * 	<tr><td><br></td><td>NUMBER</td></tr>
		 * 	<tr><td><br></td><td>BOOLEAN</td></tr>
		 * 	<tr><td><br></td><td>DATE</td></tr>
		 * 	<tr><td><br></td><td>TIMESTAMP</td></tr>
		 * 	<tr><td><br></td><td>BINARY</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0140.RsltR> up1() {
			return up1;
		}




		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL0140)FXBAL0140_FW_A.this).info;
		}


	}

	//FMCB LOGIC_CONTROLLER END
}