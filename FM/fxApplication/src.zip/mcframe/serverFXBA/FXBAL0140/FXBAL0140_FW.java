package mcframe.serverFXBA.FXBAL0140;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.logic.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

//手修正によるカスタマイズで必要なimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.serverFXBA.FXBAL0140.*;	// このimportはFrameManagerの自動生成で追加されました。
import mcframe.commonFXBA.FXBAC0140.FXBAC_ContainerColumnMapper;
import mcframe.commonFXBA.FXBAC0140.FXBAC_TableEdit;
import mcframe.serverCore.resource.MCConfig;
import mcframe.serverCore.resource.MCConst;
import mcframe.serverCore.acl.MCACLManager;
import mcframe.serverCore.queryapi.MCForeignInfo;
import mcframe.serverCore.queryapi.MCDBContainer.MCDBContainerColulmnInfo;
import mcframe.serverCore.sys.MCSys;
import mcframe.commonCore.container.io.MCContainerIOConfig;
import mcframe.commonCore.container.io.MCCsvWriter;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.requester.MCDownloadUtil;
import mcframe.commonCore.resource.ctrl.MCCustomResource;
import mcframe.commonCore.sys.MCFactory;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.util.MCFileUtil;

import static mcframe.serverCore.util.MCDBUtil.*;
import static mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil.*;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;

import java.io.File;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.jar.JarFile;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Set;
//FMCB CUSTOM_IMPORT END

/**
 * "FXBAL0140"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class FXBAL0140_FW extends FXBAL0140_FW_A{
	//FMCB CUSTOM START
	/**
	 * テーブル編集権限のACタイプ：検索
	 */
	private final String ACTYPE_SRCH =
					MCConst.app.getString("FX.FXBAL0140.tbledit.actype.srch");
	/**
	 * テーブル編集権限のACタイプ：更新
	 */
	private final String ACTYPE_UPD =
					MCConst.app.getString("FX.FXBAL0140.tbledit.actype.upd");


	/**
	 * 処理対象画面のモジュールID
	 */
	private String _moduleid = null;
	/**
	 * 処理対象画面の画面ID
	 */
	private String _screenid = null;
	/**
	 * 処理対象画面の共通リソース
	 */
	private MCCustomResource _common = null;


	/**
	 * リソースを初期化します。
	 * 
	 * @param mid 処理対象画面のモジュールID
	 * @param sid 処理対象画面の画面ID
	 */
	protected void resourceInit(String mid, String sid) {
		_moduleid = mid;
		_screenid = sid;

		// 701-00468 2017/01/31 MCF_HOMEも調べる
		String filePkg = getResourcePath() + "/common.xml";

		File file = new File(MCSys.env.MCF_HOME(), filePkg);
		if (!file.exists()) {
			ClassLoader cl = Thread.currentThread().getContextClassLoader();
			if (cl.getResource(filePkg) == null) {
				// 共通ファイルなし
				_common = null;
				return;
			}
		}
		_common = getResource("common");
	}

	/**
	 * 編集対象テーブルリソースが配置されているパス（パッケージ）を返します。
	 * 
	 * @return 配置されているパス（パッケージ）
	 */
	protected String getResourcePath() {
// 2017/05/23 起動時リソース読込高速化対応 tbleditはconst外に配置する
//		return "const/" + _moduleid + "/tbledit/" + _screenid;
		return "tbledit/" + _moduleid + "/" + _screenid;
	}

	/**
	 * 編集対象テーブルリソースをロードしたリソースオブジェクトを返します。
	 * 
	 * @param table テーブル名
	 * @return テーブルリソース
	 */
	protected MCCustomResource getResource(String table) {
		String pkgpath = getResourcePath();
		MCCustomResource cr = new MCCustomResource(table);
		cr.setTraceLogCaption("Edit Table Resource");
// 簡易デバッグ用
//String trace = 
		cr.loadInit(null, pkgpath, null);
//System.out.println(trace);
		return cr;
	}

	/**
	 * テーブルリソースから文字列値を取得します。
	 * 
	 * @param table テーブルリソース
	 * @param parts リソースキー
	 * @return リソース値。キー未設定または値未設定の場合 null
	 */
	private String getConstStr(MCCustomResource table, String...parts) {
		String key = MCConst.createKey(parts);
		String val = table.getString(key);
		if (val == null && _common != null) {
			val = _common.getString(key);
		}
		return val;
	}
	/**
	 * テーブルリソースから文字配列値を取得します。
	 * 
	 * @param table テーブルリソース
	 * @param parts リソースキー
	 * @return リソース値。キー未設定または値未設定の場合 null
	 */
	private String[] getConstStrs(MCCustomResource table, String...parts) {
		String key = MCConst.createKey(parts);
		String[] val = table.getStringArray(key);
		if (val == null && _common != null) {
			val = _common.getStringArray(key);
		}
		return val;
	}
	/**
	 * テーブルリソースから論理値を取得します。
	 * 
	 * @param table テーブルリソース
	 * @param parts リソースキー
	 * @return リソース値。キー未設定または値未設定の場合 false
	 */
	private boolean getConstBoo(MCCustomResource table, String...parts) {
		String key = MCConst.createKey(parts);
		// FC7011#006 テーブルリソースのboolean値がfalseのときcommonの値が使われる
		boolean val = (table.containsKey(key))
								? table.getBoolean(key)
								: (_common != null)
										? _common.getBoolean(key)
										: false;
		return val;

	}
	/**
	 * テーブルリソースからパターンに一致するリソースキーの部分要素の配列を取得します。
	 * 
	 * @param table テーブルリソース
	 * @param parts リソースキー
	 * @return 一致するリソースキーの部分要素の配列
	 */
	private String[] getConstChildren(MCCustomResource table, String...parts) {
		String key = MCConst.createKey(parts);
		String[] ptn = table.findPattern(key);
		if (_common != null) {
			String[] com = _common.findPattern(key);
			ptn = Stream.concat(Arrays.stream(ptn), Arrays.stream(com))
					.collect(Collectors.toSet())
					.stream()
					.toArray(count -> new String[count]);
		}
		return ptn;
	}


	/**
	 * テーブルリソースの基準ファイル名の配列を返します。
	 * 
	 * テーブルリソースの基準ファイル名はテーブル名と一致します。
	 * 共通定義の common は含みません。
	 * 
	 * @return 基準ファイル名の配列
	 */
	protected String[] getResourceBase() {
		Set<String> baseSet = new HashSet<String>();

		// パス
		String pkgpath = getResourcePath();

		// MCF_HOMEから検索
		String mcfhome =  MCSys.env.MCF_HOME();
		File homepath = new File(mcfhome, pkgpath);
		Set<String> homeSet = getResourceBasesForDir(homepath);
		baseSet.addAll(homeSet);

		// クラスパスから検索
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		//ClassLoader cl = this.getClass().getClassLoader();
		Enumeration<URL> urls;
		try {
			urls = cl.getResources(pkgpath);
			while (urls.hasMoreElements()) {
				URL url = urls.nextElement();
				String protocol = url.getProtocol();
				if ("file".equals(protocol)) {
					// fileの場合
					Set<String> fileSet = getResourceBasesForDir(new File(url.getFile()));
					baseSet.addAll(fileSet);
				}
				else if ("jar".equals(protocol)) {
					// jarの場合
					Set<String> fileSet = getResourceBasesForJar(url, pkgpath);
					baseSet.addAll(fileSet);
				}
			}
		}
		catch (java.io.IOException e) {
			throw new MCException(e);
		}
		baseSet.remove("common");	// common は含めない

		return baseSet.toArray(new String[baseSet.size()]);
	}

	/**
	 * テーブルリソースの基準ファイル名の配列を返します。
	 * 
	 * テーブルリソースの基準ファイル名はテーブル名と一致します。
	 * 
	 * @param dir ディレクトリ
	 * @return 基準ファイル名の配列
	 */
	protected Set<String> getResourceBasesForDir(File dir) {
		if (!dir.isDirectory()) {
			return new HashSet<String>();
		}

		File[] files = dir.listFiles(
							(parent, name) -> name.matches("^[^@.]+[.]xml$"));
		return Arrays.stream(files)
					.map(file -> file.getName())
					.map(name -> name.replaceFirst("[.]xml$", ""))
					.collect(Collectors.toSet());
	}

	/**
	 * テーブルリソースの基準ファイル名の配列を返します。
	 * 
	 * テーブルリソースの基準ファイル名はテーブル名と一致します。
	 * 
	 * @param url Jarファイルを示すURL
	 * @param pkgpath ファイルが配置されているパッケージ
	 * @return 基準ファイル名の配列
	 */
	protected Set<String> getResourceBasesForJar(URL url, String pkgpath) {
		final String pkg = (pkgpath.indexOf(pkgpath.length() - 1) != '/')
													? pkgpath += "/" : pkgpath;
		try (JarFile jarFile = ((JarURLConnection) url.openConnection()).getJarFile()) {
			return Collections.list(jarFile.entries()).stream()
					.map(jarEntry -> jarEntry.getName())
					.filter(name -> name.startsWith(pkg))
					.map(name -> name.replaceFirst(pkg, ""))
					.filter(name -> name.matches("^[^@.]+[.]xml$"))
					.map(name -> name.replaceFirst("[.]xml$", ""))
					.collect(Collectors.toSet());
		}
		catch (java.io.IOException e) {
			// JarファイルのI/Oエラー自体問題 > 例外で中断
			throw new MCException(e);
		}
	}


	/**
	 * テーブル定義を取得します。
	 * 
	 * @param defL 取得した定義を設定するList
	 * @param table テーブルリソース
	 */
	protected void getDefine(MCList<DefR> defL, MCCustomResource table) {
		defL.clear();

		// DBコンテナ生成
		MCList<MCDBContainer> dbl = createDBList(table);

		// 検索条件項目
		String[] conds = getConstStrs(table, "cond", "cols");
		if (conds != null) {
			Arrays.sort(conds);
		}

		// デフォルトのモード
		String defmode = getColumnMode(table, "__default__");
		if (defmode == null) {
			defmode = "E";// 編集可
		}

		MCDBContainer dbc = dbl.createRow();
		String[] colbase = dbc.getBaseColumns();
		String[] collist = dbc.getAllColumn();

		for (String colname : collist) {
			// DB項目 基本設定
			DefR defR = defL.createRow();
			setDefineToDefR(defR, dbc, colname, defmode);

			// 書式変更（設定がある場合のみ）
			setFormatToDefR(defR, table, dbc, colname);

			// 検索条件対象設定
			setCondColumn(defR, conds);

			// モード設定
			setColumnMode(defR, table,
							!MCCollectionUtil.contains(colname, colbase),
							dbc.isNullableColumn(colname));

			// オプション設定
			setColumnOption(defR, table);

			defL.add(defR);
		}
	}
	
	/**
	 * 専用リソースファイルにformatが設定されている場合は、DefRに設定値を設定します。
	 * 数値項目の場合、formatの記述は、以下のいずれかの記述で設定します。
	 *   - [MCFormatの書式名];[桁数]
	 *   - [MCFormatの書式名]
	 *   - [桁数]
	 * 
	 * formatの設定が「MCFormatの書式名」の場合は、DB定義書から取得した桁数を付与して
	 * [MCFormatの書式名];[桁数]の形式でDefRに設定します。
	 * 
	 * formatが未設定の場合は、DefRのformatはDB定義書の桁数を設定します（setFormatTODefRでは何もしない）。
	 * 数値項目意外の場合は、formatに設定されている値をDefRに設定します。
	 * 
	 * @param defR 下り電文
	 * @param table テーブル名
	 * @param dbc テーブルのDBコンテナ
	 * @param colname カラム名
	 */
	private void setFormatToDefR(DefR defR, MCCustomResource table, MCDBContainer dbc,
			String colname) {
		String format = getConstStr(table, "format", colname);
		if (format == null) {
			return;
		}

		MCMeta meta = dbc.getMeta(colname);
		switch (meta.type()) {
			case NUMBER:
				String f = makeFormatStr(defR.format(), format);
				defR.format(f);
				break;
			default:
				defR.format(format);
				break;
		}
	}

	/**
	 * DB定義書の桁数の記述と、専用リソースファイルのformatの記述から、下り電文のformatに設定する値を作成します。
	 * 
	 * @param orgFormat　DB定義書の桁数
	 * @param resFormat 専用リソースファイルのformatの記述
	 * @return 下り電文のformatに設定する値
	 */
	private String makeFormatStr(String orgFormat, String resFormat) {
		if (resFormat.contains(";") || isLengthStr(resFormat)) {
			// resFormatは「書式＋桁数」 or 「桁数」
			return resFormat;
		}
		return resFormat + ";" + orgFormat;
	}

	/**
	 * 指定された値が数値に変換できる値か判定します。
	 * 
	 * targetは、DB定義書に記載する桁数を想定しているため、半角カンマで区切られている場合があるります（例：21,7）。
	 * 
	 * @param target 数値に変換できるか調べる文字列
	 * @return trueの場合、数値に変換できる
	 */
	private boolean isLengthStr(String target) {
		boolean result = true;
		try {
			String s = target.replaceAll(",", "");
			Integer.parseInt(s);
		}
		catch (NumberFormatException e) {
			result = false;
		}
		return result;
	}

	/**
	 * テーブルのカラム定義を取得します。
	 * 
	 * @param defR 取得した定義を設定するRow
	 * @param dbc テーブルのDBコンテナ
	 * @param colname カラム名
	 * @param mode モード（デフォルト）
	 * @return 取得したカラムのメタ
	 */
	protected MCMeta setDefineToDefR(DefR defR, MCDBContainer dbc, String colname, String mode) {
		MCMeta meta = dbc.getMeta(colname);

		defR.id(colname);
		defR.name(realColumn(dbc, colname));
		defR.key(isKey(dbc, colname));
		defR.meta(meta.name());
		defR.type(meta.type().toString());
		defR.format(null);
		switch (meta.type()) {
		case STRING:
			defR.format("" + meta.length());
			break;
		case NUMBER:
			int l = (meta.minusEnable()) ? meta.length() * -1 : meta.length();
			int s = meta.scale();
			defR.format(Integer.toString(l) + "," + Integer.toString(s));
			break;
		case BOOLEAN:
			break;
		case DATE:
			defR.format("YMDHMS");
			break;
		case TIMESTAMP:
			defR.format("YMDHMSS");
			break;
		case BINARY:
			break;
		default:
			break;
		}
		// デフォルト値
		defR.mode(mode);
		defR.cond(true);
		defR.opt(null);

		return meta;
	}

	/**
	 * 実際のカラム名を返します。
	 * 処理対象のテーブルのカラムの場合、引数がそのまま返ります。
	 * 外部結合カラムの場合、[実際のテーブル名].[カラム名]を返します。
	 * @param dbc テーブルのDBコンテナ
	 * @param colname カラム名
	 * @return 実際のカラム名
	 */
	protected String realColumn(MCDBContainer dbc, String colname) {
		MCForeignInfo foreign = dbc.getForeignInfoByColumn(colname);
		MCDBContainerColulmnInfo<?> colinfo = dbc.getColumnInfo(colname);
		if (foreign != null) {
			String t = foreign.tableName();
			String c = colinfo.tableColumnName();
			colname = t + "." + c;
		}
		return colname;
	}

	/**
	 * 検索条件カラムを設定します。
	 * 引数 conds が null の場合は常に検索条件になります。
	 * 
	 * @param defR 取得した定義を設定するRow
	 * @param conds 検索条件カラム名の配列
	 */
	protected void setCondColumn(DefR defR, String[] conds) {
		boolean cond = (conds == null || (Arrays.binarySearch(conds, defR.id()) >= 0));
		defR.cond(cond);
	}

	/**
	 * カラムのモードを返します。
	 * 
	 * リソースにモードが未設定の場合は null を返します。デフォルト値は返しません。
	 * 
	 * @param table テーブルリソース
	 * @param id カラム名
	 * @return モード
	 */
	protected String getColumnMode(MCCustomResource table, String id) {
		return getConstStr(table, "dtl", "mode", id);
	}

	/**
	 * カラムのモードを設定します。
	 * 
	 * リソースにモードが未設定の場合は、何も行いません。デフォルト値は返しません。
	 * 
	 * @param defR 取得した定義を設定するRow
	 * @param table テーブルリソース
	 * @param foreign 外部結合項目の場合 true
	 * @param nullable NULL可項目の場合 true
	 */
	protected void setColumnMode(DefR defR, MCCustomResource table, boolean foreign, boolean nullable) {
		String mode = getColumnMode(table, defR.id());
		if (mode != null) {
			// リソースの設定優先
			defR.mode(mode);
		}
		else {
			// 
			if (foreign) {
				// 外部結合項目は読み取り専用
				defR.mode("RO");
			}
			else if (defR.key() || !nullable) {
				// キー項目＆NULL不可項目は必須
				defR.mode("R");
			}
			// デフォルトは設定済み
		}
	}

	/**
	 * カラムのオプションを設定します。
	 * リソースの設定に従い、次のオプションを設定します。
	 * <dl>
	 * <dt>文字列項目</dt>
	 * <dd>リストロジック設定</dd>
	 * </dl>
	 * 
	 * @param defR 取得した定義を設定するRow
	 * @param table テーブルリソース
	 */
	protected void setColumnOption(DefR defR, MCCustomResource table) {
		MCDataType type = MCDataType.valueOf(defR.type());
		switch (type) {
		case STRING:
			// リストロジック
			// COMBO^[both/cond/dtl]^[リストロジック]^[連携カラム[, ...]]^[リストのカラム名[, ...]]^[検索条件[, ...]]
			String listkey = MCConst.createKey("list", defR.id());
			String listlogic = getConstStr(table, listkey, "logic");
			if (listlogic != null) {
				String links = getConstStr(table, listkey, "link");
				links = (links != null) ? defR.id() + "," + links : defR.id();

				String alias = getConstStr(table, listkey, "alias");
				alias =  (alias != null) ? alias : links;

				String use = getConstStr(table, listkey, "use");
				if (use == null) {
					use = FXBAC_TableEdit.DEFOPT_COMBO_USE_BOTH;
				}
				else switch (use) {
				case FXBAC_TableEdit.DEFOPT_COMBO_USE_COND:
				case FXBAC_TableEdit.DEFOPT_COMBO_USE_DTL:
				case FXBAC_TableEdit.DEFOPT_COMBO_USE_BOTH:
					break;
				default:
					use = FXBAC_TableEdit.DEFOPT_COMBO_USE_BOTH;
					break;
				}
				use =  (use != null) ? use : FXBAC_TableEdit.DEFOPT_COMBO_USE_BOTH;

				String[] condarray = getConstChildren(table, listkey, "cond", "*");
				for (int i = 0; i < condarray.length; i++) {
					String cond = condarray[i];
					String condval = getConstStr(table, cond);
					String[] condkey = MCConst.splitKey(cond);
					condarray[i] = condval + 
									FXBAC_TableEdit.DEFOPT_COMBO_CONDS_ITEMSEP + 
									condkey[condkey.length - 1];
				}
				String conds = MCStringUtil.join(FXBAC_TableEdit.DEFOPT_COMBO_CONDS_SEP, condarray);

				String opt = MCStringUtil.join(FXBAC_TableEdit.DEFOPT_SEP,
									FXBAC_TableEdit.DEFOPT_COMBO, use, listlogic, links, alias, conds);
				defR.opt(opt);
			}
			break;
		default:
			break;	
		}
	}

	/**
	 * キーカラムの場合 true を返します。
	 * 
	 * @param dbc テーブルのDBコンテナ
	 * @param colname カラム名
	 * @return キーカラム以外の場合 false
	 */
	protected boolean isKey(MCDBContainer dbc, String colname) {
		for (String key : dbc.getKeyColumn()) {
			if (colname.equals(key)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * アプリケーションのリソース定義を取得します。
	 * 
	 * @param appL 取得した定義を設定するList
	 * @param table テーブルリソース
	 */
	protected void getAppParam(MCList<AppR> appL, MCCustomResource table) {
		Map<String, String> paramMap = new HashMap<>();

		// commonとtableのマージ（tableが強い）
		MCCustomResource[] resArray = { _common, table };
		for (MCCustomResource res : resArray) {
			// 701-00467 2017/01/31 common.xmlがなくても動作する
			if (res == null) {
				continue;
			}
			String[] entries = getConstChildren(res, "app", "**");
			for (String entry : entries) {
				String val = getConstStr(res, entry);
				String key = entry.substring(4);// "app."を削除
				paramMap.put(key, val);
			}
		}

		// コンテナに設定
		paramMap.entrySet().forEach(e -> {
			AppR appR = appL.createRow();
			appR.key(e.getKey());
			appR.val(e.getValue());
			appL.add(appR);
		});
	}

	/**
	 * DBコンテナを生成します。
	 * 
	 * @param table テーブルリソース
	 * @return 生成したコンテナ
	 */
	protected MCList<MCDBContainer> createDBList(MCCustomResource table) {
		String dbcbase = getConstStr(table, "dbc");
		Class<? extends MCDBContainer> dbc = MCFactory.getClass(MCDBContainer.class, dbcbase + "_R");
		return (MCList<MCDBContainer>) MCList.create(dbc);
	}

	/**
	 * データチェッカーを生成します。
	 *
	 * @param table テーブルリソース
	 * @return データチェッカー
	 */
	protected FXBAL0140DataChecker<MCDBContainer> createDataChecker(MCCustomResource table) {
		String chkbase = getConstStr(table, "checker");
		if (chkbase == null) {
			return null;
		}
		return MCFactory.create(FXBAL0140DataChecker.class, chkbase);
	}

	/**
	 * 権限がある場合 true を返します。
	 * 権限文字列は次のようになります。
	 * <code>
	 * [画面モジュールID].[画面ID].[テーブル名].[ACタイプ]
	 * </code>
	 * @param tbl テーブル名
	 * @param actype ACタイプ
	 * @return 権限がない場合 false
	 */
	protected boolean checkACL(String tbl, String actype) {
		String ac = MCConst.createKey(tbl, actype);
		MCACLManager srvmgr = MCACLManager.createServerManager();
		return srvmgr.authorize(_moduleid, _screenid, ac, tbl);
	}

	// FC7011#041 検索パフォーマンス改善
	/**
	 * テーブルのデータを検索します。
	 *
	 * @param infoR テーブル情報
	 * @param condL 検索条件
	 * @return 検索結果
	 * @throws MCException [FCBHC0024] テーブルの検索権限がない場合
	 * @since 7.0.1.2
	 */
	protected MCList<MCDBContainer> srchData(InfoR infoR, MCList<CondR> condL) {
		// オペレーションの実装
		String mid = infoR.moduleid();
		String sid = infoR.screenid();
		resourceInit(mid, sid);

		String table = infoR.table();
		MCCustomResource res = getResource(table);

		// 権限制御
		if (getConstBoo(res, "acl", "enable")) {
			// 権限制御有効
			if (!checkACL(table, ACTYPE_SRCH)) {
				// テーブルに対する権限なし
				throw new MCException(FCBHC0024, mid, sid, table);
			}
		}

		// DBコンテナ取得
		MCList<MCDBContainer> dbL = createDBList(res);

		// データ検索
		MCDBContainer cond = dbL.createRow();
		MCDBContainer t = dbL.createRow();
		t.setAlias("T");
		MCQueryApiBuilder bldr = MCQueryApiBuilder.create(t);
		for (CondR condR : condL) {
			String id = condR.id();
			MCPermColumn col = t.getColumn$(id);// Foreignのカラムも取得できる
			MCPredicate ope = null;
			Comparable<?> val = null;
			MCDataType type = MCDataType.valueOf(condR.type());
			switch (type) {
			case STRING:
				val = condR.STRING();
				cond.setStringNE(id, (String) val);
				ope = ((MCStringPermColumn) col).like(bind("1"));// " like ";
				break;
			case NUMBER:
				val = condR.NUMBER();
				cond.setNumberNE(id, (MCNumber) val);
				ope = ((MCNumberPermColumn) col).eq(bind("1"));// " = ";
				break;
			case BOOLEAN:
				val = condR.BOOLEAN();
				cond.setBooleanNE(id, (Boolean) val);
				ope = ((MCBooleanPermColumn) col).eq(bind("1"));// " = ";
				break;
			case DATE:
				val = condR.DATE();
				if (condR.opt() == null) {
				}
				else switch (condR.opt()) {
				case FXBAC_TableEdit.DEFOPT_DATE_FROM:
					cond.setDateNE(id, (MCDate) val);
					ope = ((MCDatePermColumn) col).gte(bind("1"));// " >= ";
					break;
				case FXBAC_TableEdit.DEFOPT_DATE_TO:
					cond.setDateNE(id + FXBAC_TableEdit.COND_DATE_TO, (MCDate) val);
					ope = ((MCDatePermColumn) col).lte(bind("1"));// " <= ";
					break;
				default:
					break;
				}
				break;
			case TIMESTAMP:
				val = condR.TIMESTAMP();
				if (condR.opt() == null) {
				}
				else switch (condR.opt()) {
				case FXBAC_TableEdit.DEFOPT_DATE_FROM:
					cond.setTimestampNE(id, (MCTimestamp) val);
					ope = ((MCTimestampPermColumn) col).gte(bind("1"));// " >= ";
					break;
				case FXBAC_TableEdit.DEFOPT_DATE_TO:
					cond.setTimestampNE(id + FXBAC_TableEdit.COND_DATE_TO, (MCTimestamp) val);
					ope = ((MCTimestampPermColumn) col).lte(bind("1"));// " <= ";
					break;
				default:
					break;
				}
				break;
			case BINARY:
				val = condR.BINARY();
				cond.setBinaryNE(id, (MCBinary) val);
				ope = ((MCBinaryPermColumn) col).eq(bind("1"));// " = ";
				break;
			default:
				break;
			}

			if (val != null) {
				// 値があればWhere句に追加
				bldr.addWhereWithCutOffAnd(ope, val);
			}

		}
		bldr.setSelectAll();

		FXBAL0140DataChecker<MCDBContainer> checker = createDataChecker(res);
		FXBAL0140AppDefResource appDefRes = new FXBAL0140AppDefResource(res, _common);

		// 検索前処理
		if (checker != null) {
			checker.beforeSearch(bldr, appDefRes, cond);
		}

		int size = dbSelect("FXBAL0140_DBCONTAINER_S01", dbL, bldr);

		// 検索後処理
		if (checker != null) {
			checker.afterSearch(dbL, appDefRes);
		}

		return dbL;
	}



	/**
	 * Srch01オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	public class Srch01 extends FXBAL0140_FW_A.Srch01 {
		@Override
		protected void call() {
			// オペレーションの実装
			MCList<InfoR> listL = down0();

			InfoR infoR = up0();
			String mid = infoR.moduleid();
			String sid = infoR.screenid();
			resourceInit(mid, sid);

			String[] tables = getResourceBase();
			for (String table : tables) {
				MCCustomResource res = getResource(table);
				if (getConstStr(res, "dbc") == null) {
					// DBコンテナ指定がないものはスキップ
					continue;
				}

				String name = getDBLabel(table, null, MCSys.user.locale());
				name = (name != null) ? name : table;

				// 権限制御
				if (getConstBoo(res, "acl", "enable")) {
					// 権限制御有効
					if (!checkACL(table, ACTYPE_SRCH)) {
						// 最低参照権限が必要
						continue;
					}
				}

				InfoR listR = listL.createRow();
				listR.moduleid(mid);
				listR.screenid(sid);
				listR.table(table);
				listR.name(name);
				listL.add(listR);
			}
		}
	}
	/**
	 * Srch02オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	public class Srch02 extends FXBAL0140_FW_A.Srch02 {
		@Override
		protected void call() {
			// オペレーションの実装
			InfoR infoR = up0();
			String mid = infoR.moduleid();
			String sid = infoR.screenid();
			resourceInit(mid, sid);

			String table = infoR.table();
			MCCustomResource res = getResource(table);

			// 権限制御
			boolean upd = true;	// 権限制御無効 = 更新可
			if (getConstBoo(res, "acl", "enable")) {
				// 権限制御有効
				upd = checkACL(table, ACTYPE_UPD);
				if (!upd && !checkACL(table, ACTYPE_SRCH)) {
					// 最低参照権限が必要
					throw new MCException(FCBHC0024, mid, sid, table);
				}
			}
			infoR.upd(upd);
			// FC7011#041 キー重複許可
			boolean duplicate = getConstBoo(res, "dtl", "duplicate");
			infoR.duplicate(duplicate);
			// セルコンフィグ
			String cell = getConstStr(res, "dtl", "cell");
			infoR.cell(cell);

			MCRow.copyvalue(down0(), infoR);
			getDefine(down1(), res);
			getAppParam(down2(), res);
		}
	}
	/**
	 * Srch03オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	public class Srch03 extends FXBAL0140_FW_A.Srch03 {
		@Override
		protected void call() {
			// オペレーションの実装

			// FC7011#041 検索パフォーマンス改善
			// 検索
			MCList<MCDBContainer> dbL = srchData(up0(), up1());
			int size = dbL.size();

			// 電文形式に変換
			MCCustomResource res = getResource(up0().table());
			MCList<DefR> defL = MCList.create(DefR.class);
			getDefine(defL, res);
			MCList<RsltR> rsltL = down0();
			for (int i = 0; i < size; i++) {
				MCDBContainer dbR = dbL.get(i);
				for (DefR defR : defL) {
					String id = defR.id();
					RsltR rsltR = rsltL.createRow();
					rsltR.rowno(i);
					rsltR.id(id);
					rsltR.type(defR.type());
					MCDataType type = MCDataType.valueOf(defR.type());
					switch (type) {
					case STRING:
						rsltR.STRING(dbR.getString(id));
						break;
					case NUMBER:
						rsltR.NUMBER(dbR.getNumber(id));
						break;
					case BOOLEAN:
						rsltR.BOOLEAN(dbR.getBoolean(id));
						break;
					case DATE:
						rsltR.DATE(dbR.getDate(id));
						break;
					case TIMESTAMP:
						rsltR.TIMESTAMP(dbR.getTimestamp(id));
						break;
					case BINARY:
						rsltR.BINARY(dbR.getBinary(id));
						break;
					default:
						break;
					}
					rsltL.add(rsltR);
				}
			}
		}
	}
	/**
	 * Srch13オペレーション.<p>
	 *
	 * 汎用テーブル編集の検索を行います。<br>
	 */
	public class Srch13 extends FXBAL0140_FW_A.Srch13 {
		@Override
		protected void call() {
			// オペレーションの実装
			MCList<MCDBContainer> dbL = srchData(up0(), up1());
			if (dbL.isEmpty()) {
				// 検索結果なし
				return;
			}

			// 下りデータファイル書き込み
			File file = new File(downloadPath(),
									getLogicID() + "_" +
									dbL.createRow().tableName() + "_" +
									MCSys.request.serverRequestNo() +
									".csv");
			MCCsvWriter<MCDBContainer> writer = new MCCsvWriter<MCDBContainer>(dbL, file);
			MCContainerIOConfig csvconf = new MCContainerIOConfig();
			writer.setContainerColumnMapper(new FXBAC_ContainerColumnMapper<MCDBContainer>());
			MCMessageList msglist = writer.write(csvconf);
			if (!msglist.isEmpty()) {
				// 書き込みエラー
				MCException ex = new MCException(FXBAL0032);
				ex.addCauseMessageList(msglist);
				throw ex;
			}

			MCBinary bin = MCBinary.valueOf(file);
			RsltR rsltR = down0().add();
			rsltR.BINARY(bin);
		}

		/**
		 * ダウンロードファイルの出力ディレクトリのパスを返します。
		 *
		 * @return 出力ディレクトリのパス
		 * @since 7.0.1.2
		 */
		protected File downloadPath() {
			String base = MCConfig.server.getString("net.download.dir",
													MCDownloadUtil.downloadPath());
			File dir = new File(base, getLogicID()); //ディレクトリ
			MCFileUtil.mkDir(dir);
			return dir;
		}
	}

	/**
	 * Upd01オペレーション.<p>
	 *
	 */
	public class Upd01 extends FXBAL0140_FW_A.Upd01 {
		@Override
		protected void call() {
			// オペレーションの実装
			InfoR infoR = up0();
			String mid = infoR.moduleid();
			String sid = infoR.screenid();
			resourceInit(mid, sid);

			String table = infoR.table();
			if (!checkACL(table, ACTYPE_UPD)) {
				// 最低参照権限が必要
				throw new MCException(FCBHC0024, mid, sid, table);
			}

			MCCustomResource res = getResource(table);
			MCList<MCDBContainer> modL = createDBList(res);
			MCList<MCDBContainer> delL = modL.createInstance();
			MCList<MCDBContainer> creL = modL.createInstance();

			int rowno = -1;
			MCDBContainer dbr = null;
			MCList<MCDBContainer> dbl = null;
			MCList<RsltR> rsltL = up1();
			for (RsltR rsltR : rsltL) {
				if (rowno != rsltR.rowno().intValue()) {
					if (dbr != null) {
						dbl.add(dbr);
					}

					switch (rsltR.getStatus()) {
					case MODIFY:
						dbl = modL;
						break;
					case DELETE:
						dbl = delL;
						break;
					case CREATE:
					case GUICREATE:
						dbl = creL;
						break;
					case NONE:
					default:
						dbl = null;
						break;
					}
					rowno = rsltR.rowno().intValue();
					dbr = (dbl != null) ? dbl.createRow() : null;
				}
				if (dbr != null) {
					String id = rsltR.id();
					MCDataType type = MCDataType.valueOf(rsltR.type());
					switch (type) {
					case STRING:
						dbr.setString(id, rsltR.STRING());
						break;
					case NUMBER:
						dbr.setNumber(id, rsltR.NUMBER());
						break;
					case BOOLEAN:
						dbr.setBoolean(id, rsltR.BOOLEAN());
						break;
					case DATE:
						dbr.setDate(id, rsltR.DATE());
						break;
					case TIMESTAMP:
						dbr.setTimestamp(id, rsltR.TIMESTAMP());
						break;
					case BINARY:
						dbr.setBinary(id, rsltR.BINARY());
						break;
					default:
						break;
					}
				}
			}
			if (dbr != null) {
				dbl.add(dbr);
			}

			FXBAL0140DataChecker<MCDBContainer> checker = createDataChecker(res);
			FXBAL0140AppDefResource appDefRes = new FXBAL0140AppDefResource(res, _common);

			// 更新前処理
			if (checker != null) {
				checker.beforeUpdate(creL, modL, delL, appDefRes);
			}

			// DB更新
			MCDBContainer t = modL.createRow();
			t.setAlias("T");
			MCQueryApiBuilder builder = MCQueryApiBuilder.create(t);
			boolean needLock = t.isExCtrl();

			// 以降の実装は FXUCL0020/FXUCL_MCDbUtil#dbLockInsUpdDelByStatusCheck を参考に実装

			// Delete
			if (delL.size() > 0) {
				MCList<MCDBContainer> delLocked = delL.createInstance();
				MCList<MCDBContainer> delNotLocked = delL.createInstance();
				if (needLock) {
					dbSortLockDivide("FXBAL0140_DBCONTAINER_S02", builder, delL, delLocked, delNotLocked);
				}
				else {
					delLocked = delL;
				}
				for (MCRow row : delNotLocked) {
					MCMessagePool.add(new MCMessage(row, null, FXUDL0006, row));
				}
				dbDeleteKey("FXBAL0140_DBCONTAINER_D01", delLocked, builder);
			}

			// Update
			if (modL.size() > 0) {
				if (needLock) {
					dbSortLockUpd("FXBAL0140_DBCONTAINER_U01", modL, builder);
				}
				else {
					dbUpdateKey("FXBAL0140_DBCONTAINER_U02", modL, builder);
				}
			}

			// Insert
			if (creL.size() > 0) {
				sortForUpdate(builder, creL);
				dbInsertEx("FXBAL0140_DBCONTAINER_I01", creL, builder, FXUDL0005);
			}
		}
	}

	//FMCB CUSTOM END
}