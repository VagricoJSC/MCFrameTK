package mcframe.serverFXBA.FXBAL0140;

import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import mcframe.commonCore.container.MCList;

/**
 * 汎用テーブル処理のカスタマイズ処理用インターフェイスです。
 * 
 * @param <R> 処理対象のDBコンテナ
 */
public interface FXBAL0140DataChecker<R extends MCDBContainer> {

	/**
	 * 検索前処理です。
	 *
	 * 引数のRowには画面で入力された引数が設定されています。
	 * 日時系のカラムにはFromの値が入っています。
	 * Toの値は「[カラム名]_to」の名前の一時カラムに設定されています。
	 *
	 * <p>
	 * 引数のRowの値を変更しても、検索時の検索条件には反映されないことに
	 * 注意してください。
	 *
	 * @param builder 検索を実行するビルダー
	 * @param appRes アプリケーション定義リソース
	 * @param cond 検索条件の値が入ったRow
	 */
	public default void beforeSearch(MCQueryApiBuilder builder,
											FXBAL0140AppDefResource appRes, R cond) {};

	/**
	 * 検索後処理です。
	 * @param dbL 検索したList
	 * @param appRes アプリケーション定義リソース
	 */
	public default void afterSearch(MCList<R> dbL, FXBAL0140AppDefResource appRes) {};

	/**
	 * 更新前処理です。
	 * @param insL 追加するList
	 * @param modL 更新するList
	 * @param delL 削除するList
	 * @param appRes アプリケーション定義リソース
	 */
	public default void beforeUpdate(MCList<R> insL, MCList<R> modL, MCList<R> delL,
													FXBAL0140AppDefResource appRes) {};

}
