package mcframe.serverFXBA.FXBAL0140;

import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.resource.ctrl.MCCustomResource;
import mcframe.commonCore.resource.ctrl.MCReadableResource;
import mcframe.serverCore.resource.MCConst;


/**
 * テーブルリソースのアプリケーション定義リソースを管理します。
 * 
 */
public class FXBAL0140AppDefResource {

	/**
	 * 処理対象画面のテーブルリソース
	 */
	private final MCCustomResource _table;

	/**
	 * 処理対象画面の共通リソース
	 */
	private final MCCustomResource _common;


	/**
	 * コンストラクタです。
	 * 
	 * @param table テーブルリソース
	 * @param common 共通リソース
	 */
	FXBAL0140AppDefResource(MCCustomResource table, MCCustomResource common) {
		_table = table;
		_common = common;
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値（文字列）。設定がない場合 null
	 */
	private String getSourceString(String...keys) {
		String key = "app." + MCConst.createKey(keys);
		String val = _table.getString(key);
		if (val == null && _common != null) {
			val = _common.getString(key);
		}
		return val;
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public String getString(String...keys) {
		return getSourceString(keys);
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public MCNumber getNumber(String...keys) {
		String val = getSourceString(keys);
		return MCNumber.valueOf(val);
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public boolean getBoolean(String...keys) {
		String val = getSourceString(keys);
		return (val != null) ? Boolean.parseBoolean(val) : false;
	}

	/**
	 * 配列値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public String[] getStringArray(String...keys) {
		// 実装をクライアントのgetStringArrayと合わせる
		String val = getSourceString(keys);
		if (val == null) {
			return null;
		}
		String[] vals = MCStringUtil.split(MCReadableResource.ARRAY_ESCAPE,
											MCReadableResource.ARRAY_DELIMITER, val);
		for (int i = 0; i < vals.length; i++) {
			vals[i] = MCStringUtil.trim(vals[i]);
		}
		return vals;
	}

}