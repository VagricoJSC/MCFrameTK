package mcframe.serverFXBA.FXBAL0250;

import java.util.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.param.*;
import mcframe.serverCore.logic.*;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
//FMCB IMPORT START
//FMCB IMPORT END
import static mcframe.serverCore.logic.MCLogicUtil.*;

/**
 * "FXBAL_GadgetBase"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXBAL_GadgetBase_FW_A extends mcframe.serverFXBA.FXBAL0010.FXBAL_MCLogicBase {
	/** 
	 * モジュールID<p>
	 *
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * ロジックID<p>
	 *
	 * ロジックはモジュールIDとロジックIDで一意に特定できます。<br>
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getLogicID()}を使用してください。
	 */
	public static final String LOGIC_ID = "FXBAL0250";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** ロジックIDを取得します。 */
	public String getLogicID(){ return LOGIC_ID; }

	//FMCB CTRL_FIELD_METHOD START

	protected FXBAL_GadgetBase.Srch01 aSrch01;

	protected void initSrch01() {
		this.info = PDef.FX_FXBAL0250_Srch01_INFO;
		this.aSrch01 = ((FXBAL_GadgetBase)this).new Srch01();
	}

	public static FXBAL_GadgetBase.Srch01 crtSrch01() {
		FXBAL_GadgetBase lgc = new FXBAL_GadgetBase();
		lgc.initSrch01();
		return lgc.aSrch01;
	}

	protected void paramSrch01(MCParam p) {
		if (this.aSrch01 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch01.up0());
		p.addDownBlock(aSrch01.down0());
	}

	protected void doSrch01() {
		aSrch01.call();
	};

	/**
	 * Prop_Cnd0ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.Cnd0R createProp_Cnd0R(){
		return mcframe.serverCore.dashboard.gadget.Cnd0R.create();
	}

	/**
	 * Prop_Rslt0ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.Prop_Rslt0R createProp_Rslt0R(){
		return mcframe.serverCore.dashboard.gadget.Prop_Rslt0R.create();
	}

	/**
	 * Prop_Rslt0ブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverCore.dashboard.gadget.Prop_Rslt0R> createProp_Rslt0L(){
		return MCList.create(mcframe.serverCore.dashboard.gadget.Prop_Rslt0R.class);
	}
	protected FXBAL_GadgetBase.Srch02 aSrch02;

	protected void initSrch02() {
		this.info = PDef.FX_FXBAL0250_Srch02_INFO;
		this.aSrch02 = ((FXBAL_GadgetBase)this).new Srch02();
	}

	public static FXBAL_GadgetBase.Srch02 crtSrch02() {
		FXBAL_GadgetBase lgc = new FXBAL_GadgetBase();
		lgc.initSrch02();
		return lgc.aSrch02;
	}

	protected void paramSrch02(MCParam p) {
		if (this.aSrch02 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch02.up0());
		p.addUpBlock(aSrch02.up1());
		p.addDownBlock(aSrch02.down0());
	}

	protected void doSrch02() {
		aSrch02.call();
	};

	/**
	 * Data_Cnd0ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.Cnd0R createData_Cnd0R(){
		return mcframe.serverCore.dashboard.gadget.Cnd0R.create();
	}

	/**
	 * Data_Cnd1ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.Data_Cnd0R createData_Cnd1R(){
		return mcframe.serverCore.dashboard.gadget.Data_Cnd0R.create();
	}

	/**
	 * Data_Cnd1ブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverCore.dashboard.gadget.Data_Cnd0R> createData_Cnd1L(){
		return MCList.create(mcframe.serverCore.dashboard.gadget.Data_Cnd0R.class);
	}

	/**
	 * Data_Rslt0ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.Data_Rslt0R createData_Rslt0R(){
		return mcframe.serverCore.dashboard.gadget.Data_Rslt0R.create();
	}

	/**
	 * Data_Rslt0ブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverCore.dashboard.gadget.Data_Rslt0R> createData_Rslt0L(){
		return MCList.create(mcframe.serverCore.dashboard.gadget.Data_Rslt0R.class);
	}
	protected FXBAL_GadgetBase.Srch03 aSrch03;

	protected void initSrch03() {
		this.info = PDef.FX_FXBAL0250_Srch03_INFO;
		this.aSrch03 = ((FXBAL_GadgetBase)this).new Srch03();
	}

	public static FXBAL_GadgetBase.Srch03 crtSrch03() {
		FXBAL_GadgetBase lgc = new FXBAL_GadgetBase();
		lgc.initSrch03();
		return lgc.aSrch03;
	}

	protected void paramSrch03(MCParam p) {
		if (this.aSrch03 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch03.up0());
		p.addUpBlock(aSrch03.up1());
		p.addDownBlock(aSrch03.down0());
	}

	protected void doSrch03() {
		aSrch03.call();
	};

	/**
	 * List_Cnd0ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.Cnd0R createList_Cnd0R(){
		return mcframe.serverCore.dashboard.gadget.Cnd0R.create();
	}

	/**
	 * List_Cnd1ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.List_Cnd0R createList_Cnd1R(){
		return mcframe.serverCore.dashboard.gadget.List_Cnd0R.create();
	}

	/**
	 * List_Cnd1ブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverCore.dashboard.gadget.List_Cnd0R> createList_Cnd1L(){
		return MCList.create(mcframe.serverCore.dashboard.gadget.List_Cnd0R.class);
	}

	/**
	 * List_Rslt0ブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverCore.dashboard.gadget.List_Rslt0R createList_Rslt0R(){
		return mcframe.serverCore.dashboard.gadget.List_Rslt0R.create();
	}

	/**
	 * List_Rslt0ブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverCore.dashboard.gadget.List_Rslt0R> createList_Rslt0L(){
		return MCList.create(mcframe.serverCore.dashboard.gadget.List_Rslt0R.class);
	}

	//FMCB CTRL_FIELD_METHOD END

	//FMCB LOGIC_CONTROLLER START

	/**
	 * Srch01オペレーション.<p>
	 *
	 * 共通ガジェットベースの検索を行います。<br>
	 */
	abstract public class Srch01 extends MCOperation implements mcframe.serverCore.dashboard.gadget.IfMCDashboard_ISrch01 {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch01";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverCore.dashboard.gadget.Cnd0R up0;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverCore.dashboard.gadget.Prop_Rslt0R> down0;
		
		
		// コンストラクタ
		protected Srch01() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverCore.dashboard.gadget.Cnd0R.create();
			down0 = MCList.create(mcframe.serverCore.dashboard.gadget.Prop_Rslt0R.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL_GadgetBase)FXBAL_GadgetBase_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
		}
		/**
		 * Prop_Cnd0ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.Cnd0R createProp_Cnd0R(){
			return mcframe.serverCore.dashboard.gadget.Cnd0R.create();
		}

		/**
		 * Prop_Rslt0ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.Prop_Rslt0R createProp_Rslt0R(){
			return mcframe.serverCore.dashboard.gadget.Prop_Rslt0R.create();
		}

		/**
		 * Prop_Rslt0ブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.Prop_Rslt0R> createProp_Rslt0L(){
			return MCList.create(mcframe.serverCore.dashboard.gadget.Prop_Rslt0R.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>devtype</td></tr>
		 * 	<tr><td><br></td><td>gadget</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverCore.dashboard.gadget.Cnd0R
		 */
		public mcframe.serverCore.dashboard.gadget.Cnd0R up0() {
			return up0;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr><td><br></td><td>gadget</td></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>key</td></tr>
		 * 	<tr><td><br></td><td>value</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.Prop_Rslt0R> down0() {
			return down0;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL_GadgetBase)FXBAL_GadgetBase_FW_A.this).info;
		}


	}
	/**
	 * Srch02オペレーション.<p>
	 *
	 * 共通ガジェットベースの検索を行います。<br>
	 */
	abstract public class Srch02 extends MCOperation implements mcframe.serverCore.dashboard.gadget.IfMCDashboard_ISrch02 {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch02";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverCore.dashboard.gadget.Cnd0R up0;
		/** このオペレーションへの上り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverCore.dashboard.gadget.Data_Cnd0R> up1;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverCore.dashboard.gadget.Data_Rslt0R> down0;
		
		
		// コンストラクタ
		protected Srch02() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverCore.dashboard.gadget.Cnd0R.create();
			up1 = MCList.create(mcframe.serverCore.dashboard.gadget.Data_Cnd0R.class);
			down0 = MCList.create(mcframe.serverCore.dashboard.gadget.Data_Rslt0R.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			if (i == 1) return up1();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL_GadgetBase)FXBAL_GadgetBase_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
		}
		/**
		 * Data_Cnd0ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.Cnd0R createData_Cnd0R(){
			return mcframe.serverCore.dashboard.gadget.Cnd0R.create();
		}

		/**
		 * Data_Cnd1ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.Data_Cnd0R createData_Cnd1R(){
			return mcframe.serverCore.dashboard.gadget.Data_Cnd0R.create();
		}

		/**
		 * Data_Cnd1ブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.Data_Cnd0R> createData_Cnd1L(){
			return MCList.create(mcframe.serverCore.dashboard.gadget.Data_Cnd0R.class);
		}

		/**
		 * Data_Rslt0ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.Data_Rslt0R createData_Rslt0R(){
			return mcframe.serverCore.dashboard.gadget.Data_Rslt0R.create();
		}

		/**
		 * Data_Rslt0ブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.Data_Rslt0R> createData_Rslt0L(){
			return MCList.create(mcframe.serverCore.dashboard.gadget.Data_Rslt0R.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>devtype</td></tr>
		 * 	<tr><td><br></td><td>gadget</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverCore.dashboard.gadget.Cnd0R
		 */
		public mcframe.serverCore.dashboard.gadget.Cnd0R up0() {
			return up0;
		}

		/**
		 * 上り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>item</td></tr>
		 * 	<tr><td><br></td><td>strval</td></tr>
		 * 	<tr><td><br></td><td>numval</td></tr>
		 * 	<tr><td><br></td><td>booval</td></tr>
		 * 	<tr><td><br></td><td>dtval</td></tr>
		 * 	<tr><td><br></td><td>tsval</td></tr>
		 * 	<tr><td><br></td><td>binval</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.Data_Cnd0R> up1() {
			return up1;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>item</td></tr>
		 * 	<tr><td><br></td><td>strval</td></tr>
		 * 	<tr><td><br></td><td>numval</td></tr>
		 * 	<tr><td><br></td><td>booval</td></tr>
		 * 	<tr><td><br></td><td>dtval</td></tr>
		 * 	<tr><td><br></td><td>tsval</td></tr>
		 * 	<tr><td><br></td><td>binval</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.Data_Rslt0R> down0() {
			return down0;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL_GadgetBase)FXBAL_GadgetBase_FW_A.this).info;
		}


	}
	/**
	 * Srch03オペレーション.<p>
	 *
	 * 共通ガジェットベースの検索を行います。<br>
	 */
	abstract public class Srch03 extends MCOperation implements mcframe.serverCore.dashboard.gadget.IfMCDashboard_ISrch03 {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch03";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final mcframe.serverCore.dashboard.gadget.Cnd0R up0;
		/** このオペレーションへの上り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverCore.dashboard.gadget.List_Cnd0R> up1;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverCore.dashboard.gadget.List_Rslt0R> down0;
		
		
		// コンストラクタ
		protected Srch03() {
			
			// このオペレーションのコンテナ初期化
			up0 = mcframe.serverCore.dashboard.gadget.Cnd0R.create();
			up1 = MCList.create(mcframe.serverCore.dashboard.gadget.List_Cnd0R.class);
			down0 = MCList.create(mcframe.serverCore.dashboard.gadget.List_Rslt0R.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			if (i == 1) return up1();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			return null;
		}

		public void exec() {
			clear();
			invoke((FXBAL_GadgetBase)FXBAL_GadgetBase_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
		}
		/**
		 * List_Cnd0ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.Cnd0R createList_Cnd0R(){
			return mcframe.serverCore.dashboard.gadget.Cnd0R.create();
		}

		/**
		 * List_Cnd1ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.List_Cnd0R createList_Cnd1R(){
			return mcframe.serverCore.dashboard.gadget.List_Cnd0R.create();
		}

		/**
		 * List_Cnd1ブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.List_Cnd0R> createList_Cnd1L(){
			return MCList.create(mcframe.serverCore.dashboard.gadget.List_Cnd0R.class);
		}

		/**
		 * List_Rslt0ブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverCore.dashboard.gadget.List_Rslt0R createList_Rslt0R(){
			return mcframe.serverCore.dashboard.gadget.List_Rslt0R.create();
		}

		/**
		 * List_Rslt0ブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.List_Rslt0R> createList_Rslt0L(){
			return MCList.create(mcframe.serverCore.dashboard.gadget.List_Rslt0R.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>devtype</td></tr>
		 * 	<tr><td><br></td><td>gadget</td></tr>
		 * </table>
		 *
		 * @see mcframe.serverCore.dashboard.gadget.Cnd0R
		 */
		public mcframe.serverCore.dashboard.gadget.Cnd0R up0() {
			return up0;
		}

		/**
		 * 上り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>item</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.List_Cnd0R> up1() {
			return up1;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>item</td></tr>
		 * 	<tr><td><br></td><td>value</td></tr>
		 * 	<tr><td><br></td><td>name</td></tr>
		 * 	<tr><td><br></td><td>parent</td></tr>
		 * 	<tr><td><br></td><td>key</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverCore.dashboard.gadget.List_Rslt0R> down0() {
			return down0;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((FXBAL_GadgetBase)FXBAL_GadgetBase_FW_A.this).info;
		}


	}

	//FMCB LOGIC_CONTROLLER END
}