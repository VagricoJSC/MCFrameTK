package mcframe.serverFXBA.FXBAL0250;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cn;

/**
 * [FXBAL_GadgetBase]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FX.FXBAL0250.Srch01.UP.BLOCK0")){
			return FX_FXBAL0250_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0250.Srch01.DOWN.BLOCK0")){
			return FX_FXBAL0250_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0250.Srch02.UP.BLOCK0")){
			return FX_FXBAL0250_Srch02_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0250.Srch02.UP.BLOCK1")){
			return FX_FXBAL0250_Srch02_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0250.Srch02.DOWN.BLOCK0")){
			return FX_FXBAL0250_Srch02_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0250.Srch03.UP.BLOCK0")){
			return FX_FXBAL0250_Srch03_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0250.Srch03.UP.BLOCK1")){
			return FX_FXBAL0250_Srch03_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0250.Srch03.DOWN.BLOCK0")){
			return FX_FXBAL0250_Srch03_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
			
	
	static final MCOperationInfo FX_FXBAL0250_Srch01_INFO = new MCOperationInfo("FX", "FXBAL0250", "Srch01", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0250_Srch01_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("devtype", true, "devtype"),
				MCItemDef.create("gadget", "gadget")
			}
			,
			MCBlockDef.create("Prop_Cnd0")
		);
	}


	public static MCContainerDef FX_FXBAL0250_Srch01_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("gadget", "gadget"),
				MCItemDef.create("key", true, "key"),
				MCItemDef.create("value", "value")
			}
			,
			MCBlockDef.create("Prop_Rslt0")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0250_Srch02_INFO = new MCOperationInfo("FX", "FXBAL0250", "Srch02", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0250_Srch02_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("devtype", true, "devtype"),
				MCItemDef.create("gadget", "gadget")
			}
			,
			MCBlockDef.create("Data_Cnd0")
		);
	}

	public static MCContainerDef FX_FXBAL0250_Srch02_UP_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("item", true, "item"),
				MCItemDef.create("strval", "strval"),
				MCItemDef.create("numval", "numval"),
				MCItemDef.create("booval", "booval"),
				MCItemDef.create("dtval", "dtval"),
				MCItemDef.create("tsval", "tsval"),
				MCItemDef.create("binval", "binval")
			}
			,
			MCBlockDef.create("Data_Cnd1")
		);
	}


	public static MCContainerDef FX_FXBAL0250_Srch02_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("item", true, "item"),
				MCItemDef.create("strval", "strval"),
				MCItemDef.create("numval", "numval"),
				MCItemDef.create("booval", "booval"),
				MCItemDef.create("dtval", "dtval"),
				MCItemDef.create("tsval", "tsval"),
				MCItemDef.create("binval", "binval")
			}
			,
			MCBlockDef.create("Data_Rslt0")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0250_Srch03_INFO = new MCOperationInfo("FX", "FXBAL0250", "Srch03", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0250_Srch03_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("devtype", true, "devtype"),
				MCItemDef.create("gadget", "gadget")
			}
			,
			MCBlockDef.create("List_Cnd0")
		);
	}

	public static MCContainerDef FX_FXBAL0250_Srch03_UP_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("item", true, "item")
			}
			,
			MCBlockDef.create("List_Cnd1")
		);
	}


	public static MCContainerDef FX_FXBAL0250_Srch03_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0250", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("item", true, "item"),
				MCItemDef.create("value", "value"),
				MCItemDef.create("name", "name"),
				MCItemDef.create("parent", "parent"),
				MCItemDef.create("key", "key")
			}
			,
			MCBlockDef.create("List_Rslt0")
		);
	}
	//FMCB DEF_CLASSES END
}

