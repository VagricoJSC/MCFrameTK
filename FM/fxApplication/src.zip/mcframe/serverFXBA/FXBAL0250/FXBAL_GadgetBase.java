package mcframe.serverFXBA.FXBAL0250;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;

/**
 * "FXBAL_GadgetBase"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FXBAL_GadgetBase extends FXBAL_GadgetBase_FW {

}