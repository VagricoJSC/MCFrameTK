package mcframe.serverFXBA.FXBAL0250;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.logic.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

//手修正によるカスタマイズで必要なimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.serverCore.dashboard.gadget.*;	// このimportはFrameManagerの自動生成で追加されました。
//FMCB CUSTOM_IMPORT END

/**
 * "FXBAL_GadgetBase"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class FXBAL_GadgetBase_FW extends FXBAL_GadgetBase_FW_A{
	//FMCB CUSTOM START

	/**
	 * Srch01オペレーション.<p>
	 *
	 * 共通ガジェットベースの検索を行います。<br>
	 */
	public class Srch01 extends FXBAL_GadgetBase_FW_A.Srch01 {
		@Override
		protected void call() {
			// オペレーションの実装
		}
	}
	/**
	 * Srch02オペレーション.<p>
	 *
	 * 共通ガジェットベースの検索を行います。<br>
	 */
	public class Srch02 extends FXBAL_GadgetBase_FW_A.Srch02 {
		@Override
		protected void call() {
			// オペレーションの実装
		}
	}
	/**
	 * Srch03オペレーション.<p>
	 *
	 * 共通ガジェットベースの検索を行います。<br>
	 */
	public class Srch03 extends FXBAL_GadgetBase_FW_A.Srch03 {
		@Override
		protected void call() {
			// オペレーションの実装
		}
	}

	//FMCB CUSTOM END
}