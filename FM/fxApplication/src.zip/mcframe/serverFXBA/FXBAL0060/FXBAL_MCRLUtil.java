package mcframe.serverFXBA.FXBAL0060;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;

/**
 * "FXBAL_MCRLUtil"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FXBAL_MCRLUtil extends FXBAL_MCRLUtil_FW {

}