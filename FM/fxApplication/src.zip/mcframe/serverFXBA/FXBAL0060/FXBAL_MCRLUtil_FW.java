package mcframe.serverFXBA.FXBAL0060;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.logic.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

//手修正によるカスタマイズで必要なimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.ArrayList;
import java.util.List;

import mcframe.serverCore.queryapi.MCForeignInfo;
import static mcframe.serverCore.requester.MCRequestObject.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.commonFXBA.FXBAC0050.FXBAC_RLBase;
//FMCB CUSTOM_IMPORT END

/**
 * "FXBAL_MCRLUtil"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class FXBAL_MCRLUtil_FW extends FXBAL_MCRLUtil_FW_A{
	//FMCB CUSTOM START
	protected static final String $PARTS_DOT_ALIAS = "___";

	
	private static final Class<FXBAL_MCRLUtil> _clazz = FXBAL_MCRLUtil.class;

	/**
	 * ロジック共通の更新日時カラム名を取得します。<p>
	 */
	public static String getUpdTsColumn(){
		return object(_clazz)._getUpdTsColumn();
	}
	/**
	 * ロジック共通の更新日時カラム名を取得します。<p>
	 */
	protected String _getUpdTsColumn(){
		return FXBAC_RLBase.getUpdTsColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の登録日時カラム名を取得します。<p>
	 */
	public static String getInsTsColumn(){
		return object(_clazz)._getInsTsColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の登録日時カラム名を取得します。<p>
	 */
	protected String _getInsTsColumn(){
		return FXBAC_RLBase.getInsTsColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の更新カウンタカラム名を取得します。<p>
	 */
	public static String getUpdCntrColumn(){
		return object(_clazz)._getUpdCntrColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の更新カウンタカラム名を取得します。<p>
	 */
	protected String _getUpdCntrColumn(){
		return FXBAC_RLBase.getUpdCntrColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の登録担当者ＣＤカラム名を取得します。<p>
	 */
	public static String getInsUsrCdColumn(){
		return object(_clazz)._getInsUsrCdColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の登録担当者ＣＤカラム名を取得します。<p>
	 */
	protected String _getInsUsrCdColumn(){
		return FXBAC_RLBase.getInsUsrCdColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の更新担当者ＣＤカラム名を取得します。<p>
	 */
	public static String getUpdUsrCdColumn(){
		return object(_clazz)._getUpdUsrCdColumn();
	}
	/**
	 * ロジック(ＤＢコンテナ含む)共通の更新担当者ＣＤカラム名を取得します。<p>
	 */
	protected String _getUpdUsrCdColumn(){
		return FXBAC_RLBase.getUpdUsrCdColumn();
	}
	/**更新関係のカラム名の配列を取得します。*/
	protected static String[] getUpdColNames(){
		return object(_clazz)._getUpdColNames();
	}
	/**更新関係のカラム名の配列を取得します。*/
	protected String[] _getUpdColNames(){
		return UPD_COLNAMES;
	}
	/**更新関係のカラム名の配列*/
	private static final String[] UPD_COLNAMES = new String[] {
		getInsUsrCdColumn(), getInsTsColumn(), getUpdCntrColumn(), 
		getUpdUsrCdColumn(), getUpdTsColumn()
	};
	/**
	 * 変更前キー項目名配列を返します。 <p>
	 * 項目名の変換方法はgetBeforeKeyColumn(String)に依存します。
	 * @see #getBeforeKeyColumn(String)
	 */
	public static String[] getBeforeKeyColumns(String[] keyCols) {
		return object(_clazz)._getBeforeKeyColumns(keyCols);
	}

	public String[] _getBeforeKeyColumns(String[] keyCols) {
		String[] bk = new String[keyCols.length];

		for (int i = 0; i < keyCols.length; i++) {
			bk[i] = getBeforeKeyColumn(keyCols[i]);
		}
		return bk;
	}

	/** 
	 * 変更前キー項目名を返します。<p>
	 * 部品のパスがきた場合、$PARTS_DOT（.）は$PARTS_DOT_ALIAS（___）に変換されます。
	 */
	public static String getBeforeKeyColumn(String keyCol) {

		return object(_clazz)._getBeforeKeyColumn(keyCol);

	}

	public String _getBeforeKeyColumn(String keyCol) {

		keyCol = keyCol.replace(FXBAC_RLBase.$PARTS_DOT, $PARTS_DOT_ALIAS);

		return keyCol + FXBAC_RLBase.getBkSuffix();

	}

	/**カラムパスが主テーブルの項目、または参照先項目とリンクしている場合trueを返します。*/
	public static boolean isLinkedToTableColumn(MCDBContainer dbc, String columnPath) {
		return object(_clazz)._isLinkedToTableColumn(dbc, columnPath);

	}

	protected boolean _isLinkedToTableColumn(MCDBContainer dbc, String columnPath) {
		if (dbc.containsConst(columnPath) && (!dbc.isZColumn(columnPath) || dbc.getForeignInfoByColumn(columnPath) != null)) {
			return true;
		}
		return false;
	}

	/**カラムパスが主テーブルの項目とリンクしている場合trueを返します。*/
	public static boolean isLinkedToMainTableColumn(MCDBContainer dbc, String columnPath) {
		return object(_clazz)._isLinkedToMainTableColumn(dbc, columnPath);
	}

	protected boolean _isLinkedToMainTableColumn(MCDBContainer dbc, String columnPath) {
		return dbc.isZColumn(columnPath);
	}

	/** causeMessageListを格納するExceptionのメッセージＩＤを取得します。 */
	public static String getHeaderMsgId() {
		return object(_clazz)._getHeaderMsgId();
	}
	protected String _getHeaderMsgId() {
		return FXBAL0012;
	}

	/**
	 * 引数setColsの文字列が、引数dbcの項目として認識され、それがテーブルの項目とリンクしている場合、
	 * dbc.addSelectが実行されます。
	 * はじめにdbc.removeSelectAllが実行されるため、設定されていたselect句はなくなります。 
	 * 
	 * @param builder select句が追加されるクエリAPIビルダー
	 * @param setCols select句として追加されうるカラム
	 * @param isForeignEQ select句として追加される項目が参照先の場合に追加するJOIN句の演算子を=にするかどうか
	 * @return setSelect句の引数となった文字列の配列
	 */
	public static String[] setSelectAndFrom(MCQueryApiBuilder  builder, String[] setCols, boolean isForeignEQ) {
		return object(_clazz)._setSelectAndFrom(builder, setCols, isForeignEQ);
	}
	protected String[] _setSelectAndFrom(MCQueryApiBuilder builder, String[] setCols, boolean isForeignEQ) {
		List<String> l = new ArrayList<String>();
		
		builder.clearSelect();
		MCDBContainer dbc = builder.getBaseDbc();
		for (int i = 0; i < setCols.length; i++) {
			
			String s = setCols[i];
			if (isLinkedToTableColumn(dbc, s)) {
				if (isForeignEQ) {
					MCForeignInfo f = builder.getBaseDbc().getForeignInfoByColumn(s);
					if (f != null) {
						builder.activeForeignEQ(f);
					}

				}

				MCPermColumn col = dbc.getColumn$(s);
				builder.addSelect(s, col);
				l.add(s);
			}
		}
		return l.toArray(new String[0]);
	}
	
	/**
	 * 結合元のデータがnullではないのに結合先が存在しないような行を取得しないようにします。<p>
	 * 具体的には下記のSQL文が追加されます。
	 * <li>JOIN句
	 * <dd>defaultの外部結合LEFT OUTER JOIN
	 * <li>WHERE句
	 * <dd>AND (T.aaa IS NULL AND T.bbb IS NULL) OR (J1.aaa IS NOT NULL OR J1.bbb IS NOT NULL)<br>
	 * <br>
	 * カラム名からMCForeignInfoが取得できない場合、結合カラムの情報conditionArrayが取得できない場合は例外をthrowします。<br>
	 * DBコンテナ追加項目(Z項目)として定義されていない項目を引数colに設定した場合及び、
	 * 外部参照設定を関連付けていないZ項目を引数colに設定した場合に上記状態が発生します。
	 * 
	 */
	public static <R extends MCDBContainer> void activeForeignByColumnNotNullEQ(
			MCQueryApiBuilder builder, String col) {
		object(_clazz)._activeForeignByColumnNotNullEQ(builder, col);
	}

	/**
	 * {@link #activeForeignByColumnNotNullEQ(FX_DBCBase_L, String)}
	 */
	protected void _activeForeignByColumnNotNullEQ(
			MCQueryApiBuilder builder, String col) {
		MCForeignInfo info = builder.getBaseDbc().getForeignInfoByColumn(col);
		if (info == null) {
			throw new MCAppException(FXBAL0025);
		}
		String[][] ca = info.getConditionArray();
		if (ca == null) {
			throw new MCAppException(FXBAL0025);
		}
		_activeForeignByColumnNotNullEQImpl(builder, col);
	}

	/**
	 * {@link #activeForeignByColumnNotNullEQ(FX_DBCBase_L, String)}と同様の機能を持ちます。ただし、このメソッドは例外をthrowしません。<p>
	 * 
	 * 
	 */
	public static void activeForeignByColumnNotNullEQNE(
			MCQueryApiBuilder builder, String col) {
		object(_clazz)._activeForeignByColumnNotNullEQ(builder, col);
	}

	/**
	 * {@link #activeForeignByColumnNotNullEQNE(FX_DBCBase_L, String)}
	 */
	protected <R extends MCDBContainer> void _activeForeignByColumnNotNullEQNE(
			MCQueryApiBuilder builder, String col) {
		MCForeignInfo info = builder.getBaseDbc().getForeignInfoByColumn(col);
		if (info == null) {
			return;
		}
		String[][] ca = info.getConditionArray();
		if (ca == null) {
			return;
		}
		_activeForeignByColumnNotNullEQImpl(builder, col);
	}

	private void _activeForeignByColumnNotNullEQImpl(
			MCQueryApiBuilder builder, String col) {
		MCDBContainer dbc = builder.getBaseDbc();
		MCForeignInfo info =dbc.getForeignInfoByColumn(col);
		String[][] ca = info.getConditionArray();
		MCDBContainer foreignDbc = info.getRefTableDbc();

		builder.inactiveForeign(info);
		builder.activeForeign(info);
		builder.addSelect(col, dbc.getColumn$(col));

		MCPredicate mp = null;
		MCPredicate fp = null;
		for (String[] element : ca) {
			MCPermColumn mainCol = dbc.getColumn$(element[0]);
			MCPermColumn foreCol = foreignDbc.getColumn$(element[1]);
			mp = mp == null ? MCQueryApiBuilder.makeIsNull(mainCol) : mp.and(MCQueryApiBuilder.makeIsNull(mainCol));
			fp = fp == null ? MCQueryApiBuilder.makeIsNotNull(foreCol) : mp.or(MCQueryApiBuilder.makeIsNotNull(foreCol));
		}
		builder.addWhereWithAnd(mp.or(fp));
	}
	//FMCB CUSTOM END
}