package mcframe.serverFXBA.FXBAL0120;

import mcframe.commonCore.annotation.EI;

@EI
public class FXBAL_BatchLogManager extends FXBAL_BatchLogManager_FW {

}
