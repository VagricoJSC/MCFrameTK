package mcframe.serverFXBA.FXBAL0120;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.commonCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"BatchLogH"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BatchLogHR_FW_A extends MCConstRow {

	/**
	 *  ログＮＯ.<p>
	 *
	 */
	public static final String $batch_log_no = "batch_log_no";
	/**
	 *  サーバリクエストＮＯ.<p>
	 *
	 */
	public static final String $req_no = "req_no";
	/**
	 *  データ参照制御.<p>
	 *
	 */
	public static final String $data_ref_ctl = "data_ref_ctl";
	/**
	 *  開始日時.<p>
	 *
	 */
	public static final String $start_ts = "start_ts";
	/**
	 *  最終更新日時.<p>
	 *
	 */
	public static final String $last_ts = "last_ts";
	/**
	 *  ログインシーケンス.<p>
	 *
	 */
	public static final String $login_seq = "login_seq";
	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public static final String $emsg_seq = "emsg_seq";
	/**
	 *  拡張属性１.<p>
	 *
	 */
	public static final String $ext_attr1 = "ext_attr1";
	/**
	 *  拡張属性２.<p>
	 *
	 */
	public static final String $ext_attr2 = "ext_attr2";
	/**
	 *  拡張属性３.<p>
	 *
	 */
	public static final String $ext_attr3 = "ext_attr3";
	/**
	 *  実行ユーザＣＤ.<p>
	 *
	 */
	public static final String $usr_cd = "usr_cd";
	/**
	 *  処理グループＣＤ.<p>
	 *
	 */
	public static final String $gp_batch_grp_cd = "gp_batch_grp_cd";
	/**
	 *  呼出元モジュールＩＤ.<p>
	 *
	 */
	public static final String $call_module_id = "call_module_id";
	/**
	 *  呼出元ロジックＩＤ.<p>
	 *
	 */
	public static final String $call_logic_id = "call_logic_id";
	/**
	 *  呼出元オペレーションＩＤ.<p>
	 *
	 */
	public static final String $call_operation_id = "call_operation_id";
	/**
	 *  呼出元プログラムＩＤ.<p>
	 *
	 */
	public static final String $call_pg_id = "call_pg_id";
	/**
	 *  呼出元クライアント.<p>
	 *
	 */
	public static final String $call_clt_id = "call_clt_id";
	/**
	 *  呼出元ＰＬＳＱＬ.<p>
	 *
	 */
	public static final String $call_plsql_id = "call_plsql_id";
	/**
	 *  実行ロケールＣＤ.<p>
	 *
	 */
	public static final String $lcl_cd = "lcl_cd";
	/**
	 *  終了ＦＬＧ.<p>
	 *
	 */
	public static final String $end_flg = "end_flg";
	/**
	 *  警告ありＦＬＧ.<p>
	 *
	 */
	public static final String $warn_flg = "warn_flg";
	/**
	 *  備考１.<p>
	 *
	 */
	public static final String $rmrks1 = "rmrks1";
	/**
	 *  備考２.<p>
	 *
	 */
	public static final String $rmrks2 = "rmrks2";
	/**
	 *  備考３.<p>
	 *
	 */
	public static final String $rmrks3 = "rmrks3";
	/**
	 *  備考４.<p>
	 *
	 */
	public static final String $rmrks4 = "rmrks4";
	/**
	 *  備考５.<p>
	 *
	 */
	public static final String $rmrks5 = "rmrks5";
	/**
	 *  備考６.<p>
	 *
	 */
	public static final String $rmrks6 = "rmrks6";
	/**
	 *  備考７.<p>
	 *
	 */
	public static final String $rmrks7 = "rmrks7";
	/**
	 *  備考８.<p>
	 *
	 */
	public static final String $rmrks8 = "rmrks8";
	/**
	 *  備考９.<p>
	 *
	 */
	public static final String $rmrks9 = "rmrks9";
	/**
	 *  備考１０.<p>
	 *
	 */
	public static final String $rmrks10 = "rmrks10";


	public static final MCMeta batch_log_no_META = createStringMeta($batch_log_no, 15);
	public static final MCMeta req_no_META = createCommonMeta($req_no, mcframe.commonCore.meta.M_META.SRV_REQ_NO);
	public static final MCMeta data_ref_ctl_META = createStringMeta($data_ref_ctl, 50);
	public static final MCMeta start_ts_META = createCommonMeta($start_ts, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta last_ts_META = createCommonMeta($last_ts, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta login_seq_META = createCommonMeta($login_seq, mcframe.commonCore.meta.M_META.USR_LOGIN_SEQ);
	public static final MCMeta emsg_seq_META = createNumberMeta($emsg_seq, 22, 0, false);
	public static final MCMeta ext_attr1_META = createCommonMeta($ext_attr1, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta ext_attr2_META = createCommonMeta($ext_attr2, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta ext_attr3_META = createCommonMeta($ext_attr3, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta usr_cd_META = createCommonMeta($usr_cd, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta gp_batch_grp_cd_META = createStringMeta($gp_batch_grp_cd, 50);
	public static final MCMeta call_module_id_META = createCommonMeta($call_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta call_logic_id_META = createCommonMeta($call_logic_id, mcframe.commonCore.meta.M_META.LOGIC_ID);
	public static final MCMeta call_operation_id_META = createCommonMeta($call_operation_id, mcframe.commonCore.meta.M_META.OPERATION_ID);
	public static final MCMeta call_pg_id_META = createCommonMeta($call_pg_id, mcframe.commonCore.meta.M_META.FUNC_ID);
	public static final MCMeta call_clt_id_META = createCommonMeta($call_clt_id, mcframe.commonCore.meta.M_META.MACHINE);
	public static final MCMeta call_plsql_id_META = createStringMeta($call_plsql_id, 60);
	public static final MCMeta lcl_cd_META = createCommonMeta($lcl_cd, mcframe.commonCore.meta.M_META.LOCALE_CD);
	public static final MCMeta end_flg_META = createBooleanMeta($end_flg);
	public static final MCMeta warn_flg_META = createBooleanMeta($warn_flg);
	public static final MCMeta rmrks1_META = createStringMeta($rmrks1, 100);
	public static final MCMeta rmrks2_META = createStringMeta($rmrks2, 100);
	public static final MCMeta rmrks3_META = createStringMeta($rmrks3, 100);
	public static final MCMeta rmrks4_META = createStringMeta($rmrks4, 100);
	public static final MCMeta rmrks5_META = createStringMeta($rmrks5, 100);
	public static final MCMeta rmrks6_META = createStringMeta($rmrks6, 100);
	public static final MCMeta rmrks7_META = createStringMeta($rmrks7, 100);
	public static final MCMeta rmrks8_META = createStringMeta($rmrks8, 100);
	public static final MCMeta rmrks9_META = createStringMeta($rmrks9, 100);
	public static final MCMeta rmrks10_META = createStringMeta($rmrks10, 100);

	protected static final ConstMetaList<BatchLogHR> constMetas = new ConstMetaList<BatchLogHR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			batch_log_no_META,
			req_no_META,
			data_ref_ctl_META,
			start_ts_META,
			last_ts_META,
			login_seq_META,
			emsg_seq_META,
			ext_attr1_META,
			ext_attr2_META,
			ext_attr3_META,
			usr_cd_META,
			gp_batch_grp_cd_META,
			call_module_id_META,
			call_logic_id_META,
			call_operation_id_META,
			call_pg_id_META,
			call_clt_id_META,
			call_plsql_id_META,
			lcl_cd_META,
			end_flg_META,
			warn_flg_META,
			rmrks1_META,
			rmrks2_META,
			rmrks3_META,
			rmrks4_META,
			rmrks5_META,
			rmrks6_META,
			rmrks7_META,
			rmrks8_META,
			rmrks9_META,
			rmrks10_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public List<String> getKeys(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.getKeyList(aGroup);
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BatchLogHR_FW_A(ConstMetaList<? extends BatchLogHR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BatchLogHR clone() {
		return (BatchLogHR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BatchLogHR createInstance() {
		return (BatchLogHR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BatchLogHR getValues(String... names) {
		return (BatchLogHR) super.getValues(names);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	protected void fireValueChanged(String column,
							Comparable<?> newvalue, Comparable<?> oldvalue) {
	}


	/**
	 *  ログＮＯ.<p>
	 *
	 */
	public String batch_log_no() {
		return getConstString(offset + 0, $batch_log_no);
	}

	/**
	 *  ログＮＯ.<p>
	 *
	 */
	public void batch_log_no(String value) {
		setConstString(offset + 0, $batch_log_no, value);
	}


	/**
	 *  サーバリクエストＮＯ.<p>
	 *
	 */
	public String req_no() {
		return getConstString(offset + 1, $req_no);
	}

	/**
	 *  サーバリクエストＮＯ.<p>
	 *
	 */
	public void req_no(String value) {
		setConstString(offset + 1, $req_no, value);
	}


	/**
	 *  データ参照制御.<p>
	 *
	 */
	public String data_ref_ctl() {
		return getConstString(offset + 2, $data_ref_ctl);
	}

	/**
	 *  データ参照制御.<p>
	 *
	 */
	public void data_ref_ctl(String value) {
		setConstString(offset + 2, $data_ref_ctl, value);
	}


	/**
	 *  開始日時.<p>
	 *
	 */
	public MCTimestamp start_ts() {
		return getConstTimestamp(offset + 3, $start_ts);
	}

	/**
	 *  開始日時.<p>
	 *
	 */
	public void start_ts(MCTimestamp value) {
		setConstTimestamp(offset + 3, $start_ts, value);
	}


	/**
	 *  最終更新日時.<p>
	 *
	 */
	public MCTimestamp last_ts() {
		return getConstTimestamp(offset + 4, $last_ts);
	}

	/**
	 *  最終更新日時.<p>
	 *
	 */
	public void last_ts(MCTimestamp value) {
		setConstTimestamp(offset + 4, $last_ts, value);
	}


	/**
	 *  ログインシーケンス.<p>
	 *
	 */
	public String login_seq() {
		return getConstString(offset + 5, $login_seq);
	}

	/**
	 *  ログインシーケンス.<p>
	 *
	 */
	public void login_seq(String value) {
		setConstString(offset + 5, $login_seq, value);
	}


	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public MCNumber emsg_seq() {
		return getConstNumber(offset + 6, $emsg_seq);
	}

	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public void emsg_seq(MCNumber value) {
		setConstNumber(offset + 6, $emsg_seq, value);
	}

	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public void emsg_seq(int value) {
		setConstNumber(offset + 6, $emsg_seq, value);
	}

	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public void emsg_seq(long value) {
		setConstNumber(offset + 6, $emsg_seq, value);
	}

	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public void emsg_seq(float value) {
		setConstNumber(offset + 6, $emsg_seq, value);
	}

	/**
	 *  終了ログ連番.<p>
	 *
	 */
	public void emsg_seq(double value) {
		setConstNumber(offset + 6, $emsg_seq, value);
	}


	/**
	 *  拡張属性１.<p>
	 *
	 */
	public String ext_attr1() {
		return getConstString(offset + 7, $ext_attr1);
	}

	/**
	 *  拡張属性１.<p>
	 *
	 */
	public void ext_attr1(String value) {
		setConstString(offset + 7, $ext_attr1, value);
	}


	/**
	 *  拡張属性２.<p>
	 *
	 */
	public String ext_attr2() {
		return getConstString(offset + 8, $ext_attr2);
	}

	/**
	 *  拡張属性２.<p>
	 *
	 */
	public void ext_attr2(String value) {
		setConstString(offset + 8, $ext_attr2, value);
	}


	/**
	 *  拡張属性３.<p>
	 *
	 */
	public String ext_attr3() {
		return getConstString(offset + 9, $ext_attr3);
	}

	/**
	 *  拡張属性３.<p>
	 *
	 */
	public void ext_attr3(String value) {
		setConstString(offset + 9, $ext_attr3, value);
	}


	/**
	 *  実行ユーザＣＤ.<p>
	 *
	 */
	public String usr_cd() {
		return getConstString(offset + 10, $usr_cd);
	}

	/**
	 *  実行ユーザＣＤ.<p>
	 *
	 */
	public void usr_cd(String value) {
		setConstString(offset + 10, $usr_cd, value);
	}


	/**
	 *  処理グループＣＤ.<p>
	 *
	 */
	public String gp_batch_grp_cd() {
		return getConstString(offset + 11, $gp_batch_grp_cd);
	}

	/**
	 *  処理グループＣＤ.<p>
	 *
	 */
	public void gp_batch_grp_cd(String value) {
		setConstString(offset + 11, $gp_batch_grp_cd, value);
	}


	/**
	 *  呼出元モジュールＩＤ.<p>
	 *
	 */
	public String call_module_id() {
		return getConstString(offset + 12, $call_module_id);
	}

	/**
	 *  呼出元モジュールＩＤ.<p>
	 *
	 */
	public void call_module_id(String value) {
		setConstString(offset + 12, $call_module_id, value);
	}


	/**
	 *  呼出元ロジックＩＤ.<p>
	 *
	 */
	public String call_logic_id() {
		return getConstString(offset + 13, $call_logic_id);
	}

	/**
	 *  呼出元ロジックＩＤ.<p>
	 *
	 */
	public void call_logic_id(String value) {
		setConstString(offset + 13, $call_logic_id, value);
	}


	/**
	 *  呼出元オペレーションＩＤ.<p>
	 *
	 */
	public String call_operation_id() {
		return getConstString(offset + 14, $call_operation_id);
	}

	/**
	 *  呼出元オペレーションＩＤ.<p>
	 *
	 */
	public void call_operation_id(String value) {
		setConstString(offset + 14, $call_operation_id, value);
	}


	/**
	 *  呼出元プログラムＩＤ.<p>
	 *
	 */
	public String call_pg_id() {
		return getConstString(offset + 15, $call_pg_id);
	}

	/**
	 *  呼出元プログラムＩＤ.<p>
	 *
	 */
	public void call_pg_id(String value) {
		setConstString(offset + 15, $call_pg_id, value);
	}


	/**
	 *  呼出元クライアント.<p>
	 *
	 */
	public String call_clt_id() {
		return getConstString(offset + 16, $call_clt_id);
	}

	/**
	 *  呼出元クライアント.<p>
	 *
	 */
	public void call_clt_id(String value) {
		setConstString(offset + 16, $call_clt_id, value);
	}


	/**
	 *  呼出元ＰＬＳＱＬ.<p>
	 *
	 */
	public String call_plsql_id() {
		return getConstString(offset + 17, $call_plsql_id);
	}

	/**
	 *  呼出元ＰＬＳＱＬ.<p>
	 *
	 */
	public void call_plsql_id(String value) {
		setConstString(offset + 17, $call_plsql_id, value);
	}


	/**
	 *  実行ロケールＣＤ.<p>
	 *
	 */
	public String lcl_cd() {
		return getConstString(offset + 18, $lcl_cd);
	}

	/**
	 *  実行ロケールＣＤ.<p>
	 *
	 */
	public void lcl_cd(String value) {
		setConstString(offset + 18, $lcl_cd, value);
	}


	/**
	 *  終了ＦＬＧ.<p>
	 *
	 */
	public boolean end_flg() {
		return getConstBoolean(offset + 19, $end_flg);
	}

	/**
	 *  終了ＦＬＧ.<p>
	 *
	 */
	public void end_flg(boolean value) {
		setConstBoolean(offset + 19, $end_flg, value);
	}


	/**
	 *  警告ありＦＬＧ.<p>
	 *
	 */
	public boolean warn_flg() {
		return getConstBoolean(offset + 20, $warn_flg);
	}

	/**
	 *  警告ありＦＬＧ.<p>
	 *
	 */
	public void warn_flg(boolean value) {
		setConstBoolean(offset + 20, $warn_flg, value);
	}


	/**
	 *  備考１.<p>
	 *
	 */
	public String rmrks1() {
		return getConstString(offset + 21, $rmrks1);
	}

	/**
	 *  備考１.<p>
	 *
	 */
	public void rmrks1(String value) {
		setConstString(offset + 21, $rmrks1, value);
	}


	/**
	 *  備考２.<p>
	 *
	 */
	public String rmrks2() {
		return getConstString(offset + 22, $rmrks2);
	}

	/**
	 *  備考２.<p>
	 *
	 */
	public void rmrks2(String value) {
		setConstString(offset + 22, $rmrks2, value);
	}


	/**
	 *  備考３.<p>
	 *
	 */
	public String rmrks3() {
		return getConstString(offset + 23, $rmrks3);
	}

	/**
	 *  備考３.<p>
	 *
	 */
	public void rmrks3(String value) {
		setConstString(offset + 23, $rmrks3, value);
	}


	/**
	 *  備考４.<p>
	 *
	 */
	public String rmrks4() {
		return getConstString(offset + 24, $rmrks4);
	}

	/**
	 *  備考４.<p>
	 *
	 */
	public void rmrks4(String value) {
		setConstString(offset + 24, $rmrks4, value);
	}


	/**
	 *  備考５.<p>
	 *
	 */
	public String rmrks5() {
		return getConstString(offset + 25, $rmrks5);
	}

	/**
	 *  備考５.<p>
	 *
	 */
	public void rmrks5(String value) {
		setConstString(offset + 25, $rmrks5, value);
	}


	/**
	 *  備考６.<p>
	 *
	 */
	public String rmrks6() {
		return getConstString(offset + 26, $rmrks6);
	}

	/**
	 *  備考６.<p>
	 *
	 */
	public void rmrks6(String value) {
		setConstString(offset + 26, $rmrks6, value);
	}


	/**
	 *  備考７.<p>
	 *
	 */
	public String rmrks7() {
		return getConstString(offset + 27, $rmrks7);
	}

	/**
	 *  備考７.<p>
	 *
	 */
	public void rmrks7(String value) {
		setConstString(offset + 27, $rmrks7, value);
	}


	/**
	 *  備考８.<p>
	 *
	 */
	public String rmrks8() {
		return getConstString(offset + 28, $rmrks8);
	}

	/**
	 *  備考８.<p>
	 *
	 */
	public void rmrks8(String value) {
		setConstString(offset + 28, $rmrks8, value);
	}


	/**
	 *  備考９.<p>
	 *
	 */
	public String rmrks9() {
		return getConstString(offset + 29, $rmrks9);
	}

	/**
	 *  備考９.<p>
	 *
	 */
	public void rmrks9(String value) {
		setConstString(offset + 29, $rmrks9, value);
	}


	/**
	 *  備考１０.<p>
	 *
	 */
	public String rmrks10() {
		return getConstString(offset + 30, $rmrks10);
	}

	/**
	 *  備考１０.<p>
	 *
	 */
	public void rmrks10(String value) {
		setConstString(offset + 30, $rmrks10, value);
	}


	public String getString(String name) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			return batch_log_no();
		}
		if ($req_no.equalsIgnoreCase(name)) {
			return req_no();
		}
		if ($data_ref_ctl.equalsIgnoreCase(name)) {
			return data_ref_ctl();
		}
		if ($login_seq.equalsIgnoreCase(name)) {
			return login_seq();
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			return ext_attr1();
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			return ext_attr2();
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			return ext_attr3();
		}
		if ($usr_cd.equalsIgnoreCase(name)) {
			return usr_cd();
		}
		if ($gp_batch_grp_cd.equalsIgnoreCase(name)) {
			return gp_batch_grp_cd();
		}
		if ($call_module_id.equalsIgnoreCase(name)) {
			return call_module_id();
		}
		if ($call_logic_id.equalsIgnoreCase(name)) {
			return call_logic_id();
		}
		if ($call_operation_id.equalsIgnoreCase(name)) {
			return call_operation_id();
		}
		if ($call_pg_id.equalsIgnoreCase(name)) {
			return call_pg_id();
		}
		if ($call_clt_id.equalsIgnoreCase(name)) {
			return call_clt_id();
		}
		if ($call_plsql_id.equalsIgnoreCase(name)) {
			return call_plsql_id();
		}
		if ($lcl_cd.equalsIgnoreCase(name)) {
			return lcl_cd();
		}
		if ($rmrks1.equalsIgnoreCase(name)) {
			return rmrks1();
		}
		if ($rmrks2.equalsIgnoreCase(name)) {
			return rmrks2();
		}
		if ($rmrks3.equalsIgnoreCase(name)) {
			return rmrks3();
		}
		if ($rmrks4.equalsIgnoreCase(name)) {
			return rmrks4();
		}
		if ($rmrks5.equalsIgnoreCase(name)) {
			return rmrks5();
		}
		if ($rmrks6.equalsIgnoreCase(name)) {
			return rmrks6();
		}
		if ($rmrks7.equalsIgnoreCase(name)) {
			return rmrks7();
		}
		if ($rmrks8.equalsIgnoreCase(name)) {
			return rmrks8();
		}
		if ($rmrks9.equalsIgnoreCase(name)) {
			return rmrks9();
		}
		if ($rmrks10.equalsIgnoreCase(name)) {
			return rmrks10();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			return emsg_seq();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($start_ts.equalsIgnoreCase(name)) {
			return start_ts();
		}
		if ($last_ts.equalsIgnoreCase(name)) {
			return last_ts();
		}
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		if ($end_flg.equalsIgnoreCase(name)) {
			return end_flg();
		}
		if ($warn_flg.equalsIgnoreCase(name)) {
			return warn_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			return batch_log_no();
		}
		if ($req_no.equalsIgnoreCase(name)) {
			return req_no();
		}
		if ($data_ref_ctl.equalsIgnoreCase(name)) {
			return data_ref_ctl();
		}
		if ($login_seq.equalsIgnoreCase(name)) {
			return login_seq();
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			return ext_attr1();
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			return ext_attr2();
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			return ext_attr3();
		}
		if ($usr_cd.equalsIgnoreCase(name)) {
			return usr_cd();
		}
		if ($gp_batch_grp_cd.equalsIgnoreCase(name)) {
			return gp_batch_grp_cd();
		}
		if ($call_module_id.equalsIgnoreCase(name)) {
			return call_module_id();
		}
		if ($call_logic_id.equalsIgnoreCase(name)) {
			return call_logic_id();
		}
		if ($call_operation_id.equalsIgnoreCase(name)) {
			return call_operation_id();
		}
		if ($call_pg_id.equalsIgnoreCase(name)) {
			return call_pg_id();
		}
		if ($call_clt_id.equalsIgnoreCase(name)) {
			return call_clt_id();
		}
		if ($call_plsql_id.equalsIgnoreCase(name)) {
			return call_plsql_id();
		}
		if ($lcl_cd.equalsIgnoreCase(name)) {
			return lcl_cd();
		}
		if ($rmrks1.equalsIgnoreCase(name)) {
			return rmrks1();
		}
		if ($rmrks2.equalsIgnoreCase(name)) {
			return rmrks2();
		}
		if ($rmrks3.equalsIgnoreCase(name)) {
			return rmrks3();
		}
		if ($rmrks4.equalsIgnoreCase(name)) {
			return rmrks4();
		}
		if ($rmrks5.equalsIgnoreCase(name)) {
			return rmrks5();
		}
		if ($rmrks6.equalsIgnoreCase(name)) {
			return rmrks6();
		}
		if ($rmrks7.equalsIgnoreCase(name)) {
			return rmrks7();
		}
		if ($rmrks8.equalsIgnoreCase(name)) {
			return rmrks8();
		}
		if ($rmrks9.equalsIgnoreCase(name)) {
			return rmrks9();
		}
		if ($rmrks10.equalsIgnoreCase(name)) {
			return rmrks10();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			return emsg_seq();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($start_ts.equalsIgnoreCase(name)) {
			return start_ts();
		}
		if ($last_ts.equalsIgnoreCase(name)) {
			return last_ts();
		}
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($end_flg.equalsIgnoreCase(name)) {
			return end_flg();
		}
		if ($warn_flg.equalsIgnoreCase(name)) {
			return warn_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			batch_log_no(value);
			return;
		}
		if ($req_no.equalsIgnoreCase(name)) {
			req_no(value);
			return;
		}
		if ($data_ref_ctl.equalsIgnoreCase(name)) {
			data_ref_ctl(value);
			return;
		}
		if ($login_seq.equalsIgnoreCase(name)) {
			login_seq(value);
			return;
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			ext_attr1(value);
			return;
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			ext_attr2(value);
			return;
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			ext_attr3(value);
			return;
		}
		if ($usr_cd.equalsIgnoreCase(name)) {
			usr_cd(value);
			return;
		}
		if ($gp_batch_grp_cd.equalsIgnoreCase(name)) {
			gp_batch_grp_cd(value);
			return;
		}
		if ($call_module_id.equalsIgnoreCase(name)) {
			call_module_id(value);
			return;
		}
		if ($call_logic_id.equalsIgnoreCase(name)) {
			call_logic_id(value);
			return;
		}
		if ($call_operation_id.equalsIgnoreCase(name)) {
			call_operation_id(value);
			return;
		}
		if ($call_pg_id.equalsIgnoreCase(name)) {
			call_pg_id(value);
			return;
		}
		if ($call_clt_id.equalsIgnoreCase(name)) {
			call_clt_id(value);
			return;
		}
		if ($call_plsql_id.equalsIgnoreCase(name)) {
			call_plsql_id(value);
			return;
		}
		if ($lcl_cd.equalsIgnoreCase(name)) {
			lcl_cd(value);
			return;
		}
		if ($rmrks1.equalsIgnoreCase(name)) {
			rmrks1(value);
			return;
		}
		if ($rmrks2.equalsIgnoreCase(name)) {
			rmrks2(value);
			return;
		}
		if ($rmrks3.equalsIgnoreCase(name)) {
			rmrks3(value);
			return;
		}
		if ($rmrks4.equalsIgnoreCase(name)) {
			rmrks4(value);
			return;
		}
		if ($rmrks5.equalsIgnoreCase(name)) {
			rmrks5(value);
			return;
		}
		if ($rmrks6.equalsIgnoreCase(name)) {
			rmrks6(value);
			return;
		}
		if ($rmrks7.equalsIgnoreCase(name)) {
			rmrks7(value);
			return;
		}
		if ($rmrks8.equalsIgnoreCase(name)) {
			rmrks8(value);
			return;
		}
		if ($rmrks9.equalsIgnoreCase(name)) {
			rmrks9(value);
			return;
		}
		if ($rmrks10.equalsIgnoreCase(name)) {
			rmrks10(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($start_ts.equalsIgnoreCase(name)) {
			start_ts(value);
			return;
		}
		if ($last_ts.equalsIgnoreCase(name)) {
			last_ts(value);
			return;
		}
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($end_flg.equalsIgnoreCase(name)) {
			end_flg(value);
			return;
		}
		if ($warn_flg.equalsIgnoreCase(name)) {
			warn_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			batch_log_no(value);
			return;
		}
		if ($req_no.equalsIgnoreCase(name)) {
			req_no(value);
			return;
		}
		if ($data_ref_ctl.equalsIgnoreCase(name)) {
			data_ref_ctl(value);
			return;
		}
		if ($login_seq.equalsIgnoreCase(name)) {
			login_seq(value);
			return;
		}
		if ($ext_attr1.equalsIgnoreCase(name)) {
			ext_attr1(value);
			return;
		}
		if ($ext_attr2.equalsIgnoreCase(name)) {
			ext_attr2(value);
			return;
		}
		if ($ext_attr3.equalsIgnoreCase(name)) {
			ext_attr3(value);
			return;
		}
		if ($usr_cd.equalsIgnoreCase(name)) {
			usr_cd(value);
			return;
		}
		if ($gp_batch_grp_cd.equalsIgnoreCase(name)) {
			gp_batch_grp_cd(value);
			return;
		}
		if ($call_module_id.equalsIgnoreCase(name)) {
			call_module_id(value);
			return;
		}
		if ($call_logic_id.equalsIgnoreCase(name)) {
			call_logic_id(value);
			return;
		}
		if ($call_operation_id.equalsIgnoreCase(name)) {
			call_operation_id(value);
			return;
		}
		if ($call_pg_id.equalsIgnoreCase(name)) {
			call_pg_id(value);
			return;
		}
		if ($call_clt_id.equalsIgnoreCase(name)) {
			call_clt_id(value);
			return;
		}
		if ($call_plsql_id.equalsIgnoreCase(name)) {
			call_plsql_id(value);
			return;
		}
		if ($lcl_cd.equalsIgnoreCase(name)) {
			lcl_cd(value);
			return;
		}
		if ($rmrks1.equalsIgnoreCase(name)) {
			rmrks1(value);
			return;
		}
		if ($rmrks2.equalsIgnoreCase(name)) {
			rmrks2(value);
			return;
		}
		if ($rmrks3.equalsIgnoreCase(name)) {
			rmrks3(value);
			return;
		}
		if ($rmrks4.equalsIgnoreCase(name)) {
			rmrks4(value);
			return;
		}
		if ($rmrks5.equalsIgnoreCase(name)) {
			rmrks5(value);
			return;
		}
		if ($rmrks6.equalsIgnoreCase(name)) {
			rmrks6(value);
			return;
		}
		if ($rmrks7.equalsIgnoreCase(name)) {
			rmrks7(value);
			return;
		}
		if ($rmrks8.equalsIgnoreCase(name)) {
			rmrks8(value);
			return;
		}
		if ($rmrks9.equalsIgnoreCase(name)) {
			rmrks9(value);
			return;
		}
		if ($rmrks10.equalsIgnoreCase(name)) {
			rmrks10(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($emsg_seq.equalsIgnoreCase(name)) {
			emsg_seq(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($start_ts.equalsIgnoreCase(name)) {
			start_ts(value);
			return;
		}
		if ($last_ts.equalsIgnoreCase(name)) {
			last_ts(value);
			return;
		}
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($end_flg.equalsIgnoreCase(name)) {
			end_flg(value);
			return;
		}
		if ($warn_flg.equalsIgnoreCase(name)) {
			warn_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

