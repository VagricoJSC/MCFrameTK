package mcframe.serverFXBA.FXBAL0120;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.commonCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"BatchLogMsg"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BatchLogMsgR_FW_A extends MCConstRow {

	/**
	 *  ログＮＯ.<p>
	 *
	 */
	public static final String $batch_log_no = "batch_log_no";
	/**
	 *  連番.<p>
	 *
	 */
	public static final String $seq = "seq";
	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public static final String $log_sub_key1 = "log_sub_key1";
	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public static final String $log_sub_key2 = "log_sub_key2";
	/**
	 *  バッチログ区分.<p>
	 *
	 */
	public static final String $batch_log_typ = "batch_log_typ";
	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public static final String $msg_id = "msg_id";
	/**
	 *  メッセージレベル.<p>
	 *
	 */
	public static final String $msg_lvl = "msg_lvl";
	/**
	 *  メッセージ本文.<p>
	 *
	 */
	public static final String $msg_txt = "msg_txt";
	/**
	 *  ログ出力日時.<p>
	 *
	 */
	public static final String $log_ts = "log_ts";
	/**
	 *  パラメータ１.<p>
	 *
	 */
	public static final String $prm01 = "prm01";
	/**
	 *  パラメータ２.<p>
	 *
	 */
	public static final String $prm02 = "prm02";
	/**
	 *  パラメータ３.<p>
	 *
	 */
	public static final String $prm03 = "prm03";
	/**
	 *  パラメータ４.<p>
	 *
	 */
	public static final String $prm04 = "prm04";
	/**
	 *  パラメータ５.<p>
	 *
	 */
	public static final String $prm05 = "prm05";
	/**
	 *  パラメータ６.<p>
	 *
	 */
	public static final String $prm06 = "prm06";
	/**
	 *  パラメータ７.<p>
	 *
	 */
	public static final String $prm07 = "prm07";
	/**
	 *  パラメータ８.<p>
	 *
	 */
	public static final String $prm08 = "prm08";
	/**
	 *  パラメータ９.<p>
	 *
	 */
	public static final String $prm09 = "prm09";
	/**
	 *  パラメータ１０.<p>
	 *
	 */
	public static final String $prm10 = "prm10";
	/**
	 *  パラメータ１１.<p>
	 *
	 */
	public static final String $prm11 = "prm11";
	/**
	 *  パラメータ１２.<p>
	 *
	 */
	public static final String $prm12 = "prm12";
	/**
	 *  パラメータ１３.<p>
	 *
	 */
	public static final String $prm13 = "prm13";
	/**
	 *  パラメータ１４.<p>
	 *
	 */
	public static final String $prm14 = "prm14";
	/**
	 *  パラメータ１５.<p>
	 *
	 */
	public static final String $prm15 = "prm15";
	/**
	 *  パラメータ１６.<p>
	 *
	 */
	public static final String $prm16 = "prm16";
	/**
	 *  パラメータ１７.<p>
	 *
	 */
	public static final String $prm17 = "prm17";
	/**
	 *  パラメータ１８.<p>
	 *
	 */
	public static final String $prm18 = "prm18";
	/**
	 *  パラメータ１９.<p>
	 *
	 */
	public static final String $prm19 = "prm19";
	/**
	 *  パラメータ２０.<p>
	 *
	 */
	public static final String $prm20 = "prm20";
	/**
	 *  パラメータ２１.<p>
	 *
	 */
	public static final String $prm21 = "prm21";
	/**
	 *  パラメータ２２.<p>
	 *
	 */
	public static final String $prm22 = "prm22";
	/**
	 *  パラメータ２３.<p>
	 *
	 */
	public static final String $prm23 = "prm23";
	/**
	 *  パラメータ２４.<p>
	 *
	 */
	public static final String $prm24 = "prm24";
	/**
	 *  パラメータ２５.<p>
	 *
	 */
	public static final String $prm25 = "prm25";
	/**
	 *  パラメータ２６.<p>
	 *
	 */
	public static final String $prm26 = "prm26";
	/**
	 *  パラメータ２７.<p>
	 *
	 */
	public static final String $prm27 = "prm27";
	/**
	 *  パラメータ２８.<p>
	 *
	 */
	public static final String $prm28 = "prm28";
	/**
	 *  パラメータ２９.<p>
	 *
	 */
	public static final String $prm29 = "prm29";
	/**
	 *  パラメータ３０.<p>
	 *
	 */
	public static final String $prm30 = "prm30";
	/**
	 *  パラメータ３１.<p>
	 *
	 */
	public static final String $prm31 = "prm31";
	/**
	 *  パラメータ３２.<p>
	 *
	 */
	public static final String $prm32 = "prm32";
	/**
	 *  パラメータ３３.<p>
	 *
	 */
	public static final String $prm33 = "prm33";
	/**
	 *  パラメータ３４.<p>
	 *
	 */
	public static final String $prm34 = "prm34";
	/**
	 *  パラメータ３５.<p>
	 *
	 */
	public static final String $prm35 = "prm35";
	/**
	 *  パラメータ３６.<p>
	 *
	 */
	public static final String $prm36 = "prm36";
	/**
	 *  パラメータ３７.<p>
	 *
	 */
	public static final String $prm37 = "prm37";
	/**
	 *  パラメータ３８.<p>
	 *
	 */
	public static final String $prm38 = "prm38";
	/**
	 *  パラメータ３９.<p>
	 *
	 */
	public static final String $prm39 = "prm39";
	/**
	 *  パラメータ４０.<p>
	 *
	 */
	public static final String $prm40 = "prm40";


	public static final MCMeta batch_log_no_META = createStringMeta($batch_log_no, 15);
	public static final MCMeta seq_META = createNumberMeta($seq, 22, 0, false);
	public static final MCMeta log_sub_key1_META = createNumberMeta($log_sub_key1, 9, 0, false);
	public static final MCMeta log_sub_key2_META = createNumberMeta($log_sub_key2, 9, 0, false);
	public static final MCMeta batch_log_typ_META = createStringMeta($batch_log_typ, 1);
	public static final MCMeta msg_id_META = createCommonMeta($msg_id, mcframe.commonCore.meta.M_META.MSG_ID);
	public static final MCMeta msg_lvl_META = createCommonMeta($msg_lvl, mcframe.commonCore.meta.M_META.MSG_LVL);
	public static final MCMeta msg_txt_META = createCommonMeta($msg_txt, mcframe.commonCore.meta.M_META.MSG);
	public static final MCMeta log_ts_META = createCommonMeta($log_ts, mcframe.commonCore.meta.M_META.TS);
	public static final MCMeta prm01_META = createCommonMeta($prm01, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm02_META = createCommonMeta($prm02, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm03_META = createCommonMeta($prm03, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm04_META = createCommonMeta($prm04, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm05_META = createCommonMeta($prm05, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm06_META = createCommonMeta($prm06, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm07_META = createCommonMeta($prm07, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm08_META = createCommonMeta($prm08, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm09_META = createCommonMeta($prm09, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm10_META = createCommonMeta($prm10, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm11_META = createCommonMeta($prm11, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm12_META = createCommonMeta($prm12, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm13_META = createCommonMeta($prm13, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm14_META = createCommonMeta($prm14, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm15_META = createCommonMeta($prm15, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm16_META = createCommonMeta($prm16, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm17_META = createCommonMeta($prm17, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm18_META = createCommonMeta($prm18, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm19_META = createCommonMeta($prm19, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm20_META = createCommonMeta($prm20, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm21_META = createCommonMeta($prm21, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm22_META = createCommonMeta($prm22, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm23_META = createCommonMeta($prm23, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm24_META = createCommonMeta($prm24, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm25_META = createCommonMeta($prm25, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm26_META = createCommonMeta($prm26, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm27_META = createCommonMeta($prm27, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm28_META = createCommonMeta($prm28, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm29_META = createCommonMeta($prm29, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm30_META = createCommonMeta($prm30, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm31_META = createCommonMeta($prm31, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm32_META = createCommonMeta($prm32, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm33_META = createCommonMeta($prm33, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm34_META = createCommonMeta($prm34, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm35_META = createCommonMeta($prm35, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm36_META = createCommonMeta($prm36, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm37_META = createCommonMeta($prm37, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm38_META = createCommonMeta($prm38, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm39_META = createCommonMeta($prm39, mcframe.commonCore.meta.M_META.LOG_PRM);
	public static final MCMeta prm40_META = createCommonMeta($prm40, mcframe.commonCore.meta.M_META.LOG_PRM);

	protected static final ConstMetaList<BatchLogMsgR> constMetas = new ConstMetaList<BatchLogMsgR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			batch_log_no_META,
			seq_META,
			log_sub_key1_META,
			log_sub_key2_META,
			batch_log_typ_META,
			msg_id_META,
			msg_lvl_META,
			msg_txt_META,
			log_ts_META,
			prm01_META,
			prm02_META,
			prm03_META,
			prm04_META,
			prm05_META,
			prm06_META,
			prm07_META,
			prm08_META,
			prm09_META,
			prm10_META,
			prm11_META,
			prm12_META,
			prm13_META,
			prm14_META,
			prm15_META,
			prm16_META,
			prm17_META,
			prm18_META,
			prm19_META,
			prm20_META,
			prm21_META,
			prm22_META,
			prm23_META,
			prm24_META,
			prm25_META,
			prm26_META,
			prm27_META,
			prm28_META,
			prm29_META,
			prm30_META,
			prm31_META,
			prm32_META,
			prm33_META,
			prm34_META,
			prm35_META,
			prm36_META,
			prm37_META,
			prm38_META,
			prm39_META,
			prm40_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public List<String> getKeys(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.getKeyList(aGroup);
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BatchLogMsgR_FW_A(ConstMetaList<? extends BatchLogMsgR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BatchLogMsgR clone() {
		return (BatchLogMsgR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BatchLogMsgR createInstance() {
		return (BatchLogMsgR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BatchLogMsgR getValues(String... names) {
		return (BatchLogMsgR) super.getValues(names);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	protected void fireValueChanged(String column,
							Comparable<?> newvalue, Comparable<?> oldvalue) {
	}


	/**
	 *  ログＮＯ.<p>
	 *
	 */
	public String batch_log_no() {
		return getConstString(offset + 0, $batch_log_no);
	}

	/**
	 *  ログＮＯ.<p>
	 *
	 */
	public void batch_log_no(String value) {
		setConstString(offset + 0, $batch_log_no, value);
	}


	/**
	 *  連番.<p>
	 *
	 */
	public MCNumber seq() {
		return getConstNumber(offset + 1, $seq);
	}

	/**
	 *  連番.<p>
	 *
	 */
	public void seq(MCNumber value) {
		setConstNumber(offset + 1, $seq, value);
	}

	/**
	 *  連番.<p>
	 *
	 */
	public void seq(int value) {
		setConstNumber(offset + 1, $seq, value);
	}

	/**
	 *  連番.<p>
	 *
	 */
	public void seq(long value) {
		setConstNumber(offset + 1, $seq, value);
	}

	/**
	 *  連番.<p>
	 *
	 */
	public void seq(float value) {
		setConstNumber(offset + 1, $seq, value);
	}

	/**
	 *  連番.<p>
	 *
	 */
	public void seq(double value) {
		setConstNumber(offset + 1, $seq, value);
	}


	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public MCNumber log_sub_key1() {
		return getConstNumber(offset + 2, $log_sub_key1);
	}

	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public void log_sub_key1(MCNumber value) {
		setConstNumber(offset + 2, $log_sub_key1, value);
	}

	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public void log_sub_key1(int value) {
		setConstNumber(offset + 2, $log_sub_key1, value);
	}

	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public void log_sub_key1(long value) {
		setConstNumber(offset + 2, $log_sub_key1, value);
	}

	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public void log_sub_key1(float value) {
		setConstNumber(offset + 2, $log_sub_key1, value);
	}

	/**
	 *  ログサブキー１.<p>
	 *
	 */
	public void log_sub_key1(double value) {
		setConstNumber(offset + 2, $log_sub_key1, value);
	}


	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public MCNumber log_sub_key2() {
		return getConstNumber(offset + 3, $log_sub_key2);
	}

	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public void log_sub_key2(MCNumber value) {
		setConstNumber(offset + 3, $log_sub_key2, value);
	}

	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public void log_sub_key2(int value) {
		setConstNumber(offset + 3, $log_sub_key2, value);
	}

	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public void log_sub_key2(long value) {
		setConstNumber(offset + 3, $log_sub_key2, value);
	}

	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public void log_sub_key2(float value) {
		setConstNumber(offset + 3, $log_sub_key2, value);
	}

	/**
	 *  ログサブキー２.<p>
	 *
	 */
	public void log_sub_key2(double value) {
		setConstNumber(offset + 3, $log_sub_key2, value);
	}


	/**
	 *  バッチログ区分.<p>
	 *
	 */
	public String batch_log_typ() {
		return getConstString(offset + 4, $batch_log_typ);
	}

	/**
	 *  バッチログ区分.<p>
	 *
	 */
	public void batch_log_typ(String value) {
		setConstString(offset + 4, $batch_log_typ, value);
	}


	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public String msg_id() {
		return getConstString(offset + 5, $msg_id);
	}

	/**
	 *  メッセージＩＤ.<p>
	 *
	 */
	public void msg_id(String value) {
		setConstString(offset + 5, $msg_id, value);
	}


	/**
	 *  メッセージレベル.<p>
	 *
	 */
	public String msg_lvl() {
		return getConstString(offset + 6, $msg_lvl);
	}

	/**
	 *  メッセージレベル.<p>
	 *
	 */
	public void msg_lvl(String value) {
		setConstString(offset + 6, $msg_lvl, value);
	}


	/**
	 *  メッセージ本文.<p>
	 *
	 */
	public String msg_txt() {
		return getConstString(offset + 7, $msg_txt);
	}

	/**
	 *  メッセージ本文.<p>
	 *
	 */
	public void msg_txt(String value) {
		setConstString(offset + 7, $msg_txt, value);
	}


	/**
	 *  ログ出力日時.<p>
	 *
	 */
	public MCTimestamp log_ts() {
		return getConstTimestamp(offset + 8, $log_ts);
	}

	/**
	 *  ログ出力日時.<p>
	 *
	 */
	public void log_ts(MCTimestamp value) {
		setConstTimestamp(offset + 8, $log_ts, value);
	}


	/**
	 *  パラメータ１.<p>
	 *
	 */
	public String prm01() {
		return getConstString(offset + 9, $prm01);
	}

	/**
	 *  パラメータ１.<p>
	 *
	 */
	public void prm01(String value) {
		setConstString(offset + 9, $prm01, value);
	}


	/**
	 *  パラメータ２.<p>
	 *
	 */
	public String prm02() {
		return getConstString(offset + 10, $prm02);
	}

	/**
	 *  パラメータ２.<p>
	 *
	 */
	public void prm02(String value) {
		setConstString(offset + 10, $prm02, value);
	}


	/**
	 *  パラメータ３.<p>
	 *
	 */
	public String prm03() {
		return getConstString(offset + 11, $prm03);
	}

	/**
	 *  パラメータ３.<p>
	 *
	 */
	public void prm03(String value) {
		setConstString(offset + 11, $prm03, value);
	}


	/**
	 *  パラメータ４.<p>
	 *
	 */
	public String prm04() {
		return getConstString(offset + 12, $prm04);
	}

	/**
	 *  パラメータ４.<p>
	 *
	 */
	public void prm04(String value) {
		setConstString(offset + 12, $prm04, value);
	}


	/**
	 *  パラメータ５.<p>
	 *
	 */
	public String prm05() {
		return getConstString(offset + 13, $prm05);
	}

	/**
	 *  パラメータ５.<p>
	 *
	 */
	public void prm05(String value) {
		setConstString(offset + 13, $prm05, value);
	}


	/**
	 *  パラメータ６.<p>
	 *
	 */
	public String prm06() {
		return getConstString(offset + 14, $prm06);
	}

	/**
	 *  パラメータ６.<p>
	 *
	 */
	public void prm06(String value) {
		setConstString(offset + 14, $prm06, value);
	}


	/**
	 *  パラメータ７.<p>
	 *
	 */
	public String prm07() {
		return getConstString(offset + 15, $prm07);
	}

	/**
	 *  パラメータ７.<p>
	 *
	 */
	public void prm07(String value) {
		setConstString(offset + 15, $prm07, value);
	}


	/**
	 *  パラメータ８.<p>
	 *
	 */
	public String prm08() {
		return getConstString(offset + 16, $prm08);
	}

	/**
	 *  パラメータ８.<p>
	 *
	 */
	public void prm08(String value) {
		setConstString(offset + 16, $prm08, value);
	}


	/**
	 *  パラメータ９.<p>
	 *
	 */
	public String prm09() {
		return getConstString(offset + 17, $prm09);
	}

	/**
	 *  パラメータ９.<p>
	 *
	 */
	public void prm09(String value) {
		setConstString(offset + 17, $prm09, value);
	}


	/**
	 *  パラメータ１０.<p>
	 *
	 */
	public String prm10() {
		return getConstString(offset + 18, $prm10);
	}

	/**
	 *  パラメータ１０.<p>
	 *
	 */
	public void prm10(String value) {
		setConstString(offset + 18, $prm10, value);
	}


	/**
	 *  パラメータ１１.<p>
	 *
	 */
	public String prm11() {
		return getConstString(offset + 19, $prm11);
	}

	/**
	 *  パラメータ１１.<p>
	 *
	 */
	public void prm11(String value) {
		setConstString(offset + 19, $prm11, value);
	}


	/**
	 *  パラメータ１２.<p>
	 *
	 */
	public String prm12() {
		return getConstString(offset + 20, $prm12);
	}

	/**
	 *  パラメータ１２.<p>
	 *
	 */
	public void prm12(String value) {
		setConstString(offset + 20, $prm12, value);
	}


	/**
	 *  パラメータ１３.<p>
	 *
	 */
	public String prm13() {
		return getConstString(offset + 21, $prm13);
	}

	/**
	 *  パラメータ１３.<p>
	 *
	 */
	public void prm13(String value) {
		setConstString(offset + 21, $prm13, value);
	}


	/**
	 *  パラメータ１４.<p>
	 *
	 */
	public String prm14() {
		return getConstString(offset + 22, $prm14);
	}

	/**
	 *  パラメータ１４.<p>
	 *
	 */
	public void prm14(String value) {
		setConstString(offset + 22, $prm14, value);
	}


	/**
	 *  パラメータ１５.<p>
	 *
	 */
	public String prm15() {
		return getConstString(offset + 23, $prm15);
	}

	/**
	 *  パラメータ１５.<p>
	 *
	 */
	public void prm15(String value) {
		setConstString(offset + 23, $prm15, value);
	}


	/**
	 *  パラメータ１６.<p>
	 *
	 */
	public String prm16() {
		return getConstString(offset + 24, $prm16);
	}

	/**
	 *  パラメータ１６.<p>
	 *
	 */
	public void prm16(String value) {
		setConstString(offset + 24, $prm16, value);
	}


	/**
	 *  パラメータ１７.<p>
	 *
	 */
	public String prm17() {
		return getConstString(offset + 25, $prm17);
	}

	/**
	 *  パラメータ１７.<p>
	 *
	 */
	public void prm17(String value) {
		setConstString(offset + 25, $prm17, value);
	}


	/**
	 *  パラメータ１８.<p>
	 *
	 */
	public String prm18() {
		return getConstString(offset + 26, $prm18);
	}

	/**
	 *  パラメータ１８.<p>
	 *
	 */
	public void prm18(String value) {
		setConstString(offset + 26, $prm18, value);
	}


	/**
	 *  パラメータ１９.<p>
	 *
	 */
	public String prm19() {
		return getConstString(offset + 27, $prm19);
	}

	/**
	 *  パラメータ１９.<p>
	 *
	 */
	public void prm19(String value) {
		setConstString(offset + 27, $prm19, value);
	}


	/**
	 *  パラメータ２０.<p>
	 *
	 */
	public String prm20() {
		return getConstString(offset + 28, $prm20);
	}

	/**
	 *  パラメータ２０.<p>
	 *
	 */
	public void prm20(String value) {
		setConstString(offset + 28, $prm20, value);
	}


	/**
	 *  パラメータ２１.<p>
	 *
	 */
	public String prm21() {
		return getConstString(offset + 29, $prm21);
	}

	/**
	 *  パラメータ２１.<p>
	 *
	 */
	public void prm21(String value) {
		setConstString(offset + 29, $prm21, value);
	}


	/**
	 *  パラメータ２２.<p>
	 *
	 */
	public String prm22() {
		return getConstString(offset + 30, $prm22);
	}

	/**
	 *  パラメータ２２.<p>
	 *
	 */
	public void prm22(String value) {
		setConstString(offset + 30, $prm22, value);
	}


	/**
	 *  パラメータ２３.<p>
	 *
	 */
	public String prm23() {
		return getConstString(offset + 31, $prm23);
	}

	/**
	 *  パラメータ２３.<p>
	 *
	 */
	public void prm23(String value) {
		setConstString(offset + 31, $prm23, value);
	}


	/**
	 *  パラメータ２４.<p>
	 *
	 */
	public String prm24() {
		return getConstString(offset + 32, $prm24);
	}

	/**
	 *  パラメータ２４.<p>
	 *
	 */
	public void prm24(String value) {
		setConstString(offset + 32, $prm24, value);
	}


	/**
	 *  パラメータ２５.<p>
	 *
	 */
	public String prm25() {
		return getConstString(offset + 33, $prm25);
	}

	/**
	 *  パラメータ２５.<p>
	 *
	 */
	public void prm25(String value) {
		setConstString(offset + 33, $prm25, value);
	}


	/**
	 *  パラメータ２６.<p>
	 *
	 */
	public String prm26() {
		return getConstString(offset + 34, $prm26);
	}

	/**
	 *  パラメータ２６.<p>
	 *
	 */
	public void prm26(String value) {
		setConstString(offset + 34, $prm26, value);
	}


	/**
	 *  パラメータ２７.<p>
	 *
	 */
	public String prm27() {
		return getConstString(offset + 35, $prm27);
	}

	/**
	 *  パラメータ２７.<p>
	 *
	 */
	public void prm27(String value) {
		setConstString(offset + 35, $prm27, value);
	}


	/**
	 *  パラメータ２８.<p>
	 *
	 */
	public String prm28() {
		return getConstString(offset + 36, $prm28);
	}

	/**
	 *  パラメータ２８.<p>
	 *
	 */
	public void prm28(String value) {
		setConstString(offset + 36, $prm28, value);
	}


	/**
	 *  パラメータ２９.<p>
	 *
	 */
	public String prm29() {
		return getConstString(offset + 37, $prm29);
	}

	/**
	 *  パラメータ２９.<p>
	 *
	 */
	public void prm29(String value) {
		setConstString(offset + 37, $prm29, value);
	}


	/**
	 *  パラメータ３０.<p>
	 *
	 */
	public String prm30() {
		return getConstString(offset + 38, $prm30);
	}

	/**
	 *  パラメータ３０.<p>
	 *
	 */
	public void prm30(String value) {
		setConstString(offset + 38, $prm30, value);
	}


	/**
	 *  パラメータ３１.<p>
	 *
	 */
	public String prm31() {
		return getConstString(offset + 39, $prm31);
	}

	/**
	 *  パラメータ３１.<p>
	 *
	 */
	public void prm31(String value) {
		setConstString(offset + 39, $prm31, value);
	}


	/**
	 *  パラメータ３２.<p>
	 *
	 */
	public String prm32() {
		return getConstString(offset + 40, $prm32);
	}

	/**
	 *  パラメータ３２.<p>
	 *
	 */
	public void prm32(String value) {
		setConstString(offset + 40, $prm32, value);
	}


	/**
	 *  パラメータ３３.<p>
	 *
	 */
	public String prm33() {
		return getConstString(offset + 41, $prm33);
	}

	/**
	 *  パラメータ３３.<p>
	 *
	 */
	public void prm33(String value) {
		setConstString(offset + 41, $prm33, value);
	}


	/**
	 *  パラメータ３４.<p>
	 *
	 */
	public String prm34() {
		return getConstString(offset + 42, $prm34);
	}

	/**
	 *  パラメータ３４.<p>
	 *
	 */
	public void prm34(String value) {
		setConstString(offset + 42, $prm34, value);
	}


	/**
	 *  パラメータ３５.<p>
	 *
	 */
	public String prm35() {
		return getConstString(offset + 43, $prm35);
	}

	/**
	 *  パラメータ３５.<p>
	 *
	 */
	public void prm35(String value) {
		setConstString(offset + 43, $prm35, value);
	}


	/**
	 *  パラメータ３６.<p>
	 *
	 */
	public String prm36() {
		return getConstString(offset + 44, $prm36);
	}

	/**
	 *  パラメータ３６.<p>
	 *
	 */
	public void prm36(String value) {
		setConstString(offset + 44, $prm36, value);
	}


	/**
	 *  パラメータ３７.<p>
	 *
	 */
	public String prm37() {
		return getConstString(offset + 45, $prm37);
	}

	/**
	 *  パラメータ３７.<p>
	 *
	 */
	public void prm37(String value) {
		setConstString(offset + 45, $prm37, value);
	}


	/**
	 *  パラメータ３８.<p>
	 *
	 */
	public String prm38() {
		return getConstString(offset + 46, $prm38);
	}

	/**
	 *  パラメータ３８.<p>
	 *
	 */
	public void prm38(String value) {
		setConstString(offset + 46, $prm38, value);
	}


	/**
	 *  パラメータ３９.<p>
	 *
	 */
	public String prm39() {
		return getConstString(offset + 47, $prm39);
	}

	/**
	 *  パラメータ３９.<p>
	 *
	 */
	public void prm39(String value) {
		setConstString(offset + 47, $prm39, value);
	}


	/**
	 *  パラメータ４０.<p>
	 *
	 */
	public String prm40() {
		return getConstString(offset + 48, $prm40);
	}

	/**
	 *  パラメータ４０.<p>
	 *
	 */
	public void prm40(String value) {
		setConstString(offset + 48, $prm40, value);
	}


	public String getString(String name) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			return batch_log_no();
		}
		if ($batch_log_typ.equalsIgnoreCase(name)) {
			return batch_log_typ();
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			return msg_id();
		}
		if ($msg_lvl.equalsIgnoreCase(name)) {
			return msg_lvl();
		}
		if ($msg_txt.equalsIgnoreCase(name)) {
			return msg_txt();
		}
		if ($prm01.equalsIgnoreCase(name)) {
			return prm01();
		}
		if ($prm02.equalsIgnoreCase(name)) {
			return prm02();
		}
		if ($prm03.equalsIgnoreCase(name)) {
			return prm03();
		}
		if ($prm04.equalsIgnoreCase(name)) {
			return prm04();
		}
		if ($prm05.equalsIgnoreCase(name)) {
			return prm05();
		}
		if ($prm06.equalsIgnoreCase(name)) {
			return prm06();
		}
		if ($prm07.equalsIgnoreCase(name)) {
			return prm07();
		}
		if ($prm08.equalsIgnoreCase(name)) {
			return prm08();
		}
		if ($prm09.equalsIgnoreCase(name)) {
			return prm09();
		}
		if ($prm10.equalsIgnoreCase(name)) {
			return prm10();
		}
		if ($prm11.equalsIgnoreCase(name)) {
			return prm11();
		}
		if ($prm12.equalsIgnoreCase(name)) {
			return prm12();
		}
		if ($prm13.equalsIgnoreCase(name)) {
			return prm13();
		}
		if ($prm14.equalsIgnoreCase(name)) {
			return prm14();
		}
		if ($prm15.equalsIgnoreCase(name)) {
			return prm15();
		}
		if ($prm16.equalsIgnoreCase(name)) {
			return prm16();
		}
		if ($prm17.equalsIgnoreCase(name)) {
			return prm17();
		}
		if ($prm18.equalsIgnoreCase(name)) {
			return prm18();
		}
		if ($prm19.equalsIgnoreCase(name)) {
			return prm19();
		}
		if ($prm20.equalsIgnoreCase(name)) {
			return prm20();
		}
		if ($prm21.equalsIgnoreCase(name)) {
			return prm21();
		}
		if ($prm22.equalsIgnoreCase(name)) {
			return prm22();
		}
		if ($prm23.equalsIgnoreCase(name)) {
			return prm23();
		}
		if ($prm24.equalsIgnoreCase(name)) {
			return prm24();
		}
		if ($prm25.equalsIgnoreCase(name)) {
			return prm25();
		}
		if ($prm26.equalsIgnoreCase(name)) {
			return prm26();
		}
		if ($prm27.equalsIgnoreCase(name)) {
			return prm27();
		}
		if ($prm28.equalsIgnoreCase(name)) {
			return prm28();
		}
		if ($prm29.equalsIgnoreCase(name)) {
			return prm29();
		}
		if ($prm30.equalsIgnoreCase(name)) {
			return prm30();
		}
		if ($prm31.equalsIgnoreCase(name)) {
			return prm31();
		}
		if ($prm32.equalsIgnoreCase(name)) {
			return prm32();
		}
		if ($prm33.equalsIgnoreCase(name)) {
			return prm33();
		}
		if ($prm34.equalsIgnoreCase(name)) {
			return prm34();
		}
		if ($prm35.equalsIgnoreCase(name)) {
			return prm35();
		}
		if ($prm36.equalsIgnoreCase(name)) {
			return prm36();
		}
		if ($prm37.equalsIgnoreCase(name)) {
			return prm37();
		}
		if ($prm38.equalsIgnoreCase(name)) {
			return prm38();
		}
		if ($prm39.equalsIgnoreCase(name)) {
			return prm39();
		}
		if ($prm40.equalsIgnoreCase(name)) {
			return prm40();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($seq.equalsIgnoreCase(name)) {
			return seq();
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			return log_sub_key1();
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			return log_sub_key2();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($log_ts.equalsIgnoreCase(name)) {
			return log_ts();
		}
		return super.getTimestamp(name);
	}

	public String getStringNE(String name) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			return batch_log_no();
		}
		if ($batch_log_typ.equalsIgnoreCase(name)) {
			return batch_log_typ();
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			return msg_id();
		}
		if ($msg_lvl.equalsIgnoreCase(name)) {
			return msg_lvl();
		}
		if ($msg_txt.equalsIgnoreCase(name)) {
			return msg_txt();
		}
		if ($prm01.equalsIgnoreCase(name)) {
			return prm01();
		}
		if ($prm02.equalsIgnoreCase(name)) {
			return prm02();
		}
		if ($prm03.equalsIgnoreCase(name)) {
			return prm03();
		}
		if ($prm04.equalsIgnoreCase(name)) {
			return prm04();
		}
		if ($prm05.equalsIgnoreCase(name)) {
			return prm05();
		}
		if ($prm06.equalsIgnoreCase(name)) {
			return prm06();
		}
		if ($prm07.equalsIgnoreCase(name)) {
			return prm07();
		}
		if ($prm08.equalsIgnoreCase(name)) {
			return prm08();
		}
		if ($prm09.equalsIgnoreCase(name)) {
			return prm09();
		}
		if ($prm10.equalsIgnoreCase(name)) {
			return prm10();
		}
		if ($prm11.equalsIgnoreCase(name)) {
			return prm11();
		}
		if ($prm12.equalsIgnoreCase(name)) {
			return prm12();
		}
		if ($prm13.equalsIgnoreCase(name)) {
			return prm13();
		}
		if ($prm14.equalsIgnoreCase(name)) {
			return prm14();
		}
		if ($prm15.equalsIgnoreCase(name)) {
			return prm15();
		}
		if ($prm16.equalsIgnoreCase(name)) {
			return prm16();
		}
		if ($prm17.equalsIgnoreCase(name)) {
			return prm17();
		}
		if ($prm18.equalsIgnoreCase(name)) {
			return prm18();
		}
		if ($prm19.equalsIgnoreCase(name)) {
			return prm19();
		}
		if ($prm20.equalsIgnoreCase(name)) {
			return prm20();
		}
		if ($prm21.equalsIgnoreCase(name)) {
			return prm21();
		}
		if ($prm22.equalsIgnoreCase(name)) {
			return prm22();
		}
		if ($prm23.equalsIgnoreCase(name)) {
			return prm23();
		}
		if ($prm24.equalsIgnoreCase(name)) {
			return prm24();
		}
		if ($prm25.equalsIgnoreCase(name)) {
			return prm25();
		}
		if ($prm26.equalsIgnoreCase(name)) {
			return prm26();
		}
		if ($prm27.equalsIgnoreCase(name)) {
			return prm27();
		}
		if ($prm28.equalsIgnoreCase(name)) {
			return prm28();
		}
		if ($prm29.equalsIgnoreCase(name)) {
			return prm29();
		}
		if ($prm30.equalsIgnoreCase(name)) {
			return prm30();
		}
		if ($prm31.equalsIgnoreCase(name)) {
			return prm31();
		}
		if ($prm32.equalsIgnoreCase(name)) {
			return prm32();
		}
		if ($prm33.equalsIgnoreCase(name)) {
			return prm33();
		}
		if ($prm34.equalsIgnoreCase(name)) {
			return prm34();
		}
		if ($prm35.equalsIgnoreCase(name)) {
			return prm35();
		}
		if ($prm36.equalsIgnoreCase(name)) {
			return prm36();
		}
		if ($prm37.equalsIgnoreCase(name)) {
			return prm37();
		}
		if ($prm38.equalsIgnoreCase(name)) {
			return prm38();
		}
		if ($prm39.equalsIgnoreCase(name)) {
			return prm39();
		}
		if ($prm40.equalsIgnoreCase(name)) {
			return prm40();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($seq.equalsIgnoreCase(name)) {
			return seq();
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			return log_sub_key1();
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			return log_sub_key2();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($log_ts.equalsIgnoreCase(name)) {
			return log_ts();
		}
		return super.getTimestampNE(name);
	}

	public void setString(String name, String value) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			batch_log_no(value);
			return;
		}
		if ($batch_log_typ.equalsIgnoreCase(name)) {
			batch_log_typ(value);
			return;
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			msg_id(value);
			return;
		}
		if ($msg_lvl.equalsIgnoreCase(name)) {
			msg_lvl(value);
			return;
		}
		if ($msg_txt.equalsIgnoreCase(name)) {
			msg_txt(value);
			return;
		}
		if ($prm01.equalsIgnoreCase(name)) {
			prm01(value);
			return;
		}
		if ($prm02.equalsIgnoreCase(name)) {
			prm02(value);
			return;
		}
		if ($prm03.equalsIgnoreCase(name)) {
			prm03(value);
			return;
		}
		if ($prm04.equalsIgnoreCase(name)) {
			prm04(value);
			return;
		}
		if ($prm05.equalsIgnoreCase(name)) {
			prm05(value);
			return;
		}
		if ($prm06.equalsIgnoreCase(name)) {
			prm06(value);
			return;
		}
		if ($prm07.equalsIgnoreCase(name)) {
			prm07(value);
			return;
		}
		if ($prm08.equalsIgnoreCase(name)) {
			prm08(value);
			return;
		}
		if ($prm09.equalsIgnoreCase(name)) {
			prm09(value);
			return;
		}
		if ($prm10.equalsIgnoreCase(name)) {
			prm10(value);
			return;
		}
		if ($prm11.equalsIgnoreCase(name)) {
			prm11(value);
			return;
		}
		if ($prm12.equalsIgnoreCase(name)) {
			prm12(value);
			return;
		}
		if ($prm13.equalsIgnoreCase(name)) {
			prm13(value);
			return;
		}
		if ($prm14.equalsIgnoreCase(name)) {
			prm14(value);
			return;
		}
		if ($prm15.equalsIgnoreCase(name)) {
			prm15(value);
			return;
		}
		if ($prm16.equalsIgnoreCase(name)) {
			prm16(value);
			return;
		}
		if ($prm17.equalsIgnoreCase(name)) {
			prm17(value);
			return;
		}
		if ($prm18.equalsIgnoreCase(name)) {
			prm18(value);
			return;
		}
		if ($prm19.equalsIgnoreCase(name)) {
			prm19(value);
			return;
		}
		if ($prm20.equalsIgnoreCase(name)) {
			prm20(value);
			return;
		}
		if ($prm21.equalsIgnoreCase(name)) {
			prm21(value);
			return;
		}
		if ($prm22.equalsIgnoreCase(name)) {
			prm22(value);
			return;
		}
		if ($prm23.equalsIgnoreCase(name)) {
			prm23(value);
			return;
		}
		if ($prm24.equalsIgnoreCase(name)) {
			prm24(value);
			return;
		}
		if ($prm25.equalsIgnoreCase(name)) {
			prm25(value);
			return;
		}
		if ($prm26.equalsIgnoreCase(name)) {
			prm26(value);
			return;
		}
		if ($prm27.equalsIgnoreCase(name)) {
			prm27(value);
			return;
		}
		if ($prm28.equalsIgnoreCase(name)) {
			prm28(value);
			return;
		}
		if ($prm29.equalsIgnoreCase(name)) {
			prm29(value);
			return;
		}
		if ($prm30.equalsIgnoreCase(name)) {
			prm30(value);
			return;
		}
		if ($prm31.equalsIgnoreCase(name)) {
			prm31(value);
			return;
		}
		if ($prm32.equalsIgnoreCase(name)) {
			prm32(value);
			return;
		}
		if ($prm33.equalsIgnoreCase(name)) {
			prm33(value);
			return;
		}
		if ($prm34.equalsIgnoreCase(name)) {
			prm34(value);
			return;
		}
		if ($prm35.equalsIgnoreCase(name)) {
			prm35(value);
			return;
		}
		if ($prm36.equalsIgnoreCase(name)) {
			prm36(value);
			return;
		}
		if ($prm37.equalsIgnoreCase(name)) {
			prm37(value);
			return;
		}
		if ($prm38.equalsIgnoreCase(name)) {
			prm38(value);
			return;
		}
		if ($prm39.equalsIgnoreCase(name)) {
			prm39(value);
			return;
		}
		if ($prm40.equalsIgnoreCase(name)) {
			prm40(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($log_ts.equalsIgnoreCase(name)) {
			log_ts(value);
			return;
		}
		super.setTimestamp(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($batch_log_no.equalsIgnoreCase(name)) {
			batch_log_no(value);
			return;
		}
		if ($batch_log_typ.equalsIgnoreCase(name)) {
			batch_log_typ(value);
			return;
		}
		if ($msg_id.equalsIgnoreCase(name)) {
			msg_id(value);
			return;
		}
		if ($msg_lvl.equalsIgnoreCase(name)) {
			msg_lvl(value);
			return;
		}
		if ($msg_txt.equalsIgnoreCase(name)) {
			msg_txt(value);
			return;
		}
		if ($prm01.equalsIgnoreCase(name)) {
			prm01(value);
			return;
		}
		if ($prm02.equalsIgnoreCase(name)) {
			prm02(value);
			return;
		}
		if ($prm03.equalsIgnoreCase(name)) {
			prm03(value);
			return;
		}
		if ($prm04.equalsIgnoreCase(name)) {
			prm04(value);
			return;
		}
		if ($prm05.equalsIgnoreCase(name)) {
			prm05(value);
			return;
		}
		if ($prm06.equalsIgnoreCase(name)) {
			prm06(value);
			return;
		}
		if ($prm07.equalsIgnoreCase(name)) {
			prm07(value);
			return;
		}
		if ($prm08.equalsIgnoreCase(name)) {
			prm08(value);
			return;
		}
		if ($prm09.equalsIgnoreCase(name)) {
			prm09(value);
			return;
		}
		if ($prm10.equalsIgnoreCase(name)) {
			prm10(value);
			return;
		}
		if ($prm11.equalsIgnoreCase(name)) {
			prm11(value);
			return;
		}
		if ($prm12.equalsIgnoreCase(name)) {
			prm12(value);
			return;
		}
		if ($prm13.equalsIgnoreCase(name)) {
			prm13(value);
			return;
		}
		if ($prm14.equalsIgnoreCase(name)) {
			prm14(value);
			return;
		}
		if ($prm15.equalsIgnoreCase(name)) {
			prm15(value);
			return;
		}
		if ($prm16.equalsIgnoreCase(name)) {
			prm16(value);
			return;
		}
		if ($prm17.equalsIgnoreCase(name)) {
			prm17(value);
			return;
		}
		if ($prm18.equalsIgnoreCase(name)) {
			prm18(value);
			return;
		}
		if ($prm19.equalsIgnoreCase(name)) {
			prm19(value);
			return;
		}
		if ($prm20.equalsIgnoreCase(name)) {
			prm20(value);
			return;
		}
		if ($prm21.equalsIgnoreCase(name)) {
			prm21(value);
			return;
		}
		if ($prm22.equalsIgnoreCase(name)) {
			prm22(value);
			return;
		}
		if ($prm23.equalsIgnoreCase(name)) {
			prm23(value);
			return;
		}
		if ($prm24.equalsIgnoreCase(name)) {
			prm24(value);
			return;
		}
		if ($prm25.equalsIgnoreCase(name)) {
			prm25(value);
			return;
		}
		if ($prm26.equalsIgnoreCase(name)) {
			prm26(value);
			return;
		}
		if ($prm27.equalsIgnoreCase(name)) {
			prm27(value);
			return;
		}
		if ($prm28.equalsIgnoreCase(name)) {
			prm28(value);
			return;
		}
		if ($prm29.equalsIgnoreCase(name)) {
			prm29(value);
			return;
		}
		if ($prm30.equalsIgnoreCase(name)) {
			prm30(value);
			return;
		}
		if ($prm31.equalsIgnoreCase(name)) {
			prm31(value);
			return;
		}
		if ($prm32.equalsIgnoreCase(name)) {
			prm32(value);
			return;
		}
		if ($prm33.equalsIgnoreCase(name)) {
			prm33(value);
			return;
		}
		if ($prm34.equalsIgnoreCase(name)) {
			prm34(value);
			return;
		}
		if ($prm35.equalsIgnoreCase(name)) {
			prm35(value);
			return;
		}
		if ($prm36.equalsIgnoreCase(name)) {
			prm36(value);
			return;
		}
		if ($prm37.equalsIgnoreCase(name)) {
			prm37(value);
			return;
		}
		if ($prm38.equalsIgnoreCase(name)) {
			prm38(value);
			return;
		}
		if ($prm39.equalsIgnoreCase(name)) {
			prm39(value);
			return;
		}
		if ($prm40.equalsIgnoreCase(name)) {
			prm40(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($seq.equalsIgnoreCase(name)) {
			seq(value);
			return;
		}
		if ($log_sub_key1.equalsIgnoreCase(name)) {
			log_sub_key1(value);
			return;
		}
		if ($log_sub_key2.equalsIgnoreCase(name)) {
			log_sub_key2(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($log_ts.equalsIgnoreCase(name)) {
			log_ts(value);
			return;
		}
		super.setTimestampNE(name, value);
	}



}

