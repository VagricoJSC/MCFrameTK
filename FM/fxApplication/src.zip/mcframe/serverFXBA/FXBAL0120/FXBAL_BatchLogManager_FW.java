package mcframe.serverFXBA.FXBAL0120;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.requester.MCRequestObject.object;

import java.util.HashMap;
import java.util.Map;

import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.notice.MCAppException;
import mcframe.serverCore.mcjdbc.MCDBTransaction;
import mcframe.serverCore.mcjdbc.MCTransactionManager;
import mcframe.serverCore.sys.MCSys;

/**
 * バッチログ機能です。
 *
 */
public class FXBAL_BatchLogManager_FW {
	/**
	 * このクラス（スレッドセーフ対応用）
	 */
	protected static final Class<FXBAL_BatchLogManager> CLAZZ = FXBAL_BatchLogManager.class;

	/**
	 * カレントlogger
	 */
	protected FXBAL_BatchLogger _current;
	
	/**
	 * ログ出力用のトランザクション
	 */
	protected MCDBTransaction _tran = null; 

	/**
	 * 生成したロガーを保持するMap
	 */
	private final Map<String, FXBAL_BatchLogger> _loggerMap = new HashMap<>();

	/**
	 * Loggerを取得します。
	 * 指定されたデータ参照制御用文字列でLoggerが未作成の場合はLoggerを新規作成します。
	 * 取得したLoggerはカレントLoggerにセットします。
	 * @return Logger
	 */
	public static FXBAL_BatchLogger getLogger() {
		return getLogger("");
	}

	/**
	 * Loggerを取得します。
	 * 指定されたデータ参照制御用文字列でLoggerが未作成の場合はLoggerを新規作成します。
	 * 取得したLoggerはカレントLoggerにセットします。
	 * @param dataRefCtl データ参照制御用文字列
	 * @return Logger
	 */
	public static FXBAL_BatchLogger getLogger(String dataRefCtl) {
		return object(CLAZZ).createLogger(dataRefCtl);
	}

	/**
	 * ノーマルLoggerを取得します。
	 * 指定されたデータ参照制御用文字列でLoggerが未作成の場合はLoggerを新規作成します。
	 * 取得したLoggerはカレントLoggerにセットします。
	 * @param dataRefCtl データ参照制御用文字列
	 * @return Logger
	 */
	protected FXBAL_BatchLogger createLogger(String dataRefCtl) {
		String key = loggerMapKey(dataRefCtl);
		FXBAL_BatchLogger logger = loggerMap().get(key);
		if (logger == null) {
			if(_tran == null) {
				_tran = MCTransactionManager.createDBTran(false);
			}
			logger = new FXBAL_NormalBatchLogger(_tran, dataRefCtl);
			((FXBAL_NormalBatchLogger)logger).writeLogHeader();
			loggerMap().put(key, logger);
		}
		_current = logger;
		return logger;
	}

	/**
	 * ConcurrentLoggerを取得します。
	 * 指定されたデータ参照制御用文字列でLoggerが未作成の場合はLoggerを新規作成します。
	 * 取得したLoggerはカレントLoggerにセットします。
	 * @return Logger
	 */
	public static FXBAL_BatchLogger getConcurrentLogger() {
		return getConcurrentLogger("");
	}

	/**
	 * ConcurrentLoggerを取得します。
	 * 指定されたデータ参照制御用文字列でLoggerが未作成の場合はLoggerを新規作成します。
	 * 取得したLoggerはカレントLoggerにセットします。
	 * @param dataRefCtl データ参照制御用文字列
	 * @return Logger
	 */
	public static FXBAL_BatchLogger getConcurrentLogger(String dataRefCtl) {
		return object(CLAZZ).createConcurrentLogger(dataRefCtl);
	}

	/**
	 * ConcurrentLoggerを取得します。
	 * 指定されたデータ参照制御用文字列でLoggerが未作成の場合はLoggerを新規作成します。
	 * 取得したLoggerはカレントLoggerにセットします。
	 * @param dataRefCtl データ参照制御用文字列
	 * @return Logger
	 */
	protected FXBAL_BatchLogger createConcurrentLogger(String dataRefCtl) {
		String key = loggerMapKey(dataRefCtl);
		FXBAL_BatchLogger logger = loggerMap().get(key);
		if (logger == null) {
			logger = new FXBAL_ConcurrentBatchLogger(MCTransactionManager.createDBTran(false), dataRefCtl);
			((FXBAL_ConcurrentBatchLogger)logger).writeLogHeader();
			loggerMap().put(key, logger);
		}
		_current = logger;
		return logger;
	}

	/**
	 * カレントの logger を取得します。
	 * @throws MCAppException [FXBAL0028] カレントの logger が存在しない場合
	 * @return logger
	 */
	public static FXBAL_BatchLogger logger() {
		if (object(CLAZZ)._current == null) {
			throw new MCAppException(FXBAL0028);
		}
		return object(CLAZZ)._current;
	}

	/**
	 * カレントの logger を取得します。</p>
	 * 存在しない場合はnullを返します。
	 * @return logger
	 */
	public static FXBAL_BatchLogger loggerNE() {
		return object(CLAZZ)._current;
	}

	/**
	 * カレントの logger を明示的にセットします。
	 * @param logger
	 */
	public static void logger(FXBAL_BatchLogger logger) {
		object(CLAZZ)._current = logger;
	}

	/**
	 * 保持するロガーを特定するキー値を生成します。
	 * @param dataRefCtl データ参照制御用の文字列。
	 * @return　キー値
	 */
	protected static String loggerMapKey(String dataRefCtl) {
		if (dataRefCtl == null || dataRefCtl.equals("")) {
			return MCSys.request.serverRequestNo();
		}
		String[] keys = new String[2];
		keys[0] = MCSys.request.serverRequestNo();
		keys[1] = dataRefCtl;
		String key = MCStringUtil.arrayValueJoin(keys);
		return key;
	}

	/**
	 * ロガーを保持するMapを取得します。
	 */
	protected Map<String, FXBAL_BatchLogger> loggerMap() {
		return _loggerMap;
	}
}
