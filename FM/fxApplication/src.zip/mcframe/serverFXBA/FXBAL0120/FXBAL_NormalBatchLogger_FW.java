package mcframe.serverFXBA.FXBAL0120;

import java.util.Locale;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.queryapi.IFMCSQL.*;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCLog;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageLevel;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonCore.resource.MCLocaleConst;
import mcframe.commonCore.resource.MCMessageConst;
import mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil;
import mcframe.serverCore.mcjdbc.FWDBUtil;
import mcframe.serverCore.mcjdbc.MCDBTransaction;
import mcframe.serverCore.dbc.CoreFunction;
import mcframe.serverCore.dbc.FCT_BATCH_LOG_H_R;
import mcframe.serverCore.dbc.FCT_BATCH_LOG_MSG_R;
import mcframe.serverCore.sys.MCSys;

import static mcframe.serverFXBA.FXBAL0120.Query.*;

public class FXBAL_NormalBatchLogger_FW implements FXBAL_BatchLogger, Cloneable {

	/**
	 * ログNoです。
	 */
	protected final String _logNo;

	/**
	 * データ参照制御用の文字列です。
	 * この文字列単位でログNo（Loggerインスタンス）の生成と遷移先データ確認画面の設定を行うことができます。
	 */
	protected final String _dataRefCtl;

	/**
	 * ログ出力に使用するトランザクションです。
	 * 基本的には、ロガー内の処理ではこのトランザクションを利用します。
	 */
	protected MCDBTransaction _tran;

	/**
	 * ログNoのデフォルトのカラム名です。
	 */
	public static final String LOG_NO_COLUMN = "batchLogNo";

	/**
	 * ログサブキー1のデフォルトのカラム名です。
	 */
	public static final String LOG_SUB_KEY1_COLUMN = "logSubKey1";

	/**
	 * ログサブキー2のデフォルトのカラム名です。
	 */
	public static final String LOG_SUB_KEY2_COLUMN = "logSubKey2";

	/**
	 * ログサブキー1に使用するデフォルト値です。
	 */
	protected static final int DEFAULT_LOG_SUB_KEY1 = 999999;

	/**
	 * ログサブキー2を採番するためのカウンター
	 */
	protected int _logSubKey2Counter = 1;

	/**
	 * PLSQL引継ぎ用ログサブキー1に使用するデフォルト値です。
	 */
	protected static final int DEFAULT_LOG_SUB_KEY1_PLSQL = 9999998;
	
	private static Boolean _autotestdev = Boolean.valueOf(mcframe.serverCore.sys.MCSys.env.getVMEnv("autotestdev"));

	/**
	 * コンストラクタです。
	 * @param dataRefCtl データ参照制御用文字列
	 */
	FXBAL_NormalBatchLogger_FW(MCDBTransaction tran, String dataRefCtl) {
		_logNo = makeLogNo();
		_dataRefCtl = dataRefCtl;
		_tran = tran;
	}

	private void closeCheck() {
		if (_tran == null) {
			throw new MCException(FXBAL0031);
		}
	}

	@Override
	public FXBAL_NormalBatchLogger_FW clone() {
		closeCheck();

		FXBAL_NormalBatchLogger_FW logger = null;
		try {
			logger = (FXBAL_NormalBatchLogger_FW) super.clone();
		}
		catch (CloneNotSupportedException ex) {
			throw new InternalError();
		}
		return logger;
	}

	/**
	 * @return ログ出力に使用するトランザクション
	 */
	protected MCDBTransaction dbTran4Logger() {
		return _tran;
	}

	/**
	 * ログNoを生成します。
	 * @return ログNo
	 */
	protected String makeLogNo() {
		MCRow result = MCRow.create();
		result.setStringNE("rtn", null);
		sql("FCPA_BATCH_LOG.F_MAKE_LOG_NO").mainQuery()
				.select(CoreFunction.FCPA_BATCH_LOG$F_MAKE_LOG_NO().as("rtn"))
				.executeQuery(result);
		return result.getStringNE("rtn");
	}

	/**
	 * ログヘッダにログ情報を登録します。
	 */
	protected void writeLogHeader() {
		closeCheck();

		BatchLogHR row = BatchLogHR.create();
		MCTimestamp now = MCTimestamp.now();

		row.batch_log_no(_logNo);
		row.req_no(MCSys.request.serverRequestNo());
		row.data_ref_ctl(_dataRefCtl);
		row.start_ts(now);
		row.last_ts(now);
		row.login_seq(MCSys.user.loginSequence());
		row.ext_attr1(MCSys.user.extattr1());
		row.ext_attr2(MCSys.user.extattr2());
		row.ext_attr3(MCSys.user.extattr3());
		row.usr_cd(MCSys.user.ID());
		row.call_module_id(MCSys.request.moduleId());
		row.call_logic_id(MCSys.request.logicId());
		row.call_operation_id(MCSys.request.operationId());
		row.call_pg_id(MCSys.request.reqSrcId());
		row.call_clt_id(MCSys.request.clientId());
		Locale lcl = MCSys.user.locale();
		if (lcl != null) {
			row.lcl_cd(lcl.toString());
		}
		row.gp_batch_grp_cd(FWDBUtil.getGpBatchGrpCd());

		FCT_BATCH_LOG_H_R r = FCT_BATCH_LOG_H_R.create();
		createInsHeaderQuery("FXBAL120_INS_HEADER01", r).executeUpdate(dbTran4Logger(),
				row, null);
		autotestDummyBeforeCommit();
		dbTran4Logger().fwCommit();
	}

	protected MCInsert createInsHeaderQuery(String sqlid, FCT_BATCH_LOG_H_R loghR) {
		MCInsert q = sql(sqlid).insert(loghR)
				.columns(loghR.batch_log_no, loghR.req_no, loghR.data_ref_ctl,
						loghR.start_ts, loghR.last_ts, loghR.login_seq, loghR.emsg_seq,
						loghR.ext_attr1, loghR.ext_attr2, loghR.ext_attr3, loghR.usr_cd,
						loghR.gp_batch_grp_cd, loghR.call_module_id, loghR.call_logic_id,
						loghR.call_operation_id, loghR.call_pg_id, loghR.call_clt_id,
						loghR.call_plsql_id, loghR.lcl_cd, loghR.end_flg, loghR.warn_flg,
						loghR.rmrks1, loghR.rmrks2, loghR.rmrks3, loghR.rmrks4,
						loghR.rmrks5, loghR.rmrks6, loghR.rmrks7, loghR.rmrks8,
						loghR.rmrks9, loghR.rmrks10)
				.values(bind(FCT_BATCH_LOG_H_R.$batch_log_no),
						bind(FCT_BATCH_LOG_H_R.$req_no),
						bind(FCT_BATCH_LOG_H_R.$data_ref_ctl),
						bind(FCT_BATCH_LOG_H_R.$start_ts),
						bind(FCT_BATCH_LOG_H_R.$last_ts),
						bind(FCT_BATCH_LOG_H_R.$login_seq), value(0),
						bind(FCT_BATCH_LOG_H_R.$ext_attr1),
						bind(FCT_BATCH_LOG_H_R.$ext_attr2),
						bind(FCT_BATCH_LOG_H_R.$ext_attr3),
						bind(FCT_BATCH_LOG_H_R.$usr_cd),
						bind(FCT_BATCH_LOG_H_R.$gp_batch_grp_cd),
						bind(FCT_BATCH_LOG_H_R.$call_module_id),
						bind(FCT_BATCH_LOG_H_R.$call_logic_id),
						bind(FCT_BATCH_LOG_H_R.$call_operation_id),
						bind(FCT_BATCH_LOG_H_R.$call_pg_id),
						bind(FCT_BATCH_LOG_H_R.$call_clt_id), nullValue(),
						bind(FCT_BATCH_LOG_H_R.$lcl_cd), value(false), value(false),
						nullValue(), nullValue(), nullValue(), nullValue(), nullValue(),
						nullValue(), nullValue(), nullValue(), nullValue(), nullValue());
		return q;
	}

	/**
	 * ログNoを取得します。
	 * @return ログNo
	 */
	@Override
	public String getBatchLogNo() {
		return _logNo;
	}

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * listに含まれるMCRowのそれぞれに個別のログサブキーを設定します。
	 * @param list データログに関連図けるコンテナ
	 */
	@Override
	public void setLogKey(MCList<? extends MCRow> list) {
		setLogKey(list, LOG_NO_COLUMN, LOG_SUB_KEY1_COLUMN, LOG_SUB_KEY2_COLUMN);
	}

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * listに含まれるMCRowのそれぞれに個別のログサブキーを設定します。
	 * @param list データログに関連図けるコンテナ
	 * @param batchLogNoCol ログNoを設定するコンテナのカラム名
	 * @param logSubKey1Col ログNoを設定するコンテナのカラム名
	 * @param logSubKey2Col ログNoを設定するコンテナのカラム名
	 */
	@Override
	public void setLogKey(MCList<? extends MCRow> list, String batchlogNoCol,
			String logSubKey1Col, String logSubKey2Col) {
		for (MCRow row : list) {
			setLogKey(row, batchlogNoCol, logSubKey1Col, logSubKey2Col);
		}
	}

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * @param row データログに関連図けるコンテナ
	 */
	@Override
	public void setLogKey(MCRow row) {
		setLogKey(row, LOG_NO_COLUMN, LOG_SUB_KEY1_COLUMN, LOG_SUB_KEY2_COLUMN);
	}

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * @param row データログに関連図けるコンテナ
	 * @param batchLogNoCol ログNoを設定するコンテナのカラム名
	 * @param logSubKey1Col ログNoを設定するコンテナのカラム名
	 * @param logSubKey2Col ログNoを設定するコンテナのカラム名
	 */
	@Override
	public void setLogKey(MCRow row, String batchlogNoCol, String logSubKey1Col,
			String logSubKey2Col) {
		int pIndex = row.getParamIndex();
		if (pIndex < 0) {
			pIndex = DEFAULT_LOG_SUB_KEY1;
			row.setParamIndex(pIndex);
		}
		int rIndex = row.getParamRowIndex();
		if (rIndex < 0) {
			rIndex = _logSubKey2Counter++;
			row.setParamRowIndex(rIndex);
		}
		row.setNumberNE(logSubKey1Col, pIndex);
		row.setNumberNE(logSubKey2Col, rIndex);
		row.setStringNE(batchlogNoCol, getBatchLogNo());
	}

	/**
	 * 開始ログを出力します。
	 * @param ex 例外情報
	 */
	@Override
	public void writeStartLog(MCException ex) {
		closeCheck();
		save("S", ex);
	}

	/**
	 * 開始ログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	@Override
	public void writeStartLog(String id, Object... binds) {
		closeCheck();
		MCMessage msg = new MCMessage(id, binds);
		writeStartLog(msg);
	}

	/**
	 * 開始ログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	@Override
	public void writeStartLog(MCMessage msg) {
		closeCheck();
		save("S", msg);
	}

	/**
	 * 処理経過ログを出力します。
	 * @param ex 例外情報
	 */
	@Override
	public void writeProcessLog(MCException ex) {
		closeCheck();
		save("P", ex);
	}

	/**
	 * 処理経過ログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	@Override
	public void writeProcessLog(String id, Object... binds) {
		closeCheck();
		MCMessage msg = new MCMessage(id, binds);
		writeProcessLog(msg);

	}

	/**
	 * 処理経過ログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	@Override
	public void writeProcessLog(MCMessage msg) {
		closeCheck();
		save("P", msg);
	}

	/**
	 * 処理経過ログを出力します。
	 * @param msgList バッチログにメッセージ情報のリスト
	 */
	@Override
	public void writeProcessLog(MCMessageList msgList) {
		closeCheck();
		save("P", msgList);
	}

	/**
	 * データログを出力します。
	 * @param ex 例外情報
	 */
	@Override
	public void writeDataLog(MCException ex) {
		closeCheck();
		save("D", ex);
	}

	/**
	 * データログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	@Override
	public void writeDataLog(String id, Object... binds) {
		closeCheck();
		MCMessage msg = new MCMessage(id, binds);
		writeDataLog(msg);
	}

	/**
	 * データログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	@Override
	public void writeDataLog(MCMessage msg) {
		closeCheck();
		save("D", msg);
	}

	/**
	 * データログを出力します。
	 * @param causeRow データログに関連させるMCRow
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	@Override
	public void writeDataLog(MCRow causeRow, String id, Object... binds) {
		closeCheck();
		MCMessage msg = new MCMessage(causeRow, "", id, binds);
		writeDataLog(msg);
	}

	/**
	 * データログを出力します。
	 * @param causeRow データログに関連させるMCRow
	 * @param msg バッチログに出力するメッセージ情報
	 */
	@Override
	public void writeDataLog(MCRow causeRow, MCMessage msg) {
		closeCheck();
		msg.setCauseRow(causeRow, "");
		writeDataLog(msg);
	}

	/**
	 * データログを出力します。
	 * @param msgList バッチログに出力するメッセージ情報
	 */
	@Override
	public void writeDataLog(MCMessageList msgList) {
		closeCheck();
		save("D", msgList);
	}

	/**
	 * 終了ログを出力します。
	 * @param ex 例外情報
	 */
	@Override
	public void writeEndLog(MCException ex) {
		closeCheck();
		save("E", ex);
	}

	/**
	 * 終了ログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	@Override
	public void writeEndLog(String id, Object... binds) {
		closeCheck();
		MCMessage msg = new MCMessage(id, binds);
		writeEndLog(msg);
	}

	/**
	 * 終了ログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	@Override
	public void writeEndLog(MCMessage msg) {
		closeCheck();
		save("E", msg);
	}

	/**
	 * バッチログを出力します。
	 * @param logType
	 * @param msg
	 * @return バッチログに書き込んだバッチログメッセージ情報
	 */
	protected BatchLogMsgR save(String logType, MCMessage msg) {
		closeCheck();
		MCMessageList msgList = new MCMessageList();
		msgList.add(msg);
		MCList<BatchLogMsgR> ret;
		ret = save(logType, msgList);
		if (ret.isEmpty()) {
			return null;
		}
		return ret.get(0);
	}

	/**
	 * バッチログを出力します。
	 * @param logType
	 * @param ex
	 * @return バッチログに書き込んだバッチログメッセージ情報
	 */
	protected MCList<BatchLogMsgR> save(String logType, MCException ex) {
		closeCheck();
		MCMessageList msgList = new MCMessageList();
		if (ex != null) {
			msgList.add(ex.getMCMessage());
			msgList.addAll(ex.getCauseMessageList());
		}
		return save(logType, msgList);
	}

	/**
	 * バッチログを出力します。
	 * @param logType
	 * @param msgList
	 * @return バッチログに書き込んだバッチログメッセージ情報。1件も書き込まなかった場合は内容が0件のMCListを返します。
	 */
	protected MCList<BatchLogMsgR> save(String logType, MCMessageList msgList) {
		closeCheck();

		if (msgList == null || msgList.isEmpty()) {
			return MCList.create(BatchLogMsgR.class);
		}

		MCMessageList ml = new MCMessageList();
		for (MCMessage msg : msgList) {
			if (MCLog.isEnabled(msg)) {
				ml.add(msg);
			}
		}
		if (ml.isEmpty()) {
			return MCList.create(BatchLogMsgR.class);
		}

		MCList<BatchLogMsgR> ret = MCList.create(BatchLogMsgR.class);
		MCTimestamp sysnow = MCTimestamp.now();
		boolean containsErr = makeLogMsg(logType, msgList, sysnow, ret);
		makeLogH(logType, sysnow, containsErr, ret.get(ret.size() - 1).seq());
		autotestDummyBeforeCommit();
		dbTran4Logger().fwCommit();
		return ret;
	}

	/**
	 * バッチログメッセージを作成します。
	 */
	protected boolean makeLogMsg(String logType, MCMessageList msgList,
			MCTimestamp sysnow, MCList<BatchLogMsgR> ret) {
		closeCheck();

		boolean result = false;
		MCList<MCRow> logSeqList = numberingLogSeq(msgList.size());
		MCMessageConst msgConst = MCLocaleConst.message(MCSys.user.locale());

		for (int i = 0; i < msgList.size(); i++) {
			MCMessage msg = msgList.get(i);
			BatchLogMsgR row = BatchLogMsgR.create();
			row.batch_log_no(_logNo);
			row.seq(logSeqList.get(i).getNumber("SEQ"));// postgreだとカラム名が小文字になるけど大丈夫
			MCRow causeRow = msg.getCauseRow();
			if (causeRow != null) {
				row.log_sub_key1(causeRow.getParamIndex());
				row.log_sub_key2(causeRow.getParamRowIndex());
			}
			else {
				row.log_sub_key1(-100);
				row.log_sub_key2(-100);
			}
			row.batch_log_typ(logType);
			row.msg_id(msg.getID());
			copyBind(row, msg);
			MCMessageLevel mlvl = msg.getLevel();
			if (mlvl != null) {
				row.msg_lvl(mlvl.toString().substring(0, 1));
				if (isErr(mlvl)) {
					result = true;
				}
			}
			String msgTxt = msg.toString(msgConst);
			if (msgTxt != null) {
				int len = row.getMeta(BatchLogMsgR.$msg_txt).length();
				if (msgTxt.length() > len) {
					row.msg_txt(msgTxt.substring(0, len));
				}
				else {
					row.msg_txt(msgTxt);
				}
			}
			row.log_ts(sysnow);
			ret.add(row);
		}

		FCT_BATCH_LOG_MSG_R msgR = FCT_BATCH_LOG_MSG_R.create();
		createInsMsgQuery("FXBAL120_INS_MSG01", msgR).executeBatchUpdate(dbTran4Logger(),
				ret, null, null);

		return result;
	}

	protected MCInsert createInsMsgQuery(String sqlid, FCT_BATCH_LOG_MSG_R msgR) {
		MCInsert q = sql(sqlid).insert(msgR).columns(msgR.batch_log_no, msgR.seq,
				msgR.log_sub_key1, msgR.log_sub_key2, msgR.batch_log_typ, msgR.msg_id,
				msgR.msg_lvl, msgR.msg_txt, msgR.log_ts, msgR.prm01, msgR.prm02,
				msgR.prm03, msgR.prm04, msgR.prm05, msgR.prm06, msgR.prm07, msgR.prm08,
				msgR.prm09, msgR.prm10, msgR.prm11, msgR.prm12, msgR.prm13, msgR.prm14,
				msgR.prm15, msgR.prm16, msgR.prm17, msgR.prm18, msgR.prm19, msgR.prm20,
				msgR.prm21, msgR.prm22, msgR.prm23, msgR.prm24, msgR.prm25, msgR.prm26,
				msgR.prm27, msgR.prm28, msgR.prm29, msgR.prm30, msgR.prm31, msgR.prm32,
				msgR.prm33, msgR.prm34, msgR.prm35, msgR.prm36, msgR.prm37, msgR.prm38,
				msgR.prm39, msgR.prm40).values(bind(FCT_BATCH_LOG_MSG_R.$batch_log_no),
						bind(FCT_BATCH_LOG_MSG_R.$seq),
						bind(FCT_BATCH_LOG_MSG_R.$log_sub_key1),
						bind(FCT_BATCH_LOG_MSG_R.$log_sub_key2),
						bind(FCT_BATCH_LOG_MSG_R.$batch_log_typ),
						bind(FCT_BATCH_LOG_MSG_R.$msg_id),
						bind(FCT_BATCH_LOG_MSG_R.$msg_lvl),
						bind(FCT_BATCH_LOG_MSG_R.$msg_txt),
						bind(FCT_BATCH_LOG_MSG_R.$log_ts),
						bind(FCT_BATCH_LOG_MSG_R.$prm01),
						bind(FCT_BATCH_LOG_MSG_R.$prm02),
						bind(FCT_BATCH_LOG_MSG_R.$prm03),
						bind(FCT_BATCH_LOG_MSG_R.$prm04),
						bind(FCT_BATCH_LOG_MSG_R.$prm05),
						bind(FCT_BATCH_LOG_MSG_R.$prm06),
						bind(FCT_BATCH_LOG_MSG_R.$prm07),
						bind(FCT_BATCH_LOG_MSG_R.$prm08),
						bind(FCT_BATCH_LOG_MSG_R.$prm09),
						bind(FCT_BATCH_LOG_MSG_R.$prm10),
						bind(FCT_BATCH_LOG_MSG_R.$prm11),
						bind(FCT_BATCH_LOG_MSG_R.$prm12),
						bind(FCT_BATCH_LOG_MSG_R.$prm13),
						bind(FCT_BATCH_LOG_MSG_R.$prm14),
						bind(FCT_BATCH_LOG_MSG_R.$prm15),
						bind(FCT_BATCH_LOG_MSG_R.$prm16),
						bind(FCT_BATCH_LOG_MSG_R.$prm17),
						bind(FCT_BATCH_LOG_MSG_R.$prm18),
						bind(FCT_BATCH_LOG_MSG_R.$prm19),
						bind(FCT_BATCH_LOG_MSG_R.$prm20),
						bind(FCT_BATCH_LOG_MSG_R.$prm21),
						bind(FCT_BATCH_LOG_MSG_R.$prm22),
						bind(FCT_BATCH_LOG_MSG_R.$prm23),
						bind(FCT_BATCH_LOG_MSG_R.$prm24),
						bind(FCT_BATCH_LOG_MSG_R.$prm25),
						bind(FCT_BATCH_LOG_MSG_R.$prm26),
						bind(FCT_BATCH_LOG_MSG_R.$prm27),
						bind(FCT_BATCH_LOG_MSG_R.$prm28),
						bind(FCT_BATCH_LOG_MSG_R.$prm29),
						bind(FCT_BATCH_LOG_MSG_R.$prm30),
						bind(FCT_BATCH_LOG_MSG_R.$prm31),
						bind(FCT_BATCH_LOG_MSG_R.$prm32),
						bind(FCT_BATCH_LOG_MSG_R.$prm33),
						bind(FCT_BATCH_LOG_MSG_R.$prm34),
						bind(FCT_BATCH_LOG_MSG_R.$prm35),
						bind(FCT_BATCH_LOG_MSG_R.$prm36),
						bind(FCT_BATCH_LOG_MSG_R.$prm37),
						bind(FCT_BATCH_LOG_MSG_R.$prm38),
						bind(FCT_BATCH_LOG_MSG_R.$prm39),
						bind(FCT_BATCH_LOG_MSG_R.$prm40));
		return q;
	}
	
	/**
	 * ヘッダメッセージを作成します。
	 */
	protected BatchLogHR makeLogH(String logType, MCTimestamp sysnow, boolean containErr,
			MCNumber lastSeq) {
		closeCheck();

		BatchLogHR ret = BatchLogHR.create();
		FCT_BATCH_LOG_H_R S0 = FCT_BATCH_LOG_H_R.create();
		MCUpdate q = sql("FXBAL120_UPD_HEADER01").update(S0).set(S0.last_ts)
				.eq(bind(FCT_BATCH_LOG_H_R.$last_ts));
		ret.last_ts(sysnow);
		ret.batch_log_no(_logNo);

		if (containErr) {
			q = q.set(S0.warn_flg).eq(bind(FCT_BATCH_LOG_H_R.$warn_flg));
			ret.warn_flg(true);
		}

		if (logType.equals("E")) {
			q = q.set(S0.emsg_seq).eq(bind(FCT_BATCH_LOG_H_R.$emsg_seq));
			q = q.set(S0.end_flg).eq(bind(FCT_BATCH_LOG_H_R.$end_flg));
			ret.emsg_seq(lastSeq);
			ret.end_flg(true);
		}
		q = q.where(S0.batch_log_no.eq(bind(FCT_BATCH_LOG_H_R.$batch_log_no)));
		q.executeUpdate(dbTran4Logger(), ret, null);
		return ret;
	}

	/**
	 * ログ連番を発番します。
	 * 
	 * @param cnt 発番するログ連番の数
	 */
	protected MCList<MCRow> numberingLogSeq(int cnt) {
		closeCheck();
		MCList<MCRow> ret = MCList.create(MCRow.class);
		MCRow bind = MCRow.create();
		bind.setNumberNE("cnt", cnt);

		dbTran4Logger().statement().executeQuery("FXBAL120_NUMBERING_LOGSEQ",
				FXBAL120_F_NUMBERING_LOGSEQ, bind, null, null, ret);
		return ret;
	}

	protected void copyBind(BatchLogMsgR row, MCMessage msg) {
		if (msg == null) {
			return;
		}
		String[] binds = msg.getBindArray();
		if (binds == null) {
			return;
		}
		for (int i = 0; i < binds.length; i++) {
			int cnt = i + 1;
			String colNm = "prm" + FXUCC_DataUtil.lpad(cnt, 2, "0");
			if (row.contains(colNm)) {
				int len = row.getMeta(colNm).length();
				String bind = binds[i];
				if (bind != null && bind.length() > len) {
					bind = bind.substring(0, len);
				}
				row.setString(colNm, bind);
			}
			else {
				throw new MCException(FXBAL0030, cnt - 1, binds.length, msg.getID());
			}
		}
	}

	protected boolean isErr(MCMessageLevel lvl) {
		switch (lvl) {
			case FATAL:
			case ERROR:
			case PROBLEM:
			case WARN:
				return true;
			case INFO:
			case DEBUG:
			case TRACE:
				return false;
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 * @exception FXBAL0029 備考の数が多すぎる場合
	 */
	@Override
	public void setRmrks(String... rmrks) {
		closeCheck();

		// setargs
		BatchLogHR bind = BatchLogHR.create();
		if (rmrks != null) {
			String[] rmrksColNames = rmrksCols();
			if (rmrks.length > rmrksColNames.length) {
				throw new MCException(FXBAL0029, rmrksColNames.length, rmrks.length);
			}

			bind.batch_log_no(_logNo);

			for (int i = 0; i < rmrks.length; i++) {
				bind.setString(rmrksColNames[i], rmrks[i]);
			}
		}

		FCT_BATCH_LOG_H_R S0 = FCT_BATCH_LOG_H_R.create();
		MCUpdate q = sql("FXBAL120_UPD_HEADER01").update(S0).set(S0.rmrks1)
				.eq(bind("rmrks1")).set(S0.rmrks2).eq(bind("rmrks2")).set(S0.rmrks3)
				.eq(bind("rmrks3")).set(S0.rmrks4).eq(bind("rmrks4")).set(S0.rmrks5)
				.eq(bind("rmrks5")).set(S0.rmrks6).eq(bind("rmrks6")).set(S0.rmrks7)
				.eq(bind("rmrks7")).set(S0.rmrks8).eq(bind("rmrks8")).set(S0.rmrks9)
				.eq(bind("rmrks9")).set(S0.rmrks10).eq(bind("rmrks10"))
				.where(S0.batch_log_no.eq(bind("batch_log_no")));
		q.executeUpdate(dbTran4Logger(), bind, null);
		dbTran4Logger().fwCommit();
	}

	/**
	 * 現在のログヘッダに設定されている備考情報を返します。
	 * 
	 * @return 備考の配列
	 */
	@Override
	public String[] getRmrks() {
		closeCheck();

		BatchLogHR bind = BatchLogHR.create();
		bind.batch_log_no(_logNo);
		MCRow result = MCRow.create();

		FCT_BATCH_LOG_H_R S0 = FCT_BATCH_LOG_H_R.create();
		MCMainQuery q = sql("FXBAL120_SELECT_RMRKS").mainQuery()
				.select(S0.rmrks1.as("rmrks1"), S0.rmrks2.as("rmrks2"),
						S0.rmrks3.as("rmrks3"), S0.rmrks4.as("rmrks4"),
						S0.rmrks5.as("rmrks5"), S0.rmrks6.as("rmrks6"),
						S0.rmrks7.as("rmrks7"), S0.rmrks8.as("rmrks8"),
						S0.rmrks9.as("rmrks9"), S0.rmrks10.as("rmrks10"))
				.from(S0).where(S0.batch_log_no.eq(bind("batch_log_no")));
		q.executeQuery(dbTran4Logger(), bind, null, result);

		String[] cols = rmrksCols();
		String[] ret = new String[cols.length];
		for (int i = 0; i < cols.length; i++) {
			ret[i] = result.getString(cols[i]);
		}
		return ret;
	}

	protected String[] rmrksCols() {
		return new String[] {
				BatchLogHR.$rmrks1, BatchLogHR.$rmrks2, BatchLogHR.$rmrks3,
				BatchLogHR.$rmrks4, BatchLogHR.$rmrks5, BatchLogHR.$rmrks6,
				BatchLogHR.$rmrks7, BatchLogHR.$rmrks8, BatchLogHR.$rmrks9,
				BatchLogHR.$rmrks10
		};
	}

	/**
	 * PLSQLにバッチログ情報を引き継ぎます。
	 */
	@Override
	public void inheritToPlsql(MCDBTransaction tran) {
		MCRow inRow = MCRow.create();
		inRow.setStringNE("batchLogNo", _logNo);
		inRow.setNumberNE("logSubKey1", DEFAULT_LOG_SUB_KEY1_PLSQL);
		inRow.setNumberNE("logSubKey2", 0);
		inRow.setStringNE("dataRefCtl", _dataRefCtl);
		tran.statement().execProc(FXBAL120_FCPA_BATCH_LOG_P_INHERIT, inRow);
	}

	/**
	 * PLSQLへのバッチログ情報引き継ぎを解除します。
	 */
	public void releaseInheritFromPlsql(MCDBTransaction tran) {
		MCRow inRow = MCRow.create();
		tran.statement().execProc(FXBAL120_FCPA_BATCH_LOG_P_RELEASE_INHERIT, inRow);
	}

	/**
	 * 
	 * このロガーの使用を終了します。
	 *
	 * クローズされたロガーでは、ログ出力することはできなくなります。
	 *
	 * @throws Exception
	 * @see java.lang.AutoCloseable#close()
	 */
	@Override
	public void close() {
		// NormalBatchLoggerの_tranは、NormalBatchLogger間で共有されているのでクローズしない。
		// 自身がクローズされたことを示すために_tranにはnullを設定する。
		_tran = null;
	}
	
	private void autotestDummyBeforeCommit() {
		if(!_autotestdev) return;
		mcframe.serverCore.phase.MCLogicBeforeAfter ph = mcframe.serverCore.resource.MCConst.plugin.create(mcframe.serverCore.phase.MCLogicBeforeAfter.class,
				"dispatcher.logicBeforeAfter.class");
		if(ph != null) {
			try {
				mcframe.commonCore.sys.MCFactory.invoke(ph, "autotestDummyBeforeCommit", null, null);
			}
			catch (Exception e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
			
		}
	}

}
