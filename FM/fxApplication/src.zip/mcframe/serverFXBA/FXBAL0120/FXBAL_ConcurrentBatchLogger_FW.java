package mcframe.serverFXBA.FXBAL0120;

import static mcframe.commonFX.notice.FX_Msg.*;

import mcframe.commonCore.notice.MCException;
import mcframe.serverCore.mcjdbc.MCDBTransaction;
import mcframe.serverCore.mcjdbc.MCTransactionManager;

public class FXBAL_ConcurrentBatchLogger_FW extends FXBAL_NormalBatchLogger_FW {

	/**
	 * ログ出力に使用するトランザクションです。
	 */
	protected MCDBTransaction _tran;

	private void closeCheck() {
		if(_tran == null) {
			throw new MCException(FXBAL0031);
		}		
	}

	@Override
	public FXBAL_ConcurrentBatchLogger_FW clone() {
		closeCheck();

		FXBAL_ConcurrentBatchLogger_FW logger = null;
		logger = (FXBAL_ConcurrentBatchLogger_FW) super.clone();
		logger._tran = MCTransactionManager.createDBTran(false);
		return logger;
	}

	@Override
	protected MCDBTransaction dbTran4Logger() {
		return _tran;
	}

	/**
	 * コンストラクタです。
	 * @param dataRefCtl データ参照制御用文字列
	 */
	FXBAL_ConcurrentBatchLogger_FW(MCDBTransaction tran, String dataRefCtl) {
		super(tran, dataRefCtl);
		_tran = tran;
	}

	/**
	 * 
	 * このロガーの使用を終了します。
	 *
	 * クローズされたロガーでは、ログ出力することはできなくなります。
	 *
	 * @throws Exception
	 * @see java.lang.AutoCloseable#close()
	 */
	@Override
	public void close() {
		MCTransactionManager.releaseDBTran(_tran);
		_tran = null;
		super.close();
	}

}
