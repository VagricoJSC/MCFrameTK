package mcframe.serverFXBA.FXBAL0120;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.logic.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

//手修正によるカスタマイズで必要なimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.serverCore.dbc.FCT_BATCH_LOG_H_R;
import mcframe.serverCore.dbc.FCT_BATCH_LOG_MSG_R;
import mcframe.serverCore.util.MCDBUtil;
//FMCB CUSTOM_IMPORT END

/**
 * "BatchLog"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class BatchLog_FW extends BatchLog_FW_A{
	//FMCB CUSTOM START

	/**
	 * Srch01オペレーション.<p>
	 *
	 */
	public class Srch01 extends BatchLog_FW_A.Srch01 {
		@Override
		protected void call() {
			// ヘッダ情報を取得する
			MCDBUtil.dbSelectKey("FXBAL120_SELECT_HEADER01", down0(),
					createBatchLogHeaderBuilder(), up0());

			// 明細情報を取得する
			MCDBUtil.dbSelect("FXBAL120_SELECT_MSG01", down1(),
					createBatchLogMsgBuilder(), up0());
		}

		protected MCQueryApiBuilder createBatchLogHeaderBuilder() {
			FCT_BATCH_LOG_H_R loghR = FCT_BATCH_LOG_H_R.create("T");
			MCQueryApiBuilder builder = MCQueryApiBuilder.create(loghR);
			builder = builder.setSelect(loghR.batch_log_no,
					loghR.req_no, loghR.data_ref_ctl,
					loghR.start_ts, loghR.last_ts,
					loghR.login_seq, loghR.emsg_seq,
					loghR.ext_attr1, loghR.ext_attr2,
					loghR.ext_attr3, loghR.usr_cd,
					loghR.gp_batch_grp_cd, loghR.call_module_id,
					loghR.call_logic_id, loghR.call_operation_id,
					loghR.call_pg_id, loghR.call_clt_id,
					loghR.call_plsql_id, loghR.lcl_cd,
					loghR.end_flg, loghR.warn_flg,
					loghR.rmrks1, loghR.rmrks2, loghR.rmrks3,
					loghR.rmrks4, loghR.rmrks5, loghR.rmrks6,
					loghR.rmrks7, loghR.rmrks8, loghR.rmrks9,
					loghR.rmrks10)
					.addWhereWithAnd(loghR.batch_log_no.eq(bind("batch_log_no")))
					.setOrderByAsc(loghR.batch_log_no);
			return builder;
		}

		protected MCQueryApiBuilder createBatchLogMsgBuilder() {
			FCT_BATCH_LOG_MSG_R msgR = FCT_BATCH_LOG_MSG_R.create("T");
			MCQueryApiBuilder builder = MCQueryApiBuilder.create(msgR);
			builder.setSelect(msgR.batch_log_no, msgR.seq, msgR.log_sub_key1, msgR.log_sub_key2,
					msgR.batch_log_typ, msgR.msg_id, msgR.msg_lvl, msgR.msg_txt,
					msgR.log_ts, msgR.prm01, msgR.prm02, msgR.prm03, msgR.prm04, msgR.prm05,
					msgR.prm06, msgR.prm07, msgR.prm08, msgR.prm09, msgR.prm10, msgR.prm11,
					msgR.prm12, msgR.prm13, msgR.prm14, msgR.prm15, msgR.prm16, msgR.prm17,
					msgR.prm18, msgR.prm19, msgR.prm20, msgR.prm21, msgR.prm22, msgR.prm23,
					msgR.prm24, msgR.prm25, msgR.prm26, msgR.prm27, msgR.prm28, msgR.prm29,
					msgR.prm30, msgR.prm31, msgR.prm32, msgR.prm33, msgR.prm34, msgR.prm35,
					msgR.prm36, msgR.prm37, msgR.prm38, msgR.prm39, msgR.prm40)
			.addWhereWithAnd(msgR.batch_log_no.eq(bind("batch_log_no")))
			.addWhereWithCutOffAnd(msgR.log_sub_key1.eq(bind("log_sub_key1")))
			.addWhereWithCutOffAnd(msgR.log_sub_key2.eq(bind("log_sub_key2")))
			.setOrderByAsc(msgR.batch_log_no, msgR.seq);
			return builder;
		}

	}
	//FMCB CUSTOM END
}