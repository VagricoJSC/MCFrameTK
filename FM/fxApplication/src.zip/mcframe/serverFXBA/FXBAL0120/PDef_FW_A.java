package mcframe.serverFXBA.FXBAL0120;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cn;

/**
 * [BatchLog]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FX.FXBAL0120.Srch01.UP.BLOCK0")){
			return FX_FXBAL0120_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0120.Srch01.DOWN.BLOCK0")){
			return FX_FXBAL0120_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0120.Srch01.DOWN.BLOCK1")){
			return FX_FXBAL0120_Srch01_DOWN_BLOCK1();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
	
	
	static final MCOperationInfo FX_FXBAL0120_Srch01_INFO = new MCOperationInfo("FX", "FXBAL0120", "Srch01", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0120_Srch01_UP_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0120", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("batch_log_no", true, "batch_log_no"),
				MCItemDef.create("log_sub_key1", "log_sub_key1"),
				MCItemDef.create("log_sub_key2", "log_sub_key2")
			}
			,
			MCBlockDef.create("Cnd")
		);
	}


	public static MCContainerDef FX_FXBAL0120_Srch01_DOWN_BLOCK0() {

		return new MCGeneralContainerDef("FX", "FXBAL0120", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("batch_log_no", "batch_log_no"),
				MCItemDef.create("req_no", "req_no"),
				MCItemDef.create("data_ref_ctl", "data_ref_ctl"),
				MCItemDef.create("start_ts", "start_ts"),
				MCItemDef.create("last_ts", "last_ts"),
				MCItemDef.create("login_seq", "login_seq"),
				MCItemDef.create("emsg_seq", "emsg_seq"),
				MCItemDef.create("ext_attr1", "ext_attr1"),
				MCItemDef.create("ext_attr2", "ext_attr2"),
				MCItemDef.create("ext_attr3", "ext_attr3"),
				MCItemDef.create("usr_cd", "usr_cd"),
				MCItemDef.create("gp_batch_grp_cd", "gp_batch_grp_cd"),
				MCItemDef.create("call_module_id", "call_module_id"),
				MCItemDef.create("call_logic_id", "call_logic_id"),
				MCItemDef.create("call_operation_id", "call_operation_id"),
				MCItemDef.create("call_pg_id", "call_pg_id"),
				MCItemDef.create("call_clt_id", "call_clt_id"),
				MCItemDef.create("call_plsql_id", "call_plsql_id"),
				MCItemDef.create("lcl_cd", "lcl_cd"),
				MCItemDef.create("end_flg", "end_flg"),
				MCItemDef.create("warn_flg", "warn_flg"),
				MCItemDef.create("rmrks1", "rmrks1"),
				MCItemDef.create("rmrks2", "rmrks2"),
				MCItemDef.create("rmrks3", "rmrks3"),
				MCItemDef.create("rmrks4", "rmrks4"),
				MCItemDef.create("rmrks5", "rmrks5"),
				MCItemDef.create("rmrks6", "rmrks6"),
				MCItemDef.create("rmrks7", "rmrks7"),
				MCItemDef.create("rmrks8", "rmrks8"),
				MCItemDef.create("rmrks9", "rmrks9"),
				MCItemDef.create("rmrks10", "rmrks10")
			}
			,
			MCBlockDef.create("BatchLogH")
		);
	}
	public static MCContainerDef FX_FXBAL0120_Srch01_DOWN_BLOCK1() {

		return new MCGeneralContainerDef("FX", "FXBAL0120", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("batch_log_no", "batch_log_no"),
				MCItemDef.create("seq", "seq"),
				MCItemDef.create("log_sub_key1", "log_sub_key1"),
				MCItemDef.create("log_sub_key2", "log_sub_key2"),
				MCItemDef.create("batch_log_typ", "batch_log_typ"),
				MCItemDef.create("msg_id", "msg_id"),
				MCItemDef.create("msg_lvl", "msg_lvl"),
				MCItemDef.create("msg_txt", "msg_txt"),
				MCItemDef.create("log_ts", "log_ts"),
				MCItemDef.create("prm01", "prm01"),
				MCItemDef.create("prm02", "prm02"),
				MCItemDef.create("prm03", "prm03"),
				MCItemDef.create("prm04", "prm04"),
				MCItemDef.create("prm05", "prm05"),
				MCItemDef.create("prm06", "prm06"),
				MCItemDef.create("prm07", "prm07"),
				MCItemDef.create("prm08", "prm08"),
				MCItemDef.create("prm09", "prm09"),
				MCItemDef.create("prm10", "prm10"),
				MCItemDef.create("prm11", "prm11"),
				MCItemDef.create("prm12", "prm12"),
				MCItemDef.create("prm13", "prm13"),
				MCItemDef.create("prm14", "prm14"),
				MCItemDef.create("prm15", "prm15"),
				MCItemDef.create("prm16", "prm16"),
				MCItemDef.create("prm17", "prm17"),
				MCItemDef.create("prm18", "prm18"),
				MCItemDef.create("prm19", "prm19"),
				MCItemDef.create("prm20", "prm20"),
				MCItemDef.create("prm21", "prm21"),
				MCItemDef.create("prm22", "prm22"),
				MCItemDef.create("prm23", "prm23"),
				MCItemDef.create("prm24", "prm24"),
				MCItemDef.create("prm25", "prm25"),
				MCItemDef.create("prm26", "prm26"),
				MCItemDef.create("prm27", "prm27"),
				MCItemDef.create("prm28", "prm28"),
				MCItemDef.create("prm29", "prm29"),
				MCItemDef.create("prm30", "prm30"),
				MCItemDef.create("prm31", "prm31"),
				MCItemDef.create("prm32", "prm32"),
				MCItemDef.create("prm33", "prm33"),
				MCItemDef.create("prm34", "prm34"),
				MCItemDef.create("prm35", "prm35"),
				MCItemDef.create("prm36", "prm36"),
				MCItemDef.create("prm37", "prm37"),
				MCItemDef.create("prm38", "prm38"),
				MCItemDef.create("prm39", "prm39"),
				MCItemDef.create("prm40", "prm40")
			}
			,
			MCBlockDef.create("BatchLogMsg")
		);
	}
	//FMCB DEF_CLASSES END
}

