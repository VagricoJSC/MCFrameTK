package mcframe.serverFXBA.FXBAL0120;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.serverCore.mcjdbc.MCDBTransaction;

public interface FXBAL_BatchLogger extends AutoCloseable {

	/**
	 * ログNoを取得します。
	 * @return ログNo
	 */
	public String getBatchLogNo();

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * listに含まれるMCRowのそれぞれに個別のログサブキーを設定します。
	 * @param list データログに関連図けるコンテナ
	 */
	public void setLogKey(MCList<? extends MCRow> list);

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * listに含まれるMCRowのそれぞれに個別のログサブキーを設定します。
	 * @param list データログに関連図けるコンテナ
	 * @param batchLogNoCol ログNoを設定するコンテナのカラム名
	 * @param logSubKey1Col ログNoを設定するコンテナのカラム名
	 * @param logSubKey2Col ログNoを設定するコンテナのカラム名
	 */
	public void setLogKey(MCList<? extends MCRow> list, String batchLogNoCol,
			String logSubKey1Col, String logSubKey2Col);

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * @param row データログに関連図けるコンテナ
	 */
	public void setLogKey(MCRow row);

	/**
	 * データログに関連づけるコンテナにログNo、ログサブキー1、ログサブキー2を設定します。
	 * @param row データログに関連図けるコンテナ
	 * @param batchLogNoCol ログNoを設定するコンテナのカラム名
	 * @param logSubKey1Col ログNoを設定するコンテナのカラム名
	 * @param logSubKey2Col ログNoを設定するコンテナのカラム名
	 */
	public void setLogKey(MCRow row, String batchLogNoCol, String logSubKey1Col,
			String logSubKey2Col);
	
	/**
	 * 開始ログを出力します。
	 * @param ex 例外情報
	 */
	public void writeStartLog(MCException ex);
	
	/**
	 * 開始ログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	public void writeStartLog(String id, Object... binds);
	
	/**
	 * 開始ログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	public void writeStartLog(MCMessage msg);

	/**
	 * 処理経過ログを出力します。
	 * @param ex 例外情報
	 */
	public void writeProcessLog(MCException ex);

	/**
	 * 処理経過ログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	public void writeProcessLog(String id, Object... binds);
	
	/**
	 * 処理経過ログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	public void writeProcessLog(MCMessage msg);
	
	/**
	 * 処理経過ログを出力します。
	 * @param msgList バッチログにメッセージ情報のリスト
	 */
	public void writeProcessLog(MCMessageList msgList);

	/**
	 * データログを出力します。
	 * @param ex 例外情報
	 */
	public void writeDataLog(MCException ex);

	/**
	 * データログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	public void writeDataLog(String id, Object... binds);

	/**
	 * データログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	public void writeDataLog(MCMessage msg);
	
	/**
	 * データログを出力します。
	 * @param causeRow データログに関連させるMCRow
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	public void writeDataLog(MCRow causeRow, String id, Object... binds);

	/**
	 * データログを出力します。
	 * @param causeRow データログに関連させるMCRow
	 * @param msg バッチログに出力するメッセージ情報
	 */
	public void writeDataLog(MCRow causeRow, MCMessage msg);

	/**
	 * データログを出力します。
	 * @param msgList バッチログに出力するメッセージ情報
	 */
	public void writeDataLog(MCMessageList msgList);

	/**
	 * 終了ログを出力します。
	 * @param ex 例外情報
	 */
	public void writeEndLog(MCException ex);

	/**
	 * 終了ログを出力します。
	 * @param id メッセージID
	 * @param binds メッセージに埋め込む値
	 */
	public void writeEndLog(String id, Object... binds);
	
	/**
	 * 終了ログを出力します。
	 * @param msg バッチログに出力するメッセージ情報
	 */
	public void writeEndLog(MCMessage msg);

	/**
	 * 備考を設定します。
	 * <p>
	 * 配列の長さが 10 未満の場合は、それ以降の備考はnullとみなす。
	 * （なので、配列の長さが 0 の場合は全て null クリアされることになる。）
	 * </p>
	 * @param rmrks 
	 */
	public void setRmrks(String... rmrks);

	/**
	 * 現在のログヘッダに設定されている備考情報を返します。
	 * 
	 * @return 備考の配列
	 */
	public String[] getRmrks();

	/**
	 * PLSQLにバッチログ情報を引き継ぎます。
	 * @param tran 同じバッチログNoでバッチログを出力するPLSQLを実行するトランザクション
	 */
	public void inheritToPlsql(MCDBTransaction tran);

	public FXBAL_BatchLogger clone();
	
	/**
	 * 
	 * このロガーの使用を終了します。
	 *
	 * クローズされたロガーでは、ログ出力することはできなくなります。
	 *
	 * @see java.lang.AutoCloseable#close()
	 */
	@Override
	public void close();

}
