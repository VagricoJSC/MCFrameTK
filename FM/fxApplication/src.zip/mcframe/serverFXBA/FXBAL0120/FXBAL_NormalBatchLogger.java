package mcframe.serverFXBA.FXBAL0120;

import mcframe.commonCore.annotation.EI;
import mcframe.serverCore.mcjdbc.MCDBTransaction;

@EI
public class FXBAL_NormalBatchLogger extends FXBAL_NormalBatchLogger_FW {

	/**
	 * コンストラクタです。
	 * @param dataRefCtl データ参照制御用文字列
	 */
	FXBAL_NormalBatchLogger(MCDBTransaction tran, String dataRefCtl) {
		super(tran, dataRefCtl);
	}

}
