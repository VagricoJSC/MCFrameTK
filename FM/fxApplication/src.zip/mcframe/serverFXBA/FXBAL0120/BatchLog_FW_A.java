package mcframe.serverFXBA.FXBAL0120;

import java.util.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.param.*;
import mcframe.serverCore.logic.*;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
//FMCB IMPORT START
//FMCB IMPORT END
import static mcframe.serverCore.logic.MCLogicUtil.*;

/**
 * "BatchLog"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class BatchLog_FW_A extends mcframe.serverCore.logic.MCLogicBase {
	/** 
	 * モジュールID<p>
	 *
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * ロジックID<p>
	 *
	 * ロジックはモジュールIDとロジックIDで一意に特定できます。<br>
	 * ロジックインスタンスもしくはオペレーションインスタンスから参照する場合には{@link #getLogicID()}を使用してください。
	 */
	public static final String LOGIC_ID = "FXBAL0120";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** ロジックIDを取得します。 */
	public String getLogicID(){ return LOGIC_ID; }

	//FMCB CTRL_FIELD_METHOD START

	protected BatchLog.Srch01 aSrch01;

	protected void initSrch01() {
		this.info = PDef.FX_FXBAL0120_Srch01_INFO;
		this.aSrch01 = ((BatchLog)this).new Srch01();
	}

	public static BatchLog.Srch01 crtSrch01() {
		BatchLog lgc = new BatchLog();
		lgc.initSrch01();
		return lgc.aSrch01;
	}

	protected void paramSrch01(MCParam p) {
		if (this.aSrch01 == null) {
			return;
		}
		p.setDef(this.info.def);
		p.addUpBlock(aSrch01.up0());
		p.addDownBlock(aSrch01.down0());
		p.addDownBlock(aSrch01.down1());
	}

	protected void doSrch01() {
		aSrch01.call();
	};

	/**
	 * CndブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0120.CndR createCndR(){
		return mcframe.serverFXBA.FXBAL0120.CndR.create();
	}

	/**
	 * CndブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0120.CndR> createCndL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0120.CndR.class);
	}

	/**
	 * BatchLogHブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0120.BatchLogHR createBatchLogHR(){
		return mcframe.serverFXBA.FXBAL0120.BatchLogHR.create();
	}

	/**
	 * BatchLogHブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0120.BatchLogHR> createBatchLogHL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0120.BatchLogHR.class);
	}

	/**
	 * BatchLogMsgブロックのRowコンテナを作成します。
	 *
	 * @return Rowコンテナ
	 */
	public mcframe.serverFXBA.FXBAL0120.BatchLogMsgR createBatchLogMsgR(){
		return mcframe.serverFXBA.FXBAL0120.BatchLogMsgR.create();
	}

	/**
	 * BatchLogMsgブロックのListコンテナを作成します。
	 *
	 * @return Listコンテナ
	 */
	public MCList<mcframe.serverFXBA.FXBAL0120.BatchLogMsgR> createBatchLogMsgL(){
		return MCList.create(mcframe.serverFXBA.FXBAL0120.BatchLogMsgR.class);
	}

	//FMCB CTRL_FIELD_METHOD END

	//FMCB LOGIC_CONTROLLER START

	/**
	 * Srch01オペレーション.<p>
	 *
	 * ログＮＯを指定してバッチログ情報を取得する<br>
	 */
	abstract public class Srch01 extends MCOperation {
		/** 
		 * オペレーションID<p>
		 *
		 * オペレーションはモジュールIDとロジックIDとオペレーションIDによって一意に特定できます。<br>
		 * オペレーションインスタンスから参照する場合には{@link #getOperationID()}を使用してください。
		 */
		public static final String OPERATION_ID = "Srch01";

		/** オペレーションIDを取得します。 */
		public String getOperationID(){ return OPERATION_ID; }

		//----------フィールド----------
		/** このオペレーションへの上り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0120.CndR> up0;
		/** このオペレーションからの下り電文パラメータの第0ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0120.BatchLogHR> down0;
		/** このオペレーションからの下り電文パラメータの第1ブロックのコンテナField定義 */
		private final MCList<mcframe.serverFXBA.FXBAL0120.BatchLogMsgR> down1;
		
		
		// コンストラクタ
		protected Srch01() {
			
			// このオペレーションのコンテナ初期化
			up0 = MCList.create(mcframe.serverFXBA.FXBAL0120.CndR.class);
			down0 = MCList.create(mcframe.serverFXBA.FXBAL0120.BatchLogHR.class);
			down1 = MCList.create(mcframe.serverFXBA.FXBAL0120.BatchLogMsgR.class);

			// 連携オペレーションの初期化
			
			// 連携オペレーションのコンテナ取得

			// オペレーション、オペレーショングループの登録
		}

		/**
		 * 指定された連携処理の上りブロックを準備する。<p>
		 *
		 */
		public void mapUpContainers(String key) {
			super.mapUpContainers(key);
		}

		/**
		 * 指定された連携処理の下りブロックから値をコピーする。<p>
		 *
		 */
		public void mapDownContainers(String key) {
			super.mapDownContainers(key);
		}

		public MCContainer up(int i) {
			if (i == 0) return up0();
			return null;
		}
		
		public MCContainer down(int i) {
			if (i == 0) return down0();
			if (i == 1) return down1();
			return null;
		}

		public void exec() {
			clear();
			invoke((BatchLog)BatchLog_FW_A.this);
		}
		
		protected void clear() {
			down0().clear();
			down1().clear();
		}
		/**
		 * CndブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0120.CndR createCndR(){
			return mcframe.serverFXBA.FXBAL0120.CndR.create();
		}

		/**
		 * CndブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0120.CndR> createCndL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0120.CndR.class);
		}

		/**
		 * BatchLogHブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0120.BatchLogHR createBatchLogHR(){
			return mcframe.serverFXBA.FXBAL0120.BatchLogHR.create();
		}

		/**
		 * BatchLogHブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0120.BatchLogHR> createBatchLogHL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0120.BatchLogHR.class);
		}

		/**
		 * BatchLogMsgブロックのRowコンテナを作成します。
		 *
		 * @return Rowコンテナ
		 */
		public mcframe.serverFXBA.FXBAL0120.BatchLogMsgR createBatchLogMsgR(){
			return mcframe.serverFXBA.FXBAL0120.BatchLogMsgR.create();
		}

		/**
		 * BatchLogMsgブロックのListコンテナを作成します。
		 *
		 * @return Listコンテナ
		 */
		public MCList<mcframe.serverFXBA.FXBAL0120.BatchLogMsgR> createBatchLogMsgL(){
			return MCList.create(mcframe.serverFXBA.FXBAL0120.BatchLogMsgR.class);
		}

		//-------------------------外部 I/F--------------------------
		/**
		 * 上り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[上り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr bgcolor="#ffccff"><td>*</td><td>batch_log_no</td></tr>
		 * 	<tr><td><br></td><td>log_sub_key1</td></tr>
		 * 	<tr><td><br></td><td>log_sub_key2</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0120.CndR> up0() {
			return up0;
		}


		/**
		 * 下り電文の第0ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第0ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr><td><br></td><td>batch_log_no</td></tr>
		 * 	<tr><td><br></td><td>req_no</td></tr>
		 * 	<tr><td><br></td><td>data_ref_ctl</td></tr>
		 * 	<tr><td><br></td><td>start_ts</td></tr>
		 * 	<tr><td><br></td><td>last_ts</td></tr>
		 * 	<tr><td><br></td><td>login_seq</td></tr>
		 * 	<tr><td><br></td><td>emsg_seq</td></tr>
		 * 	<tr><td><br></td><td>ext_attr1</td></tr>
		 * 	<tr><td><br></td><td>ext_attr2</td></tr>
		 * 	<tr><td><br></td><td>ext_attr3</td></tr>
		 * 	<tr><td><br></td><td>usr_cd</td></tr>
		 * 	<tr><td><br></td><td>gp_batch_grp_cd</td></tr>
		 * 	<tr><td><br></td><td>call_module_id</td></tr>
		 * 	<tr><td><br></td><td>call_logic_id</td></tr>
		 * 	<tr><td><br></td><td>call_operation_id</td></tr>
		 * 	<tr><td><br></td><td>call_pg_id</td></tr>
		 * 	<tr><td><br></td><td>call_clt_id</td></tr>
		 * 	<tr><td><br></td><td>call_plsql_id</td></tr>
		 * 	<tr><td><br></td><td>lcl_cd</td></tr>
		 * 	<tr><td><br></td><td>end_flg</td></tr>
		 * 	<tr><td><br></td><td>warn_flg</td></tr>
		 * 	<tr><td><br></td><td>rmrks1</td></tr>
		 * 	<tr><td><br></td><td>rmrks2</td></tr>
		 * 	<tr><td><br></td><td>rmrks3</td></tr>
		 * 	<tr><td><br></td><td>rmrks4</td></tr>
		 * 	<tr><td><br></td><td>rmrks5</td></tr>
		 * 	<tr><td><br></td><td>rmrks6</td></tr>
		 * 	<tr><td><br></td><td>rmrks7</td></tr>
		 * 	<tr><td><br></td><td>rmrks8</td></tr>
		 * 	<tr><td><br></td><td>rmrks9</td></tr>
		 * 	<tr><td><br></td><td>rmrks10</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0120.BatchLogHR> down0() {
			return down0;
		}

		/**
		 * 下り電文の第1ブロックのデータを格納するコンテナを取得します。<p>
		 *
		 * <table border=1 cellspacing=0 cellpadding=2 >
		 *  <caption>[下り第1ブロック項目]</caption>
		 * 	<tr bgcolor="#cccccc"><th>必須</th><th>項目名</th></tr>
		 * 	<tr><td><br></td><td>batch_log_no</td></tr>
		 * 	<tr><td><br></td><td>seq</td></tr>
		 * 	<tr><td><br></td><td>log_sub_key1</td></tr>
		 * 	<tr><td><br></td><td>log_sub_key2</td></tr>
		 * 	<tr><td><br></td><td>batch_log_typ</td></tr>
		 * 	<tr><td><br></td><td>msg_id</td></tr>
		 * 	<tr><td><br></td><td>msg_lvl</td></tr>
		 * 	<tr><td><br></td><td>msg_txt</td></tr>
		 * 	<tr><td><br></td><td>log_ts</td></tr>
		 * 	<tr><td><br></td><td>prm01</td></tr>
		 * 	<tr><td><br></td><td>prm02</td></tr>
		 * 	<tr><td><br></td><td>prm03</td></tr>
		 * 	<tr><td><br></td><td>prm04</td></tr>
		 * 	<tr><td><br></td><td>prm05</td></tr>
		 * 	<tr><td><br></td><td>prm06</td></tr>
		 * 	<tr><td><br></td><td>prm07</td></tr>
		 * 	<tr><td><br></td><td>prm08</td></tr>
		 * 	<tr><td><br></td><td>prm09</td></tr>
		 * 	<tr><td><br></td><td>prm10</td></tr>
		 * 	<tr><td><br></td><td>prm11</td></tr>
		 * 	<tr><td><br></td><td>prm12</td></tr>
		 * 	<tr><td><br></td><td>prm13</td></tr>
		 * 	<tr><td><br></td><td>prm14</td></tr>
		 * 	<tr><td><br></td><td>prm15</td></tr>
		 * 	<tr><td><br></td><td>prm16</td></tr>
		 * 	<tr><td><br></td><td>prm17</td></tr>
		 * 	<tr><td><br></td><td>prm18</td></tr>
		 * 	<tr><td><br></td><td>prm19</td></tr>
		 * 	<tr><td><br></td><td>prm20</td></tr>
		 * 	<tr><td><br></td><td>prm21</td></tr>
		 * 	<tr><td><br></td><td>prm22</td></tr>
		 * 	<tr><td><br></td><td>prm23</td></tr>
		 * 	<tr><td><br></td><td>prm24</td></tr>
		 * 	<tr><td><br></td><td>prm25</td></tr>
		 * 	<tr><td><br></td><td>prm26</td></tr>
		 * 	<tr><td><br></td><td>prm27</td></tr>
		 * 	<tr><td><br></td><td>prm28</td></tr>
		 * 	<tr><td><br></td><td>prm29</td></tr>
		 * 	<tr><td><br></td><td>prm30</td></tr>
		 * 	<tr><td><br></td><td>prm31</td></tr>
		 * 	<tr><td><br></td><td>prm32</td></tr>
		 * 	<tr><td><br></td><td>prm33</td></tr>
		 * 	<tr><td><br></td><td>prm34</td></tr>
		 * 	<tr><td><br></td><td>prm35</td></tr>
		 * 	<tr><td><br></td><td>prm36</td></tr>
		 * 	<tr><td><br></td><td>prm37</td></tr>
		 * 	<tr><td><br></td><td>prm38</td></tr>
		 * 	<tr><td><br></td><td>prm39</td></tr>
		 * 	<tr><td><br></td><td>prm40</td></tr>
		 * </table>
		 *
		 * @see MCList
		 */
		public MCList<mcframe.serverFXBA.FXBAL0120.BatchLogMsgR> down1() {
			return down1;
		}



		@Override
		public MCOperationInfo getOperationInfo(){
			return ((BatchLog)BatchLog_FW_A.this).info;
		}


	}

	//FMCB LOGIC_CONTROLLER END
}