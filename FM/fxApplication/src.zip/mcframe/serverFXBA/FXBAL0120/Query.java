package mcframe.serverFXBA.FXBAL0120;

import static mcframe.serverCore.queryapi.IFMCSQL.*;
import static mcframe.serverCore.dbc.CoreFunction.*;
import static mcframe.serverCore.util.MCDBUtil.*;
import mcframe.serverCore.dbc.*;
import mcframe.serverCore.mcjdbc.MCDatabaseManager;
import mcframe.commonCore.container.MCRow;


/**
 * FSBDL0050で実行するSQL文を記述するクラスです。
 */
public class Query {

	public static String FXBAL120_F_NUMBERING_LOGSEQ = FXBAL120_NormalBatchLogger_Sql
			.get().getF_NUMBERING_LOGSEQ();

	public static String FXBAL120_FCPA_BATCH_LOG_P_INHERIT = FXBAL120_NormalBatchLogger_Sql
			.get().getFCPA_BATCH_LOG_P_INHERIT();

	public static String FXBAL120_FCPA_BATCH_LOG_P_RELEASE_INHERIT = FXBAL120_NormalBatchLogger_Sql
			.get().getFCPA_BATCH_LOG_P_RELEASE_INHERIT();

	enum FXBAL120_NormalBatchLogger_Sql {
		ORACLE {
			@Override
			String getF_NUMBERING_LOGSEQ() {
				return "SELECT SEQ FROM TABLE(FCPA_BATCH_LOG.F_NUMBERING_LOGSEQ(:cnt))";
			}

			@Override
			String getFCPA_BATCH_LOG_P_INHERIT() {
				return "-- FXBAL120_FCPA_BATCH_LOG_P_INHERIT \n"
						+ "FCPA_BATCH_LOG.P_INHERIT(:batchLogNo, :logSubKey1, :logSubKey2, :dataRefCtl)";
			}

			@Override
			String getFCPA_BATCH_LOG_P_RELEASE_INHERIT() {
				return "-- FXBAL120_FCPA_BATCH_LOG_P_RELEASE_INHERIT \n"
						+ "FCPA_BATCH_LOG.P_RELEASE_INHERIT";
			}
		},
		AWSRDS_ORACLE {
			@Override
			String getF_NUMBERING_LOGSEQ() {
				return ORACLE.getF_NUMBERING_LOGSEQ();
			}

			@Override
			String getFCPA_BATCH_LOG_P_INHERIT() {
				return ORACLE.getFCPA_BATCH_LOG_P_INHERIT();
			}

			@Override
			String getFCPA_BATCH_LOG_P_RELEASE_INHERIT() {
				return ORACLE.getFCPA_BATCH_LOG_P_RELEASE_INHERIT();
			}
		},
		POSTGRESQL {
			@Override
			String getF_NUMBERING_LOGSEQ() {
				return "SELECT SEQ FROM FCPA_BATCH_LOG$F_NUMBERING_LOGSEQ(:cnt) SEQ";
			}

			@Override
			String getFCPA_BATCH_LOG_P_INHERIT() {
				return "-- FXBAL120_FCPA_BATCH_LOG_P_INHERIT \n"
						+ "FCPA_BATCH_LOG$P_INHERIT(:batchLogNo, :logSubKey1, :logSubKey2, :dataRefCtl)";
			}

			@Override
			String getFCPA_BATCH_LOG_P_RELEASE_INHERIT() {
				return "-- FXBAL120_FCPA_BATCH_LOG_P_RELEASE_INHERIT \n"
						+ "FCPA_BATCH_LOG$P_RELEASE_INHERIT";
			}
		},
		AWSRDS_POSTGRESQL {
			@Override
			String getF_NUMBERING_LOGSEQ() {
				return POSTGRESQL.getF_NUMBERING_LOGSEQ();
			}

			@Override
			String getFCPA_BATCH_LOG_P_INHERIT() {
				return POSTGRESQL.getFCPA_BATCH_LOG_P_INHERIT();
			}

			@Override
			String getFCPA_BATCH_LOG_P_RELEASE_INHERIT() {
				return POSTGRESQL.getFCPA_BATCH_LOG_P_RELEASE_INHERIT();
			}
		};

		static FXBAL120_NormalBatchLogger_Sql get() {
			if (MCDatabaseManager.isOracleLocal()) {
				return ORACLE;
			}
			if (MCDatabaseManager.isAwsRdsOracle()) {
				return AWSRDS_ORACLE;
			}
			if (MCDatabaseManager.isPostgreSqlLocal()) {
				return POSTGRESQL;
			}
			if (MCDatabaseManager.isAwsPostgreSqlLocal()) {
				return AWSRDS_POSTGRESQL;
			}
			return ORACLE;
		}

		abstract String getF_NUMBERING_LOGSEQ();

		abstract String getFCPA_BATCH_LOG_P_INHERIT();

		abstract String getFCPA_BATCH_LOG_P_RELEASE_INHERIT();
	}

}
