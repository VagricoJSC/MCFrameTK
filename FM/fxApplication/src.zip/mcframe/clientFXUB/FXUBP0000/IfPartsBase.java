package mcframe.clientFXUB.FXUBP0000;

import mcframe.commonCore.annotation.EI;

@EI
public interface IfPartsBase extends IfPartsBase_FW {

}
