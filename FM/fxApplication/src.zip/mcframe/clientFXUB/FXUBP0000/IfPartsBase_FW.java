package mcframe.clientFXUB.FXUBP0000;

/**
 * 各種部品を使用するベースパネルのためのインターフェース
 *
 */
public interface IfPartsBase_FW {

}
