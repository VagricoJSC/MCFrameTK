package mcframe.clientFXUB.FXUBP0000;

import mcframe.commonCore.annotation.EI;

@EI
public interface IfParts extends IfParts_FW {

}
