package mcframe.clientFXUB.FXUBP0000;

public interface IfParts_FW {

	/**
	 * テーブル部品の場合は true を返します。
	 *
	 * @return テーブル部品ではない場合は false
	 */
	public boolean isTableParts();

	/**
	 * ヘッダ部品用インデックス
	 */
	public static int HEADER_INDEX = -1;

}
