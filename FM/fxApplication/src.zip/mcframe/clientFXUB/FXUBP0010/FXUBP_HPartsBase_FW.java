package mcframe.clientFXUB.FXUBP0010;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFXBA.FXBAP0010.IfHPartsForCaller;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUBP_HPartsBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUBP_HPartsBase_FW extends FXUBP_HPartsBase_FW_A implements IfHPartsForCaller {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUBP_HPartsBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	@Override
	public boolean isTableParts() {
		return false;
	}

	/**
	 * 通信前チェック処理を実行します。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出されます。
	 * 通信定型処理から呼び出されます。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出します。
	 * </P>
	 * @param list メッセージを格納するためのリスト
	 * @param caller 通信処理クラス
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void checkForCallStack(MCMessageList list, MCCaller caller) {
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof IfHPartsForCaller) {
				IfHPartsForCaller pfc = (IfHPartsForCaller) parts;
				pfc.checkForCallStack(list, caller);
			}
		}
	}

	/**
	 * 通信前処理を実行します。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出されます。
	 * 通信定型処理から呼び出されます。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出します。
	 * </P>
	 * @param caller 通信処理クラス
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void beforeCallParts(MCCaller caller) {
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof IfHPartsForCaller) {
				IfHPartsForCaller pfc = (IfHPartsForCaller) parts;
				pfc.beforeCallParts(caller);
			}
		}
	}

	/**
	 * 通信後処理を実行します。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出されます。
	 * 通信定型処理から呼び出されます。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出します。
	 * </P>
	 * @param caller 通信処理クラス
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void afterCallParts(MCCaller caller) {
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof IfHPartsForCaller) {
				IfHPartsForCaller pfc = (IfHPartsForCaller) parts;
				pfc.afterCallParts(caller);
			}
		}
	}

	/**
	 * この部品に配置されている GUI 部品のモードを設定する。<br>
	 * 下記の通り、GUI 部品のモードを設定する。<br>
	 * <ul>
	 * <li>画面ステータスのモードが {@link MCMode#REQUIRED} の場合<br>
	 * <ul>
	 * <li>{@link #getGUIMode(MCModeBeans)} が null 以外を返した場合<br>
	 * {@link #getGUIMode(MCModeBeans)} のモードを設定する。
	 * </li>
	 * <li>{@link #getGUIMode(MCModeBeans)} が null を返した場合<br>
	 * 画面ステータスのモードを設定する。
	 * </li>
	 * </ul>
	 * </li>
	 * <li>画面ステータスのモードが {@link MCMode#ENABLE} の場合<br>
	 * <ul>
	 * <li>{@link #getGUIMode(MCModeBeans)} が null 以外を返した場合<br>
	 * {@link #getGUIMode(MCModeBeans)} のモードを設定する。
	 * </li>
	 * <li>{@link #getGUIMode(MCModeBeans)} が null を返した場合<br>
	 * 画面ステータスのモードを設定する。
	 * </li>
	 * </ul>
	 * </li>
	 * <li>画面ステータスのモードが {@link MCMode#READ_ONLY} の場合<br>
	 * 何もしない。
	 * </li>
	 * <li>画面ステータスのモードが {@link MCMode#DISABLE} の場合<br>
	 * 何もしない。
	 * </li>
	 * <li>画面ステータスのモードが {@link MCMode#INVISIBLE} の場合<br>
	 * 何もしない。
	 * </li>
	 * </ul>
	 *
	 * @see #getGUIMode(MCModeBeans)
	 */
	protected void setGUIMode() {
		MCModeBeans[] a = MCBeansUtil.getAllComponents(MCModeBeans.class, this);
		for (MCModeBeans compo : a) {
			if (isDefaultModeEditable(compo)) {
				MCMode mode = getGUIMode(compo);
				if (mode != null) {
					compo.setMode(mode);
				}
				else {
					setDefaultMode(compo);
				}
			}
		}
	}

	/**
	 * 指定された GUI 部品の入力可否を取得する。<br>
	 * <br>
	 * 画面ステータスのモードが入力不可の場合は false を返す。<br>
	 * 部品の制御で入力不可にしている場合は false を返す。<br>
	 * それ以外の場合は true を返す。
	 *
	 * @param compo GUI 部品
	 * @return GUI 部品の入力可否
	 * @see #getGUIMode(MCModeBeans)
	 */
	public boolean isPartsGUIEditable(MCModeBeans compo) {
		if (!isDefaultModeEditable(compo)) {
			return false;
		}
		MCMode mode = getGUIMode(compo);
		if (mode == null) {
			return true;
		}
		return compo.getModeInfo(mode).getStatus() == MCMode.ENABLE_STATUS;
	}

	/**
	 * 指定された GUI 部品のモードを取得する。<br>
	 * <br>
	 * 部品がモード制御する対象の GUI 部品を指定した場合は、
	 * 部品が制御するためのモードを返す。<br>
	 * 部品がモードを制御しない GUI 部品を指定した場合は null を返す。
	 *
	 * @param compo GUI 部品
	 * @return モードまたは null
	 */
	public MCMode getGUIMode(MCModeBeans compo) {
		return null;
	}

}