package mcframe.clientFXUB.FXUBP0020;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFXBA.FXBAP0010.IfDPartsForCaller;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUBP_DPartsBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUBP_DPartsBase_FW extends FXUBP_DPartsBase_FW_A implements IfDPartsForCaller {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUBP_DPartsBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	@Override
	public boolean isTableParts() {
		return true;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void checkForCallStack(MCMessageList list, MCRowMatcher matcher,
			MCCaller caller) {
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof IfDPartsForCaller) {
				IfDPartsForCaller pfc = (IfDPartsForCaller) parts;
				pfc.checkForCallStack(list, matcher, caller);
			}
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void beforeCallParts(MCRowMatcher matcher, MCCaller caller) {
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof IfDPartsForCaller) {
				IfDPartsForCaller pfc = (IfDPartsForCaller) parts;
				pfc.beforeCallParts(matcher, caller);
			}
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void afterCallParts(MCRowMatcher matcher, MCCaller caller) {
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof IfDPartsForCaller) {
				IfDPartsForCaller pfc = (IfDPartsForCaller) parts;
				pfc.afterCallParts(matcher, caller);
			}
		}
	}

	/**
	 * @deprecated {@link #setPartsCellConfig()} を利用すること。
	 */
	@Deprecated
	@Override
	protected void setCellConfig() {
		super.setCellConfig();
		setPartsCellConfig();
	}

	/**
	 * 部品のテーブルにセルコンフィグを設定する。
	 */
	protected void setPartsCellConfig() {

	}

	/**
	 * 指定されたセルの入力可否を取得する。<br>
	 * <br>
	 * 画面ステータスのモードが入力不可の場合は false を返す。<br>
	 * 部品の制御で入力不可にしている場合は false を返す。<br>
	 * それ以外の場合は true を返す。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @return セルの入力可否
	 */
	public boolean isPartsCellEditable(int index, MCColumnConfig column) {
		if (!isDefaultModeEditable(column)) {
			return false;
		}
		MCMode mode = getCellMode(index, column);
		if (mode == null) {
			return true;
		}
		return column.getModeInfo(mode).getStatus() == MCMode.ENABLE_STATUS;
	}

	/**
	 * 指定されたセルのモードを取得する。<br>
	 * <br>
	 * 部品がモード制御する対象のセルを指定した場合は、
	 * 部品が制御するためのモードを返す。<br>
	 * 部品がモードを制御しないセルを指定した場合は null を返す。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @return モードまたは null
	 */
	protected MCMode getCellMode(int index, MCColumnConfig column) {
		return null;
	}

	@Override
	protected FXBAP_CellConfig createDefaultAppCellConfig() {
		return new FXUBP_CommonCellConfig();
	}

	public class FXUBP_CommonCellConfig extends FXBAP_CellConfig {

		@SuppressWarnings("rawtypes")
		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {
			if (isDefaultModeEditable(column)) {
				return getCellMode(index, column);
			}
			return super.getPriorMode(index, column, table);
		}
	}

}