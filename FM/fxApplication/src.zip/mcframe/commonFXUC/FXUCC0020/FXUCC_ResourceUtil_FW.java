package mcframe.commonFXUC.FXUCC0020;

import java.util.Locale;
import mcframe.commonCore.resource.MCConst;

public class FXUCC_ResourceUtil_FW {
	
	//ThreadLocalではないためsetterの作成は禁止。
	
	protected static FXUCC_ResourceUtil me() {
		return new FXUCC_ResourceUtil();
	}

	/**
	 * カスタマイズ用に作成されたMCConst.dblbl.getLabelのラッパーです。
	 * 
	 * データベーステーブルまたは項目のユーザロケールラベル文字列を返します。
	 *
	 * テーブル名のみ指定した場合、テーブル名のラベル文字列を検索します。<br>
	 * テーブル名と項目名とを指定した場合、項目名のラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * <p>
	 * このメソッドをクライアントで使用する場合、pluginリソースの設定が必要です。<br>
	 * 詳しくは、フレームワークのクラスmcframe.commonCore.resource.MCDBLabelConstのjavaDocを参照してください。
	 * @param tblName テーブル名
	 * @param colName 項目名
	 * @return テーブル名または項目名のラベル文字列。テーブル名未指定の場合はnull。キーがない場合は null
	 */
	public static String getDBLabel(String tblName, String colName) {
		return me()._getDBLabel(tblName, colName);
	}
	
	public String _getDBLabel(String tblName, String colName) {
		return MCConst.dblbl.getLabel(tblName, colName);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.dblbl.getLabelのラッパーです。
	 * 
	 * データベーステーブルまたは項目のラベル文字列を返します。
	 *
	 * テーブル名のみ指定した場合、テーブル名のラベル文字列を検索します。<br>
	 * テーブル名と項目名とを指定した場合、項目名のラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param tblName テーブル名
	 * @param colName 項目名
	 * @param locale ロケール
	 * @return テーブル名または項目名のラベル文字列。テーブル名未指定の場合はnull。キーがない場合は null
	 */
	public static String getDBLabel(String tblName, String colName, Locale locale) {
		return me()._getDBLabel(tblName, colName, locale);
	}
	
	protected String _getDBLabel(String tblName, String colName, Locale locale) {
		return MCConst.dblbl.getLabel(tblName, colName, locale);
	}
	/**
	 * 
	 * カスタマイズ用に作成されたMCConst.lgclbl.getLabelのラッパーです。
	 * 
	 * ロジックＩＤまたはオペレーションＩＤのユーザロケールラベル文字列を返します。
	 *
	 * ロジックＩＤのみ指定した場合、ロジックＩＤのラベル文字列を検索します。<br>
	 * ロジックＩＤとオペレーションＩＤとを指定した場合、オペレーションＩＤのラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * <p>
	 * このメソッドをクライアントで使用する場合、pluginリソースの設定が必要です。<br>
	 * 詳しくは、フレームワークのクラスmcframe.commonCore.resource.MCLogicLabelConstのjavaDocを参照してください。
	 * @param mod モジュールＩＤ
	 * @param lgc ロジックＩＤ
	 * @param ope オペレーションＩＤ
	 * @return ロジックＩＤまたはオペレーションＩＤのラベル文字列。モジュールＩＤとロジックＩＤが未指定の場合はnull。キーがない場合は null
	 */
	public static String getLogicLabel(String mod, String lgc, String ope) {
		return me()._getLogicLabel(mod, lgc, ope);
	}
	
	protected String _getLogicLabel(String mod, String lgc, String ope) {
		return MCConst.lgclbl.getLabel(mod, lgc, ope);
	}
	/**
	 * カスタマイズ用に作成されたMCConst.lgclbl.getLabelのラッパーです。
	 * 
	 * ロジックＩＤまたはオペレーションＩＤのラベル文字列を返します。
	 *
	 * ロジックＩＤのみ指定した場合、ロジックＩＤのラベル文字列を検索します。<br>
	 * ロジックＩＤとオペレーションＩＤとを指定した場合、オペレーションＩＤのラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param mod モジュールＩＤ
	 * @param lgc ロジックＩＤ
	 * @param ope オペレーションＩＤ
	 * @param locale ロケール
	 * @return ロジックＩＤまたはオペレーションＩＤのラベル文字列。モジュールＩＤとロジックＩＤが未指定の場合はnull。キーがない場合は null
	 */
	public static String getLogicLabel(String mod, String lgc, String ope, Locale locale) {
		return me()._getLogicLabel(mod, lgc, ope, locale);
	}
	
	protected String _getLogicLabel(String mod, String lgc, String ope, Locale locale) {
		return MCConst.lgclbl.getLabel(mod, lgc, ope, locale);
	}
}
