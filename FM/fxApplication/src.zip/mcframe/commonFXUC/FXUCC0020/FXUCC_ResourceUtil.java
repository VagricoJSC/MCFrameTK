package mcframe.commonFXUC.FXUCC0020;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCC_ResourceUtil extends FXUCC_ResourceUtil_FW {

}
