package mcframe.commonFXUC.FXUCC0090;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.*;

/**
 * MCRowMapperのコピー処理中に固定的に使う値を使用する値をセットできるRowMapperです
 * <P>
 * ヘッダ・明細をリストに渡す場合にヘッダのRowをセットすることを想定しています。
 * </P>
 * 
 * @param <D> コピー先のRow
 * @param <S> コピー元のRow
 * @param <W> 固定的に使う値
 */
@EI
public abstract class FXUCC_RowMapperWith<D extends MCRow, S extends MCRow, W extends Object>
		extends FXUCC_RowMapperWith_FW<D, S, W> {
}