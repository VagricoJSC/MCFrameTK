package mcframe.commonFXUC.FXUCC0090;

import mcframe.commonCore.container.*;

/**
 * MCRowMapperのコピー処理中に固定的に使う値を使用する値をセットできるRowMapperです
 * <P>
 * ヘッダ・明細をリストに渡す場合にヘッダのRowをセットすることを想定しています。
 * </P>
 * 
 * @param <D> コピー先のRow
 * @param <S> コピー元のRow
 * @param <W> 固定的に使う値
 */
public abstract class FXUCC_RowMapperWith_FW<D extends MCRow, S extends MCRow, W extends Object>
		extends MCRowMapper<D, S> {
	abstract public void setWith(W fixedData);

	/**
	 * JOINされているList内のRowの内容をコピーします。
	 *
	 * <p>
	 * 引数 dest にJOINされているListには複数のRowが含まれる場合があります。<br>
	 * デフォルトでは引数 dest とJOINされているListの先頭行を
	 * {@link #valueCopy(MCRow, MCRow)}に渡し、値をコピーします。
	 * JOINされているRowが１行もない場合、{@link #valueCopy(MCRow, MCRow)}は
	 * 呼ばれません。
	 *
	 * <p>
	 * 引数 dest、引数 key のいずれかまたは両方が null の場合は何も行いません。
	 *
	 * @param <F> コピー元RowのListの型
	 * @param dest コピー先のRow
	 * @param fixedData 固定的に使う値
	 * @param key JOINキー
	 * @throws MCException [FCBBC0059]
	 *                       引数 key に 引数 dest 用ではないJOINキーが指定
	 *                       された場合
	 */
	public <F extends MCList<S>> void join(D dest, W fixedData, MCJoinKey<F> key) {
		setWith(fixedData);
		join(dest, key);
	}
}