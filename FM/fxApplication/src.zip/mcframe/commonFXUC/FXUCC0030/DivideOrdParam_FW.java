package mcframe.commonFXUC.FXUCC0030;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;

/**
 * 案分処理用の条件保持クラス。<p>
 * 
 * <p>・<b>機能</b><br>
 * {@link FXUCC_Divide_FW#divideOrd(DivideOrdParam)}の引数として使用される。<br>
 * FXUCC_Divide#_divideOrdによる計算結果は{@link #rslt(int, MCNumber)}の仕様に従い本クラスに保存される。</p>
 * 
 * 
 * <p>・<b>実装方法</b><br>
 * コンストラクタには各比率の計算結果を保持するためのMCList、割り当て元オーダ数、小数部有効桁数を必要とする。<br>
 * 
 * 本クラスを継承したクラスを作成し、各行に対応する比率を返す {@link #part(int)}を実装する必要がある。<br>
 * 最小数を指定する場合は{@link #min(int)}を実装する。<br>
 * 刻み数を指定する場合は{@link #step(int)}を実装する。<br>
 * 計算結果はコンストラクタで指定したMClistの各行に格納されるので、
 * 各行に対してカラム名={@link #$rslt()}のカラムから値を取得する。
 * ただし、FXUCC_Divide#_divideOrdの仕様により、格納されるのは正の整数の場合のみ。<br>
 * 該当しない場合にはMCRowにカラムが作成されない。<br>
 * </p>
 * 
 * @param <E>
 */
abstract public class DivideOrdParam_FW<E extends MCRow> {
	
	/**
	 * 結果格納用カラムのデフォルト名称"
	 */
	protected static final String DEFAULT_RSLT_COL = "_rslt";
	
	/**
	 * 結果格納用MCList
	 */
	private final MCList<E> _list;
	/**
	 * 割り当て前オーダ数
	 */
	private final MCNumber _src;
	/**
	 * 小数部有効桁数
	 */
	private final MCNumber _scale;
	/**
	 * 結果格納カラムの名称
	 */
	private final String _rsltcol;
	
	/**
	 * @param list 結果格納用MCList 必須
	 * @param src 割り当て前オーダ数 必須
	 * @param scale 小数部有効桁数 nullの場合は0
	 * @param rlstCol 結果格納カラム名 nullの場合は{@link #DEFAULT_RSLT_COL}
	 */
	public DivideOrdParam_FW(MCList<E> list, MCNumber src, MCNumber scale, String rsltCol) {
		super();
		_list = list;		
		_src = src;
		_scale = scale;
		_rsltcol = rsltCol != null ? rsltCol : DEFAULT_RSLT_COL;
	}

	/**
	 * 結果格納カラム名は{@link #DEFAULT_RSLT_COL}が使用される。<br>
	 * 
	 * 
	 * @param list 結果格納用MCList 必須
	 * @param src 割り当て前オーダ数 必須
	 * @param scale 小数部有効桁数 nullの場合は0
	 */
	public DivideOrdParam_FW(MCList<E> list, MCNumber src, MCNumber scale) {
		this(list, src, scale, null);
	}
	/**
	 * 
	 * 小数部有効桁数は0が使用される。
	 * 
	 * 
	 * @param list 結果格納用MCList 必須
	 * @param src 割り当て前オーダ数 必須
	 * @param rsltCol 結果格納カラム名 nullの場合は{@link #DEFAULT_RSLT_COL}
	 */
	public DivideOrdParam_FW(MCList<E> list, MCNumber src, String rsltCol) {
		this(list, src, null, rsltCol);
	}
	/**
	 * 
	 * 結果格納カラム名は{@link #DEFAULT_RSLT_COL}が使用される。<br>
	 * 小数部有効桁数は0が使用される。
	 * 
	 * 
	 * @param src 割り当て前オーダ数 必須
	 * @param src 案分前の数 必須
	 */
	public DivideOrdParam_FW(MCList<E> list, MCNumber src) {
		this(list, src, null, null);
	}
		
	/**
	 * デフォルトでは{@link #DEFAULT_RSLT_COL}を返す。<br>
	 * @return 結果格納用カラム名
	 */
	public String $rslt() {
		return _rsltcol;
	}

	/**
	 * 該当行の計算結果を格納する。<p>
	 * デフォルトでは、本クラスに指定したリストの
	 * MCRowの{@link #$rslt()}カラムに値を格納する。
	 * @param i index
	 * @param rslt 計算結果
	 */
	protected void rslt(int i, MCNumber rslt) {
		list().get(i).setNumberNE($rslt(), rslt);
	}
	
	/**
	 * @return 結果格納用MCList
	 */
	protected MCList<E> list() {
		return _list;
	}
	
	/**
	 * @return 刻み。デフォルトnull
	 */
	protected MCNumber step(int index){
		return null;
	}
	/**
	 * @return 最小。デフォルトnull
	 */
	protected MCNumber min(int index){
		return null;
	}
	
	
	/**
	 * @return 比率
	 */
	abstract protected MCNumber part(int index);
	
	/**
	 * @return 分割前の数
	 */
	protected MCNumber src() {
		return _src;
	}

	/**
	 * @return 小数部有効桁数
	 */
	protected MCNumber scale() {
		return _scale;
	}
	
	
	/**
	 * 比率の合計を返す。<p>
	 * 
	 * @return 比率の合計
	 */
	protected MCNumber total() {
		MCNumber sum = MCNumber.ZERO;
		for(int i=0 ; i < _list.size() ; i++){
			MCNumber n = part(i);
			if (n != null) {
				sum = sum.add(n);
			}
		}
		return sum;
	}
	
	
}
