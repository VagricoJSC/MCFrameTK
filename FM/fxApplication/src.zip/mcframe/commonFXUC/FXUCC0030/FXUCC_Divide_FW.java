package mcframe.commonFXUC.FXUCC0030;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.commonCore.container.MCIndexKey;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCRowComparator;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCLog;
import static mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil.*;

/**
 * "FXUCC_Divide"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class FXUCC_Divide_FW {
	/**
	 * @deprecated {@link #me()}を使用することを想定
	 */
	protected static FXUCC_Divide _me;

	protected static FXUCC_Divide me() {
		if (_me == null) {
			_me = new FXUCC_Divide();
		}
		return _me;
	}

	/**
	 * 割当総数を対象リストの１行目から要求数に応じて割当て行きます。
	 * <p>
	 * <b>実装例１：基本</b><br>
	 * 
	 * <pre>
	 * FXUCC_Divide.inSeq(list, val, CT_HOGE_R.$bal, CT_HOGE_R.$val);
	 * list.dbUpdate();
	 * </pre>
	 * 
	 * <p>
	 * <b>実装例２：割当結果情報を使用する例１</b><br>
	 * 
	 * <pre>
	 *                               protected void hoge(CT_HOGE_L&lt;CT_HOGE_R&gt; list , MCNumber val){
	 *                               	// 中略
	 *                               	IfDivideInSeqInfo info = FXUCC_Divide.inSeq(list, val,CT_HOGE_R.$bal , CT_HOGE_R.$val);
	 *                               	if( info.remainder().gt(0) ) {
	 *                               		CT_HOGE_R r = CT_HOGE_R.create();
	 *                               		r.key(&quot;...&quot;);
	 *                               		r.val(info.remainder());
	 *                               		list.add(r);
	 *                               	}
	 *                               	list.dbUpdate();
	 * </pre>
	 * 
	 * </p>
	 * <p>
	 * <b>実装例３：割当結果情報を使用する例１</b><br>
	 * 
	 * <pre>
	 * MCList&lt;CT_HOGE_R&gt; l = FXUCC_Divide.inSeq(list, val, CT_HOGE_R.$bal, CT_HOGE_R.$val)
	 * 		.allocated();
	 * </pre>
	 * 
	 * </p>
	 * <p>
	 * <b>実装上の注意事項</b><br>
	 * 戻り値を使用する場合は、IfDivideInSeqInfoの変数として受けることを想定している（ＥＩ構造の都合上）。
	 * </p>
	 * <p>
	 * <b>仕様</b>
	 * <ul>
	 * <li>対象のリストの１つめの行の要求数から順に割当る。割当可能残数が０になったところで割当が終了する。</li>
	 * <li>割当可能数が非負の場合、割当数＝min(要求数,割当可能残数)。（新）割当可能残数＝（旧）割当可能残数-割当数</li>
	 * <li>割当可能数が負の場合、割当数＝max(要求数,割当可能残数)。（新）割当可能残数＝（旧）割当可能残数-割当数</li>
	 * <li>割当処理が行われた行は、処理結果情報の割当済みリストにも格納される。 （Rowのインスタンスは、trgtに格納されているものと同一）</li>
	 * <li>割当が行われなかった行の割当数は０で初期化される。</li>
	 * <li>要求数が０の場合、割当判断時に割当可能数が０で無い場合は０を割当、割当済みリストに格納される。</li>
	 * <li>要求数がnullの場合は、割当数もnull。割当済みリストにも格納されない。</li>
	 * <li>最終的な割当可能残数は処理結果情報に保存される。</li>
	 * <li>対象のリストに「割当数を格納する列名」が存在しない場合は一時カラムに結果を追加する</li>
	 * </ul>
	 * </p>
	 * 
	 * @throws MCAppException CUL0001W 要求数の合計と割当可能総数の符号が異なる場合
	 * @param trgt 対象(target)
	 * @param ttl 割当可能総数(total)
	 * @param rqstCol 要求数が格納されている列名（数値用のカラムであること）
	 * @param allocCol 割当数を格納する列名（数値用のカラムであること）
	 * @return 処理結果情報
	 */
	public static <E extends MCRow> IfDivideInSeqInfo<E> inSeq(MCList<E> trgt,
			MCNumber ttl, String rqstCol, String allocCol) {

		// divide in sequentially

		FXUCC_Divide.DivideInSeq<E> d = me().new DivideInSeq<E>();
		d.set(trgt, ttl, rqstCol, allocCol);
		return d.divide();
	}

	protected <X extends MCRow> DivideInSeqInfo<X> createDivideInSeqInfo(X proto) {
		return new DivideInSeqInfo<X>();
	}

	public class DivideInSeq<E extends MCRow> {
		protected MCList<E> _trgt;

		// 割当総数
		protected MCNumber _ttl;

		// 要求数のカラム名
		protected String _rqstCol;

		// 割当数のカラム名
		protected String _allocCol;

		public void set(MCList<E> targetList, MCNumber totalAmount,
				String requestAmountColumnName, String outPutColumnName) {
			_trgt = targetList;
			_ttl = nvl(totalAmount, MCNumber.ZERO);
			_rqstCol = requestAmountColumnName;
			_allocCol = outPutColumnName;
		}

		public DivideInSeqInfo<E> divide() {
			MCList<E> trgt = _trgt;
			DivideInSeqInfo<E> ans = createDivideInSeqInfo(_trgt.createRow());

			MCNumber rem = _ttl; // remainder 残数
			MCList<E> alloc = MCList.create(trgt.createRow());

			// チェック
			MCNumber chkRqst = trgt.sum(_rqstCol);
			if (chkRqst == null) {
				// trgt.size() == 0 の時。全ての_rqstColがnull の時は計算処理をせずに終了
				ans.allocated(MCList.create(trgt.createRow()));
				ans.remainder(rem);
				trgt.setNumber(_allocCol, null);
				if (isSame(MCNumber.ZERO, rem)) {
					MCLog.write(FXUCC0015, rem);
				}
				return ans;
			}
			if (rem == null || rem.multiply(chkRqst).isNegative()) {
				// 割当の残高合計額と対象額の符号が違う場合はエラー
				throw new MCAppException(FXUCC0013, chkRqst, _ttl);
			}

			// 割当処理
			for (E r : trgt) {
				MCNumber rqst = r.getNumber(_rqstCol);
				if (rqst == null) {
					r.setNumberNE(_allocCol, null);
					continue;
				}
				if (!rem.isZero()) {
					if (isAllAllocatable(rem, rqst)) {
						// 割当ても残がある場合
						r.setNumberNE(_allocCol, rqst);
						rem = rem.subtract(rqst);
					}
					else {
						// 残を使い切る場合
						r.setNumberNE(_allocCol, rem);
						rem = MCNumber.ZERO;
					}
					alloc.add(r);
				}
				else {
					// 残を使い切った場合
					r.setNumberNE(_allocCol, MCNumber.ZERO);
				}
			}
			ans.allocated(alloc);
			ans.remainder(rem);
			if (isSame(MCNumber.ZERO, rem)) {
				MCLog.write(FXUCC0015, rem);
			}
			return ans;
		}

		/**
		 * 残数（val）の中から要求数（rqst）を全て満たすことができるかを判定します。 残数の符号により判定条件が異なります。
		 * <p>
		 * valが非負の場合（＝正の数を割当る場合）：val >= rqst の時true
		 * </p>
		 * <p>
		 * valが負の数の場合（＝負の数を割当る場合）：val <= rqst の時true
		 * </p>
		 * 
		 * @param val 残数
		 * @param rqst 要求数
		 * @return 本メソッドの本文参照
		 */
		protected boolean isAllAllocatable(MCNumber val, MCNumber rqst) {
			if (val.isNegative()) {
				return val.lte(rqst);
			}
			return val.gte(rqst);
		}
	}

	public class DivideInSeqInfo<E extends MCRow> implements IfDivideInSeqInfo<E> {
		protected MCList<E> _allocated;

		public MCList<E> allocated() {
			return _allocated;
		}

		protected void allocated(MCList<E> list) {
			_allocated = list;
		}

		protected MCNumber _rem;

		public MCNumber remainder() {
			return _rem;
		}

		protected void remainder(MCNumber num) {
			_rem = num;
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("Remainder : " + _rem + "\n");
			sb.append("Allocated : " + "\n");
			sb.append(allocated());
			return sb.toString();
		}

	}

	// //////////////////////////////////////////
	// //////////////////////////////////////////
	// //////////////////////////////////////////
	/**
	 * 割当可能総数を対象リストの割当比率に応じて割当て行きます。
	 * <p>
	 * <b>実装例</b><br>
	 * 
	 * <pre>
	 * FXUCC_Divide.prop(list, val, scale, CT_HOGE_R.$ratio, CT_HOGE_R.$val);
	 * list.dbUpdate();
	 * </pre>
	 * 
	 * <p>
	 * <b>実装上の注意事項</b><br>
	 * 戻り値を使用する場合は、IfDividePropnfoの変数として受けることを想定している（ＥＩ構造の都合上）。
	 * </p>
	 * <p>
	 * <b>仕様</b>
	 * <ul>
	 * <li>対象のリストの割当比率に応じて割当総数を振り分ける。端数は、スケール指定の影響で切り捨てられた値が大きい順に割当数のスケールの最小値（割当単位数）を加算する。</li>
	 * <li>割当可能数が非負の場合、割当総数 ＜ 割当数の合計＋割当単位数 かつ 割当総数 ＞＝ 割当数の合計</li>
	 * <li>割当可能数が負の場合、割当総数 ＞ 割当数の合計＋割当単位数 かつ 割当総数 ＜＝ 割当数の合計</li>
	 * <li>割当比率数がnullの場合は、割当数もnull。</li>
	 * <li>対象のリストに「割当数を格納する列名」が存在しない場合は一時カラムに結果を追加する</li>
	 * <li>最終的な割当可能残数は処理結果情報に保存される。(*1)</li>
	 * <li>最終的な割当可能残数が MCNumber.ZERO ではないのは以下のパタン
	 * <ul>
	 * <li>割当可能総数(total)の小数点桁数が割当数のスケールを超えていた場合</li>
	 * </ul>
	 * </li>
	 * </ul>
	 * </p>
	 * <P>
	 * *1 の部分が {@link FXUCC_Divide#prop(MCList, MCNumber, int, String, String)}と異なる点。
	 * </P>
	 * 
	 * @throws MCAppException CUL0002W 割当比率の合計が正の数ではない場合
	 * @param trgt 対象(target)
	 * @param ttl 割当可能総数(total)
	 * @param scale 割当数のスケール
	 * @param propCol 割当比率が格納されている列名（数値用のカラムであること）
	 * @param allocCol 割当数を格納する列名（数値用のカラムであること）
	 * @return 処理結果情報
	 */
	public static <E extends MCRow> IfDivideProp propNE(MCList<E> trgt, MCNumber ttl,
			int scale, String propCol, String allocCol) {

		FXUCC_Divide.DivideProp<E> d = me().new DivideProp<E>();
		d.set(trgt, ttl, scale, propCol, allocCol);
		return d.divide();
	}

	/**
	 * 割当可能総数を対象リストの割当比率に応じて割当て行きます。
	 * <p>
	 * <b>実装例</b><br>
	 * 
	 * <pre>
	 * FXUCC_Divide.prop(list, val, scale, CT_HOGE_R.$ratio, CT_HOGE_R.$val);
	 * list.dbUpdate();
	 * </pre>
	 * 
	 * <p>
	 * <b>実装上の注意事項</b><br>
	 * 戻り値を使用する場合は、IfDividePropnfoの変数として受けることを想定している（ＥＩ構造の都合上）。
	 * </p>
	 * <p>
	 * <b>仕様</b>
	 * <ul>
	 * <li>対象のリストの割当比率に応じて割当総数を振り分ける。端数は、スケール指定の影響で切り捨てられた値が大きい順に割当数のスケールの最小値（割当単位数）を加算する。</li>
	 * <li>割当可能数が非負の場合、割当総数 ＜ 割当数の合計＋割当単位数 かつ 割当総数 ＞＝ 割当数の合計</li>
	 * <li>割当可能数が負の場合、割当総数 ＞ 割当数の合計＋割当単位数 かつ 割当総数 ＜＝ 割当数の合計</li>
	 * <li>割当比率数がnullの場合は、割当数もnull。</li>
	 * <li>対象のリストに「割当数を格納する列名」が存在しない場合は一時カラムに結果を追加する</li>
	 * <li>全ての割当を行っても、尚、割当可能残数がMCNumber.ZERO ではない場合は例外が発生する(*1)</li>
	 * <li>最終的な割当残数が MCNumber.ZERO ではないのは以下のパタン
	 * <ul>
	 * <li>割当可能総数(total)の小数点桁数が割当数のスケールを超えていた場合</li>
	 * </ul>
	 * </li>
	 * </ul>
	 * </p>
	 * <P>
	 * *1 の部分が {@link FXUCC_Divide#propNE(MCList, MCNumber, int, String, String)}と異なる点。
	 * </P>
	 * @throws MCAppException CUL0002W 割当比率の合計が正の数ではない場合
	 * @throws MCAppException CUL0057W 割当残数がある場合
	 * @param trgt 対象(target)
	 * @param ttl 割当可能総数(total)
	 * @param scale 割当数のスケール
	 * @param propCol 割当比率が格納されている列名（数値用のカラムであること）
	 * @param allocCol 割当数を格納する列名（数値用のカラムであること）
	 * @return 処理結果情報
	 */
	public static <E extends MCRow> IfDivideProp prop(MCList<E> trgt, MCNumber ttl,
			int scale, String propCol, String allocCol) {

		IfDivideProp ret = propNE(trgt, ttl, scale, propCol, allocCol);
		if (ret == null) {
			return ret;
		}
		MCNumber rem = ret.remainder();

		if (rem != null && !rem.isZero()) {
			throw new MCAppException(FXUCC0018, rem);
		}

		return ret;
	}

	/**
	 * 割当可能総数を割当比率に応じて割当てを行います。
	 * <p>
	 * <b>実装例</b><br>
	 * 
	 * <pre>
	 * MCNumber[] rslt = FXUCC_Divide.propNE(val, scale, row.ratio1(), row.ratio2(), row.ratio3())
	 * 		.allocArray();
	 * row.amt1(rslt[0]);
	 * row.amt2(rslt[1]);
	 * row.amt3(rslt[2]);
	 * </pre>
	 * 
	 * <p>
	 * <b>実装上の注意事項</b><br>
	 * 戻り値を使用する場合は、IfDividePropnfoの変数として受けることを想定している（ＥＩ構造の都合上）。
	 * </p>
	 * <p>
	 * <b>仕様</b>
	 * <ul>
	 * <li>割当比率に応じて割当総数を振り分ける。端数は、スケール指定の影響で切り捨てられた値の絶対値が大きい順に
	 * 割当割合が割当割合と同じ符号の場合は割当数のスケールの最小値（割当単位数）を加算し、異なる場合は減算する。</li>
	 * <li>割当可能数が非負の場合、割当総数 ＜ 割当数の合計＋割当単位数 かつ 割当総数 ＞＝ 割当数の合計</li>
	 * <li>割当可能数が負の場合、割当総数 ＞ 割当数の合計＋割当単位数 かつ 割当総数 ＜＝ 割当数の合計</li>
	 * <li>割当比率数がnullの場合は、割当数もnull。</li>
	 * <li>対象のリストに「割当数を格納する列名」が存在しない場合は一時カラムに結果を追加する</li>
	 * <li>最終的な割当可能残数は処理結果情報に保存される。(*1)</li>
	 * <li>最終的な割当可能残数が MCNumber.ZERO ではないのは以下のパターン
	 * <ul>
	 * <li>割当可能総数(total)の小数点桁数が割当数のスケールを超えていた場合</li>
	 * </ul>
	 * </li>
	 * </ul>
	 * </p>
	 * 
	 * @throws MCAppException CUL0002W 割当比率の合計が正の数ではない場合
	 * @param ttl 割当可能総数(total)
	 * @param scale 割当数のスケール
	 * @param ratios 割当比率
	 * @return 処理結果情報
	 */
	public static IfDivideProp propNE(MCNumber ttl, int scale, MCNumber... ratios) {
		String propCol = "p";
		String allocCol = "a";
		MCList<MCRow> list = MCList.create(MCRow.class);
		list.addNumberColumn(propCol);
		list.addNumberColumn(allocCol);
		for (MCNumber ratio : ratios) {
			MCRow row = list.createRow();
			row.setNumber(propCol, ratio);
			list.add(row);
		}
		FXUCC_Divide.DivideProp<MCRow> d = me().new DivideProp<MCRow>();
		d.set(list, ttl, scale, propCol, allocCol);
		return d.divide();

	}

	/**
	 * 割当可能総数を割当比率に応じて割当てを行います。
	 * <p>
	 * <b>実装例</b><br>
	 *
	 * <pre>
	 * MCNumber[] rslt = FXUCC_Divide.prop(val, scale, row.ratio1(), row.ratio2(), row.ratio3())
	 * 		.allocArray();
	 * row.amt1(rslt[0]);
	 * row.amt2(rslt[1]);
	 * row.amt3(rslt[2]);
	 * </pre>
	 *
	 * <p>
	 * <b>実装上の注意事項</b><br>
	 * 戻り値を使用する場合は、IfDividePropnfoの変数として受けることを想定している（ＥＩ構造の都合上）。
	 * </p>
	 * <p>
	 * <b>仕様</b>
	 * <ul>
	 * <li>割当比率に応じて割当総数を振り分ける。端数は、スケール指定の影響で切り捨てられた値の絶対値が大きい順に
	 * 割当割合が割当割合と同じ符号の場合は割当数のスケールの最小値（割当単位数）を加算し、異なる場合は減算する。</li>
	 * <li>割当可能数が非負の場合、割当総数 ＜ 割当数の合計＋割当単位数 かつ 割当総数 ＞＝ 割当数の合計</li>
	 * <li>割当可能数が負の場合、割当総数 ＞ 割当数の合計＋割当単位数 かつ 割当総数 ＜＝ 割当数の合計</li>
	 * <li>割当比率数がnullの場合は、割当数もnull。</li>
	 * <li>対象のリストに「割当数を格納する列名」が存在しない場合は一時カラムに結果を追加する</li>
	 * <li>全ての割当を行っても、尚、割当可能残数がMCNumber.ZERO ではない場合は例外が発生する(*1)</li>
	 * <li>最終的な割当残数が MCNumber.ZERO ではないのは以下のパタン
	 * <ul>
	 * <li>割当可能総数(total)の小数点桁数が割当数のスケールを超えていた場合</li>
	 * </ul>
	 * </li>
	 * </ul>
	 * </p>
	 * <P>
	 * *1 の部分が {@link FXUCC_Divide#propNE(MCNumber, int, MCNumber...)}と異なる点。
	 * </P>
	 *
	 * @throws MCAppException CUL0002W 割当比率の合計が正の数ではない場合
	 * @throws MCAppException CUL0057W 割当残数がある場合
	 * @param ttl 割当可能総数(total)
	 * @param scale 割当数のスケール
	 * @param ratios 割当比率
	 * @return 処理結果情報
	 */
	public static IfDivideProp prop(MCNumber ttl, int scale, MCNumber... ratios) {

		IfDivideProp ret = propNE(ttl, scale, ratios);
		if (ret == null) {
			return ret;
		}
		MCNumber rem = ret.remainder();

		if (rem != null && !rem.isZero()) {
			throw new MCAppException(FXUCC0018, rem);
		}

		return ret;
	}

	protected DividePropInfo createDividePropInfo() {
		return new DividePropInfo();
	}

	public class DivideProp<E extends MCRow> {

		MCList<E> _trgt; // 対象のリスト

		String _propCol; // 比率のカラム名

		String _allocCol; // 割当数のカラム名

		MCNumber _ttl; // 割当可能総数

		int _scale; // 割当数のスケール

		MCNumber _uni; // 割当単位数（＝割当可能な最小の数。符号は割当総数と同じ）

		public void set(MCList<E> trgt, MCNumber ttl, int scale, String propCol,
				String allocCol) {
			_trgt = trgt;
			_scale = scale;
			_ttl = nvl(ttl, MCNumber.ZERO);
			_propCol = propCol;
			_allocCol = allocCol;
			if (_ttl.isNegative()) {
				_uni = MCNumber.valueOf(0.1).pow(_scale).negate();
			}
			else {
				_uni = MCNumber.valueOf(0.1).pow(_scale);
			}
		}

		public FXUCC_Divide.DividePropInfo divide() {

			if (_trgt == null || _trgt.size() <= 0) {
				throw new MCAppException(FXUCC0016);
			}
			if (_trgt.count(_propCol) <= 0) {
				throw new MCAppException(FXUCC0017, _propCol);
			}

			/*
			 * 切り捨てた値の絶対値を保存するカラム名
			 */
			String fractionCol = "fractionCol";
			/*
			 * 対象のデータのIndex * -1 の値を保存するカラム名<br>
			 * ソートの関係で符号反転する必要がある。
			 */
			String trgtRowNumCol = "trgtRowNumCol";
			MCList<MCRow> frctnLs = MCList.create(MCRow.class);
			frctnLs.addNumberColumn(fractionCol);
			frctnLs.addNumberColumn(trgtRowNumCol);
			/*
			 * 全体の切捨て端数をどの比率に付加するかを判定するために使用する値の桁数。
			 */
			int addScaleForFrctn = 3;

			MCNumber ttlProp = _trgt.sum(_propCol); // 比率の合計
			MCNumber ttlAlloc = MCNumber.ZERO; // 割当済の数量

			FXUCC_Divide.DividePropInfo ans = createDividePropInfo();

			// 初期条件チェック
			if (ttlProp.isZero()) {
				throw new MCAppException(FXUCC0014, ttlProp);
			}

			for (int idx = 0; idx < _trgt.size(); idx++) {
				E row = _trgt.get(idx);
				MCNumber prop = row.getNumber(_propCol);
				if (prop == null) {
					continue;
				}

				MCNumber retVal = _ttl.multiply(prop).divide(ttlProp,
						_scale + addScaleForFrctn, MCNumber.MODE_DOWN);
				// 指定されたスケールで一旦保存する
				row.setNumberNE(_allocCol, retVal.setScale(_scale, MCNumber.MODE_DOWN));
				// 切り捨てた端数を記録しておく
				MCRow fr = frctnLs.createRow();
				fr.setNumber(fractionCol, retVal.subtract(row.getNumber(_allocCol)).abs());
				fr.setNumber(trgtRowNumCol, idx * -1);
				frctnLs.add(fr);
				ttlAlloc = ttlAlloc.add(row.getNumber(_allocCol));
			}
			if (!isEnd(_ttl, ttlAlloc)) {
				// 比率が同一の場合は元のリストのidxが若い方に割り当たるようしている
				MCIndexKey idx = frctnLs.createIndex(new MCRowComparator.DESC<MCRow>(
						fractionCol, trgtRowNumCol));
				for (Iterator<MCRow> i = frctnLs.iterator(idx); i.hasNext();) {
					MCRow frctnRow = i.next();
					int rowNum = frctnRow.getNumber(trgtRowNumCol).intValue() * -1;
					E trgtRow = _trgt.get(rowNum);
					if (ttlProp.multiply(trgtRow.getNumber(_propCol)).isPositive()) {
						// 割当割合合計と割当割合の符号が同じ場合は、単位端数を加える
						trgtRow.setNumber(_allocCol,
								trgtRow.getNumber(_allocCol).add(_uni));
						ttlAlloc = ttlAlloc.add(_uni);
					}
					else if (ttlProp.multiply(trgtRow.getNumber(_propCol)).isNegative()) {
						// 割当割合合計と割当割合の符号が同じ場合は、単位端数を引く
						trgtRow.setNumber(_allocCol, trgtRow.getNumber(_allocCol)
								.subtract(_uni));
						ttlAlloc = ttlAlloc.subtract(_uni);
					}
					else {
						// ttlProp は０ではないので、_propCol が０の場合
						// は、何もしない
					}
					if (isEnd(_ttl, ttlAlloc)) {
						break;
					}
				}
			}
			ans.remainder(_ttl.subtract(ttlAlloc));

			// _trgt.getNumber(_allocCol) と実装したいが上手くいかないので
			// 自分で実装する（ここから）
			// メモ：_trgtにおいて、_allocColがリストのprotoRowに
			// ないと上記メソッドは使えないため。
			List<MCNumber> allocList = new ArrayList<MCNumber>();
			for (MCRow row : _trgt) {
				allocList.add(row.getNumberNE(_allocCol));
			}
			// 自分で実装する（ここまで）
			ans.setAllocArray(allocList);
			if (isSame(MCNumber.ZERO, ans.remainder())) {
				MCLog.write(FXUCC0015, ans.remainder());
			}
			return ans;
		}

		/**
		 * 割当終了判定
		 * <p>
		 * 割当可能総数が非負の場合：割当済数 ＜＝ 割当総数 ＜ 割当済数＋割当単位数<br>
		 * 割当可能総数が負の場合：割当済数 ＞＝ 割当総数 ＞ 割当済数＋割当単位数
		 * </p>
		 * 
		 * @param ttl 割当可能総数
		 * @param ttlAlloc 割当済総数
		 * @return
		 */
		protected boolean isEnd(MCNumber ttl, MCNumber ttlAlloc) {
			if (ttl.isNegative()) {
				return ttlAlloc.gte(ttl) && ttl.gt(ttlAlloc.add(_uni));
			}
			else {
				return ttlAlloc.lte(ttl) && ttl.lt(ttlAlloc.add(_uni));
			}
		}
	}

	public class DividePropInfo implements IfDivideProp {
		private MCNumber _rem;

		public MCNumber remainder() {
			if (_rem == null) {
				_rem = MCNumber.ZERO;
			}
			return _rem;
		}

		protected void remainder(MCNumber num) {
			_rem = num;
		}

		private MCNumber[] _allocArray;

		/**
		 * 割当数量の配列（順番及びサイズは割当対象と同じ）
		 * 
		 * @return
		 */
		public MCNumber[] allocArray() {
			if (_allocArray == null) {
				_allocArray = new MCNumber[] {};
			}
			return _allocArray;
		}

		protected void setAllocArray(List<MCNumber> arr) {
			_allocArray = arr.toArray(new MCNumber[arr.size()]);
		}

	}

	/**
	 * 案分処理を行う。<p>
	 * 
	 * DivideOrdParamの保持するリストの格納順に、各行の比率分の数量を計算し、
	 * 結果をDivideOrdParamに保存する。<p>
	 * 
	 * 
	 * 計算処理は{@link #_calcPart(MCNumber, MCNumber, MCNumber, MCNumber, MCNumber, MCNumber) _calcPart}の仕様に従う。<p>
	 * _calcPartの引数にはDivideOrdParamの値を使用する。<br>
	 * 
	 * 
	 * 比率の合計が0の場合は何もしない。また、
	 * DivideOrdParamに格納される各比率の結果は0またはnull以外の数値のみ格納され、
	 * それ以外は格納されない。<p>
	 * 
	 * @param rlist 案分対象データ
	 */
	public static void divideOrd(DivideOrdParam<?> rlist) {
		FXUCC_Divide d = me();
		d._divideOrd(rlist);
	}

	protected void _divideOrd(DivideOrdParam<?> rlist) {

		if (rlist.list() == null || rlist.list().size() <= 0) {
			throw new MCAppException(FXUCC0016);
		}

		MCNumber remainRqstQty = rlist.src();
		MCNumber remainTotalRatio = rlist.total();

		if (MCNumber.ZERO.gte(remainTotalRatio)) {
			return;
		}

		MCNumber scale = rlist.scale();
		for (int i = 0; i < rlist.list().size(); i++) {

			if (MCNumber.ZERO.gte(remainRqstQty)) {
				break;
			}
			MCNumber ratio = rlist.part(i);
			MCNumber min = rlist.min(i);
			MCNumber step = rlist.step(i);

			MCNumber newQty = _calcPart(remainRqstQty, ratio, remainTotalRatio, scale,
					min, step);

			if (MCNumber.ZERO.eq(newQty)) {
				continue;
			}

			rlist.rslt(i, newQty);

			remainRqstQty = remainRqstQty.subtract(newQty);
			remainTotalRatio = remainTotalRatio.subtract(ratio);
		}
	}

	/**
	 * 指定した比率分を計算して返す。<p>
	 * 
	 * 
	 * 始めにtarget*numerator/denominatorを計算する。<br>
	 * 結果は小数部有効桁の端数を切り上げる。<br>
	 * 計算後以下の分岐を行う。<br>
	 * <li>結果が最小数以下の場合は最小数を返す。
	 * <li>結果が最小数より多い場合は、差分が刻み数で割り切れるようになる最低限の数を加算した数を返す。
	 * <br><br>
	 * ただし、各処理は、min、stepがnullではない場合にのみ処理される。<br>
	 * 
	 * target、numerator、denominatorが0またはnullの場合は0を返す。<br>
	 * @param target 元の数
	 * @param numerator 分子
	 * @param denominator 分母
	 * @param scale 小数部有効桁。未指定の場合は0
	 * @param min 最小数。0または未指定の場合は最小数を考慮しない
	 * @param step 最小数より多い部分の刻み単位数。0または未指定の場合は刻みを考慮しない
	 * @return 計算結果
	 */
	protected MCNumber _calcPart(MCNumber target, MCNumber numerator,
			MCNumber denominator, MCNumber scale, MCNumber min, MCNumber step) {

		for (MCNumber req : new MCNumber[] {
				target, numerator, denominator
		}) {
			if (isNull(req) || MCNumber.ZERO.eq(req)) {
				return MCNumber.ZERO;
			}
		}

		scale = isNull(scale) ? MCNumber.ZERO : scale;
		min = isNull(min) ? MCNumber.ZERO : min;
		step = isNull(step) ? MCNumber.ZERO : step;

		MCNumber newQty = target.multiply(numerator).divide(denominator,
				scale.intValue(), MCNumber.MODE_UP);

		//最小より少ない場合は最小に合わせる
		if (min.gt(MCNumber.ZERO)) {
			if (min.gt(newQty)) {
				return min;
			}
		}
		//最小より多い場合は最小より多い数量を刻みの倍数に合わせる
		if (step.gt(MCNumber.ZERO)) {
			MCNumber overQty = newQty.subtract(min);
			MCNumber rm = overQty.remainder(step);
			if (MCNumber.ZERO.lt(rm)) {
				return newQty.subtract(rm).add(step);
			}
		}

		return newQty;
	}
}