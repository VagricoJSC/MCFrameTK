package mcframe.commonFXUC.FXUCC0030;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;

public interface IfDivideInSeqInfo<E extends MCRow> {
	/**
	 * @return 割当残数
	 */
	public MCNumber remainder();
	
	/**
	 * @return 割当を行ったRowが格納されているリスト
	 */
	public MCList<E> allocated();
}
