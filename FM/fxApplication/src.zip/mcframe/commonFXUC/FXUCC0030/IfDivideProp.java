package mcframe.commonFXUC.FXUCC0030;

import mcframe.commonCore.lang.MCNumber;

public interface IfDivideProp {
	/**
	 * @return 割当残数
	 */
	public MCNumber remainder();
	/**
	 * @return 割当結果の配列
	 */
	public MCNumber[] allocArray();
}
