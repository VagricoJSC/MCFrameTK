package mcframe.commonFXUC.FXUCC0030;

import mcframe.commonCore.annotation.EI;

/**
 * "FXUCC_Divide"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FXUCC_Divide extends FXUCC_Divide_FW {

}