package mcframe.commonFXUC.FXUCC0030;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;

abstract public class DivideOrdParam<E extends MCRow> extends DivideOrdParam_FW<E>{

	public DivideOrdParam(MCList<E> list, MCNumber src, MCNumber scale, String rsltCol) {
		super(list, src, scale, rsltCol);
	}

	public DivideOrdParam(MCList<E> list, MCNumber src, MCNumber scale) {
		super(list, src, scale);
	}

	public DivideOrdParam(MCList<E> list, MCNumber src, String rsltCol) {
		super(list, src, rsltCol);
	}

	public DivideOrdParam(MCList<E> list, MCNumber src) {
		super(list, src);
	}
		
}
