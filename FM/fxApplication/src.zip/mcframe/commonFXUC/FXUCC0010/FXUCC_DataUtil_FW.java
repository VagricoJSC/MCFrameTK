package mcframe.commonFXUC.FXUCC0010;

import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;

import java.util.Locale;
import java.util.regex.Pattern;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.resource.MCConst;
import mcframe.commonCore.resource.MCFormatConst;
import mcframe.commonCore.resource.MCLocaleConst;

public class FXUCC_DataUtil_FW {
	// 共通オリジナルの実装（ここから）
	protected static FXUCC_DataUtil me() {
		return new FXUCC_DataUtil();
	}

	// 共通オリジナルの実装（ここまで）
	// 以下 サーバーとクライアントと同じ
	// サーバ：コピペ -> me() を object(CLAZZ) に置換
	// クライアント：そのまま
	/**
	 * 値がNull状態か判定します。
	 * <P>
	 * 以下の場合はNull状態とみなしtrueを返します。
	 * <li>値がnullの場合</li>
	 * <li>値が空文字列の場合</li>
	 * </P>
	 * 
	 * @param String value 評価対象の値
	 * @return boolean Null状態の場合true それ以外は false
	 */
	protected boolean _isNull(Comparable<?> val) {
		if (val instanceof String) {
			return _isNull((String) val);
		}
		return val == null;
	}

	/**
	 * {@link #isNull(String)}
	 */
	protected boolean _isNull(String val) {
		return (val == null || val.equals(""));
	}

	/**
	* 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	*
	* @param val 評価対象の値
	* @param defVal nullの時に使用される値
	* @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	*/
	protected <E extends Comparable<?>> E _nvl(E val, E defVal) {
		return _isNull(val) ? defVal : val;
	}

	/**
	* val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	*
	* @param val1 評価対象の値
	* @param val2 評価対象の値
	* @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	*/
	protected <E extends Comparable<?>> boolean _isSame(E val1, E val2) {
		if (val1 instanceof Number && val2 instanceof Number) {
			return _isSame((Number) val1, (Number) val2);
		}
		if (_isNull(val1)) {
			return _isNull((E) val2);
		}
		return val1.equals(val2);
	}

	/**
	* val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	*
	* @param val1 評価対象の値
	* @param val2 評価対象の値
	* @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	*/
	protected boolean _isSame(Number val1, Number val2) {
		MCNumber num1 = toMCNumber(val1);
		MCNumber num2 = toMCNumber(val2);
		if (_isNull(num1)) {
			return _isNull(num2);
		}
		return num1.eq(num2);
	}

	/**
	 * ComprableをMCNumberに変換する
	 * 
	 * @param c
	 * @return
	 */
	protected MCNumber toMCNumber(Comparable<?> c) {
		MCNumber ans;
		if (c instanceof MCNumber) {
			ans = (MCNumber) c;
		}
		else if (c instanceof Double) {
			ans = MCNumber.valueOf((Double) c);
		}
		else if (c instanceof Float) {
			ans = MCNumber.valueOf((Float) c);
		}
		else if (c instanceof Integer) {
			ans = MCNumber.valueOf((Integer) c);
		}
		else if (c instanceof Long) {
			ans = MCNumber.valueOf((Long) c);
		}
		else if (c == null) {
			ans = null;
		}
		else {
			// 予期せぬ数値型がセットされた
			throw new MCAppException(FXUCC0001, c.getClass().getName());
		}
		return ans;
	}

	/**
	 * NumberをMCNumberに変換する
	 * 
	 * @param c
	 * @return
	 */
	protected MCNumber toMCNumber(Number c) {
		MCNumber ans;
		if (c instanceof MCNumber) {
			ans = (MCNumber) c;
		}
		else if (c instanceof Double) {
			ans = MCNumber.valueOf((Double) c);
		}
		else if (c instanceof Float) {
			ans = MCNumber.valueOf((Float) c);
		}
		else if (c instanceof Integer) {
			ans = MCNumber.valueOf((Integer) c);
		}
		else if (c instanceof Long) {
			ans = MCNumber.valueOf((Long) c);
		}
		else if (c == null) {
			ans = null;
		}
		else {
			// 予期せぬ数値型がセットされた
			throw new MCAppException(FXUCC0001, c.getClass().getName());
		}
		return ans;
	}

	// ////////////////////////////////////
	// ////////////////////////////////////
	// ////////////////////////////////////
	// ////////////////////////////////////
	// 共通 String（ここから）
	/**
	* 値がNull状態か判定します。
	* <P>
	* 以下の場合はNull状態とみなしtrueを返します。
	* <li>値がnullの場合</li>
	* <li>値が空文字列の場合</li>
	* </P>
	*
	* @param String value 評価対象の値
	* @return boolean Null状態の場合true それ以外は false
	*/

	public static boolean isNull(String value) {
		return me()._isNull(value);
	}

	/**
	* 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	*
	* @param val 評価対象の値
	* @param defVal nullの時に使用される値
	* @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	*/
	public static String nvl(String val, String defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	* val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	*
	* @param val1 評価対象の値
	* @param val2 評価対象の値
	* @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	* @see mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil.StringUtilSub#isSame(java.lang.String,
	* java.lang.String)
	*/
	public static boolean isSame(String val1, String val2) {
		return me()._isSame(val1, val2);
	}

	// 共通 String（ここまで）
	// String オリジナル（ここから）
	
	/**
	 * 評価対象の文字列がGTINコードとして妥当かどうかを判定します。
	 * <p>
	 * デフォルト実装：
	 * <li>使用可能文字: 算用数字のみ</li>
	 * </p>
	 * <p>
	 * 引数がnullの場合はfalse。
	 * </p>
	 * <p>
	 * 上記以外の仕様にする場合はカスタマイズが必要です。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列がGTINコードとして妥当な場合true それ以外 false
	 */
	public static boolean isGTINCd(String str) {
		return me()._isGTINCd(str);
	}

	/**
	 * {@link #isGTINCd(String)}
	 */
	protected boolean _isGTINCd(String str) {
		if (_isNull(str)) return false;
		for (char c : str.toCharArray()) {
			if (_isDigitsStr(String.valueOf(c))) {
				// 何もしない
			}
			else {
				return false;
			}
		}
		return true;
	}

	/**
	 * 評価対象の文字列がITFコードとして妥当かどうかを判定します。
	 * <p>
	 * デフォルト実装：
	 * <li>使用可能文字: 算用数字のみ</li>
	 * </p>
	 * <p>
	 * 引数がnullの場合はfalse。
	 * </p>
	 * <p>
	 * 上記以外の仕様にする場合はカスタマイズが必要です。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列がITFコードとして妥当な場合true それ以外 false
	 */
	public static boolean isITFCd(String str) {
		return me()._isITFCd(str);
	}

	/**
	 * {@link #isITFCd(String)}
	 */
	protected boolean _isITFCd(String str) {
		if (_isNull(str)) return false;
		for (char c : str.toCharArray()) {
			if (_isDigitsStr(String.valueOf(c))) {
				// 何もしない
			}
			else {
				return false;
			}
		}
		return true;
	}

	/**
	 * 評価対象の文字列がJANコードとして妥当かどうかを判定します。
	 * <p>
	 * デフォルト実装：
	 * <li>使用可能文字: 算用数字のみ</li>
	 * </p>
	 * <p>
	 * 引数がnullの場合はfalse。
	 * </p>
	 * <p>
	 * 上記以外の仕様にする場合はカスタマイズが必要です。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列がJANコードとして妥当な場合true それ以外 false
	 */
	public static boolean isJANCd(String str) {
		return me()._isJANCd(str);
	}

	/**
	 * {@link #isJANCd(String)}
	 */
	protected boolean _isJANCd(String str) {
		if (_isNull(str)) return false;
		for (char c : str.toCharArray()) {
			if (_isDigitsStr(String.valueOf(c))) {
				// 何もしない
			}
			else {
				return false;
			}

		}
		return true;
	}

	/**
	 * 評価対象の文字列がHSコードとして妥当かどうかを判定します。
	 * <p>
	 * デフォルト実装：
	 * <li>使用可能文字: 算用数字</li>
	 * </p>
	 * <p>
	 * 引数がnullの場合はfalse。
	 * </p>
	 * <p>
	 * 上記以外の仕様にする場合はカスタマイズが必要です。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列がHSコードとして妥当な場合true それ以外 false
	 */
	public static boolean isHSCd(String str) {
		return me()._isHSCd(str);
	}

	/**
	 * {@link #isHSCd(String)}
	 */
	protected boolean _isHSCd(String str) {
		if (_isNull(str)) return false;
		for (char c : str.toCharArray()) {
			if (_isDigitsStr(String.valueOf(c))) {
				// 何もしない
			}
			else {
				return false;
			}
		}
		return true;
	}

	/**
	 * 評価対象の文字列が郵便番号として妥当かどうかを判定します。
	 * <p>
	 * フォーマットリソースのキー"FX.zipold.pattern"の値を取得し、
	 * 評価対象の文字列とパターンマッチを行います。
	 * マッチした場合はtrueを返します。
	 * </br>
	 * ユーザのロケールに対応したフォーマットリソースから値が取得されます。
	 * </br>
	 * 評価対象の文字列がnullまたは空文字の場合はfalseを返します。
	 * </br>
	 * caseを無視する場合、フォーマットリソースのキー"FX.zipold.case.insensitive"にtrueを設定してください。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @param locale ロケール
	 * @return 評価対象の文字列が郵便番号として妥当な場合true それ以外 false
	 */
	public static boolean isZipCdStr(String str) {
		return me()._isZipCdStr(str);
	}

	/**
	 * {@link #isZipCdStr(String)}
	 */	
	protected boolean _isZipCdStr(String str) {
		return matches(str, "zipold", null);	
	}

	/**
	 * 評価対象の文字列が郵便番号として妥当かどうかを判定します。
	 * <p>
	 * フォーマットリソースのキー"FX.zip.pattern"の値を取得し、
	 * 評価対象の文字列とパターンマッチを行います。
	 * マッチした場合はtrueを返します。
	 * </br>
	 * 引数のロケールに対応したフォーマットリソースから値が取得されます。
	 * </br>
	 * 評価対象の文字列がnullまたは空文字の場合はfalseを返します。
	 * </br>
	 * caseを無視する場合、フォーマットリソースのキー"FX.zip.case.insensitive"にtrueを設定してください。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @param locale ロケール
	 * @return 評価対象の文字列が郵便番号として妥当な場合true それ以外 false
	 */
	public static boolean isZipCdStr(String str, Locale locale) {
		return me()._isZipCdStr(str, locale);
	}

	/**
	 * {@link #isZipCdStr(String, Locale)}
	 */	
	protected boolean _isZipCdStr(String str, Locale locale) {
		return matches(str, "zip", locale);	
	}

	protected boolean matches(String str, String key, Locale locale) {
		if (isNull(str)) {
			return false;
		}
		Pattern ptn = getPattern(key, locale);
		if (ptn == null) {
			return true;
		}
		return ptn.matcher(str).matches();
	}
	
	/**
	 * チェック用のPatternを取得します。</p>
	 * フォーマットリソースより、以下のキーで値を取得してPatternを作成します。
	 * <li>"FX.[key].pattern"
	 * <li>"FX.[key].case.insensitive"
	 * 
	 * 
	 * @param key タグ
	 * @param locale ロケール
	 * @return Pattern
	 */
	public Pattern getPattern(String key, Locale locale) {
		final String PTN = MCConst.createKey("FX",key,"pattern");
		final String CASE = MCConst.createKey("FX",key,"case", "insensitive");
		MCFormatConst fc = MCLocaleConst.format(locale);
		String p = fc.getString(PTN, null);
		if (isNull(p)) {
			return null;
		}
		
		Pattern ptn = null;
		if(Boolean.valueOf(fc.getString(CASE, "false"))){
			ptn = Pattern.compile(p,Pattern.CASE_INSENSITIVE);
		}
		else {
			ptn = Pattern.compile(p);
		}
		return ptn;	
	}

	/**
	 * 評価対象の文字列が電話番号として妥当かどうかを判定します。
	 * <p>
	 * デフォルト実装：
	 * <li>使用可能文字: 算用数字 - + ( ) と 半角スペース</li>
	 * </p>
	 * <p>
	 * フォーマットなどのチェックはしていない。
	 * 引数がnullの場合はfalse。
	 * </p>
	 * <p>
	 * 上記以外の仕様にする場合はカスタマイズが必要です。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が電話番号として妥当な場合true それ以外 false
	 */
	public static boolean isTelStr(String str) {
		return me()._isTelStr(str);
	}

	/**
	 * {@link #isTelStr(String)}
	 */	
	protected boolean _isTelStr(String str) {
		// メモ：この実装は、MCFrame3.62Mの電話番号チェックと同内容の実装をしている。
		// プロジェクト等で上記の処理とあわせる必要がない場合はこの実装にこだわる
		// 理由はない。
		if (_isNull(str)) return false;
		char[] regectChar = new char[] {
				'-', '+', '(', ')', ' '
		};
		StringBuilder sb = new StringBuilder();
		for (char c : str.toCharArray()) {
			boolean isAppend = true;
			for (char r : regectChar) {
				if (c == r) {
					isAppend = false;
					continue;
				}
			}
			if (isAppend) {
				sb.append(c);
			}
		}
		for (int i = 0; i < sb.length(); i++) {
			if (_isDigitsStr(String.valueOf(sb.charAt(i)))) {
				// 何もしない
			}
			else {
				return false;
			}
		}
		return true;
	}

	/**
	 * 評価対象の文字列がFAX番号として妥当かどうかを判定します。
	 * <p>
	 * デフォルト実装：
	 * <li>使用可能文字: 算用数字 - + ( ) と 半角スペース</li>
	 * </p>
	 * <p>
	 * フォーマットなどのチェックはしていない。
	 * 引数がnullの場合はfalse。
	 * </p>
	 * <p>
	 * 上記以外の仕様にする場合はカスタマイズが必要です。
	 * </p>
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列がFAX番号として妥当な場合true それ以外 false
	 */
	public static boolean isFaxStr(String str) {
		return me()._isFaxStr(str);
	}

	/**
	 * {@link #isFaxStr(String)}
	 */	
	protected boolean _isFaxStr(String str) {
		return _isTelStr(str);
	}

	/**
	 * 評価対象の文字列がURLとして妥当な文字列かどうかを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return URLとして妥当な文字列な場合true それ以外 false
	 */
	public static boolean isUrlStr(String str) {
		return me()._isUrlStr(str);
	}

	/**
	 * {@link #isUrlStr(String)}
	 */	
	protected boolean _isUrlStr(String str) {
		if (str == null) return false;
		// http://www.microsoft.com/japan/msdn/enterprise/pag/securityguidance/paght000001.aspx
		return str
				.matches("^(ht|f)tp(s?)\\:\\/\\/[0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*(:(0-9)*)*(\\/?)([a-zA-Z0-9\\-\\.\\?\\,\\'\\/\\\\\\+&amp;%\\$#_]*)?$");

	}

	/**
	 * 評価対象の文字列がE-mailとして妥当な文字列かどうかを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return E-mailとして妥当な文字列な場合true それ以外 false
	 */
	public static boolean isEmailStr(String str) {
		return me()._isEmailStr(str);
	}

	/**
	 * {@link #isEmailStr(String)}
	 */	
	protected boolean _isEmailStr(String str) {
		if (str == null) return false;
		// http://www.microsoft.com/japan/msdn/enterprise/pag/securityguidance/paght000001.aspx

		String[] va = MCStringUtil.split("@", str);
		if (va.length != 2) {
			return false;
		}
		if (!va[0].matches("^([0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*)")) {
			return false;
		}
		if (!va[1].matches("(([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$")) {
			return false;
		}
		return true;
	}

	/**
	 * 評価対象の文字列が数値を表す文字列かを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が数値を表す文字列の場合true それ以外 false
	 */
	public static boolean isNumberStr(String str) {
		return me()._isNumberStr(str);
	}

	protected static final String NOT_NUMBER_STR_EX = FCBFC0003;

	/**
	 * {@link #isNumberStr(String)}
	 */	
	protected boolean _isNumberStr(String str) {
		if (str == null) return false;
		boolean ans = true;
		try {
			MCNumber.valueOf(str);
		}
		catch (MCException ex) {
			// FCBFC0003 数値文字列が解析できませんでした。
			if (ex.getID().equals(NOT_NUMBER_STR_EX)) {
				ans = false;
			}
			else {
				throw ex;
			}
		}
		return ans;
	}

	/**
	 * 評価対象の文字列が正の数値を表す文字列かを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が正の数値を表す文字列の場合true それ以外 false
	 */
	public static boolean isPositiveNumberStr(String str) {
		return me()._isPositiveNumberStr(str);
	}

	/**
	 * {@link #isPositiveNumberStr(String)}
	 */	
	protected boolean _isPositiveNumberStr(String str) {
		if (str == null) return false;
		boolean ans = true;
		try {
			MCNumber num = MCNumber.valueOf(str);
			ans = num.isPositive();
		}
		catch (MCException ex) {
			// FCBFC0003 数値文字列が解析できませんでした。
			if (ex.getID().equals(NOT_NUMBER_STR_EX)) {
				ans = false;
			}
			else {
				throw ex;
			}
		}
		return ans;
	}

	/**
	 * 評価対象の文字列が負の数値を表す文字列かを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が負の数値を表す文字列の場合true それ以外 false
	 */

	public static boolean isNegativeNumberStr(String str) {
		return me()._isNegativeNumberStr(str);
	}

	/**
	 * {@link #isNegativeNumberStr(String)}
	 */	
	protected boolean _isNegativeNumberStr(String str) {
		if (str == null) return false;
		boolean ans = true;
		try {
			MCNumber num = MCNumber.valueOf(str);
			ans = num.isNegative();
		}
		catch (MCException ex) {
			// FCBFC0003 数値文字列が解析できませんでした。
			if (ex.getID().equals(NOT_NUMBER_STR_EX)) {
				ans = false;
			}
			else {
				throw ex;
			}
		}
		return ans;
	}

	/**
	 * 評価対象の文字列が半角の英数字のみで構成されているかを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が全て半角の英数字のみで構成されている場合true それ以外 false
	 */
	public static boolean isDigitsAlphabetStr(String str) {
		return me()._isDigitsAlphabetStr(str);
	}

	/**
	 * {@link #isDigitsAlphabetStr(String)}
	 */	
	protected boolean _isDigitsAlphabetStr(String str) {
		if (str == null) return false;
		return str.matches("[0-9a-zA-Z]+");
	}

	/**
	 * 評価対象の文字列が半角の英字のみで構成されているかを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が全て半角の英字のみで構成されている場合true それ以外 false
	 */
	public static boolean isAlphabetStr(String str) {
		return me()._isAlphabetStr(str);
	}

	/**
	 * {@link #isAlphabetStr(String)}
	 */	
	protected boolean _isAlphabetStr(String str) {
		if (str == null) return false;
		return str.matches("[a-zA-Z]+");
	}

	/**
	 * 評価対象の文字列が半角の数字のみで構成されているかを判定します。
	 * 
	 * @param str 評価対象の文字列
	 * @return 評価対象の文字列が全て半角の数字のみで構成されている場合true それ以外 false
	 */
	public static boolean isDigitsStr(String str) {
		return me()._isDigitsStr(str);
	}

	/**
	 * {@link #isDigitsStr(String)}
	 */	
	protected boolean _isDigitsStr(String str) {
		if (str == null) return false;
		return str.matches("[0-9]+");
	}

	/**
	 * OracleのLPAD関数相当の処理を提供します。
	 * <p>
	 * LPADを行います。 文字列[num]の左に指定した文字列[addStr]を[len]に 満たすまで挿入します。<BR>
	 * 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数[len]が０以下の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param num 対象の数値
	 * @param len 補充するまでの桁数（LPADを行った後のサイズを指定します。）
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String lpad(int num, int len, String addStr) {
		return me()._lpad(num, len, addStr);
	}

	/**
	 * {@link #lpad(int, int, String)}
	 */	
	protected String _lpad(int num, int len, String addStr) {
		return _lpad(String.valueOf(num), len, addStr);
	}

	/**
	 * OracleのLPAD関数相当の処理を提供します。
	 * <p>
	 * LPADを行います。 文字列[str]の左に指定した文字列[addStr]を[len]に 満たすまで挿入します。<BR>
	 * 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数[len]が０以下の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param str 対象文字列
	 * @param len 補充するまでの桁数（LPADを行った後のサイズを指定します。）
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String lpad(String str, int len, String addStr) {
		return me()._lpad(str, len, addStr);
	}

	/**
	 * {@link #lpad(String, int, String)}
	 */	
	protected String _lpad(String str, int len, String addStr) {
		return _fillString(str, LR.L, len, addStr);
	}

	/**
	 * OracleのLPAD関数相当の処理を提供します。
	 * <P>
	 * LPADを行います。 数値[num]の左に指定した文字列[addStr]を[MEMeta]に 指定されている桁数を満たすまで挿入します。<BR>
	 * 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数を持つMETA[meta]がnull又は、桁数無制限の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param num 対象の数値
	 * @param meta 補充するまでの桁数を持つMETA
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String lpad(int num, MCMeta meta, String addStr) {
		return me()._lpad(num, meta, addStr);
	}

	/**
	 * {@link #lpad(int, MCMeta, String)}
	 */	
	protected String _lpad(int num, MCMeta meta, String addStr) {
		return _lpad(String.valueOf(num), meta, addStr);
	}

	/**
	 * OracleのLPAD関数相当の処理を提供します。
	 * <P>
	 * LPADを行います。 文字列[str]の左に指定した文字列[addStr]を[MEMeta]に 指定されている桁数を満たすまで挿入します。<BR>
	 * 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数を持つMETA[meta]がnull又は、桁数無制限の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param str 対象文字列
	 * @param meta 補充するまでの桁数を持つMETA
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String lpad(String str, MCMeta meta, String addStr) {
		return me()._lpad(str, meta, addStr);
	}

	/**
	 * {@link #lpad(String, MCMeta, String)}
	 */	
	protected String _lpad(String str, MCMeta meta, String addStr) {
		if (meta == null) {
			return _fillString(str, LR.R, -1, addStr);
		}
		return _fillString(str, LR.L, meta.length(), addStr);
	}

	/**
	 * OracleのRPAD関数相当の処理を提供します。
	 * <P>
	 * RPADを行います。 数値[num]の右に指定した文字列[addStr]を[len]に 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数[len]が０以下の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param num 対象の数字
	 * @param len 補充するまでの桁数（_rpadを行った後のサイズを指定します。）
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String rpad(int num, int len, String addStr) {
		return me()._rpad(num, len, addStr);
	}

	/**
	 * {@link #rpad(int, int, String)}
	 */	
	protected String _rpad(int num, int len, String addStr) {
		return _rpad(String.valueOf(num), len, addStr);
	}

	/**
	 * OracleのRPAD関数相当の処理を提供します。
	 * <P>
	 * RPADを行います。 文字列[str]の右に指定した文字列[addStr]を[len]に 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数[len]が０以下の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param str 対象文字列
	 * @param len 補充するまでの桁数（_rpadを行った後のサイズを指定します。）
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String rpad(String str, int len, String addStr) {
		return me()._rpad(str, len, addStr);
	}

	/**
	 * {@link #rpad(String, int, String)}
	 */	
	protected String _rpad(String str, int len, String addStr) {
		return _fillString(str, LR.R, len, addStr);
	}

	/**
	 * OracleのRPAD関数相当の処理を提供します。
	 * <P>
	 * RPADを行います。 数値[num]の右に指定した文字列[addStr]を[MEMeta]に 指定されている桁数を満たすまで挿入します。<br>
	 * 満たすまで挿入します。<br>
	 * 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数を持つMETA[meta]がnull又は、桁数無制限の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param int 対象の数値
	 * @param meta 補充するまでの桁数を持つMETA
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String rpad(int num, MCMeta meta, String addStr) {
		return me()._rpad(num, meta, addStr);
	}

	/**
	 * {@link #rpad(int, MCMeta, String)}
	 */	
	protected String _rpad(int num, MCMeta meta, String addStr) {
		return _rpad(num, meta.length(), addStr);
	}

	/**
	 * OracleのRPAD関数相当の処理を提供します。
	 * <P>
	 * RPADを行います。 文字列[str]の右に指定した文字列[addStr]を[MEMeta]に 指定されている桁数を満たすまで挿入します。<br>
	 * 満たすまで挿入します。<br>
	 * 以下の場合は、戻り値がnullになります。
	 * <li>補充するまでの桁数を持つMETA[meta]がnull又は、桁数無制限の場合</li>
	 * <li>挿入する文字列[addStrが]Null状態の場合</li>
	 * </P>
	 * 
	 * @param str 対象文字列
	 * @param meta 補充するまでの桁数を持つMETA
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	public static String rpad(String str, MCMeta meta, String addStr) {
		return me()._rpad(str, meta, addStr);
	}

	/**
	 * {@link #rpad(String, MCMeta, String)}
	 */	
	protected String _rpad(String str, MCMeta meta, String addStr) {
		if (meta == null) {
			return _fillString(str, LR.R, -1, addStr);
		}
		return _fillString(str, LR.R, meta.length(), addStr);
	}

	/**
	 * 左右（L 左(Left) / R 右(Right)）
	 */
	protected enum LR {
		L, R
	};

	/**
	 * 文字列[str]に対して、補充する文字列[addStr]を [position]の位置に[len]に満たすまで挿入します。
	 * ※[str]がnullや空リテラルの場合でも[addStr]を [len]に満たすまで挿入した結果を返します。
	 * 
	 * @param str 対象文字列
	 * @param position 前に挿入 ⇒ L 後に挿入 ⇒ R
	 * @param len 補充するまでの桁数
	 * @param addStr 挿入する文字列
	 * @return 変換後の文字列。
	 */
	protected String _fillString(String str, LR position, int len, String addStr) {
		if (_isNull(addStr)) {
			return null;
		}
		if (!(len > 0)) {
			return null;
		}
		String padStr = addStr;

		StringBuilder buffer = new StringBuilder(nvl(str, ""));
		while (len > buffer.length()) {
			if (LR.L == position) {
				int sum = buffer.length() + padStr.length();
				if (sum > len) {
					padStr = padStr.substring(0, padStr.length() - (sum - len));
					buffer.insert(buffer.length() - str.length(), padStr);
				}
				else {
					buffer.insert(0, padStr);
				}
			}
			else if (LR.R == position) {
				buffer.append(padStr);
			}
		}
		if (buffer.length() == len) {
			return buffer.toString();
		}
		return buffer.toString().substring(0, len);
	}

	// String オリジナル（ここまで）
	// 共通 Number（ここから）
	/**
	 * 値がNull状態か判定します。
	 * <P>
	 * 以下の場合はNull状態とみなしtrueを返します。
	 * <li>値がnullの場合</li>
	 * </P>
	 *
	 * @param value 評価対象の値
	 * @return boolean Null状態の場合true それ以外は false
	 */
	public static boolean isNull(MCNumber val) {
		return me()._isNull(val);
	}

	/**
	 * 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 *
	 * @param val 評価対象の値
	 * @param defVal nullの時に使用される値
	 * @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 */
	public static MCNumber nvl(MCNumber val, MCNumber defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	 *
	 * @param val1 評価対象の値
	 * @param val2 評価対象の値
	 * @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	 */
	public static boolean isSame(MCNumber val1, MCNumber val2) {
		return me()._isSame((Number) val1, (Number) val2);
	}

	// 共通 Number（ここまで）
	// Numberオリジナル（ここから）

	/**
	 * 符号反転を行うメソッド。引数がnullの場合はnullを返します。 それ以外は、MCNumber#negate()の仕様に準じます。
	 * 
	 * @param num 符号反転を行う対象の値
	 * @return num の符号を反転した値。但し、num が null の場合は null
	 * @see mcframe.commonCore.lang.MCNumber#negate()
	 */
	public static MCNumber negate(MCNumber n) {
		return me()._negate(n);
	}

	/**
	 * {@link #negate(MCNumber)}
	 */	
	protected MCNumber _negate(MCNumber n) {
		if (n == null) {
			return null;
		}
		return n.negate();
	}

	/**
	 * 引数の合計値を計算します。引数の要素がnull及び数値以外の場合は無視します。
	 * <p>
	 * 全ての要素が無視されるとnullを返します。<br>
	 * 
	 * @param args 数値の配列
	 * @return 引数の各要素の合計値。全ての引数要素がnull及び数値以外の場合はnull
	 */
	public static MCNumber sum(Comparable<?>... args) {
		return me()._sum(args);
	}

	/**
	 * {@link #sum(Comparable...)}
	 */	
	protected MCNumber _sum(Comparable<?>... args) {
		MCNumber ans = null;
		for (Comparable<?> c : args) {
			if (c != null && c instanceof Number) {
				MCNumber n = toMCNumber(c);
				ans = _nvl(n.add(ans), n);
			}
		}
		return ans;
	}

	// Numberオリジナル（ここまで）
	// 共通 MCDate（ここから）
	/**
	 * 値がNull状態か判定します。
	 * <P>
	 * 以下の場合はNull状態とみなしtrueを返します。
	 * <li>値がnullの場合</li>
	 * </P>
	 *
	 * @param MCDate value 評価対象の値
	 * @return boolean Null状態の場合true それ以外は false
	 */
	public static boolean isNull(MCDate val) {
		return me()._isNull(val);
	}

	/**
	 * 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 *
	 * @param val 評価対象の値
	 * @param defVal nullの時に使用される値
	 * @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 */
	public static MCDate nvl(MCDate val, MCDate defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	 *
	 * @param val1 評価対象の値
	 * @param val2 評価対象の値
	 * @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	 */
	public static boolean isSame(MCDate val1, MCDate val2) {
		return me()._isSame(val1, val2);
	}

	// 共通 MCDate（ここまで）
	// MCDateオリジナル（ここから）
	/**
	 * 年月に変換します。
	 *
	 * @param date 変換対象の年月日
	 * @return 年月を表す MCDate
	 */
	public static MCDate toYM(MCDate date) {
		return me()._toYM(date);
	}

	/**
	 * 年月に変換します。
	 * 
	 * @param date 変換対象の年月日
	 * @return 年月を表す MCDate
	 */
	protected MCDate _toYM(MCDate date) {
		return date.startOfMonth();
	}

	// MCDateオリジナル（ここまで）

	// 共通 boolean（ここから）
	/**
	 * 値がNull状態か判定します。
	 * <P>
	 * 以下の場合はNull状態とみなしtrueを返します。
	 * <li>値がnullの場合</li>
	 * </P>
	 * アプリでは基本的にBooleanを使用しないため、アプリから 直接呼び出すことはない。
	 *
	 * @param MCNumber value 評価対象の値
	 * @return boolean Null状態の場合true それ以外は false
	 */
	public static boolean isNull(Boolean val) {
		return me()._isNull(val);
	}

	/**
	 * 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 *
	 * @param val 評価対象の値
	 * @param defVal nullの時に使用される値
	 * @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 */
	public static Boolean nvl(Boolean val, Boolean defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	 *
	 * @param val1 評価対象の値
	 * @param val2 評価対象の値
	 * @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	 */
	public static boolean isSame(Boolean val1, Boolean val2) {
		return me()._isSame(val1, val2);
	}

	// 共通 boolean（ここまで）
	// 共通 MCRow（ここから）
	/**
	 * 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 *
	 * @param val 評価対象の値
	 * @param defVal nullの時に使用される値
	 * @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	 */
	public static MCRow nvl(MCRow val, MCRow defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	 *
	 * @param val1 評価対象の値
	 * @param val2 評価対象の値
	 * @return val1とval2が両方がNull状態の場合、およびval1とval2が同値の場合 true。それ以外false。
	 */
	public static boolean isSame(MCRow val1, MCRow val2) {
		return me()._isSame(val1, val2);
	}

	/**
	 * 値がNull状態か判定します。
	 *
	 * @param Comparable value 評価対象の値
	 * @return boolean Null状態の場合true それ以外は false
	 */
	public static boolean isNull(MCRow val) {
		return me()._isNull(val);
	}

	// 共通 MCRow（ここまで）

	/**
	 * rowの指定された列が全て同値（Null状態を加味）かどうかを判断します。
	 * 
	 * @param row1 評価対象のrow1
	 * @param row2 評価対象のrow2
	 * @param cols 値を比較するカラム名又はカラムパス
	 * @return Null状態の場合true それ以外は false
	 */
	public static boolean isColSame(MCRow row1, MCRow row2, String... cols) {
		return me()._isColSame(row1, row2, cols);
	}

	/**
	 * rowの指定された列が全て同値（Null状態を加味）かどうかを判断します。
	 * 
	 * @param row1 評価対象のrow1
	 * @param row2 評価対象のrow2
	 * @param cols 値を比較するカラム名又はカラムパス
	 * @return Null状態の場合true それ以外は false
	 */
	protected <X extends MCRow> boolean _isColSame(X row1, X row2, String... cols) {
		return _isColSame(row1, cols, row2, cols);
	}

	/**
	 * rowの指定された列が全て同値（Null状態を加味）かどうかを判断します。
	 * 
	 * @param row1 評価対象のrow1
	 * @param cols1 値を比較するrow1のカラム名又はカラムパス
	 * @param row2 評価対象のrow2
	 * @param cols2 値を比較するrow2のカラム名又はカラムパス
	 * @return 指定されたカラムが同値の場合true それ以外は false
	 */
	public static boolean isColSame(MCRow row1, java.lang.String[] cols1, MCRow row2,
			java.lang.String[] cols2) {
		return me()._isColSame(row1, cols1, row2, cols2);
	}

	/**
	 * {@link #isColSame(MCRow, String[], MCRow, String[])}
	 */	
	protected boolean _isColSame(MCRow row1, String[] cols1, MCRow row2, String[] cols2) {
		if (row1 == null) {
			if (row2 == null) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (row2 == null) {
			return false;
		}
		for (int i = 0; i < cols1.length; i++) {
			if (!_isSame(row1.getValue(cols1[i]), row2.getValue(cols2[i]))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * リストがNull状態か判定します。
	 * <P>
	 * 以下の場合はNull状態とみなしtrueを返します。
	 * <li>リストがnullの場合</li>
	 * <li>リストが空（empty）の場合</li>
	 * </P>
	 */
	public static boolean isNull(MCList list) {
		return me()._isNull(list);
	}

	/**
	 * {@link #isNull(MCList)}
	 */	
	protected boolean _isNull(MCList<?> list) {
		if (list == null) {
			return true;
		}
		return list.isEmpty();
	}

	/**
	 * 値がNull状態か判定します。
	 * <P>
	 * 評価対象の値の型を判断し、適切な同名のメソッドを呼び出します。<br>
	 * </P>
	 *
	 * @param Comparable value 評価対象の値
	 * @return boolean Null状態の場合true それ以外は false
	 */
	public static boolean isNull(Comparable val) {
		return me()._isNull(val);
	}

	/**
	* 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	*
	* @param val 評価対象の値
	* @param defVal nullの時に使用される値
	* @return 評価対象の値がnullの場合は、デフォルト値を返します。それ以外は、評価対象の値を返します。
	*/
	public static Comparable nvl(Comparable val, Comparable defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	* val1とval2が同値であるかどうかを判定します（Null状態を加味）。
	*
	* @param val1 評価対象の値
	* @param val2 評価対象の値
	* @return val1とval2が両方がNull状態の場合(但し、同じMCDataTypeであること)、およびval1とval2が同値の場合
	* true。それ以外false。
	*/
	public static boolean isSame(Comparable val1, Comparable val2) {
		return me()._isSame(val1, val2);
	}

	/**
	 * 全てnullだったらtrueそれ以外false。引数がnullだったり、 長さ０の配列だったらとりあえず例外（最終的にどうすれば良いのか現時点でわからないから）
	 */
	public static boolean isNullAnd(Comparable<?>... vals) {
		return me()._isNullAnd(vals);
	}

	/**
	 * {@link #isNullAnd(Comparable...)}
	 */	
	public boolean _isNullAnd(Comparable<?>... vals) {
		if (vals == null) {
			// isNullAnd(null) と書いた場合
			return true;
		}
		if (vals.length == 0) {
			// isNullAnd() と書いた場合
			return false;
		}
		for (Comparable<?> val : vals) {
			if (_isNull(val) == false) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 一つでもnullだったらtrueそれ以外false。
	 */
	public static boolean isNullOr(Comparable<?>... vals) {
		return me()._isNullOr(vals);
	}

	/**
	 * {@link #isNullOr(Comparable...)}
	 */	
	public boolean _isNullOr(Comparable<?>... vals) {
		if (vals == null) {
			// isNullOr(null) と書いた場合
			return true;
		}
		if (vals.length == 0) {
			// isNullOr() と書いた場合
			return false;
		}
		for (Comparable<?> val : vals) {
			if (_isNull(val)) {
				return true;
			}
		}
		return false;
	}

	/**
	* Oracleの like 演算子と同等の結果を返すメソッドです（arg0 like arg1）。
	* <P>Oracleのlikeと同じ仕様を目指しているので isLike(null,null) は falseです。</P>
	* arg1の値は、MCStringUtil#arrayValueSplitメソッドにて複数の値に分割され、
	* いずれかの値が該当すれば、trueを返します。<BR>
	*/
	public static boolean isLike(String arg0, String arg1) {
		return me()._isLike(arg0, arg1, true);
	}

	/**
	* Oracleの like 演算子と同等の結果を返すメソッドです（arg0 like arg1）。
	* <P>Oracleのlikeと同じ仕様を目指しているので isLike(null,null) は falseです。</P>
	* arg1の値は、複数の値へ分割しません。<BR>
	*/
	public static boolean isLikeNoArray(String arg0, String arg1) {
		return me()._isLike(arg0, arg1, false);
	}

	static boolean ARRAY_VALUE_INVALID = 
			MCConst.plugin.getBoolean(
				MCConst.createKey("ArrayValue", "invalid"), false);

	/**
	* Oracleの like 演算子と同等の結果を返すメソッドです（arg0 like arg1）。
	* <P>Oracleのlikeと同じ仕様を目指しているので isLike(null,null) は falseです。</P>
	* 引数arrayにtrueを指定した場合は、arg1の値をMCStringUtil#arrayValueSplitメソッドにて
	* 分割し、いずれかの値が該当すれば、trueを返します。<BR>
	*/
	protected boolean _isLike(String arg0, String arg1, boolean array) {
		if (isNull(arg0)) return false;
		if (isNull(arg1)) return false;
		if (array && !ARRAY_VALUE_INVALID) {
			String[] arg1s = MCStringUtil.arrayValueSplit(arg1);
			for (String ag : arg1s) {
				String regex = _toRegexForOracleLike(ag);
				if (arg0.matches(regex)) {
					return true;
				}
			}
			return false;
		}
		else{
			String regex = _toRegexForOracleLike(arg1);
			return arg0.matches(regex);
		}
	}

	/**
	* Oracle の like 演算子相当の評価を行うための正規表現を返す。
	* <pre>
	* // static import しているイメージで
	* boolean flg = str.matches(toRegexForOracleLike('ABC%XYZ'));
	* </pre>
	*/
	public static String toRegexForOracleLike(String str) {
		return me()._toRegexForOracleLike(str);
	}

	/**
	 * {@link #toRegexForOracleLike(String)}
	 */	
	protected String _toRegexForOracleLike(String str) {
		String ans = str;
		// 正規表現の文字列を回避
		String[][] escStrArr = new String[][] {
			{
					"\\\\E", "\\\\E\\\\\\\\E\\\\Q"
			}
		};
		for (String[] e : escStrArr) {
			ans = ans.replaceAll(e[0], e[1]);
		}
		// 曖昧検索対応
		String[][] replaceArray = new String[][] {
				{
						"%", "\\\\E.*\\\\Q"
				}, {
						"_", "\\\\E.\\\\Q"
				}
		};
		for (String[] e : replaceArray) {
			ans = ans.replaceAll(e[0], e[1]);
		}
		ans = "\\Q" + ans + "\\E";
		return ans;
	}
	
	/**
	 * 日付フォーマットを取得するリソースキーを返します。
	 *
	 * @param id フォーマット ID
	 * @return リソースキー
	 */
	protected String getDateOutputPatternKey(String id) {
		return MCConst.createKey("FX.date", id, "output.pattern");
	}
}
