package mcframe.commonFXUC.FXUCC0010;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCC_DataUtil extends FXUCC_DataUtil_FW {

}
