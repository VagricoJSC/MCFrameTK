package mcframe.commonFXUC.FXUCC0170;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCC_ValidaterUtil extends FXUCC_ValidaterUtil_FW {
}
