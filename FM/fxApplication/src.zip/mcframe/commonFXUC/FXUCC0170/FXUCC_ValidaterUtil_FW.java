package mcframe.commonFXUC.FXUCC0170;

import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.notice.MCMessage;

/**
 * 項目チェックのユーティリティクラスです。
 */
public abstract class FXUCC_ValidaterUtil_FW {

	/**
	 * 自身のインスタンス
	 */
	private static FXUCC_ValidaterUtil _me;

	/**
	 * コンストラクタです。
	 */
	public FXUCC_ValidaterUtil_FW() {
		super();
	}

	protected static FXUCC_ValidaterUtil me() {
		if (_me == null) {
			_me = new FXUCC_ValidaterUtil();
		}
		return _me;
	}

	protected String toString(MCMessage msg) {
		return msg.toString();
	}

	/**
	 * 複数のメッセージ用名称をメッセージで表示する際に使用する区切り文字列を返します。
	 *
	 * @return 区切り文字列
	 */
	protected String labelSeparator() {
		return " , ";
	}

	/**
	 * 指定されたラベルと値の文字列表現を返します。
	 * <p>
	 * ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 * 複数指定された場合は改行コード（LF）で区切ります。<br>
	 * ラベルと値の数が異なる場合は数が少ない方に合わせます。
	 *
	 * @param label ラベル
	 * @param value 値
	 * @return 文字列
	 */
	public static String toStringWithMsgLabel(String[] label, Comparable<?>[] value) {
		return me()._toStringWithMsgLabel(label, value);
	}

	/**
	 * 指定されたラベルと値の文字列表現を返します。
	 * <p>
	 * ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 *
	 * @param label ラベル
	 * @param value 値
	 * @return 文字列
	 */
	public static String toStringWithMsgLabel(String label, Comparable<?> value) {
		return me()._toStringWithMsgLabel(label, value);
	}

	/**
	 * 指定された項目の文字列表現を返します。
	 * <p>
	 * 項目ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 *
	 * @param label ラベル
	 * @param value 値
	 * @return 文字列
	 */
	protected String _toStringWithMsgLabel(String label, Comparable<?> value) {
		return toString(new MCMessage(FXUCC0022, label, value));
	}

	/**
	 * 指定された項目の文字列表現を返します。
	 * <p>
	 * 項目ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 * 複数指定された場合は引数の区切り文字で区切ります。<br>
	 * ラベルと値の数が異なる場合は数が少ない方に合わせます。
	 *
	 * @param label ラベル
	 * @param value 値
	 * @param delimiter 区切り文字
	 * @return 文字列
	 */
	protected String _toStringWithMsgLabel(String label[], Comparable<?>[] value,
			String delimiter) {
		int length = label.length < value.length ? label.length : value.length;
		String[] msg = new String[length];
		for (int i = 0; i < length; i++) {
			msg[i] = _toStringWithMsgLabel(label[i], value[i]);
		}
		return MCStringUtil.join(delimiter, msg);
	}

	/**
	 * 指定された項目の文字列表現を返します。
	 * <p>
	 * 項目ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 * 複数指定された場合は改行コード（LF）で区切ります。<br>
	 * ラベルと値の数が異なる場合は数が少ない方に合わせます。
	 *
	 * @param label ラベル
	 * @param value 値
	 * @return 文字列
	 */
	protected String _toStringWithMsgLabel(String label[], Comparable<?>[] value) {
		return _toStringWithMsgLabel(label, value, MCStringUtil.LF_CODE);
	}

	// ----- 各種メッセージ START ---------------

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param val 値
	 * @param metaLength メタで定義された精度
	 * @param metaScale メタで定義された小数点以下の桁数
	 * @return FXUCC0023
	 */
	public static MCMessage msgInvalidNumberPrecision(String msgLabel, Comparable<?> val,
			int metaLength, int metaScale) {
		return me()._msgInvalidNumberPrecision(msgLabel, val, metaLength, metaScale);
	}

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param val 値
	 * @param metaLength メタで定義された精度
	 * @param metaScale メタで定義された小数点以下の桁数
	 * @return FXUCC0023
	 */
	protected MCMessage _msgInvalidNumberPrecision(String msgLabel, Comparable<?> val,
			int metaLength, int metaScale) {
		return new MCMessage(FXUCC0023, msgLabel, val, metaLength - metaScale, metaScale);
	}

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param val 値
	 * @param metaLength メタで定義された精度
	 * @param metaScale メタで定義された小数点以下の桁数
	 * @return FXUCC0024
	 */
	public static MCMessage msgInvalidNumberPrecision(String msgLabel, int guiIdx,
			Comparable<?> val, int metaLength, int metaScale) {
		return me()._msgInvalidNumberPrecision(msgLabel, guiIdx, val, metaLength,
				metaScale);
	}

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param val 値
	 * @param metaLength メタで定義された精度
	 * @param metaScale メタで定義された小数点以下の桁数
	 * @return FXUCC0024
	 */
	protected MCMessage _msgInvalidNumberPrecision(String msgLabel, int guiIdx,
			Comparable<?> val, int metaLength, int metaScale) {
		return new MCMessage(FXUCC0024, msgLabel, guiIdx + 1, val,
				metaLength - metaScale, metaScale);
	}

	/**
	 * 入力フィールドに設定される最大文字数より多い文字を設定された場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param val 値
	 * @param inputLength 値の文字数
	 * @param metaLength メタで定義された文字数
	 * @return FXUCC0026
	 */
	public static MCMessage msgTooLongString(String msgLabel, Comparable<?> val,
			int inputLength, int metaLength) {
		return me()._msgTooLongString(msgLabel, val, inputLength, metaLength);
	}

	/**
	 * 入力フィールドに設定される最大文字数より多い文字を設定された場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param val 値
	 * @param inputLength 値の文字数
	 * @param metaLength メタで定義された文字数
	 * @return FXUCC0025
	 */
	protected MCMessage _msgTooLongString(String msgLabel, Comparable<?> val,
			int inputLength, int metaLength) {
		return new MCMessage(FXUCC0025, msgLabel, val, inputLength, metaLength);
	}

	/**
	 * 入力フィールドに設定される最大文字数より多い文字を設定された場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param val 値
	 * @param inputLength 値の文字数
	 * @param metaLength メタで定義された文字数
	 * @return FXUCC0026
	 */
	public static MCMessage msgTooLongString(String msgLabel, int guiIdx,
			Comparable<?> val, int inputLength, int metaLength) {
		return me()._msgTooLongString(msgLabel, guiIdx, val, inputLength, metaLength);
	}

	/**
	 * 入力フィールドに設定される最大文字数より多い文字を設定された場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param val 値
	 * @param inputLength 値の文字数
	 * @param metaLength メタで定義された文字数
	 * @return FXUCC0026
	 */
	protected MCMessage _msgTooLongString(String msgLabel, int guiIdx, Comparable<?> val,
			int inputLength, int metaLength) {
		return new MCMessage(FXUCC0026, msgLabel, guiIdx + 1, val, inputLength,
				metaLength);
	}

	/**
	 * ０より大きい値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0027
	 */
	public static MCMessage msgNotPositive(String msgLabel) {
		return me()._msgNotPositive(msgLabel);
	}

	/**
	 * ０より大きい値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0027
	 */
	protected MCMessage _msgNotPositive(String msgLabel) {
		return new MCMessage(FXUCC0027, msgLabel);
	}

	/**
	 * ０より大きい値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0028
	 */
	public static MCMessage msgNotPositive(String msgLabel, int guiIdx) {
		return me()._msgNotPositive(msgLabel, guiIdx);
	}

	/**
	 * ０より大きい値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0028
	 */
	protected MCMessage _msgNotPositive(String msgLabel, int guiIdx) {
		return new MCMessage(FXUCC0028, msgLabel, guiIdx + 1);
	}

	/**
	 * ０以外の値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0029
	 */
	public static MCMessage msgZero(String msgLabel) {
		return me()._msgZero(msgLabel);
	}

	/**
	 * ０以外の値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0029
	 */
	protected MCMessage _msgZero(String msgLabel) {
		return new MCMessage(FXUCC0029, msgLabel);
	}

	/**
	 * ０以外の値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0030
	 */
	public static MCMessage msgZero(String msgLabel, int guiIdx) {
		return me()._msgZero(msgLabel, guiIdx);
	}

	/**
	 * ０以外の値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0030
	 */
	protected MCMessage _msgZero(String msgLabel, int guiIdx) {
		return new MCMessage(FXUCC0030, msgLabel, guiIdx + 1);
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx1 行数。guiIndx1+1がメッセージに設定される
	 * @param guiIdx2 行数。guiIndx2+1がメッセージに設定される
	 * @return FXUCC0031
	 */
	public static MCMessage msgDuplicate(String msgLabel, int guiIdx1, int guiIdx2) {
		return me()._msgDuplicate(msgLabel, guiIdx1, guiIdx2);
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx1 行数。guiIndx1+1がメッセージに設定される
	 * @param guiIdx2 行数。guiIndx2+1がメッセージに設定される
	 * @return FXUCC0031
	 */
	protected MCMessage _msgDuplicate(String msgLabel, int guiIdx1, int guiIdx2) {
		return new MCMessage(FXUCC0031, msgLabel, guiIdx1 + 1, guiIdx2 + 1);
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージ
	 *
	 * @param msgLabels 項目名
	 * @return FXUCC0032
	 */
	public static MCMessage msgAtLeastOneInput(String msgLabels) {
		return me()._msgAtLeastOneInput(msgLabels);
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージ
	 *
	 * @param msgLabels 項目名
	 * @return FXUCC0032
	 */
	protected MCMessage _msgAtLeastOneInput(String msgLabels) {
		return new MCMessage(FXUCC0032, msgLabels);
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージ
	 *
	 * @param msgLabels 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0033
	 */
	public static MCMessage msgAtLeastOneInput(String msgLabels, int guiIdx) {
		return me()._msgAtLeastOneInput(msgLabels, guiIdx);
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージ
	 *
	 * @param msgLabels 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0033
	 */
	protected MCMessage _msgAtLeastOneInput(String msgLabels, int guiIdx) {
		return new MCMessage(FXUCC0033, guiIdx + 1, msgLabels);
	}

	/**
	 * チェック対象の日付が運用日付以前の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0036またはFXUCC0058
	 */
	public static MCMessage msgNotAfterToday(String msgLabel, String dt, String today,
			boolean equals) {
		return me()._msgNotAfterToday(msgLabel, dt, today, equals);
	}

	/**
	 * チェック対象の日付が運用日付以前の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0036またはFXUCC0058
	 */
	protected MCMessage _msgNotAfterToday(String msgLabel, String dt, String today,
			boolean equals) {
		return new MCMessage(equals ? FXUCC0036 : FXUCC0058, msgLabel, dt, today);
	}

	/**
	 * チェック対象の日付が運用日付以前の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0037またはFXUCC0059
	 */
	public static MCMessage msgNotAfterToday(String msgLabel, String dt, String today,
			int guiIdx, boolean equals) {
		return me()._msgNotAfterToday(msgLabel, dt, today, guiIdx, equals);
	}

	/**
	 * チェック対象の日付が運用日付以前の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0037またはFXUCC0059
	 */
	protected MCMessage _msgNotAfterToday(String msgLabel, String dt, String today,
			int guiIdx, boolean equals) {
		return new MCMessage(equals ? FXUCC0037 : FXUCC0059, guiIdx + 1, msgLabel, dt,
				today);
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param today 運用日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0038またはFXUCC0062
	 */
	public static MCMessage msgNot2DtBeforeToday(String msgLabel1, String msgLabel2,
			String dt1, String dt2, String today, boolean equals) {
		return me()._msgNot2DtBeforeToday(msgLabel1, msgLabel2, dt1, dt2, today, equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param today 運用日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0038またはFXUCC0062
	 */
	protected MCMessage _msgNot2DtBeforeToday(String msgLabel1, String msgLabel2,
			String dt1, String dt2, String today, boolean equals) {
		return new MCMessage(equals ? FXUCC0038 : FXUCC0062, msgLabel1, msgLabel2, dt1,
				dt2, today);
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param today 運用日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0039またはFXUCC0063
	 */
	public static MCMessage msgNot2DtBeforeToday(String msgLabel1, String msgLabel2,
			String dt1, String dt2, String today, int guiIdx, boolean equals) {
		return me()._msgNot2DtBeforeToday(msgLabel1, msgLabel2, dt1, dt2, today, guiIdx,
				equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param today 運用日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0039またはFXUCC0063
	 */
	protected MCMessage _msgNot2DtBeforeToday(String msgLabel1, String msgLabel2,
			String dt1, String dt2, String today, int guiIdx, boolean equals) {
		return new MCMessage(equals ? FXUCC0039 : FXUCC0063, guiIdx + 1, msgLabel1,
				msgLabel2, dt1, dt2, today);
	}

	/**
	 * チェック対象の日付が運用日付以降の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0040またはFXUCC0060
	 */
	public static MCMessage msgNotBeforeToday(String msgLabel, String dt, String today,
			boolean equals) {
		return me()._msgNotBeforeToday(msgLabel, dt, today, equals);
	}

	/**
	 * チェック対象の日付が運用日付以降の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0040またはFXUCC0060
	 */
	protected MCMessage _msgNotBeforeToday(String msgLabel, String dt, String today,
			boolean equals) {
		return new MCMessage(equals ? FXUCC0040 : FXUCC0060, msgLabel, dt, today);
	}

	/**
	 * チェック対象の日付が運用日付以降の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0041またはFXUCC0061
	 */
	public static MCMessage msgNotBeforeToday(String msgLabel, String dt, String today,
			int guiIdx, boolean equals) {
		return me()._msgNotBeforeToday(msgLabel, dt, today, guiIdx, equals);
	}

	/**
	 * チェック対象の日付が運用日付以降の場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param dt 日付
	 * @param today 運用日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0041またはFXUCC0061
	 */
	protected MCMessage _msgNotBeforeToday(String msgLabel, String dt, String today,
			int guiIdx, boolean equals) {
		return new MCMessage(equals ? FXUCC0041 : FXUCC0061, guiIdx + 1, msgLabel, dt,
				today);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param msgLabel3 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param dt3 日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0042またはFXUCC0056
	 */
	public static MCMessage msgNot3DtBeforeAfter(String msgLabel1, String msgLabel2,
			String msgLabel3, String dt1, String dt2, String dt3, boolean equals) {
		return me()._msgNot3DtBeforeAfter(msgLabel1, msgLabel2, msgLabel3, dt1, dt2, dt3,
				equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param msgLabel3 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param dt3 日付
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0042またはFXUCC0056
	 */
	protected MCMessage _msgNot3DtBeforeAfter(String msgLabel1, String msgLabel2,
			String msgLabel3, String dt1, String dt2, String dt3, boolean equals) {
		return new MCMessage(equals ? FXUCC0042 : FXUCC0056, msgLabel1, msgLabel2,
				msgLabel3, dt1, dt2, dt3);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param msgLabel3 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param dt3 日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0043またはFXUCC0057
	 */
	public static MCMessage msgNot3DtBeforeAfter(String msgLabel1, String msgLabel2,
			String msgLabel3, String dt1, String dt2, String dt3, int guiIdx,
			boolean equals) {
		return me()._msgNot3DtBeforeAfter(msgLabel1, msgLabel2, msgLabel3, dt1, dt2, dt3,
				guiIdx, equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param msgLabel1 項目名
	 * @param msgLabel2 項目名
	 * @param msgLabel3 項目名
	 * @param dt1 日付
	 * @param dt2 日付
	 * @param dt3 日付
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0043またはFXUCC0057
	 */
	protected MCMessage _msgNot3DtBeforeAfter(String msgLabel1, String msgLabel2,
			String msgLabel3, String dt1, String dt2, String dt3, int guiIdx,
			boolean equals) {
		return new MCMessage(equals ? FXUCC0043 : FXUCC0057, guiIdx + 1, msgLabel1,
				msgLabel2, msgLabel3, dt1, dt2, dt3);
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来、過去であるべき日付の項目名
	 * @param msgLabel2 本来、未来であるべき日付の項目名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0044またはFXUCC0054
	 */
	public static MCMessage msgNotBefore(String msgLabel1, String msgLabel2,
			boolean equals) {
		return me()._msgNotBefore(msgLabel1, msgLabel2, equals);
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来、過去であるべき日付の項目名
	 * @param msgLabel2 本来、未来であるべき日付の項目名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0044またはFXUCC0054
	 */
	protected MCMessage _msgNotBefore(String msgLabel1, String msgLabel2, boolean equals) {
		return new MCMessage(equals ? FXUCC0044 : FXUCC0054, msgLabel1, msgLabel2);
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来、過去であるべき日付の項目名
	 * @param msgLabel2 本来、未来であるべき日付の項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0045またはFXUCC0055
	 */
	public static MCMessage msgNotBefore(String msgLabel1, String msgLabel2, int guiIdx,
			boolean equals) {
		return me()._msgNotBefore(msgLabel1, msgLabel2, guiIdx, equals);
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来、過去であるべき日付の項目名
	 * @param msgLabel2 本来、未来であるべき日付の項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0045またはFXUCC0055
	 */
	protected MCMessage _msgNotBefore(String msgLabel1, String msgLabel2, int guiIdx,
			boolean equals) {
		return new MCMessage(equals ? FXUCC0045 : FXUCC0055, msgLabel1, msgLabel2,
				guiIdx + 1);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0046
	 */
	public static MCMessage msgNoDataAtReq(String msgLabel) {
		return me()._msgNoDataAtReq(msgLabel);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0046
	 */
	protected MCMessage _msgNoDataAtReq(String msgLabel) {
		return new MCMessage(FXUCC0046, msgLabel);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0047
	 */
	public static MCMessage msgNoDataAtReq(String msgLabel, int guiIdx) {
		return me()._msgNoDataAtReq(msgLabel, guiIdx);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0047
	 */
	protected MCMessage _msgNoDataAtReq(String msgLabel, int guiIdx) {
		return new MCMessage(FXUCC0047, guiIdx + 1, msgLabel);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @return FXUCC0046
	 */
	public static MCMessage msgNoDataAtReq(MCRow causeRow, String causeCol,
			String msgLabel) {
		return me()._msgNoDataAtReq(causeRow, causeCol, msgLabel);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @return FXUCC0046
	 */
	protected MCMessage _msgNoDataAtReq(MCRow causeRow, String causeCol, String msgLabel) {
		return new MCMessage(causeRow, causeCol, FXUCC0046, msgLabel);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0047
	 */
	public static MCMessage msgNoDataAtReq(MCRow causeRow, String causeCol,
			String msgLabel, int guiIdx) {
		return me()._msgNoDataAtReq(causeRow, causeCol, msgLabel, guiIdx);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0047
	 */
	protected MCMessage _msgNoDataAtReq(MCRow causeRow, String causeCol, String msgLabel,
			int guiIdx) {
		return new MCMessage(causeRow, causeCol, FXUCC0047, guiIdx + 1, msgLabel);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来は小さい数値の項目名
	 * @param msgLabel2 本来は大きい数値の項目名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0052
	 */
	public static MCMessage msgNotSmall(String msgLabel1, String msgLabel2, boolean equals) {
		return me()._msgNotSmall(msgLabel1, msgLabel2, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来は小さい数値の項目名
	 * @param msgLabel2 本来は大きい数値の項目名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0048またはFXUCC0052
	 */
	protected MCMessage _msgNotSmall(String msgLabel1, String msgLabel2, boolean equals) {
		return new MCMessage(equals ? FXUCC0048 : FXUCC0052, msgLabel1, msgLabel2);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来は小さい数値の項目名
	 * @param msgLabel2 本来は大きい数値の項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0049またはFXUCC0053
	 */
	public static MCMessage msgNotSmall(String msgLabel1, String msgLabel2, int guiIdx,
			boolean equals) {
		return me()._msgNotSmall(msgLabel1, msgLabel2, guiIdx, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param msgLabel1 本来は小さい数値の項目名
	 * @param msgLabel2 本来は大きい数値の項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCC0049またはFXUCC0053
	 */
	protected MCMessage _msgNotSmall(String msgLabel1, String msgLabel2, int guiIdx,
			boolean equals) {
		return new MCMessage(equals ? FXUCC0049 : FXUCC0053, msgLabel1, msgLabel2,
				guiIdx + 1);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0050
	 */
	public static MCMessage msgTooManyInputs(String msgLabel) {
		return me()._msgTooManyInputs(msgLabel);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param msgLabel 項目名
	 * @return FXUCC0050
	 */
	protected MCMessage _msgTooManyInputs(String msgLabel) {
		return new MCMessage(FXUCC0050, msgLabel);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0051
	 */
	public static MCMessage msgTooManyInputs(String msgLabel, int guiIdx) {
		return me()._msgTooManyInputs(msgLabel, guiIdx);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0051
	 */
	protected MCMessage _msgTooManyInputs(String msgLabel, int guiIdx) {
		return new MCMessage(FXUCC0051, guiIdx + 1, msgLabel);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @return FXUCC0050
	 */
	public static MCMessage msgTooManyInputs(MCRow causeRow, String causeCol,
			String msgLabel) {
		return me()._msgTooManyInputs(causeRow, causeCol, msgLabel);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @return FXUCC0050
	 */
	protected MCMessage _msgTooManyInputs(MCRow causeRow, String causeCol, String msgLabel) {
		return new MCMessage(causeRow, causeCol, FXUCC0050, msgLabel);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0051
	 */
	public static MCMessage msgTooManyInputs(MCRow causeRow, String causeCol,
			String msgLabel, int guiIdx) {
		return me()._msgTooManyInputs(causeRow, causeCol, msgLabel, guiIdx);
	}

	/**
	 * 複数の項目に値が入力されていたときのエラーメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param causeCol 関連するRowのカラム名
	 * @param msgLabel 項目名
	 * @param guiIdx 行数。guiIndx+1がメッセージに設定される
	 * @return FXUCC0051
	 */
	protected MCMessage _msgTooManyInputs(MCRow causeRow, String causeCol,
			String msgLabel, int guiIdx) {
		return new MCMessage(causeRow, causeCol, FXUCC0051, guiIdx + 1, msgLabel);
	}

	// ----- 各種メッセージ END ---------------
}
