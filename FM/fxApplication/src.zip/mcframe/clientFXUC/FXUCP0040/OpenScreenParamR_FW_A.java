package mcframe.clientFXUC.FXUCP0040;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"OpenScreenParam"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class OpenScreenParamR_FW_A extends MCConstRow {

	/**
	 *  起動元項目キー.<p>
	 *
	 */
	public static final String $base_param_key = "base_param_key";
	/**
	 *  項目キー.<p>
	 *
	 */
	public static final String $open_param_key = "open_param_key";
	/**
	 *  バインド行かどうか.<p>
	 *
	 */
	public static final String $is_bind = "is_bind";
	/**
	 *  データ型.<p>
	 *
	 */
	public static final String $type = "type";
	/**
	 *  識別キー.<p>
	 *
	 */
	public static final String $to_key = "to_key";
	/**
	 *  枠・種類.<p>
	 *
	 */
	public static final String $to_panel = "to_panel";
	/**
	 *  名称.<p>
	 *
	 */
	public static final String $to_name = "to_name";
	/**
	 *  枠名.<p>
	 *
	 */
	public static final String $from_panel = "from_panel";
	/**
	 *  名称.<p>
	 *
	 */
	public static final String $from_name = "from_name";
	/**
	 *  識別キー.<p>
	 *
	 */
	public static final String $from_key = "from_key";
	/**
	 *  テキスト.<p>
	 *
	 */
	public static final String $text = "text";
	/**
	 *  チェックボックス.<p>
	 *
	 */
	public static final String $check = "check";
	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public static final String $radio = "radio";
	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public static final String $radio_nm = "radio_nm";
	/**
	 *  日付（今日）.<p>
	 *
	 */
	public static final String $today_flg = "today_flg";
	/**
	 *  日付（月初）.<p>
	 *
	 */
	public static final String $firstday_flg = "firstday_flg";
	/**
	 *  日付（月末）.<p>
	 *
	 */
	public static final String $lastday_flg = "lastday_flg";
	/**
	 *  日付（固定値）.<p>
	 *
	 */
	public static final String $date = "date";
	/**
	 *  差分（月）.<p>
	 *
	 */
	public static final String $month = "month";
	/**
	 *  差分（週）.<p>
	 *
	 */
	public static final String $week = "week";
	/**
	 *  曜日.<p>
	 *
	 */
	public static final String $day_of_week_type = "day_of_week_type";
	/**
	 *  曜日名.<p>
	 *
	 */
	public static final String $day_of_week_type_nm = "day_of_week_type_nm";
	/**
	 *  差分（日）.<p>
	 *
	 */
	public static final String $day = "day";
	/**
	 *  差分（時）.<p>
	 *
	 */
	public static final String $hour = "hour";
	/**
	 *  差分（分）.<p>
	 *
	 */
	public static final String $minute = "minute";
	/**
	 *  数値.<p>
	 *
	 */
	public static final String $num = "num";


	public static final MCMeta base_param_key_META = createStringMeta($base_param_key);
	public static final MCMeta open_param_key_META = createStringMeta($open_param_key);
	public static final MCMeta is_bind_META = createBooleanMeta($is_bind);
	public static final MCMeta type_META = createStringMeta($type);
	public static final MCMeta to_key_META = createStringMeta($to_key);
	public static final MCMeta to_panel_META = createStringMeta($to_panel);
	public static final MCMeta to_name_META = createStringMeta($to_name);
	public static final MCMeta from_panel_META = createStringMeta($from_panel);
	public static final MCMeta from_name_META = createStringMeta($from_name);
	public static final MCMeta from_key_META = createStringMeta($from_key);
	public static final MCMeta text_META = createStringMeta($text, 900);
	public static final MCMeta check_META = createBooleanMeta($check);
	public static final MCMeta radio_META = createStringMeta($radio);
	public static final MCMeta radio_nm_META = createStringMeta($radio_nm);
	public static final MCMeta today_flg_META = createBooleanMeta($today_flg);
	public static final MCMeta firstday_flg_META = createBooleanMeta($firstday_flg);
	public static final MCMeta lastday_flg_META = createBooleanMeta($lastday_flg);
	public static final MCMeta date_META = createTimestampMeta($date);
	public static final MCMeta month_META = createNumberMeta($month);
	public static final MCMeta week_META = createNumberMeta($week);
	public static final MCMeta day_of_week_type_META = createStringMeta($day_of_week_type);
	public static final MCMeta day_of_week_type_nm_META = createStringMeta($day_of_week_type_nm);
	public static final MCMeta day_META = createNumberMeta($day);
	public static final MCMeta hour_META = createNumberMeta($hour);
	public static final MCMeta minute_META = createNumberMeta($minute);
	public static final MCMeta num_META = createNumberMeta($num);

	protected static final ConstMetaList<OpenScreenParamR> constMetas = new ConstMetaList<OpenScreenParamR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			base_param_key_META,
			open_param_key_META,
			is_bind_META,
			type_META,
			to_key_META,
			to_panel_META,
			to_name_META,
			from_panel_META,
			from_name_META,
			from_key_META,
			text_META,
			check_META,
			radio_META,
			radio_nm_META,
			today_flg_META,
			firstday_flg_META,
			lastday_flg_META,
			date_META,
			month_META,
			week_META,
			day_of_week_type_META,
			day_of_week_type_nm_META,
			day_META,
			hour_META,
			minute_META,
			num_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected OpenScreenParamR_FW_A(ConstMetaList<? extends OpenScreenParamR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OpenScreenParamR clone() {
		return (OpenScreenParamR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OpenScreenParamR createInstance() {
		return (OpenScreenParamR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OpenScreenParamR getValues(String... names) {
		return (OpenScreenParamR) super.getValues(names);
	}



	/**
	 *  起動元項目キー.<p>
	 *
	 */
	public String base_param_key() {
		return getConstString(offset + 0, $base_param_key);
	}

	/**
	 *  起動元項目キー.<p>
	 *
	 */
	public void base_param_key(String value) {
		setConstString(offset + 0, $base_param_key, value);
	}


	/**
	 *  項目キー.<p>
	 *
	 */
	public String open_param_key() {
		return getConstString(offset + 1, $open_param_key);
	}

	/**
	 *  項目キー.<p>
	 *
	 */
	public void open_param_key(String value) {
		setConstString(offset + 1, $open_param_key, value);
	}


	/**
	 *  バインド行かどうか.<p>
	 *
	 */
	public boolean is_bind() {
		return getConstBoolean(offset + 2, $is_bind);
	}

	/**
	 *  バインド行かどうか.<p>
	 *
	 */
	public void is_bind(boolean value) {
		setConstBoolean(offset + 2, $is_bind, value);
	}


	/**
	 *  データ型.<p>
	 *
	 */
	public String type() {
		return getConstString(offset + 3, $type);
	}

	/**
	 *  データ型.<p>
	 *
	 */
	public void type(String value) {
		setConstString(offset + 3, $type, value);
	}


	/**
	 *  識別キー.<p>
	 *
	 */
	public String to_key() {
		return getConstString(offset + 4, $to_key);
	}

	/**
	 *  識別キー.<p>
	 *
	 */
	public void to_key(String value) {
		setConstString(offset + 4, $to_key, value);
	}


	/**
	 *  枠・種類.<p>
	 *
	 */
	public String to_panel() {
		return getConstString(offset + 5, $to_panel);
	}

	/**
	 *  枠・種類.<p>
	 *
	 */
	public void to_panel(String value) {
		setConstString(offset + 5, $to_panel, value);
	}


	/**
	 *  名称.<p>
	 *
	 */
	public String to_name() {
		return getConstString(offset + 6, $to_name);
	}

	/**
	 *  名称.<p>
	 *
	 */
	public void to_name(String value) {
		setConstString(offset + 6, $to_name, value);
	}


	/**
	 *  枠名.<p>
	 *
	 */
	public String from_panel() {
		return getConstString(offset + 7, $from_panel);
	}

	/**
	 *  枠名.<p>
	 *
	 */
	public void from_panel(String value) {
		setConstString(offset + 7, $from_panel, value);
	}


	/**
	 *  名称.<p>
	 *
	 */
	public String from_name() {
		return getConstString(offset + 8, $from_name);
	}

	/**
	 *  名称.<p>
	 *
	 */
	public void from_name(String value) {
		setConstString(offset + 8, $from_name, value);
	}


	/**
	 *  識別キー.<p>
	 *
	 */
	public String from_key() {
		return getConstString(offset + 9, $from_key);
	}

	/**
	 *  識別キー.<p>
	 *
	 */
	public void from_key(String value) {
		setConstString(offset + 9, $from_key, value);
	}


	/**
	 *  テキスト.<p>
	 *
	 */
	public String text() {
		return getConstString(offset + 10, $text);
	}

	/**
	 *  テキスト.<p>
	 *
	 */
	public void text(String value) {
		setConstString(offset + 10, $text, value);
	}


	/**
	 *  チェックボックス.<p>
	 *
	 */
	public boolean check() {
		return getConstBoolean(offset + 11, $check);
	}

	/**
	 *  チェックボックス.<p>
	 *
	 */
	public void check(boolean value) {
		setConstBoolean(offset + 11, $check, value);
	}


	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public String radio() {
		return getConstString(offset + 12, $radio);
	}

	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public void radio(String value) {
		setConstString(offset + 12, $radio, value);
	}


	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public String radio_nm() {
		return getConstString(offset + 13, $radio_nm);
	}

	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public void radio_nm(String value) {
		setConstString(offset + 13, $radio_nm, value);
	}


	/**
	 *  日付（今日）.<p>
	 *
	 */
	public boolean today_flg() {
		return getConstBoolean(offset + 14, $today_flg);
	}

	/**
	 *  日付（今日）.<p>
	 *
	 */
	public void today_flg(boolean value) {
		setConstBoolean(offset + 14, $today_flg, value);
	}


	/**
	 *  日付（月初）.<p>
	 *
	 */
	public boolean firstday_flg() {
		return getConstBoolean(offset + 15, $firstday_flg);
	}

	/**
	 *  日付（月初）.<p>
	 *
	 */
	public void firstday_flg(boolean value) {
		setConstBoolean(offset + 15, $firstday_flg, value);
	}


	/**
	 *  日付（月末）.<p>
	 *
	 */
	public boolean lastday_flg() {
		return getConstBoolean(offset + 16, $lastday_flg);
	}

	/**
	 *  日付（月末）.<p>
	 *
	 */
	public void lastday_flg(boolean value) {
		setConstBoolean(offset + 16, $lastday_flg, value);
	}


	/**
	 *  日付（固定値）.<p>
	 *
	 */
	public MCTimestamp date() {
		return getConstTimestamp(offset + 17, $date);
	}

	/**
	 *  日付（固定値）.<p>
	 *
	 */
	public void date(MCTimestamp value) {
		setConstTimestamp(offset + 17, $date, value);
	}


	/**
	 *  差分（月）.<p>
	 *
	 */
	public MCNumber month() {
		return getConstNumber(offset + 18, $month);
	}

	/**
	 *  差分（月）.<p>
	 *
	 */
	public void month(MCNumber value) {
		setConstNumber(offset + 18, $month, value);
	}

	/**
	 *  差分（月）.<p>
	 *
	 */
	public void month(int value) {
		setConstNumber(offset + 18, $month, value);
	}

	/**
	 *  差分（月）.<p>
	 *
	 */
	public void month(long value) {
		setConstNumber(offset + 18, $month, value);
	}

	/**
	 *  差分（月）.<p>
	 *
	 */
	public void month(float value) {
		setConstNumber(offset + 18, $month, value);
	}

	/**
	 *  差分（月）.<p>
	 *
	 */
	public void month(double value) {
		setConstNumber(offset + 18, $month, value);
	}


	/**
	 *  差分（週）.<p>
	 *
	 */
	public MCNumber week() {
		return getConstNumber(offset + 19, $week);
	}

	/**
	 *  差分（週）.<p>
	 *
	 */
	public void week(MCNumber value) {
		setConstNumber(offset + 19, $week, value);
	}

	/**
	 *  差分（週）.<p>
	 *
	 */
	public void week(int value) {
		setConstNumber(offset + 19, $week, value);
	}

	/**
	 *  差分（週）.<p>
	 *
	 */
	public void week(long value) {
		setConstNumber(offset + 19, $week, value);
	}

	/**
	 *  差分（週）.<p>
	 *
	 */
	public void week(float value) {
		setConstNumber(offset + 19, $week, value);
	}

	/**
	 *  差分（週）.<p>
	 *
	 */
	public void week(double value) {
		setConstNumber(offset + 19, $week, value);
	}


	/**
	 *  曜日.<p>
	 *
	 */
	public String day_of_week_type() {
		return getConstString(offset + 20, $day_of_week_type);
	}

	/**
	 *  曜日.<p>
	 *
	 */
	public void day_of_week_type(String value) {
		setConstString(offset + 20, $day_of_week_type, value);
	}


	/**
	 *  曜日名.<p>
	 *
	 */
	public String day_of_week_type_nm() {
		return getConstString(offset + 21, $day_of_week_type_nm);
	}

	/**
	 *  曜日名.<p>
	 *
	 */
	public void day_of_week_type_nm(String value) {
		setConstString(offset + 21, $day_of_week_type_nm, value);
	}


	/**
	 *  差分（日）.<p>
	 *
	 */
	public MCNumber day() {
		return getConstNumber(offset + 22, $day);
	}

	/**
	 *  差分（日）.<p>
	 *
	 */
	public void day(MCNumber value) {
		setConstNumber(offset + 22, $day, value);
	}

	/**
	 *  差分（日）.<p>
	 *
	 */
	public void day(int value) {
		setConstNumber(offset + 22, $day, value);
	}

	/**
	 *  差分（日）.<p>
	 *
	 */
	public void day(long value) {
		setConstNumber(offset + 22, $day, value);
	}

	/**
	 *  差分（日）.<p>
	 *
	 */
	public void day(float value) {
		setConstNumber(offset + 22, $day, value);
	}

	/**
	 *  差分（日）.<p>
	 *
	 */
	public void day(double value) {
		setConstNumber(offset + 22, $day, value);
	}


	/**
	 *  差分（時）.<p>
	 *
	 */
	public MCNumber hour() {
		return getConstNumber(offset + 23, $hour);
	}

	/**
	 *  差分（時）.<p>
	 *
	 */
	public void hour(MCNumber value) {
		setConstNumber(offset + 23, $hour, value);
	}

	/**
	 *  差分（時）.<p>
	 *
	 */
	public void hour(int value) {
		setConstNumber(offset + 23, $hour, value);
	}

	/**
	 *  差分（時）.<p>
	 *
	 */
	public void hour(long value) {
		setConstNumber(offset + 23, $hour, value);
	}

	/**
	 *  差分（時）.<p>
	 *
	 */
	public void hour(float value) {
		setConstNumber(offset + 23, $hour, value);
	}

	/**
	 *  差分（時）.<p>
	 *
	 */
	public void hour(double value) {
		setConstNumber(offset + 23, $hour, value);
	}


	/**
	 *  差分（分）.<p>
	 *
	 */
	public MCNumber minute() {
		return getConstNumber(offset + 24, $minute);
	}

	/**
	 *  差分（分）.<p>
	 *
	 */
	public void minute(MCNumber value) {
		setConstNumber(offset + 24, $minute, value);
	}

	/**
	 *  差分（分）.<p>
	 *
	 */
	public void minute(int value) {
		setConstNumber(offset + 24, $minute, value);
	}

	/**
	 *  差分（分）.<p>
	 *
	 */
	public void minute(long value) {
		setConstNumber(offset + 24, $minute, value);
	}

	/**
	 *  差分（分）.<p>
	 *
	 */
	public void minute(float value) {
		setConstNumber(offset + 24, $minute, value);
	}

	/**
	 *  差分（分）.<p>
	 *
	 */
	public void minute(double value) {
		setConstNumber(offset + 24, $minute, value);
	}


	/**
	 *  数値.<p>
	 *
	 */
	public MCNumber num() {
		return getConstNumber(offset + 25, $num);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(MCNumber value) {
		setConstNumber(offset + 25, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(int value) {
		setConstNumber(offset + 25, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(long value) {
		setConstNumber(offset + 25, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(float value) {
		setConstNumber(offset + 25, $num, value);
	}

	/**
	 *  数値.<p>
	 *
	 */
	public void num(double value) {
		setConstNumber(offset + 25, $num, value);
	}


	public String getString(String name) {
		if ($base_param_key.equalsIgnoreCase(name)) {
			return base_param_key();
		}
		if ($open_param_key.equalsIgnoreCase(name)) {
			return open_param_key();
		}
		if ($type.equalsIgnoreCase(name)) {
			return type();
		}
		if ($to_key.equalsIgnoreCase(name)) {
			return to_key();
		}
		if ($to_panel.equalsIgnoreCase(name)) {
			return to_panel();
		}
		if ($to_name.equalsIgnoreCase(name)) {
			return to_name();
		}
		if ($from_panel.equalsIgnoreCase(name)) {
			return from_panel();
		}
		if ($from_name.equalsIgnoreCase(name)) {
			return from_name();
		}
		if ($from_key.equalsIgnoreCase(name)) {
			return from_key();
		}
		if ($text.equalsIgnoreCase(name)) {
			return text();
		}
		if ($radio.equalsIgnoreCase(name)) {
			return radio();
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			return radio_nm();
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			return day_of_week_type();
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			return day_of_week_type_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($week.equalsIgnoreCase(name)) {
			return week();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		if ($is_bind.equalsIgnoreCase(name)) {
			return is_bind();
		}
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			return today_flg();
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			return firstday_flg();
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			return lastday_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($base_param_key.equalsIgnoreCase(name)) {
			return base_param_key();
		}
		if ($open_param_key.equalsIgnoreCase(name)) {
			return open_param_key();
		}
		if ($type.equalsIgnoreCase(name)) {
			return type();
		}
		if ($to_key.equalsIgnoreCase(name)) {
			return to_key();
		}
		if ($to_panel.equalsIgnoreCase(name)) {
			return to_panel();
		}
		if ($to_name.equalsIgnoreCase(name)) {
			return to_name();
		}
		if ($from_panel.equalsIgnoreCase(name)) {
			return from_panel();
		}
		if ($from_name.equalsIgnoreCase(name)) {
			return from_name();
		}
		if ($from_key.equalsIgnoreCase(name)) {
			return from_key();
		}
		if ($text.equalsIgnoreCase(name)) {
			return text();
		}
		if ($radio.equalsIgnoreCase(name)) {
			return radio();
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			return radio_nm();
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			return day_of_week_type();
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			return day_of_week_type_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($week.equalsIgnoreCase(name)) {
			return week();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($is_bind.equalsIgnoreCase(name)) {
			return is_bind();
		}
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			return today_flg();
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			return firstday_flg();
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			return lastday_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($base_param_key.equalsIgnoreCase(name)) {
			base_param_key(value);
			return;
		}
		if ($open_param_key.equalsIgnoreCase(name)) {
			open_param_key(value);
			return;
		}
		if ($type.equalsIgnoreCase(name)) {
			type(value);
			return;
		}
		if ($to_key.equalsIgnoreCase(name)) {
			to_key(value);
			return;
		}
		if ($to_panel.equalsIgnoreCase(name)) {
			to_panel(value);
			return;
		}
		if ($to_name.equalsIgnoreCase(name)) {
			to_name(value);
			return;
		}
		if ($from_panel.equalsIgnoreCase(name)) {
			from_panel(value);
			return;
		}
		if ($from_name.equalsIgnoreCase(name)) {
			from_name(value);
			return;
		}
		if ($from_key.equalsIgnoreCase(name)) {
			from_key(value);
			return;
		}
		if ($text.equalsIgnoreCase(name)) {
			text(value);
			return;
		}
		if ($radio.equalsIgnoreCase(name)) {
			radio(value);
			return;
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			radio_nm(value);
			return;
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			day_of_week_type(value);
			return;
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			day_of_week_type_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($is_bind.equalsIgnoreCase(name)) {
			is_bind(value);
			return;
		}
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			today_flg(value);
			return;
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			firstday_flg(value);
			return;
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			lastday_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($base_param_key.equalsIgnoreCase(name)) {
			base_param_key(value);
			return;
		}
		if ($open_param_key.equalsIgnoreCase(name)) {
			open_param_key(value);
			return;
		}
		if ($type.equalsIgnoreCase(name)) {
			type(value);
			return;
		}
		if ($to_key.equalsIgnoreCase(name)) {
			to_key(value);
			return;
		}
		if ($to_panel.equalsIgnoreCase(name)) {
			to_panel(value);
			return;
		}
		if ($to_name.equalsIgnoreCase(name)) {
			to_name(value);
			return;
		}
		if ($from_panel.equalsIgnoreCase(name)) {
			from_panel(value);
			return;
		}
		if ($from_name.equalsIgnoreCase(name)) {
			from_name(value);
			return;
		}
		if ($from_key.equalsIgnoreCase(name)) {
			from_key(value);
			return;
		}
		if ($text.equalsIgnoreCase(name)) {
			text(value);
			return;
		}
		if ($radio.equalsIgnoreCase(name)) {
			radio(value);
			return;
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			radio_nm(value);
			return;
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			day_of_week_type(value);
			return;
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			day_of_week_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($is_bind.equalsIgnoreCase(name)) {
			is_bind(value);
			return;
		}
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			today_flg(value);
			return;
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			firstday_flg(value);
			return;
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			lastday_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

