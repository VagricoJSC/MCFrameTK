package mcframe.clientFXUC.FXUCP0040;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.clientCore.beans.resource.MCPersonalizeResourceIO.toResourceLayerType;
import static mcframe.clientCore.beans.resource.MCPersonalizeResourceIO.saveResource;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import static mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil.adjustValueByCalenderFormat;
import static mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil.getMacroString;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BoxLayout;

import mcframe.clientCore.beans.plaf.metal.MCTheme;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.MCConfig;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
import mcframe.clientCore.sys.MCSys;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase_FW;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXUC.FXUCP0030.IfToolbarBeansHolder;
import mcframe.clientFXUC.FXUCP0200.FXUCP_AppScreenOpener;
import mcframe.commonCore.sys.MCClientOperation;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
//import mcframe.commonCore.sys.MCFactory;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_ToolBarUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_ToolBarUtil_FW extends FXUCP_ToolBarUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 連携先の入力値設定情報を表す定数です。
	 */
	public static final String SRCH_CND_KEY = "$srch_cnd$";

	/**
	 * 連携先の起動区分を表す定数です。
	 */
	public static final String OPN_TYP_KEY = "$opn_typ$";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_ToolBarUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXUCP_ToolBarUtil_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Robot]のボタン[play_s_list]の押下時の処理
	 */
	@Override
	public void doRobot_play_s_list(MCEventInfo info) {
	}
	/**
	 * Panel[Scenario]のボタン[s_test]の押下時の処理
	 */
	@Override
	public void doScenario_s_test(MCEventInfo info) {
	}
	/**
	 * Panel[Dev]のボタン[test_assistance]の押下時の処理
	 */
	@Override
	public void doDev_test_assistance(MCEventInfo info) {
	}
	/**
	 * Panel[Btn]のボタン[barcode]の押下時の処理
	 */
	@Override
	public void doBtn_barcode(MCEventInfo info) {
	}
	/**
	 * Panel[Btn]のボタン[b_flow]の押下時の処理
	 */
	@Override
	public void doBtn_b_flow(MCEventInfo info) {
	}
	/**
	 * Panel[Btn]のボタン[move_xy]の押下時の処理
	 */
	@Override
	public void doBtn_move_xy(MCEventInfo info) {
	}
	/**
	 * Panel[Btn]のボタン[graph]の押下時の処理
	 */
	@Override
	public void doBtn_graph(MCEventInfo info) {
	}
	/**
	 * Panel[Btn]のボタン[screen_switch]の押下時の処理
	 */
	@Override
	public void doBtn_screen_switch(MCEventInfo info) {
	}
	/**
	 * Panel[Dev]のボタン[s_invisible]の押下時の処理
	 */
	@Override
	public void doDev_s_invisible(MCEventInfo info) {
	}
	// ユーティリティ（ここから）
	/** 正規表現の中で正規表現のルールを使わない箇所の始まり */
	protected final String SKIP_REGEX_ST = "\\Q";

	/** 正規表現の中で正規表現のルールを使わない箇所の終わり */
	protected final String SKIP_REGEX_END = "\\E";

	/**
	 * 指定された予約語をデータに置き換える
	 * <P>
	 * 事前条件
	 * <li> src != null</li>
	 * <li> p != null</li>
	 * </P>
	 *
	 * @author    h-kawada
	 * @since     7.0.2
	 * @param src 置換元の文字列
	 * @param panel ツールバーをもつ画面
	 * @return 置換後の文字列
	 */
	public static String convStr(String src, FXBAP_PanelBase panel) {
		return getBarInst(panel).convStr(src, (MCRootPanel) panel);
	}

	/**
	 * 指定された予約語をデータに置き換える
	 * <P>
	 * 事前条件
	 * <li> src != null</li>
	 * <li> p != null</li>
	 * </P>
	 */
	protected String convStr(String src, MCRootPanel p) {
		String dest = src;
		MCDate dt = new MCDate();
		String[][] convStr = new String[][] {
				{
						"{yyyy}", dt.toString("yyyy")
				}, {
						"{MM}", dt.toString("MM")
				}, {
						"{dd}", dt.toString("dd")
				}, {
						"{HH}", dt.toString("HH")
				}, {
						"{mm}", dt.toString("mm")
				}, {
						"{ss}", dt.toString("ss")
				}, {
						"{SSS}", dt.toString("SSS")
				}, {
						"{USER}", MCSys.user.ID()
				}, {
						"{clientID}", MCSys.user.clientID()
				}, {
						"{moduleID}", p == null ? "" : p.getModuleID()
				}, {
						"{submoduleID}", p == null ? "" : p.getSubmoduleID()
				}, {
						"{screenID}", p == null ? "" : p.getScreenID()
				}, {
						"{MCF_HOME}", MCSys.env.MCF_HOME()
				}, {
						"{LOCALE}", MCSys.user.locale().toString()
				}
		};
		for (String[] s : convStr) {
			dest = dest.replaceAll(SKIP_REGEX_ST + s[0] + SKIP_REGEX_END, s[1]);
		}

		// ClientConfigのリソースをバインド変数に展開
		dest = MCStringUtil.bind(dest, MCConfig.client.bindsrc);

		return dest;
	}

	// ユーティリティ（ここまで）
	// Toolbarの情報保持用（ここから）
	public static IfToolbarBeansHolder createBeansHolder(Component comp, int order,
			boolean ignore) {
		return _me._createBeansHolder(comp, order, ignore);

	}

	protected IfToolbarBeansHolder _createBeansHolder(Component comp, int order,
			boolean ignore) {
		ToolbarComponentHolder ret = new ToolbarComponentHolder();
		ret.comp(comp);
		ret.order(order);
		ret.isIgnore(ignore);
		return ret;
	}

	public static IfToolbarBeansHolder createBeansHolder() {
		return _me._createBeansHolder();

	}

	protected IfToolbarBeansHolder _createBeansHolder() {
		ToolbarComponentHolder ret = new ToolbarComponentHolder();
		return ret;
	}

	/**
	 * ツールバーに表示する物の情報を保持する
	 */
	public class ToolbarComponentHolder implements IfToolbarBeansHolder {
		/**
		 * ツールバーに表示するコンポーネント
		 */
		protected Component _comp;

		/**
		 * ツールバーに表示するコンポーネント
		 */
		@Override
		public Component comp() {
			return _comp;
		}

		/**
		 * ツールバーに表示するコンポーネント
		 */
		@Override
		public void comp(Component comp) {
			_comp = comp;
		}

		/**
		 * 表示順
		 */
		protected int _order = 999999;

		/**
		 * 表示順
		 */
		@Override
		public int order() {
			return _order;
		}

		/**
		 * 表示順
		 */
		@Override
		public void order(int order) {
			_order = order;
		}

		/**
		 * 表示しない
		 */
		protected boolean _isIgnore = false;

		/**
		 * 表示しない
		 */
		@Override
		public boolean isIgnore() {
			return _isIgnore;
		}

		/**
		 * 表示しない
		 */
		@Override
		public void isIgnore(boolean isIgnore) {
			_isIgnore = isIgnore;
		}
	}

	// Toolbarの情報保持用（ここまで）

	/**
	 * Panel[Btn]のボタン[open_XUP0180]の押下時の処理
	 */
	@Override
	public void doBookmark_open_XUP0180(MCEventInfo info) {
		FXBAP_PanelBase p = btn2Panel().get(Bookmark_open_XUP0180);
		if (p != null) {
			p.openModalPanel("FS", "FSBAP0290", p.T1);
		}
	}

	/**
	 * Panel[Btn]のボタン[open_WBP0850]の押下時の処理
	 */
	@Override
	public void doBtn_open_WBP0850(MCEventInfo info) {
		FXBAP_PanelBase p = btn2Panel().get(Btn_open_WBP0850);
		if (p != null) {
			MCRootPanel memoPanel = p.createPanel("FS", "FSBAP0190", MCRootPanel.MODELESS);
			if (memoPanel instanceof MCMemoPanel) {
				MCMemoPanel m = (MCMemoPanel) memoPanel;
				m.setMemoKey(p.getModuleID(), p.getScreenID());
				m.setTargetName(p.getScreenID(), p.getScreenName());
				m.doSearchMemo();
				p.showChildPanel(memoPanel, MCRootPanel.SCREEN_SINGLE);
			}
		}
	}

	// イベント制御（ここから）
	/**
	 * Panel[Btn]のボタン[sclear]の押下時の処理
	 */
	@Override
	public void doBtn_sclear(MCEventInfo info) {
		FXBAP_PanelBase p = btn2Panel().get(Btn_sclear);
		if (p != null) {
			p.screenClear();
		}
	}

	/**
	 * Panel[Btn]のボタン[excel_out]の押下時の処理
	 */
	@Override
	public void doBtn_excel_out(MCEventInfo info) {
		FXBAP_PanelBase p = btn2Panel().get(Btn_excel_out);
		if (p == null) {
			return;
		}

		MCTextPopupMenuItem i = p.getExcelOutMenuItem();

		if (i.getRootPanel() == null) {
			p.configurePopup();
		}
		if (i.checkAC()) {
			try {
				MCBeansUtil.setClientOperationType(i, MCClientOperation.OPR_BUTTON);
				MCClientOperation o = MCBeansUtil.getClientOperation(i);
				if (o != null) {
					MCHistoryRegister.exec(o, i.getACType());
				}

				MCEventInfo e = i.getEventInfo();
				for (MCAPListener l : i.getAPListeners()) {
					l.doAPEvent(i, e);
				}

			}
			finally {
				MCBeansUtil.setClientOperation(i, null);
			}
		}
		else {
			dialog(FXUCP0028);
		}
	}

	/**
	 * Panel[Btn]のボタン[tbl_zoom]の押下時の処理
	 */
	@Override
	public void doBtn_tbl_zoom(MCEventInfo info) {
		FXBAP_PanelBase p = btn2Panel().get(Btn_tbl_zoom);
		if (p != null) {
			p.tableSizeChange();
		}
	}

	@Override
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap instanceof MCButton) {
			MCButton btn = (MCButton) ap;
			OpenScreenInfoR infoR = openScreenInfoMap().get(btn);
			MCList<OpenScreenParamR> paramL = openScreenParamMap().get(btn);
			if (infoR != null) {
				open(btn, infoR, paramL);
				return;
			}
		}
	}

	// イベント制御（ここまで）

	// 7012-2037 (メインメニューがメモリーリークする)
//	/**
//	 * ツールバーインスタンスのマップ
//	 */
// 	private static final Map<MCRootPanel, FXUCP_ToolBarUtil> _barInstMap = new HashMap<MCRootPanel, FXUCP_ToolBarUtil>();

	/**
	 * panelに対応するツールバーインスタンスを返す。
	 *
	 * @param panel
	 * @return
	 */
	protected static FXUCP_ToolBarUtil getBarInst(FXBAP_PanelBase_FW panel) {
		// メモリーリークのの発生を抑制するためstatic変数を廃止
		FXUCP_ToolBarUtil inst = ((FXBAP_PanelBase)panel)._getToolBarUtil();
		if (inst == null) {
			inst = new FXUCP_ToolBarUtil();
			((FXBAP_PanelBase)panel)._setToolBarUtil(inst);
			inst.jbInit();
			inst.mcInit();
		}
		return inst;

//		FXUCP_ToolBarUtil inst = _barInstMap.get(panel);
//		if (inst == null) {
//			inst = new FXUCP_ToolBarUtil();
//			_barInstMap.put(panel, inst);
//			inst.jbInit();
//			inst.mcInit();
//		}
//		return inst;
	}
	// 7012-2037 ここまで

	/**
	 * panelに対応するツールバーインスタンスを削除します。
	 *
	 * @param panel
	 */
	// 7012-2037 (メインメニューがメモリーリークする)
	public static void removeBarInst(FXBAP_PanelBase_FW panel) {
		// panelをstatic変数に格納するのをやめる。
		((FXBAP_PanelBase)panel)._setToolBarUtil(null);
//		_barInstMap.remove(panel);
	}
	// 7012-2037 ここまで

	// ユーティリティ（ここから）
	private Map<MCButton, FXBAP_PanelBase> _btn2Panel;

	protected Map<MCButton, FXBAP_PanelBase> btn2Panel() {
		if (_btn2Panel == null) {
			_btn2Panel = new HashMap<MCButton, FXBAP_PanelBase>();
		}
		return _btn2Panel;
	}

	protected String createBtnName(MCRootPanel panel, String btnName) {
		return panel.getClass().getName() + "." + this.getClass().getName() + "."
				+ btnName;
	}

	// ユーティリティ（ここまで）
	// ボタンの定義（ここから）
	// commandボタン（ここから）
	/**
	 * コマンド実行ボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param command 実行するコマンド
	 * @param iconName アイコンの名称
	 * @param msg メッセージ用名称（ツールチップ）
	 * @param label ラベル
	 */
	public static MCButton createCommandBtn(FXBAP_PanelBase panel, String objName,
			String command, String iconName, String msg, String label) {
		return getBarInst(panel)._createCommandBtn(panel, objName, command, iconName,
				msg, label);
	}

	protected int _webLinkBtnCounter = 0;

	/**
	 * コマンド実行ボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	protected MCButton _createCommandBtn(FXBAP_PanelBase panel, String objName,
			String command, String iconName, String msg, String label) {
		MCButton btn = new MCButton("toolbar_" + objName, MCTheme.BUTTON_TOOLBAR);

		// マルチプラットフォームを考えるとファクトリにすべき
		ExecProcessForWin listener = new ExecProcessForWin();

		String convertedCmd;
		if (isNull(command)) {
			convertedCmd = "";
		}
		else {
			convertedCmd = convStr(command, panel);
		}

		listener.cmd(convertedCmd);

		btn.addAPListener(listener);

		if (iconName != null) {
			btn.setIcon(iconName);
		}
		if (msg != null) {
			String convertedMsg = convStr(msg, panel);
			btn.setToolTipText(convertedMsg);
		}

		btn.updateResource();

		prefBtnWidth(btn);
		btn.initialized();

		return btn;
	}

	protected void prefBtnWidth(MCButton btn) {
		  btn.setPreferredSize(null);
		  int nw = btn.getPreferredSize().width;
		  if (nw < 22) {
			  nw = 22;
		  }
		  btn.setSize(nw, 22);
	}

	/**
	 * 外部プロセスを実行するための {@link MCAPListener}
	 */
	public class ExecProcessForWin implements MCAPListener {
		/**
		 * 実行するコマンド
		 */
		protected String _cmd;

		/**
		 * 実行するコマンド
		 */
		protected String cmd() {
			return _cmd;
		}

		/**
		 * 実行するコマンドをセットする
		 */
		public void cmd(String cmd) {
			_cmd = cmd;
		}

		// MCAPListener の実装
		@Override
		public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
			String cmd = cmd();
			if (cmd == null || "".equals(cmd)) {
				throw new MCAppException(FXUCP0027);
			}
			String start = "cmd.exe /c start";
			String execCmd = start + " \"\" " + _cmd;

			MCLog.write(new MCMessage(FXUCP0023, execCmd));

			try {
				Process process = Runtime.getRuntime().exec(execCmd);
				int exitvalue = process.waitFor();

				BufferedReader stdIn = new BufferedReader(new InputStreamReader(process
						.getInputStream()));
				String stdLine = null;
				StringBuilder stdInfo = new StringBuilder();
				while ((stdLine = stdIn.readLine()) != null) {
					stdInfo.append(stdLine + "\n");
				}
				MCLog.write(FXUCP0025, stdInfo.toString());

				if (0 != exitvalue) {
					BufferedReader errorIn = null;
					errorIn = new BufferedReader(new InputStreamReader(process
							.getErrorStream()));
					String errorline = null;
					StringBuilder errorInfo = new StringBuilder();
					while ((errorline = errorIn.readLine()) != null) {
						errorInfo.append(errorline + "\n");
					}

					throw new MCAppException(FXUCP0022, exitvalue, errorInfo.toString());
				}
				else {
					MCLog.write(FXUCP0024);
				}
			}
			catch (IOException e) {
				MCLog.write(e);
				throw new MCAppException(FXUCP0026);
			}
			catch (InterruptedException e) {
				MCLog.write(e);
				throw new MCAppException(FXUCP0026);
			}
		}
	}

	// commandボタン（ここまで）
	// フロー（ここから）
	/**
	 * フローボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createFlowBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createFlowBtn(panel);
	}

	protected MCButton _createFlowBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_b_flow, panel);
		Btn_b_flow.updateResource();
		return Btn_b_flow;
	}

	// フロー（ここまで）
	// バーコード（ここから）
		/**
		 * フローボタンを返します。
		 *
		 * @param panel ボタンを利用するベースパネルインスタンス
		 */
		public static MCButton createBarcodeBtn(FXBAP_PanelBase panel) {
			return getBarInst(panel)._createBarcodeBtn(panel);
		}

		protected MCButton _createBarcodeBtn(FXBAP_PanelBase panel) {
			btn2Panel().put(Btn_barcode, panel);
			Btn_barcode.updateResource();
			return Btn_barcode;
		}

		// バーコード（ここまで）
	// 項目移動（ここから）
	/**
	 * 項目移動ボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createMoveXYBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createMoveXYBtn(panel);
	}

	protected MCButton _createMoveXYBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_move_xy, panel);
		Btn_move_xy.updateResource();
		return Btn_move_xy;
	}

	// 項目移動（ここまで）

	// グラフ（ここから）
	/**
	 *　グラフボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createGraphBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createGraphBtn(panel);
	}

	protected MCButton _createGraphBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_graph, panel);
		Btn_graph.updateResource();
		return Btn_graph;
	}

	// グラフ（ここまで）

	// 画面設定グループ（ここから）
	/**
	 * 画面設定グループボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createPgBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createPgBtn(panel);
	}

	protected MCButton _createPgBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_screen_switch, panel);
		Btn_screen_switch.updateResource();
		return Btn_screen_switch;
	}

	// 画面設定グループ（ここまで）
	// テーブルサイズ変更ボタン（ここから）
	/**
	 * テーブルサイズ変更ボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createTblSizeChangeBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createTblSizeChangeBtn(panel);
	}

	protected MCButton _createTblSizeChangeBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_tbl_zoom, panel);
		Btn_tbl_zoom.updateResource();
		return Btn_tbl_zoom;
	}

	// テーブルサイズ変更ボタン（ここまで）
	// 画面クリアボタン（ここから）
	/**
	 * 画面クリアボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createSClearBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createSClearBtn(panel);
	}

	protected MCButton _createSClearBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_sclear, panel);
		Btn_sclear.updateResource();
		return Btn_sclear;
	}

	// 画面クリアボタン（ここまで）
	// エクセル出力（ここから）
	/**
	 * エクセル出力用ボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createExcelBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createExcelBtn(panel);
	}

	protected MCButton _createExcelBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_excel_out, panel);
		Btn_excel_out.updateResource();
		return Btn_excel_out;
	}

	// エクセル出力（ここまで）
	// メモ（ここから）
	/**
	 * メモ用ボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCButton createMemoBtn(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createMemoBtn(panel);
	}

	protected MCButton _createMemoBtn(FXBAP_PanelBase panel) {
		btn2Panel().put(Btn_open_WBP0850, panel);
		Btn_open_WBP0850.updateResource();
		return Btn_open_WBP0850;
	}

	// メモ（ここまで）

	// 画面起動設定画面起動（ここから）
	/**
	 * 画面起動設定画面起動枠を返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCPanel createScreenBookmarkSettingPanel(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createScreenBookmarkSettingPanel(panel);
	}

	protected MCPanel _createScreenBookmarkSettingPanel(FXBAP_PanelBase panel) {
		BookmarkPanel.isTabOrderChildPanel(true); // 7.0.1 サブパネルでのタブ順階層構造をフラットにする。
		BookmarkPanel.setLayout(new BoxLayout(BookmarkPanel, BoxLayout.PAGE_AXIS));
		btn2Panel().put(Bookmark_open_XUP0180, panel);
		return updateRes(BookmarkPanel);
	}

	// 画面起動設定画面起動（ここまで）

	// ロボット（ここから）
	/**
	 * シナリオ枠を返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCPanel createRobotPanel(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createRobotPanel(panel);
	}

	protected MCPanel _createRobotPanel(FXBAP_PanelBase panel) {
		RobotPanel.isTabOrderChildPanel(true); // 7.0.1 サブパネルでのタブ順階層構造をフラットにする。
		RobotPanel.setLayout(new BoxLayout(RobotPanel, BoxLayout.PAGE_AXIS));
		btn2Panel().put(Robot_play_s_list, panel);
		return updateRes(RobotPanel);
	}

	// ロボット（ここまで）

	// シナリオ（ここから）
	/**
	 * シナリオ枠を返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCPanel createScenarioPanel(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createScenarioPanel(panel);
	}

	protected MCPanel _createScenarioPanel(FXBAP_PanelBase panel) {
		ScenarioPanel.isTabOrderChildPanel(true); // 7.0.1 サブパネルでのタブ順階層構造をフラットにする。
		ScenarioPanel.setLayout(new BoxLayout(ScenarioPanel, BoxLayout.PAGE_AXIS));
		btn2Panel().put(Robot_play_s_list, panel);
		return updateRes(ScenarioPanel);
	}

	// シナリオ（ここまで）


	// 開発用（ここから）
	/**
	 * 開発用枠を返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 */
	public static MCPanel createDevPanel(FXBAP_PanelBase panel) {
		return getBarInst(panel)._createDevPanel(panel);
	}

	protected MCPanel _createDevPanel(FXBAP_PanelBase panel) {
		DevPanel.isTabOrderChildPanel(true); // 7.0.1 サブパネルでのタブ順階層構造をフラットにする。
		DevPanel.setLayout(new BoxLayout(DevPanel, BoxLayout.PAGE_AXIS));
		//ロボットは不要
//			btn2Panel().put(Dev_robot, panel);
		btn2Panel().put(Dev_s_invisible, panel);
		return updateRes(DevPanel);
	}

	protected MCPanel updateRes(MCPanel p) {
		for (MCButton b : MCBeansUtil.getAllComponents(MCButton.class, p)) {
			b.updateResource();
		}
		p.updateResource();
		p.setOpaque(false);
		p.setPreferredSize(null);
		return p;
	}
	// 開発用（ここまで）

	// 画面起動（ここから）
	/**
	 * 画面連携を行うためのボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param labelText ボタンのラベルになる文字列
	 * @param msgText ボタンのツールチップテキストに出てくる文字列
	 * @param module 起動する画面のモジュールＩＤ
	 * @param screen 起動する画面の画面ＩＤ
	 */
	public static MCButton createOpenScreenBtn(FXBAP_PanelBase panel, String labelText,
			String msgText, String module, String screen) {
		MCPanelType p = panel.getPanelType(module, screen);
		return getBarInst(panel)._createOpenScreenBtn(panel, labelText, msgText, module,
				screen, p);
	}

	/**
	 * 画面連携を行うためのボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param info 起動画面の情報
	 */
	public static MCButton createOpenScreenBtn(FXBAP_PanelBase panel, OpenScreenInfoR info) {
		return getBarInst(panel)._createOpenScreenBtn(panel, info);
	}

	/**
	 * 画面連携を行うためのボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param info 起動画面の情報
	 * @param params 起動画面に渡す値
	 */
	public static MCButton createOpenScreenBtn(FXBAP_PanelBase panel,
					OpenScreenInfoR info, MCList<OpenScreenParamR> params) {
		return getBarInst(panel)._createOpenScreenBtn(panel, info, params);
	}

	/**
	 * 画面連携を行うためのボタンを返します。
	 *
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param labelText ボタンのラベルになる文字列
	 * @param msgText ボタンのツールチップテキストに出てくる文字列
	 * @param module 起動する画面のモジュールＩＤ
	 * @param screen 起動する画面の画面ＩＤ
	 * @param panelTyp パネルの表示方法
	 */
	public static MCButton createOpenScreenBtn(FXBAP_PanelBase panel, String labelText,
			String msgText, String module, String screen, MCPanelType panelTyp) {
		return getBarInst(panel)._createOpenScreenBtn(panel, labelText, msgText, module,
				screen, panelTyp);
	}

	/**
	 * 画面連携ボタンの名称を作るために使用
	 */
	protected int _openScreenBtnCounter = 0;

	// カウンターリセット
	public static void resetOpenScreenBtnCounter(FXBAP_PanelBase panel) {
		getBarInst(panel)._openScreenBtnCounter = 0;
	}

	/**
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param labelText ボタンのラベルになる文字列
	 * @param msgText ボタンのツールチップテキストに出てくる文字列
	 * @param module 起動する画面のモジュールＩＤ
	 * @param screen 起動する画面の画面ＩＤ
	 * @param panelTyp パネルの表示方法
	 */
	protected MCButton _createOpenScreenBtn(FXBAP_PanelBase panel, String labelText,
			String msgText, String module, String screen, MCPanelType panelTyp) {
		OpenScreenInfoR info = createOpenScreenInfoR();
		info.base_module_id(panel.getModuleID());
		info.base_screen_id(panel.getScreenID());
		info.open_module_id(module);
		info.open_screen_id(screen);
		info.panel_typ(toString(panelTyp));
		info.msg_text(msgText);
		info.lbl_text(labelText);
		return _createOpenScreenBtn(panel, info);
	}

	/**
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param info 起動画面の情報
	 */
	protected MCButton _createOpenScreenBtn(FXBAP_PanelBase panel, OpenScreenInfoR info) {
		return _createOpenScreenBtn(panel, info, null);
	}

	public static final String BOOKMARK_OPEN_SCREEN_NM_PRF = "open_screen";
	/**
	 * @param panel ボタンを利用するベースパネルインスタンス
	 * @param info 起動画面の情報
	 * @param params 起動画面に渡す値
	 */
	protected MCButton _createOpenScreenBtn(FXBAP_PanelBase panel,
					OpenScreenInfoR info, MCList<OpenScreenParamR> params) {
		MCButton btn = new MCButton(BOOKMARK_OPEN_SCREEN_NM_PRF
				+ String.valueOf(_openScreenBtnCounter++), MCTheme.BUTTON_TOOLBAR);

		btn.setText(info.lbl_text());
		btn.setToolTipText(info.msg_text());
		btn.addAPListener(this);

		btn2Panel().put(btn, panel);

		openScreenInfoMap().put(btn, info);
		openScreenParamMap().put(btn, params);
		btn.updateResource();

		prefBtnWidth(btn);
		btn.initialized();

		return btn;
	}

	/** infoRを元に画面を起動します */
	protected void open(MCButton btn, OpenScreenInfoR info) {
		open(btn, info, null);
	}

	/** infoRを元に画面を起動します */
	protected void open(MCButton btn, OpenScreenInfoR info, MCList<OpenScreenParamR> params) {
		if (info == null) {
			return;
		}

		MCScreenOpener so = new MCScreenOpener(
								info.open_module_id(), info.open_screen_id());
		MCRootPanel topanel = so.getPanel();
		
		// 連携元の画面を取得する
		FXBAP_PanelBase basePanel = btn2Panel().get(btn);
		
		HashMap<String, MCRowBeans> k2b = new HashMap<>();
		MCRowBeans[] rbs = getSrchCndBeans((IfSrchCndBase) topanel);
		for (MCRowBeans rb : rbs) {
			String key = MCScreenOpener.createGUIKey(rb);
			k2b.put(key, rb);
		}
		// 連携項目
		Map<String, Comparable<?>> paramMap = new HashMap<String, Comparable<?>>();
		MCRow bind = MCRow.create();
		if (params != null && params.size() > 0) {
			Map<String, MCBeans> beanMap = getOpenScreenParamBeansMap(basePanel);
			for (int i = 0; i < params.size(); i++) {
				OpenScreenParamR param = params.get(i);
				MCBeans b = beanMap.get(param.base_param_key());
				if (b instanceof MCRowBeans) {
					Comparable<?> val = ((MCRowBeans) b).getRowValue();
					paramMap.put(param.open_param_key(), val);
				}
				else if (b instanceof MCColumnConfig) {
					MCColumnConfig col = (MCColumnConfig) b;
					MCTable<?> tbl = ((MCColumnConfig) b).getBaseTable();
					MCRow row = tbl.getSelectedMCRow();
					if (row != null) {
						// 行が選択されていれば連携する
						String colpath = col.getBaseRowColumnName();
						Comparable<?> val = row.getValue(colpath);
						paramMap.put(param.open_param_key(), val);
					}
				}
				else if (MCScreenOpener.PARAM_ACTION.equals(
												param.base_param_key())) {
					paramMap.put(MCScreenOpener.PARAM_ACTION,
												param.open_param_key());
				}
				else if (SRCH_CND_KEY.equals(param.base_param_key())) {
					paramMap.put(SRCH_CND_KEY,
							param.open_param_key());
				}
				else if (OPN_TYP_KEY.equals(param.base_param_key())) {
					paramMap.put(OPN_TYP_KEY,
							param.open_param_key());
				}
				//固定値
				else {
					MCRowBeans rb = k2b.get(param.open_param_key());
					Comparable<?> v = getFixedValue(topanel, rb, param);
					paramMap.put(param.open_param_key(), v);
				}
				//バインドRow作成
				if (param.is_bind()) {
					bind.setValueNE(
							param.open_param_key(),
							paramMap.get(param.open_param_key()));
					paramMap.remove(param.open_param_key());
				}
			}
		}

		// 画面を開く
		if (topanel instanceof FXBAP_PanelBase) {			
			String ot = (String)paramMap.get(OPN_TYP_KEY);
			if (!isNull(ot)) {
				so.setInitParameter(ot);
				so.setInitObjParameter(bind);
				paramMap.remove(OPN_TYP_KEY);
				
			}
		}
		so.setParameter(paramMap);
		try {
			// とりあえず現状は設定値を無視する
			//so.show(MCFrameType.MODELESS, toMCPanelType(info.panel_typ()));
			MCPanelType paneType = basePanel.getPanelType(
								info.open_module_id(), info.open_screen_id());
			so.show(MCFrameType.MODELESS, paneType);
		}
		catch (MCException ex) {
			// FCBAC0156[E]の代わりにFCBAC0376[W]がスローされるのでメッセージの
			// 変換は不要になったが、既存とメッセージを合わせるために変換する
			String id = ex.getID();
			if (isSame(FCBAC0376, id)) {
				// [FCBAC0376] 画面が見つからなかった場合
				throw new MCAppException(FXBAP0085, info.open_module_id(), info
						.open_screen_id());
			}
			throw ex;
		}
	}
	
	/**
	 * 画面の枠をキーに、対応した枠名を値に持つMapを生成します。
	 *
	 * 枠名がない枠には識別文字列を生成し値に設定します。
	 *
	 * @param rp 画面
	 * @return 生成したマップ
	 */
	public static Map<MCPanel, String> createPanelNameMap(MCRootPanel rp) {
		Map<MCPanel, String> map = new HashMap<MCPanel, String>();

		List<Object[]> list = MCBeansUtil.getPanelNameList(rp);
		int size = list.size();
		for (int i = 0, id = 1; i < size; i++) {
			Object[] w = list.get(i);
			if (w[2] == null) {
				if (!map.containsKey(w[1])) {
					map.put((MCPanel) w[1], "(" + id + ")");
					id++;
				}
			}
			else {
				map.put((MCPanel) w[1], (String) w[2]);
			}
		}
		return map;
	}
	protected Map<String, MCBeans> getOpenScreenParamBeansMap(FXBAP_PanelBase rp) {
		Map<String, MCBeans> map = new HashMap<String, MCBeans>();

		// 見出し
		MCRowBeans[] rbs = MCScreenOpener.getRowBeans(rp);
		for (MCRowBeans b : rbs) {
			// この判定はxAppsじゃないとできない
			if (b instanceof MCModeBeans &&
					isVisibleInBaseAllStatuses((MCModeBeans) b)) {
				String target = MCScreenOpener.createGUIKey(b);
				map.put(target, b);
			}
		}

		// テーブル
		MCFixedColumnTable<?>[] tbls = MCBeansUtil.getAllComponents(
												MCFixedColumnTable.class, rp);
		for (MCFixedColumnTable<?> tbl : tbls) {
			MCColumnConfig[] cols = tbl.getColumnConfigs();
			for (MCColumnConfig col : cols) {
				if (isVisibleInBaseAllStatuses(col)) {
					String target = MCScreenOpener.createGUIKey(col);
					map.put(target, col);
				}
			}
		}

		return map;
	}

	/**
	 * MCPanelTypeの文字列表現を返します。
	 * <P>
	 * このメソッドの戻り値は {@link #toMCPanelType(String)}でMCPanelTypeに戻すことが 可能です。
	 *
	 * @param t
	 * @return
	 */
	protected String toString(MCPanelType t) {
		return t.toString();
	}

	/**
	 * 文字列を {@link MCPanelType} に変換します。
	 * {@link MCPanelType} に変換できない文字列が指定された場合は null を返します。<p>
	 * このメソッドの引数には {@link #toString(MCPanelType)}
	 * で作成した文字列が指定されることを想定しています。
	 *
	 * @param type 文字列
	 * @return　{@link MCPanelType} または null
	 */
	protected MCPanelType toMCPanelType(String type) {
		for (MCPanelType t : MCPanelType.values()) {
			if (t.toString().equals(type)) {
				return t;
			}
		}
		return null;
	}

	/** 画面起動ボタンとその関連情報を保持するマップ */
	private Map<MCButton, OpenScreenInfoR> _openScreenInfoMap;

	/** 画面起動ボタンとその関連情報を保持するマップ */
	protected Map<MCButton, OpenScreenInfoR> openScreenInfoMap() {
		if (_openScreenInfoMap == null) {
			_openScreenInfoMap = new HashMap<MCButton, OpenScreenInfoR>();
		}
		return _openScreenInfoMap;
	}

	/** 画面起動ボタンとその関連情報を保持するマップ */
	private Map<MCButton, MCList<OpenScreenParamR>> _openScreenParamMap;

	/** 画面起動ボタンとその関連情報を保持するマップ */
	protected Map<MCButton, MCList<OpenScreenParamR>> openScreenParamMap() {
		if (_openScreenParamMap == null) {
			_openScreenParamMap = new HashMap<MCButton, MCList<OpenScreenParamR>>();
		}
		return _openScreenParamMap;
	}

	// 画面起動（ここまで）
	// ボタンの定義（ここまで）

	// 画面起動パーソナライズ情報の管理（共通）＜ここから＞
	public static final String OPEN_SCREEN = "OPEN_SCREEN";

	protected String createRootResourceKey(OpenScreenInfoR row) {
		return MCConst.createKey(OPEN_SCREEN, row.base_module_id(), row.base_screen_id());
	}

	public static final String NUMBER_PREFIX = "ORD_";

	protected String createBaseResourceKey(OpenScreenInfoR row, Number i) {
		return MCConst.createKey(OPEN_SCREEN, row.base_module_id(), row.base_screen_id(),
				NUMBER_PREFIX + String.valueOf(i));
	}

	public static final String OPEN_PARAM = "open_param";
	public static final String OPEN_PARAM_BIND = "open_param_bind";

	/**
	 * @see mcframe.commonCore.resource.ctrl.MCResourceBundle#isSearchedProgram(String)
	 */
	public static boolean isSearchedProgram(String type, String pgmid) {
		return _me._isSearchedProgram(type, pgmid);
	}

	protected boolean _isSearchedProgram(String type, String pgmid) {
		return MCConst.app.isSearchedProgram(toResourceLayerType(type), pgmid);
	}

	/**
	 * TYPE_USER, TYPE_EXT, TYPE_SYS
	 */
	static final FXC_RESOURCE_SETTING_UNIT[] SETTING_UNIT_ARR = {
			FXC_RESOURCE_SETTING_UNIT.TYPE_USER, FXC_RESOURCE_SETTING_UNIT.TYPE_EXT,
			FXC_RESOURCE_SETTING_UNIT.TYPE_SYS
	};

	/**
	 * @return　setting_unit_typeを除いた固定カラム名の配列を返します。
	 */
	protected String[] getSaveRowColumns() {
		// リソースキーの組み立て時に使わないsetting_unit_typeをcolnames()から取り除く
		return java.util.Arrays.stream(OpenScreenInfoR.colnames())
				.filter(r -> !r.equals(OpenScreenInfoR.$setting_unit_type))
				.collect(java.util.stream.Collectors.toList()).toArray(new String[0]);
	}

	// 画面起動パーソナライズ情報の管理（共通）＜ここまで＞
	// 画面起動パーソナライズ情報の管理（保存）＜ここから＞
	protected static FXUCP_ToolBarUtil _me = new FXUCP_ToolBarUtil();

	/**
	 * 画面遷移設定のパーソナライズ情報を保存します。
	 * <p>
	 * 既存のパーソナライズ情報をいったん削除してから保存します。
	 *
	 * @param list 画面遷移設定のリスト
	 */
	public static void saveOpenScreenInfo(MCList<OpenScreenInfoR> list) {
		_me._saveOpenScreenInfo(list);
	}

	/**
	 * @see #saveOpenScreenInfo(MCList)
	 */
	protected void _saveOpenScreenInfo(MCList<OpenScreenInfoR> list) {
		saveOpenScreenInfoRemove(list);
		saveOpenScreenInfoSetup(list);
		saveResource();
	}

	/**
	 * 画面遷移設定のパーソナライズ情報を保存します。
	 * <p>
	 * 既存のパーソナライズ情報をいったん削除してから保存します。
	 *
	 * @param list 画面遷移設定のリスト
	 * @param map 画面遷移設定と画面遷移連携設定のマップ
	 */
	public static void saveOpenScreenInfo(MCList<OpenScreenInfoR> list,
						Map<OpenScreenInfoR, MCList<OpenScreenParamR>> map) {
		_me._saveOpenScreenInfo(list, map);
	}

	/**
	 * @see #saveOpenScreenInfo(MCList, Map)
	 */
	protected void _saveOpenScreenInfo(MCList<OpenScreenInfoR> list,
						Map<OpenScreenInfoR, MCList<OpenScreenParamR>> map) {
		saveOpenScreenInfoRemove(list);
		saveOpenScreenInfoSetup(list);
		saveOpenScreenParamSetup(list, map);
		saveResource();
	}

	/**
	 * 過去のセッティング情報を削除する。
	 */
	protected void saveOpenScreenInfoRemove(MCList<OpenScreenInfoR> list) {
		for (OpenScreenInfoR row : list) {
			// メモ：createResourceBaseKeyの仕様によっては２週目以降は空振りで終わりかも
			MCResourceLayerType type = toResourceLayerType(row.setting_unit_type());
			String[] keys = MCConst.app.findPattern(type,
					MCConst.createKey(createRootResourceKey(row), "**"));

			for (String key : keys) {
				MCConst.app.remove(type, key);
			}
		}
	}

	/**
	 * 保存する情報を組み立てる
	 */
	protected void saveOpenScreenInfoSetup(MCList<OpenScreenInfoR> list) {
		MCList<OpenScreenInfoR> ls = exceptDeleteAndEmpty(list);
		for (int index = 0; index < ls.size(); index++) {
			OpenScreenInfoR row = ls.get(index);
			MCResourceLayerType type = toResourceLayerType(row.setting_unit_type());
			String baseKey = createBaseResourceKey(row, index);

			for (String column : getSaveRowColumns()) {
				String key = MCConst.createKey(baseKey, column);
				switch (row.getMeta(column).type()) {
					case BOOLEAN:
						MCConst.app.setString(type, key,
								Boolean.toString(row.getBoolean(column)));
						break;
					case NUMBER:
						MCConst.app.setString(type, key,
								row.getNumber(column).toPlainString());
						break;
					case STRING:
						MCConst.app.setString(type, key, row.getString(column));
						break;
					default:
						// 予期せぬ型⇒使ってはいけない
				}
			}
		}
	}

	/**
	 * 保存するパラメータを組み立てる
	 *
	 * @param list
	 * @param map
	 */
	protected void saveOpenScreenParamSetup(MCList<OpenScreenInfoR> list,
						Map<OpenScreenInfoR, MCList<OpenScreenParamR>> map) {
		MCList<OpenScreenInfoR> ls = exceptDeleteAndEmpty(list);

		for (int index = 0; index < ls.size(); index++) {
			OpenScreenInfoR row = ls.get(index);
			MCList<OpenScreenParamR> paramL = map.get(row);
			if (paramL == null || paramL.size() <= 0) {
				continue;
			}

			MCResourceLayerType type = toResourceLayerType(row.setting_unit_type());
			String baseKey = createBaseResourceKey(row, index);
			for (OpenScreenParamR param : paramL) {
				String key = null;
				if (param.is_bind()) {
					key = MCConst.createKey(baseKey, OPEN_PARAM_BIND,
							param.open_param_key());
				}
				else {
					key = MCConst.createKey(baseKey, OPEN_PARAM, param.open_param_key());
				}
				if (param.base_param_key() != null) {
					MCConst.app.setString(type, key, param.base_param_key());
				}
				else {
					String[] fixedval = getFixedValueStrings(param);
					MCConst.app.setStringArray(type, key, fixedval);
				}
			}
		}
	}

	/**
	 * 固定値をRowに設定する。
	 * @param param Row
	 * @param values　固定値の保存用配列
	 */
	private void setFixedValues(OpenScreenParamR param, String[] vs) {
		// getFixedValueStringsと同じindexにすること
		// TYPE
		// テキスト、ラジオ
		// チェック
		// 数値
		// 日付、タイムスタンプ
		// 日付（今日）フラグ、日付（月初）フラグ、日付（月末）フラグ
		// 差分（月）、差分（週）、曜日、差分（日）、差分（時）、差分（分）
		int c = 0;
		MCDataType dtype = MCDataType.valueOf(vs[c++]);
		param.type(dtype.name());
		param.text(vs[c++]);
		param.radio(vs[c++]);
		param.check(Boolean.valueOf(vs[c++]));
		param.num(getNumber(vs[c++]));

		switch (dtype) {
			case DATE:
				param.date(MCTimestamp.valueOf(toNull(vs[c++]),MCDate.TO_STRING_FORMAT));
				break;
			case TIMESTAMP:
				param.date(MCTimestamp.valueOf(toNull(vs[c++]),MCTimestamp.TO_STRING_FORMAT));
				break;
			default:
		}
		param.today_flg(Boolean.valueOf(vs[c++]));
		param.firstday_flg(Boolean.valueOf(vs[c++]));
		param.lastday_flg(Boolean.valueOf(vs[c++]));
		param.month(getNumber(vs[c++]));
		param.week(getNumber(vs[c++]));
		param.day_of_week_type(vs[c++]);
		param.day(getNumber(vs[c++]));
		param.hour(getNumber(vs[c++]));
		param.minute(getNumber(vs[c++]));
	}
	private MCNumber getNumber(String v) {
		return MCNumber.valueOf(toNull(v));
	}
	/**
	 * 空文字をnullにする。
	 * @param v 値
	 * @return 修正後の値
	 */
	private String toNull(String v) {
		return !isNull(v) ? v : null;
	}

	/**
	 * 固定値を連携先に合わせた値に変換した値を返す。
	 * @param rb 連携先項目またはnull 
	 * @param param 固定値を持つ行
	 */
	private Comparable<?> getFixedValue(MCRootPanel topanel, MCRowBeans rb, OpenScreenParamR param) {
		// TYPE
		// テキスト、ラジオ
		// チェック
		// 数値
		// 日付、タイムスタンプ
		// 日付（今日）フラグ、日付（月初）フラグ、日付（月末）フラグ
		// 差分（月）、差分（週）、曜日、差分（日）、差分（時）、差分（分）
		MCDataType dtype = null;
		if (rb != null) {
			dtype = rb.getDataType();
		}
		else {
			dtype = MCDataType.valueOf(param.type());
		}
		switch (dtype) {
			case STRING:
				String s = param.text();
				if (!isNull(s)) {
					return getMacroString(s);
				}
				return param.radio();
			case BINARY:
				return null;
			case BOOLEAN:
				return param.check();
			case NUMBER:
				return param.num();
			case ROW:
				return null;
			case DATE:
			case TIMESTAMP:
				return getCalenderValue(topanel, rb, param, dtype);
			default:
				return null;
		}
	}
	
	/**
	 * 連携先項目に合わせて固定値を変換した値を返す。
	 * @param panel 連携先画面
	 * @param compo 連携先項目
	 * @param data 固定値を含む行
	 * @param datatype データ型
	 * @return
	 */
	private MCCalendarDate getCalenderValue(MCRootPanel panel, MCRowBeans compo, OpenScreenParamR data, MCDataType datatype) {
		
		// 設定する日付
		MCCalendarDate<?> v = null;

		// 日付（今日）の場合
		if (data.today_flg()) {
			v = panel.today(datatype);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
		}
		// 日付（月初）の場合
		else if (data.firstday_flg()) {
			v = panel.today(datatype);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
			v = v.startOfMonth();
		}
		// 日付（月末）の場合
		else if (data.lastday_flg()) {
			v = panel.today(datatype);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
			v = v.endOfMonth();
		}
		else {
			MCTimestamp t = data.date();
			// 日付（固定値）の場合
			if (t != null) {
				v = t;
				if (MCDataType.DATE == datatype) {
					v = t.toMCDate();
				}
				if (data.month() != null) {
					v = v.addMonth(data.month());
				}
			}
			// 日付が指定されていない場合は null を設定する
		}

		if (v != null) {
			if (data.week() != null) {
				v = v.addDay(data.week().multiply(7));
				String t = data.day_of_week_type();
				if (!isNull(t)) {
					int dw = Integer.parseInt(t) - v.getDayOfWeek();
					v = v.addDay(dw);
				}
			}
			if (data.day() != null) {
				v = v.addDay(data.day());
			}
			if (data.hour() != null) {
				v = v.addHour(data.hour());
			}
			if (data.minute() != null) {
				v = v.addMinute(data.minute());
			}
		}

		return adjustValueByCalenderFormat(compo, v);
	}

	/**
	 * 固定値を保存用配列に変更する。
	 * @param param 固定値を持つ行
	 */
	private String[] getFixedValueStrings(OpenScreenParamR param ) {
		// TYPE
		// テキスト、ラジオ
		// チェック
		// 数値
		// 日付、タイムスタンプ
		// 日付（今日）フラグ、日付（月初）フラグ、日付（月末）フラグ
		// 差分（月）、差分（週）、曜日、差分（日）、差分（時）、差分（分）
		String[] va = new String[15];
		MCDataType dtype = MCDataType.valueOf(param.type());
		va[0] = param.type();
		switch (dtype) {
			case STRING:
				va[1] = param.text();
				va[2] = param.radio();
				break;
			case BINARY:
				break;
			case BOOLEAN:
				va[3] = String.valueOf(param.check());
				break;
			case NUMBER:
				va[4] = param.num() != null ? String.valueOf(param.num()) : null;
				break;
			case ROW:
				break;
			case DATE:
			case TIMESTAMP:
				int c = 5;
				switch(dtype) {
					case DATE:
						va[c++] = !isNull(param.date())
						? MCDate.valueOf(param.date()).toString() : null;
						break;
					case TIMESTAMP:
						va[c++] = !isNull(param.date()) ? param.date().toString() : null;
						break;
					default:
				}
				va[c++] = String.valueOf(param.today_flg());
				va[c++] = String.valueOf(param.firstday_flg());
				va[c++] = String.valueOf(param.lastday_flg());
				va[c++] = param.month() != null ? String.valueOf(param.month()) : null;
				va[c++] = param.week() != null ? String.valueOf(param.week()) : null;
				va[c++] = param.day_of_week_type();
				va[c++] = param.day() != null ? String.valueOf(param.day()) : null;
				va[c++] = param.hour() != null ? String.valueOf(param.hour()) : null;
				va[c++] = param.minute() != null ? String.valueOf(param.minute())
						: null;
				break;
			default:
				break; 
		}

		return va;
	}

	// 画面起動パーソナライズ情報の保存＜ここまで＞
	// 画面起動パーソナライズ情報の読込＜ここから＞

	/**
	 * 画面遷移設定のリソース値をロードします。
	 * <p>
	 * 遷移設定画面から呼び出された場合は、ラジオボタンの設定単位と一致する設定（proto.setting_unit_type()の値）をロードします。<br>
	 * 画面オープン時に呼び出された場合（proto.setting_unit_type()がnull）は、すべての設定単位の値をロードします。
	 * 
	 * @param proto 遷移設定のRow（keyを作成する際に使う、起動元画面のモジュールIDと画面IDが入っている）
	 * @return 画面遷移設定のリソース値を格納したList
	 */
	public static MCList<OpenScreenInfoR> loadOpenScreenInfo(OpenScreenInfoR proto) {
		return _me._loadOpenScreenInfo(proto);
	}

	/**
	 * @see #loadOpenScreenInfo(OpenScreenInfoR)
	 */
	public MCList<OpenScreenInfoR> _loadOpenScreenInfo(OpenScreenInfoR proto) {
		MCList<OpenScreenInfoR> ans = createOpenScreenInfoL();
		String rootKey = createRootResourceKey(proto);

		for (FXC_RESOURCE_SETTING_UNIT u : SETTING_UNIT_ARR) {
			if (proto.setting_unit_type() != null
					&& FXC_RESOURCE_SETTING_UNIT.get(proto.setting_unit_type()) != u) {
				continue;
				// 画面遷移設定画面から呼び出された場合には、proto.setting_unit_type()のみロードしたい
			}

			String settingUnitType = u.value();
			StringBuilder sb = new StringBuilder(NUMBER_PREFIX).append('*');
			MCResourceLayerType type = toResourceLayerType(settingUnitType);
			String[] baseKeys = MCConst.app.findPattern(type,
					MCConst.createKey(rootKey, sb.toString()));
			// continueの条件に使っているため、protoには触らず別途Rowを生成する
			OpenScreenInfoR cndR = proto.clone();
			cndR.setting_unit_type(settingUnitType); 

			for (int i = 0; i < baseKeys.length; i++) {
				String baseKey = createBaseResourceKey(cndR, i);
				OpenScreenInfoR row = _loadOpenScreenInfoR(type, baseKey);
				row.setting_unit_type(settingUnitType);
				ans.add(row);
			}
		}
		return ans;
	}

	/**
	 * 画面遷移設定のリソース値を格納したRowを返します。
	 * <p>
	 * なお、setting_unit_typeの値はこのメソッドではセットされません。必要に応じてセットするように実装してください。
	 * 
	 * @param baseKey OPEN_SCREEN.[MODULE_ID].[SCREEN_ID].[設定単位_連番]
	 * @return リソース値を格納したRow
	 */
	protected OpenScreenInfoR _loadOpenScreenInfoR(MCResourceLayerType type,
			String baseKey) {
		OpenScreenInfoR row = createOpenScreenInfoR();

		for (String column : getSaveRowColumns()) {
			String key = MCConst.createKey(baseKey, column);
			switch (row.getMeta(column).type()) {
				case BOOLEAN:
					boolean b = Boolean.valueOf(MCConst.app.getString(type, key));
					row.setBoolean(column, b);
					break;
				case NUMBER:
					MCNumber n = MCNumber.valueOf(MCConst.app.getString(type, key));
					row.setNumber(column, n);
					break;
				case STRING:
					String s = MCConst.app.getString(type, key);
					row.setString(column, s);
					break;
				default:
					// 予期せぬ型⇒使ってはいけない
			}
		}
		return row;
	}

	/**
	 * @param proto keyを作成するのに使う
	 * @param index 対応する画面の表示行位置
	 */
	public static MCList<OpenScreenParamR> loadOpenScreenParam(OpenScreenInfoR proto,
			int index) {
		return _me._loadOpenScreenParam(proto, index);
	}

	/**
	 * @param proto keyを作成するのに使う
	 * @param index 対応する画面の表示行位置
	 */
	public MCList<OpenScreenParamR> _loadOpenScreenParam(OpenScreenInfoR proto,
			int index) {
		MCList<OpenScreenParamR> ans = createOpenScreenParamL();
		String baseKey = createBaseResourceKey(proto, index);
		MCResourceLayerType type = toResourceLayerType(proto.setting_unit_type());
		_loadOpenScreenParamImpl(ans, type, baseKey, OPEN_PARAM);
		_loadOpenScreenParamImpl(ans, type, baseKey, OPEN_PARAM_BIND);
		return ans;
	}

	/**
	 * 指定したキーの値を読み込みます。
	 * 
	 * @param ans 保存するコンテナ
	 * @param protobaseKey ベースキー
	 * @param openKey 画面遷移パラメータキー
	 */
	private void _loadOpenScreenParamImpl(MCList<OpenScreenParamR> ans,
			MCResourceLayerType type, String protobaseKey, String openKey) {
		String baseKey = MCConst.createKey(protobaseKey, openKey);
		int openpos = baseKey.length() + 1;
		String[] keys = MCConst.app.findPattern(type, MCConst.createKey(baseKey, "**"));

		for (String key : keys) {
			String open = key.substring(openpos);
			String base = MCConst.app.getString(type, key);
			String[] basefixed = MCConst.app.getStringArray(type, key);

			OpenScreenParamR row = ans.createRow();
			row.is_bind(OPEN_PARAM_BIND.equals(openKey));
			row.open_param_key(open);
			row.to_key(open);
			if (basefixed.length > 1) {
				setFixedValues(row, basefixed);
			}
			else {
				row.base_param_key(base);
				row.from_key(base);
			}
			ans.add(row);
		}
	}

	// 画面起動パーソナライズ情報の読込＜ここまで＞

}