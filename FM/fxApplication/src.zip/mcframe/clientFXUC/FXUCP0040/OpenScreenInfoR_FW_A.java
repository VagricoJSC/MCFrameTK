package mcframe.clientFXUC.FXUCP0040;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"OpenScreenInfo"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class OpenScreenInfoR_FW_A extends MCConstRow {

	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public static final String $setting_unit_type = "setting_unit_type";
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $open_module_id = "open_module_id";
	/**
	 *  モジュール名.<p>
	 *
	 */
	public static final String $open_module_nm = "open_module_nm";
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public static final String $open_screen_id = "open_screen_id";
	/**
	 *  画面タイプ.<p>
	 *
	 */
	public static final String $panel_typ = "panel_typ";
	/**
	 *  ボタン.<p>
	 *
	 */
	public static final String $lbl_text = "lbl_text";
	/**
	 *  画面名.<p>
	 *
	 */
	public static final String $msg_text = "msg_text";
	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public static final String $usr_id = "usr_id";
	/**
	 *  起動元画面モジュールＩＤ.<p>
	 *
	 */
	public static final String $base_module_id = "base_module_id";
	/**
	 *  起動元画面画面ＩＤ.<p>
	 *
	 */
	public static final String $base_screen_id = "base_screen_id";


	public static final MCMeta setting_unit_type_META = createStringMeta($setting_unit_type);
	public static final MCMeta open_module_id_META = createCommonMeta($open_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta open_module_nm_META = createCommonMeta($open_module_nm, mcframe.commonCore.meta.M_META.MODULE_ID_NM);
	public static final MCMeta open_screen_id_META = createCommonMeta($open_screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta panel_typ_META = createStringMeta($panel_typ);
	public static final MCMeta lbl_text_META = createStringMeta($lbl_text, 5);
	public static final MCMeta msg_text_META = createCommonMeta($msg_text, mcframe.commonCore.meta.M_META.SCREEN_NAME);
	public static final MCMeta usr_id_META = createStringMeta($usr_id);
	public static final MCMeta base_module_id_META = createStringMeta($base_module_id);
	public static final MCMeta base_screen_id_META = createStringMeta($base_screen_id);

	protected static final ConstMetaList<OpenScreenInfoR> constMetas = new ConstMetaList<OpenScreenInfoR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			setting_unit_type_META,
			open_module_id_META,
			open_module_nm_META,
			open_screen_id_META,
			panel_typ_META,
			lbl_text_META,
			msg_text_META,
			usr_id_META,
			base_module_id_META,
			base_screen_id_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected OpenScreenInfoR_FW_A(ConstMetaList<? extends OpenScreenInfoR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OpenScreenInfoR clone() {
		return (OpenScreenInfoR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OpenScreenInfoR createInstance() {
		return (OpenScreenInfoR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OpenScreenInfoR getValues(String... names) {
		return (OpenScreenInfoR) super.getValues(names);
	}



	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public String setting_unit_type() {
		return getConstString(offset + 0, $setting_unit_type);
	}

	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public void setting_unit_type(String value) {
		setConstString(offset + 0, $setting_unit_type, value);
	}


	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String open_module_id() {
		return getConstString(offset + 1, $open_module_id);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void open_module_id(String value) {
		setConstString(offset + 1, $open_module_id, value);
	}


	/**
	 *  モジュール名.<p>
	 *
	 */
	public String open_module_nm() {
		return getConstString(offset + 2, $open_module_nm);
	}

	/**
	 *  モジュール名.<p>
	 *
	 */
	public void open_module_nm(String value) {
		setConstString(offset + 2, $open_module_nm, value);
	}


	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public String open_screen_id() {
		return getConstString(offset + 3, $open_screen_id);
	}

	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public void open_screen_id(String value) {
		setConstString(offset + 3, $open_screen_id, value);
	}


	/**
	 *  画面タイプ.<p>
	 *
	 */
	public String panel_typ() {
		return getConstString(offset + 4, $panel_typ);
	}

	/**
	 *  画面タイプ.<p>
	 *
	 */
	public void panel_typ(String value) {
		setConstString(offset + 4, $panel_typ, value);
	}


	/**
	 *  ボタン.<p>
	 *
	 */
	public String lbl_text() {
		return getConstString(offset + 5, $lbl_text);
	}

	/**
	 *  ボタン.<p>
	 *
	 */
	public void lbl_text(String value) {
		setConstString(offset + 5, $lbl_text, value);
	}


	/**
	 *  画面名.<p>
	 *
	 */
	public String msg_text() {
		return getConstString(offset + 6, $msg_text);
	}

	/**
	 *  画面名.<p>
	 *
	 */
	public void msg_text(String value) {
		setConstString(offset + 6, $msg_text, value);
	}


	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public String usr_id() {
		return getConstString(offset + 7, $usr_id);
	}

	/**
	 *  ユーザＩＤ.<p>
	 *
	 */
	public void usr_id(String value) {
		setConstString(offset + 7, $usr_id, value);
	}


	/**
	 *  起動元画面モジュールＩＤ.<p>
	 *
	 */
	public String base_module_id() {
		return getConstString(offset + 8, $base_module_id);
	}

	/**
	 *  起動元画面モジュールＩＤ.<p>
	 *
	 */
	public void base_module_id(String value) {
		setConstString(offset + 8, $base_module_id, value);
	}


	/**
	 *  起動元画面画面ＩＤ.<p>
	 *
	 */
	public String base_screen_id() {
		return getConstString(offset + 9, $base_screen_id);
	}

	/**
	 *  起動元画面画面ＩＤ.<p>
	 *
	 */
	public void base_screen_id(String value) {
		setConstString(offset + 9, $base_screen_id, value);
	}


	public String getString(String name) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($open_module_id.equalsIgnoreCase(name)) {
			return open_module_id();
		}
		if ($open_module_nm.equalsIgnoreCase(name)) {
			return open_module_nm();
		}
		if ($open_screen_id.equalsIgnoreCase(name)) {
			return open_screen_id();
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			return panel_typ();
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			return lbl_text();
		}
		if ($msg_text.equalsIgnoreCase(name)) {
			return msg_text();
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			return usr_id();
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			return base_module_id();
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			return base_screen_id();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($open_module_id.equalsIgnoreCase(name)) {
			return open_module_id();
		}
		if ($open_module_nm.equalsIgnoreCase(name)) {
			return open_module_nm();
		}
		if ($open_screen_id.equalsIgnoreCase(name)) {
			return open_screen_id();
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			return panel_typ();
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			return lbl_text();
		}
		if ($msg_text.equalsIgnoreCase(name)) {
			return msg_text();
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			return usr_id();
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			return base_module_id();
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			return base_screen_id();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($open_module_id.equalsIgnoreCase(name)) {
			open_module_id(value);
			return;
		}
		if ($open_module_nm.equalsIgnoreCase(name)) {
			open_module_nm(value);
			return;
		}
		if ($open_screen_id.equalsIgnoreCase(name)) {
			open_screen_id(value);
			return;
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			panel_typ(value);
			return;
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			lbl_text(value);
			return;
		}
		if ($msg_text.equalsIgnoreCase(name)) {
			msg_text(value);
			return;
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			usr_id(value);
			return;
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			base_module_id(value);
			return;
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			base_screen_id(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($open_module_id.equalsIgnoreCase(name)) {
			open_module_id(value);
			return;
		}
		if ($open_module_nm.equalsIgnoreCase(name)) {
			open_module_nm(value);
			return;
		}
		if ($open_screen_id.equalsIgnoreCase(name)) {
			open_screen_id(value);
			return;
		}
		if ($panel_typ.equalsIgnoreCase(name)) {
			panel_typ(value);
			return;
		}
		if ($lbl_text.equalsIgnoreCase(name)) {
			lbl_text(value);
			return;
		}
		if ($msg_text.equalsIgnoreCase(name)) {
			msg_text(value);
			return;
		}
		if ($usr_id.equalsIgnoreCase(name)) {
			usr_id(value);
			return;
		}
		if ($base_module_id.equalsIgnoreCase(name)) {
			base_module_id(value);
			return;
		}
		if ($base_screen_id.equalsIgnoreCase(name)) {
			base_screen_id(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

