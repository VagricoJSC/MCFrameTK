package mcframe.clientFXUC.FXUCP0040;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FXUCP_ToolBarUtil"パネルクラスです。<p>
 *
 * ツールバーのユーティリティ<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXUCP_ToolBarUtil_FW_A extends mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXUC";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXUCP0040";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  イベントフロー.<p>
	 *
	 */
	public MCButton Btn_b_flow = null;
	/**
	 *  バーコード.<p>
	 *
	 */
	public MCButton Btn_barcode = null;
	/**
	 *  画面クリア.<p>
	 *
	 */
	public MCButton Btn_sclear = null;
	/**
	 *  エクセル出力.<p>
	 *
	 */
	public MCButton Btn_excel_out = null;
	/**
	 *  テーブル最大化.<p>
	 *
	 */
	public MCButton Btn_tbl_zoom = null;
	/**
	 *  メモ.<p>
	 *
	 */
	public MCButton Btn_open_WBP0850 = null;
	/**
	 *  項目配置変更.<p>
	 *
	 */
	public MCButton Btn_move_xy = null;
	/**
	 *  グラフ.<p>
	 *
	 */
	public MCButton Btn_graph = null;
	/**
	 *  パーソナライズグループ.<p>
	 *
	 */
	public MCButton Btn_screen_switch = null;
	// [Bookmark]ブロック関連のField定義
	public MCPanel BookmarkPanel = null;
	// [Bookmark]ブロックの項目のField定義
	/**
	 *  画面遷移追加.<p>
	 *
	 */
	public MCButton Bookmark_open_XUP0180 = null;
	// [Robot]ブロック関連のField定義
	public MCPanel RobotPanel = null;
	// [Robot]ブロックの項目のField定義
	/**
	 *  再生リスト.<p>
	 *
	 */
	public MCButton Robot_play_s_list = null;
	// [Scenario]ブロック関連のField定義
	public MCPanel ScenarioPanel = null;
	// [Scenario]ブロックの項目のField定義
	/**
	 *  シナリオテスト.<p>
	 *
	 */
	public MCButton Scenario_s_test = null;
	// [Dev]ブロック関連のField定義
	public MCPanel DevPanel = null;
	// [Dev]ブロックの項目のField定義
	/**
	 *  システム非表示設定.<p>
	 *
	 */
	public MCButton Dev_s_invisible = null;
	/**
	 *  テスト支援.<p>
	 *
	 */
	public MCButton Dev_test_assistance = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [OpenScreenInfo]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR> aOpenScreenInfoL;
	/** [OpenScreenParam]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> aOpenScreenParamL;

	/**
	 * コピーによってaOpenScreenInfoLを設定します。
	 *
	 * aOpenScreenInfoLのインスタンスは変更されません。
	 *
	 * @param dataset OpenScreenInfoL
	 */
	public void setOpenScreenInfoL(MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR> aList) {
		if (getOpenScreenInfoL() != aList) {
			getOpenScreenInfoL().setAll(aList);
		}
	}

	/**
	 * [OpenScreenInfo]ブロックのコンテナaOpenScreenInfoLを返します。
	 *
	 * @return OpenScreenInfoL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR> getOpenScreenInfoL() {
		return aOpenScreenInfoL;
	}

	/**
	 * aOpenScreenInfoRを作成します。
	 *
	 * @return OpenScreenInfoR
	 */
	public mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR createOpenScreenInfoR() {
		return mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR.create();
	}

	/**
	 * aOpenScreenInfoLを作成します。
	 *
	 * @return OpenScreenInfoL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR> createOpenScreenInfoL() {
		return MCList.create(mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR.class);
	}

	/**
	 * コピーによってaOpenScreenParamLを設定します。
	 *
	 * aOpenScreenParamLのインスタンスは変更されません。
	 *
	 * @param dataset OpenScreenParamL
	 */
	public void setOpenScreenParamL(MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> aList) {
		if (getOpenScreenParamL() != aList) {
			getOpenScreenParamL().setAll(aList);
		}
	}

	/**
	 * [OpenScreenParam]ブロックのコンテナaOpenScreenParamLを返します。
	 *
	 * @return OpenScreenParamL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> getOpenScreenParamL() {
		return aOpenScreenParamL;
	}

	/**
	 * aOpenScreenParamRを作成します。
	 *
	 * @return OpenScreenParamR
	 */
	public mcframe.clientFXUC.FXUCP0040.OpenScreenParamR createOpenScreenParamR() {
		return mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.create();
	}

	/**
	 * aOpenScreenParamLを作成します。
	 *
	 * @return OpenScreenParamL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0040.OpenScreenParamR> createOpenScreenParamL() {
		return MCList.create(mcframe.clientFXUC.FXUCP0040.OpenScreenParamR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getOpenScreenInfoL())) ret.add(getOpenScreenInfoL());
		if(!MCCollectionUtil.contains(ret, getOpenScreenParamL())) ret.add(getOpenScreenParamL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getOpenScreenInfoL()) return "OpenScreenInfo";
		if(aCnt == getOpenScreenParamL()) return "OpenScreenParam";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("OpenScreenInfo")) return getOpenScreenInfoL();
		if(bId.equals("OpenScreenParam")) return getOpenScreenParamL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(BtnPanel);
		ret.add(BookmarkPanel);
		ret.add(RobotPanel);
		ret.add(ScenarioPanel);
		ret.add(DevPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_ToolBarUtil_FW_A() {
		aOpenScreenInfoL = createOpenScreenInfoL();
		aOpenScreenParamL = createOpenScreenParamL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXUCP_ToolBarUtil_FW_A(String name) {
		aOpenScreenInfoL = createOpenScreenInfoL();
		aOpenScreenParamL = createOpenScreenParamL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXUCP_ToolBarUtil_FW.jbCreateBtn((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbCreateBookmark((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbCreateRobot((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbCreateScenario((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbCreateDev((FXUCP_ToolBarUtil)this);
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FXUCP_ToolBarUtil p) {
	}

	/**
	 * [Bookmark]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBookmark(FXUCP_ToolBarUtil p) {
	}

	/**
	 * [Robot]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateRobot(FXUCP_ToolBarUtil p) {
	}

	/**
	 * [Scenario]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateScenario(FXUCP_ToolBarUtil p) {
	}

	/**
	 * [Dev]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDev(FXUCP_ToolBarUtil p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_ToolBarUtil create(){
		FXUCP_ToolBarUtil p = new FXUCP_ToolBarUtil();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_ToolBarUtil create(String name){
		FXUCP_ToolBarUtil p = new FXUCP_ToolBarUtil(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXUCP_ToolBarUtil_FW.jbfInitBtn((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbfInitBookmark((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbfInitRobot((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbfInitScenario((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbfInitDev((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbInitBtn((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbInitBookmark((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbInitRobot((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbInitScenario((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.jbInitDev((FXUCP_ToolBarUtil)this);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_b_flow = p.beansFactory.createButton("Btn.b_flow", "toolbar");
		p.Btn_barcode = p.beansFactory.createButton("Btn.barcode", "toolbar");
		p.Btn_sclear = p.beansFactory.createButton("Btn.sclear", "toolbar");
		p.Btn_excel_out = p.beansFactory.createButton("Btn.excel_out", "toolbar");
		p.Btn_tbl_zoom = p.beansFactory.createButton("Btn.tbl_zoom", "toolbar");
		p.Btn_open_WBP0850 = p.beansFactory.createButton("Btn.open_WBP0850", "toolbar");
		p.Btn_move_xy = p.beansFactory.createButton("Btn.move_xy", "toolbar");
		p.Btn_graph = p.beansFactory.createButton("Btn.graph", "toolbar");
		p.Btn_screen_switch = p.beansFactory.createButton("Btn.screen_switch", "toolbar");
	}

	/**
	 * [Bookmark]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBookmark(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.BookmarkPanel = p.beansFactory.createPanel("Bookmark");
		// ブロックの項目の初期化
		p.Bookmark_open_XUP0180 = p.beansFactory.createButton("Bookmark.open_XUP0180", "toolbar");
	}

	/**
	 * [Robot]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitRobot(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.RobotPanel = p.beansFactory.createPanel("Robot");
		// ブロックの項目の初期化
		p.Robot_play_s_list = p.beansFactory.createButton("Robot.play_s_list", "toolbar");
	}

	/**
	 * [Scenario]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitScenario(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.ScenarioPanel = p.beansFactory.createPanel("Scenario");
		// ブロックの項目の初期化
		p.Scenario_s_test = p.beansFactory.createButton("Scenario.s_test", "toolbar");
	}

	/**
	 * [Dev]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDev(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.DevPanel = p.beansFactory.createPanel("Dev");
		// ブロックの項目の初期化
		p.Dev_s_invisible = p.beansFactory.createButton("Dev.s_invisible", "toolbar");
		p.Dev_test_assistance = p.beansFactory.createButton("Dev.test_assistance", "toolbar");
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.setLastBeans(p.BtnPanel);
		p.BtnPanel.setNextBeans(p.BookmarkPanel);
		// ブロックの項目の初期化
		p.Btn_b_flow.setIcon("B_FLOW");
		p.BtnPanel.add(p.Btn_b_flow);
		p.BtnPanel.setLastBeans(p.Btn_b_flow);
		p.Btn_b_flow.setNextBeans(p.Btn_barcode);
		p.Btn_barcode.setIcon("BARCODE");
		p.BtnPanel.add(p.Btn_barcode);
		p.Btn_barcode.setNextBeans(p.Btn_sclear);
		p.Btn_sclear.setIcon("SCREEN_CLEAR_T");
		p.Btn_sclear.setFunctionKey(MCFunctionKey.F24);
		p.BtnPanel.add(p.Btn_sclear);
		p.Btn_sclear.setNextBeans(p.Btn_excel_out);
		p.Btn_excel_out.setIcon("EXCEL_T");
		p.BtnPanel.add(p.Btn_excel_out);
		p.Btn_excel_out.setNextBeans(p.Btn_tbl_zoom);
		p.Btn_tbl_zoom.setIcon("TBL_ZOOM_T");
		p.BtnPanel.add(p.Btn_tbl_zoom);
		p.Btn_tbl_zoom.setNextBeans(p.Btn_open_WBP0850);
		p.Btn_open_WBP0850.setIcon("MEMO_T");
		p.BtnPanel.add(p.Btn_open_WBP0850);
		p.Btn_open_WBP0850.setNextBeans(p.Btn_move_xy);
		p.Btn_move_xy.setIcon("MOVE_XY");
		p.BtnPanel.add(p.Btn_move_xy);
		p.Btn_move_xy.setNextBeans(p.Btn_graph);
		p.Btn_graph.setIcon("GRAPH");
		p.BtnPanel.add(p.Btn_graph);
		p.Btn_graph.setNextBeans(p.Btn_screen_switch);
		p.Btn_screen_switch.setIcon("S_SWITCH");
		p.BtnPanel.add(p.Btn_screen_switch);
	}

	/**
	 * [Bookmark]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBookmark(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.add(p.BookmarkPanel);
		p.BookmarkPanel.setNextBeans(p.RobotPanel);
		// ブロックの項目の初期化
		p.Bookmark_open_XUP0180.setIcon("BOOKMARK");
		p.BookmarkPanel.add(p.Bookmark_open_XUP0180);
	}

	/**
	 * [Robot]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitRobot(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.add(p.RobotPanel);
		p.RobotPanel.setNextBeans(p.ScenarioPanel);
		// ブロックの項目の初期化
		p.Robot_play_s_list.setIcon("PLAY_S_LIST");
		p.RobotPanel.add(p.Robot_play_s_list);
	}

	/**
	 * [Scenario]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitScenario(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.add(p.ScenarioPanel);
		p.ScenarioPanel.setNextBeans(p.DevPanel);
		// ブロックの項目の初期化
		p.Scenario_s_test.setIcon("PLAY_S_LIST");
		p.ScenarioPanel.add(p.Scenario_s_test);
	}

	/**
	 * [Dev]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDev(FXUCP_ToolBarUtil p) {
		// ブロック関連の初期化
		p.add(p.DevPanel);
		// ブロックの項目の初期化
		p.DevPanel.add(p.Dev_s_invisible);
		p.Dev_s_invisible.setNextBeans(p.Dev_test_assistance);
		p.DevPanel.add(p.Dev_test_assistance);
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXUCP_ToolBarUtil_FW.mcInitBtn((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.mcInitBookmark((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.mcInitRobot((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.mcInitScenario((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.mcInitDev((FXUCP_ToolBarUtil)this);

		// [INIT]ステータスのモードの設定
		FXUCP_ToolBarUtil_FW.statusInitINIT_Btn((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.statusInitINIT_Bookmark((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.statusInitINIT_Robot((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.statusInitINIT_Scenario((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.statusInitINIT_Dev((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.statusInitINIT_OpenScreenInfo((FXUCP_ToolBarUtil)this);
		FXUCP_ToolBarUtil_FW.statusInitINIT_OpenScreenParam((FXUCP_ToolBarUtil)this);

	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FXUCP_ToolBarUtil p) {
		p.Btn_b_flow.addAllListener(p);
		p.Btn_b_flow.setAPMethodName("doBtn_b_flow");
		p.Btn_barcode.addAllListener(p);
		p.Btn_barcode.setAPMethodName("doBtn_barcode");
		p.Btn_sclear.addAllListener(p);
		p.Btn_sclear.setAPMethodName("doBtn_sclear");
		p.Btn_excel_out.addAllListener(p);
		p.Btn_excel_out.setAPMethodName("doBtn_excel_out");
		p.Btn_tbl_zoom.addAllListener(p);
		p.Btn_tbl_zoom.setAPMethodName("doBtn_tbl_zoom");
		p.Btn_open_WBP0850.addAllListener(p);
		p.Btn_open_WBP0850.setAPMethodName("doBtn_open_WBP0850");
		p.Btn_move_xy.addAllListener(p);
		p.Btn_move_xy.setAPMethodName("doBtn_move_xy");
		p.Btn_graph.addAllListener(p);
		p.Btn_graph.setAPMethodName("doBtn_graph");
		p.Btn_screen_switch.addAllListener(p);
		p.Btn_screen_switch.setAPMethodName("doBtn_screen_switch");
	}

	/**
	 *  [Bookmark]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBookmark(FXUCP_ToolBarUtil p) {
		p.Bookmark_open_XUP0180.addAllListener(p);
		p.Bookmark_open_XUP0180.setAPMethodName("doBookmark_open_XUP0180");
	}

	/**
	 *  [Robot]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitRobot(FXUCP_ToolBarUtil p) {
		p.Robot_play_s_list.addAllListener(p);
		p.Robot_play_s_list.setAPMethodName("doRobot_play_s_list");
	}

	/**
	 *  [Scenario]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitScenario(FXUCP_ToolBarUtil p) {
		p.Scenario_s_test.addAllListener(p);
		p.Scenario_s_test.setAPMethodName("doScenario_s_test");
	}

	/**
	 *  [Dev]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDev(FXUCP_ToolBarUtil p) {
		p.Dev_s_invisible.addAllListener(p);
		p.Dev_s_invisible.setAPMethodName("doDev_s_invisible");
		p.Dev_test_assistance.addAllListener(p);
		p.Dev_test_assistance.setAPMethodName("doDev_test_assistance");
	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FXUCP_ToolBarUtil p){

	}

	/**
	 * [INIT]ステータスの[Bookmark]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Bookmark(FXUCP_ToolBarUtil p){

	}

	/**
	 * [INIT]ステータスの[Robot]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Robot(FXUCP_ToolBarUtil p){
		p.Robot_play_s_list.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[Scenario]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Scenario(FXUCP_ToolBarUtil p){
		p.Scenario_s_test.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[Dev]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dev(FXUCP_ToolBarUtil p){

	}

	/**
	 * [INIT]ステータスの[OpenScreenInfo]ブロックのモードの設定
	 */
	protected static void statusInitINIT_OpenScreenInfo(FXUCP_ToolBarUtil p){

	}

	/**
	 * [INIT]ステータスの[OpenScreenParam]ブロックのモードの設定
	 */
	protected static void statusInitINIT_OpenScreenParam(FXUCP_ToolBarUtil p){

	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_b_flow) doBtn_b_flow(info);
		else if (ap == Btn_barcode) doBtn_barcode(info);
		else if (ap == Btn_sclear) doBtn_sclear(info);
		else if (ap == Btn_excel_out) doBtn_excel_out(info);
		else if (ap == Btn_tbl_zoom) doBtn_tbl_zoom(info);
		else if (ap == Btn_open_WBP0850) doBtn_open_WBP0850(info);
		else if (ap == Btn_move_xy) doBtn_move_xy(info);
		else if (ap == Btn_graph) doBtn_graph(info);
		else if (ap == Btn_screen_switch) doBtn_screen_switch(info);
		else if (ap == Bookmark_open_XUP0180) doBookmark_open_XUP0180(info);
		else if (ap == Robot_play_s_list) doRobot_play_s_list(info);
		else if (ap == Scenario_s_test) doScenario_s_test(info);
		else if (ap == Dev_s_invisible) doDev_s_invisible(info);
		else if (ap == Dev_test_assistance) doDev_test_assistance(info);
	}

	/**
	 * [Btn]パネルの[b_flow]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_b_flow(MCEventInfo info);

	/**
	 * [Btn]パネルの[barcode]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_barcode(MCEventInfo info);

	/**
	 * [Btn]パネルの[sclear]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_sclear(MCEventInfo info);

	/**
	 * [Btn]パネルの[excel_out]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_excel_out(MCEventInfo info);

	/**
	 * [Btn]パネルの[tbl_zoom]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_tbl_zoom(MCEventInfo info);

	/**
	 * [Btn]パネルの[open_WBP0850]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_open_WBP0850(MCEventInfo info);

	/**
	 * [Btn]パネルの[move_xy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_move_xy(MCEventInfo info);

	/**
	 * [Btn]パネルの[graph]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_graph(MCEventInfo info);

	/**
	 * [Btn]パネルの[screen_switch]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_screen_switch(MCEventInfo info);

	/**
	 * [Bookmark]パネルの[open_XUP0180]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBookmark_open_XUP0180(MCEventInfo info);

	/**
	 * [Robot]パネルの[play_s_list]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doRobot_play_s_list(MCEventInfo info);

	/**
	 * [Scenario]パネルの[s_test]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doScenario_s_test(MCEventInfo info);

	/**
	 * [Dev]パネルの[s_invisible]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDev_s_invisible(MCEventInfo info);

	/**
	 * [Dev]パネルの[test_assistance]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDev_test_assistance(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}