package mcframe.clientFXUC.FXUCP0080;

public class TmplData extends TmplData_FW {
	
	/**
	 * コンストラクタです。
	 */
	public TmplData() {}
	
}