package mcframe.clientFXUC.FXUCP0080;

import mcframe.commonCore.container.MCContainer;

public class TmplData_FW {
	
	/**
	 * 枠名です。
	 */
	protected String _panel_name = null;
	
	/**
	 * コンテナです。
	 */
	protected MCContainer _container = null;
	
	/**
	 * コンストラクタです。
	 */
	public TmplData_FW() {}
	
	/**
	 * 枠名を設定します。
	 * 
	 * @param name 枠名
	 */
	public void setPanelName(String name) {
		_panel_name = name;
	}
	
	/**
	 * 枠名を返します。<p>
	 * 枠名が設定されていない場合は null を返します。
	 * 
	 * @return 枠名、または null
	 */
	public String getPanelName() {
		return _panel_name;
	}
	
	/**
	 * コンテナを設定します。<p>
	 * <font color="red">
	 * InnerRowを含むコンテナを指定しないでください。
	 * </font>
	 * 
	 * @param cont コンテナ
	 */
	public void setContainer(MCContainer cont) {
		_container = cont;
	}
	
	/**
	 * コンテナを返します。<p>
	 * コンテナが設定されていない場合は null を返します。
	 * 
	 * @return コンテナ、または null
	 */
	public MCContainer getContainer() {
		return _container;
	}
	
}