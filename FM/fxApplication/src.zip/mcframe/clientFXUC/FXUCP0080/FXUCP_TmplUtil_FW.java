package mcframe.clientFXUC.FXUCP0080;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Arrays;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;

import mcframe.clientFXBA.FXBAP0010.IfTmplBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_TmplUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_TmplUtil_FW extends FXUCP_TmplUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * インスタンスです。
	 */
	protected static FXUCP_TmplUtil _util = new FXUCP_TmplUtil();
	
	/**
	 * テンプレートに関するパーソナライズ情報であることを表すキーです。
	 */
	protected static String _p_tmpl = "p_tmpl";

	/**
	 * 設定情報ＩＤを表すキーの接頭語です。
	 */
	protected String _setting_info_id_prefix = "user_";
	
	/**
	 * テンプレートの情報を設定、取得するためのリソースキーです。
	 */
	protected String _info = "info";
	
	/**
	 * テンプレートのデータを設定、取得するためのリソースキーです。
	 */
	protected String _data = "data";
	
	/**
	 * カラム数を表すキーの接頭語です。
	 */
	protected String _column_count_prefix = "column_count_";
	
	/**
	 * 行数を表すキーの接頭語です。
	 */
	protected String _row_count_prefix = "row_count_";
	
	/**
	 * Rowコンテナの情報を設定、取得するためのリソースキーです。
	 */
	protected String _row = "row";
	
	/**
	 * Listコンテナの情報を設定、取得するためのリソースキーです。
	 */
	protected String _list = "list";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_TmplUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	/**
	 * テンプレート情報をリソースに保存します。
	 * <p>
	 * 
	 * 保存するテンプレート情報は下記の通りです。
	 * <p>
	 * <table border="1">
	 * <tr><th>テンプレート情報</th><th>メソッド名</th></tr>
	 * <tr><td>設定情報ＩＤ</td><td>{@link TmplInfo#setSettingInfoID(String)} </td><tr>
	 * <tr><td>設定情報名</td><td> {@link TmplInfo#setSettingInfoName(String)} </td></tr>
	 * <tr><td>備考</td><td> {@link TmplInfo#setRemark(String)} </td></tr>
	 * <tr><td>無効フラグ</td><td> {@link TmplInfo#setIgnoreFlg(Boolean)} </td></tr>
	 * <tr><td>ポップアップ表示フラグ</td><td> {@link TmplInfo#setShowPopupFlg(Boolean)} </td></tr>
	 * <tr><td>テンプレートデータ</td><td> {@link TmplInfo#setTmplDataList(List)} </td></tr>
	 * </table>
	 * <p>
	 * 設定情報ＩＤが指定されていない場合は、保存するときに設定情報ＩＤを発行します。
	 * 発行した設定情報ＩＤを指定されたTmplInfoに設定します。
	 * <p>
	 * 保存するテンプレートデータは下記の通りです。
	 * <p>
	 * <table border="1">
	 * <tr><th>テンプレートデータ</th><th>メソッド名</th></tr>
	 * <tr><td>枠名</td><td> {@link TmplData#setPanelName(String)} </td></tr>
	 * <tr><td>コンテナ</td><td> {@link TmplData#setContainer(MCContainer)} </td></tr>
	 * </table>
	 * <p>
	 * コンテナのデータ型が {@link MCDataType#BINARY} 以外の全ての項目が保存対象になります。
	 * <font color="red">
	 * コンテナにはInnerRowを指定しないでください。
	 * MCListを指定する場合は、MCListにカラムが存在する必要があります。
	 * </font>
	 * <p>
	 * 
	 * 引数removeの指定とメソッド実行後のテンプレート情報の関係は以下の通りです。
	 * <p>
	 * <ul>
	 * <li>テンプレート情報を新規登録する場合<br>
	 * テンプレート情報を新規登録する場合は、引数removeの指定に関係なく、メソッド実行後は指定されたテンプレート情報とテンプレートデータが保存された状態になります。
	 * </li>
	 * <li>テンプレート情報を更新する場合<br>
	 * <ul>
	 * <li>引数removeにtrueを指定した場合<br>
	 * 指定された設定情報ＩＤのテンプレート情報とテンプレートデータを削除してから保存します。
	 * メソッド実行後は、保存されているテンプレート情報とテンプレートデータが削除され、指定されたテンプレート情報と指定されたテンプレートデータのみが保存された状態になります。
	 * </li>
	 * <li>引数removeにfalseを指定した場合<br>
	 * テンプレート情報については、引数removeがfalseの場合も、指定されたテンプレート情報のみが保存された状態になります。
	 * <p>
	 * 
	 * テンプレートデータについては、テンプレートデータが指定されなかった場合は、保存されているテンプレートデータが残った状態になります。
	 * <p>
	 * テンプレートデータが指定された場合は、指定されたテンプレートデータのみが保存された状態になります。
	 * テンプレートデータとしてコンテナ２つ分のデータが保存されている状態でコンテナ１つのテンプレートデータを指定した場合は、
	 * 指定されたコンテナ１つ分のデータのみが保存された状態になります。
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param info テンプレート情報
	 * @param remove テンプレート情報を削除してから保存する場合は true
	 */	
	public static void writeResource(
			IfTmplBase base, List<TmplInfo> info, boolean remove) {
		_util._writeResource(base, info, remove);
	}
	
	/**
	 * テンプレート情報をリソースに保存します。
	 * <p>
	 * 
	 * 保存するテンプレート情報は下記の通りです。
	 * <p>
	 * <table border="1">
	 * <tr><th>テンプレート情報</th><th>メソッド名</th></tr>
	 * <tr><td>設定情報ＩＤ</td><td>{@link TmplInfo#setSettingInfoID(String)} </td><tr>
	 * <tr><td>設定情報名</td><td> {@link TmplInfo#setSettingInfoName(String)} </td></tr>
	 * <tr><td>備考</td><td> {@link TmplInfo#setRemark(String)} </td></tr>
	 * <tr><td>無効フラグ</td><td> {@link TmplInfo#setIgnoreFlg(Boolean)} </td></tr>
	 * <tr><td>ポップアップ表示フラグ</td><td> {@link TmplInfo#setShowPopupFlg(Boolean)} </td></tr>
	 * <tr><td>テンプレートデータ</td><td> {@link TmplInfo#setTmplDataList(List)} </td></tr>
	 * </table>
	 * <p>
	 * 設定情報ＩＤが指定されていない場合は、保存するときに設定情報ＩＤを発行します。
	 * 発行した設定情報ＩＤを指定されたTmplInfoに設定します。
	 * <p>
	 * 保存するテンプレートデータは下記の通りです。
	 * <p>
	 * <table border="1">
	 * <tr><th>テンプレートデータ</th><th>メソッド名</th></tr>
	 * <tr><td>枠名</td><td> {@link TmplData#setPanelName(String)} </td></tr>
	 * <tr><td>コンテナ</td><td> {@link TmplData#setContainer(MCContainer)} </td></tr>
	 * </table>
	 * <p>
	 * コンテナのデータ型が {@link MCDataType#BINARY} 以外の全ての項目が保存対象になります。
	 * <font color="red">
	 * コンテナにはInnerRowを指定しないでください。
	 * MCListを指定する場合は、MCListにカラムが存在する必要があります。
	 * </font>
	 * <p>
	 * 
	 * 引数removeの指定とメソッド実行後のテンプレート情報の関係は以下の通りです。
	 * <p>
	 * <ul>
	 * <li>テンプレート情報を新規登録する場合<br>
	 * テンプレート情報を新規登録する場合は、引数removeの指定に関係なく、メソッド実行後は指定されたテンプレート情報とテンプレートデータが保存された状態になります。
	 * </li>
	 * <li>テンプレート情報を更新する場合<br>
	 * <ul>
	 * <li>引数removeにtrueを指定した場合<br>
	 * 指定された設定情報ＩＤのテンプレート情報とテンプレートデータを削除してから保存します。
	 * メソッド実行後は、保存されているテンプレート情報とテンプレートデータが削除され、指定されたテンプレート情報と指定されたテンプレートデータのみが保存された状態になります。
	 * </li>
	 * <li>引数removeにfalseを指定した場合<br>
	 * テンプレート情報については、引数removeがfalseの場合も、指定されたテンプレート情報のみが保存された状態になります。
	 * <p>
	 * 
	 * テンプレートデータについては、テンプレートデータが指定されなかった場合は、保存されているテンプレートデータが残った状態になります。
	 * <p>
	 * テンプレートデータが指定された場合は、指定されたテンプレートデータのみが保存された状態になります。
	 * テンプレートデータとしてコンテナ２つ分のデータが保存されている状態でコンテナ１つのテンプレートデータを指定した場合は、
	 * 指定されたコンテナ１つ分のデータのみが保存された状態になります。
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param info テンプレート情報
	 * @param remove テンプレート情報を削除してから保存する場合は true
	 */	
	protected void _writeResource(
			IfTmplBase panel, List<TmplInfo> info, boolean remove) {
		
		// リソース情報を削除する
		if (remove) {
			_removeResource(panel, info, false);
		}
		
		// 登録済みの設定情報ＩＤの連番のリスト
		List<Integer> ul = new ArrayList<Integer>();
		for (TmplInfo f : _readTmplInfoResource(panel)) {
			String id = f.getSettingInfoID();
			if (!isNull(id)) {
				ul.add(Integer.valueOf(
						id.substring(_setting_info_id_prefix.length())));
			}
		}
		for (TmplInfo f : info) {
			String id = f.getSettingInfoID();
			if (!isNull(id)) {
				ul.add(Integer.valueOf(
						id.substring(_setting_info_id_prefix.length())));
			}
		}

		String tk = _createTmplKey(panel);
		
		int n = 0;
		
		String p = _getPgmId(panel);
		
		for (TmplInfo f : info) {
			// 設定情報ＩＤを発行する
			if (isNull(f.getSettingInfoID())) {
				while (true) {
					if (!ul.contains(n)) {
						ul.add(n);
						break;
					}
					n++;
				}
				f.setSettingInfoID(_setting_info_id_prefix + String.valueOf(n));
			}
			
			String pk = MCConst.createKey(tk, f.getSettingInfoID());
			
			// テンプレート情報を設定する
			String k = MCConst.createKey(pk, _info);
			String[] v = new String[]{
					f.getSettingInfoName(),
					f.getRemark(),
					Boolean.toString(
							isNull(f.getIgnoreFlg()) ? 
									false : f.getIgnoreFlg()),
					Boolean.toString(
							isNull(f.getShowPopupFlg()) ? 
									false : f.getShowPopupFlg())
			};
			_getResource().setStringArrayKeyRotation(p, k, v);
			
			// テンプレートデータを設定する
			k = MCConst.createKey(pk, _data);

			List<String> vl = new ArrayList<String>();
			
			List<TmplData> dl = f.getTmplDataList();
			if (dl != null) {
				for (TmplData d : dl) {
					MCContainer c = d.getContainer();
					
					if (c instanceof MCRow) {
						MCRow o = (MCRow)c;
						
						vl.add(_row);
						vl.add(d.getPanelName());
						List<String> nl = _getEnableColumnNameList(c);
						vl.add(_column_count_prefix + String.valueOf(nl.size()));
						vl.addAll(nl);
						vl.addAll(_getDataTypeListString(c, nl));
						vl.addAll(_getValueListString(o, nl));
					}
					else if (c instanceof MCList<?>) {
						MCList<?> l = (MCList<?>)c;

						vl.add(_list);
						vl.add(d.getPanelName());
						List<String> nl = _getEnableColumnNameList(c);
						vl.add(_column_count_prefix + String.valueOf(nl.size()));
						vl.addAll(nl);
						vl.addAll(_getDataTypeListString(c, nl));

						vl.add(_row_count_prefix + l.size());
						for (MCRow o : l) {
							vl.addAll(_getValueListString(o, nl));
						}
					}
				}
				
				_getResource().setStringArrayKeyRotation(
						p, k, vl.toArray(new String[vl.size()]));
			}
		}
		
		MCConst.saveUser();
		
	}
	
	/**
	 * 指定されたコンテナのカラム名のうち、テンプレートとして有効なカラム名をリストにして返します。
	 * 
	 * @param cont コンテナ
	 * @return テンプレートとして有効なカラム名のリスト
	 */
	protected List<String> _getEnableColumnNameList(MCContainer cont) {
		List<String> l = new ArrayList<String>();
		for (String n : cont.getColumnPathArray()) {
			switch (cont.getDataType(n)) {
				case STRING:
				case BOOLEAN:
				case DATE:
				case TIMESTAMP:
				case NUMBER:
					l.add(n);
					break;
				default:
					break;
			}
		}
		return l;
	}
	
	/**
	 * コンテナのデータ型をリストにして返します。
	 * 
	 * @param cont コンテナ
	 * @param names カラム名の配列
	 * @return コンテナのデータ型のリスト
	 */
	protected List<String> _getDataTypeListString(
			MCContainer cont, List<String> name) {
		List<String> vl = new ArrayList<String>();
		for (String n : name) {
			vl.add(cont.getDataType(n).name());
		}
		return vl;
	}
	
	/**
	 * 指定されたMCRowの指定されたカラムの値を文字列に変換した値をリストにして返します。
	 * 
	 * @param row MCRow
	 * @param name カラム名のリスト
	 * @return MCRowの値を文字列に変換した値のリスト
	 */
	protected List<String> _getValueListString(MCRow row, List<String> name) {
		List<String> vl = new ArrayList<String>();
		for (String n : name) {
			switch (row.getDataType(n)) {
				case STRING:
					vl.add(row.getString(n));
					break;
				case BOOLEAN:
					vl.add(String.valueOf(row.getBoolean(n)));
					break;
				case DATE:
					MCDate dv = row.getDate(n);
					vl.add(dv != null ? dv.toString() : null);
					break;
				case TIMESTAMP:
					MCTimestamp tv = row.getTimestamp(n);
					vl.add(tv != null ? tv.toString() : null);
					break;
				case NUMBER:
					MCNumber nv = row.getNumber(n);
					vl.add(nv != null ? nv.toSimpleString() : null);
					break;
				default:
					break;
			}
		}
		return vl;
	}
	
	/**
	 * リソースに保存されているテンプレート情報を削除します。
	 * <p>
	 * 
	 * 指定された画面の全てのテンプレート情報を削除します。
	 * <p>
	 * 
	 * テンプレート情報を削除するだけの場合は、引数saveにtrueを指定してください。
	 * テンプレート情報の削除と更新をする場合は、削除、更新の順番に処理を行ってください。
	 * 引数saveにfalseを指定してテンプレート情報を削除してください。そして、
	 * {@link #writeResource(IfTmplBase, List, boolean)} 
	 * でテンプレート情報を更新してください。
	 * この順番で処理を実行することで、リソース情報のDBテーブルへの保存処理（通信処理）の回数を減らすことができます。
	 * 
	 * @param panel　画面
	 * @param save 削除した後に保存する場合は true、保存しない場合は false
	 */
	public static void removeResource(IfTmplBase panel, boolean save) {
		_util._removeResource(panel, save);
	}
	
	/**
	 * リソースに保存されているテンプレート情報を削除します。
	 * <p>
	 * 
	 * 指定された画面の全てのテンプレート情報を削除します。
	 * <p>
	 * 
	 * テンプレート情報を削除するだけの場合は、引数saveにtrueを指定してください。
	 * テンプレート情報の削除と更新をする場合は、削除、更新の順番に処理を行ってください。
	 * 引数saveにfalseを指定してテンプレート情報を削除してください。そして、
	 * {@link #writeResource(IfTmplBase, List, boolean)} 
	 * でテンプレート情報を更新してください。
	 * この順番で処理を実行することで、リソース情報のDBテーブルへの保存処理（通信処理）の回数を減らすことができます。
	 * 
	 * @param panel　画面
	 * @param save 削除した後に保存する場合は true、保存しない場合は false
	 */
	protected void _removeResource(IfTmplBase panel, boolean save) {
		String pk = _createTmplKey(panel);
		_getResource().remove(pk);
		
		String[] ka = _getResource().findPattern(pk + ".**");
		_getResource().remove(ka);

		if (save) {
			MCConst.saveUser();
		}
	}

	/**
	 * リソースに保存されているテンプレート情報を削除します。
	 * <p>
	 * 
	 * 指定されたTmplInfoのテンプレート情報を削除します。
	 * <p>
	 * 
	 * テンプレート情報を削除するだけの場合は、引数saveにtrueを指定してください。
	 * テンプレート情報の削除と更新をする場合は、削除、更新の順番に処理を行ってください。
	 * 引数saveにfalseを指定してテンプレート情報を削除してください。そして、
	 * {@link #writeResource(IfTmplBase, List, boolean)} 
	 * でテンプレート情報を更新してください。
	 * この順番で処理を実行することで、リソース情報のDBテーブルへの保存処理（通信処理）の回数を減らすことができます。
	 * 
	 * @param panel 画面
	 * @param info 削除対象のテンプレート情報
	 * @param save 削除した後に保存する場合は true、保存しない場合は false
	 */
	public static void removeResource(
			IfTmplBase panel, List<TmplInfo> info, boolean save) {
		_util._removeResource(panel, info, save);
	}
	
	/**
	 * リソースに保存されているテンプレート情報を削除します。
	 * <p>
	 * 
	 * 指定されたTmplInfoのテンプレート情報を削除します。
	 * <p>
	 * 
	 * テンプレート情報を削除するだけの場合は、引数saveにtrueを指定してください。
	 * テンプレート情報の削除と更新をする場合は、削除、更新の順番に処理を行ってください。
	 * 引数saveにfalseを指定してテンプレート情報を削除してください。そして、
	 * {@link #writeResource(IfTmplBase, List, boolean)} 
	 * でテンプレート情報を更新してください。
	 * この順番で処理を実行することで、リソース情報のDBテーブルへの保存処理（通信処理）の回数を減らすことができます。
	 * 
	 * @param panel 画面
	 * @param info 削除対象のテンプレート情報
	 * @param save 削除した後に保存する場合は true、保存しない場合は false
	 */
	protected void _removeResource(
			IfTmplBase panel, List<TmplInfo> info, boolean save) {
		String pk = _createTmplKey(panel);
		
		for (TmplInfo i : info) {
			String id = i.getSettingInfoID();
			if (!isNull(id)) {
				String k = MCConst.createKey(pk, id);
				_getResource().remove(k);
				
				String[] ka = _getResource().findPattern(k + ".**");
				_getResource().remove(ka);
			}
		}

		if (save) {
			MCConst.saveUser();
		}
	}
	
	/**
	 * リソースに保存されているテンプレート情報をTmplInfoのリストにして返します。
	 * <p>
	 * 
	 * 取得するテンプレート情報は下記の通りです。
	 * <p>
	 * 
	 * <table border="1">
	 * <tr><th>テンプレート情報</th><th>メソッド名</th></tr>
	 * <tr><td>設定情報ＩＤ</td><td> {@link TmplInfo#getSettingInfoID()} </td></tr>
	 * <tr><td>設定情報名</td><td> {@link TmplInfo#getSettingInfoName()} </td></tr>
	 * <tr><td>備考</td><td> {@link TmplInfo#getRemark()} </td></tr>
	 * <tr><td>無効フラグ</td><td> {@link TmplInfo#getIgnoreFlg()} </td></tr>
	 * <tr><td>ポップアップ表示フラグ</td><td> {@link TmplInfo#getShowPopupFlg()} </td></tr>
	 * <tr><td>テンプレートデータのリスト</td><td> {@link TmplInfo#getTmplDataList()} </td></tr>
	 * </table>
	 * <p>
	 * 
	 * 取得するテンプレートデータは下記の通りです。
	 * <p>
	 * 
	 * <table border="1">
	 * <tr><th>テンプレートデータ</th><th>メソッド名</th></tr>
	 * <tr><td>枠名</td><td> {@link TmplData#getPanelName()} </td></tr>
	 * <tr><td>コンテナ</td><td> {@link TmplData#getContainer()} </td></tr>
	 * </table>
	 * 
	 * @param panel 画面
	 * @return テンプレート情報
	 */
	protected List<TmplInfo> _readResource(IfTmplBase panel) {
		List<TmplInfo> l = _readTmplInfoResource(panel);
		_readTmplDataResource(panel, l);
		return l;
	}

	/**
	 * リソースに保存されているテンプレート情報をTmplInfoのリストにして返します。
	 * <p>
	 * 
	 * 取得するテンプレート情報は下記の通りです。
	 * <ul>
	 * <li>設定情報ＩＤ</li>
	 * <li>設定情報名</li>
	 * <li>備考</li>
	 * <li>無効フラグ</li>
	 * <li>ポップアップ表示フラグ</li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @return リソースに保存されているテンプレート情報
	 */
	protected List<TmplInfo> _readTmplInfoResource(IfTmplBase panel) {
		List<TmplInfo> l = new ArrayList<TmplInfo>();
		
		String pk = _createTmplKey(panel);
		String[] ka = _getResource().findPattern(pk + ".*");
		
		for (String k : ka) {
			String id = k.substring(pk.length() + 1);
			if (!id.startsWith(_setting_info_id_prefix)) {
				continue;
			}
			
			TmplInfo i = new TmplInfo();
			i.setSettingInfoID(id);
			
			String[] va = _getResource().getStringArrayKeyRotation(
					_getPgmId(panel), MCConst.createKey(k, _info));
			i.setSettingInfoName(isNull(va[0]) ? null : va[0]);
			i.setRemark(isNull(va[1]) ? null : va[1]);
			i.setIgnoreFlg(Boolean.valueOf(va[2]));
			i.setShowPopupFlg(Boolean.valueOf(va[3]));
			
			l.add(i);
		}
		
		return l;
	}
	
	/**
	 * 指定されたTmplInfoの設定情報ＩＤを使用して、リソースに保存されているテンプレート情報を取得します。
	 * 取得した情報を指定されたTmplInfoに格納します。
	 * <p>
	 * 
	 * 取得するテンプレート情報は下記の通りです。
	 * <ul>
	 * <li>枠名</li>
	 * <li>コンテナ</li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param info TmplInfoのリスト
	 */
	protected void _readTmplDataResource(
			IfTmplBase panel, List<TmplInfo> info) {
		String tk = _createTmplKey(panel);
		
		String p = _getPgmId(panel);
		
		for (TmplInfo f : info) {
			List<TmplData> l = new ArrayList<TmplData>();
			
			String k = MCConst.createKey(tk, f.getSettingInfoID(), _data);
			List<String> vl = new ArrayList<String>();
			vl.addAll(Arrays.asList(
					_getResource().getStringArrayKeyRotation(p, k)));
			
			while (vl.size() != 0) {
				TmplData d = new TmplData();

				String y = vl.remove(0);					// コンテナの種類
				
				d.setPanelName(vl.remove(0));				// 枠名

				int cc = Integer.parseInt(vl.remove(0).substring(
						_column_count_prefix.length()));	// カラム数
				String[] na = new String[cc];				// カラム名の配列
				for (int i = 0; i < cc; i++) {
					na[i] = vl.remove(0);
				}
				String[] da = new String[cc];				// データ型の配列
				for (int i = 0; i < cc; i++) {
					da[i] = vl.remove(0);
				}

				if (_row.equals(y)) {
					MCRow o = MCRow.create();
					_setValues(o, na, da, vl.toArray(new String[vl.size()]));
					for (int i = 0; i < na.length; i++) {
						vl.remove(0);
					}
					d.setContainer(o);
				}
				else if (_list.equals(y)) {
					MCList<MCRow> ol = MCList.create(MCRow.class);
					for (int i = 0; i < na.length; i++) {
						switch (MCDataType.valueOf(da[i])) {
							case STRING:
								ol.addStringColumn(na[i]);
								break;
							case BOOLEAN:
								ol.addBooleanColumn(na[i]);
								break;
							case DATE:
								ol.addDateColumn(na[i]);
								break;
							case TIMESTAMP:
								ol.addTimestampColumn(na[i]);
								break;
							case NUMBER:
								ol.addNumberColumn(na[i]);
								break;
							default:
								break;
						}
					}
					
					int oc = Integer.parseInt(vl.remove(0).substring(
							_row_count_prefix.length()));	// 行数
					for (int i = 0; i < oc; i++) {
						MCRow o = ol.createRow();
						_setValues(o, 
								na, da, vl.toArray(new String[vl.size()]));
						for (int j = 0; j < na.length; j++) {
							vl.remove(0);
						}
						
						ol.add(o);
					}
					
					d.setContainer(ol);
				}

				l.add(d);
			}

			f.setTmplDataList(l);
		}
	}
	
	/**
	 * MCRowのカラムに値を設定します。
	 * 
	 * @param proto MCRow
	 * @param names カラム名の配列
	 * @param types データ型の配列
	 * @param values 値の配列
	 */
	protected void _setValues(
			MCRow row, String[] names, String[] types, String[] values) {
		for (int i = 0; i < names.length; i++) {
			String n = names[i];
			String v = values[i];
			
			switch (MCDataType.valueOf(types[i])) {
				case STRING:
					row.setStringNE(n, isNull(v) ? null : v);
					break;
				case BOOLEAN:
					row.setBooleanNE(n, Boolean.valueOf(v));
					break;
				case DATE:
					row.setDateNE(names[i], isNull(v) ? 
							null : MCDate.valueOf(
									v, MCDate.TO_STRING_FORMAT));
					break;
				case TIMESTAMP:
					row.setTimestampNE(names[i], isNull(v) ? 
							null : MCTimestamp.valueOf(
									v, MCTimestamp.TO_STRING_FORMAT));
					break;
				case NUMBER:
					row.setNumberNE(n, isNull(v) ? null :  MCNumber.valueOf(v));
					break;
				default:
					break;
			}
		}
	}
		
	/**
	 * リソースに保存されているテンプレート情報を検索します。
	 * リソースに保存されているテンプレート情報から検索条件に該当する情報を抽出して返します。
	 * <p>
	 * 
	 * 検索条件として評価する項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>設定情報ＩＤ<br>
	 * 設定情報ＩＤが指定されている場合は、指定された設定情報ＩＤと一致するテンプレート情報を検索します。
	 * 設定情報ＩＤを指定する場合は {@link TmplInfo#setSettingInfoID(String)} を使用してください。
	 * </li>
	 * <li>設定情報名<br>
	 * 設定情報名が指定されている場合は、指定された設定情報名と一致するテンプレート情報を検索します。
	 * 設定情報名を指定する場合は {@link TmplInfo#setSettingInfoName(String)} を使用してください。
	 * </li>
	 * <li>備考<br>
	 * 備考が指定されている場合は、指定された備考と一致するテンプレート情報を検索します。
	 * 備考を指定する場合は {@link TmplInfo#setRemark(String)} を使用してください。
	 * </li>
	 * <li>無効フラグ<br>
	 * 無効フラグが指定されている場合は、指定された無効フラグと一致するテンプレート情報を検索します。
	 * 無効フラグを指定する場合は {@link TmplInfo#setIgnoreFlg(Boolean)} を使用してください。
	 * </li>
	 * <li>ポップアップ表示フラグ<br>
	 * ポップアップ表示フラグが指定されている場合は、指定されたポップアップ表示フラグと一致するテンプレート情報を検索します。
	 * ポップアップ表示フラグを指定する場合は {@link TmplInfo#setShowPopupFlg(Boolean)} を使用してください。
	 * </li>
	 * <li>テンプレートデータ<br>
	 * テンプレートデータが指定されている場合は、指定されたテンプレートデータと一致するテンプレート情報を検索します。
	 * テンプレートデータを指定する場合は {@link TmplInfo#setTmplDataList(List)} を使用してください。
	 * <p>
	 * 
	 * 検索条件として評価するテンプレートデータの項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>枠名<br>
	 * 検索条件に指定された枠名と枠名が一致するテンプレートデータを探します。
	 * 枠名が一致するテンプレートデータが見つかった場合は、コンテナの値が検索条件と一致するかどうかの評価を行います。
	 * 枠名が一致するテンプレートデータが見つからなかった場合は、指定されたテンプレートデータを無視します。
	 * </li>
	 * <li>コンテナ<br>
	 * 枠名が一致するテンプレートデータが見つかった場合は、検索条件に指定されたコンテナとカラムの値が一致するテンプレートデータを探します。
	 * <p>
	 * 
	 * <font color="red">
	 * 検索条件のコンテナはMCRowを指定してください。MCListを指定した場合は無視します。
	 * </font>
	 * 
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param cnd 検索条件
	 * @return テンプレート情報
	 */
	public static List<TmplInfo> searchResource(IfTmplBase panel, TmplInfo cnd) {
		return _util._searchResource(panel, cnd);
	}
	
	/**
	 * リソースに保存されているテンプレート情報を検索します。
	 * リソースに保存されているテンプレート情報から検索条件に該当する情報を抽出して返します。
	 * <p>
	 * 
	 * 検索条件として評価する項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>設定情報ＩＤ<br>
	 * 設定情報ＩＤが指定されている場合は、指定された設定情報ＩＤと一致するテンプレート情報を検索します。
	 * 設定情報ＩＤを指定する場合は {@link TmplInfo#setSettingInfoID(String)} を使用してください。
	 * </li>
	 * <li>設定情報名<br>
	 * 設定情報名が指定されている場合は、指定された設定情報名と一致するテンプレート情報を検索します。
	 * 設定情報名を指定する場合は {@link TmplInfo#setSettingInfoName(String)} を使用してください。
	 * </li>
	 * <li>備考<br>
	 * 備考が指定されている場合は、指定された備考と一致するテンプレート情報を検索します。
	 * 備考を指定する場合は {@link TmplInfo#setRemark(String)} を使用してください。
	 * </li>
	 * <li>無効フラグ<br>
	 * 無効フラグが指定されている場合は、指定された無効フラグと一致するテンプレート情報を検索します。
	 * 無効フラグを指定する場合は {@link TmplInfo#setIgnoreFlg(Boolean)} を使用してください。
	 * </li>
	 * <li>ポップアップ表示フラグ<br>
	 * ポップアップ表示フラグが指定されている場合は、指定されたポップアップ表示フラグと一致するテンプレート情報を検索します。
	 * ポップアップ表示フラグを指定する場合は {@link TmplInfo#setShowPopupFlg(Boolean)} を使用してください。
	 * </li>
	 * <li>テンプレートデータ<br>
	 * テンプレートデータが指定されている場合は、指定されたテンプレートデータと一致するテンプレート情報を検索します。
	 * テンプレートデータを指定する場合は {@link TmplInfo#setTmplDataList(List)} を使用してください。
	 * <p>
	 * 
	 * 検索条件として評価するテンプレートデータの項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>枠名<br>
	 * 検索条件に指定された枠名と枠名が一致するテンプレートデータを探します。
	 * 枠名が一致するテンプレートデータが見つかった場合は、コンテナの値が検索条件と一致するかどうかの評価を行います。
	 * 枠名が一致するテンプレートデータが見つからなかった場合は、指定されたテンプレートデータを無視します。
	 * </li>
	 * <li>コンテナ<br>
	 * 枠名が一致するテンプレートデータが見つかった場合は、検索条件に指定されたコンテナとカラムの値が一致するテンプレートデータを探します。
	 * <p>
	 * 
	 * <font color="red">
	 * 検索条件のコンテナはMCRowを指定してください。MCListを指定した場合は無視します。
	 * </font>
	 * 
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param cnd 検索条件
	 * @return テンプレート情報
	 */
	protected List<TmplInfo> _searchResource(IfTmplBase panel, TmplInfo cnd) {
		List<TmplInfo> l = _searchTmplInfoResource(panel, cnd);
		_searchTmplDataResource(panel, cnd, l);
		return l;
	}
	
	/**
	 * リソースに保存されているテンプレート情報を検索します。
	 * リソースに保存されているテンプレート情報から検索条件に該当する情報を抽出して返します。
	 * <p>
	 * 
	 * 検索条件として評価する項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>設定情報ＩＤ<br>
	 * 設定情報ＩＤが指定されている場合は、指定された設定情報ＩＤと一致するテンプレート情報を検索します。
	 * 設定情報ＩＤを指定する場合は {@link TmplInfo#setSettingInfoID(String)} を使用してください。
	 * </li>
	 * <li>設定情報名<br>
	 * 設定情報名が指定されている場合は、指定された設定情報名と一致するテンプレート情報を検索します。
	 * 設定情報名を指定する場合は {@link TmplInfo#setSettingInfoName(String)} を使用してください。
	 * </li>
	 * <li>備考<br>
	 * 備考が指定されている場合は、指定された備考と一致するテンプレート情報を検索します。
	 * 備考を指定する場合は {@link TmplInfo#setRemark(String)} を使用してください。
	 * </li>
	 * <li>無効フラグ<br>
	 * 無効フラグが指定されている場合は、指定された無効フラグと一致するテンプレート情報を検索します。
	 * 無効フラグを指定する場合は {@link TmplInfo#setIgnoreFlg(Boolean)} を使用してください。
	 * </li>
	 * <li>ポップアップ表示フラグ<br>
	 * ポップアップ表示フラグが指定されている場合は、指定されたポップアップ表示フラグと一致するテンプレート情報を検索します。
	 * ポップアップ表示フラグを指定する場合は {@link TmplInfo#setShowPopupFlg(Boolean)} を使用してください。
	 * </li>
	 * </ul>
	 * <p>
	 * 
	 * 検索結果として返す項目は下記の通りです。
	 * <p>
	 * <ul>
	 * <li>設定情報ＩＤ</li>
	 * <li>設定情報名</li>
	 * <li>備考</li>
	 * <li>無効フラグ</li>
	 * <li>ポップアップ表示フラグ</li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param cnd 検索条件
	 * @return テンプレート情報
	 */	
	public static List<TmplInfo> searchTmplInfoResource(
			IfTmplBase panel, TmplInfo cnd) {
		return _util._searchTmplInfoResource(panel, cnd);
	}
	
	/**
	 * リソースに保存されているテンプレート情報を検索します。
	 * リソースに保存されているテンプレート情報から検索条件に該当する情報を抽出して返します。
	 * <p>
	 * 
	 * 検索条件として評価する項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>設定情報ＩＤ<br>
	 * 設定情報ＩＤが指定されている場合は、指定された設定情報ＩＤと一致するテンプレート情報を検索します。
	 * 設定情報ＩＤを指定する場合は {@link TmplInfo#setSettingInfoID(String)} を使用してください。
	 * </li>
	 * <li>設定情報名<br>
	 * 設定情報名が指定されている場合は、指定された設定情報名と一致するテンプレート情報を検索します。
	 * 設定情報名を指定する場合は {@link TmplInfo#setSettingInfoName(String)} を使用してください。
	 * </li>
	 * <li>備考<br>
	 * 備考が指定されている場合は、指定された備考と一致するテンプレート情報を検索します。
	 * 備考を指定する場合は {@link TmplInfo#setRemark(String)} を使用してください。
	 * </li>
	 * <li>無効フラグ<br>
	 * 無効フラグが指定されている場合は、指定された無効フラグと一致するテンプレート情報を検索します。
	 * 無効フラグを指定する場合は {@link TmplInfo#setIgnoreFlg(Boolean)} を使用してください。
	 * </li>
	 * <li>ポップアップ表示フラグ<br>
	 * ポップアップ表示フラグが指定されている場合は、指定されたポップアップ表示フラグと一致するテンプレート情報を検索します。
	 * ポップアップ表示フラグを指定する場合は {@link TmplInfo#setShowPopupFlg(Boolean)} を使用してください。
	 * </li>
	 * </ul>
	 * <p>
	 * 
	 * 検索結果として返す項目は下記の通りです。
	 * <p>
	 * <ul>
	 * <li>設定情報ＩＤ</li>
	 * <li>設定情報名</li>
	 * <li>備考</li>
	 * <li>無効フラグ</li>
	 * <li>ポップアップ表示フラグ</li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param cnd 検索条件
	 * @return テンプレート情報
	 */	
	protected List<TmplInfo> _searchTmplInfoResource(
			IfTmplBase panel, TmplInfo cnd) {
		// 設定情報を読み込む
		List<TmplInfo> l = _readTmplInfoResource(panel);
		
		if (cnd != null) {
			// 設定情報で絞り込む
			// 検索条件に設定情報が指定されている場合のみ絞り込む
			boolean e1 = !isNull(cnd.getSettingInfoID());
			boolean e2 = !isNull(cnd.getSettingInfoName());
			boolean e3 = !isNull(cnd.getRemark());
			boolean e4 = !isNull(cnd.getIgnoreFlg());
			boolean e5 = !isNull(cnd.getShowPopupFlg());
			if (e1 || e2 || e3 || e4 || e5) {
				for (TmplInfo i : l.toArray(new TmplInfo[l.size()])) {
					if (e1 && !isLike(
							i.getSettingInfoID(), cnd.getSettingInfoID())) {
						l.remove(i);
						continue;
					}
					if (e2 && !isLike(
							i.getSettingInfoName(), cnd.getSettingInfoName())) {
						l.remove(i);
						continue;
					}
					if (e3 && !isLike(i.getRemark(), cnd.getRemark())) {
						l.remove(i);
						continue;
					}
					if (e4 && !cnd.getIgnoreFlg().equals(i.getIgnoreFlg())) {
						l.remove(i);
						continue;
					}
					if (e5 && !cnd.getShowPopupFlg().equals(i.getShowPopupFlg())) {
						l.remove(i);
						continue;
					}
				}
			}
		}
		
		return l;
	}
	
	/**
	 * 指定されたTmplInfoのリストを検索します。
	 * 指定されたTmplInfoのリストから検索条件に該当しないTmplInfoを削除します。
	 * <p>
	 * 
	 * 検索条件として評価する項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>テンプレートデータ<br>
	 * テンプレートデータが指定されている場合は、指定されたテンプレートデータと一致するテンプレート情報を検索します。
	 * テンプレートデータを指定する場合は {@link TmplInfo#setTmplDataList(List)} を使用してください。
	 * <p>
	 * 
	 * 検索条件として評価するテンプレートデータの項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>枠名<br>
	 * 検索条件に指定された枠名と枠名が一致するテンプレートデータを探します。
	 * 枠名が一致するテンプレートデータが見つかった場合は、コンテナの値が検索条件と一致するかどうかの評価を行います。
	 * 枠名が一致するテンプレートデータが見つからなかった場合は、指定されたテンプレートデータを無視します。
	 * </li>
	 * <li>コンテナ<br>
	 * 枠名が一致するテンプレートデータが見つかった場合は、検索条件に指定されたコンテナとカラムの値が一致するテンプレートデータを探します。
	 * <p>
	 * 
	 * <font color="red">
	 * 検索条件のコンテナはMCRowを指定してください。MCListを指定した場合は無視します。
	 * </font>
	 * 
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param cnd 検索条件
	 * @param info 検索対象のTmplInfoのリスト
	 * @return テンプレート情報
	 */	
	public static void searchTmplDataResource(
			IfTmplBase panel, TmplInfo cnd, List<TmplInfo> info) {
		_util._searchTmplDataResource(panel, cnd, info);
	}
	
	/**
	 * 指定されたTmplInfoのリストを検索します。
	 * 指定されたTmplInfoのリストから検索条件に該当しないTmplInfoを削除します。
	 * <p>
	 * 
	 * 検索条件として評価する項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>テンプレートデータ<br>
	 * テンプレートデータが指定されている場合は、指定されたテンプレートデータと一致するテンプレート情報を検索します。
	 * テンプレートデータを指定する場合は {@link TmplInfo#setTmplDataList(List)} を使用してください。
	 * <p>
	 * 
	 * 検索条件として評価するテンプレートデータの項目は下記の通りです。
	 * <p>
	 * 
	 * <ul>
	 * <li>枠名<br>
	 * 検索条件に指定された枠名と枠名が一致するテンプレートデータを探します。
	 * 枠名が一致するテンプレートデータが見つかった場合は、コンテナの値が検索条件と一致するかどうかの評価を行います。
	 * 枠名が一致するテンプレートデータが見つからなかった場合は、指定されたテンプレートデータを無視します。
	 * </li>
	 * <li>コンテナ<br>
	 * 枠名が一致するテンプレートデータが見つかった場合は、検索条件に指定されたコンテナとカラムの値が一致するテンプレートデータを探します。
	 * <p>
	 * 
	 * <font color="red">
	 * 検索条件のコンテナはMCRowを指定してください。MCListを指定した場合は無視します。
	 * </font>
	 * 
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param panel 画面
	 * @param cnd 検索条件
	 * @param info 検索対象のTmplInfoのリスト
	 * @return テンプレート情報
	 */	
	protected void _searchTmplDataResource(
			IfTmplBase panel, TmplInfo cnd, List<TmplInfo> info) {
		// テンプレートデータを読み込む
		_readTmplDataResource(panel, info);

		// 検索条件にテンプレートデータが指定されていない場合は絞り込まない
		if (cnd == null) {
			return;
		}
		List<TmplData> cl = cnd.getTmplDataList();
		if (cl == null || cl.size() == 0) {
			return;
		}
		
		for (TmplInfo i : info.toArray(new TmplInfo[info.size()])) {
			for (TmplData c : cl) {
				if (!(c.getContainer() instanceof MCRow)) {
					continue;
				}
				
				TmplData d = _getTmplData(
						c.getPanelName(), i.getTmplDataList());
				if (d == null) {
					continue;
				}

				MCRow co = (MCRow)c.getContainer();
				List<String> nl = _getEnableColumnNameList(co);
				for (String n : nl.toArray(new String[nl.size()])) {
					if (MCDataType.BOOLEAN.equals(co.getDataType(n))) {
						if (!co.getBoolean(n)) {
							nl.remove(n);
						}
					}
					else if (isNull(co.getValue(n))) {
						nl.remove(n);
					}
				}

				if (nl.size() == 0) {
					continue;
				}
				
				if (d.getContainer() instanceof MCRow) {
					MCRow o = (MCRow) d.getContainer();
					if (!_isMatch(co, o, nl)) {
						info.remove(i);
						break;
					}
				}
				else if (d.getContainer() instanceof MCList<?>) {
					boolean e = false;
					
					MCList<?> ol = (MCList<?>)d.getContainer();
					for (MCRow o : ol) {
						if (_isMatch(co, o, nl)) {
							e = true;
							break;
						}
					}

					if (!e) {
						info.remove(i);
						break;
					}
				}
			}
		}

	}
	
	/**
	 * 指定されたTmplDataのリストから枠名が指定された枠名と一致するTmplDataを探して返します。
	 * <p>
	 * 
	 * TmplDataが見つからなかった場合は null を返します。
	 * 
	 * @param name 枠名
	 * @param list TmplDataのリスト
	 * @return TmplDataまたは null
	 */
	protected TmplData _getTmplData(String name, List<TmplData> list) {
		if (list == null) {
			return null;
		}
		
		for (TmplData d : list) {
			if (isSame(name, d.getPanelName())) {
				return d;
			}
		}
		return null;
	}
	
	/**
	 * 指定されたデータコンテナが指定された検索条件と一致するかどうかを判断します。
	 * 検索条件と一致すると判断された場合は true を返します。
	 * 
	 * @param cnd 検索条件
	 * @param data データコンテナ
	 * @param name 評価するカラム名のリスト
	 * @return 検索条件と一致しないと判断された場合は false
	 */
	protected boolean _isMatch(MCRow cnd, MCRow data, List<String> name) {
		if (name == null) {
			return true;
		}
		
		for (String n : name) {
			MCDataType y = data.getDataType(n);
			if (y != null) {
				switch (y) {
					case STRING:
						if (!isLike(data.getString(n), cnd.getString(n))) {
							return false;
						}
						break;
					default:
						if (!isSame(data.getValue(n), cnd.getValue(n))) {
							return false;
						}
						break;
				}
			}
		}
		return true;
	}
	
	/**
	 * テンプレート情報を設定、取得するためのリソースを返します。
	 * 
	 * @return リソース
	 */
	protected MCGeneralPersonalizeResource _getResource() {
		return MCConst.app;
	}
	
	/**
	 * プログラムＩＤを返します。
	 * 
	 * @param panel 画面
	 * @return プログラムＩＤ
	 */
	protected String _getPgmId(IfTmplBase panel) {
		return MCConst.createKey(panel.getModuleID(), panel.getScreenID());
	}
	
	/**
	 * テンプレート情報を設定、取得ことを表すリソースキーを作成します。
	 * 
	 * @param panel 画面
	 * @return リソースキー
	 */
	protected String _createTmplKey(IfTmplBase panel) {
		return MCConst.createKey(
				panel.getModuleID(), panel.getScreenID(), _p_tmpl);
	}

}