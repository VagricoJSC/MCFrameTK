package mcframe.clientFXUC.FXUCP0080;

import java.util.List;

public class TmplInfo_FW {
	
	/**
	 * 設定情報ＩＤです。
	 */
	protected String _setting_info_id = null;
	
	/**
	 * 設定情報名です。
	 */
	protected String _setting_info_name = null;
	
	/**
	 * 備考です。
	 */
	protected String _remark = null;
	
	/**
	 * 無効フラグです。
	 */
	protected Boolean _ignore_flg = null;
	
	/**
	 * ポップアップ表示フラグです。
	 */
	protected Boolean _show_popup_flg = null;
	
	/**
	 * テンプレートデータのリストです。
	 */
	protected List<TmplData> _tmpl_data_list = null;
	
	/**
	 * コンストラクタです。
	 */
	public TmplInfo_FW() {}

	/**
	 * 設定情報ＩＤを設定します。
	 * 
	 * @param id 設定情報ＩＤ
	 */
	public void setSettingInfoID(String id) {
		_setting_info_id = id;
	}
	
	/**
	 * 設定情報ＩＤを返します。<p>
	 * 設定情報ＩＤが設定されていない場合は null を返します。
	 * 
	 * @return　設定情報ＩＤ、または null
	 */
	public String getSettingInfoID() {
		return _setting_info_id;
	}
	
	/**
	 * 設定情報名を設定します。
	 * 
	 * @param name 設定情報名
	 */
	public void setSettingInfoName(String name) {
		_setting_info_name = name;
	}
	
	/**
	 * 設定情報名を返します。<p>
	 * 設定情報名が設定されていない場合は null を返します。
	 * 
	 * @return 設定情報名、または null
	 */
	public String getSettingInfoName() {
		return _setting_info_name;
	}
	
	/**
	 * 備考を設定します。
	 *
	 * @param remark 備考
	 */
	public void setRemark(String remark) {
		_remark = remark;
	}
	
	/**
	 * 備考を返します。<p>
	 * 備考が設定されていない場合は null を返します。
	 *
	 * @return 備考、または null
	 */
	public String getRemark() {
		return _remark;
	}

	/**
	 * 無効フラグを設定します。
	 * 
	 * @param flg 無効フラグ
	 */
	public void setIgnoreFlg(Boolean flg) {
		_ignore_flg = flg;
	}
	
	/**
	 * 無効フラグを返します。<p>
	 * 無効フラグが設定されていない場合は null を返します。
	 * 
	 * @return 無効フラグ、または null
	 */
	public Boolean getIgnoreFlg() {
		return _ignore_flg;
	}
	
	/**
	 * ポップアップ表示フラグを設定します。
	 * 
	 * @param flg ポップアップ表示フラグ
	 */
	public void setShowPopupFlg(Boolean flg) {
		_show_popup_flg = flg;
	}
	
	/**
	 * ポップアップ表示フラグを返します。<p>
	 * ポップアップ表示フラグが設定されていない場合は null を返します。
	 * 
	 * @return ポップアップ表示フラグ、または null
	 */
	public Boolean getShowPopupFlg() {
		return _show_popup_flg;
	}
	
	/**
	 * テンプレートデータのリストを設定します。
	 * 
	 * @param list テンプレートデータのリスト
	 */
	public void setTmplDataList(List<TmplData> list) {
		_tmpl_data_list = list;
	}
	
	/**
	 * テンプレートデータのリストを返します。
	 * 
	 * @return テンプレートデータのリスト
	 */
	public List<TmplData> getTmplDataList() {
		return _tmpl_data_list;
	}
	
}