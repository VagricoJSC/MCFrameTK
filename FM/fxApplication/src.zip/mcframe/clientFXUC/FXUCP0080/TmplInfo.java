package mcframe.clientFXUC.FXUCP0080;

public class TmplInfo extends TmplInfo_FW {
	
	/**
	 * コンストラクタです。
	 */
	public TmplInfo() {}
	
}