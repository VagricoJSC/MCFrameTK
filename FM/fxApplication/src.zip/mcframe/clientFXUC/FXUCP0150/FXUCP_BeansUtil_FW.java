package mcframe.clientFXUC.FXUCP0150;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase.*;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListConfig;
import static mcframe.commonFX.notice.FX_Msg.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_BeansUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_BeansUtil_FW extends FXUCP_BeansUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	private static FXUCP_BeansUtil _BeansUtil = new FXUCP_BeansUtil();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_BeansUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// ///////////////////////////////////////////////
	// ユーティリティ（ここから）
	// ///////////////////////////////////////////////
	/**
	 * MCBeansの配列からMCRowBeansの配列を取得する
	 *
	 * @param beans MCBeansの配列
	 * @return MCRowBeansの配列
	 */
	public static MCRowBeans[] getMCRowBeans(MCBeans... beans) {
		if (beans == null) {
			return null;
		}
		List<MCBeans> l = new ArrayList<MCBeans>();
		for (int i = 0; i < beans.length; i++) {
			if (beans[i] instanceof MCRowBeans) {
				l.add(beans[i]);
			}
		}
		return l.toArray(new MCRowBeans[0]);
	}

	/**
	 * MCBeansの配列からMCColumnConfigの配列を取得する
	 *
	 * @param beans MCBeansの配列
	 * @return MCColumnConfigの配列
	 */
	public static MCColumnConfig[] getMCColumnConfig(MCBeans... beans) {
		if (beans == null) {
			return null;
		}
		List<MCBeans> l = new ArrayList<MCBeans>();
		for (int i = 0; i < beans.length; i++) {
			if (beans[i] instanceof MCColumnConfig) {
				l.add(beans[i]);
			}
		}
		return l.toArray(new MCColumnConfig[0]);
	}

	// ///////////////////////////////////////////////
	// ユーティリティ（ここまで）
	// ///////////////////////////////////////////////

	// ///////////////////////////////////////////////
	// 値の取得（ここから）
	// ///////////////////////////////////////////////

	/**
	 * MCBeansから値を取得する<br>
	 * MCRowBeans/MCColumnConfigに対応している<br>
	 * それ以外のBeansの場合はnullを返す<br>
	 * MCColumnConfigである場合は選択行の値を返す（選択行が取得できない場合はnullを返す）
	 *
	 * @param beans 値を取得する
	 * @return MCBeansの値
	 */
	public static Comparable<?> getValueOf(MCBeans beans) {
		return _BeansUtil._getValueOf(beans);
	}

	/**
	 * MCBeansから値を取得する<br>
	 * MCRowBeans/MCColumnConfigに対応している<br>
	 * それ以外のBeansの場合はnullを返す<br>
	 * MCColumnConfigである場合は選択行の値を返す（選択行が取得できない場合はnullを返す）
	 *
	 * @param beans 値を取得する
	 * @return MCBeansの値
	 */
	protected Comparable<?> _getValueOf(MCBeans beans) {

		if (beans instanceof MCRowBeans) {
			return ((MCRowBeans) beans).getRowValue();
		}
		if (beans instanceof MCColumnConfig) {
			MCColumnConfig config = (MCColumnConfig) beans;
			MCTable<?> tbl = config.getTable();
			if (tbl != null) {
				MCRow row = tbl.getSelectedMCRow();
				if (row != null) {
					return row.getValue(config.getRowColumnName());
				}
			}
		}
		return null;
	}

	// ///////////////////////////////////////////////
	// 値の取得（ここまで）
	// ///////////////////////////////////////////////

	// ///////////////////////////////////////////////
	// 初期表示するためのメソッド（ここから）
	// [初期表示の規則]
	// 結果が1件の場合、それを表示する。
	// 複数件の場合は基本的に表示しない。ただし次の場合は表示させる。
	// １、リストに初期表示項目($DEF_FLG)カラムの値がtrueのものがある場合
	// ２、setDefaultValueの引数colsにbooleanのカラム名を設定した場合
	// ///////////////////////////////////////////////

	/**
	 * 初期表示用Rowを取得し、setValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を MCLinkBeansに設定します。ただし、結果が１件の場合はそれを表示します。
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(MCRow row)
	 *
	 * 値のsetは
	 * @param c MCLinkBeans
	 * @param cols booleanのカラム
	 *
	 */
	public static void setDefaultValue(MCLinkBeans c, String... cols) {
		_BeansUtil._setDefaultValue(c, cols);

	}

	/**
	 * 初期表示用Rowを取得し、<b>引数idxの行の</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 * 上記の場合でも、ステータス s と一致しない場合は表示しません。
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(int index, MCRow row)
	 *
	 * @param c 明細コンボ
	 * @param idx パネル行index
	 * @param s ステータス
	 * @param cols booleanのカラム
	 */
	public static void setDefaultValue(MCColumnConfig c, int idx, Status[] s,
			String... cols) {
		_BeansUtil._setDefaultValue(c, idx, s, cols);
	}

	/**
	 * 初期表示用Rowを取得し、<b>引数idxの行の</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(int index, MCRow row)
	 *
	 * @param c 明細コンボ
	 * @param idx パネル行index
	 * @param cols booleanのカラム
	 */
	public static void setDefaultValue(MCColumnConfig c, int idx, String... cols) {
		_BeansUtil._setDefaultValue(c, idx, cols);
	}

	/**
	 * 初期表示用Rowを取得し、<b>すべての行の</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 * 上記の場合でも、ステータス s と一致しない場合は表示しません。
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(int index, MCRow row)
	 *
	 * @param c 明細コンボ
	 * @param s ステータス
	 * @param cols booleanのカラム
	 */
	public static void setDefaultValue(MCColumnConfig c, Status[] s, String... cols) {
		_BeansUtil._setDefaultValue(c, s, cols);
	}

	/**
	 * 初期表示用Rowを取得し、<b>選択されている</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(int index, MCRow row)
	 *
	 * @param c 明細コンボ
	 * @param cols booleanのカラム
	 */
	public static void setDefaultValue(MCColumnConfig c, String... cols) {
		_BeansUtil._setDefaultValue(c, cols);
	}

	/**
	 * 初期表示用Rowを取得し、MCLinkBeansにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を MCLinkBeansに設定します。ただし、結果が１件の場合はそれを表示します。
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(MCRow row)
	 *
	 * @param c MCLinkBeans
	 * @param cols booleanのカラム
	 *
	 */
	@SuppressWarnings("unchecked")
	//MCListのジェネリクス
	protected void _setDefaultValue(MCLinkBeans c, String... cols) {
		MCRow r = getDispRow(c.doListEvent(MCListConfig.LIST), cols);
		setValueEx(c, r);

	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */

	// getValueの X へのキャスト
	protected void setValueEx(MCLinkBeans bean, MCRow r) {
		MCRow org = ((MCRowBeans) bean).getRow();
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValues(r);
			handleSetValueMessageList(bean, r, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValues(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	protected void handleSetValueMessageList(MCLinkBeans bean, MCRow r, MCMessageList msg) {
		if (0 < msg.size()) {
			MCAppException e = new MCAppException(FXBAP0059);
			e.setCauseMessageList(msg);
			throw e;
		}
	}

	/**
	 * 初期表示用Rowを取得し、<b>引数idxの行の</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 * 上記の場合でも、ステータス s と一致しない場合は表示しません。
	 *
	 * @see mcframe.clientCore.beans.list.MCLinkBeans#setValues(int index, MCRow row)
	 *
	 * @param c 明細コンボ
	 * @param idx パネル行index
	 * @param s ステータス
	 * @param cols booleanのカラム
	 */
	@SuppressWarnings("unchecked")
	//MCListのジェネリクス
	protected void _setDefaultValue(MCColumnConfig c, int idx, Status[] s, String... cols) {

		if (null == s
				|| containsStatus(c.getBaseTable().getSelectedMCRow().getStatus(), s)) {

			MCRow r = getDispRow(c.doListEvent(MCListConfig.LIST, idx), cols);

			if (0 <= idx) {
				setValuesEx(c, idx, r);
			}
		}
	}

	/**
	 * 値を設定します。 引数で指定された行に値を設定します。
	 * 値がセットできない場合は例外を発生させます。
	 *
	 *
	 * @param bean 値を設定するBeans
	 * @param idx 対象の行
	 * @param val 設定する値
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, int, Comparable, MCMessageList)
	 */
	public void setValuesEx(MCColumnConfig bean, int idx, MCRow val) {
		Comparable<?> org = bean.getValue(idx);
		try {
			// 例外処理をしているので setValuesEx を使わない
			MCMessageList msg = bean.setValues(idx, val);
			handleSetValueMessageList(bean, idx, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(idx, org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	protected void handleSetValueMessageList(MCColumnConfig bean, int idx, MCRow r,
			MCMessageList msg) {
		if (msg.size() > 0) {
			MCAppException ae = new MCAppException(FXBAP0059);
			ae.setCauseMessageList(msg);
			throw ae;
		}
	}

	/**
	 * 初期表示用Rowを取得し、<b>引数idxの行の</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 *
	 * @param c 明細コンボ
	 * @param idx パネル行index
	 * @param cols booleanのカラム
	 */
	protected void _setDefaultValue(MCColumnConfig c, int idx, String... cols) {
		Status[] s = null;
		_setDefaultValue(c, idx, s, cols);

	}

	/**
	 * 初期表示用Rowを取得し、<b>すべての行の</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 * 上記の場合でも、ステータス s と一致しない場合は表示しません。
	 *
	 * @param c 明細コンボ
	 * @param s ステータス
	 * @param cols booleanのカラム
	 */
	protected void _setDefaultValue(MCColumnConfig c, Status[] s, String... cols) {
		for (int idx = 0; idx < c.getBaseTable().getRowCount(); idx++)
			_setDefaultValue(c, idx, s, cols);
	}

	/**
	 * 初期表示用Rowを取得し、<b>選択されている</b>明細コンボにsetValues()で設定します。
	 * <p>
	 * 引数colsには、booleanのカラム名を指定できます。<br>
	 * カラム名を指定した場合、それらのカラムがすべてtrueの行を表示します。<br>
	 * ただし、結果が１件の場合はそれを表示します。<br>
	 *
	 * @param c 明細コンボ
	 * @param cols booleanのカラム
	 */
	protected void _setDefaultValue(MCColumnConfig c, String... cols) {
		int idx = c.getBaseTable().getMCSelectedRow();
		_setDefaultValue(c, idx, cols);
	}

	/**
	 * ステータス配列cond 内に ステータス rsと一致するものがあればtrueを返します。
	 * @param rs ステータス
	 * @param ステータスの配列
	 */
	protected boolean containsStatus(Status rs, Status[] cond) {

		for (Status cs : cond) {
			if (rs == cs) {
				return true;
			}
		}
		return false;

	}

	/**
	 * 初期表示するRowを返します。
	 * <p>
	 * 次の仕様に従いRowを返します。
	 * <li>件数が１件の場合はそれを返す。</li>
	 * <li>カラム名 colsが指定されていない場合、初期表示項目($DEF_FLG)カラムがtrueのRowを返す。</li>
	 * <li>colsが指定されている場合、それらのカラムが全てtrueのRowを返す。</li>
	 * <li>複数のRowが初期表示対象のRowである場合、始めに見つけたRowを返す。</li>
	 * </P>
	 * <P>
	 * 次の場合はnullを返します。
	 * <li>初期表示対象のRowが見つからない場合。</li>
	 * <li>条件のカラムが見つからない場合。</li>
	 * <li>条件のカラムが1つでもbooleanでない場合。</li>
	 * </P>
	 */
	protected MCRow getDispRow(MCList<MCRow> lst, String... cols) {

		MCRow down = null;

		if (lst == null || lst.size() <= 0) return null;
		if (lst.size() == 1) return lst.get(0);

		/* colsが指定されていない場合の処理 */
		if (cols.length <= 0) {

			if (isBooleanColumns(lst, $DEF_FLG)) {
				down = lst.getFirst($DEF_FLG, true);
			}
		}
		/* colsが指定されている場合の処理 */
		else {
			boolean b = true;
			for (String col : cols) {
				if (!isBooleanColumns(lst, col)) {
					b = false;
					break;
				}
			}
			if (b) {
				down = getColsTrueRow(lst, cols);
			}
		}

		return down;
	}

	/* 条件のカラムのチェック */
	protected boolean isBooleanColumns(MCList<MCRow> lst, String col) {
		if (0 < lst.size()) {
			return MCDataType.BOOLEAN.equals(lst.get(0).getDataType(col));

		}
		return false;
	}

	/** colsのカラムデータが全てtrueのRowを返します。 */
	protected MCRow getColsTrueRow(MCList<MCRow> lst, String... cols) {

		MCRow down = null;
		boolean f = false;
		for (MCRow r : lst) {
			for (String c : cols) {
				if (r.getBoolean(c)) {
					f = true;
				}
				else {
					f = false;
					break;
				}
			}
			if (f) {
				down = r;
				break;
			}
		}
		return down;
	}

	// ///////////////////////////////////////////////
	// 初期表示するためのメソッド（ここまで）
	// ///////////////////////////////////////////////

}