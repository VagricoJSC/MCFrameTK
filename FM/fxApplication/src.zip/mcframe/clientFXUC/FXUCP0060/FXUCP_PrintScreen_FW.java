package mcframe.clientFXUC.FXUCP0060;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Arrays;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import mcframe.commonCore.util.MCCollectionUtil;

import javax.imageio.ImageIO;

import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.sys.MCSys;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_PrintScreen"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_PrintScreen_FW extends FXUCP_PrintScreen_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_PrintScreen_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// 目次
	// 画像を取得する
	// 画像をファイルに保存する
	// 画像をクリップボードに保存する

	private static FXUCP_PrintScreen _me;

	protected static FXUCP_PrintScreen me() {
		if (_me == null) {
			_me = new FXUCP_PrintScreen();
		}
		return _me;
	}

	// 画像を取得する（ここから）
	/**
	 * 外部からよびだされた内容を保存するためのログ
	 */
	protected void argLog(Component comp) {
		String className = null;
		String compName = null;
		String compLocationOnScreen = null;
		String compSize = null;
		if (comp != null) {
			className = comp.getClass().getName();
			compName = comp.getName();
			compLocationOnScreen = comp.getLocationOnScreen().toString();
			compSize = comp.getSize().toString();
		}
		MCLog.write(FXUCP0016, className, compName, compLocationOnScreen, compSize);
	}

	/**
	 * 指定された領域の画面イメージを返します。
	 */
	protected BufferedImage _printScreen(Rectangle rect) {
		if (rect == null) return null;
		Robot robot;
		try {
			robot = new Robot();
		}
		catch (AWTException e) {
			String trace = MCLog.stackTrace(e);
			throw new MCAppException(FXUCP0002, trace);
		}
		BufferedImage image;
		if (rect.getWidth() <= 0 || rect.getHeight() <= 0) {
			image = null;
		}
		else {
			image = robot.createScreenCapture(rect);
		}
		return image;

	}

	/**
	 * 指定されたパネルの画面イメージを返します
	 */
	public static BufferedImage printScreen(MCRootPanel compo) {
		me().argLog(compo);
		return me()._printScreen(compo);
	}

	/**
	 * 指定されたパネルの画面イメージを返します
	 */
	protected BufferedImage _printScreen(MCRootPanel compo) {
		if (compo == null) {
			return null;
		}

		MCFrame frame = compo.getFrame();
		Rectangle rect;
		if (frame != null) {
			rect = new Rectangle(frame.getLocationOnScreen(), frame.getSize());
		}
		else {
			rect = new Rectangle(compo.getLocationOnScreen(), compo.getSize());
		}
		return _printScreen(rect);
	}

	// 画像を取得する（ここまで）
	// 画像をファイルに保存する（ここから）
	/** ファイル名に使えない文字 */
	private char[] _taboos;

	/** ファイル名に使えない文字 */
	protected char[] taboos() {
		// メモ：':'を一番初めに ':' を持ってくると、
		// 例外メッセージで使用する ':' と見分けが
		// 付かなくなるので、それ以後にする
		if (_taboos == null) {
			_taboos = new char[] {
					'?', '"', '<', '>', '|', ':'
			};
		}
		return _taboos;
	}

	/**
	 * 画像データをファイルに保存します。
	 * 
	 * @param image 出力する画像データ
	 * @param formatName 画像ファイルの種類。{@link ImageIO#getWriterFormatNames}に指定されているもののどれか。
	 *            （BMP, jpeg, bmp, wbmp, png, JPG, PNG, jpg, WBMP, JPEG）
	 * @param fileName 出力ファイル名
	 */
	protected void _save(RenderedImage image, String formatName, String fileName) {
		File file = new File(fileName);
		String name = file.getName();
		// 禁止文字列のチェック
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
			for (char t : taboos()) {
				if (c == t) {
					String taboos = Arrays.toString(taboos());
					taboos = taboos.substring(1, taboos.length() - 1);
					throw new MCAppException(FXUCP0004, name, taboos);
				}
			}
		}

		if (file.exists()) {
			// ファイルが存在している場合、ファイルが上書き可能かチェックする
			if (!file.canWrite()) {
				throw new MCAppException(FXUCP0005, name);
			}
			else {
				// メモ：上書き確認とかしてあげても良いかも

				// 空のファイルで上書きをしてみることで他アプリケーションが
				// ロックしているかどうかをチェックする
				BufferedWriter r = null;
				try {
					FileOutputStream o = new FileOutputStream(file.getAbsoluteFile());
					r = new BufferedWriter(new OutputStreamWriter(o));
				}
				catch (Throwable e) {
					throw new MCAppException(FXUCP0006, name);
				}
				finally {
					if (r != null) {
						try {
							r.close();
						}
						catch (IOException e) {
							MCLog.write(e);
						}
					}
				}
			}
		}
		else {
			// 出力先フォルダを作る
			File dir = new File(file.getParent());
			if (dir.exists()) {
				// 既にフォルダがある
			}
			else {
				if (dir.mkdirs() == false) {
					throw new MCAppException(FXUCP0009, dir.getAbsolutePath());
				}
			}
			// ファイルを一度作ってみる（書き込み権限がないフォルダを指定されていないかのチェック）
			BufferedWriter r = null;
			try {
				FileOutputStream o = new FileOutputStream(file.getAbsoluteFile());
				r = new BufferedWriter(new OutputStreamWriter(o));
			}
			catch (Throwable e) {
				throw new MCAppException(FXUCP0010, dir.getAbsolutePath());
			}
			finally {
				if (r != null) {
					try {
						r.close();
					}
					catch (IOException e) {
						MCLog.write(e);
					}
				}
			}
		}

		if (MCCollectionUtil.contains(formatName, ImageIO.getWriterFormatNames()) == false) {
			String t = Arrays.toString(ImageIO.getWriterFormatNames());
			t = t.substring(1, t.length() - 1);
			throw new MCAppException(FXUCP0008, formatName, t);
		}

		try {
			ImageIO.write(image, formatName, file);
		}
		catch (IOException e) {
			String trace = MCLog.stackTrace(e);
			throw new MCAppException(FXUCP0007, name, trace);
		}
		MCLog.write(FXUCP0011, file.getAbsolutePath());
	}

	/**
	 * パネルの画像をファイルに出力します。<br>
	 * 
	 * @return 出力できた場合 true それ以外false（ScreenShotの対象が取得できない場合などfalse）
	 */
	public static boolean printScreenToFile(MCRootPanel compo, String formatName,
			String fileName) {
		me().argLog(compo);
		return me()._printScreenToFile(compo, formatName, fileName);
	}

	/**
	 * パネルの画像をファイルに出力します。<br>
	 * 
	 * @param formatName 画像ファイルの種類。{@link ImageIO#getWriterFormatNames}に指定されているもののどれか。
	 *            （BMP, jpeg, bmp, wbmp, png, JPG, PNG, jpg, WBMP, JPEG）
	 * @param fileName 出力ファイル名
	 * @return 出力できた場合 true それ以外false（ScreenShotの対象が取得できない場合などfalse）
	 */
	protected boolean _printScreenToFile(MCRootPanel compo, String formatName,
			String fileName) {
		boolean ret = false;
		BufferedImage image = _printScreen(compo);
		if (image != null) {
			_save(image, formatName, fileName);
			ret = true;
		}
		return ret;
	}

	/**
	 * 指定されたパネルの画像をファイルに出力します。<br>
	 * 出力先のファイルは設定ファイルから取得します。
	 * 
	 * @return 出力したファイルのファイル名)(出力できなかった場合null)
	 */
	public static String printScreenToFile(MCRootPanel compo) {
		me().argLog(compo);
		return me()._printScreenToFile(ROOT_PANEL, compo);
	}

	/**
	 * 指定されたパネルの画像をファイルに出力します。<br>
	 * 出力先のファイルは設定ファイルから取得します。
	 * 
	 * @return 出力したファイルのファイル名)(出力できなかった場合null)
	 */
	protected String _printScreenToFile(String tag, MCRootPanel compo) {
		if (compo == null) {
			return null;
		}
		String fileName = _getFileNameFromResource(tag, compo);
		String formatName = _getFormatNameFromResource(tag);
		String ret = null;
		if (_printScreenToFile(compo, formatName, fileName)) {
			ret = fileName;
		}
		return ret;
	}

	/** リソース取得の際に使用する */
	protected static final String XUP0200_SCREEN_ID = "FXUCP0060";

	/** リソース取得の際に使用する */
	protected static final String XUP0200_MODULE_ID = "FX";

	/** リソース取得の際に使用する */
	protected static final String ROOT_PANEL = "ROOT_PANEL";

	/** リソース取得の際に使用する */
	protected static final String DESK_TOP = "DESK_TOP";

	/** リソース取得の際に使用する */
	protected static final String FILE_NAME = "FILE_NAME";

	/** リソース取得の際に使用する */
	protected static final String FORMAT_NAME = "FORMAT_NAME";
	
	/** リソース取得の際に使用する */
	protected static final String FOOTER_STR = "FOOTER_STR";

	/** リソース取得の際に使用する */
	protected static final String HEADER_STR = "HEADER_STR";
	
	/** リソース取得の際に使用する */
	protected static final String PRINT_OUT = "PRINT_OUT";
	
	protected String _getFileNameFromResource(String tag, MCRootPanel compo) {
		String key = MCConst.createKey(XUP0200_MODULE_ID, XUP0200_SCREEN_ID, tag,
				FILE_NAME);
		String str = getResource(key);
		return convStr(str, compo);
	}

	protected String _getFileNameFromResource(String tag) {
		String key = MCConst.createKey(XUP0200_MODULE_ID, XUP0200_SCREEN_ID, tag,
				FILE_NAME);
		String str = getResource(key);
		return convStr(str, null);
	}

	protected String _getFormatNameFromResource(String tag) {
		String key = MCConst.createKey(XUP0200_MODULE_ID, XUP0200_SCREEN_ID, tag,
				FORMAT_NAME);
		String str = getResource(key);
		return str;
	}
	
	protected String _getFooterFromResource(MCRootPanel compo) {
		String key = MCConst.createKey(XUP0200_MODULE_ID, XUP0200_SCREEN_ID, PRINT_OUT,
				FOOTER_STR);
		String str = getResource(key);
		return convStr(str, compo);
	}

	protected String _getHeaderFromResource(MCRootPanel compo) {
		String key = MCConst.createKey(XUP0200_MODULE_ID, XUP0200_SCREEN_ID, PRINT_OUT,
				HEADER_STR);
		String str = getResource(key);
		return convStr(str, compo);
	}

	protected String getResource(String key) {
		if (MCConst.app.containsKey(key) == false) {
			throw new MCAppException(FXUCP0013, key);
		}
		String str = MCConst.app.getString(key);
		if (str == null) {
			throw new MCAppException(FXUCP0014, key);
		}
		else {
			MCLog.write(FXUCP0015, key, str);
		}
		return str;
	}

	/** 正規表現の中で正規表現のルールを使わない箇所の始まり */
	protected final String SKIP_REGEX_ST = "\\Q";

	/** 正規表現の中で正規表現のルールを使わない箇所の終わり */
	protected final String SKIP_REGEX_END = "\\E";

	/**
	 * 指定された予約語をデータに置き換える
	 * <P>
	 * 事前条件
	 * <li> src != null</li>
	 * </P>
	 */
	protected String convStr(String src, MCRootPanel p) {
		String dest = src;
		MCDate dt = new MCDate();
		String[][] convStr = new String[][] {
				{
						"{yyyy}", dt.toString("yyyy")
				}, {
						"{MM}", dt.toString("MM")
				}, {
						"{dd}", dt.toString("dd")
				}, {
						"{HH}", dt.toString("HH")
				}, {
						"{mm}", dt.toString("mm")
				}, {
						"{ss}", dt.toString("ss")
				}, {
						"{SSS}", dt.toString("SSS")
				}, {
						"{USER}", MCSys.user.ID()
				}, {
						"{clientID}", MCSys.user.clientID()
				}, {
						"{moduleID}", p == null ? "" : p.getModuleID()
				}, {
						"{submoduleID}", p == null ? "" : p.getSubmoduleID()
				}, {
						"{screenID}", p == null ? "" : p.getScreenID()
				}, {
						"{screenName}", p == null ? "" : p.getScreenName()
				}, {
						"{MCF_HOME}", MCSys.env.MCF_HOME()
				}
		};
		for (String[] s : convStr) {
			dest = dest.replaceAll(SKIP_REGEX_ST + s[0] + SKIP_REGEX_END, s[1]);
		}
		return dest;
	}

	// 画像をファイルに保存する（ここまで）
	
	// 画像を印刷（ここから）
	
	/**
	 * 指定されたパネルの画像をプリンタで印刷します
	 * 
	 * @return 出力できた場合 true それ以外false（ScreenShotの対象が取得できない場合などfalse）
	 */
	protected boolean _printScreenToPrinter(MCRootPanel compo) {
		boolean ret = false;
		BufferedImage image = _printScreen(compo);
		String headerStr = _getHeaderFromResource(compo);
		String footerStr = _getFooterFromResource(compo);
		if (image != null) {
			PrinterJob pj = PrinterJob.getPrinterJob();
			PrintableImage pImage = new PrintableImage();

			pImage.setImage(image);
			pImage.setHeader(headerStr);
			pImage.setFooter(footerStr);

			pj.setPrintable(pImage);
			if (pj.printDialog()) {
				try {
					pj.print();
				}
				catch (Exception e) {
					MCException mainEx = new MCException(FXUCP0034 , e.getLocalizedMessage());
					mainEx.setStackTrace(e.getStackTrace());
					throw mainEx;
				}
				MCLog.write(FXUCP0035);
				ret = true;
			}
		}
		return ret;
	}

	/**
	 * 指定されたパネルの画像を印刷します
	 * 
	 * @return 出力できた場合 true それ以外false（ScreenShotの対象が取得できない場合などfalse）
	 */
	public static boolean printScreenToPrinter(MCRootPanel compo) {
		me().argLog(compo);
		return me()._printScreenToPrinter(compo);
	}
	
	/**
	 * 指定された画像を印刷する。
	 * 印刷対象の画像が１枚の紙に収まりきらない場合は、
	 * １枚に収まるように画像を縮小する。
	 * 印刷範囲は指定する必要がある。
	 */	
	public class PrintableImage implements Printable {
		/**
		 * スクリーンショットのイメージ
		 */
		private BufferedImage _image;

		/**
		 * スクリーンショットのイメージ
		 */
		protected BufferedImage getImage() {
			if(_image != null){
				return _image;
			}
			return null;
		}
		
		/**
		 * スクリーンキャプチャを撮る範囲を指定
		 */
		public void setImage(BufferedImage image) {
			_image = image;
		}
		
		/**
		 * ヘッダの文字列
		 */
		private String _headerStr;
		
		/**
		 * ヘッダの文字列
		 */
		protected String getHeaderStr() {
			return _headerStr;
		}
		/**
		 * ヘッダ文字列のセット
		 */
		public void setHeader(String str) {
			_headerStr = str;
		}
		
		/**
		 * フッタの文字列
		 */
		private String _footerStr;
		/**
		 * フッタの文字列
		 */
		protected String getFooterStr() {
			return _footerStr;
		}
		
		/**
		 * フッタの設定
		 */
		public void setFooter(String str) {
			_footerStr = str;
		}
		
		/**
		 * ヘッダが配置される x 座標
		 */
		protected int getHeaderX(PageFormat pf){
			return (int)pf.getImageableX() + 5;
		}
		/**
		 * イメージが配置される x 座標
		 */
		protected int getImageX(PageFormat pf){
			return getHeaderX(pf);
		}
		/**
		 * フッタが配置される x 座標
		 */
		protected int getFooterX(PageFormat pf){
			return getHeaderX(pf);
		}
		
		/**
		 * ヘッダが配置される y 座標
		 */
		protected int getHeaderY(PageFormat pf){
			return (int)pf.getImageableY() + 10;
		}
		/**
		 * イメージが配置される y 座標
		 */
		protected int getImageY(PageFormat pf){
			return getHeaderY(pf) + 20;
		}
		/**
		 * フッタが配置される y 座標
		 */
		protected int getFooterY(PageFormat pf){
			return (int)pf.getHeight() - 15;
		}
		
		/**
		 * イメージの最大横幅
		 */
		protected int getImageMaxWidth(PageFormat pf){
			int leftMergin = getImageX(pf);
			int rightMergin = leftMergin;
			return (int)pf.getWidth() - leftMergin - rightMergin;
		}
		/**
		 * イメージの最大縦幅
		 */
		protected int getImageMaxHeight(PageFormat pf){
			return getFooterY(pf) - getImageY(pf) - 5;
		}

		/**
		 * 印刷処理本体
		 */
		@Override
		public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
			if (page >= 1) {
				return Printable.NO_SUCH_PAGE;
			}
			Graphics2D g2 = (Graphics2D) g;
			BufferedImage image = getImage();

			// イメージのセット
			if (image != null) {
				double shrinkRate = 1.0;
				if (image.getWidth() > getImageMaxWidth(pf)) {
					shrinkRate = (double) getImageMaxWidth(pf)
							/ (double) image.getWidth();
				}
				if (image.getHeight() > getImageMaxHeight(pf)) {
					double tempRate = (double) getImageMaxHeight(pf)
							/ (double) image.getHeight();
					if (tempRate < shrinkRate) {
						shrinkRate = tempRate;
					}
				}

				if (shrinkRate < 1) {
					g2.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
							RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
					g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
							RenderingHints.VALUE_ANTIALIAS_ON);
					g2.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
							RenderingHints.VALUE_COLOR_RENDER_QUALITY);
					g2.setRenderingHint(RenderingHints.KEY_DITHERING,
							RenderingHints.VALUE_DITHER_ENABLE);
					g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
							RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
					g2.setRenderingHint(RenderingHints.KEY_RENDERING,
							RenderingHints.VALUE_RENDER_QUALITY);
					g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
							RenderingHints.VALUE_INTERPOLATION_BILINEAR);
					g2.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
							RenderingHints.VALUE_FRACTIONALMETRICS_ON);
					g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,
							RenderingHints.VALUE_STROKE_NORMALIZE);

					int w = (int) (image.getWidth() * shrinkRate);
					int h = (int) (image.getHeight() * shrinkRate);
					g2.drawImage(image, getImageX(pf), getImageY(pf), w, h, null);
				}
				else {
					g2.drawImage(image, null, getImageX(pf), getImageY(pf));
				}
			}

			// ヘッダフッタ
			g.drawString(getHeaderStr(), getHeaderX(pf), getHeaderY(pf));
			g.drawString(getFooterStr(), getFooterX(pf), getFooterY(pf));

			return Printable.PAGE_EXISTS;
		}

	}
	// 画像を印刷（ここまで）
	
	// 画像をクリップボードに保存する（ここから）

	/**
	 * 指定されたパネルの画像をクリップボードにコピーします
	 * 
	 * @return 出力できた場合 true それ以外false（ScreenShotの対象が取得できない場合などfalse）
	 */
	public static boolean printScreenToClip(MCRootPanel compo) {
		me().argLog(compo);
		return me()._printScreenToClip(compo);
	}

	/**
	 * 指定されたパネルの画像をクリップボードにコピーします
	 * 
	 * @return 出力できた場合 true それ以外false（ScreenShotの対象が取得できない場合などfalse）
	 */
	protected boolean _printScreenToClip(MCRootPanel compo) {
		boolean ret = false;
		BufferedImage image = _printScreen(compo);
		if (image != null) {
			ImageTransferable imgClip = new ImageTransferable(image);
			Clipboard clp = Toolkit.getDefaultToolkit().getSystemClipboard();
			try {
				clp.setContents(imgClip, null);
			}
			catch (java.lang.IllegalStateException e) {
				// メモ：何らかの原因（多くは何かのプログラム（含むMCFrame以外のプログラム）の不具合）で
				// クリップボードが空にできない状況が発生する場合がある。
				// その時に以下の例外が発生する。
				// java.lang.IllegalStateException: cannot open system clipboard
				MCLog.write(e);
				throw new MCAppException(FXUCP0017);
			}
			MCLog.write(FXUCP0012);
			ret = true;
		}
		return ret;
	}

	/**
	 * クリップボードに画像を格納するためのクラス
	 */
	public class ImageTransferable implements Transferable {
		// イメージ
		Image _img;

		// データ形式
		DataFlavor[] _flvs;

		public ImageTransferable(Image img) {
			this._img = img;
			_flvs = new DataFlavor[1];
			_flvs[0] = new DataFlavor("image/x-java-image; class=java.awt.Image", "Image");
		}

		public DataFlavor[] getTransferDataFlavors() {
			return _flvs;
		}

		public boolean isDataFlavorSupported(DataFlavor flavor) {
			return _flvs[0].equals(flavor);
		}

		public Object getTransferData(DataFlavor flavor) {
			if (_flvs[0].equals(flavor)) {
				return _img;
			}
			throw new MCAppException(FXUCP0003, flavor, _flvs[0]);
		}

		public void lostOwnership(Clipboard clipboard, Transferable contents) {
		}
	}
	// 画像をクリップボードに保存する（ここまで）

}