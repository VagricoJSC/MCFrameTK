package mcframe.clientFXUC.FXUCP0030;

import java.util.List;

import mcframe.clientCore.beans.MCButton;

/**
 * 画面のヘッダーバーです。
 * このインタフェースのユーザは、mcframeアイコンボタンとツールバーを開くボタンの右に表示される、全画面共通のボタンや画面固有のボタンを定義できます。
 *
 * @author h-kawada  / Modifier：$Author$
 * @version   $Date:: 2022-07-27 $
 * @since     7.0.2
 * @see {@link FXUCP_GeneralLayout#createHeaderBarWest()}
 */
public interface IfHeaderBar_FW {

	/**
	 * ヘッダーバーに左詰めで表示する、画面固有のボタンのリストを返します。
	 * リスト中の並び順が、画面でのボタンの順番に対応します。
	 *
	 * @author    h-kawada
	 * @since     7.0.2
	 * @return 画面固有のボタンのリスト
	 */
	public List<MCButton> westHeaderBarItems();

}
