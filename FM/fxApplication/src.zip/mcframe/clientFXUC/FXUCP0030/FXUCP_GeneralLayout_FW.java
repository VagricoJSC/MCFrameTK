package mcframe.clientFXUC.FXUCP0030;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.ArrayList;
import java.util.List;

import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.plaf.metal.MCMetalLookAndFeel;
import mcframe.clientCore.beans.plaf.metal.MCTheme;
import mcframe.clientCore.beans.statusbar.MCStatusBar;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.*;

import java.util.Arrays;
import java.util.Comparator;

//import mcframe.clientCore.beans.layout.MCGeneralLayout;
import mcframe.clientCore.beans.layout.MCLayoutEventInfo;
import mcframe.clientCore.resource.MCConst;
import static mcframe.commonFX.notice.FX_Msg.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_GeneralLayout"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_GeneralLayout_FW extends FXUCP_GeneralLayout_FW_A {

	// カスタマイズのfieldはこの間に記述してください。
	// FMCB CUSTOM_FIELD START

	// FMCB CUSTOM_FIELD END

	// 自動生成クラスを手書きで修正しています（ここから）
	// /**
	// * コンストラクタです。通常の画面として作成するときに使用します。
	// */
	// public FXUCP_GeneralLayout_FW() {
	// super();
	// //コンストラクタのカスタマイズ処理はこの間に記述してください。
	// //FMCB CUSTOM_CONSTRUCTOR START
	//
	// //FMCB CUSTOM_CONSTRUCTOR END
	// }
	public FXUCP_GeneralLayout_FW(MCRootPanel panel) {
		super(panel);
	}

	// 画面処理メソッドはこれより下に定義してください。
	// FMCB CUSTOM_METHOD START
	// ユーティリティ
	// メイン
	// ツールバーを隠す対応
	// ツールバークラスの拡張
	// フォント比率変更対応

	// ユーティリティ（ここから）

	// ユーティリティ（ここまで）
	// メイン（ここから）
	/**
	 * ツールバー
	 */
	protected MCPanel _tBar;
	protected MCScrollPane _tBarScroll;

	/**
	 * 再レイアウト前処理メソッド
	 */
	@Override
	public void beforeRelayout() {
		super.beforeRelayout();
		// 7.0.1 ツールバーを隠さずに自動レイアウトできるように変更したためhideToolBarは不要。
//		// レイアウトの計算でツールバーが邪魔になるため隠す。
//		if(false) {
//			hideToolBar();
//		}
	}

	/**
	 * 再自動レイアウト
	 * @param useLayoutLocationForSortPolicy ソートポリシーを使用するかどうか
	 */
	@Override
	protected void relayout(boolean useLayoutLocationForSortPolicy) {
		super.relayout(useLayoutLocationForSortPolicy);
		_layout();
	}

	@Override
	public void layout() {
		super.layout();
		_layout();
	}

	protected void _layout() {
		if (!panel.isPartsPanel()) {
			if (_btnHide != null) {
				addToolBar();

				// フォント比率変更用に値を保存
				try {
					if (isToolbarAvailable()) {
						if(_default_pre_size == null) {
							int mgn = 15;//ボタンに余裕を持たせるためのマージン
							// 6.4.0 再レイアウトで_tBarの幅が膨張していくため加算しない。
							_default_pre_size = _tBar.getPreferredSize();
							_default_pre_size.width += mgn;
							// 701-00628 BEGIN
//							_default_pre_size.height = 0;
							// 701-00628 END
							_tBar.setPreferredSize(_default_pre_size);
						}
					}
				}
				catch (NullPointerException npe) {
					// log for JRW-5-016-07116(対応されたら try catch やめる)
					logForJRW_5_016_07116();
					throw npe;
				}
			}
		}
	}

	/**
	 * ツールバーを追加します。
	 */
	protected void addToolBar() {
		if (!isToolbarTargetPanel()) {
			return ;
		}
		if(_tBar == null) {
			_tBar = createToolBar();
			_tBar.isTabOrderChildPanel(false); // 7.0.1 タブ順制御
			_tBarScroll = new MCScrollPane("_tbarScroll");
			_tBarScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			_tBarScroll.getVerticalScrollBar().setPreferredSize(new Dimension(0,0));
			_tBarScroll.setViewportView(_tBar);
			panel.add(_tBarScroll, BorderLayout.WEST);
			_tBarScroll.setMinimumSize(new Dimension(_tBar.getWidth(), 0));
			setupToolBarPanel();
		} else {
			// toolbarを復活させる。
			if(isHideToolBar()) {
				doHide();
			} else {
				doShow();
			}
		}
	}

	private void logForJRW_5_016_07116() {
		StringBuilder sb = new StringBuilder();

		logForJRW_5_016_07116_loop(sb, "+", panel);
		MCLog.developDebug(sb.toString());
	}

	private void logForJRW_5_016_07116_loop(StringBuilder ans, String depth,
			Container comp) {
		ans.append(logForJRW_5_016_07116_string(depth, comp));
		for (Component c : comp.getComponents()) {
			if (c instanceof Container) {
				logForJRW_5_016_07116_loop(ans, depth + "+", (Container) c);
			}
			else if(c != null){
				ans.append(logForJRW_5_016_07116_string(depth, c));
			}
		}
	}

	private StringBuilder logForJRW_5_016_07116_string(String depth, Component comp) {
		StringBuilder sb = new StringBuilder(depth);
		try {
			sb.append("\t" + comp.getClass().getSimpleName());
			sb.append("\t" + comp.getX() + "\t" + comp.getY());
			sb.append("\t" + comp.getMaximumSize());
		}
		catch(NullPointerException e){
			sb.append("\t <<RAISE NPE!!>>");
		}
		sb.append("\n");
		return sb;
	}
	/**
	 * ツールバーを追加した分だけフレームを拡大します。
	 */
	protected void adjustFrameSize() {
		if (!isToolbarAvailable()) {
			return;
		}
		//frameサイズ調整
		MCFrame f = panel.getFrame();
		if (f != null) {
			Dimension pd = f.getSize();
			pd.width += _tBar.getPreferredSize().width;
			double gw = panel.getGraphicsConfiguration().getBounds().getWidth();

			if (gw < pd.width) {
				pd.width = Double.valueOf(gw).intValue();
			}
			f.setSize(pd);
		}
	}

	private List<IfToolbarBeansHolder>_toolbarItems = null;

	/**
	 * 以下の場合は、ツールバーを作成しない（実際はサイズが０の状態になる）
	 * <li>panelがIfToolBarを実装していない場合</li>
	 * <li>panel#toolBarItems の戻り値がnullまたはサイズが０の場合</li>
	 */
	protected void setupToolBarPanel() {
		if (panel instanceof IfToolBar) {
			IfToolBar tb = (IfToolBar) panel;
			List<IfToolbarBeansHolder> list1 = tb.toolBarItems();
			List<Component> list = convert(list1);
			if (list != null && list.size() > 0) {
				list.add(0, null);
				setupToolBarPanel(list, false);
			}
			_toolbarItems = list1; // 7.0.1
		}
	}

	// 再自動レイアウトでtoolbarのタブ順を再設定する。 7.0.1
	@Override
	protected void updateToolBarTabOrder() {
		if (panel instanceof IfToolBar) {
			IfToolBar tb = (IfToolBar) panel;
			if(_toolbarItems != null) {
				List<IfToolbarBeansHolder> list1 = _toolbarItems;
//				List<IfToolbarBeansHolder> list1 = tb.toolBarItems();
				List<Component> list = convert(list1);
				if (list != null && list.size() > 0) {
					list.add(0, null);
					setupToolBarPanel(list, true);
				}
			}
		}
	}

	public class IfToolbarBeansHolderComparator<E extends IfToolbarBeansHolder>
			implements Comparator<E> {

		@Override
		public int compare(E o1, E o2) {
			if (o2 == null) {
				if (o1 == null) {
					return 0;
				}
				return -1;
			}
			if (o1 == null) return 1;
			return o1.order() - o2.order();
		}
	}

	protected List<Component> convert(List<IfToolbarBeansHolder> list1) {
		IfToolbarBeansHolder[] list2 = new IfToolbarBeansHolder[list1.size()];
		list2 = list1.toArray(list2);
		Arrays.sort(list2, new IfToolbarBeansHolderComparator<IfToolbarBeansHolder>());

		List<Component> list = new ArrayList<Component>();

		for (IfToolbarBeansHolder beans : list2) {
			if (!beans.isIgnore()) {
				list.add(beans.comp());
			}
		}
		return list;
	}

	protected MCTabOrderBeans _dummy = new MCTabOrderBeans() {

		@Override
		public void setName(String name) {
		}

		@Override
		public String getName() {
			return null;
		}

		@Override
		public String getType() {
			return null;
		}

		@Override
		public String getMessageByLocale() {
			return null;
		}

		@Override
		public String getLabelByLocale() {
			return null;
		}

		@Override
		public MCRootPanel getRootPanel() {
			return null;
		}

		@Override
		public MCRootPanel getBaseRootPanel() {
			return null;
		}

		@Override
		public MCRootPanel getNearestRootPanel() {
			return null;
		}

		@Override
		public void localeChanged() {
		}

		@Override
		public void added() {
		}

		@Override
		public void removed() {
		}

		@Override
		public boolean equalsIgnoreCase(Component compo) {
			return false;
		}

		@Override
		public void initialized() {
		}

		@Override
		public void addAliasName(String alias, MCRootPanel panel) {
		}

		@Override
		public void setAliasName(String alias, MCRootPanel panel) {
		}

		@Override
		public void removeAliasName(MCRootPanel panel) {
		}

		@Override
		public void removeAliasNames() {
		}

		@Override
		public String getAliasName(MCRootPanel panel) {
			return null;
		}

		@Override
		public String[] getAliasNames() {
			return null;
		}

		@Override
		public void updateBounds(int ratio) {
		}

		@Override
		public void updateFontSize(int ratio) {
		}

		@Override
		public Dimension getDefaultSize() {
			return null;
		}

		@Override
		// 7.0.1
		public Rectangle getDefaultBounds() {
			return null;
		}

		@Override
		public void afterRequestFocus() {
		}

		@Override
		public void handle(Throwable t) {
		}

		@Override
		public void setMessageName(String name) {
		}

		@Override
		public String _getMessageName() {
			return null;
		}

		@Override
		public void setNextBeans(MCTabOrderBeans compo) {
		}

		@Override
		public MCTabOrderBeans getNextBeans() {
			return null;
		}

		@Override
		public boolean isFocusableByKeybord() {
			return false;
		}

		@Override
		public void insertNextBeans(MCTabOrderBeans compo) {
		}

		@Override
		public void insertPreviousBeans(MCTabOrderBeans compo) {
		}

		@Override
		public void setPreviousBeans(MCTabOrderBeans compo) {
		}

		@Override
		public MCTabOrderBeans getPreviousBeans() {
			return null;
		}

		@Override
		public void setTabOrderEnabled(boolean enabled) {
		}

		@Override
		public boolean isTabOrderEnabled() {
			return false;
		}

		@Override
		public JComponent getTargetComponent() {
			return null;
		}

		@Override
		public void setFocusable(boolean focusable) {
		}

		@Override
		public void setNextBeans(MCTabOrderBeans compo, int updateType) {
		}

		@Override
		public void insertNextBeans(MCTabOrderBeans compo, int updateType) {
		}

		@Override
		public void insertPreviousBeans(MCTabOrderBeans compo, int updateType) {
		}

	};

	protected void setupToolBarPanel(List<Component> compos, boolean isRelayout) {

		if (!isToolbarAvailable()) {
			return;
		}
		MCPanel toolBarPanel = _tBar;

		_btnHide.setFocusable(true);
//		_btnHide.insertNextBeans(toolBarPanel);

		List<Component>compos2 = compos;

		//toolbarpanelの中身
		MCTabOrderBeans lastTabBeans = null;
		for (Component compo : compos2) {
			if (compo == null) {
				if(isRelayout == false) {
					toolBarPanel.add(Box.createVerticalGlue());
				}
			}
			else {
				if(isRelayout == false) {
					toolBarPanel.add(compo);
				}
				if (compo instanceof MCTabOrderBeans) {
					MCTabOrderBeans tabBeans = (MCTabOrderBeans) compo;
					if (toolBarPanel.getFirstBeans() == null || toolBarPanel.getFirstBeans() == _dummy || lastTabBeans == null) {
						toolBarPanel.setFirstBeans(tabBeans);
						lastTabBeans = tabBeans;
					}
					else {
						//子コンポーネントの全てのタブ移動順をadd順に設定する
						if (tabBeans instanceof MCTabOrderBasis) {
							setTabOrderByAdd((MCTabOrderBasis)tabBeans);
						}
						tabBeans.setNextBeans(null);
						lastTabBeans.setNextBeans(tabBeans);
					}
					lastTabBeans = tabBeans;
				}
			}
		}

		if(isRelayout) {
			// タブ順を元に戻す。
			addToHeaderBarTabOrder(_westbar);
			addToHeaderBarTabOrder(_eastbar);
		} else {
			// 部品がないとタブ指定ができないため後処理にする。
			_btnHide.insertNextBeans(toolBarPanel);
		}

		//BoxLayoutで土台の枠の最大幅にするための設定
		setupToolBarCompParam(toolBarPanel, isRelayout);

		//ショートカットキーを画面にも反映する
		setToolBarFunctionKeyToRootPanel(toolBarPanel);
	}

	private void setTabOrderByAdd(MCTabOrderBasis t) {
		Container pc = (Container)t;
		MCTabOrderBeans last = null;
		for (Component c : pc.getComponents()) {
			if (c instanceof MCTabOrderBeans) {
				MCTabOrderBeans n = (MCTabOrderBeans)c;
				if (last == null ) {
					t.setFirstBeans(n);
				}
				else {
					last.setNextBeans(n);
				}
				last = n;
				if (c instanceof MCTabOrderBasis) {
					setTabOrderByAdd((MCTabOrderBasis) c);
				}
			}
		}
		t.setLastBeans(last);
	}

	/**
	 * 左配置時のサイズ設定と内容表示の設定
	 */
	protected void setupToolBarCompParam(JComponent jc, boolean isRelayout) {
		if(isRelayout == true) { // 7.0.1
			return;
		} else {
			if (jc instanceof MCButton || jc instanceof MCPanel) {
				jc.setPreferredSize(null);
				jc.setMaximumSize(new Dimension(Short.MAX_VALUE, Short.MAX_VALUE));
				jc.setAlignmentY(Component.CENTER_ALIGNMENT);
				jc.setAlignmentX(Component.CENTER_ALIGNMENT);
				for (Component b : jc.getComponents()) {
					JComponent c = (JComponent) b;
					setupToolBarCompParam(c, isRelayout);
				}
			}
		}
	}

	/**
	 * ツールバー上のボタンのファンクションキーを常に有効にします。
	 */
	private void setToolBarFunctionKeyToRootPanel(JComponent jc) {
		if (jc instanceof MCButton) {
			MCButton b = (MCButton) jc;
			setAnytimeFAction(b);
		}
		else if (jc instanceof MCPanel) {
			for (Component b : jc.getComponents()) {
				JComponent c = (JComponent) b;
				setToolBarFunctionKeyToRootPanel(c);
			}
		}
	}
	/**
	 * ツールバーに追加されているオブジェクトをすべて消去します。
	 * <P>
	 * </P>
	 */
	public void removeAll() {
		if (!isToolbarAvailable()) {
			return;
		}
		for (Component comp : _tBar.getComponents()) {
			_tBar.remove(comp);
			if (comp instanceof MCTabOrderBeans) {
				// tabOrderから削除
				removeFromTabOrder((MCTabOrderBeans) comp);
			}
		}

		_tBar.setFirstBeans(_dummy);
	}

	protected void removeFromTabOrder(MCTabOrderBeans tabOrdBean) {
		MCTabOrderBeans prevBean = tabOrdBean.getPreviousBeans();
		MCTabOrderBeans nextBean = tabOrdBean.getNextBeans();
		tabOrdBean.setNextBeans(null);
		if (prevBean != null) {
			prevBean.setNextBeans(nextBean);
		}
	}

	/**
	 * ツールバーに追加されているオブジェクトをすべて消去し, 再生成します。
	 */
	public void resetToolBarPanel() {
		removeAll();
		setupToolBarPanel();
	}

	protected static final int DEF_BTN_HEIGHT = 22;

	protected static final int DEF_BTN_WIDTH = 22;

	// メイン（ここまで）

	// ツールバーを隠す対応（ここから）
	/**
	 * ツールバーを隠す（実際には非常に細く表示する）かどうか
	 */
	private boolean _isHideToolBar = false;

	/**
	 * ツールバーを隠す（実際には非常に細く表示する）かどうか
	 */
	public boolean isHideToolBar() {
		return _isHideToolBar;
	}

	/**
	 * ツールバーを隠す（実際には非常に細く表示する）かどうかをセットする
	 */
	public void isHideToolBar(boolean isHide) {
		_isHideToolBar = isHide;
	}

	/**
	 * 「ツールバーを隠す」ボタン
	 */
	protected MCButton _btnHide;

	private void doHide() {
		if (!isHideToolBar()) {
			doHideToggle(false);
		}
	}
	private void doShow() {
		if (!isToolbarAvailable()) {
			return;
		}
		if (isHideToolBar()) {
			doHideToggle(false);
		}
	}
	private void doHideToggle() {
		doHideToggle(false);
	}

	private void doHideToggle(boolean isValidate) {
		if (!isToolbarAvailable()) {
			return;
		}
		boolean isHide = isHideToolBar();
		_tBarScroll.setVisible(isHide);
		allVisible(_tBar,isHide);
		String id = isHide ? FXUCP0029 : FXUCP0030;
		String msg = MCConst.message.getMessage(id);
		_btnHide.setToolTipText(msg);
		isHideToolBar(!isHide); // フラグの反転
		if(isValidate == true) {
			panel.validate();
		} else {
			panel.revalidate();
		}
	}

	/**
	 * ツールバーを強制的に隠します
	 * 6.4.0
	 */
	public void hideToolBar() {
		if (!isToolbarTargetPanel()) {
			return ;
		}
		if(_tBar != null) {
			if(_isHideToolBar == false) {
				doHideToggle(true);
			}
		}
	}

	/**
	 * ツールバーを強制的に開く
	 * 7.0.1
	 */
	public void showToolBar() {
		if (!isToolbarTargetPanel()) {
			return ;
		}
		if(_tBar != null) {
			if(_isHideToolBar == true) {
				doHideToggle(false);
			}
		}
	}

	private void allVisible(Component c, boolean isHide) {
		c.setVisible(isHide);
		if (c instanceof Container) {
			Container cc = (Container)c;
			for (Component c2 : cc.getComponents()){
				allVisible(c2, isHide);
			}
		}
	}

	@Override
	protected MCPanel createHeaderBarWest() {
		MCPanel west = super.createHeaderBarWest();
		if (isToolbarTargetPanel()) {

			List<MCButton> buttons = new ArrayList<>();
			addToolbarOpenButton(buttons);
			IfHeaderBar targetPanel = (IfHeaderBar) panel;
			buttons.addAll(targetPanel.westHeaderBarItems());

			// ヘッダーバーにボタンを追加
			for (MCButton button : buttons) {
				west.add(button);
				setBarTabOrder(west, button);
			}
		}
		return west;
	}

	private void addToolbarOpenButton(List<MCButton> buttons) {
		MCButton l = createHeaderButton("_open_tbar");
		_btnHide = l;
		l.setIcon("HBAR_TBAROPEN");
		l.setMode(MCMode.ENABLE);
		l.addAPListener((c, i) -> doHideToggle());
		buttons.add(l);
	}

	// ツールバーを隠す対応（ここまで）

	// ツールバークラスの拡張（ここから）

	/**
	 * ツールバーのファクトリメソッド
	 */
	public MCPanel createToolBar() {
		MCPanel t = new MCPanel("_tbar") {
			Color _b = MCConst.beans.getColor("toolbar.bg");
			Color _f = MCConst.beans.getColor("toolbar.fg");

			@Override
			public Color getBackground() {
				return _b;
			}
			@Override
			public Color getForeground() {
				return _f;
			}
		};
		t.setOpaque(true);
		BoxLayout blayout = new BoxLayout(t, BoxLayout.PAGE_AXIS);
		t.setLayout(blayout);
		Insets s = getMargin();
		if (s != null) {
			t.setBorder(BorderFactory.createEmptyBorder(0,s.left,0,s.right));
		}
		else {
			t.setBorder(BorderFactory.createEmptyBorder());
		}
		return t;
	}

	private boolean isToolbarAvailable() {
		return _tBar != null;
	}
	private boolean isToolbarTargetPanel() {
		return panel instanceof IfToolBar;
	}


	// ツールバークラスの拡張（ここまで）
	// フォント比率変更対応（ここから）

	/**
	 * ツールバーのデフォルト（100%）のサイズをストックする
	 */
	protected Dimension _default_pre_size = null;

	/**
	 * フォント比率変更メソッドの実装
	 */
	@Override
	public void fontRatioChange(MCLayoutEventInfo info) {
		if (panel.isPartsPanel()) {
			super.fontRatioChange(info);
		}
		else {

			// MCGeneralLayout#fontRatioChangeを実行する
			super.fontRatioChange(info);
			if (isToolbarAvailable()) {
				fontRatioChange(_tBar, info);
				if (!isHideToolBar()) {
					Dimension d = new Dimension(_default_pre_size);
	//				d.height = d.height * info.getPanelNewFontRatio() / 100;
					d.width = d.width * info.getPanelNewFontRatio() / 100;
					_tBar.setPreferredSize(d);
				}
				setupToolBarCompParam(_tBar, false);
			}
		}

	}

	@Override
	public void initialized() {
		super.initialized();
		if (MCConst.beans.getBoolean("toolbar.hide", false)) {
			doHide();
		}
		else {
			adjustFrameSize();
		}
	}

	protected void fontRatioChange(Container cont, MCLayoutEventInfo info) {
		int ratio = info.getPanelNewFontRatio();
		for (Component c : cont.getComponents()) {
			if (c instanceof MCBeans) {
				((MCBeans) c).updateFontSize(ratio);
				((MCBeans) c).updateBounds(ratio);

			} if (c instanceof Container) {
				fontRatioChange((Container) c, info);
			}
		}
	}

	// フォント比率変更対応（ここまで）

	// ツールバーを開くボタンを返す。
	@Override
	public MCButton getOpenTbarButton() {
		if(_westbar != null) {
			Component[] list = MCBeansUtil.getAllComponents(_westbar);
			for(Component c : list) {
				if(c instanceof MCButton) {
					if("_open_tbar".equals(c.getName())) {
						return (MCButton)c;
					}
				}
			}
		}
		return null;
	}
}