package mcframe.clientFXUC.FXUCP0030;
import mcframe.commonCore.annotation.EI;
@EI
public interface IfToolbarBeansHolder extends IfToolbarBeansHolder_FW{

}
