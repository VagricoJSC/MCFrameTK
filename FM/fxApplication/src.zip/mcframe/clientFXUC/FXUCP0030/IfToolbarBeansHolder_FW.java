package mcframe.clientFXUC.FXUCP0030;

import java.awt.Component;

public interface IfToolbarBeansHolder_FW {
	/**
	 * ツールバーに表示するコンポーネント
	 */
	public Component comp();

	/**
	 * ツールバーに表示するコンポーネント
	 */
	public void comp(Component comp);

	/**
	 * 表示順
	 */
	public int order();

	/**
	 * 表示順
	 */
	public void order(int order);
	
	/**
	 * 表示しない
	 */
	public boolean isIgnore();

	/**
	 * 表示しない
	 */
	public void isIgnore(boolean order);


}
