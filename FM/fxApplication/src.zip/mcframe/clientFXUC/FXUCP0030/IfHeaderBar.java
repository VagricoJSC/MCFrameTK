package mcframe.clientFXUC.FXUCP0030;

public interface IfHeaderBar extends IfHeaderBar_FW {

}
