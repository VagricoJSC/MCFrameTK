package mcframe.clientFXUC.FXUCP0030;

import java.util.List;
import java.util.ArrayList;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;

/**
 * 画面"FXUCP_GeneralLayout"パネルクラスです。<p>
 *
 * GeneralLayoutの拡張<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
abstract public class FXUCP_GeneralLayout_FW_A extends
		mcframe.clientCore.beans.layout.MCGeneralLayout {

	private static final String MODULE_ID = "FX";

	private static final String SUBMODULE_ID = "FXUC";

	private static final String SCREEN_ID = "FXUCP0030";

	public String getModuleID() {
		return MODULE_ID;
	}

	public String getSubmoduleID() {
		return SUBMODULE_ID;
	}

	public String getScreenID() {
		return SCREEN_ID;
	}

	// 自動生成クラスを手書きで修正しています（ここから）
	// /**
	// * コンストラクタです。通常の画面として作成するときに使用します。
	// */
	// public FXUCP_GeneralLayout_FW_A() {
	// }
	public FXUCP_GeneralLayout_FW_A(MCRootPanel panel) {
		super(panel);
	}

}