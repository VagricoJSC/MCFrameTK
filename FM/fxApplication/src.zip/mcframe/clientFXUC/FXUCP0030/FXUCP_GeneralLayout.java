// FMSE PANEL_EI
package mcframe.clientFXUC.FXUCP0030;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.commonCore.annotation.EI;

/**
 * 画面"FXUCP_GeneralLayout"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@EI
@SuppressWarnings("serial")
public class FXUCP_GeneralLayout extends FXUCP_GeneralLayout_FW {
	// 自動生成クラスを手書きで修正しています（ここから）
	// /**
	// * コンストラクタです。通常の画面として作成するときに使用します。
	// */
	// public FXUCP_GeneralLayout() {
	// super();
	// }
	public FXUCP_GeneralLayout(MCRootPanel panel) {
		super(panel);
	}
	// 自動生成クラスを手書きで修正しています（ここまで）

}