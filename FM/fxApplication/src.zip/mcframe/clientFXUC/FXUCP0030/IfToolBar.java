package mcframe.clientFXUC.FXUCP0030;
import mcframe.commonCore.annotation.EI;
@EI
public interface IfToolBar extends IfToolBar_FW{

}
