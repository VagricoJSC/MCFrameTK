package mcframe.clientFXUC.FXUCP0030;

import java.util.List;

public interface IfToolBar_FW {

	public List<IfToolbarBeansHolder> toolBarItems();

}
