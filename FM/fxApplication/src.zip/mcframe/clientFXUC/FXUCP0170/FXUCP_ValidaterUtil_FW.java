package mcframe.clientFXUC.FXUCP0170;

import mcframe.clientCore.beans.MCRowBeans;
import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonFXUC.FXUCC0170.FXUCC_ValidaterUtil;

/**
 * 項目チェックのユーティリティクラスです。
 */
public abstract class FXUCP_ValidaterUtil_FW extends FXUCC_ValidaterUtil {

	/**
	 * 自身のインスタンス
	 */
	private static FXUCP_ValidaterUtil _me;

	/**
	 * コンストラクタです。
	 */
	public FXUCP_ValidaterUtil_FW() {
		super();
	}

	protected static FXUCP_ValidaterUtil me() {
		if (_me == null) {
			_me = new FXUCP_ValidaterUtil();
		}
		return _me;
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param gui GUI部品
	 * @return FXUCC0046
	 */
	public static MCMessage msgNoDataAtReq(MCRowBeans gui) {
		return me()._msgNoDataAtReq(gui);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param gui GUI部品
	 * @return FXUCC0046
	 */
	protected MCMessage _msgNoDataAtReq(MCRowBeans gui) {
		return _msgNoDataAtReq(gui.getBaseRow(), gui.getBaseRowColumnName(),
				gui.getMessageByLocale());
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param conf カラムコンフィグ
	 * @return FXUCC0047
	 */
	public static MCMessage msgNoDataAtReq(MCRow causeRow, MCColumnConfig conf) {
		return me()._msgNoDataAtReq(causeRow, conf);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param causeRow 関連するRow
	 * @param conf カラムコンフィグ
	 * @return FXUCC0047
	 */
	protected MCMessage _msgNoDataAtReq(MCRow causeRow, MCColumnConfig conf) {
		return _msgNoDataAtReq(causeRow.getRootRow(), conf.getBaseRowColumnName(),
				conf.getMessageByLocale(), causeRow.getGUIIndex());
	}
}
