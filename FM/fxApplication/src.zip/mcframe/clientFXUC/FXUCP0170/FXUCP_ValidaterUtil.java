package mcframe.clientFXUC.FXUCP0170;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCP_ValidaterUtil extends FXUCP_ValidaterUtil_FW {
}
