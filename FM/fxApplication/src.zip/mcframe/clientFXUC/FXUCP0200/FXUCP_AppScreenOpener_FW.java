package mcframe.clientFXUC.FXUCP0200;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mcframe.clientCore.beans.MCBeansUtil;
import mcframe.clientCore.beans.MCFrameType;
import mcframe.clientCore.beans.MCPanelType;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.MCRowBeans;
import mcframe.clientCore.beans.MCScreenOpener;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;

public class FXUCP_AppScreenOpener_FW extends MCScreenOpener {

	/**
	 * FXUCP_AppScreenOpenerから画面を起動したことを表す定数です。
	 */
	public static final String APP_SCREEN_OPENER = "APP_SCREEN_OPENER";

	/**
	 * 遷移先の検索枠のRowコンテナ
	 */
	private MCRow cndRow = null;

	/**
	 * 遷移後に検索を実行するか（デフォルト＝オフ）
	 */
	private boolean searchFlg = false;

	/**
	 * 遷移先の検索枠のブロック名（デフォルト＝Cnd）
	 */
	private String cndBlockNm = "Cnd";

	/**
	 * {PARAM_ACTION=ACT_SEARCH}以外のパラメータ設定
	 */
	private Map<String, String> map = new HashMap<>();

	/**
	 * 値が「null」または「false」でも遷移先に設定するカラム名のリスト
	 */
	protected List<String> forceCols;

	/**
	 * valueInitを実行する場合true;
	 */
	private boolean valueInit = false;

	
	/**
	 * 画面のフレーム種別
	 */
	private MCFrameType frameType;
	
	/**
	 * 画面の表示モード
	 */
	private MCPanelType panelType;
	
	public FXUCP_AppScreenOpener_FW(String moduleid, String screenid) {
		super(moduleid, screenid);
	}

	/**
	 * 画面を表示します。
	 * 
	 * フレーム種別は {@link #getFrameType()} の設定に従います。
	 * 画面モードは {@link #getPanelType()} の設定に従います。
	 *
	 * <p>
	 * 画面モードがSINGLEの場合、既に画面が開いていればその画面を閉じてから表示します。
	 */
	@Override
	public void show() {
		show(getFrameType(), getPanelType());
	}

	/**
	 * 画面を表示します。
	 *
	 * パラメータがある場合は、起動後に値を設定します。
	 * パラメータに起動時の実行ボタンがある場合は、値設定後にボタンを実行します。
	 *
	 * <p>
	 * SINGLEモードで表示する場合、既に画面が開いていればその画面を閉じてから表示します。
	 * 
	 * <p>
	 * 子画面として表示する場合は
	 * {@link #showChild(MCFrameType, MCPanelType, MCRootPanel)}
	 * を利用してください。
	 *
	 * @param frame フレーム種別。nullを指定した場合は {@link #getFrameType()} とする。
	 * @param panel 表示モード。nullを指定した場合は {@link #getPanelType()} とする。
	 */
	@Override
	public void show(MCFrameType frame, MCPanelType panel) {
		frameType = frame;
		panelType = panel;

		if (!canOpenScreen(getFrameType(), getPanelType())) {
			return;
		}
		
		Map<String, Comparable<?>> map = crtScreenOpnerBind();
		setParameter(map);

		super.show(getPanel());
	}

	/**
	 * 画面をモーダレスの子画面として表示します。
	 * 
	 * フレーム種別は {@link MCFrameType#MODELESS} となります。
	 * 画面モードは {@link #getPanelType()} の設定に従います。
	 * 
	 * <p>
	 * 画面モードがSINGLEまたはSCREEN_SINGLEの場合、
	 * 親画面が同じ画面が既に開いていればその画面を閉じてから表示します。
	 *
	 * @param parent 親画面
	 */
	@Override
	public void showChild(MCRootPanel parent) {
		showChild(MCFrameType.MODELESS, getPanelType(), parent);
	}
	
	/**
	 * 画面を子画面として表示します。
	 *
	 * パラメータがある場合は、起動後に値を設定します。
	 * パラメータに起動時の実行ボタンがある場合は、値設定後にボタンを実行します。
	 * 
	 * <p>
	 * SINGLEモードまたはSCREEN_SINGLEモードで表示する場合、
	 * 親画面が同じ画面が既に開いていればその画面を閉じてから表示します。
	 *
	 * @param frame フレーム種別。
	 * 親画面がシステムモーダルの場合は強制的に {@link MCFrameType#SYSTEM_MODAL} となる。
	 * nullを指定した場合は{@link #getFrameType()} とする。
	 * @param panel 表示モード。nullを指定した場合は {@link #getPanelType()} とする。
	 * @param parent 親画面
	 */
	@Override
	public void showChild(MCFrameType frame, MCPanelType panel, MCRootPanel parent) {
		// 親画面がシステムモーダルの場合は子画面もシステムモーダルにする
		if (parent.getFrame().getFrameType() == MCRootPanel.SYSTEM_MODAL) {
			frame = MCRootPanel.SYSTEM_MODAL;
		}
		
		frameType = frame;
		panelType = panel;

		if (!canOpenScreen(getFrameType(), getPanelType(), parent)) {
			return;
		}

		// バインド変数を作成する前にパネルを確定しておく
		MCRootPanel startup = getChildPanel(parent);

		Map<String, Comparable<?>> map = crtScreenOpnerBind();
		setParameter(map);

		super.showChild(startup, parent);
	}

	/**
	 * 遷移先の検索枠に設定する値の設定されたRowコンテナをセットします。<br>
	 */
	public void putCnd(MCRow row) {
		cndRow = row;
	}

	/**
	 * 遷移先の検索枠に設定する値の設定されたRowコンテナをセットします。<br>
	 * 引数forceColumnに設定されたカラムは、引数cndRの値が「null」または「false」の場合でも遷移先に設定します。
	 */
	public void putCnd(MCRow cndR, List<String> forceColumn) {
		putCnd(cndR);
		forceCols = forceColumn;
	}

	/**
	 * 遷移先の検索枠のブロック名を指定する場合に実行します。<br>
	 * （デフォルト＝Cnd）
	 */
	public void putCndBlockNm(String nm) {
		cndBlockNm = nm;
	}

	/**
	 * 遷移後に検索を実行する場合に実行します。
	 */
	public void putSearchAction() {
		searchFlg = true;
	}

	/**
	 * {PARAM_ACTION=ACT_SEARCH}以外のパラメータ設定を行います。
	 */
	public void putBind(String key, String value) {
		map.put(key, value);
	}

	protected Map<String, Comparable<?>> crtScreenOpnerBind() {
		Map<String, Comparable<?>> bind = new HashMap<>();
		if (cndRow == null) {
			return bind;
		}
		// 画面の作成
		MCRootPanel p = getPanel();

		for (MCRowBeans rb : getSrchCndBeans(p, cndRow)) {
			String baseCol = getColName(rb, p);
			String baseRootCol = rb.getBaseRowColumnName();
			if (cndRow.contains(baseCol)) {

				boolean isForceTgtCol = forceCols != null &&
						(forceCols.contains(baseCol) || forceCols.contains(baseRootCol));

				String key = MCScreenOpener.createGUIKey(rb);
				// 「null」または「false」の場合は対象外
				if (cndRow.getDataType(baseCol) == MCDataType.BOOLEAN
						&& !cndRow.getBoolean(baseCol)) {
					if (!isForceTgtCol) {
						continue;
					}
				}
				Comparable<?> value = cndRow.getValue(baseCol);
				if (value == null) {
					if (!isForceTgtCol) {
						continue;
					}
				}
				bind.put(key, value);
			}
		}
		if (searchFlg) {
			bind.put(MCScreenOpener.PARAM_ACTION, MCScreenOpener.ACT_SEARCH);
		}
		if (map != null) {
			bind.putAll(map);
		}
		return bind;
	}

	protected List<MCRowBeans> getSrchCndBeans(MCRootPanel p, MCRow bind) {
		List<Object[]> list = FXUCP_SrchCndUtil.getSrchCndBeans((IfSrchCndBase) p, true);
		List<MCRowBeans> l = new ArrayList<>();
		for (Object[] objs : list) {
			MCRowBeans b = (MCRowBeans) objs[1];
			// ブロック名で絞り込み
			if (getBlockColName(b, p).startsWith(cndBlockNm)) {
				l.add(b);
			}
		}
		return l;
	}

	/**
	 * エイリアスを考慮したカラム名を返します。
	 * @param rb
	 * @param p
	 * @return カラム名
	 */
	public static String getColName(MCRowBeans rb, MCRootPanel p) {
		String alias = rb.getAliasName(p);
		if (!isNull(alias)) {
			String[] strs = alias.split("\\.");
			return strs[strs.length - 1];
		}
		return rb.getBaseRowColumnName();
	}

	/**
	 * エイリアスを考慮したカラム名（ブロック名付き）を返します。
	 * @param rb
	 * @param p
	 * @return
	 */
	public static String getBlockColName(MCRowBeans rb, MCRootPanel p) {
		String alias = rb.getAliasName(p);
		if (!isNull(alias)) {
			return alias;
		}
		return rb.getName();
	}

	/**
	 * 画面起動時にvalueInitを実行する場合に実行します。
	 */
	public void runValueInit() {
		valueInit = true;
	}

	@Override
	protected String getOpenType() {
		if (valueInit) {
			return super.getOpenType();
		}
		return APP_SCREEN_OPENER;
	}

	@Override
	protected MCFrameType getFrameType() {
		if (frameType != null) {
			return frameType;
		}
		return super.getFrameType();
	}

	@Override
	protected MCPanelType getPanelType() {
		if (panelType != null) {
			return panelType;
		}
		return super.getPanelType();
	}
	
}
