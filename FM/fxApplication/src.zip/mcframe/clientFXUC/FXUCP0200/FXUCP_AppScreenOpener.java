package mcframe.clientFXUC.FXUCP0200;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCP_AppScreenOpener extends FXUCP_AppScreenOpener_FW {

	public FXUCP_AppScreenOpener(String moduleid, String screenid) {
		super(moduleid, screenid);
	}

}

