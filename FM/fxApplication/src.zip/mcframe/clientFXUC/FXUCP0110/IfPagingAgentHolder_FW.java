package mcframe.clientFXUC.FXUCP0110;

import mcframe.clientCore.beans.MCPagingAgent;

public interface IfPagingAgentHolder_FW {
	/**
	 * ページングで使用するソートタイプ：ASC
	 */
	public static final String ASC = "ASC";

	/**
	 * ページングで使用するソートタイプ：ASC_NULL_AHEAD
	 */
	public static final String ASC_NULL_AHEAD = "ASC_NULL_AHEAD";

	/**
	 * ページングで使用するソートタイプ：DESC
	 */
	public static final String DESC = "DESC";

	/**
	 * ページングで使用するソートタイプ：DESC_NULL_AHEAD
	 */
	public static final String DESC_NULL_AHEAD = "DESC_NULL_AHEAD";

	public MCPagingAgent getPagingAgent();

	public void doPageNext();

	public void doPagePrev();

	public void doPageJump(int idxFrom, int idxTo);

	/**
	 * ページングのサイズを設定します。
	 * 
	 * @param size ページングのサイズ
	 */
	public void setPagingSize(int size);

	/**
	 * ページングのサイズを返します。
	 * 
	 * @return ページングのサイズ
	 */
	public int getPagingSize();

	/**
	 * ページングのサイズのデフォルト値を返します。
	 * 
	 * @return ページングのサイズのデフォルト値
	 */
	public int getDefaultPagingSize();
}
