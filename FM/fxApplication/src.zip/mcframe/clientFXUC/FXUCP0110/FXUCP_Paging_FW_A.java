package mcframe.clientFXUC.FXUCP0110;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FXUCP_Paging"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXUCP_Paging_FW_A extends mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXUC";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXUCP0110";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 * display 範囲.<p>
	 *
	 */
	public MCTextField Btn_disp = null;
	public MCLabel Btn_count_Label = null;
	/**
	 *  表示件数.<p>
	 *
	 */
	public MCNumberField Btn_count = null;
	/**
	 *  全件表示.<p>
	 *
	 */
	public MCCheckBox Btn_all_disp = null;
	/**
	 *  前.<p>
	 *
	 */
	public MCButton Btn_prev = null;
	/**
	 *  次.<p>
	 *
	 */
	public MCButton Btn_next = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Btn]ブロックのコンテナField定義 */
	private final mcframe.clientFXUC.FXUCP0110.BtnR aBtnR;

	/**
	 * 項目コピーによってaBtnRを設定します。
	 *
	 * aBtnRのインスタンスは変更されません。
	 *
	 * @param row BtnR
	 */
	public void setBtnR(mcframe.clientFXUC.FXUCP0110.BtnR row) {
		if (row != null) {
			MCRow.copyall(getBtnR(), row);
		}
	}

	/**
	 * [Btn]ブロックのコンテナaBtnRを返します。
	 *
	 * @return BtnR
	 */
	public mcframe.clientFXUC.FXUCP0110.BtnR getBtnR() {
		return aBtnR;
	}

	/**
	 * aBtnRを作成します。
	 *
	 * @return BtnR
	 */
	public mcframe.clientFXUC.FXUCP0110.BtnR createBtnR() {
		return mcframe.clientFXUC.FXUCP0110.BtnR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getBtnR())) ret.add(getBtnR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getBtnR()) return "Btn";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Btn")) return getBtnR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_Paging_FW_A() {
		aBtnR = createBtnR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXUCP_Paging_FW_A(mcframe.clientFXUC.FXUCP0110.BtnR row){
		aBtnR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXUCP_Paging_FW.jbCreateBtn((FXUCP_Paging)this);
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FXUCP_Paging p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FXUCP_Paging create(mcframe.clientFXUC.FXUCP0110.BtnR row){
		FXUCP_Paging p = new FXUCP_Paging(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_Paging create(){
		FXUCP_Paging p = new FXUCP_Paging();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXUCP_Paging_FW.jbfInitBtn((FXUCP_Paging)this);
		FXUCP_Paging_FW.jbInitBtn((FXUCP_Paging)this);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FXUCP_Paging p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_disp = p.beansFactory.createTextField("Btn.disp");
		p.Btn_count_Label = p.beansFactory.createLabel("Btn.count_Label");
		p.Btn_count = p.beansFactory.createNumberField("Btn.count");
		p.Btn_count.setLabel(p.Btn_count_Label);
		p.Btn_all_disp = p.beansFactory.createCheckBox("Btn.all_disp");
		p.Btn_prev = p.beansFactory.createButton("Btn.prev", "no_border");
		p.Btn_next = p.beansFactory.createButton("Btn.next", "no_border");
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FXUCP_Paging p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.setLastBeans(p.BtnPanel);
		p.BtnPanel.setValueCheck(false);
		p.BtnPanel.setExtValue(MCPanel.SRCH_CND_SETTING_PANEL, true);
		// ブロックの項目の初期化
		p.BtnPanel.add(p.Btn_disp);
		p.BtnPanel.setLastBeans(p.Btn_disp);
		p.Btn_disp.setNextBeans(p.Btn_count);
		p.Btn_disp.setRow(p.getBtnR(), mcframe.clientFXUC.FXUCP0110.BtnR.disp_META);
		p.BtnPanel.add(p.Btn_count_Label);
		p.BtnPanel.add(p.Btn_count);
		p.Btn_count.setNextBeans(p.Btn_all_disp);
		p.Btn_count.setRow(p.getBtnR(), mcframe.clientFXUC.FXUCP0110.BtnR.count_META);
		p.BtnPanel.add(p.Btn_all_disp);
		p.Btn_all_disp.setNextBeans(p.Btn_prev);
		p.Btn_all_disp.setRow(p.getBtnR(), mcframe.clientFXUC.FXUCP0110.BtnR.all_disp_META);
		p.Btn_prev.setIcon("PREV");
		p.Btn_prev.setFunctionKey(MCFunctionKey.F5);
		p.BtnPanel.add(p.Btn_prev);
		p.Btn_prev.setNextBeans(p.Btn_next);
		p.Btn_next.setIcon("NEXT");
		p.Btn_next.setFunctionKey(MCFunctionKey.F6);
		p.BtnPanel.add(p.Btn_next);
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXUCP_Paging_FW.mcInitBtn((FXUCP_Paging)this);

		// [ENABLE]ステータスのモードの設定
		FXUCP_Paging_FW.statusInitENABLE_Btn((FXUCP_Paging)this);

		// [DISABLE]ステータスのモードの設定
		FXUCP_Paging_FW.statusInitDISABLE_Btn((FXUCP_Paging)this);

	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FXUCP_Paging p) {
		p.Btn_disp.setListListener(p);
		p.Btn_disp.addAllListener(p);
		p.Btn_count.setListListener(p);
		p.Btn_count.addAllListener(p);
		p.Btn_all_disp.addAllListener(p);
		p.Btn_prev.addAllListener(p);
		p.Btn_prev.setAPMethodName("doBtn_prev");
		p.Btn_next.addAllListener(p);
		p.Btn_next.setAPMethodName("doBtn_next");
	}

	/**
	 * [ENABLE]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Btn(FXUCP_Paging p){
		p.Btn_disp.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Btn_count.putMode(p, ENABLE, MCMode.REQUIRED);
		p.Btn_all_disp.putMode(p, ENABLE, MCMode.REQUIRED);
		p.Btn_prev.putMode(p, ENABLE, MCMode.READ_ONLY);
		p.Btn_next.putMode(p, ENABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Btn(FXUCP_Paging p){
		p.Btn_disp.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_count.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_all_disp.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_prev.putMode(p, DISABLE, MCMode.DISABLE);
		p.Btn_next.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_prev) doBtn_prev(info);
		else if (ap == Btn_next) doBtn_next(info);
	}

	/**
	 * [Btn]パネルの[prev]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_prev(MCEventInfo info);

	/**
	 * [Btn]パネルの[next]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_next(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Btn_disp) return doBtn_disp_VC(info);
		if (vc == Btn_count) return doBtn_count_VC(info);
		if (vc == Btn_all_disp) return doBtn_all_disp_VC(info);
		return true;
	}

	/**
	 * [Btn]パネルの[disp]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_disp_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[count]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_count_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btn]パネルの[all_disp]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtn_all_disp_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Btn_disp) doBtn_disp_NC(info);
		else if (nc == Btn_count) doBtn_count_NC(info);
		else if (nc == Btn_all_disp) doBtn_all_disp_NC(info);
	}

	/**
	 * [Btn]パネルの[disp]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_disp_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[count]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_count_NC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[all_disp]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_all_disp_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Btn_disp) doBtn_disp_NE(info);
		else if (ne == Btn_count) doBtn_count_NE(info);
		else if (ne == Btn_all_disp) doBtn_all_disp_NE(info);
	}

	/**
	 * [Btn]パネルの[disp]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_disp_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[count]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_count_NE(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[all_disp]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_all_disp_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Btn_disp) doBtn_disp_NX(info);
		else if (nx == Btn_count) doBtn_count_NX(info);
		else if (nx == Btn_all_disp) doBtn_all_disp_NX(info);
	}

	/**
	 * [Btn]パネルの[disp]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_disp_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[count]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_count_NX(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[all_disp]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_all_disp_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Btn_disp) doBtn_disp_LC(info);
		else if (lc == Btn_count) doBtn_count_LC(info);
	}

	/**
	 * [Btn]パネルの[disp]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_disp_LC(MCEventInfo info){
	}

	/**
	 * [Btn]パネルの[count]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtn_count_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}