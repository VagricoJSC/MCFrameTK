package mcframe.clientFXUC.FXUCP0110;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.requester.paging.MCPagingAgent;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import static mcframe.commonFX.notice.FX_Msg.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_Paging"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_Paging_FW extends FXUCP_Paging_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_Paging_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXUCP_Paging_FW(mcframe.clientFXUC.FXUCP0110.BtnR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Btn START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Btn END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[prev]の押下時の処理
	 */
	@Override
	public void doBtn_prev(MCEventInfo info) {
		getPagingAgentHolder().doPagePrev();
		
		dispUpdate();
	}

	/**
	 * Panel[Btn]のボタン[next]の押下時の処理
	 */
	@Override
	public void doBtn_next(MCEventInfo info) {
		getPagingAgentHolder().doPageNext();
		
		dispUpdate();
	}

	/**
	 * 件数表示のラベルに使用するためのメッセージ
	 */
	protected MCMessage _msgForDisp = new MCMessage(FXUCP0001);

	/**
	 * ボタンの活性／非活性及び、件数表示を更新します。
	 */
	public void dispUpdate() {
		getBtnR().from(pagingAgent().from());
		getBtnR().to(pagingAgent().to());
		getBtnR().ttl(pagingAgent().total());
		if (getBtnR().to().gt(getBtnR().ttl())) {
			getBtnR().to(getBtnR().ttl());
		}
		if (pagingAgent().total() == 0) {
			// 検索結果がない場合
			getBtnR().disp(null);
			Btn_disp.setToolTipText(null);

			setPagingCountMode();
		}
		else {
			// 検索結果がある場合
			_msgForDisp.setBind(getBtnR().ttl(), getBtnR().from(), getBtnR().to());
			getBtnR().disp(_msgForDisp.toString());
			Btn_disp.setToolTipText(_msgForDisp.toString());
			
			Btn_count.setMode(MCMode.READ_ONLY);
			Btn_all_disp.setMode(MCMode.READ_ONLY);
		}

		if (pagingAgent().hasPrevious()) {
			Btn_prev.setMode(MCMode.ENABLE);
		}
		else {
			Btn_prev.setMode(MCMode.DISABLE);
		}
		if (pagingAgent().hasNext()) {
			Btn_next.setMode(MCMode.ENABLE);
		}
		else {
			Btn_next.setMode(MCMode.DISABLE);
		}
	}

	public MCPagingAgent pagingAgent() {
		return getPagingAgentHolder().getPagingAgent();
	}
	
	protected IfPagingAgentHolder getPagingAgentHolder() {
		MCRootPanel p = getUnderPanel();
		if (p == null) {
			throw new MCException(FXUCP0032, getModuleID(), getScreenID());
		}
		if (p instanceof IfPagingAgentHolder) {
			return (IfPagingAgentHolder)p;
		}
		throw new MCException(FXUCP0033, p.getModuleID(), p.getScreenID());
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		
		setValueEx(Btn_count, MCNumber.valueOf(
				getPagingAgentHolder().getDefaultPagingSize()));
	}
	
	@Override
	public boolean doBtn_count_VC(MCEventInfo info) {
		if (!super.doBtn_count_VC(info)) {
			return false;
		}
		
		MCNumber v = (MCNumber)info.getNewValue();
		if (isNull(v)) {
			return true;
		}
		if (!v.isPositive() || v.gt(Integer.MAX_VALUE)) {
			return false;
		}
		
		return true;
	}

	@Override
	public void doBtn_count_NC(MCEventInfo info) {
		super.doBtn_count_NC(info);
		
		if (!isNull(getBtnR().count())) {
			getBtnR().all_disp(false);
		}
		
		setPagingCountMode();
	}

	@Override
	public void doBtn_all_disp_NC(MCEventInfo info) {
		super.doBtn_all_disp_NC(info);
		
		if (getBtnR().all_disp()) {
			getBtnR().count(null);
		}
		
		setPagingCountMode();
	}

	/**
	 * 表示件数のモードを設定します。
	 */
	protected void setPagingCountMode() {
		if (isDefaultModeEditable(Btn_count)) {
			if (getBtnR().all_disp()) {
				Btn_count.setMode(MCMode.ENABLE);
			}
			else {
				setDefaultMode(Btn_count);
			}
		}
	}

	public void setPagingSize() {
		int size;
		if (getBtnR().all_disp()) {
			size = Integer.MAX_VALUE;
		}
		else {
			MCNumber v = getBtnR().count();
			if (!isNull(v)) {
				size = v.intValue();
			}
			else {
				size = getPagingAgentHolder().getDefaultPagingSize();
			}
		}
		getPagingAgentHolder().setPagingSize(size);
	}

}