package mcframe.clientFXUC.FXUCP0110;

public interface IfPagingAgentHolder extends IfPagingAgentHolder_FW{

}
