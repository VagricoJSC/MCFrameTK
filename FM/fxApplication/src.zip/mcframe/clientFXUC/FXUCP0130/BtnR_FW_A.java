package mcframe.clientFXUC.FXUCP0130;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Btn"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BtnR_FW_A extends MCConstRow {

	/**
	 * display 範囲.<p>
	 *
	 */
	public static final String $disp = "disp";
	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public static final String $from = "from";
	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public static final String $to = "to";
	/**
	 * total 全件.<p>
	 *
	 */
	public static final String $ttl = "ttl";
	/**
	 *  表示件数.<p>
	 *
	 */
	public static final String $count = "count";
	/**
	 *  全件表示.<p>
	 *
	 */
	public static final String $all_disp = "all_disp";


	public static final MCMeta disp_META = createStringMeta($disp, 100);
	public static final MCMeta from_META = createNumberMeta($from, 8, 0, false);
	public static final MCMeta to_META = createNumberMeta($to, 8, 0, false);
	public static final MCMeta ttl_META = createNumberMeta($ttl, 8, 0, false);
	public static final MCMeta count_META = createNumberMeta($count, 10, 0, false);
	public static final MCMeta all_disp_META = createBooleanMeta($all_disp);

	protected static final ConstMetaList<BtnR> constMetas = new ConstMetaList<BtnR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			disp_META,
			from_META,
			to_META,
			ttl_META,
			count_META,
			all_disp_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BtnR_FW_A(ConstMetaList<? extends BtnR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtnR clone() {
		return (BtnR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtnR createInstance() {
		return (BtnR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtnR getValues(String... names) {
		return (BtnR) super.getValues(names);
	}



	/**
	 * display 範囲.<p>
	 *
	 */
	public String disp() {
		return getConstString(offset + 0, $disp);
	}

	/**
	 * display 範囲.<p>
	 *
	 */
	public void disp(String value) {
		setConstString(offset + 0, $disp, value);
	}


	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public MCNumber from() {
		return getConstNumber(offset + 1, $from);
	}

	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public void from(MCNumber value) {
		setConstNumber(offset + 1, $from, value);
	}

	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public void from(int value) {
		setConstNumber(offset + 1, $from, value);
	}

	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public void from(long value) {
		setConstNumber(offset + 1, $from, value);
	}

	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public void from(float value) {
		setConstNumber(offset + 1, $from, value);
	}

	/**
	 * from 表示件数の最小値.<p>
	 *
	 */
	public void from(double value) {
		setConstNumber(offset + 1, $from, value);
	}


	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public MCNumber to() {
		return getConstNumber(offset + 2, $to);
	}

	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public void to(MCNumber value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public void to(int value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public void to(long value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public void to(float value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 * to 表示件数の最大値.<p>
	 *
	 */
	public void to(double value) {
		setConstNumber(offset + 2, $to, value);
	}


	/**
	 * total 全件.<p>
	 *
	 */
	public MCNumber ttl() {
		return getConstNumber(offset + 3, $ttl);
	}

	/**
	 * total 全件.<p>
	 *
	 */
	public void ttl(MCNumber value) {
		setConstNumber(offset + 3, $ttl, value);
	}

	/**
	 * total 全件.<p>
	 *
	 */
	public void ttl(int value) {
		setConstNumber(offset + 3, $ttl, value);
	}

	/**
	 * total 全件.<p>
	 *
	 */
	public void ttl(long value) {
		setConstNumber(offset + 3, $ttl, value);
	}

	/**
	 * total 全件.<p>
	 *
	 */
	public void ttl(float value) {
		setConstNumber(offset + 3, $ttl, value);
	}

	/**
	 * total 全件.<p>
	 *
	 */
	public void ttl(double value) {
		setConstNumber(offset + 3, $ttl, value);
	}


	/**
	 *  表示件数.<p>
	 *
	 */
	public MCNumber count() {
		return getConstNumber(offset + 4, $count);
	}

	/**
	 *  表示件数.<p>
	 *
	 */
	public void count(MCNumber value) {
		setConstNumber(offset + 4, $count, value);
	}

	/**
	 *  表示件数.<p>
	 *
	 */
	public void count(int value) {
		setConstNumber(offset + 4, $count, value);
	}

	/**
	 *  表示件数.<p>
	 *
	 */
	public void count(long value) {
		setConstNumber(offset + 4, $count, value);
	}

	/**
	 *  表示件数.<p>
	 *
	 */
	public void count(float value) {
		setConstNumber(offset + 4, $count, value);
	}

	/**
	 *  表示件数.<p>
	 *
	 */
	public void count(double value) {
		setConstNumber(offset + 4, $count, value);
	}


	/**
	 *  全件表示.<p>
	 *
	 */
	public boolean all_disp() {
		return getConstBoolean(offset + 5, $all_disp);
	}

	/**
	 *  全件表示.<p>
	 *
	 */
	public void all_disp(boolean value) {
		setConstBoolean(offset + 5, $all_disp, value);
	}


	public String getString(String name) {
		if ($disp.equalsIgnoreCase(name)) {
			return disp();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($from.equalsIgnoreCase(name)) {
			return from();
		}
		if ($to.equalsIgnoreCase(name)) {
			return to();
		}
		if ($ttl.equalsIgnoreCase(name)) {
			return ttl();
		}
		if ($count.equalsIgnoreCase(name)) {
			return count();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($all_disp.equalsIgnoreCase(name)) {
			return all_disp();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($disp.equalsIgnoreCase(name)) {
			return disp();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($from.equalsIgnoreCase(name)) {
			return from();
		}
		if ($to.equalsIgnoreCase(name)) {
			return to();
		}
		if ($ttl.equalsIgnoreCase(name)) {
			return ttl();
		}
		if ($count.equalsIgnoreCase(name)) {
			return count();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($all_disp.equalsIgnoreCase(name)) {
			return all_disp();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($disp.equalsIgnoreCase(name)) {
			disp(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($all_disp.equalsIgnoreCase(name)) {
			all_disp(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($disp.equalsIgnoreCase(name)) {
			disp(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($from.equalsIgnoreCase(name)) {
			from(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		if ($ttl.equalsIgnoreCase(name)) {
			ttl(value);
			return;
		}
		if ($count.equalsIgnoreCase(name)) {
			count(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($all_disp.equalsIgnoreCase(name)) {
			all_disp(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

