package mcframe.clientFXUC.FXUCP0130;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.resource.MCConst;
import static mcframe.commonFX.notice.FX_Msg.FXUCP0001;
import mcframe.clientFXBA.FXBAP0010.IfPagingAgentHolder;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PagingParam;
import static mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher.PagingCallTyp;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_Paging"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_Paging_FW extends FXUCP_Paging_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 件数表示のラベルに使用するためのメッセージ
	 */
	protected MCMessage _msgForDisp = new MCMessage(FXUCP0001);
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_Paging_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXUCP_Paging_FW(mcframe.clientFXUC.FXUCP0130.BtnR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Btn START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Btn END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * 有効なページングエージェントを保持する画面を返します。<p>
	 * この画面→利用画面の順に評価します。
	 * @return ページングエージェントホルダー
	 */
	protected IfPagingAgentHolder getPagingAgentHolder() {
		MCRootPanel p = this;
		while(p != null) {
			if (p instanceof IfPagingAgentHolder) {
				IfPagingAgentHolder h = (IfPagingAgentHolder)p;
				if (h.isPagingAgentHolder()) {
					return h;
				}
			}
			p = p.getUnderPanel();
		}
		return null;
	}
	
	protected FXBAP_PanelBase getXpanelPagingAgentHolder() {
		IfPagingAgentHolder h = getPagingAgentHolder();
		FXBAP_PanelBase xp = null;
		if (h instanceof FXBAP_PanelBase) {
			xp = (FXBAP_PanelBase)h;
		}
		else {
			xp = getBaseXPanel();
		}
		return xp;
	}
	@Override
	public MCPagingAgent getPagingAgent(Class clr) {
		IfPagingAgentHolder h = getPagingAgentHolder();
		if (h != null) {
			//作成済みページングエージェントを取得する
			PagingCallTyp t = h.getPagingCallTyp();
			try {
				h.setPagingCallTyp(PagingCallTyp.NEXT);
				return h.getPagingAgent(clr);
			}
			finally {
				h.setPagingCallTyp(t);
			}
		}
		return null;
	}
	
	/**
	 * 画面クリア、画面再表示時に値を再設定します。
	 */
	@Override
	public void screenClearBody() {
		super.screenClearBody();
		setDefaultCountSize();
	}
	
	/**
	 * {@inheritDoc}<p>
	 * 利用画面のsetupPartsで使用するメソッドです。<br>
	 * 可変長引数ですが、採用されるのは1つめだけです。<br>
	 * 件数がnullの場合は、リソース値を件数フィールドに設定します({@link #setDefaultCountSize()})。<br>
	 * ページング情報は件数フィールドの設定で上書きされます。<br>
	 */
	@Override
	public void setPagingParam(FXBAP_PagingParam... ps){
		super.setPagingParam(ps);
		setDefaultCountSize();
		for (FXBAP_PagingParam p : ps) {
			if (p != null) {
				overWrite(p);
			}
		}
	}
	
	/**
	 * {@inheritDoc}<p>
	 * 画面の設定で上書き後に返します。
	 */
	@Override
	public List<FXBAP_PagingParam> getPagingParam() {
		List<FXBAP_PagingParam> l = super.getPagingParam();
		for (FXBAP_PagingParam p : l) {
			if (p != null) {
				overWrite(p);
			}
		}
		return l;
	}

	protected void overWrite(FXBAP_PagingParam p) {
		MCNumber n = Btn_count.getValue();
		//sizeを上書き
		p.setSize(isNull(n) ? -1 : n.intValue());
	}
	/**
	 * @deprecated　複数件の設定は想定されていません。
	 */
	@Override
	public void addPagingParam(FXBAP_PagingParam... p) {
		super.addPagingParam(p);
	}

	/**
	 * Panel[Btn]のボタン[prev]の押下時の処理
	 */
	@Override
	public void doBtn_prev(MCEventInfo info) {
		callPagingSearcher(PagingCallTyp.PREV);
	}
	/**
	 * Panel[Btn]のボタン[next]の押下時の処理
	 */
	@Override
	public void doBtn_next(MCEventInfo info) {
		callPagingSearcher(PagingCallTyp.NEXT);
	}
	/**
	 * ページングホルダーの設置を変更後、検索を行います。
	 * @param pct 「新規検索」、「次へ」、「前へ」を表す定数
	 */
	protected void callPagingSearcher(PagingCallTyp pct) {
		IfPagingAgentHolder h = getPagingAgentHolder();
		if (h == null) {
			return;
		}
		List<FXBAP_PagingParam> pps = getPagingParam();
		if (Btn_all_disp.getValue() || pps.isEmpty()) {
			//ページングしない
			h.setPagingCallTyp(null);
		}
		else {
			//ページング設定変更
			h.setPagingCallTyp(pct);
			h.setPagingParam(
					pps.toArray(new FXBAP_PagingParam[pps.size()]));
			
		}
		try {
			h.callPagingSearcher(this);
		} finally {
			h.setPagingCallTyp(PagingCallTyp.NEW);
		}
		dispUpdate();
	}

	@Override
	public void doBtn_all_disp_NC(MCEventInfo info) {
		super.doBtn_all_disp_NC(info);
		
		if (getBtnR().all_disp()) {
			setValueEx(Btn_count, null);
		}
		else {
			setDefaultCountSize();
		}
	}
	
	@Override
	public void doBtn_count_NC(MCEventInfo info) {
		super.doBtn_count_NC(info);
		
		if (!isNull(getBtnR().count())) {
			getBtnR().all_disp(false);
			setActivePrevNextBtnMode();
		}
		else {
			getBtnR().all_disp(true);
			setInactivePrevNextBtnMode();
		}
		
		List<FXBAP_PagingParam> l = getPagingParam();
		for (FXBAP_PagingParam p : l) {
			if (p != null) {
				overWrite(p);
			}
		}
	}
	
	@Override
	public boolean doBtn_count_VC(MCEventInfo info) {
		if (!super.doBtn_count_VC(info)) {
			return false;
		}
		
		MCNumber v = (MCNumber)info.getNewValue();
		if (!isNull(v) && 
				(!v.isPositive() || v.gt(Integer.MAX_VALUE))) {
			return false;
		}
		
		return true;
	}
	/**
	 * ボタンの活性／非活性及び、件数表示を更新します。
	 */
	public void dispUpdate() {
		List<FXBAP_PagingParam> l = getPagingParam();
		if (l == null || l.isEmpty()) {
			setValueEx(Btn_all_disp, true);
		}
		else {
			FXBAP_PagingParam p = (FXBAP_PagingParam)l.get(0);
			MCPagingAgent pa = getPagingAgent(p.getTargetCaller());
			int blk = p.getParamBlockIndex(pa.param());
			getBtnR().from(pa.from(blk));
			getBtnR().to(pa.to(blk));
			
			getBtnR().ttl(pa.total(blk));
			if (getBtnR().to().gt(getBtnR().ttl())) {
				getBtnR().to(getBtnR().ttl());
			}
			
			if ( !donePaging(p, pa) ) {
				getBtnR().disp(null);
				Btn_disp.setToolTipText(null);	
			}
			else {
				// 検索結果がある場合
				_msgForDisp.setBind(getBtnR().ttl(), getBtnR().from(), getBtnR().to());
				
				getBtnR().disp(_msgForDisp.toString());
				Btn_disp.setToolTipText(_msgForDisp.toString());
				
//				Btn_count.setMode(MCMode.READ_ONLY);
//				Btn_all_disp.setMode(MCMode.READ_ONLY);
			}
	
			setActivePrevNextBtnMode();
		}
	}
	/**
	 * ページングによる検索が行われたかどうかを判定します。<p>
	 * @param p　ページング情報
	 * @param pa ページングエージェント
	 * @return ページング結果が0件、または画面にデータが反映されていない場合true
	 */
	protected boolean donePaging(FXBAP_PagingParam p,MCPagingAgent pa ) {
		IfPagingAgentHolder ph = getPagingAgentHolder();
		if (ph instanceof MCRootPanel) {
			MCRootPanel panel = (MCRootPanel)ph;
			MCContainer c = panel.getContainer(p.getTargetBlockId());
			if (c instanceof MCList) {
				MCList l = (MCList)c;
				return pa.total(p.getParamBlockIndex(pa.param())) != 0 && 
							l.size() != 0 ;
			}
		}
		return false;
	}
	
	protected void setInactivePrevNextBtnMode() {
		Btn_prev.setMode(MCMode.DISABLE);
		Btn_next.setMode(MCMode.DISABLE);
		
	}
	protected void setActivePrevNextBtnMode() {

		List<FXBAP_PagingParam> l = getPagingParam();
		if (l == null || l.isEmpty()) {
			return;
		}
		FXBAP_PagingParam p = (FXBAP_PagingParam)l.get(0);
		MCPagingAgent pa = getPagingAgent(p.getTargetCaller());
		if (pa == null) {
			return;
		}
		
		int blk = p.getParamBlockIndex(pa.param());
		if (blk >= 0) {
			//nextから先にモード変更することで、
			//prevがDisableになるときにnextにフォーカス移動するようにしている。
			if (donePaging(p, pa) && pa.hasNext(blk) ) {
				Btn_next.setMode(MCMode.ENABLE);
			}
			else {
				Btn_next.setMode(MCMode.DISABLE);
			}
			if (donePaging(p, pa) && pa.hasPrevious(blk) ) {
				Btn_prev.setMode(MCMode.ENABLE);
			}
			else {
				Btn_prev.setMode(MCMode.DISABLE);
			}
		}
	}
	
	/**
	 * 件数がnullの場合に件数の初期値を設定します。<p>
	 * 初期値はMCAppClientリソースの設定が次の優先順で採用されます。
	 * <li>[moduleID].[screenID].[blockID].pagesize
	 * <li>[moduleID].[screenID].pagesize
	 * <li>X.pagesize<br><br>
	 * いずれにも設定がない場合は1000を設定します。
	 * @param blkId ブロックＩＤ
	 */
	protected void setDefaultCountSize() {
		if (isNull(getBtnR().count())) {
			MCNumber val = MCNumber.valueOf(1000);
			FXBAP_PanelBase xp = getXpanelPagingAgentHolder();
			for (FXBAP_PagingParam p : super.getPagingParam()) {
				if (p != null) {
					if (xp != null) {
						MCNumber n = getPgmSettingNumberNE(
								getBaseXPanel(), null, p.getTargetBlockId(), "pagesize");
						if (n == null) {
							n = getPgmSettingNumberNE(
									getBaseXPanel(), null, "pagesize");
						}
						if (n == null) {
							n = MCConst.app.getNumber("FX.pagesize", val);
						}
						if (n != null) {
							val = n;
						}
					}
					setValueEx(Btn_count, val);
				}
			}
		}
	}

	/**
	 * {@inheritDoc}<p>
	 * 表示位置を表示するラベルをクリアします。
	 */
	@Override
	public void setDISABLEStatus() {
		super.setDISABLEStatus();
		
		getBtnR().disp(null);
		Btn_disp.setToolTipText(null);		
	}
	
	@Override
	protected void beansAttrInit() {
		super.beansAttrInit();
		
		Btn_disp.setBorder(null);
	}

}