// FMSE PANEL_EI
package mcframe.clientFXUC.FXUCP0090;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.commonCore.annotation.EI;

/**
 * 画面"FXUCP_VerticalViewUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FXUCP_VerticalViewUtil extends FXUCP_VerticalViewUtil_FW {

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_VerticalViewUtil() {
		super();
	}

}