package mcframe.clientFXUC.FXUCP0090;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_VerticalViewUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_VerticalViewUtil_FW extends FXUCP_VerticalViewUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	
	/**
	 * static メソッドのアクセス用フィールドです。
	 */
	protected static FXUCP_VerticalViewUtil _util = new FXUCP_VerticalViewUtil();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_VerticalViewUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	/**
	 * 指定された画面に縦表示（見出し用）の対象となる項目が存在する場合は true を返します。
	 * 
	 * @param panel 画面
	 * @return 指定された画面に縦表示（見出し用）の対象となる項目が存在しない場合は false
	 */
	public static boolean isTargetPanel(MCRootPanel panel) {
		return _util._isTargetPanel(panel);
	}
	
	/**
	 * 指定された画面に縦表示（見出し用）の対象となる項目が存在する場合は true を返します。
	 * 
	 * @param panel 画面
	 * @return 指定された画面に縦表示（見出し用）の対象となる項目が存在しない場合は false
	 */
	protected boolean _isTargetPanel(MCRootPanel panel) {
		for (MCTabOrderBeans c : panel.getTabOrderBeans()) {
			if (c instanceof Component && isTargetBeans((Component)c)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 指定された GUI 部品が縦表示（見出し用）の対象となる項目の場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return 指定された GUI 部品が縦表示（見出し用）の対象となる項目ではない場合は false
	 */
	public static boolean isTargetBeans(Component compo) {
		return _util._isTargetBeans(compo);
	}
	
	/**
	 * 指定された GUI 部品が縦表示（見出し用）の対象となる項目の場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return 指定された GUI 部品が縦表示（見出し用）の対象となる項目ではない場合は false
	 */	
	protected boolean _isTargetBeans(Component compo) {
		if (!(compo instanceof MCRowBeans) 
				&& !(compo instanceof MCRadioButton)) {
			return false;
		}

		if (!(compo instanceof MCModeBeans) 
				|| MCMode.isInvisible((MCModeBeans)compo)) {
			return false;
		}

		Component c = compo;
		
		while (c != null) {
			if (c instanceof MCRootPanel
					&& !(((MCRootPanel) c).isPartsPanel())) {
				break;
			}
			
			Component p = c.getParent();
			
			if (!c.isVisible()) {
				if (p instanceof MCTabbedPane) {
					MCTabbedPane tp = (MCTabbedPane) p;
					if (!tp.isVisible()) {
						return false;
					}
					int i = tp.indexOfComponent(c);
					if (i != -1 && tp.isEnabledAt(i)) {
						c = p;
						continue;
					}
				}
				return false;
			}
			c = p;
		}
		
		return true;
	}

}