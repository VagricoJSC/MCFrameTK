package mcframe.clientFXUC.FXUCP0070;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JComponent;

import mcframe.clientCore.beans.resource.MCPersonalizeResourceIO;
import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
import mcframe.clientCore.beans.text.MCCalendarFormat;
import mcframe.clientCore.beans.text.MCDateFormat;
import mcframe.clientCore.beans.text.MCTimestampFormat;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;
import mcframe.clientCore.sys.MCSys;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
import mcframe.commonCore.util.MCCollectionUtil;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_SrchCndUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_SrchCndUtil_FW extends FXUCP_SrchCndUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * static メソッドのアクセス用フィールドです。
	 */
	protected static FXUCP_SrchCndUtil _util = new FXUCP_SrchCndUtil();

	/**
	 * 検索条件のパーソナライズデータであることを表すキーです。
	 */
	protected static final String P_SRCH_CND_KEY = "p_srch_cnd";

	/**
	 * リソースキーです。
	 * 初期検索ＦＬＧを取得するときに使用します。
	 */
	protected static final String SRCH_FLG_KEY = "srch_flg";

	/**
	 * リソースキーです。
	 * 画面クリア時設定可否ＦＬＧを取得するときに使用します。
	 */
	protected static final String CLEAR_FLG_KEY = "clear_flg";

	/**
	 * リソースキーです。
	 * ラジオボタンの名称の区切り文字を取得するときに使用します。
	 */
	protected static final String BTN_GRP_NM_DLM = "BTN_GRP_NM_DLM";

	/**
	 * 設定情報名、備考を取得するためのリソースキーです。
	 */
	protected static final String INFO_PREFIX = "info";

	/**
	 * 入力値設定の適用順リソースキー
	 */
	protected static final String SRCH_CND_ORDER_KEY = "srch_cnd";
	
	/**
	 * 入力値設定のポップアップメニューから選択時の適用順リソースキー
	 */
	protected static final String SRCH_CND_UPDATE_ORDER_KEY = "update_order";
	
	/**
	 * 入力値設定のポップアップメニューから選択時の適用順：昇順（定義順）
	 */
	protected static final String SRCH_CND_UPDATE_ORDER_ASC = "asc";	
	
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_SrchCndUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	/**
	 * 検索条件の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 */
	public static void setInitCnd(IfSrchCndBase panel, SrchCndInfo info) {
		_util._setInitCnd(panel, info);
	}

	/**
	 * 検索条件の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 */
	protected void _setInitCnd(IfSrchCndBase panel, SrchCndInfo info) {
		if (panel == null || info == null) {
			return;
		}

		List<Object[]> ol = getSrchCndBeans(panel, true);
		List<SrchCndR> sl = new ArrayList<>();
		sl.addAll(info.getSrchCndList());
		if (ol == null || sl.size() == 0) {
			return;
		}

		List<Object[]> kl = createGUIKeyList(ol);

		for (Object[] oa : ol) {
			MCRowBeans c = (MCRowBeans) oa[1];
			if (!_isModeEditable(c)) {
				continue;
			}

			String k = null;
			for (Object[] ka : kl) {
				if (c.equals(ka[0])) {
					k = (String) ka[1];
					break;
				}
			}
			for (SrchCndR s : sl) {
				if (MCStringUtil.eq(s.field_key(), k)) {
					_setInitCnd(panel, s, c);
					sl.remove(s);
					break;
				}
			}
		}
	}

	/**
	 * 検索条件の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 */
	protected void _setInitCnd(IfSrchCndBase panel, SrchCndR data, MCRowBeans compo) {
		if (!data.set_flg()) {
			return;
		}

		MCDataType t = compo.getDataType();
		if (t == null) {
			return;
		}

		switch (t) {
			case STRING:
				if (compo instanceof MCButtonGroup) {
					_setInitCndRadio(panel, data, (MCButtonGroup) compo);
				}
				else {
					_setInitCndText(panel, data, compo);
				}
				break;
			case BOOLEAN:
				_setInitCndCheck(panel, data, compo);
				break;
			case DATE:
				_setInitCndDate(panel, data, compo);
				break;
			case TIMESTAMP:
				_setInitCndTimestamp(panel, data, compo);
				break;
			case NUMBER:
				_setInitCndNumber(panel, data, compo);
				break;
			default:
				break;
		}
	}

	/**
	 * 検索条件（ラジオボタン項目）の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo ボタングループ
	 */
	protected void _setInitCndRadio(IfSrchCndBase panel, SrchCndR data,
			MCButtonGroup compo) {
		String v = data.radio();
		for (MCRadioButton c : compo.getRadioButtons()) {
			if (!isSame(c.getActionCommand(), v)) {
				continue;
			}
			if (_isModeEditable(c)) {
				compo.setViewValue(v);
			}
			break;
		}
	}

	/**
	 * 検索条件（文字列項目）の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 */
	protected void _setInitCndText(IfSrchCndBase panel, SrchCndR data, MCRowBeans compo) {
		if (!MCDataType.STRING.equals(compo.getDataType())) {
			return;
		}
		// 7012-3342 (入力値設定の初期でマクロが変換されない不具合)
		// 7013-0110 (入力値設定の初期でマクロが変換されない不具合)
		String str = data.text();
		// マクロ置換
		String str2 = getMacroString(str);
		compo.setViewValue(str2);

//		compo.setViewValue(data.text());
		// 7013-0110 ここまで
		// 7012-3342 ここまで
	}

	/**
	 * 検索条件（チェックボックス項目）の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 */
	protected void _setInitCndCheck(IfSrchCndBase panel, SrchCndR data,
			MCRowBeans compo) {
		if (!MCDataType.BOOLEAN.equals(compo.getDataType())) {
			return;
		}
		compo.setViewValue(data.check());
	}

	/**
	 * 検索条件（日付項目）の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 */
	protected void _setInitCndDate(IfSrchCndBase panel, SrchCndR data, MCRowBeans compo) {
		if (!MCDataType.DATE.equals(compo.getDataType())) {
			return;
		}

		MCDate v = (MCDate) _getDateDiffValue(panel, data, compo);

		v = (MCDate) adjustValueByCalenderFormat(compo, v);

		compo.setViewValue(v);
	}

	/**
	 * 検索条件（日付項目）の初期値を返します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 * @return 検索条件（日付項目）の初期値
	 */
	protected MCCalendarDate<?> _getDateDiffValue(IfSrchCndBase panel, SrchCndR data,
			MCRowBeans compo) {
		MCDataType t = compo.getDataType();
		if (t == null) {
			return null;
		}
		switch (t) {
			case DATE:
				MCDate d = panel.today(t);
				return _getDateDiffValue(panel, data, compo, d);
			case TIMESTAMP:
				MCTimestamp ts = panel.today(t);
				return _getDateDiffValue(panel, data, compo, ts);
			default:
				return null;
		}
	}

	/**
	 * 検索条件（日付項目）の初期値を返します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 * @param date 日付
	 * @return 検索条件（日付項目）の初期値
	 */
	protected MCCalendarDate<?> _getDateDiffValue(IfSrchCndBase panel, SrchCndR data,
			MCRowBeans compo, MCCalendarDate<?> date) {

		// 差分（月）
		MCNumber v = data.month();

		// 日付（今日）の場合
		if (data.today_flg()) {
			if (v != null) {
				date = date.addMonth(v);
			}
		}
		// 日付（月初）の場合
		else if (data.firstday_flg()) {
			if (v != null) {
				date = date.addMonth(v);
			}
			date = date.startOfMonth();
		}
		// 日付（月末）の場合
		else if (data.lastday_flg()) {
			if (v != null) {
				date = date.addMonth(v);
			}
			date = date.endOfMonth();
		}
		else {
			if (MCDataType.DATE.equals(compo.getDataType())) {
				date = MCDate.valueOf(data.date());
			}
			else {
				date = data.date();
			}
			// 日付（固定値）の場合
			if (date != null) {
				if (v != null) {
					date = date.addMonth(v);
				}
			}
		}

		if (date == null) {
			return date;
		}

		// 差分（週）
		v = data.week();
		if (v != null) {
			date = date.addDay(v.multiply(7));
			String t = data.day_of_week_type();
			if (!isNull(t)) {
				int dw = Integer.parseInt(t) - date.getDayOfWeek();
				date = date.addDay(dw);
			}
		}

		// 差分（日）
		v = data.day();
		if (v != null) {
			date = date.addDay(v);
		}
		// 差分（時）
		v = data.hour();
		if (v != null) {
			date = date.addHour(v);
		}
		// 差分（分）
		v = data.minute();
		if (v != null) {
			date = date.addMinute(v);
		}

		return date;
	}

	/**
	 * 検索条件（タイムスタンプ項目）の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 */
	protected void _setInitCndTimestamp(IfSrchCndBase panel, SrchCndR data,
			MCRowBeans compo) {
		if (!MCDataType.TIMESTAMP.equals(compo.getDataType())) {
			return;
		}

		MCTimestamp v = (MCTimestamp) _getDateDiffValue(panel, data, compo);

		v = (MCTimestamp) adjustValueByCalenderFormat(compo, v);

		compo.setViewValue(v);
	}

	/**
	 * 検索条件（数値項目）の初期値を設定します。
	 *
	 * @param panel 画面
	 * @param data 検索条件に関する情報
	 * @param compo GUI 部品
	 */
	protected void _setInitCndNumber(IfSrchCndBase panel, SrchCndR data,
			MCRowBeans compo) {
		if (!MCDataType.NUMBER.equals(compo.getDataType())) {
			return;
		}
		compo.setViewValue(data.num());
	}

	/**
	 * 初期フォーカスを設定します。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 */
	public static void setInitFocus(IfSrchCndBase panel, SrchCndInfo info) {
		_util._setInitFocus(panel, info);
	}

	/**
	 * 初期フォーカスを設定します。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 */
	protected void _setInitFocus(IfSrchCndBase panel, SrchCndInfo info) {
		if (panel == null || info == null) {
			return;
		}

		List<Object[]> ol = getSrchCndBeans(panel, true);
		List<SrchCndR> sl = new ArrayList<>();
		sl.addAll(info.getSrchCndList());
		if (ol == null || sl.size() == 0) {
			return;
		}

		List<Object[]> kl = createGUIKeyList(ol);

		for (Object[] oa : ol) {
			MCRowBeans c = (MCRowBeans) oa[1];
			if (!_isModeEditable(c)) {
				continue;
			}

			String k = null;
			for (Object[] ka : kl) {
				if (c.equals(ka[0])) {
					k = (String) ka[1];
					break;
				}
			}

			for (SrchCndR s : sl) {
				if (!MCStringUtil.eq(s.field_key(), k)) {
					continue;
				}
				if (!s.focus_flg()) {
					sl.remove(s);
					break;
				}
				if (c instanceof MCButtonGroup) {
					MCButtonGroup g = (MCButtonGroup) c;
					for (MCRadioButton b : g.getRadioButtons()) {
						if (_isModeEditable(b)) {
							MCBeansUtil.focus(b);
							return;
						}
					}
				}
				else if (c instanceof JComponent) {
					MCBeansUtil.focus((JComponent) c);
				}
				return;
			}
		}
	}

	/**
	 * 入力値設定対象枠の GUI 部品のリストを返します。<p>
	 * 指定された画面の入力値設定対象枠に配置されている GUI 部品のリストを返します。
	 * 非表示項目は除外されます。<p>
	 * 引数 sort に true を指定した場合は、GUI 部品のリストをタブ移動順にソートします。
	 *
	 * @param panel 画面
	 * @param sort リストをソートしない場合は false
	 * @return リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	public static List<Object[]> getSrchCndBeans(IfSrchCndBase panel, boolean sort) {
		return _util._getSrchCndBeans(panel, sort);
	}

	/**
	 * 入力値設定対象枠の GUI 部品のリストを返します。<p>
	 * 指定された画面の入力値設定対象枠に配置されている GUI 部品のリストを返します。
	 * 非表示項目は除外されます。<p>
	 * 引数 sort に true を指定した場合は、GUI 部品のリストをタブ移動順にソートします。
	 *
	 * @param panel 画面
	 * @param sort ソートするかどうか
	 * @return リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	protected List<Object[]> _getSrchCndBeans(IfSrchCndBase panel, boolean sort) {
		List<Object[]> list = new ArrayList<>();
		if (panel == null) {
			return list;
		}

		List<MCPanel> l = getSrchPanels(panel);
		if (l == null) {
			return list;
		}

		for (MCPanel p : l) {
			list.addAll(_getRowBeans(p));
		}

		if (sort) {
			list = _sort(panel, list);
		}

		return list;
	}

	/**
	 * GUI 部品のリストを返します。<p>
	 * 指定されたパネル（枠）に配置されている GUI 部品のリストを返します。
	 * 非表示項目は除外されます。
	 *
	 * @param panel パネル（枠）
	 * @return リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	protected List<Object[]> _getRowBeans(MCPanel panel) {
		List<Object[]> l = new ArrayList<>();
		if (panel == null) {
			return l;
		}

		String n = panel.getName();
		List<MCButtonGroup> a = new ArrayList<>();

		for (MCModeBeans c : MCBeansUtil.getAllComponents(MCModeBeans.class, panel)) {
			if (_isModeInvisible(c) || c instanceof MCEditorBeans) {
				continue;
			}
			else if (c instanceof MCRadioButton) {
				MCButtonGroup g = ((MCRadioButton) c).getGroup();
				if (!MCCollectionUtil.contains(a, g)) {
					l.add(new Object[] {
							n, g
					});
					a.add(g);
				}
			}
			else if (c instanceof MCRowBeans) {
				l.add(new Object[] {
						n, (MCRowBeans) c
				});
			}
		}

		return l;
	}

	/**
	 * リストをソートします。
	 * 指定された画面のタブ移動順にソートします。<p>
	 * リストにタブ移動対象外の GUI 部品が含まれる場合は、末尾に追加します。
	 *
	 * @param panel 枠
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 * @return ソートされたリスト
	 */
	protected List<Object[]> _sort(IfSrchCndBase panel, List<Object[]> list) {
		List<Object[]> l = new ArrayList<>();

		List<Object[]> tmp = new ArrayList<>();
		tmp.addAll(list);

		for (MCTabOrderBeans t : panel.getTabOrderBeans()) {
			MCRowBeans c = null;
			if (t instanceof MCRadioButton) {
				c = ((MCRadioButton) t).getGroup();
			}
			else if (t instanceof MCRowBeans) {
				c = (MCRowBeans) t;
			}

			if (c == null) {
				continue;
			}

			for (Object[] o : tmp) {
				if (c == o[1]) {
					l.add(o);
					tmp.remove(o);
					break;
				}
			}
		}

		l.addAll(tmp);

		return l;
	}

	/**
	 * GUI 部品のモードをチェックします。
	 * GUI 部品のモードが入力可能な場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return GUI 部品のモードが入力可能ではない場合は false
	 */
	protected boolean _isModeEditable(MCRowBeans compo) {
		if (compo instanceof MCButtonGroup) {
			for (MCRadioButton c : ((MCButtonGroup) compo).getRadioButtons()) {
				if (_isModeEditable(c)) {
					return true;
				}
			}
		}
		else if (compo instanceof MCModeBeans) {
			return _isModeEditable((MCModeBeans) compo);
		}
		return false;
	}

	/**
	 * GUI 部品のモードをチェックします。
	 * GUI 部品のモードが入力可能な場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return GUI 部品のモードが入力可能ではない場合は false
	 */
	protected boolean _isModeEditable(MCModeBeans compo) {
		MCModeInfo i = compo.getModeInfo();
		return i != null ? i.getStatus() == MCMode.ENABLE_STATUS : false;
	}

	/**
	 * GUI 部品のモードをチェックします。
	 * GUI 部品のモードが非表示の場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return GUI 部品のモードが非表示ではない場合は false
	 */
	protected boolean _isModeInvisible(MCModeBeans compo) {
		MCModeInfo i = compo.getModeInfo();
		return i != null ? i.getStatus() == MCMode.INVISIBLE_STATUS : false;
	}

	/**
	 * 初期検索を実行します。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 */
	public static void doInitSrch(IfSrchCndBase panel, SrchCndInfo info) {
		_util._doInitSrch(panel, info);
	}

	/**
	 * 初期検索を実行します。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 */
	protected void _doInitSrch(IfSrchCndBase panel, SrchCndInfo info) {
		if (panel == null || info == null) {
			return;
		}

		if (info.getInitSrchFlg()) {
			panel.doSrchAction();
		}
	}

	/**
	 * 指定された画面の入力値設定に関するリソースを削除します。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 */
	public static void removeResource(String type, IfSrchCndBase panel) {
		_util._removeResource(type, panel);
	}

	/**
	 * 指定された画面の入力値設定に関するリソースを削除します。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 */
	protected void _removeResource(String type, IfSrchCndBase panel) {
		_removeResourceImpl(type, panel, true);
	}

	/**
	 * 指定された画面の入力値設定に関するリソースを削除します。<br>
	 * 変更を保存はしません。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 */
	public static void removeResourceNoSave(String type, IfSrchCndBase panel) {
		_util._removeResourceNoSave(type, panel);
	}

	/**
	 * removeResourceNoSaveで指定したIDのみを削除するメソッド。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 * @param setting_info_id 設定情報ID
	 */
	public static void removeResourceNoSaveById(String type, IfSrchCndBase panel, String setting_info_id) {
		_util._removeResourceNoSaveById(type, panel, setting_info_id);
	}

	/**
	 * 指定された画面の入力値設定に関するリソースを削除します。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 */
	protected void _removeResourceNoSave(String type, IfSrchCndBase panel) {
		_removeResourceImpl(type, panel, false);

	}

	/**
	 * _removeResourceNoSaveで指定したIDのみを削除するメソッド。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 * @param setting_info_id 設定情報ID
	 */
	protected void _removeResourceNoSaveById(String type, IfSrchCndBase panel, String setting_info_id) {
		_removeResourceImplById(type, panel, false, setting_info_id);

	}

	protected void _removeResourceImpl(String type, IfSrchCndBase panel, boolean doSave) {

		if (panel == null) {
			return;
		}

		MCResourceLayerType y = toResourceLayerType(type);
		if (y == null) {
			return;
		}

		String k = _srch_cnd_io.createSrchCndKey(panel, y);
		String[] ka = getResource().findPattern(y, k + ".**");
		getResource().remove(y, ka);

		if (doSave) {
			MCPersonalizeResourceIO.saveResource();
		}
	}

	/**
	 * _removeResourceImplで指定したIDのみを削除するメソッド。
	 *
	 * @param type 設定情報単位
	 * @param panel 画面
	 * @param doSave 保存するかどうかのフラグ
	 * @param setting_info_id 設定情報ID
	 */
	protected void _removeResourceImplById(String type, IfSrchCndBase panel, boolean doSave, String setting_info_id) {

		if (panel == null) {
			return;
		}

		MCResourceLayerType y = toResourceLayerType(type);
		if (y == null) {
			return;
		}

		String k = _srch_cnd_io.createSrchCndKey(panel, y);
		String[] ka = getResource().findPattern(y, k + "." + setting_info_id + ".**");
		getResource().remove(y, ka);

		// 初期設定のリソースが引数のIDと一致する場合は削除
		String ik = MCConst.createKey(k, "init");
		String iv = getResource().getString(ik);
		if(iv != null && iv.equals(setting_info_id)) {
			getResource().remove(y, ik);
		}

		if (doSave) {
			MCPersonalizeResourceIO.saveResource();
		}
	}

	protected MCResourceLayerType toResourceLayerType(String type) {
		for (MCResourceLayerType v : MCResourceLayerType.values()) {
			if (v.name().equals(type)) {
				return v;
			}
		}
		return null;
	}

	/**
	 * 入力値設定情報を取得、登録するためのリソースを返します。
	 *
	 * @return リソース
	 */
	public static MCGeneralPersonalizeResource getResource() {
		return _util._getResource();
	}

	/**
	 * 入力値設定情報を取得、登録するためのリソースを返します。
	 *
	 * @return リソース
	 */
	protected MCGeneralPersonalizeResource _getResource() {
		return MCConst.app;
	}

	public static SrchCndR getData(IfSrchCndBase panel, MCRowBeans compo, SrchCndR data) {
		return _util._getData(panel, compo, data);
	}

	/**
	 *
	 * 検索条件に関する情報を設定します。
	 *
	 * @param prefix リソースキーの接頭辞
	 * @param panel 画面
	 * @param name 枠名
	 * @param label 枠のラベル名
	 * @param compo GUI 部品
	 * @param field_key GUI 部品のリソースキー
	 * @param data 設定する情報を格納したコンテナ
	 * @return 情報を設定したコンテナ
	 */
	protected SrchCndR _getData(IfSrchCndBase panel, MCRowBeans compo, SrchCndR data) {
		if (panel == null || compo == null || data == null) {
			return null;
		}

		SrchCndR o = data.createInstance();
		o.set_flg(false);

		o.field_key(data.field_key());
		o.name(data.name());
		o.panel_name(data.panel_name());
		o.focus_flg(data.focus_flg());
		o.required_flg(data.required_flg());

		MCDataType y = compo.getDataType();
		if (y == null) {
			return o;
		}

		switch (y) {
			case STRING:
				if (compo instanceof MCButtonGroup) {
					setRadioValue(panel, (MCButtonGroup) compo, data, o);
				}
				else {
					setTextValue(panel, compo, data, o);
				}
				break;
			case BOOLEAN:
				setCheckValue(panel, compo, data, o);
				break;
			case DATE:
				setDateValue(panel, compo, data, o);
				break;
			case TIMESTAMP:
				setTimestampValue(panel, compo, data, o);
				break;
			case NUMBER:
				setNumberValue(panel, compo, data, o);
				break;
			default:
				break;
		}

		return o;
	}

	/**
	 * 検索条件に関する情報（ラジオボタン項目）を設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setRadioValue(IfSrchCndBase panel, MCButtonGroup compo, SrchCndR from,
			SrchCndR to) {
		MCRadioButton rb = compo.getSelectedButton();
		if (rb == null) {
			return;
		}

		to.radio(rb.getActionCommand());
		to.radio_nm(getRadioButtonName(rb));
	}

	/**
	 * 検索条件に関する情報（文字列項目）をコンテナに設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setTextValue(IfSrchCndBase panel, MCRowBeans compo, SrchCndR from,
			SrchCndR to) {
		if (!MCDataType.STRING.equals(compo.getDataType())) {
			return;
		}
		to.text((String) compo.getRowValue());
	}

	/**
	 * 検索条件に関する情報（チェックボックス項目）をコンテナに設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setCheckValue(IfSrchCndBase panel, MCRowBeans compo, SrchCndR from,
			SrchCndR to) {
		if (!MCDataType.BOOLEAN.equals(compo.getDataType())) {
			return;
		}
		to.check((Boolean) compo.getRowValue());
	}

	/**
	 * 検索条件に関する情報（日付項目）をコンテナに設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setDateValue(IfSrchCndBase panel, MCRowBeans compo, SrchCndR from,
			SrchCndR to) {
		if (!MCDataType.DATE.equals(compo.getDataType())) {
			return;
		}

		MCDate v = (MCDate) compo.getRowValue();

		SrchCndR o = from.clone();

		MCDate t = panel.today(MCDataType.DATE);
		MCDate m = (MCDate) adjustValue(compo, o, t);
		if (isSame(v, m)) {
			to.today_flg(o.today_flg());
			to.firstday_flg(o.firstday_flg());
			to.lastday_flg(o.lastday_flg());
			to.date(o.date());
			to.month(o.month());
			to.week(o.week());
			to.day_of_week_type(o.day_of_week_type());
			to.day(o.day());
			to.hour(o.hour());
			to.minute(o.minute());
		}
		else {
			to.date(v != null ? v.toMCTimestamp() : null);
		}
	}

	/**
	 * 検索条件に関する情報（タイムスタンプ項目）をコンテナに設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setTimestampValue(IfSrchCndBase panel, MCRowBeans compo, SrchCndR from,
			SrchCndR to) {
		if (!MCDataType.TIMESTAMP.equals(compo.getDataType())) {
			return;
		}

		MCTimestamp v = (MCTimestamp) compo.getRowValue();

		SrchCndR o = from.clone();

		MCTimestamp t = panel.today(MCDataType.TIMESTAMP);
		MCTimestamp m = (MCTimestamp) adjustValue(compo, o, t);
		if (isSame(v, m)) {
			to.today_flg(o.today_flg());
			to.firstday_flg(o.firstday_flg());
			to.lastday_flg(o.lastday_flg());
			to.date(o.date());
			to.month(o.month());
			to.week(o.week());
			to.day_of_week_type(o.day_of_week_type());
			to.day(o.day());
			to.hour(o.hour());
			to.minute(o.minute());
		}
		else {
			to.date(v);
		}
	}

	protected MCCalendarDate<?> adjustValue(MCRowBeans compo, SrchCndR data,
			MCCalendarDate<?> date) {

		// 差分（月）
		MCNumber d = data.month();

		// 日付（今日）の場合
		if (data.today_flg()) {
			if (d != null) {
				date = date.addMonth(d);
			}
		}
		// 日付（月初）の場合
		else if (data.firstday_flg()) {
			if (d != null) {
				date = date.addMonth(d);
			}
			date = date.startOfMonth();
		}
		// 日付（月末）の場合
		else if (data.lastday_flg()) {
			if (d != null) {
				date = date.addMonth(d);
			}
			date = date.endOfMonth();
		}

		else {
			// 日付（固定値）の場合
			MCTimestamp ts = data.date();
			if (ts != null && MCDataType.DATE.equals(compo.getDataType())) {
				date = ts.toMCDate();
			}
			else {
				date = ts;
			}
			if (date != null) {
				if (d != null) {
					date = date.addMonth(d);
				}
			}
		}

		if (date == null) {
			return date;
		}

		// 差分（週）
		d = data.week();
		if (d != null) {
			date = date.addDay(d.multiply(7));
			String t = data.day_of_week_type();
			if (!isNull(t)) {
				int dw = Integer.parseInt(t) - date.getDayOfWeek();
				date = date.addDay(dw);
			}
		}

		// 差分（日）
		d = data.day();
		if (d != null) {
			date = date.addDay(d);
		}

		// 差分（時）
		d = data.hour();
		if (d != null) {
			date = date.addHour(d);
		}

		// 差分（分）
		d = data.minute();
		if (d != null) {
			date = date.addMinute(d);
		}

		return date;
	}

	/**
	 * 検索条件に関する情報（数値項目）をコンテナに設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 情報を設定するコンテナ
	 */
	protected void setNumberValue(IfSrchCndBase panel, MCRowBeans compo, SrchCndR from,
			SrchCndR to) {
		if (!MCDataType.NUMBER.equals(compo.getDataType())) {
			return;
		}
		to.num((MCNumber) compo.getRowValue());
	}

	/**
	 * 検索条件に関する情報をリソースに保存します。<p>
	 * 保存に失敗した場合もクライアントリソースはコミットされます。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	public static void writeResource(IfSrchCndBase panel, Map<String, Integer> map,
			List<SrchCndInfo> info, List<Object[]> list) {
		_util._writeResource(panel, map, info, list);
	}

	/**
	 * 検索条件に関する情報をリソースに保存します。<p>
	 * 保存に失敗した場合もクライアントリソースはコミットされます。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	protected void _writeResource(IfSrchCndBase panel, Map<String, Integer> map,
			List<SrchCndInfo> info, List<Object[]> list) {
		_srch_cnd_io.writeResource(panel, map, info, list);
	}

	/**
	 * 検索条件に関する情報をリソースに設定します。<p>
	 * 変更を保存はしません。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	public static void writeResourceNoSave(IfSrchCndBase panel, Map<String, Integer> map,
			List<SrchCndInfo> info, List<Object[]> list) {
		_util._writeResourceNoSave(panel, map, info, list);
	}

	/**
	 * 検索条件に関する情報をリソースに設定します。<p>
	 * 変更を保存はしません。
	 *
	 * @param panel 画面
	 * @param info 検索条件に関する情報
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	protected void _writeResourceNoSave(IfSrchCndBase panel, Map<String, Integer> map,
			List<SrchCndInfo> info, List<Object[]> list) {
		_srch_cnd_io.writeResourceNoSave(panel, map, info, list);
	}

	/**
	 * 画面の検索条件を更新します。
	 *
	 * @param panel 画面
	 * @param list 検索条件に関する情報
	 * @param compos リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	public static void updateCnd(IfSrchCndBase panel, List<SrchCndR> list,
			List<Object[]> compos) {
		_util._updateCnd(panel, list, compos);
	}

	/**
	 * 画面の検索条件を更新します。
	 *
	 * @param panel 画面
	 * @param list 検索条件に関する情報
	 * @param compos リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 */
	protected void _updateCnd(IfSrchCndBase panel, List<SrchCndR> list,
			List<Object[]> compos) {
		if (panel == null || list == null || compos == null) {
			return;
		}
		/* 設定と実際の表示項目とで数が変わる場合がある。
		if (compos.size() != list.size()) {
			return;
		}
		*/
		
		//#7033-1901
		//適用順が指定されている場合は設定に従う。
		String order = getUpdateSortOrder(panel);
		if (order != null && SRCH_CND_UPDATE_ORDER_ASC.equals(order)) {
			// 初期ONと同じ順番で必須フラグ以外の設定を適用
			_setInitCnd(panel, list, compos);
			// 必須フラグを適用
			setRequired(list, compos);
			return;
		}

		// 6.4.0 モードを先に切り替えないと入力不可で値が設定できない。

		for (int i = 0; i < compos.size(); i++) {
			Object[] a = compos.get(i);
			MCRowBeans c = (MCRowBeans) a[1];
			// #7014-5647
//			if (!_isModeEditable(c)) {
//				continue;
//			}

//			SrchCndR d = list.get(i);
			// 簡易バグ票No.54の対応（ここから）
			// キーが一致する項目を探す
			String id = _createGUIKey((String) a[0], c);
			SrchCndR d = null;
			for (SrchCndR o : list) {
				if (o.field_key().equals(id)) {
					d = o;
					break;
				}
			}
//			String id = "";
//			if (c instanceof MCButtonGroup) {
//				MCButtonGroup bg = (MCButtonGroup) c;
//				id = bg.getName();
//			}
//			else {
//				id = ((Component) c).getParent().getName() + "." + c.getName();
//			}
//			SrchCndR d = getSrchCndR(id, list);
			// 簡易バグ票No.54の対応（ここまで）
			if (d == null) {
				continue;
			}
			if (!d.set_flg()) {
				continue;
			}

			c.setRequiredFlg(d.required_flg());

			// #7014-5647 必須フラグは入力不可項目でもセットするためモード判定を移動
			if (!_isModeEditable(c)) {
				continue;
			}

			MCDataType t = c.getDataType();
			if (t == null) {
				continue;
			}

			switch (t) {
				case STRING:
					if (c instanceof MCButtonGroup) {
						_updateRadioCnd(panel, (MCButtonGroup) c, d);
					}
					break;
				default:
					break;
			}
		}

		for (int i = 0; i < compos.size(); i++) {
			Object[] a = compos.get(i);
			MCRowBeans c = (MCRowBeans) a[1];
			if (!_isModeEditable(c)) {
				continue;
			}

//			SrchCndR d = list.get(i);
			// 簡易バグ票No.54の対応（ここから）
			// キーが一致する項目を探す
			String id = _createGUIKey((String) a[0], c);
			SrchCndR d = null;
			for (SrchCndR o : list) {
				if (o.field_key().equals(id)) {
					d = o;
					break;
				}
			}
//			String id = "";
//			if (c instanceof MCButtonGroup) {
//				MCButtonGroup bg = (MCButtonGroup) c;
//				id = bg.getName();
//			}
//			else {
//				id = ((Component) c).getParent().getName() + "." + c.getName();
//			}
//			SrchCndR d = getSrchCndR(id, list);
			// 簡易バグ票No.54の対応（ここまで）
			if (d == null) {
				continue;
			}
			if (!d.set_flg()) {
				continue;
			}

//			c.setRequiredFlg(d.required_flg());

			MCDataType t = c.getDataType();
			if (t == null) {
				continue;
			}

			switch (t) {
				case STRING:
					if (c instanceof MCButtonGroup) {
						// 6.4.0
						//_updateRadioCnd(panel, (MCButtonGroup) c, d);
					}
					else {
						// _updateTextCnd(panel, c, d);
						_updateTextCnd2(panel, c, d);
					}
					break;
				case BOOLEAN:
					_updateCheckCnd(panel, c, d);
					break;
				case DATE:
					_updateDateCnd(panel, c, d);
					break;
				case TIMESTAMP:
					_updateTimestampCnd(panel, c, d);
					break;
				case NUMBER:
					_updateNumberCnd(panel, c, d);
					break;
				default:
					break;
			}
		}
	}
	
	//#7033-1901追加
	/**
	 * 更新時の適用順のリソース設定を取得<p>
	 * 
	 * @param panel 画面
	 * @return リソース値。未指定の場合はnull。
	 */
	protected String getUpdateSortOrder(IfSrchCndBase panel) {
		String keySys = MCConst.createKey(SRCH_CND_ORDER_KEY, SRCH_CND_UPDATE_ORDER_KEY);
		String keyScreen = MCConst.createKey(panel.getModuleID(), panel.getScreenID(), keySys);
		String order = MCConst.app.getString(keyScreen, MCConst.app.getString(keySys, null));
		return order;
	}
	
	//#7033-1901追加
	/**
	 * 入力値設定の必須フラグをGUI部品に設定する。
	 * 
	 * @param list 入力値設定のリスト
	 * @param compos GUI部品のリスト
	 */
	protected void setRequired(List<SrchCndR> list, List<Object[]> compos) {
		List<SrchCndR> sl = new ArrayList<>();
		sl.addAll(list);
		if (compos == null || sl.size() == 0) {
			return;
		}
		for (int i = 0; i < compos.size(); i++) {
			Object[] a = compos.get(i);
			MCRowBeans c = (MCRowBeans) a[1];

			String id = _createGUIKey((String) a[0], c);
			SrchCndR d = null;
			for (SrchCndR o : sl) {
				if (o.field_key().equals(id)) {
					d = o;
					sl.remove(o);
					break;
				}
			}

			if (d == null) {
				continue;
			}
			if (!d.set_flg()) {
				continue;
			}

			c.setRequiredFlg(d.required_flg());
		}
	}
	
	//#7033-1901追加
	/**
	 * 入力値設定の初期ON時の適用処理。<p>
	 * 引数compos順に設定を適用します。
	 * updateCndから呼ばれるため{@link #_setInitCnd(IfSrchCndBase, SrchCndInfo)}の引数を変更した。
	 *  
	 * @param panel 画面
	 * @param list 入力値設定のリスト
	 * @param compos GUI部品のリスト
	 */
	protected void _setInitCnd(IfSrchCndBase panel, List<SrchCndR> list, List<Object[]> compos) {
		List<SrchCndR> sl = new ArrayList<>();
		sl.addAll(list);
		if (compos == null || sl.size() == 0) {
			return;
		}

		List<Object[]> kl = createGUIKeyList(compos);
		for (Object[] oa : compos) {
			MCRowBeans c = (MCRowBeans) oa[1];
			if (!_isModeEditable(c)) {
				continue;
			}
			String k = null;
			for (Object[] ka : kl) {
				if (c.equals(ka[0])) {
					k = (String) ka[1];
					break;
				}
			}
			if (k == null) {
				continue;
			}
			for (SrchCndR s : sl) {
				if (MCStringUtil.eq(s.field_key(), k)) {
					_setInitCnd(panel, s, c);
					sl.remove(s);
					break;
				}
			}
		}
	}

	static final String MACRO_KEY = "$(USER_ID)";

	// マクロ文字のstrを値に変換し返す。
	public static final String getMacroString(String str) {
		if (str == null) {
			return null;
		}

		String result = "";
		int m = 0;

		boolean loop = true;
		while (loop) {
			int n = str.indexOf(MACRO_KEY, m);
			if (n >= 0) {
				result = result + str.substring(m, n) + MCSys.user.ID();
				m = m + n + MACRO_KEY.length();
			}
			else {
				loop = false;
			}
		}
		if (m < str.length()) {
			result = result + str.substring(m, str.length());
		}

		return result;

	}

	// 6.4.0 listの中から探し出す。
	protected SrchCndR getSrchCndR(String id, List<SrchCndR> list) {
		// 完全一致で探し出す。
		for (SrchCndR r : list) {
			String key = r.field_key();
			if (key.equals(id)) {
				return r;
			}
		}

		// 後方一致で探し出す。
		for (SrchCndR r : list) {
			String key = r.field_key();
			if (key.endsWith(id)) {
				return r;
			}
		}
		return null;
	}

	/**
	 * ラジオボタンの値を設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 設定情報
	 */
	protected void _updateRadioCnd(IfSrchCndBase panel, MCButtonGroup compo,
			SrchCndR data) {
		compo.setViewValue(data.radio());
	}

	/**
	 * GUI 部品の値を設定します。
	 *マクロ機能あり
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 設定情報
	 */
	protected void _updateTextCnd2(IfSrchCndBase panel, MCRowBeans compo, SrchCndR data) {
		if (!MCDataType.STRING.equals(compo.getDataType())) {
			return;
		}
		String str = data.text();
		// マクロ置換
		String str2 = getMacroString(str);

		compo.setViewValue(str2);
	}

	/**
	 * GUI 部品の値を設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 設定情報
	 */
	protected void _updateCheckCnd(IfSrchCndBase panel, MCRowBeans compo, SrchCndR data) {
		if (!MCDataType.BOOLEAN.equals(compo.getDataType())) {
			return;
		}
		compo.setViewValue(data.check());
	}

	/**
	 * GUI 部品の値を設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 設定情報
	 */
	protected void _updateDateCnd(IfSrchCndBase panel, MCRowBeans compo, SrchCndR data) {
		if (!MCDataType.DATE.equals(compo.getDataType())) {
			return;
		}

		// 設定する日付
		MCDate v = null;

		// 日付（今日）の場合
		if (data.today_flg()) {
			v = panel.today(MCDataType.DATE);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
		}
		// 日付（月初）の場合
		else if (data.firstday_flg()) {
			v = panel.today(MCDataType.DATE);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
			v = v.startOfMonth();
		}
		// 日付（月末）の場合
		else if (data.lastday_flg()) {
			v = panel.today(MCDataType.DATE);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
			v = v.endOfMonth();
		}
		else {
			MCTimestamp t = data.date();
			// 日付（固定値）の場合
			if (t != null) {
				v = t.toMCDate();
				if (data.month() != null) {
					v = v.addMonth(data.month());
				}
			}
			// 日付が指定されていない場合は null を設定する
		}

		if (v != null) {
			if (data.week() != null) {
				v = v.addDay(data.week().multiply(7));
				String t = data.day_of_week_type();
				if (!isNull(t)) {
					int dw = Integer.parseInt(t) - v.getDayOfWeek();
					v = v.addDay(dw);
				}
			}
			if (data.day() != null) {
				v = v.addDay(data.day());
			}
			if (data.hour() != null) {
				v = v.addHour(data.hour());
			}
			if (data.minute() != null) {
				v = v.addMinute(data.minute());
			}
		}

		v = (MCDate) adjustValueByCalenderFormat(compo, v);

		compo.setViewValue(v);
	}

	/**
	 * GUI 部品の値を設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 設定情報
	 */
	protected void _updateTimestampCnd(IfSrchCndBase panel, MCRowBeans compo,
			SrchCndR data) {
		if (!MCDataType.TIMESTAMP.equals(compo.getDataType())) {
			return;
		}

		// 設定する日付
		MCTimestamp v = null;

		// 日付（今日）の場合
		if (data.today_flg()) {
			v = panel.today(MCDataType.TIMESTAMP);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
		}
		// 日付（月初）の場合
		else if (data.firstday_flg()) {
			v = panel.today(MCDataType.TIMESTAMP);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
			v = v.startOfMonth();
		}
		// 日付（月末）の場合
		else if (data.lastday_flg()) {
			v = panel.today(MCDataType.TIMESTAMP);
			if (data.month() != null) {
				v = v.addMonth(data.month());
			}
			v = v.endOfMonth();
		}
		else {
			v = data.date();
			// 日付（固定値）の場合
			if (v != null) {
				if (data.month() != null) {
					v = v.addMonth(data.month());
				}
			}
			// 日付が指定されていない場合は null を設定する
		}

		if (v != null) {
			if (data.week() != null) {
				v = v.addDay(data.week().multiply(7));
				String t = data.day_of_week_type();
				if (!isNull(t)) {
					int dw = Integer.parseInt(t) - v.getDayOfWeek();
					v = v.addDay(dw);
				}
			}
			if (data.day() != null) {
				v = v.addDay(data.day());
			}
			if (data.hour() != null) {
				v = v.addHour(data.hour());
			}
			if (data.minute() != null) {
				v = v.addMinute(data.minute());
			}
		}

		v = (MCTimestamp) adjustValueByCalenderFormat(compo, v);

		compo.setViewValue(v);
	}

	/**
	 * GUI 部品の値を設定します。
	 *
	 * @param panel 画面
	 * @param compo GUI 部品
	 * @param data 設定情報
	 */
	protected void _updateNumberCnd(IfSrchCndBase panel, MCRowBeans compo,
			SrchCndR data) {
		if (!MCDataType.NUMBER.equals(compo.getDataType())) {
			return;
		}
		compo.setViewValue(data.num());
	}

	/**
	 * 入力値設定の対象となる枠のリストを返します。
	 *
	 * @param panel 画面
	 * @return 入力値設定対象枠のリスト
	 */
	public static List<MCPanel> getSrchPanels(IfSrchCndBase panel) {
		return _util._getSrchPanels(panel);
	}

	/**
	 * 入力値設定の対象となる枠のリストを返します。
	 *
	 * @param panel 画面
	 * @return 入力値設定対象枠のリスト
	 */
	protected List<MCPanel> _getSrchPanels(IfSrchCndBase panel) {
		if (panel == null) {
			return new ArrayList<>();
		}
		return ((MCRootPanel) panel).getSrchCndPanels();
	}

	/**
	 * 設定情報ＩＤを表すリソースキーを作成します。
	 *
	 * @param type 設定単位
	 * @param order 設定情報のインデックス値
	 * @return 設定情報ＩＤを表すリソースキー
	 */
	public static String createSettingInfoID(String type, int order) {
		return _util._createSettingInfoID(type, order);
	}

	/**
	 * 設定情報ＩＤを表すリソースキーを作成します。
	 *
	 * @param order 設定情報のインデックス値
	 * @return 設定情報ＩＤを表すリソースキー
	 */
	protected String _createSettingInfoID(String type, int order) {
		return MCPersonalizeResourceIO.createSettingInfoID(type, order);
	}

	public static Map<String, Integer> readSettingInfoNO(IfSrchCndBase panel) {
		return _util._srch_cnd_io.readSettingInfoNOMap(panel);
	}

	/**
	 * リソースに保存されている検索条件に関する情報を取得します。
	 *
	 * @param panel 画面
	 * @param type 情報を格納するコンテナ（型）
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 * @return 検索条件に関する情報
	 */
	public static List<SrchCndInfo> readResource(IfSrchCndBase panel, SrchCndR type,
			List<Object[]> list) {
		return _util._readResource(panel, type, list);
	}

	/**
	 * リソースに保存されている検索条件に関する情報を取得します。
	 *
	 * @param panel 画面
	 * @param type 情報を格納するコンテナ（型）
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 * @return 検索条件に関する情報
	 */
	protected List<SrchCndInfo> _readResource(IfSrchCndBase panel, SrchCndR type,
			List<Object[]> list) {

		List<Object[]> pnl = new ArrayList<>();
		List<Object[]> kl = new ArrayList<>();

		List<SrchCndInfo> l = new ArrayList<>();

		l.addAll(_srch_cnd_io.readResource(MCResourceLayerType.USER, panel, type, list,
				pnl, kl));
		l.addAll(_srch_cnd_io.readResource(MCResourceLayerType.EXT, panel, type, list,
				pnl, kl));
		l.addAll(_srch_cnd_io.readResource(MCResourceLayerType.SYS, panel, type, list,
				pnl, kl));
		l.addAll(_srch_cnd_io.readResource(MCResourceLayerType.BARCODE, panel, type, list,
				pnl, kl));

		return l;
	}

	/**
	 * リソースに保存されている入力値設定ＩＤを取得します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @return 入力値設定ＩＤ
	 */
	protected List<SrchCndInfo> _readResource(String module_id, String screen_id) {
		List<SrchCndInfo> l = new ArrayList<>();

		l.addAll(_srch_cnd_io.readResource(MCResourceLayerType.USER, module_id,
				screen_id));
		l.addAll(
				_srch_cnd_io.readResource(MCResourceLayerType.EXT, module_id, screen_id));
		l.addAll(
				_srch_cnd_io.readResource(MCResourceLayerType.SYS, module_id, screen_id));
		l.addAll(_srch_cnd_io.readResource(MCResourceLayerType.BARCODE, module_id,
				screen_id));

		return l;
	}

	/**
	 * 枠のラベル名を返します。
	 *
	 * @param compo GUI 部品
	 * @param list リスト（第一要素：GUI 部品、第二要素：MCRootPanel、または MCPanel、第三要素：枠名、または null）
	 * @return 枠のラベル名、または null
	 */
	protected String _getPanelLabelName(MCRowBeans compo, List<Object[]> list) {
		if (compo instanceof MCButtonGroup) {
			MCRadioButton o = ((MCButtonGroup) compo).getSelectedButton();
			if (o != null) {
				for (Object[] a : list) {
					if (o.equals(a[0])) {
						return (String) a[2];
					}
				}
			}
		}
		else {
			for (Object[] a : list) {
				if (compo.equals(a[0])) {
					return (String) a[2];
				}
			}
		}
		return null;
	}

	/**
	 * リソースに保存されている検索条件に関する情報をリストにして返します。
	 *
	 * @param panel 画面
	 * @return 検索条件に関する情報のリスト
	 */
	public static List<SrchCndInfo> getSrchCndInfoList(IfSrchCndBase panel) {
		return _util._getSrchCndInfoList(panel);
	}

	/**
	 * リソースに保存されている検索条件に関する情報をリストにして返します。
	 *
	 * @param panel 画面
	 * @return 検索条件に関する情報のリスト
	 */
	protected List<SrchCndInfo> _getSrchCndInfoList(IfSrchCndBase panel) {
		List<Object[]> ol = getSrchCndBeans(panel, true);
		return _readResource(panel, SrchCndR.create(), ol);
	}

	/**
	 * リソースに保存されている入力値設定ＩＤをリストにして返します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @return 入力値設定ＩＤのリスト
	 */
	public static List<SrchCndInfo> getSrchCndIDList(String module_id, String screen_id) {
		return _util._getSrchCndIDList(module_id, screen_id);
	}

	/**
	 * リソースに保存されている入力値設定ＩＤをリストにして返します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @return 入力値設定ＩＤのリスト
	 */
	protected List<SrchCndInfo> _getSrchCndIDList(String module_id, String screen_id) {
		return _readResource(module_id, screen_id);
	}

	/**
	 * 入力値設定情報名を返します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @param id 入力値設定ＩＤ
	 * @return 入力値設定情報名
	 */
	public static String getSettingInfoName(String module_id, String screen_id,
			String id) {
		return _util._getSettingInfoName(module_id, screen_id, id);
	}

	/**
	 * 入力値設定情報名を返します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @param id 入力値設定ＩＤ
	 * @return 入力値設定情報名
	 */
	protected String _getSettingInfoName(String module_id, String screen_id, String id) {
		SrchCndInfo info = _srch_cnd_io.readInfo(module_id, screen_id, id);
		return info != null ? info.getSettingInfoName() : null;
	}

	/**
	 * 設定単位付入力値設定情報名を返します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @param id 入力値設定ＩＤ
	 * @return 入力値設定情報名
	 */
	public static String getSettingInfoUnitName(String module_id, String screen_id,
			String id) {
		return _util._getSettingInfoUnitName(module_id, screen_id, id);
	}

	/**
	 * 設定単位付入力値設定情報名を返します。
	 *
	 * @param module_id モジュールＩＤ
	 * @param screen_id 画面ＩＤ
	 * @param id 入力値設定ＩＤ
	 * @return 入力値設定情報名
	 */
	protected String _getSettingInfoUnitName(String module_id, String screen_id,
			String id) {

		// 7013-1956(【メニューブックマーク】パーソナライズグループや入力値の名称がIDになる)
		// 画面リソースが読まれていない場合は読み込む。
		String key = MCConst.createKey(module_id, screen_id);
		if (!getResource().containsKey(key)) {
			MCConst.loadPgmResource(key);
		}
		// 7013-1956 ここまで

		SrchCndInfo info = _srch_cnd_io.readInfo(module_id, screen_id, id);

		return info != null ? info.getSettingInfoUnitName() : null;
	}

	public static SrchCndInfo getInitSrchCndInfo(List<SrchCndInfo> list) {
		return _util._getInitSrchCndInfo(list);
	}

	protected SrchCndInfo _getInitSrchCndInfo(List<SrchCndInfo> list) {
		if (list == null) {
			return null;
		}

		SrchCndInfo e = null;
		SrchCndInfo s = null;
		for (SrchCndInfo i : list) {
			if (i.getInitFlg()) {
				MCResourceLayerType y = toResourceLayerType(i.getSettingUnitType());
				switch (y) {
					case USER:
						return i;
					case EXT:
						e = i;
						break;
					case SYS:
						s = i;
						break;
					case BARCODE:
						break;
					default:
						break;
				}
			}
		}
		return e != null ? e : s;
	}

	public static SrchCndInfo getInfo(String type, String id, List<SrchCndInfo> list) {
		return _util._getInfo(type, id, list);
	}

	protected SrchCndInfo _getInfo(String type, String id, List<SrchCndInfo> list) {
		if (list == null) {
			return null;
		}

		for (SrchCndInfo i : list) {
			if (type.equals(i.getSettingUnitType()) && id.equals(i.getSettingInfoID())) {
				return i;
			}
		}
		return null;
	}

	protected String _createGUIKey(String name, MCRowBeans compo) {
		return _srch_cnd_io.createGUIKey(name, compo);
	}

	/**
	 * GUI部品とリソースキーの配列をリストにして返します。
	 *
	 * @param list リスト（第一要素：枠名（String）、第二要素：GUI 部品（MCRowBeans））
	 * @return リスト（第一要素：GUI部品（MCRowBeans）、第二要素：リソースキー（String））
	 */
	public static List<Object[]> createGUIKeyList(List<Object[]> list) {
		List<Object[]> tl = new ArrayList<>();
		for (Object[] oa : list) {
			MCRowBeans c = (MCRowBeans) oa[1];
			String s = _util._createGUIKey((String) oa[0], c);
			tl.add(new Object[] {
					c, s
			});
		}

		List<Object[]> l = new ArrayList<>();
		for (Object[] ta : tl) {
			boolean c = false;

			String v = (String) ta[1];
			for (Object[] a : l) {
				if (MCStringUtil.eq(v, (String) a[1])) {
					c = true;
					break;
				}
			}

			if (!c) {
				l.add(ta);
			}
			else {
				while (true) {
					v = v + "_";
					boolean c2 = false;
					for (Object[] a : l) {
						if (MCStringUtil.eq(v, (String) a[1])) {
							c2 = true;
							break;
						}
					}
					if (!c2) {
						l.add(new Object[] {
								ta[0], v
						});
						break;
					}
				}
			}
		}

		return l;
	}

	/**
	 * 指定された値を日付項目の書式に合わせて調整した値を返します。
	 *
	 * @param compo 日付項目
	 * @param value 値
	 * @return 調整した値
	 */
	public static final MCCalendarDate adjustValueByCalenderFormat(MCRowBeans compo,
			MCCalendarDate<?> value) {
		if (value == null) {
			return value;
		}
		if (compo == null) {
			return value;
		}
		
		MCCalendarFormat f = null;
		if (compo instanceof MCCalendarField) {
			f = ((MCCalendarField) compo).getCalendarFormat();
		}
		else if (compo instanceof MCCalendarComboBox) {
			f = ((MCCalendarComboBox) compo).getCalendarFormat();
		}

		if (f == null) {
			return value;
		}

		try {
			MCDateFieldType y = getDateFieldType(f.getInputPattern());
			return y != null ? value.trunc(y) : value;
		}
		catch (MCException e) {
			return null;
		}
	}

	private static final MCDateFieldType getDateFieldType(String pattern) {
		if (isNull(pattern)) {
			return null;
		}

		boolean[] a = new boolean[7];
		for (char c : pattern.toCharArray()) {
			if ('y' == c) {
				a[0] = true;
			}
			else if ('M' == c) {
				a[1] = true;
			}
			else if ('d' == c) {
				a[2] = true;
			}
			else if ('H' == c || 'h' == c) {
				a[3] = true;
			}
			else if ('m' == c) {
				a[4] = true;
			}
			else if ('s' == c) {
				a[5] = true;
			}
			else if ('S' == c) {
				a[6] = true;
			}
		}

		if (a[6]) {
			return null;
		}
		else if (a[5]) {
			return MCDateFieldType.SECOND;
		}
		else if (a[4]) {
			return MCDateFieldType.MINUTE;
		}
		else if (a[3]) {
			return MCDateFieldType.HOUR;
		}
		else if (a[2]) {
			return MCDateFieldType.DAY;
		}
		else if (a[1]) {
			return MCDateFieldType.MONTH;
		}
		else if (a[0]) {
			return MCDateFieldType.YEAR;
		}
		return null;
	}

	/**
	 * GUI部品のメッセージ用名称を返します。
	 *
	 * メッセージ用名称が設定されていない場合は、ラベル名を返します。
	 * ラベル名も設定されていない場合は、名前を返します。
	 *
	 * @param compo GUI部品
	 * @return メッセージ用名称
	 */
	public static String getMessageName(MCRowBeans compo) {
		// XUP_SrchCndIOのメソッドを使うのでgetSrchCndIOの引数は問わない
		return _util._getMessageName(compo);
	}

	/**
	 * 名称を返します。<p>
	 * 名称を取得できなかった場合は null を返します。
	 *
	 * @param compo GUI 部品
	 * @return 名称、または null
	 */
	protected String _getMessageName(MCRowBeans compo) {
		if (compo instanceof MCButtonGroup) {
			StringBuilder sb = new StringBuilder();
			String d = getResource().getString(
					MCConst.createKey(getModuleID(), getScreenID(), BTN_GRP_NM_DLM));

			for (MCRadioButton c : ((MCButtonGroup) compo).getRadioButtons()) {
				if (!_isModeInvisible(c)) {
					if (sb.length() != 0) {
						sb.append(d);
					}
					sb.append(getRadioButtonName(c));
				}
			}
			return sb.toString();
		}
		return compo.getMessageByLocale();
	}

	/**
	 * ラジオボタン名を返します。
	 *
	 * @param compo ラジオボタン
	 * @return ラジオボタン名
	 */
	protected String getRadioButtonName(MCRadioButton compo) {
		String n = compo.getLabelByLocale();
		if (!isNull(n)) {
			return n;
		}
		n = compo.getMessageByLocale();
		if (!isNull(n)) {
			return n;
		}
		return null;
	}

	public static boolean isSearchedProgram(String type, String pgmid) {
		return _util._isSearchedProgram(type, pgmid);
	}

	protected boolean _isSearchedProgram(String type, String pgmid) {
		return MCConst.app.isSearchedProgram(toResourceLayerType(type), pgmid);
	}

	/**
	 * 新仕様のリソースの読込、保存をするためのクラスです。
	 */
	protected final XUP_SrchCndIO _srch_cnd_io = new XUP_SrchCndIO();

	/**
	 * 入力値設定に関するパーソナライズ情報について、リソースとのI/Oを行います。
	 */
	public class XUP_SrchCndIO {

		/**
		 * 画面の入力値設定であることを表すリソースキーを作成します。
		 *
		 * @param panel 画面
		 * @return リソースキー
		 */
		protected String createSrchCndKey(IfSrchCndBase panel, MCResourceLayerType type) {
			return createSrchCndKey(panel.getModuleID(), panel.getScreenID(), type);
		}

		/**
		 * 画面の入力値設定であることを表すリソースキーを作成します。
		 *
		 * @param module_id モジュールＩＤ
		 * @param screen_id 画面ＩＤ
		 * @return リソースキー
		 */
		protected String createSrchCndKey(String module_id, String screen_id,
				MCResourceLayerType type) {
			if (MCResourceLayerType.BARCODE == type) {
				return MCConst.createKey(MCGroupResource.SCREEN_RESOURCE_KEY_PREFIX,
						module_id, screen_id, MCGroupResource.BARCODE_RESOURCE_KEY,
						P_SRCH_CND_KEY);
			}
			else {
				return MCConst.createKey(MCGroupResource.SCREEN_RESOURCE_KEY_PREFIX,
						module_id, screen_id, P_SRCH_CND_KEY);
			}
		}

		/**
		 * GUI 部品を一意に特定するためのリソースキーを作成します。
		 *
		 * @param name 枠名
		 * @param compo GUI 部品
		 * @return GUI 部品を一意に特定するためのリソースキー
		 */
		protected String createGUIKey(String name, MCRowBeans compo) {
			if (compo == null) {
				return null;
			}

			List<String> l = new ArrayList<>();

			l.add(name);

			MCRootPanel p = compo.getRootPanel();
			if (p.isPartsPanel()) {
				MCRootPanel[] a = MCBeansUtil.getRootPanelLayer(p);
				MCCollectionUtil.reverse(a);
				for (MCRootPanel o : a) {
					if (o == p) {
						continue;
					}
					String s = p.getName();
					s = s != null ? s.replace('.', '_') : "null";
					l.add(s);
				}
			}

			l.add(compo.getName());

			return MCConst.createKey(l.toArray(new String[l.size()]));
		}

		protected List<SrchCndInfo> readResource(MCResourceLayerType type,
				IfSrchCndBase panel, SrchCndR data, List<Object[]> list,
				List<Object[]> pnl, List<Object[]> kl) {
			String pk = createSrchCndKey(panel, type);

			List<String> idl = readID(type, pk);

			List<SrchCndInfo> l = new ArrayList<>();

			if (idl.isEmpty()) {
				return l;
			}

			if (kl.isEmpty()) {
				kl.addAll(createGUIKeyList(list));
			}
			if (pnl.isEmpty()) {
				List<MCBeans> a = new ArrayList<>();
				for (Object[] k : kl) {
					MCRowBeans o = (MCRowBeans) k[0];
					if (o instanceof MCButtonGroup) {
						a.addAll(Arrays.asList(((MCButtonGroup) o).getRadioButtons()));
					}
					else {
						a.add(o);
					}
				}
				pnl.addAll(MCBeansUtil.getPanelNameList(a.toArray(new MCBeans[0])));
			}

			String iv = getResource().getString(type, MCConst.createKey(pk, "init"));

			for (String id : idl) {
				String[] va = readInfo(type, pk, id);
				if (va == null) {
					continue;
				}
				SrchCndInfo f = new SrchCndInfo();
				f.setSettingUnitType(type.name());
				f.setSettingInfoID(id);
				f.setSettingInfoName(va[0]);
				f.setRemark(va[1]);
				f.setInitFlg(id.equals(iv));

				String k = MCConst.createKey(pk, id);
				List<SrchCndR> cl = new ArrayList<>();

				for (Object[] oa : list) {
					MCRowBeans o = (MCRowBeans) oa[1];
					SrchCndR c = data.clone();

					String fk = null;
					for (Object[] ka : kl) {
						if (o.equals(ka[0])) {
							fk = (String) ka[1];
							break;
						}
					}

					_srch_cnd_io.readResource(type, k, panel, (String) oa[0],
							_getPanelLabelName(o, pnl), o, fk, c);
					cl.add(c);
				}
				f.setSrchCndList(cl);

				f.setInitSrchFlg(_srch_cnd_io.getSrchFlg(type, k));
				f.setClearFlg(_srch_cnd_io.getClearFlg(type, k));

				l.add(f);
			}

			return l;
		}

		/**
		 * リソースから設定情報ＩＤのリストを取得します。
		 *
		 * @param type レイヤー
		 * @param key 設定情報のキー
		 * @return 設定情報ＩＤのリスト
		 */
		protected List<String> readID(MCResourceLayerType type, String key) {
			List<String> idl = new ArrayList<>();
			for (String p : getResource().findPattern(type, key + ".*")) {
				String id = p.substring(key.length() + 1);
				int v1 = MCPersonalizeResourceIO.getSettingInfoNO(type, id);
				if (v1 != -1) {
					int i = 0;
					for (; i < idl.size(); i++) {
						int v2 = MCPersonalizeResourceIO.getSettingInfoNO(type,
								idl.get(i));
						if (v2 > v1) {
							break;
						}
					}
					idl.add(i, id);
				}
			}
			return idl;
		}

		/**
		 * 設定情報名と備考の配列を取得します。
		 * <p>
		 * 以下の場合はnullを返します。
		 * <li>設定情報名のキーが見つからない場合</li>
		 * <li>設定情報名と備考のが不正な場合</li>
		 *
		 * @param type レイヤー
		 * @param key 設定情報のキー
		 * @param id 設定情報ＩＤ
		 * @return 設定情報名と備考の配列
		 */
		protected String[] readInfo(MCResourceLayerType type, String key, String id) {
			String k = MCConst.createKey(key, id, INFO_PREFIX);
			if (!getResource().containsKey(type, k)) {
				return null;
			}
			String[] va = getResource().getStringArray(type, k);
			if (va == null || va.length != 2) {
				return null;
			}
			return va;
		}

		/**
		 * リソースに保存されている入力値設定ＩＤを取得します。
		 *
		 * @param type レイヤー
		 * @param module_id モジュールＩＤ
		 * @param screen_id 画面ＩＤ
		 * @return 入力値設定ＩＤのリスト
		 */
		protected List<SrchCndInfo> readResource(MCResourceLayerType type,
				String module_id, String screen_id) {
			List<SrchCndInfo> l = new ArrayList<>();

			String pk = createSrchCndKey(module_id, screen_id, type);
			List<String> idl = readID(type, pk);

			String ik = MCConst.createKey(pk, "init");
			String iv = getResource().getString(type, ik);

			for (String id : idl) {
				String[] va = readInfo(type, pk, id);
				if (va == null) {
					continue;
				}
				SrchCndInfo f = new SrchCndInfo();
				f.setSettingUnitType(type.name());
				f.setSettingInfoID(id);
				f.setSettingInfoName(va[0]);
				f.setRemark(va[1]);
				f.setInitFlg(id.equals(iv));

				String k = MCConst.createKey(pk, id);
				f.setInitSrchFlg(_srch_cnd_io.getSrchFlg(type, k));
				f.setClearFlg(_srch_cnd_io.getClearFlg(type, k));

				l.add(f);
			}

			return l;
		}

		/**
		 * リソースに保存されている入力値設定情報を取得します。
		 *
		 * @param module_id モジュールＩＤ
		 * @param screen_id 画面ＩＤ
		 * @param id 入力値設定ＩＤ
		 * @return 入力値設定情報
		 */
		protected SrchCndInfo readInfo(String module_id, String screen_id, String id) {

			for (MCResourceLayerType type : MCResourceLayerType.values()) {
				String pk = createSrchCndKey(module_id, screen_id, type);
				String ik = MCConst.createKey(pk, "init");

				String[] va = readInfo(type, pk, id);
				if (va == null) {
					continue;
				}
				String iv = getResource().getString(type, ik);
				SrchCndInfo f = new SrchCndInfo();
				f.setSettingUnitType(type.name());
				f.setSettingInfoID(id);
				f.setSettingInfoName(va[0]);
				f.setRemark(va[1]);
				f.setInitFlg(id.equals(iv));

				String k = MCConst.createKey(pk, id);
				f.setInitSrchFlg(_srch_cnd_io.getSrchFlg(type, k));
				f.setClearFlg(_srch_cnd_io.getClearFlg(type, k));
				return f;
			}
			return null;
		}

		/**
		 * 保存されている設定情報をコンテナに格納します。
		 *
		 * @param prefix リソースキーの接頭語
		 * @param panel 画面
		 * @param name 枠名
		 * @param label 枠のラベル名
		 * @param compo GUI 部品
		 * @param field_key GUI 部品のリソースキー
		 * @param data 設定情報を格納するコンテナ
		 */
		protected void readResource(MCResourceLayerType type, String prefix,
				IfSrchCndBase panel, String name, String label, MCRowBeans compo,
				String field_key, SrchCndR data) {
			if (prefix == null || compo == null || data == null) {
				return;
			}

			MCDataType y = compo.getDataType();
			if (y == null) {
				return;
			}

			data.field_key(field_key);
			data.panel_name(label);
			data.name(_getMessageName(compo));

			String k = MCConst.createKey(prefix, data.field_key());
			if (!getResource().containsKey(type, k)) {
				return;
			}

			String[] va = getResource().getStringArray(type, k);

			data.set_flg(Boolean.valueOf(va[0]));
			data.focus_flg(Boolean.valueOf(va[1]));
			data.required_flg(Boolean.valueOf(va[2]));

			if (MCDataType.STRING.equals(y)) {
				if (compo instanceof MCButtonGroup) {
					String v = isNull(va[5]) ? null : va[5];
					for (MCRadioButton o : ((MCButtonGroup) compo).getRadioButtons()) {
						if (isSame(v, o.getActionCommand())) {
							data.radio(v);
							data.radio_nm(getRadioButtonName(o));
							break;
						}
					}
				}
				else {
					data.text(isNull(va[3]) ? null : va[3]);
				}
			}
			else if (MCDataType.BOOLEAN.equals(y)) {
				data.check(Boolean.valueOf(va[4]));
			}
			else if (MCDataType.DATE.equals(y) || MCDataType.TIMESTAMP.equals(y)) {
				if (!(compo instanceof MCCalendarDocumentBeans<?>)) {
					return;
				}

				MCCalendarDocumentBeans<?> c = (MCCalendarDocumentBeans<?>) compo;

				data.today_flg(Boolean.valueOf(va[6]));
				data.firstday_flg(Boolean.valueOf(va[7]));
				data.lastday_flg(Boolean.valueOf(va[8]));

				if (MCDataType.DATE.equals(y)) {
					MCDate v = null;
					try {
						v = MCDate.valueOf(va[9], MCDate.TO_STRING_FORMAT);
					}
					catch (Exception e) {
						try {
							MCDateFormat f = (MCDateFormat) c.getCalendarFormat();
							v = f.doInputParse(va[9]);
						}
						catch (Exception ex) {
							v = null;
						}
					}
					if (v != null) {
						data.date(v.toMCTimestamp());
					}
					else {
						data.date(null);
					}
				}
				else {
					MCTimestamp v = null;
					try {
						v = MCTimestamp.valueOf(va[9], MCTimestamp.TO_STRING_FORMAT);
					}
					catch (Exception e) {
						try {
							MCTimestampFormat f = (MCTimestampFormat) c
									.getCalendarFormat();
							v = f.doInputParse(va[9]);
						}
						catch (Exception ex) {
							v = null;
						}
					}
					data.date(v);
				}

				data.month(isNull(va[10]) ? null : MCNumber.valueOf(va[10]));
				data.week(isNull(va[11]) ? null : MCNumber.valueOf(va[11]));
				data.day_of_week_type(isNull(va[12]) ? null : va[12]);
				data.day(isNull(va[13]) ? null : MCNumber.valueOf(va[13]));
				data.hour(isNull(va[14]) ? null : MCNumber.valueOf(va[14]));
				data.minute(isNull(va[15]) ? null : MCNumber.valueOf(va[15]));

			}
			else if (MCDataType.NUMBER.equals(y)) {
				data.num(isNull(va[16]) ? null : MCNumber.valueOf(va[16]));
			}
		}

		/**
		 * 初期検索ＦＬＧを返します。
		 *
		 * @param prefix リソースキーの接頭語
		 * @return 初期検索ＦＬＧ
		 */
		protected boolean getSrchFlg(MCResourceLayerType type, String prefix) {
			if (isNull(prefix)) {
				return false;
			}

			String k = MCConst.createKey(prefix, SRCH_FLG_KEY);
			if (getResource().containsKey(type, k)) {
				String v = getResource().getString(type, k);
				return isNull(v) ? false : Boolean.valueOf(v);
			}

			return false;
		}

		/**
		 * 画面クリア時設定可否ＦＬＧを返します。
		 *
		 * @param prefix リソースキーの接頭語
		 * @return 画面クリア時設定可否ＦＬＧ
		 */
		protected boolean getClearFlg(MCResourceLayerType type, String prefix) {
			if (isNull(prefix)) {
				return false;
			}

			String k = MCConst.createKey(prefix, CLEAR_FLG_KEY);
			if (getResource().containsKey(type, k)) {
				String v = getResource().getString(type, k);
				return isNull(v) ? false : Boolean.valueOf(v);
			}

			return false;
		}

		protected Map<String, Integer> readSettingInfoNOMap(IfSrchCndBase panel) {
			Map<String, Integer> m = new HashMap<>();
			if (panel == null) {
				return m;
			}

			MCResourceLayerType[] ya = new MCResourceLayerType[] {
					MCResourceLayerType.USER, MCResourceLayerType.EXT,
					MCResourceLayerType.SYS, MCResourceLayerType.BARCODE
			};
			for (MCResourceLayerType y : ya) {
				String k = MCConst.createKey(createSrchCndKey(panel, y),
						"setting_info_no");
				if (getResource().containsKey(y, k)) {
					m.put(y.name(), Integer.valueOf(getResource().getString(y, k)));
				}
			}
			return m;
		}

		protected void writeResource(IfSrchCndBase panel, Map<String, Integer> map,
				List<SrchCndInfo> info, List<Object[]> list) {
			writeResourceImpl(panel, map, info, list, true);
		}

		protected void writeResourceNoSave(IfSrchCndBase panel, Map<String, Integer> map,
				List<SrchCndInfo> info, List<Object[]> list) {

			writeResourceImpl(panel, map, info, list, false);
		}

		protected void writeResourceImpl(IfSrchCndBase panel, Map<String, Integer> map,
				List<SrchCndInfo> info, List<Object[]> list, boolean doSave) {

			if (panel == null) {
				return;
			}

			boolean save = false;

			MCResourceLayerType iy = null;
			String is = null;

			if (info != null && list != null) {
				for (SrchCndInfo f : info) {
					MCResourceLayerType ly = toResourceLayerType(f.getSettingUnitType());

					String pfx = createSrchCndKey(panel, ly);

					List<SrchCndR> cl = f.getSrchCndList();
					// データの数と画面部品の数が一致しない場合に対応
					if (cl == null /* || cl.size() != list.size() */) {
						continue;
					}

					String pk = MCConst.createKey(pfx, f.getSettingInfoID());

					// 設定情報名、備考
					String[] va = new String[] {
							f.getSettingInfoName(), f.getRemark()
					};
					getResource().setStringArray(ly, MCConst.createKey(pk, INFO_PREFIX),
							va);

					List<Object[]> kl = createGUIKeyList(list);

					for (int j = 0; j < cl.size(); j++) {
						SrchCndR s = cl.get(j);

						if (!s.set_flg()) {
							continue;
						}

						// 簡易バグ票No.54の対応（ここから）
						// キーが一致する項目を探す
						Object[] a = getBeans(s.field_key(), kl);
//						Object[] a = getObject(s.field_key(), list);
						// 簡易バグ票No.54の対応（ここまで）
						if (a == null) {
							continue;
						}

//						Object[] a = list.get(j);
						MCRowBeans c = (MCRowBeans) a[1];
						MCDataType y = c.getDataType();

						String gk = null;
						for (Object[] ka : kl) {
							if (c.equals(ka[0])) {
								gk = (String) ka[1];
							}
						}
						if (gk == null) {
							gk = createGUIKey((String) a[0], c);
						}

						String k = MCConst.createKey(pk, gk);

						// 設定フラグ、初期フォーカスフラグ、必須フラグ
						// テキスト、チェック、ラジオ、
						// 日付（今日）フラグ、日付（月初）フラグ、日付（月末）フラグ、日付
						// 差分（月）、差分（週）、曜日、差分（日）、差分（時）、差分（分）
						// 数値
						va = new String[17];
						va[0] = String.valueOf(s.set_flg());
						va[1] = String.valueOf(s.focus_flg());
						va[2] = String.valueOf(s.required_flg());

						if (MCDataType.STRING.equals(y)) {
							if (c instanceof MCButtonGroup) {
								va[5] = s.radio();
							}
							else {
								va[3] = s.text();
							}
						}
						else if (MCDataType.BOOLEAN.equals(y)) {
							va[4] = String.valueOf(s.check());
						}
						else if (MCDataType.DATE.equals(y)
								|| MCDataType.TIMESTAMP.equals(y)) {
							if (!(c instanceof MCCalendarDocumentBeans<?>)) {
								continue;
							}

							va[6] = String.valueOf(s.today_flg());
							va[7] = String.valueOf(s.firstday_flg());
							va[8] = String.valueOf(s.lastday_flg());

							if (MCDataType.DATE.equals(y)) {
								va[9] = !isNull(s.date())
										? MCDate.valueOf(s.date()).toString() : null;
							}
							else {
								va[9] = !isNull(s.date()) ? s.date().toString() : null;
							}

							va[10] = s.month() != null ? String.valueOf(s.month()) : null;
							va[11] = s.week() != null ? String.valueOf(s.week()) : null;
							va[12] = s.day_of_week_type();
							va[13] = s.day() != null ? String.valueOf(s.day()) : null;
							va[14] = s.hour() != null ? String.valueOf(s.hour()) : null;
							va[15] = s.minute() != null ? String.valueOf(s.minute())
									: null;
						}
						else if (MCDataType.NUMBER.equals(y)) {
							va[16] = s.num() != null ? String.valueOf(s.num()) : null;
						}
						else if (MCDataType.BINARY.equals(y)) {

						}
						else {
							continue;
						}

						getResource().setStringArray(ly, k, va);
					}

					writeSrchFlgResource(ly, panel, pk, f.getInitSrchFlg());
					writeClearFlgResource(ly, panel, pk, f.getClearFlg());

					if (f.getInitFlg()) {
						iy = ly;
						is = f.getSettingInfoID();
					}

					save = true;
				}
			}

			if (is != null) {
				String pfx = createSrchCndKey(panel, iy);
				String k = MCConst.createKey(pfx, "init");
				getResource().setString(iy, k, is);
				save = true;
			}

			if (map != null) {
				for (Map.Entry<String, Integer> e : map.entrySet()) {
					MCResourceLayerType ly = toResourceLayerType(e.getKey());
					String pfx = createSrchCndKey(panel, ly);
					String k = MCConst.createKey(pfx, "setting_info_no");
					getResource().setString(ly, k, e.getValue().toString());
				}
				save = true;
			}

			if (save && doSave) {
				MCPersonalizeResourceIO.saveResource();
			}
		}

		// 6.4.0
		// idからObje[]を探し出す。
		protected Object[] getObject(String id, List<Object[]> list) {
			// 完全一致で探し出す。
			for (Object[] r : list) {
				MCRowBeans c = (MCRowBeans) r[1];
				String id2 = "";
				if (c instanceof MCButtonGroup) {
					MCButtonGroup bg = (MCButtonGroup) c;
					id2 = bg.getName();
				}
				else {
					id2 = ((Component) c).getParent().getName() + "." + c.getName();
				}
				if (id.equals(id2)) {
					return r;
				}
			}

			// 後方一致で探し出す。
			for (Object[] r : list) {
				MCRowBeans c = (MCRowBeans) r[1];
				String id2 = "";
				if (c instanceof MCButtonGroup) {
					MCButtonGroup bg = (MCButtonGroup) c;
					id2 = bg.getName();
				}
				else {
					id2 = ((Component) c).getParent().getName() + "." + c.getName();
				}
				if (id.endsWith(id2)) {
					return r;
				}
			}
			return null;
		}

		/**
		 * キーが一致する要素を返します。
		 *
		 * @param id キー
		 * @param list 第一要素：MCRowBeans, 第二要素：キー
		 * @return キーが一致する要素。第一要素：キー, 第二要素：MCRowBeans
		 */
		protected Object[] getBeans(String id, List<Object[]> list) {
			for (Object[] a : list) {
				if (id.equals(a[1])) {
					return new Object[] {
							a[1], a[0]
					};
				}
			}
			return null;
		}

		/**
		 * 初期検索ＦＬＧを設定します。
		 *
		 * @param panel 画面
		 * @param prefix リソースキーの接頭語
		 * @param flg 初期検索ＦＬＧ
		 */
		protected void writeSrchFlgResource(MCResourceLayerType type, IfSrchCndBase panel,
				String prefix, boolean flg) {
			String k = MCConst.createKey(prefix, SRCH_FLG_KEY);
			getResource().setString(type, k, String.valueOf(flg));
		}

		/**
		 * 画面クリア時設定可否ＦＬＧを設定します。
		 *
		 * @param panel 画面
		 * @param prefix リソースキーの接頭語
		 * @param flg 画面クリア時設定可否ＦＬＧ
		 */
		protected void writeClearFlgResource(MCResourceLayerType type,
				IfSrchCndBase panel, String prefix, boolean flg) {
			String k = MCConst.createKey(prefix, CLEAR_FLG_KEY);
			getResource().setString(type, k, String.valueOf(flg));
		}

	}

}