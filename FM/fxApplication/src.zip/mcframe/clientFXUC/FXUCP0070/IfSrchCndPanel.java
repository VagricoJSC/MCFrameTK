package mcframe.clientFXUC.FXUCP0070;

import mcframe.commonCore.annotation.EI;

/**
 * 入力値設定画面に実装するインタフェースです。
 */
@EI
public interface IfSrchCndPanel extends IfSrchCndPanel_FW {

}