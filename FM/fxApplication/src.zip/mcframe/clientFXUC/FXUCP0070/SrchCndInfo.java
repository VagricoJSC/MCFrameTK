package mcframe.clientFXUC.FXUCP0070;

public class SrchCndInfo extends SrchCndInfo_FW {
	
	/**
	 * コンストラクタです。
	 */
	public SrchCndInfo() {}
	
}