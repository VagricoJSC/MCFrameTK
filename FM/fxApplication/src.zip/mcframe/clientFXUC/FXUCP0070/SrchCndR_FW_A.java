package mcframe.clientFXUC.FXUCP0070;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"SrchCnd"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class SrchCndR_FW_A extends MCConstRow {

	public static final String $set_flg = "set_flg";
	public static final String $panel_name = "panel_name";
	public static final String $name = "name";
	public static final String $focus_flg = "focus_flg";
	public static final String $required_flg = "required_flg";
	public static final String $text = "text";
	public static final String $check = "check";
	public static final String $radio = "radio";
	public static final String $radio_nm = "radio_nm";
	public static final String $today_flg = "today_flg";
	public static final String $firstday_flg = "firstday_flg";
	public static final String $lastday_flg = "lastday_flg";
	public static final String $date = "date";
	public static final String $week = "week";
	public static final String $day_of_week_type = "day_of_week_type";
	public static final String $day_of_week_type_nm = "day_of_week_type_nm";
	public static final String $month = "month";
	public static final String $day = "day";
	public static final String $hour = "hour";
	public static final String $minute = "minute";
	public static final String $num = "num";
	public static final String $field_key = "field_key";


	public static final MCMeta set_flg_META = createBooleanMeta($set_flg);
	public static final MCMeta panel_name_META = createStringMeta($panel_name);
	public static final MCMeta name_META = createStringMeta($name);
	public static final MCMeta focus_flg_META = createBooleanMeta($focus_flg);
	public static final MCMeta required_flg_META = createBooleanMeta($required_flg);
	public static final MCMeta text_META = createStringMeta($text, 900);
	public static final MCMeta check_META = createBooleanMeta($check);
	public static final MCMeta radio_META = createStringMeta($radio);
	public static final MCMeta radio_nm_META = createStringMeta($radio_nm);
	public static final MCMeta today_flg_META = createBooleanMeta($today_flg);
	public static final MCMeta firstday_flg_META = createBooleanMeta($firstday_flg);
	public static final MCMeta lastday_flg_META = createBooleanMeta($lastday_flg);
	public static final MCMeta date_META = createTimestampMeta($date);
	public static final MCMeta week_META = createNumberMeta($week, 2, 0, true);
	public static final MCMeta day_of_week_type_META = createStringMeta($day_of_week_type, 1);
	public static final MCMeta day_of_week_type_nm_META = createStringMeta($day_of_week_type_nm);
	public static final MCMeta month_META = createNumberMeta($month, 2, 0, true);
	public static final MCMeta day_META = createNumberMeta($day, 2, 0, true);
	public static final MCMeta hour_META = createNumberMeta($hour, 2, 0, true);
	public static final MCMeta minute_META = createNumberMeta($minute, 2, 0, true);
	public static final MCMeta num_META = createNumberMeta($num);
	public static final MCMeta field_key_META = createStringMeta($field_key);

	protected static final ConstMetaList<SrchCndR> constMetas = new ConstMetaList<SrchCndR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			set_flg_META,
			panel_name_META,
			name_META,
			focus_flg_META,
			required_flg_META,
			text_META,
			check_META,
			radio_META,
			radio_nm_META,
			today_flg_META,
			firstday_flg_META,
			lastday_flg_META,
			date_META,
			week_META,
			day_of_week_type_META,
			day_of_week_type_nm_META,
			month_META,
			day_META,
			hour_META,
			minute_META,
			num_META,
			field_key_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected SrchCndR_FW_A(ConstMetaList<? extends SrchCndR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SrchCndR clone() {
		return (SrchCndR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SrchCndR createInstance() {
		return (SrchCndR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SrchCndR getValues(String... names) {
		return (SrchCndR) super.getValues(names);
	}



	public boolean set_flg() {
		return getConstBoolean(offset + 0, $set_flg);
	}

	public void set_flg(boolean value) {
		setConstBoolean(offset + 0, $set_flg, value);
	}


	public String panel_name() {
		return getConstString(offset + 1, $panel_name);
	}

	public void panel_name(String value) {
		setConstString(offset + 1, $panel_name, value);
	}


	public String name() {
		return getConstString(offset + 2, $name);
	}

	public void name(String value) {
		setConstString(offset + 2, $name, value);
	}


	public boolean focus_flg() {
		return getConstBoolean(offset + 3, $focus_flg);
	}

	public void focus_flg(boolean value) {
		setConstBoolean(offset + 3, $focus_flg, value);
	}


	public boolean required_flg() {
		return getConstBoolean(offset + 4, $required_flg);
	}

	public void required_flg(boolean value) {
		setConstBoolean(offset + 4, $required_flg, value);
	}


	public String text() {
		return getConstString(offset + 5, $text);
	}

	public void text(String value) {
		setConstString(offset + 5, $text, value);
	}


	public boolean check() {
		return getConstBoolean(offset + 6, $check);
	}

	public void check(boolean value) {
		setConstBoolean(offset + 6, $check, value);
	}


	public String radio() {
		return getConstString(offset + 7, $radio);
	}

	public void radio(String value) {
		setConstString(offset + 7, $radio, value);
	}


	public String radio_nm() {
		return getConstString(offset + 8, $radio_nm);
	}

	public void radio_nm(String value) {
		setConstString(offset + 8, $radio_nm, value);
	}


	public boolean today_flg() {
		return getConstBoolean(offset + 9, $today_flg);
	}

	public void today_flg(boolean value) {
		setConstBoolean(offset + 9, $today_flg, value);
	}


	public boolean firstday_flg() {
		return getConstBoolean(offset + 10, $firstday_flg);
	}

	public void firstday_flg(boolean value) {
		setConstBoolean(offset + 10, $firstday_flg, value);
	}


	public boolean lastday_flg() {
		return getConstBoolean(offset + 11, $lastday_flg);
	}

	public void lastday_flg(boolean value) {
		setConstBoolean(offset + 11, $lastday_flg, value);
	}


	public MCTimestamp date() {
		return getConstTimestamp(offset + 12, $date);
	}

	public void date(MCTimestamp value) {
		setConstTimestamp(offset + 12, $date, value);
	}


	public MCNumber week() {
		return getConstNumber(offset + 13, $week);
	}

	public void week(MCNumber value) {
		setConstNumber(offset + 13, $week, value);
	}

	public void week(int value) {
		setConstNumber(offset + 13, $week, value);
	}

	public void week(long value) {
		setConstNumber(offset + 13, $week, value);
	}

	public void week(float value) {
		setConstNumber(offset + 13, $week, value);
	}

	public void week(double value) {
		setConstNumber(offset + 13, $week, value);
	}


	public String day_of_week_type() {
		return getConstString(offset + 14, $day_of_week_type);
	}

	public void day_of_week_type(String value) {
		setConstString(offset + 14, $day_of_week_type, value);
	}


	public String day_of_week_type_nm() {
		return getConstString(offset + 15, $day_of_week_type_nm);
	}

	public void day_of_week_type_nm(String value) {
		setConstString(offset + 15, $day_of_week_type_nm, value);
	}


	public MCNumber month() {
		return getConstNumber(offset + 16, $month);
	}

	public void month(MCNumber value) {
		setConstNumber(offset + 16, $month, value);
	}

	public void month(int value) {
		setConstNumber(offset + 16, $month, value);
	}

	public void month(long value) {
		setConstNumber(offset + 16, $month, value);
	}

	public void month(float value) {
		setConstNumber(offset + 16, $month, value);
	}

	public void month(double value) {
		setConstNumber(offset + 16, $month, value);
	}


	public MCNumber day() {
		return getConstNumber(offset + 17, $day);
	}

	public void day(MCNumber value) {
		setConstNumber(offset + 17, $day, value);
	}

	public void day(int value) {
		setConstNumber(offset + 17, $day, value);
	}

	public void day(long value) {
		setConstNumber(offset + 17, $day, value);
	}

	public void day(float value) {
		setConstNumber(offset + 17, $day, value);
	}

	public void day(double value) {
		setConstNumber(offset + 17, $day, value);
	}


	public MCNumber hour() {
		return getConstNumber(offset + 18, $hour);
	}

	public void hour(MCNumber value) {
		setConstNumber(offset + 18, $hour, value);
	}

	public void hour(int value) {
		setConstNumber(offset + 18, $hour, value);
	}

	public void hour(long value) {
		setConstNumber(offset + 18, $hour, value);
	}

	public void hour(float value) {
		setConstNumber(offset + 18, $hour, value);
	}

	public void hour(double value) {
		setConstNumber(offset + 18, $hour, value);
	}


	public MCNumber minute() {
		return getConstNumber(offset + 19, $minute);
	}

	public void minute(MCNumber value) {
		setConstNumber(offset + 19, $minute, value);
	}

	public void minute(int value) {
		setConstNumber(offset + 19, $minute, value);
	}

	public void minute(long value) {
		setConstNumber(offset + 19, $minute, value);
	}

	public void minute(float value) {
		setConstNumber(offset + 19, $minute, value);
	}

	public void minute(double value) {
		setConstNumber(offset + 19, $minute, value);
	}


	public MCNumber num() {
		return getConstNumber(offset + 20, $num);
	}

	public void num(MCNumber value) {
		setConstNumber(offset + 20, $num, value);
	}

	public void num(int value) {
		setConstNumber(offset + 20, $num, value);
	}

	public void num(long value) {
		setConstNumber(offset + 20, $num, value);
	}

	public void num(float value) {
		setConstNumber(offset + 20, $num, value);
	}

	public void num(double value) {
		setConstNumber(offset + 20, $num, value);
	}


	public String field_key() {
		return getConstString(offset + 21, $field_key);
	}

	public void field_key(String value) {
		setConstString(offset + 21, $field_key, value);
	}


	public String getString(String name) {
		if ($panel_name.equalsIgnoreCase(name)) {
			return panel_name();
		}
		if ($name.equalsIgnoreCase(name)) {
			return name();
		}
		if ($text.equalsIgnoreCase(name)) {
			return text();
		}
		if ($radio.equalsIgnoreCase(name)) {
			return radio();
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			return radio_nm();
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			return day_of_week_type();
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			return day_of_week_type_nm();
		}
		if ($field_key.equalsIgnoreCase(name)) {
			return field_key();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($week.equalsIgnoreCase(name)) {
			return week();
		}
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumber(name);
	}
	public MCTimestamp getTimestamp(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getTimestamp(name);
	}
	public boolean getBoolean(String name) {
		if ($set_flg.equalsIgnoreCase(name)) {
			return set_flg();
		}
		if ($focus_flg.equalsIgnoreCase(name)) {
			return focus_flg();
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			return required_flg();
		}
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			return today_flg();
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			return firstday_flg();
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			return lastday_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($panel_name.equalsIgnoreCase(name)) {
			return panel_name();
		}
		if ($name.equalsIgnoreCase(name)) {
			return name();
		}
		if ($text.equalsIgnoreCase(name)) {
			return text();
		}
		if ($radio.equalsIgnoreCase(name)) {
			return radio();
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			return radio_nm();
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			return day_of_week_type();
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			return day_of_week_type_nm();
		}
		if ($field_key.equalsIgnoreCase(name)) {
			return field_key();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($week.equalsIgnoreCase(name)) {
			return week();
		}
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumberNE(name);
	}
	public MCTimestamp getTimestampNE(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getTimestampNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($set_flg.equalsIgnoreCase(name)) {
			return set_flg();
		}
		if ($focus_flg.equalsIgnoreCase(name)) {
			return focus_flg();
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			return required_flg();
		}
		if ($check.equalsIgnoreCase(name)) {
			return check();
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			return today_flg();
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			return firstday_flg();
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			return lastday_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($panel_name.equalsIgnoreCase(name)) {
			panel_name(value);
			return;
		}
		if ($name.equalsIgnoreCase(name)) {
			name(value);
			return;
		}
		if ($text.equalsIgnoreCase(name)) {
			text(value);
			return;
		}
		if ($radio.equalsIgnoreCase(name)) {
			radio(value);
			return;
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			radio_nm(value);
			return;
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			day_of_week_type(value);
			return;
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			day_of_week_type_nm(value);
			return;
		}
		if ($field_key.equalsIgnoreCase(name)) {
			field_key(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setTimestamp(String name, MCTimestamp value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setTimestamp(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($set_flg.equalsIgnoreCase(name)) {
			set_flg(value);
			return;
		}
		if ($focus_flg.equalsIgnoreCase(name)) {
			focus_flg(value);
			return;
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			required_flg(value);
			return;
		}
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			today_flg(value);
			return;
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			firstday_flg(value);
			return;
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			lastday_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($panel_name.equalsIgnoreCase(name)) {
			panel_name(value);
			return;
		}
		if ($name.equalsIgnoreCase(name)) {
			name(value);
			return;
		}
		if ($text.equalsIgnoreCase(name)) {
			text(value);
			return;
		}
		if ($radio.equalsIgnoreCase(name)) {
			radio(value);
			return;
		}
		if ($radio_nm.equalsIgnoreCase(name)) {
			radio_nm(value);
			return;
		}
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			day_of_week_type(value);
			return;
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			day_of_week_type_nm(value);
			return;
		}
		if ($field_key.equalsIgnoreCase(name)) {
			field_key(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setTimestampNE(String name, MCTimestamp value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setTimestampNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($set_flg.equalsIgnoreCase(name)) {
			set_flg(value);
			return;
		}
		if ($focus_flg.equalsIgnoreCase(name)) {
			focus_flg(value);
			return;
		}
		if ($required_flg.equalsIgnoreCase(name)) {
			required_flg(value);
			return;
		}
		if ($check.equalsIgnoreCase(name)) {
			check(value);
			return;
		}
		if ($today_flg.equalsIgnoreCase(name)) {
			today_flg(value);
			return;
		}
		if ($firstday_flg.equalsIgnoreCase(name)) {
			firstday_flg(value);
			return;
		}
		if ($lastday_flg.equalsIgnoreCase(name)) {
			lastday_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

