package mcframe.clientFXUC.FXUCP0070;

/**
 * 入力値設定画面に実装するインタフェースです。
 */
public interface IfSrchCndPanel_FW {
	
	/**
	 * 入力値設定情報のコンテナを返します。
	 * 
	 * @param index 処理対象行
	 * @return 入力値設定情報のコンテナ
	 */
	public SrchCndR srchCndR(int index);
}