package mcframe.clientFXUC.FXUCP0070;

import java.util.ArrayList;
import java.util.List;

import mcframe.clientCore.resource.MCConst;
import mcframe.clientFXUC.FXUCP0210.FXUCP_PersonalizeUtil;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

public class SrchCndInfo_FW {

	/**
	 * 設定単位のデリミタ
	 */
	private static final String UNIT_DELIMITER = MCConst.beans
			.getStringNoTrim(MCConst.createKey("resource_setting_unit", "delimiter"), "");

	/**
	 * 初期設定フラグです。
	 */
	protected boolean _init_flg = false;

	/**
	 * 設定単位です。
	 */
	private String _setting_unit_type = null;

	/**
	 * 設定情報ＩＤです。
	 */
	protected String _setting_info_id = null;

	/**
	 * 設定情報名です。
	 */
	protected String _setting_info_name = null;

	/**
	 * 備考です。
	 */
	protected String _remark = null;

	/**
	 * 検索条件のリストです。
	 */
	protected List<SrchCndR> _srch_cnd_list = new ArrayList<>();

	/**
	 * 初期検索フラグです。
	 */
	protected boolean _init_srch_flg = false;

	/**
	 * 画面クリア時入力値設定フラグです。
	 */
	protected boolean _clear_flg = false;

	/**
	 * コンストラクタです。
	 */
	public SrchCndInfo_FW() {
	}

	/**
	 * 初期設定フラグを設定します。
	 *
	 * @param flg 初期設定フラグ
	 */
	public void setInitFlg(boolean flg) {
		_init_flg = flg;
	}

	/**
	 * 初期設定フラグを返します。
	 *
	 * @return 初期設定フラグ
	 */
	public boolean getInitFlg() {
		return _init_flg;
	}

	/**
	 * 設定単位を設定します。
	 *
	 * @param type 設定単位
	 */
	public void setSettingUnitType(String type) {
		_setting_unit_type = type;
	}

	/**
	 * 設定単位を返します。<p>
	 * 設定単位が設定されていない場合は null を返します。
	 *
	 * @return 設定単位、または null
	 */
	public String getSettingUnitType() {
		return _setting_unit_type;
	}

	/**
	 * 設定単位名を返します。<p>
	 * 設定単位名が設定されていない場合は null を返します。
	 *
	 * @return 設定単位名、または null
	 */
	public String getSettingUnitTypeName() {
		if (isNull(getSettingUnitType())) {
			return null;
		}
		FXC_RESOURCE_SETTING_UNIT type = FXC_RESOURCE_SETTING_UNIT
				.getNE(getSettingUnitType());
		return type == null ? null : type.name();
	}

	/**
	 * 設定情報ＩＤを設定します。
	 *
	 * @param id 設定情報ＩＤ
	 */
	public void setSettingInfoID(String id) {
		_setting_info_id = id;
	}

	/**
	 * 設定情報ＩＤを返します。<p>
	 * 設定情報ＩＤが設定されていない場合は null を返します。
	 *
	 * @return 設定情報ＩＤ、または null
	 */
	public String getSettingInfoID() {
		return _setting_info_id;
	}

	/**
	 * 設定情報名を設定します。
	 *
	 * @param name 設定情報名
	 */
	public void setSettingInfoName(String name) {
		_setting_info_name = name;
	}

	/**
	 * 設定情報名を返します。<p>
	 * 設定情報名が設定されていない場合は null を返します。
	 *
	 * @return 設定情報名、または null
	 */
	public String getSettingInfoName() {
		return _setting_info_name;
	}

	/**
	 * 設定単位付設定情報名を返します。<p>
	 * 設定情報名が設定されていない場合は null を返します。
	 *
	 * @return 設定単位付設定情報名、または null
	 */
	public String getSettingInfoUnitName() {
		return FXUCP_PersonalizeUtil.getSettingInfoUnitName(getSettingInfoName(),
				getSettingUnitType());
	}

	/**
	 * 備考を設定します。
	 *
	 * @param remark 備考
	 */
	public void setRemark(String remark) {
		_remark = remark;
	}

	/**
	 * 備考を返します。<p>
	 * 備考が設定されていない場合は null を返します。
	 *
	 * @return 備考、または null
	 */
	public String getRemark() {
		return _remark;
	}

	/**
	 * 検索条件のリストを設定します。
	 *
	 * @param list 検索条件のリスト
	 */
	public void setSrchCndList(List<SrchCndR> list) {
		_srch_cnd_list = list;
	}

	/**
	 * 検索条件のリストを返します。
	 *
	 * @return 検索条件のリスト
	 */
	public List<SrchCndR> getSrchCndList() {
		return _srch_cnd_list;
	}

	/**
	 * 初期検索フラグを設定します。
	 *
	 * @param flg 初期検索フラグ
	 */
	public void setInitSrchFlg(boolean flg) {
		_init_srch_flg = flg;
	}

	/**
	 * 初期検索フラグを返します。
	 *
	 * @return 初期検索フラグ
	 */
	public boolean getInitSrchFlg() {
		return _init_srch_flg;
	}

	/**
	 * 画面クリア時入力値設定フラグを設定します。
	 *
	 * @param flg 画面クリア時入力値設定フラグ
	 */
	public void setClearFlg(boolean flg) {
		_clear_flg = flg;
	}

	/**
	 * 画面クリア時入力値設定フラグを返します。
	 *
	 * @return 画面クリア時入力値設定フラグ
	 */
	public boolean getClearFlg() {
		return _clear_flg;
	}

}