package mcframe.clientFXUC.FXUCP0210;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCP_PersonalizeUtil extends FXUCP_PersonalizeUtil_FW {
	
}