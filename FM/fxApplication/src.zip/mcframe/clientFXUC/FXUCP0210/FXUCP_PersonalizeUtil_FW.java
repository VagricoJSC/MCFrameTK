package mcframe.clientFXUC.FXUCP0210;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

public class FXUCP_PersonalizeUtil_FW {

	/**
	 * 設定単位のデリミタ
	 */
	private static final String UNIT_DELIMITER = MCConst.beans
			.getStringNoTrim(MCConst.createKey("resource_setting_unit", "delimiter"), "");

	/**
	 * 設定単位付設定情報名を返します。<p>
	 * 設定情報名がnullの場合は null を返します。
	 *
	 * @param setting_info_nm 設定情報名
	 * @param setting_unit_type 設定単位
	 * @return 設定単位付設定情報名、または null
	 */
	public static String getSettingInfoUnitName(String setting_info_nm,
			String setting_unit_type) {
		if (isNull(setting_info_nm)) {
			return null;
		}
		FXC_RESOURCE_SETTING_UNIT type = FXC_RESOURCE_SETTING_UNIT
				.getNE(setting_unit_type);
		if (type == null || FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(type)) {
			return setting_info_nm;
		}
		return MCStringUtil.join(UNIT_DELIMITER, setting_info_nm, type.name());
	}
}