package mcframe.clientFXUC.FXUCP0140;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFXUC.FXUCP0130.*;


//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.beans.message.MCProgressInfo;
import mcframe.clientCore.beans.message.MCProgressPanel;
import mcframe.clientCore.beans.message.MCProgressThread;
import mcframe.clientCore.resource.MCConst;

import java.io.File;

import java.nio.charset.Charset;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.isNull;
import static mcframe.commonFX.notice.FX_Msg.FXUCP0001;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_Paging"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_Paging_FW extends FXUCP_Paging_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 件数表示のラベルに使用するためのメッセージ
	 */
	protected MCMessage _msgForDisp = new MCMessage(FXUCP0001);
	
	FXUCP_FileReader _fileReader;
	MCList<MCRow> _out;
	String[] _cols;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_Paging_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXUCP_Paging_FW(mcframe.clientFXUC.FXUCP0130.BtnR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Btn START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Btn END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[prev]の押下時の処理
	 */
	@Override
	public void doBtn_prev(MCEventInfo info) {

		MCProgressThread t = new MCProgressThread() {

			@Override
			public boolean doMultiThread() {
				return true;
			}

			@Override
			protected void action() {
				_fileReader.prev(_out, _cols);
			}
			
		};
		doProgress(t);
		dispUpdate();
	}
	
	/**
	 * Panel[Btn]のボタン[next]の押下時の処理
	 */
	@Override
	public void doBtn_next(MCEventInfo info) {
		MCProgressThread t = new MCProgressThread() {

			@Override
			public boolean doMultiThread() {
				return true;
			}

			@Override
			protected void action() {
				_fileReader.next(_out, _cols);
			}
			
		};
		doProgress(t);
		dispUpdate();
	}
	
	@Override
	public void doBtn_all_disp_NC(MCEventInfo info) {
		super.doBtn_all_disp_NC(info);
		
		if (getBtnR().all_disp()) {
			setValueEx(Btn_count, null);
		}
		else {
			setDefaultCountSize();
		}
	}

	@Override
	public void doBtn_count_NC(MCEventInfo info) {
		super.doBtn_count_NC(info);
		
		if (!isNull(getBtnR().count())) {
			getBtnR().all_disp(false);
			Btn_prev.setMode(getPrevMode());
			Btn_next.setMode(getNextMode());
		}
		else {
			getBtnR().all_disp(true);
			Btn_prev.setMode(MCMode.DISABLE);
			Btn_next.setMode(MCMode.DISABLE);
		}
	}
	/**
	 * プログレスダイアログによりthreadを実行します。
	 * @param t スレッド
	 */
	protected void doProgress(MCProgressThread t) {

		_fileReader.setCanceled(false);
		MCRootPanel panel = getBaseRootPanel();
		MCProgressInfo info = new MCProgressInfo(panel);
		MCProgressPanel pp = info.getProgressPanel(panel);
		t.setProgress(pp);
		info.setAction(t);
		info.setForceProgressDisplay(true);
		info.setDialogType(MCMessageBox.CANCEL_DIALOG);
		panel.showChildPanel((MCRootPanel) pp, MCPanelType.SINGLE);
		int rtnOption = pp.getResultOption();
		
		if (rtnOption == MCMessageBox.CANCEL_OPTION) {
			try {
				_fileReader.setCanceled(true);
				t.join();
			}
			catch (InterruptedException e) {
			}
		}
		Throwable ex = t.getException();
		if (ex != null) {
			MCException e = null;
			if (ex instanceof MCException) {
				e = (MCException)ex;
			}
			else {
				e = new MCException(ex);
			}
			throw e;
		}
	}
	
	/**
	 * ファイルを設定します。<p>
	 * {@link #setFile(File, Charset, String, boolean, MCNumber, MCNumber, MCList, String...)}
	 * を実行します。<br>
	 * ファイルが以下の条件を満たさない場合は上記メソッドを使用して下さい。<br>
	 * <li>ファイルの文字セットUTF-8
	 * <li>データの区切り文字「,」
	 * <li>文字列がダブルクォートで囲まれている
	 * 
	 * @param file 読み込み対象　
	 * @param lineTotal ファイル内の件数
	 * @param pageSize ページ件数(未指定の場合は{@link #setDefaultCountSize()}によりページ件数が設定される) 
	 * @param out データ格納対象コンテナ
	 * @param cols データ格納対象カラム
	 */
	public void setFile(File file, MCNumber lineTotal, MCNumber pageSize,
			MCList<? extends MCRow> out, String... cols) {
		setFile(file, null, null, true, lineTotal, pageSize, out, cols);
	}	
	/**
	 * ファイルを設定します。<p>
	 * 引数fileに設定できるものは、以下のフォーマットのテキストファイルのみです。<br>
	 * <li>１行目：項目ラベル
	 * <li>2行目以降：明細データ<br><br>
	 * 引数lineTotalにはfile内の件数を設定します。<br>
	 * ファイルのカラムindexと、引数colsのindexを一致させる必要があります。<br>
	 * 
	 * @param file 読み込み対象　
	 * @param charset ファイルの文字セット（未指定の場合は「UTF-8」を使用する）
	 * @param delimiter ファイルの区切り文字（未指定の場合は「,」を使用する）
	 * @param doubleQuote 文字列がダブルクォートで囲まれている場合trueを設定
	 * @param lineTotal ファイル内の件数
	 * @param pageSize ページ件数(未指定の場合は{@link #setDefaultCountSize()}によりページ件数が設定される) 
	 * @param out データ格納対象コンテナ
	 * @param cols データ格納対象カラム
	 */
	@SuppressWarnings("unchecked")//outのキャスト
	public void setFile(File file, Charset charset, String delimiter,
			boolean doubleQuote, MCNumber lineTotal, MCNumber pageSize,
			MCList<? extends MCRow> out, String... cols) {
		if (_fileReader != null && _fileReader._reader != null) {
			_fileReader._reader.close();
		}
		BtnR r = getBtnR();
		_fileReader = new FXUCP_FileReader(file, charset, delimiter, doubleQuote, r);
		_out = (MCList<MCRow>) out;
		_cols = cols;
		r.from(MCNumber.ZERO);
		r.to(MCNumber.ZERO);
		r.ttl(lineTotal);
		if (!isNull(pageSize)) {
			r.count(pageSize);
		}
		setDefaultCountSize();
	}
	
	/**
	 * 初期表示前の設定にします。<p>
	 * このメソッド実行後にBtn_nextのイベントを実行すると、１件目から表示対象になります。
	 */
	public void initPagingParam() {
		if (_fileReader != null) {
			_fileReader.initFileReader();
		}
	}
	
	/**
	 * ページ件数が未指定の場合にページ件数の初期値を設定します。<p>
	 * 初期値はMCAppClientリソースの設定が次の優先順で採用されます。
	 * <li>[moduleID].[screenID].pagesize
	 * <li>X.pagesize<br><br>
	 * いずれにも設定がない場合は1000を設定します。
	 * @param blkId ブロックＩＤ
	 */
	protected void setDefaultCountSize() {
		if (isNull(getBtnR().count())) {
			MCNumber val = getPgmSettingNumberNE(
						getBaseXPanel(), null, "pagesize");
			if (val == null) {
				val = MCConst.app.getNumber("FX.pagesize", null);
			}
			if (val == null) {
				val = MCNumber.valueOf(1000);
			}
			setValueEx(Btn_count, val);
		}
	}
	
	/**
	 * ファイルに記載されいているラベルを返します。
	 * @return
	 */
	public String[] getFileLabels(){
		return _fileReader.getLabels();
	}
	
	/**
	 * 表示状態を更新します。
	 */
	protected void dispUpdate() {
		if (_out.size() <= 0) {
			getBtnR().disp(null);
			Btn_disp.setToolTipText(null);
			Btn_prev.setMode(MCMode.DISABLE);
			Btn_next.setMode(MCMode.DISABLE);
		}
		else {
			_msgForDisp.setBind(getBtnR().ttl(), getBtnR().from(), getBtnR().to());
			getBtnR().disp(_msgForDisp.toString());
			Btn_disp.setToolTipText(_msgForDisp.toString());
			if (getBtnR().all_disp()) {
				Btn_prev.setMode(MCMode.DISABLE);
				Btn_next.setMode(MCMode.DISABLE);
			}
			else {
				Btn_prev.setMode(getPrevMode());
				Btn_next.setMode(getNextMode());
			}
		}
	}
	/**
	 * Btn_nextのモードを返します。
	 * @return モード
	 */
	protected MCMode getNextMode() {
		if (getBtnR().to().eq(getBtnR().ttl())) {
			return MCMode.READ_ONLY;
		}
		else {
			return MCMode.ENABLE;
		}
	}
	/**
	 * Btn_prevのモードを返します。
	 * @return モード
	 */
	protected MCMode getPrevMode() {
		if (getBtnR().from().lte(MCNumber.ONE)) {
			return MCMode.READ_ONLY;
		}
		else {
			return MCMode.ENABLE;
		}
	}
	
	/**
	 * {@inheritDoc}<p>
	 * 表示位置を表示するラベルをクリアします。
	 */
	@Override
	public void setDISABLEStatus() {
		super.setDISABLEStatus();
		getBtnR().disp(null);
		Btn_disp.setToolTipText(null);
		
	}

}