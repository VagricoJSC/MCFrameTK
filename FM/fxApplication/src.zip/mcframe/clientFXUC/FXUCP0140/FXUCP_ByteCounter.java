package mcframe.clientFXUC.FXUCP0140;

import java.nio.charset.CharsetEncoder;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCP_ByteCounter extends FXUCP_ByteCounter_FW{

	protected FXUCP_ByteCounter(CharsetEncoder encoder) {
		super(encoder);
	}
}
