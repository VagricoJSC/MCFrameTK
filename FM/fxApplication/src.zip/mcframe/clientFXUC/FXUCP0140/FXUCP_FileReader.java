package mcframe.clientFXUC.FXUCP0140;

import java.io.File;
import java.nio.charset.Charset;

import mcframe.clientFXUC.FXUCP0130.BtnR;
import mcframe.commonCore.annotation.EI;

@EI
public class FXUCP_FileReader extends FXUCP_FileReader_FW{

	public FXUCP_FileReader(File file, Charset charset, String delimiter, boolean doubleQuart, BtnR row) {
		super(file, charset, delimiter, doubleQuart, row);
	}
}
