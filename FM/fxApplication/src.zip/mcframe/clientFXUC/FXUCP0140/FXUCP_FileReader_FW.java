package mcframe.clientFXUC.FXUCP0140;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import mcframe.clientFXUC.FXUCP0130.BtnR;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.util.MCCsvEnToken;

public class FXUCP_FileReader_FW {

	/**
	 * ファイルの位置を保持する単位行数です。
	 */
	protected int _posBuf = 1000;

	/**
	 * 文字セットです。
	 */
	protected final Charset _charset;

	/**
	 * ファイルのデリミタです。<p>
	 * はじめの１文字のみ使用されます。<br>
	 * 未指定の場合はMCCsvEnTokenの初期設定のままです。
	 * 
	 */
	protected final String _delimiter;

	/**
	 * 文字列がダブルクォートで囲まれているかどうかの設定です。<p>
	 */
	protected final boolean _dq;
	

	/**
	 * ページング情報です。
	 */
	protected BtnR _param;
	
	/**
	 * 読み込み開始位置です。
	 */
	protected long _initBytes;

	/**
	 * 読み込み開始位置のキャッシュです。
	 */
	protected List<Long> _posList = new ArrayList<>();
	
	/**
	 * ファイルです。
	 */
	protected File _file;

	/**
	 * CSV読み込みトークンです。
	 */
	protected MCCsvEnToken _mctoken;

	/**
	 * InputStreamReaderです。
	 */
	protected FXUCP_InputStreamReader _reader;

	/**
	 * ファイルから読み込んだラベルの配列です。
	 */
	protected String[] _labels;

	/**
	 * 今までに読み込んだ行の最大数です。
	 */
	protected long _maxLine;

	/**
	 * キャンセルしたかどうかを表します。
	 */
	protected boolean _canceled = false;
	
	/**
	 * コンストラクタです。
	 * @param file 読み込み対象　
	 * @param charset ファイルの文字セット（未指定の場合は「UTF-8」を使用する）
	 * @param delimiter ファイルの区切り文字（未指定の場合は「,」を使用する）
	 * @param doubleQuote 文字列がダブルクォートで囲まれている場合trueを設定
	 * @param　row ページング情報（next prevなどで内容が変更される）
	 */
	public FXUCP_FileReader_FW(File file, Charset charset, String delimiter, boolean doubleQuote, BtnR row) {
				
		_file = file;
		if (charset != null) {
			_charset = charset;
		}
		else {
			_charset = Charset.forName("UTF-8");
		}
		_delimiter = delimiter;
		_dq = doubleQuote;
		_param = row;
		//開始を表すために0を設定
		initFileReader();
	}
	
	/**
	 * 本クラスを初期化します。
	 */
	public void initFileReader() {
		//開始を表すために0を設定
		_param.from(MCNumber.ZERO);
		_param.to(MCNumber.ZERO);
		_maxLine = 0L;
		_initBytes = 0L;
		_posList.clear();
		_canceled = false;
		initMCCsvEnToken();
		if (_mctoken.hasMoreTokens()) {
			_labels = _mctoken.nextLineTokens();
			_posList.add(_reader.getCount());
		}
		else {
			_labels = new String[0];
		}
	}

	/**
	 * 次の値を引数outに設定します。<p>
	 * ファイルのカラムindex順に、引数colsのカラムに値を設定します。
	 * @param out コンテナ
	 * @param cols カラム名配列
	 */
	public void next(final MCList<MCRow> out, final String... cols) {

		if (out == null) {
			return ;
		}
		
		if (_param.from().lte(MCNumber.ZERO)) {
			_param.from(MCNumber.ONE);
		}
		else {
			_param.from(_param.to().add(MCNumber.ONE));
		}
		nextImpl(out, cols);
	}
	
	/**
	 * ページング情報のfrom、count、all_dispの値に応じてファイルを読み込みます。
	 * @param out 結果格納用コンテナ
	 * @param cols コンテナカラム名配列
	 */
	protected void nextImpl(MCList<MCRow> out, String... cols) {

		if (out == null) {
			return ;
		}

		MCList<MCRow> rslt = (MCList<MCRow>)out.createInstance();
		
		long from = _param.from().longValueExact();
		long curIdx = from - 1L;
		long size = Long.MIN_VALUE;
		boolean all = _param.all_disp();
		long readCount;

		if (!all) {
			size = _param.count().intValue();
		}
		
		if (curIdx < 0L) {
			curIdx = 0L;
		}
		//loop内でコンテナの値は変更しないこと（描画をさせないため）
		out.clear();
		for (readCount = 0L; true; readCount++) {
			
			if (_canceled) {
				readCount--;
				break;
			}
			
			//hasMoreTokensの実行で_readerのバイトカウントが追加されるため、
			//_posListへのキャッシュの処理は、hasMoreTokensよりも前に呼ぶ必要がある。
			if (curIdx > _maxLine && curIdx % _posBuf == 0L) {
				_posList.add(_reader.getCount() + _initBytes);
				_maxLine = curIdx;
			}

			//次のページの場合
			if (!all && readCount >= size) {
				readCount--;
				break;
			}
			
			
			//最終行の場合
			if (!_mctoken.hasMoreTokens()) {
				readCount--;
				break;
			}
			
			String[] vals = _mctoken.nextLineTokens();
			
			MCRow r = out.createRow();
			
			for (int c = 0; c < vals.length; c++) {
				String val = vals[c];
				if (cols.length > c) {
					String col = cols[c];
					r.setStringNE(col, val);
				}
			}
			rslt.add(r);
			curIdx++;
		}
		out.addAll(rslt);
		
		_param.to(from + readCount);

	}
	
	/**
	 * 前の値を引数outに設定します。
	 * ファイルのカラムindex順に、引数colsのカラムに値を設定します。
	 * @param out コンテナ
	 * @param 前があるかどうか
	 */
	public void prev(MCList<MCRow> out, String... cols) {

		if (out == null) {
			return ;
		}
		
		long from = _param.from().longValueExact();
		long newFrom = from - _param.count().longValueExact();
		if (newFrom <= 0L) {
			newFrom = 1L;
		}
		
		long prevIdx = newFrom - 1L;
		long prevPos = prevIdx/_posBuf;//あまりは切り捨て
		_initBytes = _posList.get(
				MCNumber.valueOf(prevPos).intValueExact()).longValue();
		long curIdx = prevPos*_posBuf;
		initMCCsvEnToken();
				
		//開始行まで移動
		while (prevIdx > curIdx) {
			if (!_mctoken.hasMoreTokens()) {
				break;
			}
			_mctoken.nextLineTokens();
			curIdx++;
		}
		_param.from(newFrom);
		_param.to(newFrom);
		nextImpl(out, cols);
		
	}
	
	/**
	 * 現在の設定でMCCsvEnTokenを再作成します。
	 */
	protected void initMCCsvEnToken() {
		if (_reader != null) {
			_reader.close();
		}
		_reader = FXUCP_InputStreamReader.create(_file, _charset, _initBytes);
		_mctoken = new MCCsvEnToken(_reader);
		if (_delimiter != null) {
			_mctoken.setDelimiter(_delimiter.charAt(0));
		}
		_mctoken.setDoubleQuotation(_dq);
	}
	
	/**
	 * ファイルのラベルを返す。
	 * @return ラベル
	 */
	public String[] getLabels() {
		return _labels;
	}

	/**
	 * キャンセルする場合trueを設定します。
	 * @param キャンセルするかどうか
	 */
	public void setCanceled(boolean b) {
		_canceled = b;
	}
}
