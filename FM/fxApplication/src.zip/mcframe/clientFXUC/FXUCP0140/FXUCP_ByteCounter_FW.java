package mcframe.clientFXUC.FXUCP0140;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CoderResult;

import mcframe.commonCore.notice.MCException;
import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * 文字のバイト数をカウントするクラスです。
 */
public class FXUCP_ByteCounter_FW {

	/**
	 * バッファの容量です。
	 */
	protected static final int BUFFER = 1024;

	/**
	 * エンコーダです。
	 */
	protected CharsetEncoder _encoder;

	/**
	 * 文字バッファです。
	 */
	protected CharBuffer _charBuf;

	/**
	 * バイトバッファです。
	 */
	protected ByteBuffer _byteBuf;

	/**
	 * バイト数です。
	 */
	protected long _count;

	/**
	 * 
	 * コンストラクタです。
	 * 
	 * @param encoder エンコーダ
	 */
	protected FXUCP_ByteCounter_FW(CharsetEncoder encoder) {
		super();
		this._encoder = encoder;
		this._charBuf = CharBuffer.allocate(BUFFER);
		this._byteBuf = ByteBuffer.allocate((int) (BUFFER * (double) encoder
				.maxBytesPerChar()));
		_count = 0L;
	}
	
	/**
	 * バイト数を返します。
	 * 
	 * @return バイト数
	 */
	protected long getCount() {
		flush();
		return _count;
	}

	/**
	 * バッファに文字を書き込みます。
	 * <p>
	 * バッファ位置が{@link #BUFFER}と同値の場合はバッファをフラッシュします。
	 *
	 * @param c 文字
	 */
	protected void count(char c) {
		if (_charBuf.position() == BUFFER) {
			flush();
		}
		_charBuf.put(c);
	}

	/**
	 * バッファに追加された文字のバイト数を計算し、バッファをクリアします。
	 */
	protected void flush() {
		if (_charBuf.position() > 0) {
			_encoder.reset();
			_byteBuf.clear();
			_charBuf.limit(_charBuf.position());
			_charBuf.position(0);
			CoderResult result = _encoder.encode(_charBuf, _byteBuf, true);
			throwException(result);
			result = _encoder.flush(_byteBuf);
			throwException(result);
			_count += (long)_byteBuf.position();
			_charBuf.clear();
		}
	}

	/**
	 * CoderResultの例外チェックをします。
	 * @param result CorderResult
	 */
	protected void throwException(CoderResult result) {
		if (!result.isUnderflow() && result.isError()) {
			try {
				result.throwException();
			}
			catch (Exception e) {
				throw new MCException(e, FXUCP0036);
			}
		}
	}
}
