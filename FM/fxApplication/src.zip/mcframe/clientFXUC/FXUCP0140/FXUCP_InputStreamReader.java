package mcframe.clientFXUC.FXUCP0140;

import java.io.InputStream;
import java.nio.charset.Charset;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCP_InputStreamReader extends FXUCP_InputStreamReader_FW {
	protected FXUCP_InputStreamReader(InputStream in, Charset cs)  {
		super(in, cs);
	}
}
