package mcframe.clientFXUC.FXUCP0140;

import static mcframe.commonFX.notice.FX_Msg.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCLog;

public class FXUCP_InputStreamReader_FW extends InputStreamReader {

	final Charset _cs;
	InputStream _fs;
	
	/**
	 * バイトカウンターです。
	 */
	FXUCP_ByteCounter _counter;
	
	/**
	 * コンストラクタです。
	 * @param in ストリーム
	 * @param cs 文字コード
	 * @throws FileNotFoundException ファイルが存在しない場合
	 */
	protected FXUCP_InputStreamReader_FW(InputStream in, Charset cs)  {
		super(in, cs);
		_fs = in;
		_cs = cs;
		_counter = new FXUCP_ByteCounter(cs.newEncoder());
		
	}
	
	/**
	 * FXUCP_InputStreamReaderを生成します。
	 * @param f ファイル
	 * @param cs 文字コード
	 * @param initBytes 読み込み開始位置
	 * @return インスタンス
	 */
	protected static FXUCP_InputStreamReader create(File f, Charset cs, long initBytes) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(f);
			fis.getChannel().position(initBytes);
			return new FXUCP_InputStreamReader(fis, cs);
		}
		//FileInputStream
		catch (FileNotFoundException e) {
			if (fis != null) {
				try {
					fis.close();
				}
				catch (IOException e1) {
					MCLog.write(e1);
				}
			}
			
			throw new MCAppException(e, FXUCP0037, f.getAbsolutePath());
		}
		//position
		catch (IOException e) {
			throw new MCAppException(e);
		}
	}
	
	@Override
	public int read() throws IOException {
		int ret = super.read();
		if (ret != -1 && _counter != null) {
			_counter.count((char) ret);
		}
		return ret;
	}
	
	/**
	 * ファイルの読込済バイト数を返します。
	 *
	 * @return 読込済バイト数
	 */
	protected long getCount() {
		return _counter.getCount();
	}
	
	/**
	 * ストリームをcloseします。<p>
	 * I/O例外はログに出力します。
	 */
	@Override
	public void close() {
		try {
			super.close();
		}
		catch (IOException e) {
			MCLog.write(e);
		}
	}
}
