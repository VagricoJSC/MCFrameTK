package mcframe.clientFXUC.FXUCP0100;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Rslt"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class RsltR_FW_A extends MCConstRow {

	/**
	 *  選択.<p>
	 *
	 */
	public static final String $select = "select";
	/**
	 *  値.<p>
	 *
	 */
	public static final String $in_value = "in_value";
	/**
	 *  表示内容.<p>
	 *
	 */
	public static final String $view_value = "view_value";


	public static final MCMeta select_META = createCommonMeta($select, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta in_value_META = createStringMeta($in_value);
	public static final MCMeta view_value_META = createStringMeta($view_value);

	protected static final ConstMetaList<RsltR> constMetas = new ConstMetaList<RsltR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			select_META,
			in_value_META,
			view_value_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected RsltR_FW_A(ConstMetaList<? extends RsltR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR clone() {
		return (RsltR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR createInstance() {
		return (RsltR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR getValues(String... names) {
		return (RsltR) super.getValues(names);
	}



	/**
	 *  選択.<p>
	 *
	 */
	public boolean select() {
		return getConstBoolean(offset + 0, $select);
	}

	/**
	 *  選択.<p>
	 *
	 */
	public void select(boolean value) {
		setConstBoolean(offset + 0, $select, value);
	}


	/**
	 *  値.<p>
	 *
	 */
	public String in_value() {
		return getConstString(offset + 1, $in_value);
	}

	/**
	 *  値.<p>
	 *
	 */
	public void in_value(String value) {
		setConstString(offset + 1, $in_value, value);
	}


	/**
	 *  表示内容.<p>
	 *
	 */
	public String view_value() {
		return getConstString(offset + 2, $view_value);
	}

	/**
	 *  表示内容.<p>
	 *
	 */
	public void view_value(String value) {
		setConstString(offset + 2, $view_value, value);
	}


	public String getString(String name) {
		if ($in_value.equalsIgnoreCase(name)) {
			return in_value();
		}
		if ($view_value.equalsIgnoreCase(name)) {
			return view_value();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($select.equalsIgnoreCase(name)) {
			return select();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($in_value.equalsIgnoreCase(name)) {
			return in_value();
		}
		if ($view_value.equalsIgnoreCase(name)) {
			return view_value();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($select.equalsIgnoreCase(name)) {
			return select();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($in_value.equalsIgnoreCase(name)) {
			in_value(value);
			return;
		}
		if ($view_value.equalsIgnoreCase(name)) {
			view_value(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($select.equalsIgnoreCase(name)) {
			select(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($in_value.equalsIgnoreCase(name)) {
			in_value(value);
			return;
		}
		if ($view_value.equalsIgnoreCase(name)) {
			view_value(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($select.equalsIgnoreCase(name)) {
			select(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

