package mcframe.clientFXUC.FXUCP0100;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FXUCP_InPluralValue"パネルクラスです。<p>
 *
 * 複数値の検索を行います。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXUCP_InPluralValue_FW_A extends mcframe.clientFXBA.FXBAP0030.FXBAP_ISPanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXUC";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXUCP0100";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Rslt]ブロック関連のField定義
	public MCPanel RsltPanel = null;
	public MCScrollPane RsltScrollPane = null;
	public MCTable2<mcframe.clientFXUC.FXUCP0100.RsltR> RsltTable = null;
	// [Rslt]ブロックの項目のField定義
	/**
	 *  選択.<p>
	 *
	 */
	public MCColumnConfig columnRslt_select = null;
	/**
	 *  値.<p>
	 *
	 */
	public MCColumnConfig columnRslt_in_value = null;
	/**
	 *  表示内容.<p>
	 *
	 */
	public MCColumnConfig columnRslt_view_value = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 * 追加 追加.<p>
	 *
	 */
	public MCButton Btn_add = null;
	/**
	 * 削除 削除.<p>
	 *
	 */
	public MCButton Btn_del = null;
	/**
	 *  全選択.<p>
	 *
	 */
	public MCButton Btn_select_all = null;
	/**
	 *  全解除.<p>
	 *
	 */
	public MCButton Btn_deselect_all = null;
	/**
	 * 行コピー 行コピー.<p>
	 *
	 */
	public MCButton Btn_copy = null;
	/**
	 *  決定.<p>
	 *
	 */
	public MCButton Btn_accept = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [COMB_S]モードを表す定数 */
	public static final String COMB_S = "COMB_S";
	/** [COMB_F]モードを表す定数 */
	public static final String COMB_F = "COMB_F";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, COMB_S, COMB_F};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Rslt]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXUC.FXUCP0100.RsltR> aRsltL;

	/**
	 * コピーによってaRsltLを設定します。
	 *
	 * aRsltLのインスタンスは変更されません。
	 *
	 * @param dataset RsltL
	 */
	public void setRsltL(MCList<mcframe.clientFXUC.FXUCP0100.RsltR> aList) {
		if (getRsltL() != aList) {
			getRsltL().setAll(aList);
		}
	}

	/**
	 * [Rslt]ブロックのコンテナaRsltLを返します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0100.RsltR> getRsltL() {
		return aRsltL;
	}

	/**
	 * aRsltRを作成します。
	 *
	 * @return RsltR
	 */
	public mcframe.clientFXUC.FXUCP0100.RsltR createRsltR() {
		return mcframe.clientFXUC.FXUCP0100.RsltR.create();
	}

	/**
	 * aRsltLを作成します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0100.RsltR> createRsltL() {
		return MCList.create(mcframe.clientFXUC.FXUCP0100.RsltR.class);
	}

	/**
	 * RsltTableを初期化します。
	 */
	protected void createRsltTable(){
		if(RsltTable == null){
			RsltTable = beansFactory.createTable2("Rslt.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getRsltL())) ret.add(getRsltL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getRsltL()) return "Rslt";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Rslt")) return getRsltL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(RsltPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_InPluralValue_FW_A() {
		aRsltL = createRsltL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXUCP_InPluralValue_FW_A(String name) {
		aRsltL = createRsltL();
		createRsltTable();
		RsltTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXUCP_InPluralValue_FW.jbCreateRslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.jbCreateBtn((FXUCP_InPluralValue)this);
	}

	/**
	 * [Rslt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateRslt(FXUCP_InPluralValue p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FXUCP_InPluralValue p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_InPluralValue create(){
		FXUCP_InPluralValue p = new FXUCP_InPluralValue();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_InPluralValue create(String name){
		FXUCP_InPluralValue p = new FXUCP_InPluralValue(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXUCP_InPluralValue_FW.jbfInitRslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.jbfInitBtn((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.jbInitRslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.jbInitBtn((FXUCP_InPluralValue)this);
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitRslt(FXUCP_InPluralValue p) {
		// ブロック関連の初期化
		p.RsltPanel = p.beansFactory.createPanel("Rslt");
		p.RsltScrollPane = p.beansFactory.createScrollPane("Rslt.scroll");
		p.createRsltTable();
		// ブロックの項目の初期化
		p.columnRslt_select = p.beansFactory.createTableColumn("Rslt.select", MCColumnType.CHECK);
		p.columnRslt_in_value = p.beansFactory.createTableColumn("Rslt.in_value", MCColumnType.TEXT);
		p.columnRslt_view_value = p.beansFactory.createTableColumn("Rslt.view_value", MCColumnType.TEXT);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FXUCP_InPluralValue p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_add = p.beansFactory.createButton("Btn.add", "no_border");
		p.Btn_del = p.beansFactory.createButton("Btn.del", "no_border");
		p.Btn_select_all = p.beansFactory.createButton("Btn.select_all", "no_border");
		p.Btn_deselect_all = p.beansFactory.createButton("Btn.deselect_all", "no_border");
		p.Btn_copy = p.beansFactory.createButton("Btn.copy", "no_border");
		p.Btn_accept = p.beansFactory.createButton("Btn.accept", "upd");
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitRslt(FXUCP_InPluralValue p) {
		// ブロック関連の初期化
		p.add(p.RsltPanel);
		p.setLastBeans(p.RsltPanel);
		p.RsltPanel.setNextBeans(p.BtnPanel);
		p.RsltPanel.add(p.RsltScrollPane);
		p.RsltPanel.setLastBeans(p.RsltTable);
		p.RsltScrollPane.setViewportView(p.RsltTable);
		p.RsltTable.setList(p.getRsltL());
		p.RsltTable.setStatusColumnVisible(false);
		p.RsltPanel.setValueCheck(false);
		p.RsltPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FXUCP_InPluralValue p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_add.setIcon("INSERT_RECORD");
		p.Btn_add.setFunctionKey(MCFunctionKey.F5);
		p.BtnPanel.add(p.Btn_add);
		p.BtnPanel.setLastBeans(p.Btn_add);
		p.Btn_add.setNextBeans(p.Btn_del);
		p.Btn_del.setIcon("DELETE_RECORD");
		p.Btn_del.setFunctionKey(MCFunctionKey.F6);
		p.BtnPanel.add(p.Btn_del);
		p.Btn_del.setNextBeans(p.Btn_select_all);
		p.Btn_select_all.setIcon("SELECT_ALL");
		p.Btn_select_all.setFunctionKey(MCFunctionKey.F13);
		p.BtnPanel.add(p.Btn_select_all);
		p.Btn_select_all.setNextBeans(p.Btn_deselect_all);
		p.Btn_deselect_all.setIcon("DESELECT_ALL");
		p.Btn_deselect_all.setFunctionKey(MCFunctionKey.F14);
		p.BtnPanel.add(p.Btn_deselect_all);
		p.Btn_deselect_all.setNextBeans(p.Btn_copy);
		p.Btn_copy.setIcon("COPY_RECORD");
		p.Btn_copy.setFunctionKey(MCFunctionKey.F17);
		p.BtnPanel.add(p.Btn_copy);
		p.Btn_copy.setNextBeans(p.Btn_accept);
		p.Btn_accept.setIcon("REGISTER");
		p.Btn_accept.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_accept);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXUCP_InPluralValue_FW.mcInitRslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.mcInitBtn((FXUCP_InPluralValue)this);

		// [INIT]ステータスのモードの設定
		FXUCP_InPluralValue_FW.statusInitINIT_Rslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.statusInitINIT_Btn((FXUCP_InPluralValue)this);

		// [COMB_S]ステータスのモードの設定
		FXUCP_InPluralValue_FW.statusInitCOMB__S_Rslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.statusInitCOMB__S_Btn((FXUCP_InPluralValue)this);

		// [COMB_F]ステータスのモードの設定
		FXUCP_InPluralValue_FW.statusInitCOMB__F_Rslt((FXUCP_InPluralValue)this);
		FXUCP_InPluralValue_FW.statusInitCOMB__F_Btn((FXUCP_InPluralValue)this);

	}

	/**
	 *  [Rslt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitRslt(FXUCP_InPluralValue p) {
		p.RsltTable.addAllListener(p);
		p.columnRslt_select.addAllListener(p);
		p.columnRslt_in_value.addAllListener(p);
		p.columnRslt_in_value.setListListener(p);
		p.columnRslt_view_value.addAllListener(p);
		p.columnRslt_view_value.setListListener(p);
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FXUCP_InPluralValue p) {
		p.Btn_add.addAllListener(p);
		p.Btn_add.setAPMethodName("doBtn_add");
		p.Btn_del.addAllListener(p);
		p.Btn_del.setAPMethodName("doBtn_del");
		p.Btn_select_all.addAllListener(p);
		p.Btn_select_all.setAPMethodName("doBtn_select_all");
		p.Btn_deselect_all.addAllListener(p);
		p.Btn_deselect_all.setAPMethodName("doBtn_deselect_all");
		p.Btn_copy.addAllListener(p);
		p.Btn_copy.setAPMethodName("doBtn_copy");
		p.Btn_accept.addAllListener(p);
		p.Btn_accept.setAPMethodName("doBtn_accept");
	}

	/**
	 * [INIT]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Rslt(FXUCP_InPluralValue p){
		p.columnRslt_select.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnRslt_in_value.putMode(p, INIT, MCMode.ENABLE);
		p.columnRslt_view_value.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FXUCP_InPluralValue p){
		p.Btn_add.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_del.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_select_all.putMode(p, INIT, MCMode.READ_ONLY);
		p.Btn_deselect_all.putMode(p, INIT, MCMode.READ_ONLY);
		p.Btn_copy.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_accept.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [COMB_S]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitCOMB__S_Rslt(FXUCP_InPluralValue p){
		p.columnRslt_select.putMode(p, COMB_S, MCMode.REQUIRED);
		p.columnRslt_in_value.putMode(p, COMB_S, MCMode.READ_ONLY);
		p.columnRslt_view_value.putMode(p, COMB_S, MCMode.READ_ONLY);

	}

	/**
	 * [COMB_S]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitCOMB__S_Btn(FXUCP_InPluralValue p){
		p.Btn_add.putMode(p, COMB_S, MCMode.READ_ONLY);
		p.Btn_del.putMode(p, COMB_S, MCMode.READ_ONLY);
		p.Btn_select_all.putMode(p, COMB_S, MCMode.ENABLE);
		p.Btn_deselect_all.putMode(p, COMB_S, MCMode.ENABLE);
		p.Btn_copy.putMode(p, COMB_S, MCMode.READ_ONLY);
		p.Btn_accept.putMode(p, COMB_S, MCMode.ENABLE);

	}

	/**
	 * [COMB_F]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitCOMB__F_Rslt(FXUCP_InPluralValue p){
		p.columnRslt_select.putMode(p, COMB_F, MCMode.REQUIRED);
		p.columnRslt_in_value.putMode(p, COMB_F, MCMode.ENABLE);
		p.columnRslt_view_value.putMode(p, COMB_F, MCMode.READ_ONLY);

	}

	/**
	 * [COMB_F]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitCOMB__F_Btn(FXUCP_InPluralValue p){
		p.Btn_add.putMode(p, COMB_F, MCMode.ENABLE);
		p.Btn_del.putMode(p, COMB_F, MCMode.ENABLE);
		p.Btn_select_all.putMode(p, COMB_F, MCMode.ENABLE);
		p.Btn_deselect_all.putMode(p, COMB_F, MCMode.ENABLE);
		p.Btn_copy.putMode(p, COMB_F, MCMode.ENABLE);
		p.Btn_accept.putMode(p, COMB_F, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FXUCP_InPluralValue_FW.setTableConfigRslt((FXUCP_InPluralValue)this);
	}

	/**
	 * [Rslt]ブロックのTableの設定
	 */
	protected static void setTableConfigRslt(FXUCP_InPluralValue p) {
		p.columnRslt_select.setMeta(mcframe.clientFXUC.FXUCP0100.RsltR.select_META);
		p.RsltTable.addColumnConfig(p.columnRslt_select);
		p.columnRslt_in_value.setMeta(mcframe.clientFXUC.FXUCP0100.RsltR.in_value_META);
		p.RsltTable.addColumnConfig(p.columnRslt_in_value);
		p.columnRslt_view_value.setMeta(mcframe.clientFXUC.FXUCP0100.RsltR.view_value_META);
		p.RsltTable.addColumnConfig(p.columnRslt_view_value);
		// スクロール固定カラムの指定
		p.RsltTable.setUnscrollColumn(p.columnRslt_select);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[COMB_S]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setCOMB_SStatus() {
		status = COMB_S;
		setAllStatus(status);
	}

	/**
	 * この画面を[COMB_F]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setCOMB_FStatus() {
		status = COMB_F;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (COMB_S.equals(status)) {
			setCOMB_SStatus();
		}
		else if (COMB_F.equals(status)) {
			setCOMB_FStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_add) doBtn_add(info);
		else if (ap == Btn_del) doBtn_del(info);
		else if (ap == Btn_select_all) doBtn_select_all(info);
		else if (ap == Btn_deselect_all) doBtn_deselect_all(info);
		else if (ap == Btn_copy) doBtn_copy(info);
		else if (ap == Btn_accept) doBtn_accept(info);
	}

	/**
	 * [Btn]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_add(MCEventInfo info);

	/**
	 * [Btn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_del(MCEventInfo info);

	/**
	 * [Btn]パネルの[select_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_select_all(MCEventInfo info);

	/**
	 * [Btn]パネルの[deselect_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_deselect_all(MCEventInfo info);

	/**
	 * [Btn]パネルの[copy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_copy(MCEventInfo info);

	/**
	 * [Btn]パネルの[accept]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_accept(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == RsltTable) return doRslt_VC(info);
		if (vc == columnRslt_select) return doRslt_select_VC(info);
		if (vc == columnRslt_in_value) return doRslt_in_value_VC(info);
		if (vc == columnRslt_view_value) return doRslt_view_value_VC(info);
		return true;
	}

	/**
	 * [Rslt]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[select]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_select_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[in_value]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_in_value_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[view_value]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_view_value_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == RsltTable) doRslt_NC(info);
		else if (nc == columnRslt_select) doRslt_select_NC(info);
		else if (nc == columnRslt_in_value) doRslt_in_value_NC(info);
		else if (nc == columnRslt_view_value) doRslt_view_value_NC(info);
	}

	/**
	 * [Rslt]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[select]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_select_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[in_value]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_in_value_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[view_value]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_view_value_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == RsltTable) doRslt_NE(info);
		else if (ne == columnRslt_select) doRslt_select_NE(info);
		else if (ne == columnRslt_in_value) doRslt_in_value_NE(info);
		else if (ne == columnRslt_view_value) doRslt_view_value_NE(info);
	}

	/**
	 * [Rslt]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[select]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_select_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[in_value]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_in_value_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[view_value]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_view_value_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == RsltTable) doRslt_NX(info);
		else if (nx == columnRslt_select) doRslt_select_NX(info);
		else if (nx == columnRslt_in_value) doRslt_in_value_NX(info);
		else if (nx == columnRslt_view_value) doRslt_view_value_NX(info);
	}

	/**
	 * [Rslt]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[select]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_select_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[in_value]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_in_value_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[view_value]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_view_value_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnRslt_in_value) doRslt_in_value_LC(info);
		else if (lc == columnRslt_view_value) doRslt_view_value_LC(info);
	}

	/**
	 * [Rslt]パネルの[in_value]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_in_value_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[view_value]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_view_value_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}