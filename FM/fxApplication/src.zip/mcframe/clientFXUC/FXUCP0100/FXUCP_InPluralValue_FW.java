package mcframe.clientFXUC.FXUCP0100;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListConfig;
import mcframe.clientCore.beans.list.MCListType;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import static mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_InPluralValue"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_InPluralValue_FW extends FXUCP_InPluralValue_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	
	/**
	 * 呼出元画面からのバインド値
	 */
	MCRow _bind = null;
	
	/**
	 * 呼出元のフィールドオブジェクト
	 */
	Object _comp = null;
	
	
	/**
	 * 呼出元へ返す際の項目名
	 */
	String _inputCol = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_InPluralValue_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXUCP_InPluralValue_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doBtn_select_all(MCEventInfo info) {
		for(RsltR r:RsltTable.getViewRows()){
			if(!r.isEmpty()){
				RsltTable.setValue(true, r.getGUIIndex(), columnRslt_select);
			}
		}
	}
	/**
	 * Panel[Btn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doBtn_deselect_all(MCEventInfo info) {
		for (RsltR r : RsltTable.getViewRows()) {
			RsltTable.setValue(false, r.getGUIIndex(), columnRslt_select);
		}
	}

	/**
	 * Panel[Btn]のボタン[copy]の押下時の処理
	 */
	@Override
	public void doBtn_copy(MCEventInfo info) {
		RsltR r = RsltTable.getSelectedMCRow();
		if (r != null) {
			RsltR cp = r.clone();
			if (!r.isStatusGUICreate()) {
				cp.setStatus(MCRow.CREATE);
			}
			insertRow(RsltTable, cp);
		}
	}
	/**
	 * Panel[Btn]のボタン[add]の押下時の処理
	 */
	@Override
	public void doBtn_add(MCEventInfo info) {
		RsltTable.insertRow();
	}
	/**
	 * Panel[Btn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doBtn_del(MCEventInfo info) {
		RsltTable.truncateRow();
	}
	/**
	 * Panel[Btn]のボタン[accept]の押下時の処理
	 */
	@Override
	public void doBtn_accept(MCEventInfo info) {
		doAccept();
	}

	@Override
	public void doCnd_srch(MCEventInfo info) {
	}

	@Override
	public MCRow getCndR() {
		return null;
	}

	@Override
	public void setCondition(MCRow row, String mode) {
	}

	public void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		_bind = null;
		_comp = null;
		super.initByScreenParam(openTyp, bind, args);
		if (args != null && args.length > 2) {
			_bind = bind;
			_comp = args[2];
			valueInitWithMode(_bind, _comp);
		}
	}
	
	/**
	 * 値の初期化と、モードの設定を行います。
	 *
	 * @param bind 呼出元画面からのバインド値
	 * @param comp 呼出元のフィールドオブジェクト
	 */
	public void valueInitWithMode(MCRow bind, Object comp) {
		getRsltL().clear();
		if (comp instanceof MCTextField) {
			MCTextField t = (MCTextField)comp;
			if (t.getLabelByLocale() != null) {
				columnRslt_in_value.setHeaderName(t.getLabelByLocale());
			}
			else{
				columnRslt_in_value.setHeaderName(t.getMessageByLocale());
			}
			columnRslt_in_value.setLength(t.getLength());
			
			_inputCol = t.getRowColumnName();
			
			String[] vs = MCStringUtil.arrayValueSplit(
					bind.getStringNE($INPUT_VAL));
			for (String v : vs) {
				RsltR r = RsltR.create();
				r.in_value(v);
				getRsltL().add(r);
			}
			
		}
		if (comp instanceof MCTextComboBox) {
			MCTextComboBox t = (MCTextComboBox)comp;
			if (t.getLabelByLocale() != null) {
				columnRslt_in_value.setHeaderName(t.getLabelByLocale());
			}
			else{
				columnRslt_in_value.setHeaderName(t.getMessageByLocale());
			}
			columnRslt_in_value.setLength(t.getLength());

			//コンボのListPutterを正とする。
			MCListConfig lcf = t.getListConfig(); 
			if (getISListPutter() != lcf.getListPutter()) {
				getISListPutter().setColumns(
						lcf.getListPutter().getColumns());
			}
			_inputCol = t.getListNames()[0];

			MCList<?> tm = t.doListEvent(MCListConfig.LIST);
			if (tm != null && tm.size() >= 0) {
				if (t.getListType() == MCListType.FREE) {
					setCOMB_FStatus();
				}
				else{
					setCOMB_SStatus();
				}
				
				String[] vs = MCStringUtil.arrayValueSplit(
						bind.getStringNE($INPUT_VAL));
				
				if (t.getListNames().length > 0) {
					String[] vc = t.getListVisibleColumn();
					if (vc == null) {
						vc = t.getListNames();					
					}

					for (MCRow r : tm) {
						RsltR ar = RsltR.create();
						ar.in_value(r.getStringNE(_inputCol));
						Object o = lcf.format(t, r ,vc);
						if (o != null) {
							ar.view_value(o.toString());
						}
						for (String c : lcf.getListPutter().getColumns()) {
							ar.setValueNE(c, r.getValueNE(c));
						}
						getRsltL().add(ar);
					}
					for (int i = 0; i < vs.length; i++) {
						boolean f = false;
						for (int j = 0; j < getRsltL().size(); j++) {
							if (vs[i] != null && vs[i].equals(
									getRsltL().get(j).in_value())) {
								getRsltL().get(j).select(true);
								f = true;
								break;
							}
						} 
						if (!f && t.getListType() == MCListType.FREE) {
							RsltR r = RsltR.create();
							r.in_value(vs[i]);
							r.select(true);
							getRsltL().add(r);
						}
					}
				}
				
				
				
			}
		}
		RsltTable.adjustAllWidth();
		RsltTable.fillSpace();

		if (getStatus().equals(INIT)) {
			RsltTable.focusCellAt(0, columnRslt_in_value);
		}
		else{
			RsltTable.focusCellAt(0, columnRslt_select);
		}
	}
	@Override
	protected String getCheckColumnName() {
		if (isCheckColumnTarget()) {
			return columnRslt_select.getBaseTableColumnName();
		}
		//チェックカラムの存在を加味した動作をさせないようにする
		return null;
	}
	
	private boolean isCheckColumnTarget() {
		return getStatus().equals(COMB_F) ||getStatus().equals(COMB_S);
	}
	
	@Override
	public MCList getAcceptList(MCLinkBeans target, boolean isDCEvent) {
		MCList ls = getRsltL();
		if (isCheckColumnTarget()) {
			ls = super.getAcceptList(target, isDCEvent);
		}
		//新規追加対象にデータを追加
		ls = ls.subList(
				new MCRowMatcher() {
					@Override
					public boolean match(MCRow row) {
						return (!row.isEmpty(RsltR.$in_value));
					}});
		for (int i = 0; i < ls.size(); i++) {
			MCRow r = ls.get(i);
			if (r.getValueNE(_inputCol) == null) {
				r.setValueNE(_inputCol, r.getStringNE(RsltR.$in_value));
			}
			else{
				if (!r.getValueNE(_inputCol).equals(
						r.getStringNE(RsltR.$in_value))){
					String t = r.getStringNE(RsltR.$in_value);
					r.clear();
					r.setValueNE(_inputCol, t);
				}
			}
		}
		//チェックがない場合
		//入力値がない場合でもnull値で確定させる
		if (!isCheckColumnTarget() && ls.size() == 0) {
			ls.add(ls.createRow());
		}
		return ls;
	}
	
	@Override
	public void valueInit() {
		super.valueInit();
		if (_bind != null && _comp != null) {
			valueInitWithMode(_bind, _comp);
		}
	}
	
	@Override
	public void setOpenFocus() {
		super.setOpenFocus();
		if (getStatus().equals(INIT)) {
			RsltTable.focusCellAt(0, columnRslt_in_value);
		}
		else{
			RsltTable.focusCellAt(0, columnRslt_select);
		}
	}
	
	@Override
	public void doDCAccept(MCEventInfo info) {
		super.doDCAccept(info);
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		if (beans == RsltTable) {
			return new PopupConfig();
		}
		return super.createFXBAP_PopupConfig(beans);
	}

	/**
	 * カスタマイズ用のPopupConfigクラスです。<P>
	 */
	public class PopupConfig extends FXBAP_PopupConfig {
		
		/**
		 * 
		 * コンストラクタです。
		 */
		public PopupConfig() {
			super();
		}
		
		@Override
		protected boolean ignoreColumnWidth() {
			return true;
		}

		@Override
		protected boolean ignoreSortOrder() {
			return true;
		}

		@Override
		protected boolean ignoreSumInfo() {
			return true;
		}
		
		@Override
		protected boolean ignoreRowFilter() {
			return true;
		}
		
	}

	/**
	 * 文字列からNOT LIKE 検索のキーワードおよびエスケープを除去する。
	 * 呼出元のフィールドオブジェクトが複数値入力可かどうかで処理する。
	 * 
	 * @param compo コンポーネント
	 * @param value 文字列
	 * @return 処理後の文字列
	 */
	public String removeNotLikeString(MCBeans compo, String value) {
		return super.removeNotLikeString((MCBeans)_comp, value);
	}

	/**
	 * 複数値入力補助画面かどうかを返す。
	 * 
	 * @return true(有効)
	 */
	public boolean isInPluralValue() {
		return true;
	}
}