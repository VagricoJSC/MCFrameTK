package mcframe.clientFXUC.FXUCP0050;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FXUCP_FindCell"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXUCP_FindCell_FW_A extends mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXUC";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXUCP0050";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	public MCTitledBorder CndTitledBorder = null;
	// [Cnd]ブロックの項目のField定義
	/**
	 *  データ種別.<p>
	 *
	 */
	public MCButtonGroup Cnd_data_typ_Group = null;
	public MCRadioButton Cnd_data_typ_STR = null;
	public MCRadioButton Cnd_data_typ_NUM = null;
	public MCRadioButton Cnd_data_typ_DATE = null;
	/**
	 *  検索条件.<p>
	 *
	 */
	public MCLabel Cnd_cndLbl = null;
	/**
	 *  検索条件.<p>
	 *
	 */
	public MCTextField Cnd_str = null;
	/**
	 *  検索条件.<p>
	 *
	 */
	public MCNumberField Cnd_num = null;
	/**
	 *  検索条件.<p>
	 *
	 */
	public MCDateField Cnd_date = null;
	/**
	 * operator 検索条件種別.<p>
	 *
	 */
	public MCButtonGroup Cnd_ope_Group = null;
	public MCRadioButton Cnd_ope_EQ = null;
	public MCRadioButton Cnd_ope_gte = null;
	public MCRadioButton Cnd_ope_lte = null;
	/**
	 *  全て検索.<p>
	 *
	 */
	public MCButton Cnd_srch_all = null;
	/**
	 *  前検索.<p>
	 *
	 */
	public MCButton Cnd_srch_prev = null;
	/**
	 *  次検索.<p>
	 *
	 */
	public MCButton Cnd_srch_next = null;
	// [Rslt]ブロック関連のField定義
	public MCPanel RsltPanel = null;
	public MCScrollPane RsltScrollPane = null;
	public MCTable2<mcframe.clientFXUC.FXUCP0050.RsltR> RsltTable = null;
	// [Rslt]ブロックの項目のField定義
	/**
	 *  行.<p>
	 *
	 */
	public MCColumnConfig columnRslt_lno = null;
	/**
	 *  カラム名.<p>
	 *
	 */
	public MCColumnConfig columnRslt_col_lbl = null;
	/**
	 *  値(文字).<p>
	 *
	 */
	public MCColumnConfig columnRslt_str_val = null;
	/**
	 *  値(数).<p>
	 *
	 */
	public MCColumnConfig columnRslt_num_val = null;
	/**
	 *  値(日付).<p>
	 *
	 */
	public MCColumnConfig columnRslt_date_val = null;
	// [Opt]ブロック関連のField定義
	public MCPanel OptPanel = null;
	public MCTitledBorder OptTitledBorder = null;
	// [Opt]ブロックの項目のField定義
	/**
	 * is_visible_row_only 表示している行のみ検索.<p>
	 *
	 */
	public MCCheckBox Opt_is_vis_row_only = null;
	/**
	 * is_selection_column_only 選択しているセルの列のみ検索.<p>
	 *
	 */
	public MCCheckBox Opt_is_sel_col_only = null;
	/**
	 *  大文字小文字を区別しない.<p>
	 *
	 */
	public MCCheckBox Opt_is_ignore_case = null;
	/**
	 *  部分一致.<p>
	 *
	 */
	public MCCheckBox Opt_is_substring = null;
	/**
	 *  ワイルドカードを使用.<p>
	 *
	 */
	public MCCheckBox Opt_is_pattern_matching = null;
	/** [STR]モードを表す定数 */
	public static final String STR = "STR";
	/** [NUM]モードを表す定数 */
	public static final String NUM = "NUM";
	/** [DATE]モードを表す定数 */
	public static final String DATE = "DATE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{STR, NUM, DATE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFXUC.FXUCP0050.CndR aCndR;
	/** [Rslt]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXUC.FXUCP0050.RsltR> aRsltL;
	/** [Opt]ブロックのコンテナField定義 */
	private final mcframe.clientFXUC.FXUCP0050.OptR aOptR;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFXUC.FXUCP0050.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFXUC.FXUCP0050.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFXUC.FXUCP0050.CndR createCndR() {
		return mcframe.clientFXUC.FXUCP0050.CndR.create();
	}

	/**
	 * コピーによってaRsltLを設定します。
	 *
	 * aRsltLのインスタンスは変更されません。
	 *
	 * @param dataset RsltL
	 */
	public void setRsltL(MCList<mcframe.clientFXUC.FXUCP0050.RsltR> aList) {
		if (getRsltL() != aList) {
			getRsltL().setAll(aList);
		}
	}

	/**
	 * [Rslt]ブロックのコンテナaRsltLを返します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0050.RsltR> getRsltL() {
		return aRsltL;
	}

	/**
	 * aRsltRを作成します。
	 *
	 * @return RsltR
	 */
	public mcframe.clientFXUC.FXUCP0050.RsltR createRsltR() {
		return mcframe.clientFXUC.FXUCP0050.RsltR.create();
	}

	/**
	 * aRsltLを作成します。
	 *
	 * @return RsltL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0050.RsltR> createRsltL() {
		return MCList.create(mcframe.clientFXUC.FXUCP0050.RsltR.class);
	}

	/**
	 * RsltTableを初期化します。
	 */
	protected void createRsltTable(){
		if(RsltTable == null){
			RsltTable = beansFactory.createTable2("Rslt.table");
		}
	}

	/**
	 * 項目コピーによってaOptRを設定します。
	 *
	 * aOptRのインスタンスは変更されません。
	 *
	 * @param row OptR
	 */
	public void setOptR(mcframe.clientFXUC.FXUCP0050.OptR row) {
		if (row != null) {
			MCRow.copyall(getOptR(), row);
		}
	}

	/**
	 * [Opt]ブロックのコンテナaOptRを返します。
	 *
	 * @return OptR
	 */
	public mcframe.clientFXUC.FXUCP0050.OptR getOptR() {
		return aOptR;
	}

	/**
	 * aOptRを作成します。
	 *
	 * @return OptR
	 */
	public mcframe.clientFXUC.FXUCP0050.OptR createOptR() {
		return mcframe.clientFXUC.FXUCP0050.OptR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getRsltL())) ret.add(getRsltL());
		if(!MCCollectionUtil.contains(ret, getOptR())) ret.add(getOptR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getRsltL()) return "Rslt";
		if(aCnt == getOptR()) return "Opt";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("Rslt")) return getRsltL();
		if(bId.equals("Opt")) return getOptR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(RsltPanel);
		ret.add(OptPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_FindCell_FW_A() {
		aCndR = createCndR();
		aRsltL = createRsltL();
		aOptR = createOptR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXUCP_FindCell_FW_A(String name) {
		aCndR = createCndR();
		aRsltL = createRsltL();
		createRsltTable();
		RsltTable.setRowName(name);
		aOptR = createOptR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXUCP_FindCell_FW.jbCreateCnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbCreateRslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbCreateOpt((FXUCP_FindCell)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FXUCP_FindCell p) {
	}

	/**
	 * [Rslt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateRslt(FXUCP_FindCell p) {
	}

	/**
	 * [Opt]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateOpt(FXUCP_FindCell p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_FindCell create(){
		FXUCP_FindCell p = new FXUCP_FindCell();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXUCP_FindCell create(String name){
		FXUCP_FindCell p = new FXUCP_FindCell(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXUCP_FindCell_FW.jbfInitCnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbfInitRslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbfInitOpt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbInitCnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbInitRslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.jbInitOpt((FXUCP_FindCell)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FXUCP_FindCell p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		p.CndTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Cnd_data_typ_Group = p.beansFactory.createButtonGroup("Cnd.data_typ");
		p.Cnd_data_typ_STR = p.beansFactory.createRadioButton("Cnd.data_typ_STR");
		p.Cnd_data_typ_NUM = p.beansFactory.createRadioButton("Cnd.data_typ_NUM");
		p.Cnd_data_typ_DATE = p.beansFactory.createRadioButton("Cnd.data_typ_DATE");
		p.Cnd_cndLbl = p.beansFactory.createLabel("Cnd.cndLbl");
		p.Cnd_str = p.beansFactory.createTextField("Cnd.str");
		p.Cnd_num = p.beansFactory.createNumberField("Cnd.num");
		p.Cnd_date = p.beansFactory.createDateField("Cnd.date");
		p.Cnd_ope_Group = p.beansFactory.createButtonGroup("Cnd.ope");
		p.Cnd_ope_EQ = p.beansFactory.createRadioButton("Cnd.ope_EQ");
		p.Cnd_ope_gte = p.beansFactory.createRadioButton("Cnd.ope_gte");
		p.Cnd_ope_lte = p.beansFactory.createRadioButton("Cnd.ope_lte");
		p.Cnd_srch_all = p.beansFactory.createButton("Cnd.srch_all");
		p.Cnd_srch_prev = p.beansFactory.createButton("Cnd.srch_prev");
		p.Cnd_srch_next = p.beansFactory.createButton("Cnd.srch_next");
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitRslt(FXUCP_FindCell p) {
		// ブロック関連の初期化
		p.RsltPanel = p.beansFactory.createPanel("Rslt");
		p.RsltScrollPane = p.beansFactory.createScrollPane("Rslt.scroll");
		p.createRsltTable();
		// ブロックの項目の初期化
		p.columnRslt_lno = p.beansFactory.createTableColumn("Rslt.lno", MCColumnType.NUMBER);
		p.columnRslt_col_lbl = p.beansFactory.createTableColumn("Rslt.col_lbl", MCColumnType.TEXT);
		p.columnRslt_str_val = p.beansFactory.createTableColumn("Rslt.str_val", MCColumnType.TEXT);
		p.columnRslt_num_val = p.beansFactory.createTableColumn("Rslt.num_val", MCColumnType.NUMBER);
		p.columnRslt_date_val = p.beansFactory.createTableColumn("Rslt.date_val", MCColumnType.DATE);
	}

	/**
	 * [Opt]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitOpt(FXUCP_FindCell p) {
		// ブロック関連の初期化
		p.OptPanel = p.beansFactory.createPanel("Opt");
		p.OptTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Opt_is_vis_row_only = p.beansFactory.createCheckBox("Opt.is_vis_row_only");
		p.Opt_is_sel_col_only = p.beansFactory.createCheckBox("Opt.is_sel_col_only");
		p.Opt_is_ignore_case = p.beansFactory.createCheckBox("Opt.is_ignore_case");
		p.Opt_is_substring = p.beansFactory.createCheckBox("Opt.is_substring");
		p.Opt_is_pattern_matching = p.beansFactory.createCheckBox("Opt.is_pattern_matching");
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FXUCP_FindCell p) {
		// ブロック関連の初期化
		p.CndPanel.setBorder(p.CndTitledBorder);
		p.add(p.CndPanel);
		p.setLastBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.RsltPanel);
		p.CndPanel.setValueCheck(false);
		p.CndPanel.setExtValue(MCPanel.SRCH_CND_SETTING_PANEL, true);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.CndPanel.setLastBeans(p.Cnd_data_typ_Group);
		p.Cnd_data_typ_Group.setFirstBeans(p.Cnd_data_typ_STR);
		p.Cnd_data_typ_STR.setActionCommand("0");
		p.Cnd_data_typ_Group.add(p.Cnd_data_typ_STR);
		p.CndPanel.add(p.Cnd_data_typ_STR);
		p.Cnd_data_typ_STR.setNextBeans(p.Cnd_data_typ_NUM);
		p.Cnd_data_typ_NUM.setActionCommand("1");
		p.Cnd_data_typ_Group.add(p.Cnd_data_typ_NUM);
		p.CndPanel.add(p.Cnd_data_typ_NUM);
		p.Cnd_data_typ_NUM.setNextBeans(p.Cnd_data_typ_DATE);
		p.Cnd_data_typ_DATE.setActionCommand("2");
		p.Cnd_data_typ_Group.add(p.Cnd_data_typ_DATE);
		p.CndPanel.add(p.Cnd_data_typ_DATE);
		p.Cnd_data_typ_Group.setRow(p.getCndR(), mcframe.clientFXUC.FXUCP0050.CndR.data_typ_META);
		p.Cnd_data_typ_Group.setNextBeans(p.Cnd_str);
		p.CndPanel.add(p.Cnd_cndLbl);
		p.CndPanel.add(p.Cnd_str);
		p.Cnd_str.setNextBeans(p.Cnd_num);
		p.Cnd_str.setRow(p.getCndR(), mcframe.clientFXUC.FXUCP0050.CndR.str_META);
		p.CndPanel.add(p.Cnd_num);
		p.Cnd_num.setNextBeans(p.Cnd_date);
		p.Cnd_num.setRow(p.getCndR(), mcframe.clientFXUC.FXUCP0050.CndR.num_META);
		p.CndPanel.add(p.Cnd_date);
		p.Cnd_date.setNextBeans(p.Cnd_ope_Group);
		p.Cnd_date.setRow(p.getCndR(), mcframe.clientFXUC.FXUCP0050.CndR.date_META);
		p.Cnd_date.setFormatID("YMD");
		p.Cnd_ope_Group.setFirstBeans(p.Cnd_ope_EQ);
		p.Cnd_ope_EQ.setActionCommand("0");
		p.Cnd_ope_Group.add(p.Cnd_ope_EQ);
		p.CndPanel.add(p.Cnd_ope_EQ);
		p.Cnd_ope_EQ.setNextBeans(p.Cnd_ope_gte);
		p.Cnd_ope_gte.setActionCommand("1");
		p.Cnd_ope_Group.add(p.Cnd_ope_gte);
		p.CndPanel.add(p.Cnd_ope_gte);
		p.Cnd_ope_gte.setNextBeans(p.Cnd_ope_lte);
		p.Cnd_ope_lte.setActionCommand("2");
		p.Cnd_ope_Group.add(p.Cnd_ope_lte);
		p.CndPanel.add(p.Cnd_ope_lte);
		p.Cnd_ope_Group.setRow(p.getCndR(), mcframe.clientFXUC.FXUCP0050.CndR.ope_META);
		p.Cnd_ope_Group.setNextBeans(p.Cnd_srch_all);
		p.Cnd_srch_all.setFunctionKey(MCFunctionKey.F1);
		p.CndPanel.add(p.Cnd_srch_all);
		p.Cnd_srch_all.setNextBeans(p.Cnd_srch_prev);
		p.Cnd_srch_prev.setFunctionKey(MCFunctionKey.F5);
		p.CndPanel.add(p.Cnd_srch_prev);
		p.Cnd_srch_prev.setNextBeans(p.Cnd_srch_next);
		p.Cnd_srch_next.setFunctionKey(MCFunctionKey.F6);
		p.CndPanel.add(p.Cnd_srch_next);
	}

	/**
	 * [Rslt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitRslt(FXUCP_FindCell p) {
		// ブロック関連の初期化
		p.add(p.RsltPanel);
		p.RsltPanel.setNextBeans(p.OptPanel);
		p.RsltPanel.add(p.RsltScrollPane);
		p.RsltPanel.setLastBeans(p.RsltTable);
		p.RsltScrollPane.setViewportView(p.RsltTable);
		p.RsltTable.setList(p.getRsltL());
		p.RsltPanel.setValueCheck(false);
		p.RsltPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Opt]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitOpt(FXUCP_FindCell p) {
		// ブロック関連の初期化
		p.OptPanel.setBorder(p.OptTitledBorder);
		p.add(p.OptPanel);
		p.OptPanel.setValueCheck(false);
		p.OptPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.OptPanel.add(p.Opt_is_vis_row_only);
		p.OptPanel.setLastBeans(p.Opt_is_vis_row_only);
		p.Opt_is_vis_row_only.setNextBeans(p.Opt_is_sel_col_only);
		p.Opt_is_vis_row_only.setRow(p.getOptR(), mcframe.clientFXUC.FXUCP0050.OptR.is_vis_row_only_META);
		p.OptPanel.add(p.Opt_is_sel_col_only);
		p.Opt_is_sel_col_only.setNextBeans(p.Opt_is_ignore_case);
		p.Opt_is_sel_col_only.setRow(p.getOptR(), mcframe.clientFXUC.FXUCP0050.OptR.is_sel_col_only_META);
		p.OptPanel.add(p.Opt_is_ignore_case);
		p.Opt_is_ignore_case.setNextBeans(p.Opt_is_substring);
		p.Opt_is_ignore_case.setRow(p.getOptR(), mcframe.clientFXUC.FXUCP0050.OptR.is_ignore_case_META);
		p.OptPanel.add(p.Opt_is_substring);
		p.Opt_is_substring.setNextBeans(p.Opt_is_pattern_matching);
		p.Opt_is_substring.setRow(p.getOptR(), mcframe.clientFXUC.FXUCP0050.OptR.is_substring_META);
		p.OptPanel.add(p.Opt_is_pattern_matching);
		p.Opt_is_pattern_matching.setRow(p.getOptR(), mcframe.clientFXUC.FXUCP0050.OptR.is_pattern_matching_META);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXUCP_FindCell_FW.mcInitCnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.mcInitRslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.mcInitOpt((FXUCP_FindCell)this);

		// [STR]ステータスのモードの設定
		FXUCP_FindCell_FW.statusInitSTR_Cnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.statusInitSTR_Rslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.statusInitSTR_Opt((FXUCP_FindCell)this);

		// [NUM]ステータスのモードの設定
		FXUCP_FindCell_FW.statusInitNUM_Cnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.statusInitNUM_Rslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.statusInitNUM_Opt((FXUCP_FindCell)this);

		// [DATE]ステータスのモードの設定
		FXUCP_FindCell_FW.statusInitDATE_Cnd((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.statusInitDATE_Rslt((FXUCP_FindCell)this);
		FXUCP_FindCell_FW.statusInitDATE_Opt((FXUCP_FindCell)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FXUCP_FindCell p) {
		p.Cnd_data_typ_Group.addAllListener(p);
		p.Cnd_data_typ_STR.addAllListener(p);
		p.Cnd_data_typ_NUM.addAllListener(p);
		p.Cnd_data_typ_DATE.addAllListener(p);
		p.Cnd_str.setListListener(p);
		p.Cnd_str.addAllListener(p);
		p.Cnd_num.setListListener(p);
		p.Cnd_num.addAllListener(p);
		p.Cnd_date.setListListener(p);
		p.Cnd_date.addAllListener(p);
		p.Cnd_ope_Group.addAllListener(p);
		p.Cnd_ope_EQ.addAllListener(p);
		p.Cnd_ope_gte.addAllListener(p);
		p.Cnd_ope_lte.addAllListener(p);
		p.Cnd_srch_all.addAllListener(p);
		p.Cnd_srch_all.setAPMethodName("doCnd_srch_all");
		p.Cnd_srch_prev.addAllListener(p);
		p.Cnd_srch_prev.setAPMethodName("doCnd_srch_prev");
		p.Cnd_srch_next.addAllListener(p);
		p.Cnd_srch_next.setAPMethodName("doCnd_srch_next");
	}

	/**
	 *  [Rslt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitRslt(FXUCP_FindCell p) {
		p.RsltTable.addAllListener(p);
		p.columnRslt_lno.addAllListener(p);
		p.columnRslt_lno.setListListener(p);
		p.columnRslt_col_lbl.addAllListener(p);
		p.columnRslt_col_lbl.setListListener(p);
		p.columnRslt_str_val.addAllListener(p);
		p.columnRslt_str_val.setListListener(p);
		p.columnRslt_num_val.addAllListener(p);
		p.columnRslt_num_val.setListListener(p);
		p.columnRslt_date_val.addAllListener(p);
		p.columnRslt_date_val.setListListener(p);
	}

	/**
	 *  [Opt]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitOpt(FXUCP_FindCell p) {
		p.Opt_is_vis_row_only.addAllListener(p);
		p.Opt_is_sel_col_only.addAllListener(p);
		p.Opt_is_ignore_case.addAllListener(p);
		p.Opt_is_substring.addAllListener(p);
		p.Opt_is_pattern_matching.addAllListener(p);
	}

	/**
	 * [STR]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitSTR_Cnd(FXUCP_FindCell p){
		p.Cnd_data_typ_Group.putMode(p, STR, MCMode.REQUIRED);
		p.Cnd_cndLbl.putMode(p, STR, MCMode.REQUIRED);
		p.Cnd_str.putMode(p, STR, MCMode.REQUIRED);
		p.Cnd_num.putMode(p, STR, MCMode.DISABLE);
		p.Cnd_date.putMode(p, STR, MCMode.DISABLE);
		p.Cnd_ope_Group.putMode(p, STR, MCMode.REQUIRED);
		p.Cnd_srch_all.putMode(p, STR, MCMode.ENABLE);
		p.Cnd_srch_prev.putMode(p, STR, MCMode.ENABLE);
		p.Cnd_srch_next.putMode(p, STR, MCMode.ENABLE);

	}

	/**
	 * [STR]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitSTR_Rslt(FXUCP_FindCell p){
		p.columnRslt_lno.putMode(p, STR, MCMode.READ_ONLY);
		p.columnRslt_col_lbl.putMode(p, STR, MCMode.READ_ONLY);
		p.columnRslt_str_val.putMode(p, STR, MCMode.READ_ONLY);
		p.columnRslt_num_val.putMode(p, STR, MCMode.INVISIBLE);
		p.columnRslt_date_val.putMode(p, STR, MCMode.INVISIBLE);

	}

	/**
	 * [STR]ステータスの[Opt]ブロックのモードの設定
	 */
	protected static void statusInitSTR_Opt(FXUCP_FindCell p){
		p.Opt_is_vis_row_only.putMode(p, STR, MCMode.REQUIRED);
		p.Opt_is_sel_col_only.putMode(p, STR, MCMode.REQUIRED);
		p.Opt_is_ignore_case.putMode(p, STR, MCMode.REQUIRED);
		p.Opt_is_substring.putMode(p, STR, MCMode.REQUIRED);
		p.Opt_is_pattern_matching.putMode(p, STR, MCMode.REQUIRED);

	}

	/**
	 * [NUM]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitNUM_Cnd(FXUCP_FindCell p){
		p.Cnd_data_typ_Group.putMode(p, NUM, MCMode.REQUIRED);
		p.Cnd_cndLbl.putMode(p, NUM, MCMode.REQUIRED);
		p.Cnd_str.putMode(p, NUM, MCMode.DISABLE);
		p.Cnd_num.putMode(p, NUM, MCMode.REQUIRED);
		p.Cnd_date.putMode(p, NUM, MCMode.DISABLE);
		p.Cnd_ope_Group.putMode(p, NUM, MCMode.REQUIRED);
		p.Cnd_srch_all.putMode(p, NUM, MCMode.ENABLE);
		p.Cnd_srch_prev.putMode(p, NUM, MCMode.ENABLE);
		p.Cnd_srch_next.putMode(p, NUM, MCMode.ENABLE);

	}

	/**
	 * [NUM]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitNUM_Rslt(FXUCP_FindCell p){
		p.columnRslt_lno.putMode(p, NUM, MCMode.READ_ONLY);
		p.columnRslt_col_lbl.putMode(p, NUM, MCMode.READ_ONLY);
		p.columnRslt_str_val.putMode(p, NUM, MCMode.INVISIBLE);
		p.columnRslt_num_val.putMode(p, NUM, MCMode.READ_ONLY);
		p.columnRslt_date_val.putMode(p, NUM, MCMode.INVISIBLE);

	}

	/**
	 * [NUM]ステータスの[Opt]ブロックのモードの設定
	 */
	protected static void statusInitNUM_Opt(FXUCP_FindCell p){
		p.Opt_is_vis_row_only.putMode(p, NUM, MCMode.REQUIRED);
		p.Opt_is_sel_col_only.putMode(p, NUM, MCMode.REQUIRED);
		p.Opt_is_ignore_case.putMode(p, NUM, MCMode.DISABLE);
		p.Opt_is_substring.putMode(p, NUM, MCMode.DISABLE);
		p.Opt_is_pattern_matching.putMode(p, NUM, MCMode.DISABLE);

	}

	/**
	 * [DATE]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitDATE_Cnd(FXUCP_FindCell p){
		p.Cnd_data_typ_Group.putMode(p, DATE, MCMode.REQUIRED);
		p.Cnd_cndLbl.putMode(p, DATE, MCMode.REQUIRED);
		p.Cnd_str.putMode(p, DATE, MCMode.DISABLE);
		p.Cnd_num.putMode(p, DATE, MCMode.DISABLE);
		p.Cnd_date.putMode(p, DATE, MCMode.REQUIRED);
		p.Cnd_ope_Group.putMode(p, DATE, MCMode.REQUIRED);
		p.Cnd_srch_all.putMode(p, DATE, MCMode.ENABLE);
		p.Cnd_srch_prev.putMode(p, DATE, MCMode.ENABLE);
		p.Cnd_srch_next.putMode(p, DATE, MCMode.ENABLE);

	}

	/**
	 * [DATE]ステータスの[Rslt]ブロックのモードの設定
	 */
	protected static void statusInitDATE_Rslt(FXUCP_FindCell p){
		p.columnRslt_lno.putMode(p, DATE, MCMode.READ_ONLY);
		p.columnRslt_col_lbl.putMode(p, DATE, MCMode.READ_ONLY);
		p.columnRslt_str_val.putMode(p, DATE, MCMode.INVISIBLE);
		p.columnRslt_num_val.putMode(p, DATE, MCMode.INVISIBLE);
		p.columnRslt_date_val.putMode(p, DATE, MCMode.READ_ONLY);

	}

	/**
	 * [DATE]ステータスの[Opt]ブロックのモードの設定
	 */
	protected static void statusInitDATE_Opt(FXUCP_FindCell p){
		p.Opt_is_vis_row_only.putMode(p, DATE, MCMode.REQUIRED);
		p.Opt_is_sel_col_only.putMode(p, DATE, MCMode.REQUIRED);
		p.Opt_is_ignore_case.putMode(p, DATE, MCMode.DISABLE);
		p.Opt_is_substring.putMode(p, DATE, MCMode.DISABLE);
		p.Opt_is_pattern_matching.putMode(p, DATE, MCMode.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return STR;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FXUCP_FindCell_FW.setTableConfigRslt((FXUCP_FindCell)this);
	}

	/**
	 * [Rslt]ブロックのTableの設定
	 */
	protected static void setTableConfigRslt(FXUCP_FindCell p) {
		p.columnRslt_lno.setMeta(mcframe.clientFXUC.FXUCP0050.RsltR.lno_META);
		p.RsltTable.addColumnConfig(p.columnRslt_lno);
		p.columnRslt_col_lbl.setMeta(mcframe.clientFXUC.FXUCP0050.RsltR.col_lbl_META);
		p.RsltTable.addColumnConfig(p.columnRslt_col_lbl);
		p.columnRslt_str_val.setMeta(mcframe.clientFXUC.FXUCP0050.RsltR.str_val_META);
		p.RsltTable.addColumnConfig(p.columnRslt_str_val);
		p.columnRslt_num_val.setMeta(mcframe.clientFXUC.FXUCP0050.RsltR.num_val_META);
		p.RsltTable.addColumnConfig(p.columnRslt_num_val);
		p.columnRslt_date_val.setMeta(mcframe.clientFXUC.FXUCP0050.RsltR.date_val_META);
		p.columnRslt_date_val.setFormatID("YMD");
		p.RsltTable.addColumnConfig(p.columnRslt_date_val);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[STR]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setSTRStatus() {
		status = STR;
		setAllStatus(status);
	}

	/**
	 * この画面を[NUM]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setNUMStatus() {
		status = NUM;
		setAllStatus(status);
	}

	/**
	 * この画面を[DATE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDATEStatus() {
		status = DATE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (STR.equals(status)) {
			setSTRStatus();
		}
		else if (NUM.equals(status)) {
			setNUMStatus();
		}
		else if (DATE.equals(status)) {
			setDATEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Cnd_srch_all) doCnd_srch_all(info);
		else if (ap == Cnd_srch_prev) doCnd_srch_prev(info);
		else if (ap == Cnd_srch_next) doCnd_srch_next(info);
	}

	/**
	 * [Cnd]パネルの[srch_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCnd_srch_all(MCEventInfo info);

	/**
	 * [Cnd]パネルの[srch_prev]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCnd_srch_prev(MCEventInfo info);

	/**
	 * [Cnd]パネルの[srch_next]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCnd_srch_next(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == RsltTable) return doRslt_VC(info);
		if (vc == Cnd_data_typ_Group) return doCnd_data_typ_VC(info);
		if (vc == Cnd_str) return doCnd_str_VC(info);
		if (vc == Cnd_num) return doCnd_num_VC(info);
		if (vc == Cnd_date) return doCnd_date_VC(info);
		if (vc == Cnd_ope_Group) return doCnd_ope_VC(info);
		if (vc == columnRslt_lno) return doRslt_lno_VC(info);
		if (vc == columnRslt_col_lbl) return doRslt_col_lbl_VC(info);
		if (vc == columnRslt_str_val) return doRslt_str_val_VC(info);
		if (vc == columnRslt_num_val) return doRslt_num_val_VC(info);
		if (vc == columnRslt_date_val) return doRslt_date_val_VC(info);
		if (vc == Opt_is_vis_row_only) return doOpt_is_vis_row_only_VC(info);
		if (vc == Opt_is_sel_col_only) return doOpt_is_sel_col_only_VC(info);
		if (vc == Opt_is_ignore_case) return doOpt_is_ignore_case_VC(info);
		if (vc == Opt_is_substring) return doOpt_is_substring_VC(info);
		if (vc == Opt_is_pattern_matching) return doOpt_is_pattern_matching_VC(info);
		return true;
	}

	/**
	 * [Rslt]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[data_typ]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_data_typ_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[str]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_str_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[num]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_num_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[date]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_date_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[ope]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_ope_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[lno]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_lno_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[col_lbl]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_col_lbl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[str_val]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_str_val_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[num_val]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_num_val_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Rslt]パネルの[date_val]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doRslt_date_val_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Opt]パネルの[is_vis_row_only]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doOpt_is_vis_row_only_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Opt]パネルの[is_sel_col_only]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doOpt_is_sel_col_only_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Opt]パネルの[is_ignore_case]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doOpt_is_ignore_case_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Opt]パネルの[is_substring]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doOpt_is_substring_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Opt]パネルの[is_pattern_matching]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doOpt_is_pattern_matching_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == RsltTable) doRslt_NC(info);
		else if (nc == Cnd_data_typ_Group) doCnd_data_typ_NC(info);
		else if (nc == Cnd_str) doCnd_str_NC(info);
		else if (nc == Cnd_num) doCnd_num_NC(info);
		else if (nc == Cnd_date) doCnd_date_NC(info);
		else if (nc == Cnd_ope_Group) doCnd_ope_NC(info);
		else if (nc == columnRslt_lno) doRslt_lno_NC(info);
		else if (nc == columnRslt_col_lbl) doRslt_col_lbl_NC(info);
		else if (nc == columnRslt_str_val) doRslt_str_val_NC(info);
		else if (nc == columnRslt_num_val) doRslt_num_val_NC(info);
		else if (nc == columnRslt_date_val) doRslt_date_val_NC(info);
		else if (nc == Opt_is_vis_row_only) doOpt_is_vis_row_only_NC(info);
		else if (nc == Opt_is_sel_col_only) doOpt_is_sel_col_only_NC(info);
		else if (nc == Opt_is_ignore_case) doOpt_is_ignore_case_NC(info);
		else if (nc == Opt_is_substring) doOpt_is_substring_NC(info);
		else if (nc == Opt_is_pattern_matching) doOpt_is_pattern_matching_NC(info);
	}

	/**
	 * [Rslt]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[data_typ]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_data_typ_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[str]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_str_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[num]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_num_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[date]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_date_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[ope]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_ope_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[lno]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_lno_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[col_lbl]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_col_lbl_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[str_val]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_str_val_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[num_val]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_num_val_NC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[date_val]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_date_val_NC(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_vis_row_only]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_vis_row_only_NC(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_sel_col_only]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_sel_col_only_NC(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_ignore_case]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_ignore_case_NC(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_substring]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_substring_NC(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_pattern_matching]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_pattern_matching_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == RsltTable) doRslt_NE(info);
		else if (ne == Cnd_data_typ_Group) doCnd_data_typ_NE(info);
		else if (ne == Cnd_str) doCnd_str_NE(info);
		else if (ne == Cnd_num) doCnd_num_NE(info);
		else if (ne == Cnd_date) doCnd_date_NE(info);
		else if (ne == Cnd_ope_Group) doCnd_ope_NE(info);
		else if (ne == columnRslt_lno) doRslt_lno_NE(info);
		else if (ne == columnRslt_col_lbl) doRslt_col_lbl_NE(info);
		else if (ne == columnRslt_str_val) doRslt_str_val_NE(info);
		else if (ne == columnRslt_num_val) doRslt_num_val_NE(info);
		else if (ne == columnRslt_date_val) doRslt_date_val_NE(info);
		else if (ne == Opt_is_vis_row_only) doOpt_is_vis_row_only_NE(info);
		else if (ne == Opt_is_sel_col_only) doOpt_is_sel_col_only_NE(info);
		else if (ne == Opt_is_ignore_case) doOpt_is_ignore_case_NE(info);
		else if (ne == Opt_is_substring) doOpt_is_substring_NE(info);
		else if (ne == Opt_is_pattern_matching) doOpt_is_pattern_matching_NE(info);
	}

	/**
	 * [Rslt]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[data_typ]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_data_typ_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[str]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_str_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[num]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_num_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[date]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_date_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[ope]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_ope_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[lno]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_lno_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[col_lbl]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_col_lbl_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[str_val]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_str_val_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[num_val]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_num_val_NE(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[date_val]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_date_val_NE(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_vis_row_only]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_vis_row_only_NE(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_sel_col_only]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_sel_col_only_NE(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_ignore_case]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_ignore_case_NE(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_substring]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_substring_NE(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_pattern_matching]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_pattern_matching_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == RsltTable) doRslt_NX(info);
		else if (nx == Cnd_data_typ_Group) doCnd_data_typ_NX(info);
		else if (nx == Cnd_str) doCnd_str_NX(info);
		else if (nx == Cnd_num) doCnd_num_NX(info);
		else if (nx == Cnd_date) doCnd_date_NX(info);
		else if (nx == Cnd_ope_Group) doCnd_ope_NX(info);
		else if (nx == columnRslt_lno) doRslt_lno_NX(info);
		else if (nx == columnRslt_col_lbl) doRslt_col_lbl_NX(info);
		else if (nx == columnRslt_str_val) doRslt_str_val_NX(info);
		else if (nx == columnRslt_num_val) doRslt_num_val_NX(info);
		else if (nx == columnRslt_date_val) doRslt_date_val_NX(info);
		else if (nx == Opt_is_vis_row_only) doOpt_is_vis_row_only_NX(info);
		else if (nx == Opt_is_sel_col_only) doOpt_is_sel_col_only_NX(info);
		else if (nx == Opt_is_ignore_case) doOpt_is_ignore_case_NX(info);
		else if (nx == Opt_is_substring) doOpt_is_substring_NX(info);
		else if (nx == Opt_is_pattern_matching) doOpt_is_pattern_matching_NX(info);
	}

	/**
	 * [Rslt]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[data_typ]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_data_typ_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[str]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_str_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[num]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_num_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[date]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_date_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[ope]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_ope_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[lno]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_lno_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[col_lbl]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_col_lbl_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[str_val]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_str_val_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[num_val]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_num_val_NX(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[date_val]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_date_val_NX(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_vis_row_only]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_vis_row_only_NX(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_sel_col_only]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_sel_col_only_NX(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_ignore_case]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_ignore_case_NX(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_substring]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_substring_NX(MCEventInfo info){
	}

	/**
	 * [Opt]パネルの[is_pattern_matching]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doOpt_is_pattern_matching_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_str) doCnd_str_LC(info);
		else if (lc == Cnd_num) doCnd_num_LC(info);
		else if (lc == Cnd_date) doCnd_date_LC(info);
		else if (lc == columnRslt_lno) doRslt_lno_LC(info);
		else if (lc == columnRslt_col_lbl) doRslt_col_lbl_LC(info);
		else if (lc == columnRslt_str_val) doRslt_str_val_LC(info);
		else if (lc == columnRslt_num_val) doRslt_num_val_LC(info);
		else if (lc == columnRslt_date_val) doRslt_date_val_LC(info);
	}

	/**
	 * [Cnd]パネルの[str]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_str_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[num]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_num_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[date]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_date_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[lno]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_lno_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[col_lbl]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_col_lbl_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[str_val]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_str_val_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[num_val]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_num_val_LC(MCEventInfo info){
	}

	/**
	 * [Rslt]パネルの[date_val]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doRslt_date_val_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}