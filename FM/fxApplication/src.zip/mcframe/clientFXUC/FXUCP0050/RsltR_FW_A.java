package mcframe.clientFXUC.FXUCP0050;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Rslt"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class RsltR_FW_A extends MCConstRow {

	/**
	 *  行.<p>
	 *
	 */
	public static final String $lno = "lno";
	/**
	 *  カラム名.<p>
	 *
	 */
	public static final String $col_lbl = "col_lbl";
	/**
	 *  値(文字).<p>
	 *
	 */
	public static final String $str_val = "str_val";
	/**
	 *  値(数).<p>
	 *
	 */
	public static final String $num_val = "num_val";
	/**
	 *  値(日付).<p>
	 *
	 */
	public static final String $date_val = "date_val";


	public static final MCMeta lno_META = createNumberMeta($lno);
	public static final MCMeta col_lbl_META = createStringMeta($col_lbl);
	public static final MCMeta str_val_META = createStringMeta($str_val);
	public static final MCMeta num_val_META = createNumberMeta($num_val);
	public static final MCMeta date_val_META = createDateMeta($date_val);

	protected static final ConstMetaList<RsltR> constMetas = new ConstMetaList<RsltR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			lno_META,
			col_lbl_META,
			str_val_META,
			num_val_META,
			date_val_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected RsltR_FW_A(ConstMetaList<? extends RsltR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR clone() {
		return (RsltR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR createInstance() {
		return (RsltR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public RsltR getValues(String... names) {
		return (RsltR) super.getValues(names);
	}



	/**
	 *  行.<p>
	 *
	 */
	public MCNumber lno() {
		return getConstNumber(offset + 0, $lno);
	}

	/**
	 *  行.<p>
	 *
	 */
	public void lno(MCNumber value) {
		setConstNumber(offset + 0, $lno, value);
	}

	/**
	 *  行.<p>
	 *
	 */
	public void lno(int value) {
		setConstNumber(offset + 0, $lno, value);
	}

	/**
	 *  行.<p>
	 *
	 */
	public void lno(long value) {
		setConstNumber(offset + 0, $lno, value);
	}

	/**
	 *  行.<p>
	 *
	 */
	public void lno(float value) {
		setConstNumber(offset + 0, $lno, value);
	}

	/**
	 *  行.<p>
	 *
	 */
	public void lno(double value) {
		setConstNumber(offset + 0, $lno, value);
	}


	/**
	 *  カラム名.<p>
	 *
	 */
	public String col_lbl() {
		return getConstString(offset + 1, $col_lbl);
	}

	/**
	 *  カラム名.<p>
	 *
	 */
	public void col_lbl(String value) {
		setConstString(offset + 1, $col_lbl, value);
	}


	/**
	 *  値(文字).<p>
	 *
	 */
	public String str_val() {
		return getConstString(offset + 2, $str_val);
	}

	/**
	 *  値(文字).<p>
	 *
	 */
	public void str_val(String value) {
		setConstString(offset + 2, $str_val, value);
	}


	/**
	 *  値(数).<p>
	 *
	 */
	public MCNumber num_val() {
		return getConstNumber(offset + 3, $num_val);
	}

	/**
	 *  値(数).<p>
	 *
	 */
	public void num_val(MCNumber value) {
		setConstNumber(offset + 3, $num_val, value);
	}

	/**
	 *  値(数).<p>
	 *
	 */
	public void num_val(int value) {
		setConstNumber(offset + 3, $num_val, value);
	}

	/**
	 *  値(数).<p>
	 *
	 */
	public void num_val(long value) {
		setConstNumber(offset + 3, $num_val, value);
	}

	/**
	 *  値(数).<p>
	 *
	 */
	public void num_val(float value) {
		setConstNumber(offset + 3, $num_val, value);
	}

	/**
	 *  値(数).<p>
	 *
	 */
	public void num_val(double value) {
		setConstNumber(offset + 3, $num_val, value);
	}


	/**
	 *  値(日付).<p>
	 *
	 */
	public MCDate date_val() {
		return getConstDate(offset + 4, $date_val);
	}

	/**
	 *  値(日付).<p>
	 *
	 */
	public void date_val(MCDate value) {
		setConstDate(offset + 4, $date_val, value);
	}


	public String getString(String name) {
		if ($col_lbl.equalsIgnoreCase(name)) {
			return col_lbl();
		}
		if ($str_val.equalsIgnoreCase(name)) {
			return str_val();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($lno.equalsIgnoreCase(name)) {
			return lno();
		}
		if ($num_val.equalsIgnoreCase(name)) {
			return num_val();
		}
		return super.getNumber(name);
	}
	public MCDate getDate(String name) {
		if ($date_val.equalsIgnoreCase(name)) {
			return date_val();
		}
		return super.getDate(name);
	}

	public String getStringNE(String name) {
		if ($col_lbl.equalsIgnoreCase(name)) {
			return col_lbl();
		}
		if ($str_val.equalsIgnoreCase(name)) {
			return str_val();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($lno.equalsIgnoreCase(name)) {
			return lno();
		}
		if ($num_val.equalsIgnoreCase(name)) {
			return num_val();
		}
		return super.getNumberNE(name);
	}
	public MCDate getDateNE(String name) {
		if ($date_val.equalsIgnoreCase(name)) {
			return date_val();
		}
		return super.getDateNE(name);
	}

	public void setString(String name, String value) {
		if ($col_lbl.equalsIgnoreCase(name)) {
			col_lbl(value);
			return;
		}
		if ($str_val.equalsIgnoreCase(name)) {
			str_val(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setDate(String name, MCDate value) {
		if ($date_val.equalsIgnoreCase(name)) {
			date_val(value);
			return;
		}
		super.setDate(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($col_lbl.equalsIgnoreCase(name)) {
			col_lbl(value);
			return;
		}
		if ($str_val.equalsIgnoreCase(name)) {
			str_val(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($lno.equalsIgnoreCase(name)) {
			lno(value);
			return;
		}
		if ($num_val.equalsIgnoreCase(name)) {
			num_val(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setDateNE(String name, MCDate value) {
		if ($date_val.equalsIgnoreCase(name)) {
			date_val(value);
			return;
		}
		super.setDateNE(name, value);
	}



}

