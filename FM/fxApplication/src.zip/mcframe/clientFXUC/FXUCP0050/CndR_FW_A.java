package mcframe.clientFXUC.FXUCP0050;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cnd"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CndR_FW_A extends MCConstRow {

	/**
	 *  データ種別.<p>
	 *
	 */
	public static final String $data_typ = "data_typ";
	/**
	 *  検索条件.<p>
	 *
	 */
	public static final String $str = "str";
	/**
	 *  検索条件.<p>
	 *
	 */
	public static final String $num = "num";
	/**
	 *  検索条件.<p>
	 *
	 */
	public static final String $date = "date";
	/**
	 * operator 検索条件種別.<p>
	 *
	 */
	public static final String $ope = "ope";


	public static final MCMeta data_typ_META = createStringMeta($data_typ);
	public static final MCMeta str_META = createStringMeta($str);
	public static final MCMeta num_META = createNumberMeta($num);
	public static final MCMeta date_META = createDateMeta($date);
	public static final MCMeta ope_META = createStringMeta($ope);

	protected static final ConstMetaList<CndR> constMetas = new ConstMetaList<CndR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			data_typ_META,
			str_META,
			num_META,
			date_META,
			ope_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CndR_FW_A(ConstMetaList<? extends CndR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR clone() {
		return (CndR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR createInstance() {
		return (CndR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR getValues(String... names) {
		return (CndR) super.getValues(names);
	}



	/**
	 *  データ種別.<p>
	 *
	 */
	public String data_typ() {
		return getConstString(offset + 0, $data_typ);
	}

	/**
	 *  データ種別.<p>
	 *
	 */
	public void data_typ(String value) {
		setConstString(offset + 0, $data_typ, value);
	}


	/**
	 *  検索条件.<p>
	 *
	 */
	public String str() {
		return getConstString(offset + 1, $str);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void str(String value) {
		setConstString(offset + 1, $str, value);
	}


	/**
	 *  検索条件.<p>
	 *
	 */
	public MCNumber num() {
		return getConstNumber(offset + 2, $num);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void num(MCNumber value) {
		setConstNumber(offset + 2, $num, value);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void num(int value) {
		setConstNumber(offset + 2, $num, value);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void num(long value) {
		setConstNumber(offset + 2, $num, value);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void num(float value) {
		setConstNumber(offset + 2, $num, value);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void num(double value) {
		setConstNumber(offset + 2, $num, value);
	}


	/**
	 *  検索条件.<p>
	 *
	 */
	public MCDate date() {
		return getConstDate(offset + 3, $date);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void date(MCDate value) {
		setConstDate(offset + 3, $date, value);
	}


	/**
	 * operator 検索条件種別.<p>
	 *
	 */
	public String ope() {
		return getConstString(offset + 4, $ope);
	}

	/**
	 * operator 検索条件種別.<p>
	 *
	 */
	public void ope(String value) {
		setConstString(offset + 4, $ope, value);
	}


	public String getString(String name) {
		if ($data_typ.equalsIgnoreCase(name)) {
			return data_typ();
		}
		if ($str.equalsIgnoreCase(name)) {
			return str();
		}
		if ($ope.equalsIgnoreCase(name)) {
			return ope();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumber(name);
	}
	public MCDate getDate(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getDate(name);
	}

	public String getStringNE(String name) {
		if ($data_typ.equalsIgnoreCase(name)) {
			return data_typ();
		}
		if ($str.equalsIgnoreCase(name)) {
			return str();
		}
		if ($ope.equalsIgnoreCase(name)) {
			return ope();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($num.equalsIgnoreCase(name)) {
			return num();
		}
		return super.getNumberNE(name);
	}
	public MCDate getDateNE(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getDateNE(name);
	}

	public void setString(String name, String value) {
		if ($data_typ.equalsIgnoreCase(name)) {
			data_typ(value);
			return;
		}
		if ($str.equalsIgnoreCase(name)) {
			str(value);
			return;
		}
		if ($ope.equalsIgnoreCase(name)) {
			ope(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setDate(String name, MCDate value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setDate(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($data_typ.equalsIgnoreCase(name)) {
			data_typ(value);
			return;
		}
		if ($str.equalsIgnoreCase(name)) {
			str(value);
			return;
		}
		if ($ope.equalsIgnoreCase(name)) {
			ope(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($num.equalsIgnoreCase(name)) {
			num(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setDateNE(String name, MCDate value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setDateNE(name, value);
	}



}

