package mcframe.clientFXUC.FXUCP0050;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import mcframe.clientCore.beans.popup.MCPopupBeans;

import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_FindCell"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_FindCell_FW extends FXUCP_FindCell_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_FindCell_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXUCP_FindCell_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	// 目次
	// 共通
	// 画面の動き
	// 検索の共通部品
	// 検索のマッチャー
	// 検索のメッセージ関連
	// 検索の実処理
	// 検索の検索対象を探す処理

	// 共通（ここから）
	/** 検索モード：「次へ」をあらわす定数（SEARCH_MODE_FORWARD） */
	protected static final String SEARCH_MODE_FW = "F";

	/** 検索モード：「前へ」をあらわす定数（SEARCH_MODE_BACKWARD） */
	protected static final String SEARCH_MODE_BK = "B";

	/** 検索モード：「全て」をあらわす定数 */
	protected static final String SEARCH_MODE_ALL = "A";

	/** 検索モードを取得する */
	protected String _searchMode;

	/** 検索対象のテーブル */
	protected MCTable<?> _targetTable;
	
	/** 
	 * 検索対象のリスト<p>
	 * 検索処理開始時に設定する。
	 * 検索処理終了時に null にする。
	 */
	protected MCList _targetList;
	
	/** 検索結果を一時的に格納するためのリスト */
	protected MCList<RsltR> _tmpRslt = createRsltL();

	// 共通（ここまで）
	// 画面の動き（ここから）
	@Override
	protected void setSortColumn() {
		RsltTable.addSortColumn(columnRslt_lno, MCList.SortType.ASC);
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		FXBAP_PopupConfig conf = super.createFXBAP_PopupConfig(beans);
		if (beans == RsltTable) {
			conf.ignoreFindCell(true);
		}
		return conf;
	}

	/** 簡易キャッシュ */
	protected static CndR _cacheCndRow;

	protected static OptR _cacheOptRow;

	@Override
	public boolean beforeClose() {
		boolean ans = super.beforeClose();
		if (ans) {
			saveCache();
		}
		return ans;
	}

	@Override
	public boolean beforeOpen() {
		boolean ret = super.beforeOpen();
		if (!ret) return ret;
		
		getFrame().setParentPanelEnable(true);
//		MCFrame mcf = getFrame();
//		if (mcf instanceof MCInternalFrame) {
//			MCInternalFrame f = (MCInternalFrame) mcf;
//			f.setLayer(1);
//		}
		return true;
	}

	/** 検索条件をキャッシュします。 */
	protected void saveCache() {
		if (_cacheCndRow == null) {
			_cacheCndRow = createCndR();
		}
		if (_cacheOptRow == null) {
			_cacheOptRow = createOptR();
		}
		MCRow.copyall(_cacheCndRow, getCndR());
		MCRow.copyall(_cacheOptRow, getOptR());
	}

	/**
	 * <li>起動タイプ：T1<br>
	 * バインド値 ：なし<br>
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * </table> <br>
	 * その他の引数： <table border = 1>
	 * <tr>
	 * <th>順番</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>0</td>
	 * <td>MCTable</td>
	 * <td>検索対象のテーブル</td>
	 * </tr>
	 * </table> <br>
	 * </li>
	 */
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);
		if (T1 == openTyp) {
			if (args != null && args.length > 0 && args[0] instanceof MCTable) {
				_targetTable = (MCTable<?>) args[0];
				valueInit();
				if (_cacheCndRow == null) {
					// 何もしない
				}
				else {
					MCRow.copyvalue(getCndR(), _cacheCndRow);
					if (isSame(Cnd_data_typ_STR.getActionCommand(), getCndR().data_typ())) {
						setSTRStatus();
					}
					else if (isSame(Cnd_data_typ_NUM.getActionCommand(), getCndR()
							.data_typ())) {
						setNUMStatus();
					}
					else if (isSame(Cnd_data_typ_DATE.getActionCommand(), getCndR()
							.data_typ())) {
						setDATEStatus();
					}
				}
				if (_cacheOptRow == null) {
					getOptR().is_vis_row_only(true);
					getOptR().is_ignore_case(true);
					getOptR().is_pattern_matching(true);
					getOptR().is_substring(true);
				}
				else {
					MCRow.copyvalue(getOptR(), _cacheOptRow);
				}

			}
			else {
				throw new MCAppException(msgUnknownOpenParam());
			}
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		
		getOptR().is_vis_row_only(true);
		getOptR().is_ignore_case(true);
		getOptR().is_pattern_matching(true);
		getOptR().is_substring(true);
	}
	
	@Override
	public void setSTRStatus() {
		super.setSTRStatus();
		Cnd_ope_gte.setMode(MCMode.DISABLE);
		Cnd_ope_lte.setMode(MCMode.DISABLE);
		getCndR().ope(Cnd_ope_EQ.getActionCommand());
		Cnd_str.mcRequestFocus();
	}

	@Override
	public void setDATEStatus() {
		super.setDATEStatus();
		Cnd_date.mcRequestFocus();
	}

	@Override
	public void setNUMStatus() {
		super.setNUMStatus();
		Cnd_num.mcRequestFocus();
	}

	/**
	 * Panel[Cnd]のボタン[srch_prev]の押下時の処理
	 */
	@Override
	public void doCnd_srch_prev(MCEventInfo info) {
		_searchMode = SEARCH_MODE_BK;
		doSearch();
	}

	/**
	 * Panel[Cnd]のボタン[srch_next]の押下時の処理
	 */
	@Override
	public void doCnd_srch_next(MCEventInfo info) {
		_searchMode = SEARCH_MODE_FW;
		doSearch();
	}

	/**
	 * Panel[Cnd]のボタン[srch_all]の押下時の処理
	 */
	@Override
	public void doCnd_srch_all(MCEventInfo info) {
		_searchMode = SEARCH_MODE_ALL;
		clearRsltRToColumn();
		clearRsltRToTargerRow();
		doSearch();
	}

	@Override
	public void doCnd_data_typ_NC(MCEventInfo info) {
		super.doCnd_data_typ_NC(info);
		if (isSame(info.getNewValue(), Cnd_data_typ_STR.getActionCommand())) {
			setSTRStatus();
		}
		else if (isSame(info.getNewValue(), Cnd_data_typ_NUM.getActionCommand())) {
			setNUMStatus();
		}
		else if (isSame(info.getNewValue(), Cnd_data_typ_DATE.getActionCommand())) {
			setDATEStatus();
		}
	}

	@Override
	public void doRslt_NC(MCEventInfo info) {
		super.doRslt_NC(info);
		RsltR r = RsltTable.getSelectedMCRow();
		if (r != null) {
			MCRow trow = getRsltRToTargetRow(r);
			MCColumnConfig tcolumn = getRsltRToColumn(r);
			MCTable<?> t = tcolumn.getBaseTable();
			if (t.getList().contains(trow)) {
				t.focusCellAt(trow.getGUIIndex(), tcolumn);
			}
		}
	}

	// 画面の動き（ここまで）
	// 検索の共通部品（ここから）
	/** 文字列を検索している時はtrue それ以外は false */
	protected boolean isStrSearch() {
		return Cnd_data_typ_STR.isSelected();
	}

	/** 数値を検索している時はtrue それ以外は false */
	protected boolean isNumSearch() {
		return Cnd_data_typ_NUM.isSelected();
	}

	/** 日付を検索している時はtrue それ以外は false */
	protected boolean isDateSearch() {
		return Cnd_data_typ_DATE.isSelected();
	}

	protected boolean isPatternMatching() {
		return getOptR().is_pattern_matching();
	}

	protected boolean isOpeEq() {
		return Cnd_ope_EQ.isSelected();
	}

	protected boolean isOpeLte() {
		return Cnd_ope_lte.isSelected();
	}

	protected boolean isOpeGte() {
		return Cnd_ope_gte.isSelected();
	}

	/**
	 * 選択しているカラムのみ検索
	 * 
	 * @return
	 */
	protected boolean isSelColOnly() {
		return getOptR().is_sel_col_only();
	}

	/** 大文字小文字を無視する */
	protected boolean isIgnoreCase() {
		return getOptR().is_ignore_case();
	}

	/** 部分一致 */
	protected boolean isSubString() {
		return getOptR().is_substring();
	}

	protected boolean isForward() {
		return _searchMode == SEARCH_MODE_FW;
	}

	protected boolean isBackward() {
		return _searchMode == SEARCH_MODE_BK;
	}

	protected boolean isSearchAll() {
		return _searchMode == SEARCH_MODE_ALL;
	}

	protected int[] _cell = new int[2];

	protected static int ROW_IDX = 0;

	protected static int COL_IDX = 1;

	/** searchAll の時の検索結果のRowとcolumnConfigとを紐づけるための情報 */
	protected Map<RsltR, MCColumnConfig> _rowToColumn;

	/** searchAll の時の検索結果のRowとtargetのRowとを紐づけるための情報 */
	Map<RsltR, MCRow/*TargetRow*/> _rsltToTargetRow = new HashMap<RsltR, MCRow>();
	
	/** searchAll の時の検索結果のRowからcolumnConfigを取得する */
	protected MCColumnConfig getRsltRToColumn(RsltR row) {
		return _rowToColumn.get(row);
	}

	/** searchAll の時の検索結果のRowとcolumnConfigの紐づき情報を保存 */
	protected void addRsltRToColumn(RsltR row, MCColumnConfig column) {
		_rowToColumn.put(row, column);
	}

	/**
	 * searchAll の時の検索結果のRowとcolumnConfigの紐づき情報をクリアし、<br>
	 * 新たな紐づき情報を保存できるようにする
	 */
	protected void clearRsltRToColumn() {
		if (_rowToColumn == null) {
			_rowToColumn = new HashMap<RsltR, MCColumnConfig>();
		}
		_rowToColumn.clear();
	}

	/** searchAll の時の検索結果のRowからtargetのrowを取得する */
	protected MCRow getRsltRToTargetRow(RsltR row) {
		return _rsltToTargetRow.get(row);
	}

	/** searchAll の時の検索結果のRowとtargetのrowの紐づき情報を保存 */
	protected void addRsltRToTargetRow(RsltR row, MCRow trow) {
		_rsltToTargetRow.put(row, trow);
	}

	/**
	 * searchAll の時の検索結果のRowとtargetのrowの紐づき情報をクリアし、<br>
	 * 新たな紐づき情報を保存できるようにする
	 */
	protected void clearRsltRToTargerRow() {
		if (_rsltToTargetRow == null) {
			_rsltToTargetRow = new HashMap<RsltR, MCRow>();
		}
		_rsltToTargetRow.clear();
	}
	
	/** 検索結果のクリア */
	protected void clearRslt() {
		_tmpRslt.clear();
		getRsltL().clear();
	}
	
	// 検索の共通部品（ここまで）
	// 検索のマッチャー（ここから）
	public abstract class Condition {
		/** 検索条件に合致している場合は true それ以外はflase */
		abstract public boolean match(Comparable<?> data);
	}

	/**
	 * 数値・等しい
	 */
	public class NumberEQ extends Condition {
		protected MCNumber _operand;

		public NumberEQ() {
			_operand = Cnd_num.getValue();
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof MCNumber) {
				return _operand.compareTo((MCNumber) data) == 0;
			}
			return false;
		}
	}

	/**
	 * 数値・以下
	 */
	public class NumberLTE extends Condition {
		protected MCNumber _operand;

		public NumberLTE() {
			_operand = Cnd_num.getValue();
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof MCNumber) {
				return _operand.compareTo((MCNumber) data) >= 0;
			}
			return false;
		}
	}

	/**
	 * 数値・以上
	 */
	public class NumberGTE extends Condition {
		protected MCNumber _operand;

		public NumberGTE() {
			_operand = Cnd_num.getValue();
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof MCNumber) {
				return _operand.compareTo((MCNumber) data) <= 0;
			}
			return false;
		}
	}

	/**
	 * 日付・等しい
	 */
	public class DateEQ extends Condition {
		protected MCDate _operand;

		public DateEQ() {
			_operand = Cnd_date.getValue();
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			return _operand.equals(data);
		}
	}

	/**
	 * 日付・以下
	 */
	public class DateLTE extends Condition {
		protected MCDate _operand;

		public DateLTE() {
			_operand = Cnd_date.getValue();
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof MCCalendarDate) {
				return ((MCCalendarDate<?>) data).lte(_operand);
			}
			return false;
		}
	}

	/**
	 * 日付・以上
	 */
	public class DateGTE extends Condition {
		protected MCDate _operand;

		public DateGTE() {
			_operand = Cnd_date.getValue();
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof MCCalendarDate) {
				return ((MCCalendarDate<?>) data).gte(_operand);
			}
			return false;
		}
	}

	/**
	 * 文字列・等しい（大文字小文字を加味）
	 */
	public class StringEQ extends Condition {
		protected String _cond;

		/**
		 * {@link FXUCP_FindCell}用
		 * @param cond
		 */
		public StringEQ() {
			this(getCndR().str(), isPatternMatching(), isSubString());
		}

		/**
		 * 外部から使う用のコンストラクタ
		 * @param cond 条件節
		 * @param isPatternMatching 曖昧検索をする場合true（＝条件節内の [%][_] をワイルドカードとみなす場合true）
		 * @param isSubString 検索対象の文字列に条件節が含まれているものを検索する場合true。
		 */
		public StringEQ(String cond, boolean isPatternMatching, boolean isSubString) {
			_cond = cond;
			_isPatternMatching = isPatternMatching;
			_isSubString = isSubString;
		}

		protected String _operand;

		protected String operand() {
			if (_operand == null) {
				_operand = toRegex(_cond);
			}
			return _operand;
		}

		/**
		 *  曖昧検索をするかどうか。
		 *  曖昧検索する場合 true それ以外 false
		 */
		protected boolean _isPatternMatching = false;

		/**
		 *  部分一致検索をするかどうか。
		 *  部分一致検索する場合 true それ以外 false
		 */
		protected boolean _isSubString = false;

		protected String toRegex(String str) {
			String ans = str;
			// 正規表現の文字列を回避
			String[][] escStrArr = new String[][] {
				{
						"\\\\E", "\\\\E\\\\\\\\E\\\\Q"
				}
			};
			for (String[] e : escStrArr) {
				ans = ans.replaceAll(e[0], e[1]);
			}
			// 曖昧検索対応
			if (_isPatternMatching) {
				String[][] replaceArray = new String[][] {
						{
								"%", "\\\\E.*\\\\Q"
						}, {
								"_", "\\\\E.\\\\Q"
						}
				};
				for (String[] e : replaceArray) {
					ans = ans.replaceAll(e[0], e[1]);
				}

			}
			ans = "\\Q" + ans + "\\E";
			// 部分一致
			if (_isSubString) {
				ans = ".*" + ans + ".*";
			}
			return ans;
		}

		/** 検索条件に合致している場合は true それ以外はfalse */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof String) {
				String str = (String) data;
				Pattern p = Pattern.compile(operand(), Pattern.DOTALL);
				Matcher m = p.matcher(str);
				return m.matches();
			}
			return false;
		}
	}

	/**
	 * 文字列・等しい（大文字小文字を区別しない）
	 */
	public class StringEQIgnoreCase extends StringEQ {

		public StringEQIgnoreCase() {
			super();
		}

		public StringEQIgnoreCase(String cond, boolean isPatternMatching,
				boolean isSubString) {
			super(cond, isPatternMatching, isSubString);
		}

		@Override
		protected String toRegex(String str) {
			return super.toRegex(str.toLowerCase());
		}

		/** 検索条件に合致している場合は true それ以外はflase */
		@Override
		public boolean match(Comparable<?> data) {
			if (data instanceof String) {
				return super.match(((String) data).toLowerCase());
			}
			return false;
		}
	}

	// 検索のマッチャー（ここまで）

	// 検索のメッセージ関連（ここから）
	protected void notFoundMsg() {
		dialog(FXUCP0020);
	}

	// 検索のメッセージ関連（ここまで）

	// 検索の実処理（ここから）

	protected void doSearch() {
		clearRslt();
		setTargetList();
		
		if (getTargetList().size() <= 0) {
			dialog(FXUCP0021);
			return;
		}
		MCMessageList msgList = checkReq(getCndR());
		if (msgList.size() > 0) {
			dialog(msgList.get(0));
			notFoundForcus();
			return;
		}
		MCColumnConfig[] columns = getTargetColumns(); // 対象のデータタイプのカラムのみになっている
		if (columns.length <= 0) {
			notFound();
			return;
		}
		int[] cell = getFirstTargetCell(columns);
		Condition matcher = getCondition();

		boolean isFound = false;
		while (true) {
			if (cell == null) {
				break;
			}
			if (cell[ROW_IDX] < 0) {
				cell = endOrNext(cell[ROW_IDX], cell[COL_IDX], columns, false);
			}
			else if (matcher.match(columns[cell[COL_IDX]].getValue(cell[ROW_IDX]))) {
				cell = endOrNext(cell[ROW_IDX], cell[COL_IDX], columns, true);
				isFound = true;
			}
			else {
				cell = endOrNext(cell[ROW_IDX], cell[COL_IDX], columns, false);
			}
		}

		// 検索結果をセットする
		setRsltL(_tmpRslt);
		
		if (!getRsltL().isEmpty()) {
			sort(RsltTable);
			RsltTable.adjustWidth();
			RsltTable.selectRowNoFocus(0);
		}

		if (isFound == false) {
			notFound();

		}
		_targetTable.repaint();
	}

	/**
	 * 検索対象のリストを設定します。
	 * セル検索の対象となるテーブルのリストを {@link #_targetList} に設定します。<p>
	 * 「表示している行のみ検索」がチェックされている場合は、
	 * 表示されていない行（高さが 0 の行）以外の行を設定します。
	 */
	protected void setTargetList() {
		if (getOptR().is_vis_row_only()) {
			MCList l = _targetTable.getList();
			_targetList = l.createInstance();
			for (MCRow o : l.toArray()) {
				if (_targetTable.getRowHeight(o.getGUIIndex()) > 0) {
					_targetList.add(o);
				}
			}
		}
		else {
			_targetList = _targetTable.getList();
		}
	}

	/**
	 * 検索対象のリストを取得します。<p>
	 * 検索対象のリストが設定されていない場合は null を返します。
	 * 
	 * @return 検索対象のリスト、または null
	 */
	protected MCList getTargetList() {
		return _targetList;
	}
	
	/**
	 * 検索結果がなかった場合の処理
	 */
	protected void notFound() {
		notFoundMsg();
		notFoundForcus();
	}

	/**
	 * 検索結果が存在しない場合のフォーカス設定
	 */
	protected void notFoundForcus() {
		if (isNumSearch()) {
			Cnd_num.mcRequestFocus();
		}
		else if (isDateSearch()) {
			Cnd_date.mcRequestFocus();
		}
		else if (isStrSearch()) {
			Cnd_str.mcRequestFocus();
		}
	}

	/**
	 * マッチャーのファクトリメソッド
	 * 
	 * @return
	 */
	protected Condition getCondition() {
		Condition ans = null;
		if (isStrSearch()) {
			if (isIgnoreCase()) {
				ans = new StringEQIgnoreCase();
			}
			else {
				ans = new StringEQ();
			}
		}
		else if (isNumSearch()) {
			if (isOpeEq()) {
				ans = new NumberEQ();
			}
			else if (isOpeLte()) {
				ans = new NumberLTE();
			}
			else if (isOpeGte()) {
				ans = new NumberGTE();
			}
		}
		else if (isDateSearch()) {
			if (isOpeEq()) {
				ans = new DateEQ();
			}
			else if (isOpeLte()) {
				ans = new DateLTE();
			}
			else if (isOpeGte()) {
				ans = new DateGTE();
			}
		}

		return ans;
	}

	// 検索の実処理（ここまで）

	// 検索の検索対象を探す処理（ここから）

	/**
	 * 検索対象のカラムのみの配列を取得する
	 */
	protected MCColumnConfig[] getTargetColumns() {
		List<MCColumnConfig> list = new ArrayList<MCColumnConfig>();
		MCDataType dataType = null;
		if (isDateSearch()) {
			dataType = MCDataType.DATE;
		}
		else if (isStrSearch()) {
			dataType = MCDataType.STRING;
		}
		else if (isNumSearch()) {
			dataType = MCDataType.NUMBER;
		}

		MCColumnConfig[] allConfigs;

		if (isSelColOnly()) {
			allConfigs = new MCColumnConfig[1];
			allConfigs[0] = _targetTable.getSelectedColumnConfig();
			if (allConfigs[0] == null) {
				return new MCColumnConfig[0];
			}
		}
		else {
			allConfigs = _targetTable.getViewColumnConfigs();
		}

		for (MCColumnConfig conf : allConfigs) {
			if (dataType == conf.getDataType()) {
				if (conf.getColumnType() != MCColumnType.PASSWORD) {
					list.add(conf);
				}
			}
		}
		return list.toArray(new MCColumnConfig[0]);
	}

	/**
	 * 事前条件：_targetTable.size() > 0<br>
	 * 事前条件：configs.size() > 0<br>
	 * 
	 * @param configs
	 * @return 取得できない場合null。取得できた場合、0番目の要素 rowIndex 1番目の要素 columnIndex
	 */
	protected int[] getFirstTargetCell(MCColumnConfig[] configs) {
		_cell[ROW_IDX] = _targetTable.getMCSelectedRow();
		if (isSearchAll()) {
			_cell[COL_IDX] = 0;
			_cell[ROW_IDX] = getNextTargetRow(-1);
		}
		else {
			MCColumnConfig selectedColumn = _targetTable.getSelectedColumnConfig();
			_cell[COL_IDX] = -1;
			boolean isFound = false;
			for (MCColumnConfig c : _targetTable.getViewColumnConfigs()) {
				boolean isMatch = false;
				if (c == configs[_cell[COL_IDX] + 1]) {
					_cell[COL_IDX]++;
					isMatch = true;
				}
				if (c == selectedColumn) {
					if (isBackward()) {
						if (isMatch) {
							// 選択していたセルが目的のデータ型の時はそれの１つ前から検索し始める
							// （そうしないと「前検索」を連打した時に前に行かない）
							_cell[COL_IDX]--;
						}
						if (_cell[COL_IDX] < 0) {
							_cell[COL_IDX] = configs.length - 1;
							_cell[ROW_IDX] = getNextTargetRow(_cell[ROW_IDX]);
							if (_cell[ROW_IDX] < 0) {
								return null;
							}
						}
					}
					else if (isForward()) {
						_cell[COL_IDX]++;
						if (_cell[COL_IDX] >= configs.length) {
							_cell[COL_IDX] = 0;
							_cell[ROW_IDX] = getNextTargetRow(_cell[ROW_IDX]);
							if (_cell[ROW_IDX] < 0) {
								return null;
							}
						}
					}
					isFound = true;
					break;
				}
				else {
					if (configs.length <= _cell[COL_IDX] + 1) {
						// 対象のカラム（configs）を全て探したが、まだ現在
						// フォーカスがあるセルのカラムが出現しない場合
						isFound = isMatch;
						if (isBackward()) {
							// バックワードの場合は最後の対象のカラムが
							// 一番初めの検索対象
							break;
						}
						else if (isForward()) {
							// 次の行の先頭のカラム
							_cell[COL_IDX] = 0;
							
							_cell[ROW_IDX] = getNextTargetRow(_cell[ROW_IDX]);
							if (_cell[ROW_IDX] < 0) {
								return null;
							}
							break;
						}
						else {
							// 本来ありえないはず
							break;
						}

					}
				}
			}
			if (isFound == false) {
				return null;
			}
		}
		return _cell;
	}

	/**
	 * 終了する場合は、必要な処理をして終了する。
	 * 
	 * @param currentRowIdx
	 * @param currentColumnIdx
	 * @param configs
	 * @param isFound
	 * @return
	 */
	protected int[] endOrNext(int currentRowIdx, int currentColumnIdx,
			MCColumnConfig[] configs, boolean isFound) {
		int[] ans;
		if (isSearchAll()) {
			if (isFound) {
				MCColumnConfig column = configs[currentColumnIdx];
				RsltR row = createRsltR();
				row.lno(currentRowIdx + 1);
				row.col_lbl(column.getLabelByLocale());
				Comparable<?> val = column.getValue(currentRowIdx);
				if (val instanceof String) {
					row.str_val((String) val);
				}
				else if (val instanceof MCNumber) {
					row.num_val((MCNumber) val);
				}
				else if (val instanceof MCDate) {
					row.date_val((MCDate) val);
				}
				
				_tmpRslt.add(row);
				
				addRsltRToColumn(row, column);
				addRsltRToTargetRow(row, column.getBaseTable().getRow(currentRowIdx));
			}
			ans = getNextTargetCell(currentRowIdx, currentColumnIdx, configs);
		}
		else if (isBackward() || isForward()) {
			if (isFound) {
				_targetTable.focusCellAt(currentRowIdx, configs[currentColumnIdx]);
				ans = null;
			}
			else {
				ans = getNextTargetCell(currentRowIdx, currentColumnIdx, configs);
			}
		}
		else {
			ans = null;
		}
		return ans;
	}

	/**
	 * 事前条件：_targetTable.size() > 0<br>
	 * 事前条件：configs.size() > 0<br>
	 * 
	 * @param configs
	 * @return 取得できない場合null。取得できた場合、0番目の要素 rowIndex 1番目の要素 columnIndex
	 */
	protected int[] getNextTargetCell(int currentRowIdx, int currentColumnIdx,
			MCColumnConfig[] configs) {
		_cell[ROW_IDX] = currentRowIdx;
		_cell[COL_IDX] = currentColumnIdx;

		if (isSearchAll() || isForward()) {
			_cell[COL_IDX]++;
			if (_cell[COL_IDX] >= configs.length) {
				_cell[COL_IDX] = 0;
				
				_cell[ROW_IDX] = getNextTargetRow(_cell[ROW_IDX]);
				if (_cell[ROW_IDX] < 0) {
					return null;
				}
			}
		}
		else if (isBackward()) {
			_cell[COL_IDX]--;
			if (_cell[COL_IDX] < 0) {
				_cell[COL_IDX] = configs.length - 1;
				
				_cell[ROW_IDX] = getNextTargetRow(_cell[ROW_IDX]);
				if (_cell[ROW_IDX] < 0) {
					return null;
				}
			}
		}

		return _cell;
	}
	
	/**
	 * 次に検索する行の行位置を返します。<p>
	 * 検索の方向（押下したボタン）と検索範囲によって、返す行位置が異なります。<p>
	 * <ul>
	 * <li>全て検索、次検索の場合<br>
	 * 全て検索、次検索の場合は、下方向に探索します。<p>
	 * 「表示している行のみ検索」がチェックされている場合は、
	 * 表示されていない行（高さが 0 の行）を除外して下方向に探索します。
	 * 「表示している行のみ検索」がチェックされていない場合は、
	 * 行の高さに関係なく下方向に探索します。
	 * </li>
	 * <li>前検索の場合<br>
	 * 前検索の場合は、上方向に探索します。<p>
	 * 「表示している行のみ検索」がチェックされている場合は、
	 * 表示されていない行（高さが 0 の行）を除外して上方向に探索します。
	 * 「表示している行のみ検索」がチェックされていない場合は、
	 * 行の高さに関係なく上方向に探索します。
	 * </li>
	 * </ul><p>
	 * 次に検索する行が見つからなかった場合は -1 を返します。
	 * 
	 * @param index 基準となる行の行位置
	 * @return 次に検索する行の行位置、または -1
	 */
	protected int getNextTargetRow(int index) {
		if (isSearchAll() || isForward()) {
			index++;
			int x = _targetTable.getList().size();
			if (!getOptR().is_vis_row_only()) {
				if (index >= x) {
					return -1;
				}
				return index;
			}
			
			while (true) {
				if (index >= x) {
					return -1;
				}
				if (_targetTable.getRowHeight(index) > 0) {
					return index;
				}
				index++;
			}
		}
		else if (isBackward()) {
			index--;
			if (!getOptR().is_vis_row_only()) {
				return index;
			}
			
			while (true) {
				if (index < 0) {
					return -1;
				}
				if (_targetTable.getRowHeight(index) > 0) {
					return index;
				}
				index--;
			}
		}
		return index;
	}
	
	// 検索の検索対象を探す処理（ここまで）

}