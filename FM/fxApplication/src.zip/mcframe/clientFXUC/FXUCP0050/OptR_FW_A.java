package mcframe.clientFXUC.FXUCP0050;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Opt"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class OptR_FW_A extends MCConstRow {

	/**
	 * is_visible_row_only 表示している行のみ検索.<p>
	 *
	 */
	public static final String $is_vis_row_only = "is_vis_row_only";
	/**
	 * is_selection_column_only 選択しているセルの列のみ検索.<p>
	 *
	 */
	public static final String $is_sel_col_only = "is_sel_col_only";
	/**
	 *  大文字小文字を区別しない.<p>
	 *
	 */
	public static final String $is_ignore_case = "is_ignore_case";
	/**
	 *  部分一致.<p>
	 *
	 */
	public static final String $is_substring = "is_substring";
	/**
	 *  ワイルドカードを使用.<p>
	 *
	 */
	public static final String $is_pattern_matching = "is_pattern_matching";


	public static final MCMeta is_vis_row_only_META = createBooleanMeta($is_vis_row_only);
	public static final MCMeta is_sel_col_only_META = createBooleanMeta($is_sel_col_only);
	public static final MCMeta is_ignore_case_META = createBooleanMeta($is_ignore_case);
	public static final MCMeta is_substring_META = createBooleanMeta($is_substring);
	public static final MCMeta is_pattern_matching_META = createBooleanMeta($is_pattern_matching);

	protected static final ConstMetaList<OptR> constMetas = new ConstMetaList<OptR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			is_vis_row_only_META,
			is_sel_col_only_META,
			is_ignore_case_META,
			is_substring_META,
			is_pattern_matching_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected OptR_FW_A(ConstMetaList<? extends OptR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OptR clone() {
		return (OptR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OptR createInstance() {
		return (OptR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public OptR getValues(String... names) {
		return (OptR) super.getValues(names);
	}



	/**
	 * is_visible_row_only 表示している行のみ検索.<p>
	 *
	 */
	public boolean is_vis_row_only() {
		return getConstBoolean(offset + 0, $is_vis_row_only);
	}

	/**
	 * is_visible_row_only 表示している行のみ検索.<p>
	 *
	 */
	public void is_vis_row_only(boolean value) {
		setConstBoolean(offset + 0, $is_vis_row_only, value);
	}


	/**
	 * is_selection_column_only 選択しているセルの列のみ検索.<p>
	 *
	 */
	public boolean is_sel_col_only() {
		return getConstBoolean(offset + 1, $is_sel_col_only);
	}

	/**
	 * is_selection_column_only 選択しているセルの列のみ検索.<p>
	 *
	 */
	public void is_sel_col_only(boolean value) {
		setConstBoolean(offset + 1, $is_sel_col_only, value);
	}


	/**
	 *  大文字小文字を区別しない.<p>
	 *
	 */
	public boolean is_ignore_case() {
		return getConstBoolean(offset + 2, $is_ignore_case);
	}

	/**
	 *  大文字小文字を区別しない.<p>
	 *
	 */
	public void is_ignore_case(boolean value) {
		setConstBoolean(offset + 2, $is_ignore_case, value);
	}


	/**
	 *  部分一致.<p>
	 *
	 */
	public boolean is_substring() {
		return getConstBoolean(offset + 3, $is_substring);
	}

	/**
	 *  部分一致.<p>
	 *
	 */
	public void is_substring(boolean value) {
		setConstBoolean(offset + 3, $is_substring, value);
	}


	/**
	 *  ワイルドカードを使用.<p>
	 *
	 */
	public boolean is_pattern_matching() {
		return getConstBoolean(offset + 4, $is_pattern_matching);
	}

	/**
	 *  ワイルドカードを使用.<p>
	 *
	 */
	public void is_pattern_matching(boolean value) {
		setConstBoolean(offset + 4, $is_pattern_matching, value);
	}


	public boolean getBoolean(String name) {
		if ($is_vis_row_only.equalsIgnoreCase(name)) {
			return is_vis_row_only();
		}
		if ($is_sel_col_only.equalsIgnoreCase(name)) {
			return is_sel_col_only();
		}
		if ($is_ignore_case.equalsIgnoreCase(name)) {
			return is_ignore_case();
		}
		if ($is_substring.equalsIgnoreCase(name)) {
			return is_substring();
		}
		if ($is_pattern_matching.equalsIgnoreCase(name)) {
			return is_pattern_matching();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($is_vis_row_only.equalsIgnoreCase(name)) {
			return is_vis_row_only();
		}
		if ($is_sel_col_only.equalsIgnoreCase(name)) {
			return is_sel_col_only();
		}
		if ($is_ignore_case.equalsIgnoreCase(name)) {
			return is_ignore_case();
		}
		if ($is_substring.equalsIgnoreCase(name)) {
			return is_substring();
		}
		if ($is_pattern_matching.equalsIgnoreCase(name)) {
			return is_pattern_matching();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($is_vis_row_only.equalsIgnoreCase(name)) {
			is_vis_row_only(value);
			return;
		}
		if ($is_sel_col_only.equalsIgnoreCase(name)) {
			is_sel_col_only(value);
			return;
		}
		if ($is_ignore_case.equalsIgnoreCase(name)) {
			is_ignore_case(value);
			return;
		}
		if ($is_substring.equalsIgnoreCase(name)) {
			is_substring(value);
			return;
		}
		if ($is_pattern_matching.equalsIgnoreCase(name)) {
			is_pattern_matching(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($is_vis_row_only.equalsIgnoreCase(name)) {
			is_vis_row_only(value);
			return;
		}
		if ($is_sel_col_only.equalsIgnoreCase(name)) {
			is_sel_col_only(value);
			return;
		}
		if ($is_ignore_case.equalsIgnoreCase(name)) {
			is_ignore_case(value);
			return;
		}
		if ($is_substring.equalsIgnoreCase(name)) {
			is_substring(value);
			return;
		}
		if ($is_pattern_matching.equalsIgnoreCase(name)) {
			is_pattern_matching(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

