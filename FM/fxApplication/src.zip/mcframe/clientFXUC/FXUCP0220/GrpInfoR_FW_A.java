package mcframe.clientFXUC.FXUCP0220;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"GrpInfo"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class GrpInfoR_FW_A extends MCConstRow {

	public static final String $per_grp_id = "per_grp_id";
	public static final String $per_grp_nm = "per_grp_nm";
	public static final String $setting_unit_type = "setting_unit_type";
	public static final String $setting_unit_type_nm = "setting_unit_type_nm";
	public static final String $search_settings_id = "search_settings_id";
	public static final String $search_settings_nm = "search_settings_nm";
	public static final String $location_settings_id = "location_settings_id";
	public static final String $location_settings_nm = "location_settings_nm";
	public static final String $remark = "remark";


	public static final MCMeta per_grp_id_META = createStringMeta($per_grp_id);
	public static final MCMeta per_grp_nm_META = createStringMeta($per_grp_nm);
	public static final MCMeta setting_unit_type_META = createStringMeta($setting_unit_type);
	public static final MCMeta setting_unit_type_nm_META = createStringMeta($setting_unit_type_nm);
	public static final MCMeta search_settings_id_META = createStringMeta($search_settings_id);
	public static final MCMeta search_settings_nm_META = createStringMeta($search_settings_nm);
	public static final MCMeta location_settings_id_META = createStringMeta($location_settings_id);
	public static final MCMeta location_settings_nm_META = createStringMeta($location_settings_nm);
	public static final MCMeta remark_META = createStringMeta($remark);

	protected static final ConstMetaList<GrpInfoR> constMetas = new ConstMetaList<GrpInfoR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			per_grp_id_META,
			per_grp_nm_META,
			setting_unit_type_META,
			setting_unit_type_nm_META,
			search_settings_id_META,
			search_settings_nm_META,
			location_settings_id_META,
			location_settings_nm_META,
			remark_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected GrpInfoR_FW_A(ConstMetaList<? extends GrpInfoR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public GrpInfoR clone() {
		return (GrpInfoR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public GrpInfoR createInstance() {
		return (GrpInfoR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public GrpInfoR getValues(String... names) {
		return (GrpInfoR) super.getValues(names);
	}



	public String per_grp_id() {
		return getConstString(offset + 0, $per_grp_id);
	}

	public void per_grp_id(String value) {
		setConstString(offset + 0, $per_grp_id, value);
	}


	public String per_grp_nm() {
		return getConstString(offset + 1, $per_grp_nm);
	}

	public void per_grp_nm(String value) {
		setConstString(offset + 1, $per_grp_nm, value);
	}


	public String setting_unit_type() {
		return getConstString(offset + 2, $setting_unit_type);
	}

	public void setting_unit_type(String value) {
		setConstString(offset + 2, $setting_unit_type, value);
	}


	public String setting_unit_type_nm() {
		return getConstString(offset + 3, $setting_unit_type_nm);
	}

	public void setting_unit_type_nm(String value) {
		setConstString(offset + 3, $setting_unit_type_nm, value);
	}


	public String search_settings_id() {
		return getConstString(offset + 4, $search_settings_id);
	}

	public void search_settings_id(String value) {
		setConstString(offset + 4, $search_settings_id, value);
	}


	public String search_settings_nm() {
		return getConstString(offset + 5, $search_settings_nm);
	}

	public void search_settings_nm(String value) {
		setConstString(offset + 5, $search_settings_nm, value);
	}


	public String location_settings_id() {
		return getConstString(offset + 6, $location_settings_id);
	}

	public void location_settings_id(String value) {
		setConstString(offset + 6, $location_settings_id, value);
	}


	public String location_settings_nm() {
		return getConstString(offset + 7, $location_settings_nm);
	}

	public void location_settings_nm(String value) {
		setConstString(offset + 7, $location_settings_nm, value);
	}


	public String remark() {
		return getConstString(offset + 8, $remark);
	}

	public void remark(String value) {
		setConstString(offset + 8, $remark, value);
	}


	public String getString(String name) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			return per_grp_id();
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			return per_grp_nm();
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			return setting_unit_type_nm();
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			return search_settings_id();
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			return search_settings_nm();
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			return location_settings_id();
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			return location_settings_nm();
		}
		if ($remark.equalsIgnoreCase(name)) {
			return remark();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			return per_grp_id();
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			return per_grp_nm();
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			return setting_unit_type_nm();
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			return search_settings_id();
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			return search_settings_nm();
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			return location_settings_id();
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			return location_settings_nm();
		}
		if ($remark.equalsIgnoreCase(name)) {
			return remark();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			per_grp_id(value);
			return;
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			per_grp_nm(value);
			return;
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			setting_unit_type_nm(value);
			return;
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			search_settings_id(value);
			return;
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			search_settings_nm(value);
			return;
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			location_settings_id(value);
			return;
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			location_settings_nm(value);
			return;
		}
		if ($remark.equalsIgnoreCase(name)) {
			remark(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			per_grp_id(value);
			return;
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			per_grp_nm(value);
			return;
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		if ($setting_unit_type_nm.equalsIgnoreCase(name)) {
			setting_unit_type_nm(value);
			return;
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			search_settings_id(value);
			return;
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			search_settings_nm(value);
			return;
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			location_settings_id(value);
			return;
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			location_settings_nm(value);
			return;
		}
		if ($remark.equalsIgnoreCase(name)) {
			remark(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

