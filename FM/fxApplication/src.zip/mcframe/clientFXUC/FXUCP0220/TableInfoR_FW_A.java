package mcframe.clientFXUC.FXUCP0220;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"TableInfo"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class TableInfoR_FW_A extends MCConstRow {

	public static final String $table_id = "table_id";
	public static final String $table_nm = "table_nm";
	public static final String $column_order_id = "column_order_id";
	public static final String $column_order_nm = "column_order_nm";
	public static final String $sort_id = "sort_id";
	public static final String $sort_nm = "sort_nm";
	public static final String $filter_id = "filter_id";
	public static final String $filter_nm = "filter_nm";
	public static final String $signal_id = "signal_id";
	public static final String $signal_nm = "signal_nm";


	public static final MCMeta table_id_META = createStringMeta($table_id);
	public static final MCMeta table_nm_META = createStringMeta($table_nm);
	public static final MCMeta column_order_id_META = createStringMeta($column_order_id);
	public static final MCMeta column_order_nm_META = createStringMeta($column_order_nm);
	public static final MCMeta sort_id_META = createStringMeta($sort_id);
	public static final MCMeta sort_nm_META = createStringMeta($sort_nm);
	public static final MCMeta filter_id_META = createStringMeta($filter_id);
	public static final MCMeta filter_nm_META = createStringMeta($filter_nm);
	public static final MCMeta signal_id_META = createStringMeta($signal_id);
	public static final MCMeta signal_nm_META = createStringMeta($signal_nm);

	protected static final ConstMetaList<TableInfoR> constMetas = new ConstMetaList<TableInfoR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			table_id_META,
			table_nm_META,
			column_order_id_META,
			column_order_nm_META,
			sort_id_META,
			sort_nm_META,
			filter_id_META,
			filter_nm_META,
			signal_id_META,
			signal_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected TableInfoR_FW_A(ConstMetaList<? extends TableInfoR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableInfoR clone() {
		return (TableInfoR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableInfoR createInstance() {
		return (TableInfoR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableInfoR getValues(String... names) {
		return (TableInfoR) super.getValues(names);
	}



	public String table_id() {
		return getConstString(offset + 0, $table_id);
	}

	public void table_id(String value) {
		setConstString(offset + 0, $table_id, value);
	}


	public String table_nm() {
		return getConstString(offset + 1, $table_nm);
	}

	public void table_nm(String value) {
		setConstString(offset + 1, $table_nm, value);
	}


	public String column_order_id() {
		return getConstString(offset + 2, $column_order_id);
	}

	public void column_order_id(String value) {
		setConstString(offset + 2, $column_order_id, value);
	}


	public String column_order_nm() {
		return getConstString(offset + 3, $column_order_nm);
	}

	public void column_order_nm(String value) {
		setConstString(offset + 3, $column_order_nm, value);
	}


	public String sort_id() {
		return getConstString(offset + 4, $sort_id);
	}

	public void sort_id(String value) {
		setConstString(offset + 4, $sort_id, value);
	}


	public String sort_nm() {
		return getConstString(offset + 5, $sort_nm);
	}

	public void sort_nm(String value) {
		setConstString(offset + 5, $sort_nm, value);
	}


	public String filter_id() {
		return getConstString(offset + 6, $filter_id);
	}

	public void filter_id(String value) {
		setConstString(offset + 6, $filter_id, value);
	}


	public String filter_nm() {
		return getConstString(offset + 7, $filter_nm);
	}

	public void filter_nm(String value) {
		setConstString(offset + 7, $filter_nm, value);
	}


	public String signal_id() {
		return getConstString(offset + 8, $signal_id);
	}

	public void signal_id(String value) {
		setConstString(offset + 8, $signal_id, value);
	}


	public String signal_nm() {
		return getConstString(offset + 9, $signal_nm);
	}

	public void signal_nm(String value) {
		setConstString(offset + 9, $signal_nm, value);
	}


	public String getString(String name) {
		if ($table_id.equalsIgnoreCase(name)) {
			return table_id();
		}
		if ($table_nm.equalsIgnoreCase(name)) {
			return table_nm();
		}
		if ($column_order_id.equalsIgnoreCase(name)) {
			return column_order_id();
		}
		if ($column_order_nm.equalsIgnoreCase(name)) {
			return column_order_nm();
		}
		if ($sort_id.equalsIgnoreCase(name)) {
			return sort_id();
		}
		if ($sort_nm.equalsIgnoreCase(name)) {
			return sort_nm();
		}
		if ($filter_id.equalsIgnoreCase(name)) {
			return filter_id();
		}
		if ($filter_nm.equalsIgnoreCase(name)) {
			return filter_nm();
		}
		if ($signal_id.equalsIgnoreCase(name)) {
			return signal_id();
		}
		if ($signal_nm.equalsIgnoreCase(name)) {
			return signal_nm();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($table_id.equalsIgnoreCase(name)) {
			return table_id();
		}
		if ($table_nm.equalsIgnoreCase(name)) {
			return table_nm();
		}
		if ($column_order_id.equalsIgnoreCase(name)) {
			return column_order_id();
		}
		if ($column_order_nm.equalsIgnoreCase(name)) {
			return column_order_nm();
		}
		if ($sort_id.equalsIgnoreCase(name)) {
			return sort_id();
		}
		if ($sort_nm.equalsIgnoreCase(name)) {
			return sort_nm();
		}
		if ($filter_id.equalsIgnoreCase(name)) {
			return filter_id();
		}
		if ($filter_nm.equalsIgnoreCase(name)) {
			return filter_nm();
		}
		if ($signal_id.equalsIgnoreCase(name)) {
			return signal_id();
		}
		if ($signal_nm.equalsIgnoreCase(name)) {
			return signal_nm();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($table_id.equalsIgnoreCase(name)) {
			table_id(value);
			return;
		}
		if ($table_nm.equalsIgnoreCase(name)) {
			table_nm(value);
			return;
		}
		if ($column_order_id.equalsIgnoreCase(name)) {
			column_order_id(value);
			return;
		}
		if ($column_order_nm.equalsIgnoreCase(name)) {
			column_order_nm(value);
			return;
		}
		if ($sort_id.equalsIgnoreCase(name)) {
			sort_id(value);
			return;
		}
		if ($sort_nm.equalsIgnoreCase(name)) {
			sort_nm(value);
			return;
		}
		if ($filter_id.equalsIgnoreCase(name)) {
			filter_id(value);
			return;
		}
		if ($filter_nm.equalsIgnoreCase(name)) {
			filter_nm(value);
			return;
		}
		if ($signal_id.equalsIgnoreCase(name)) {
			signal_id(value);
			return;
		}
		if ($signal_nm.equalsIgnoreCase(name)) {
			signal_nm(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($table_id.equalsIgnoreCase(name)) {
			table_id(value);
			return;
		}
		if ($table_nm.equalsIgnoreCase(name)) {
			table_nm(value);
			return;
		}
		if ($column_order_id.equalsIgnoreCase(name)) {
			column_order_id(value);
			return;
		}
		if ($column_order_nm.equalsIgnoreCase(name)) {
			column_order_nm(value);
			return;
		}
		if ($sort_id.equalsIgnoreCase(name)) {
			sort_id(value);
			return;
		}
		if ($sort_nm.equalsIgnoreCase(name)) {
			sort_nm(value);
			return;
		}
		if ($filter_id.equalsIgnoreCase(name)) {
			filter_id(value);
			return;
		}
		if ($filter_nm.equalsIgnoreCase(name)) {
			filter_nm(value);
			return;
		}
		if ($signal_id.equalsIgnoreCase(name)) {
			signal_id(value);
			return;
		}
		if ($signal_nm.equalsIgnoreCase(name)) {
			signal_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

