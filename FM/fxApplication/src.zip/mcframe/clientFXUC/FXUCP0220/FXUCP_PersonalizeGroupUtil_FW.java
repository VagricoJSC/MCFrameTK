package mcframe.clientFXUC.FXUCP0220;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import static mcframe.commonCore.lang.MCStringUtil.nullToBlank;
import static mcframe.commonCore.resource.ctrl.MCResource.*;

import java.util.HashMap;

import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;
import mcframe.clientFXUC.FXUCP0210.FXUCP_PersonalizeUtil;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_PersonalizeGroupUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_PersonalizeGroupUtil_FW extends FXUCP_PersonalizeGroupUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected static final String PERSONALIZE_GROUP_NAME_KEY = "perGrpNM";

	protected static final String PERSONALIZE_GROUP_ID_KEY = "perGrpID";

	protected static final String PERSONALIZE_GROUP_REMARK_KEY = "remark";

	protected static final String PERSONALIZE_GROUP = "personalize_group";

	public static final String PERSONALIZE_GRP_ID = "PGRP_ID_";

	public static final String PERSONALIZE_GRP_NM = "PGRP_NM_";

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_PersonalizeGroupUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	protected static MCGeneralPersonalizeResource getResource() {
		return MCConst.app;
	}

	/**
	 * パーソナライズグループ名を返します。
	 *
	 * @param moduleID モジュールID
	 * @param screenID 画面ID
	 * @param perGrpID パーソナライズグループID
	 * @return パーソラナイズグループ名
	 */
	public static String getPersonalizeGroupName(String moduleID, String screenID,
			String perGrpID) {
		String key = MCConst.createKey(createListResourceKey(moduleID, screenID),
				perGrpID, PERSONALIZE_GROUP_NAME_KEY);

		// 7013-1956(【メニューブックマーク】パーソナライズグループや入力値の名称がIDになる)
		if (!getResource().containsKey(key)) {
			MCConst.loadPgmResource(MCConst.createKey(moduleID, screenID));
		}
		// 7013-1956 ここまで

		return getResource().getString(key);
	}
	
	public static String getPersonalizeGroupUnitName(String moduleID, String screenID,
			String perGrpID) {
		String key = MCConst.createKey(createListResourceKey(moduleID, screenID),
				perGrpID, PERSONALIZE_GROUP_NAME_KEY);

		if (!getResource().containsKey(key)) {
			MCConst.loadPgmResource(MCConst.createKey(moduleID, screenID));
		}
		
		for (MCResourceLayerType type : MCResourceLayerType.values()) {
			String nm = getResource().getString(type, key);
			if (!isNull(nm)) {
				return FXUCP_PersonalizeUtil.getSettingInfoUnitName(nm, type.toString());
			}
		}
		
		return null;
//		return getResource().getString(key);
	}

	public static MCList<GrpInfoR> getPersonalizeGroupList(String moduleID,
			String screenID) {
		MCList<GrpInfoR> list = MCList.create(GrpInfoR.class);
		loadPersonalizeList(list, moduleID, screenID);
		return list;
	}

	// フォーカス指定情報の一覧をパーソナライズから読込みする。
	public static <T extends GrpInfoR> void loadPersonalizeList(MCList<T> list,
			String moduleID, String screenID) {

		String key_prefix = MCConst.createKey(createListResourceKey(moduleID, screenID),
				"*");

		String[] base_keys;

		// ユーザ
		base_keys = getResource().findPattern(MCResourceLayerType.USER, key_prefix);
		addPersonalizeList(MCResourceLayerType.USER, list, moduleID, screenID, base_keys);
		// 会社共通
		base_keys = getResource().findPattern(MCResourceLayerType.EXT, key_prefix);
		addPersonalizeList(MCResourceLayerType.EXT, list, moduleID, screenID, base_keys);
		// システム共通
		base_keys = getResource().findPattern(MCResourceLayerType.SYS, key_prefix);
		addPersonalizeList(MCResourceLayerType.SYS, list, moduleID, screenID, base_keys);
	}

	private static <T extends GrpInfoR> void addPersonalizeList(MCResourceLayerType type,
			MCList<T> list, String moduleID, String screenID, String... keys) {
		for (String key : keys) {
			String[] keyArray = MCConst.splitKey(key);
			String perGrpID = keyArray[keyArray.length - 1];
			String perGrpNM = getResource().getString(type,
					MCConst.createKey(key, PERSONALIZE_GROUP_NAME_KEY));
			String remark = getResource().getString(type,
					MCConst.createKey(key, PERSONALIZE_GROUP_REMARK_KEY));

			String searchSettingsID = getResource().getString(type,
					key + ".searchSettingsID");
			String lcoationSettingsID = getResource().getString(type,
					key + ".locationSettingsID");

			T r = list.createRow();
			r.setting_unit_type(type.toString());
			r.per_grp_id(perGrpID);
			r.per_grp_nm(perGrpNM);
			r.remark(remark);
			r.search_settings_id(searchSettingsID);
			r.location_settings_id(lcoationSettingsID);

			list.add(r);
		}
	}

	/**
	 * パーソナライズグループのテーブル設定を読み込む。
	 * 
	 * @param type 設定単位
	 * @param resL 読み込んだ情報を格納するリスト
	 * @param moduleID モジュールＩＤ
	 * @param screenID 画面ＩＤ
	 * @param aPerGrpID パーソナライズグループＩＤ
	 */
	public static <T extends TableInfoR> void loadPersonalizeTable(
			MCResourceLayerType type, MCList<T> resL, String moduleID, String screenID,
			String aPerGrpID) {
		if (!isNull(aPerGrpID)) {
			String listKey = createListResourceKey(moduleID, screenID) + "." + aPerGrpID;

			String[] baseKeys1 = getResource().findPattern(type,
					MCConst.createKey(listKey, "*"));
			String itemKey = listKey + ".item";
			for (String key1 : baseKeys1) {
				if (key1.contains(itemKey)) {
					T r = resL.createRow();
					r.table_id(getResource().getString(type, key1 + ".tableID"));
					r.column_order_id(
							getResource().getString(type, key1 + ".columnOrderID"));
					r.sort_id(getResource().getString(type, key1 + ".sortID"));
					r.filter_id(getResource().getString(type, key1 + ".filterID"));
					r.signal_id(getResource().getString(type, key1 + ".signalID"));

					resL.add(r);
				}
			}
		}
	}

	/**
	 * パーソナライズグループを保存します。
	 *
	 * @param aModuleID モジュールＩＤ
	 * @param aScreenID 画面ＩＤ
	 * @param aPerGrpID グループＩＤ
	 * @param aPerGrpNM グループ名
	 * @param aRemark 備考
	 * @param aSearchSettingsID 入力値設定情報名
	 * @param aLocationSettingsID 項目配置設定情報名
	 * @param list テーブルパーソナライズリスト
	 */
	public static <T extends TableInfoR> void savePersonalize(MCResourceLayerType type,
			String aModuleID, String aScreenID, String aPerGrpID, String aPerGrpNM,
			String aRemark, String aSearchSettingsID, String aLocationSettingsID,
			MCList<T> list) {
		String listKey = createListResourceKey(aModuleID, aScreenID) + "." + aPerGrpID;

		String[] ka = getResource().findPattern(type, listKey + ".**");
		getResource().remove(type, ka);

		getResource().setString(type,
				MCConst.createKey(listKey, PERSONALIZE_GROUP_ID_KEY), aPerGrpID);
		getResource().setString(type,
				MCConst.createKey(listKey, PERSONALIZE_GROUP_NAME_KEY), aPerGrpNM);
		getResource().setString(type,
				MCConst.createKey(listKey, PERSONALIZE_GROUP_REMARK_KEY), aRemark);
		if (!isNull(aSearchSettingsID)) {
			getResource().setString(type, listKey + ".searchSettingsID",
					aSearchSettingsID);
		}
		if (!isNull(aLocationSettingsID)) {
			getResource().setString(type, listKey + ".locationSettingsID",
					aLocationSettingsID);
		}

		int idx = 0;
		for (T r : list) {
			String resItemKey = listKey + ".item" + idx;
			getResource().setString(type, resItemKey + ".tableID", r.table_id());

			if (!isNull(r.column_order_id())) {
				getResource().setString(type, resItemKey + ".columnOrderID",
						r.column_order_id());
			}
			if (!isNull(r.sort_id())) {
				getResource().setString(type, resItemKey + ".sortID", r.sort_id());
			}
			if (!isNull(r.filter_id())) {
				getResource().setString(type, resItemKey + ".filterID", r.filter_id());
			}
			if (!isNull(r.signal_id())) {
				getResource().setString(type, resItemKey + ".signalID", r.signal_id());
			}

			idx++;
		}
//		MCConst.saveUser();
	}

	public static void removePersonalize(MCResourceLayerType type, String moduleID,
			String screenID, String aPerGrpID) {
		String listKey = createListResourceKey(moduleID, screenID) + "." + aPerGrpID;
		String[] ka = getResource().findPattern(type, listKey + ".**");
		getResource().remove(type, ka);
	}

	protected static String createListResourceKey(String moduleID, String screenID) {
		// キーを変更する。
		return createKey("_0_SCR_", moduleID, screenID, PERSONALIZE_GROUP, "list");
	}

	public static void loadPersonalizeTable(String moduleID, String screenID,
			String perGrpID, HashMap<String, String> map1, HashMap<String, String> map2,
			HashMap<String, String> map3, HashMap<String, String> map4) {

		String listKey = createListResourceKey(moduleID, screenID) + "." + perGrpID;

		String[] baseKeys1 = getResource().findPattern(MCConst.createKey(listKey, "*"));
		String itemKey = listKey + ".item";
		for (String key1 : baseKeys1) {
			if (key1.contains(itemKey)) {

				String tableID = getResource().getString(key1 + ".tableID");

				map1.put(tableID, getResource().getString(key1 + ".columnOrderID"));
				map2.put(tableID, getResource().getString(key1 + ".sortID"));
				map3.put(tableID, getResource().getString(key1 + ".filterID"));
				map4.put(tableID, getResource().getString(key1 + ".signalID"));
			}
		}
	}

	public static void loadPersonalize(String moduleID, String screenID, String aPerGrpID,
			HashMap<String, String> map) {
		String listKey = createListResourceKey(moduleID, screenID);
		String key1 = MCConst.createKey(listKey, aPerGrpID);
		String searchSettingsID = nullToBlank(
				getResource().getString(key1 + ".searchSettingsID"));
		String locationSettingsID = nullToBlank(
				getResource().getString(key1 + ".locationSettingsID"));
		map.put("searchSettingsID", searchSettingsID);
		map.put("locationSettingsID", locationSettingsID);
	}

	// 新規IDを自動生成する。
	public static String createGroupID(MCRootPanel targetPanel) {
		String moduleID = targetPanel.getModuleID();
		String screenID = targetPanel.getScreenID();

		// すでに登録されているかどうかのチェック
		List<String> list = new ArrayList<>();
		String listKey = createListResourceKey(moduleID, screenID);
		String[] baseKeys = getResource().findPattern(MCConst.createKey(listKey, "*"));
		for (String key1 : baseKeys) {
			String grp_id = getResource().getString(key1 + "." + PERSONALIZE_GROUP_ID_KEY,
					"");
			list.add(grp_id);
		}

		for (int n = 1; n < 100000; n++) {
			String grp_id = PERSONALIZE_GRP_ID + String.format("%05d", n);
			if (list.contains(grp_id) == false) {
				return grp_id;
			}
		}

		return PERSONALIZE_GRP_ID + "99999";
	}

	// 設定名から設定IDを得る。
	public static String getGroupID(MCRootPanel targetPanel, String nm) {
		String moduleID = targetPanel.getModuleID();
		String screenID = targetPanel.getScreenID();

		String listKey = createListResourceKey(moduleID, screenID);
		String[] baseKeys = getResource().findPattern(MCConst.createKey(listKey, "*"));
		for (String key1 : baseKeys) {
			String grp_nm = getResource()
					.getString(key1 + "." + PERSONALIZE_GROUP_NAME_KEY, "");
			if (grp_nm.equals(nm)) {
				String grp_id = getResource()
						.getString(key1 + "." + PERSONALIZE_GROUP_ID_KEY, "");
				return grp_id;
			}
		}
		return null;
	}

}