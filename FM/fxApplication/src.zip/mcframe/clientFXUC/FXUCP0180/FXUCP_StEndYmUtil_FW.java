package mcframe.clientFXUC.FXUCP0180;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import mcframe.clientCore.container.MCConstRow;
import mcframe.clientFXBA.FXBAP0050.FXBAP_RLBase;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import mcframe.commonCore.container.MCIndexKey;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;
import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * 開始年月終了年月のユーティリティクラスです。
 */
abstract public class FXUCP_StEndYmUtil_FW {
	protected static final FXUCP_StEndYmUtil _util = new FXUCP_StEndYmUtil();

	/**
	 * 開始年月終了年月制御対象の画面かどうかを返します。
	 *
	 * @param panel パネル
	 * @return 開始年月終了年月制御対象の画面の場合true
	 */
	public static boolean isStEndYm(FXBAP_RLBase panel) {
		return _util._isStEndYm(panel);
	}

	/**
	 * ベースキーの配列を取得します。ベースキーは開始年月以外のKey項目の配列です。
	 *
	 * @param panel パネル
	 * @return ベースキーの配列
	 */
	public static String[] getBaseKey(FXBAP_RLBase panel) {
		return _util._getBaseKey(panel);
	}

	/**
	 * 開始年月終了年月の重複をチェックします。
	 *
	 * @param l Listコンテナ
	 * @param base_keys ベースキー
	 * @param ml メッセージリスト
	 */
	public static <R extends MCRow> void checkStEndYmValid(MCList<R> l,
			String[] base_keys, MCMessageList ml) {
		_util._checkStEndYmValid(l, base_keys, ml, false);
	}

	/**
	 * 開始年月終了年月の重複をチェックし、補正します。
	 *
	 * @param l Listコンテナ
	 * @param base_keys ベースキー
	 * @param ml メッセージリスト
	 */
	public static <R extends MCRow> void checkStEndYmValidAutoMod(MCList<R> l,
			String[] base_keys, MCMessageList ml) {
		_util._checkStEndYmValid(l, base_keys, ml, true);
	}

	/**
	 * 開始年月の項目名
	 *
	 */
	protected static final String $ST_YM_CLM = "st_ym";

	/**
	 * 終了年月の項目名
	 *
	 */
	protected static final String $END_YM_CLM = "end_ym";

	/**
	 * 開始年月の項目名
	 *
	 */
	protected static final String $ST_YM_CLM_PATH_SUFIX = ".st_ym";

	/**
	 * 終了年月の項目名
	 *
	 */
	protected static final String $END_YM_CLM_PATH_SUFIX = ".end_ym";

	protected String getStYmClm() {
		return $ST_YM_CLM;
	}

	protected String getEndYmClm() {
		return $END_YM_CLM;
	}

	protected String getStYmClmPathSufix() {
		return $ST_YM_CLM_PATH_SUFIX;
	}

	protected String getEndYmClmPathSufix() {
		return $END_YM_CLM_PATH_SUFIX;
	}

	/**
	 * 開始年月終了年月制御対象の画面かどうかを返します。
	 *
	 * @param panel パネル
	 * @return 開始年月終了年月制御対象の画面の場合true
	 */
	protected boolean _isStEndYm(FXBAP_RLBase panel) {
		MCConstRow r = panel.getDtlL().createRow();
		return !(isNull(_getStYmClmPath(r)) || isNull(_getEndYmClmPath(r)));
	}

	/**
	 * ベースキーの配列を取得します。ベースキーは開始年月以外のKey項目の配列です。
	 *
	 * @param panel パネル
	 * @return ベースキーの配列
	 */
	protected String[] _getBaseKey(FXBAP_RLBase panel) {
		String[] clms = panel.getDtlRKeyColumns();
		List<String> ret = new ArrayList<String>(Arrays.asList(clms));
		ret.remove(_getStYmClmPath(panel.getDtlL().createRow()));
		return ret.toArray(new String[0]);
	}

	/**
	 * 開始年月終了年月の重複をチェックします。
	 * チェックした上で補正します。
	 *
	 * @param l Listコンテナ
	 * @param base_keys ベースキー
	 * @param ml メッセージリスト
	 * @param auto_mod 自動調整する場合はtrue
	 * @param  メッセージリスト
	 */
	@SuppressWarnings("rawtypes")
	protected <R extends MCRow> void _checkStEndYmValid(MCList<R> l, String[] base_keys,
			MCMessageList ml, boolean auto_mod) {
		String st_ym_clm = _getStYmClmPath(l.createRow());
		String end_ym_clm = _getEndYmClmPath(l.createRow());
		Set<List<Comparable>> val_set = _getBaseKeySet(l, base_keys);
		MCIndexKey idx = l.createIndex(base_keys);
		for (List<Comparable> val : val_set) {
			_checkStEndYmValid(l.subList(idx, val.toArray(new Comparable[0])), st_ym_clm,
					end_ym_clm, ml, auto_mod);
		}
	}

	/**
	 * ベースキーの値のセットを取得します。
	 *
	 * @param l リスト
	 * @param base_keys ベースキー
	 * @return ベースキーの値のセット
	 */
	@SuppressWarnings("rawtypes")
	protected <R extends MCRow> Set<List<Comparable>> _getBaseKeySet(MCList<R> l,
			String[] base_keys) {
		Set<List<Comparable>> val_set = new HashSet<List<Comparable>>();
		for (MCRow r : l) {
			List<Comparable> vals = new ArrayList<Comparable>();
			for (String key : base_keys) {
				vals.add(r.getValue(key));
			}
			val_set.add(vals);
		}
		return val_set;
	}

	/**
	 * 開始年月終了年月の重複をチェックします。
	 *
	 * @param l Listコンテナ
	 * @param st_dt_clm 開始年月のカラムパス
	 * @param end_dt_clm 終了年月のカラムパス
	 * @param ml メッセージリスト
	 * @param auto_mod 自動調整する場合はtrue
	 */
	protected <R extends MCRow> void _checkStEndYmValid(MCList<R> l, String st_ym_clm,
			String end_ym_clm, MCMessageList ml, boolean auto_mod) {
		if (l.size() < 2) {
			return;
		}
		l.sort(st_ym_clm);
		for (int i = 0; i < l.size(); i++) {
			MCRow r = l.get(i);
			for (int j = i + 1; j < l.size(); j++) {
				MCRow s = l.get(j);
				_checkStEndYmValid(r, s, st_ym_clm, end_ym_clm, ml, auto_mod);
			}
		}
	}

	/**
	 * 開始年月終了年月の重複をチェックします。
	 *
	 * @param r 比較対象１
	 * @param s 比較対象２
	 * @param st_dt_clm 開始年月のカラムパス
	 * @param end_dt_clm 終了年月のカラムパス
	 * @param ml メッセージリスト
	 * @param auto_mod 自動調整する場合はtrue
	 */
	protected <R extends MCRow> void _checkStEndYmValid(R r, R s, String st_ym_clm,
			String end_ym_clm, MCMessageList ml, boolean auto_mod) {
		MCDate st_ym1 = r.getDate(st_ym_clm);
		MCDate end_ym1 = r.getDate(end_ym_clm);
		MCDate st_ym2 = s.getDate(st_ym_clm);
		MCDate end_ym2 = s.getDate(end_ym_clm);

		// nullの場合はチェックしない
		if (isNull(st_ym1) || isNull(end_ym1) || isNull(st_ym2) || isNull(end_ym2)) {
			return;
		}
		if (end_ym2.ltDate(st_ym1) || st_ym2.gtDate(end_ym1)) {
			return;
		}

		// 自動調整
		else if (auto_mod) {
			// 開始年月が同じ場合は何もしない
			if (isSame(r.getDate(st_ym_clm), s.getDate(st_ym_clm))) {
				ml.add(new MCMessage(r, null, FXUCP0040, r.getGUIIndex() + 1, s
						.getGUIIndex() + 1));
			}
			// 開始年月が違う場合は、前レコードの終了年月を開始年月の1月前にし、ステータス変更
			else {
				r.setDate(end_ym_clm, s.getDate(st_ym_clm).addMonth(-1));
				if (r.isStatusNone()) {
					r.setStatus(MCRow.MODIFY);
				}
				ml.add(new MCMessage(r, null, FXUCP0039, r.getGUIIndex() + 1, s
						.getGUIIndex() + 1));
			}
		}
		// 自動調整なし
		else {
			ml.add(new MCMessage(r, null, FXUCP0038, r.getGUIIndex() + 1,
					s.getGUIIndex() + 1));
		}
	}

	/**
	 * コンテナの開始年月のカラムパスを返します。
	 *
	 * @param r コンテナ
	 * @return 開始年月のカラムパス
	 */
	protected String _getStYmClmPath(MCRow r) {
		String[] arr = r.getColumnPathArray();
		for (String s : arr) {
			if (isSame(s, getStYmClm()) || s.endsWith(getStYmClmPathSufix())) {
				return s;
			}
		}
		return null;
	}

	/**
	 * コンテナの終了年月のカラムパスを返します。
	 *
	 * @param r コンテナ
	 * @return 終了年月のカラムパス
	 */
	protected String _getEndYmClmPath(MCRow r) {
		String[] arr = r.getColumnPathArray();
		for (String s : arr) {
			if (isSame(s, getEndYmClm()) || s.endsWith(getEndYmClmPathSufix())) {
				return s;
			}
		}
		return null;
	}
}
