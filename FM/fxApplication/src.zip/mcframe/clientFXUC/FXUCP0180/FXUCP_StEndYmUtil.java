package mcframe.clientFXUC.FXUCP0180;

import mcframe.commonCore.annotation.EI;

/**
 * 開始年月終了年月のユーティリティクラスです。
 *
 */
@EI
public class FXUCP_StEndYmUtil extends FXUCP_StEndYmUtil_FW {
	FXUCP_StEndYmUtil() {
		super();
	}

	/**
	 * インスタンス生成
	 */
	public FXUCP_StEndYmUtil createInstance() {
		return new FXUCP_StEndYmUtil();
	}
}
