package mcframe.clientFXUC.FXUCP0010;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.sys.MCSys;
import static mcframe.commonFX.notice.FX_Msg.*;

import java.util.Locale;

import mcframe.commonCore.meta.MCMeta;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXUCP_DataUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXUCP_DataUtil_FW extends FXUCP_DataUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXUCP_DataUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// クライアントオリジナルの実装（ここから）
	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	public static String toYMString(MCCalendarDate<?> dt) {
		return me()._toYMString(dt);
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	protected String _toYMString(MCCalendarDate<?> dt) {
		// サーバーはクライアントのロケールで文字列変換しなくてはいけない
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YM"));
		}
		return ans;
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	public static String toYMDString(MCCalendarDate<?> dt) {
		return me()._toYMDString(dt);
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	protected String _toYMDString(MCCalendarDate<?> dt) {
		// サーバーはクライアントのロケールで文字列変換しなくてはいけない
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YMD"));
		}
		return ans;
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	public static String toY2MString(MCCalendarDate<?> dt) {
		return me()._toY2MString(dt);
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	protected String _toY2MString(MCCalendarDate<?> dt) {
		// サーバーはクライアントのロケールで文字列変換しなくてはいけない
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2M"));
		}
		return ans;
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	public static String toY2MDString(MCCalendarDate<?> dt) {
		return me()._toY2MDString(dt);
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	protected String _toY2MDString(MCCalendarDate<?> dt) {
		// サーバーはクライアントのロケールで文字列変換しなくてはいけない
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2MD"));
		}
		return ans;
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（月日）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	public static String toMDString(MCCalendarDate<?> dt) {
		return me()._toMDString(dt);
	}

	/**
	* 日付データをクライアントロケールに合わせた書式で文字列化します（月日）
	*
	* @param dt 日付データ
	* @return 日付データの文字列表現
	*/
	protected String _toMDString(MCCalendarDate<?> dt) {
		// サーバーはクライアントのロケールで文字列変換しなくてはいけない
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("MD"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toYMDHMSString(MCCalendarDate<?> dt) {
		return me()._toYMDHMSString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toYMDHMSString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YMDHMS"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toY2MDHMSString(MCCalendarDate<?> dt) {
		return me()._toY2MDHMSString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toY2MDHMSString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2MDHMS"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toYMDHMString(MCCalendarDate<?> dt) {
		return me()._toYMDHMString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toYMDHMString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YMDHM"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toY2MDHMString(MCCalendarDate<?> dt) {
		return me()._toY2MDHMString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 *
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toY2MDHMString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2MDHM"));
		}
		return ans;
	}

	/**
	 * 時間をHMSフォーマットで文字列化する。<p>
	 * このメソッドを使用した場合、時間は24時間表記になります。
	 *
	 * @param time 時間
	 * @return 時間をHMSフォーマットで文字列化したもの
	 */
	public static String toHMSStr(long time) {
		return me()._toYMDStr(time);
	}

	/**
	 * 時間をHMSフォーマットで文字列化する。
	 *
	 * @param time 時間（秒単位）
	 * @return 時間をHMSフォーマットで文字列化したもの
	 */
	protected String _toYMDStr(long time) {
		boolean minus = false;
		if (time < 0L) {
			minus = true;
			time *= -1L;
		}
		long hour = time / 3600L;
		long minute = time / 60L % 60L;
		long second = time % 60L;
		if (minus) {
			hour *= -1L;
		}
		return new MCMessage(FXUCC0012, String.format("%02d", hour), // intの桁数で足りる保障がないので、lpad(int,int,String)を使用しない
				String.format("%02d", minute), String.format("%02d", second)).toString();
	}
	
	/**
	 * 
	 * 日付のフォーマッタを返します。
	 * <p>
	 * FXの設定がない場合は標準のフォーマットを返します。
	 *
	 * @param id フォーマット ID
	 * @return フォーマッタ
	 */
	protected MCDateFormat getDateFormat(String id) {
		String format = MCConst.format.getString(getDateOutputPatternKey(id), MCConst.format.getDateOutputPattern(id));
		return MCDateFormat.create(format, MCSys.user.locale());
	}

	/**
	* 数値データを % 記号つきの文字列に変換します
	*
	* @param num 数値データ
	* @return 数値データの%記号つきの文字列
	*/
	public static String toPercentString(MCNumber num) {
		return me()._toPercentString(num);

	}

	/**
	* 数値データを % 記号つきの文字列に変換します
	*
	* @param num 数値データ
	* @return 数値データの%記号つきの文字列
	*/
	protected String _toPercentString(MCNumber num) {
		// サーバーはクライアントのロケールで文字列変換しなくては
		// いけないけど必要なさそうだからとりあえず作らない。
		MCMessage msg = new MCMessage(FXUCC0006, num);
		return msg.toString();
	}

	private static FXUCP_DataUtil _me;

	protected static FXUCP_DataUtil me() {
		if (_me == null) {
			_me = new FXUCP_DataUtil();
		}
		return _me;
	}

	// クライアントオリジナルの実装（ここまで）
	// 以下 サーバーと共通と同じ
	// サーバ：コピペ -> me() を object(CLAZZ) に置換
	// 共通：そのまま

	// ////////////////////////////////////
	// ////////////////////////////////////
	// ////////////////////////////////////
	// ////////////////////////////////////
	// 共通 String（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(String)}
	 */
	public static boolean isNull(String value) {
		return me()._isNull(value);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(String, String)}
	 */
	public static String nvl(String val, String defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(String, String)}
	 */
	public static boolean isSame(String val1, String val2) {
		return me()._isSame(val1, val2);
	}

	// 共通 String（ここまで）
	// String オリジナル（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isGTINCd(String)}
	 */
	public static boolean isGTINCd(String str) {
		return me()._isGTINCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isITFCd(String)}
	 */
	public static boolean isITFCd(String str) {
		return me()._isITFCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isJANCd(String)}
	 */
	public static boolean isJANCd(String str) {
		return me()._isJANCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isHSCd(String)}
	 */
	public static boolean isHSCd(String str) {
		return me()._isHSCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isZipCdStr(String)}
	 */
	public static boolean isZipCdStr(String str) {
		return me()._isZipCdStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isZipCdStr(String, Locale)}
	 */
	public static boolean isZipCdStr(String str, Locale locale) {
		return me()._isZipCdStr(str, locale);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isTelStr(String)}
	 */
	public static boolean isTelStr(String str) {
		return me()._isTelStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isFaxStr(String)}
	 */
	public static boolean isFaxStr(String str) {
		return me()._isFaxStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isUrlStr(String)}
	 */
	public static boolean isUrlStr(String str) {
		return me()._isUrlStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isEmailStr(String)}
	 */
	public static boolean isEmailStr(String str) {
		return me()._isEmailStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNumberStr(String)}
	 */
	public static boolean isNumberStr(String str) {
		return me()._isNumberStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isPositiveNumberStr(String)}
	 */
	public static boolean isPositiveNumberStr(String str) {
		return me()._isPositiveNumberStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNegativeNumberStr(String)}
	 */
	public static boolean isNegativeNumberStr(String str) {
		return me()._isNegativeNumberStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isDigitsAlphabetStr(String)}
	 */
	public static boolean isDigitsAlphabetStr(String str) {
		return me()._isDigitsAlphabetStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isAlphabetStr(String)}
	 */
	public static boolean isAlphabetStr(String str) {
		return me()._isAlphabetStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isDigitsStr(String)}
	 */
	public static boolean isDigitsStr(String str) {
		return me()._isDigitsStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(int, int, String)}
	 */
	public static String lpad(int num, int len, String addStr) {
		return me()._lpad(num, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(String, int, String)}
	 */
	public static String lpad(String str, int len, String addStr) {
		return me()._lpad(str, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(int, MCMeta, String)}
	 */
	public static String lpad(int num, MCMeta meta, String addStr) {
		return me()._lpad(num, meta, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(String, MCMeta, String)}
	 */
	public static String lpad(String str, MCMeta meta, String addStr) {
		return me()._lpad(str, meta, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(int, int, String)}
	 */
	public static String rpad(int num, int len, String addStr) {
		return me()._rpad(num, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(String, int, String)}
	 */
	public static String rpad(String str, int len, String addStr) {
		return me()._rpad(str, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(int, MCMeta, String)}
	 */
	public static String rpad(int num, MCMeta meta, String addStr) {
		return me()._rpad(num, meta, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(String, MCMeta, String)}
	 */
	public static String rpad(String str, MCMeta meta, String addStr) {
		return me()._rpad(str, meta, addStr);
	}

	// String オリジナル（ここまで）
	// 共通 Number（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCNumber)}
	 */
	public static boolean isNull(MCNumber val) {
		return me()._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(MCNumber, MCNumber)}
	 */
	public static MCNumber nvl(MCNumber val, MCNumber defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(MCNumber, MCNumber)}
	 */
	public static boolean isSame(MCNumber val1, MCNumber val2) {
		return me()._isSame((Number) val1, (Number) val2);
	}

	// 共通 Number（ここまで）
	// Numberオリジナル（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#negate(MCNumber)}
	 */
	public static MCNumber negate(MCNumber n) {
		return me()._negate(n);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#sum(Comparable...)}
	 */
	public static MCNumber sum(Comparable<?>... args) {
		return me()._sum(args);
	}

	// Numberオリジナル（ここまで）
	// 共通 MCDate（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCDate)}
	 */
	public static boolean isNull(MCDate val) {
		return me()._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(MCDate, MCDate)}
	 */
	public static MCDate nvl(MCDate val, MCDate defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(MCDate, MCDate)}
	 */
	public static boolean isSame(MCDate val1, MCDate val2) {
		return me()._isSame(val1, val2);
	}

	// 共通 MCDate（ここまで）
	// MCDateオリジナル（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#toYM(MCDate)}
	 */
	public static MCDate toYM(MCDate date) {
		return me()._toYM(date);
	}

	// MCDateオリジナル（ここまで）

	// 共通 boolean（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(Boolean)}
	 */
	public static boolean isNull(Boolean val) {
		return me()._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(Boolean, Boolean)}
	 */
	public static Boolean nvl(Boolean val, Boolean defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(Boolean, Boolean)}
	 */
	public static boolean isSame(Boolean val1, Boolean val2) {
		return me()._isSame(val1, val2);
	}

	// 共通 boolean（ここまで）
	// 共通 MCRow（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(MCRow, MCRow)}
	 */
	public static MCRow nvl(MCRow val, MCRow defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(MCRow, MCRow)}
	 */
	public static boolean isSame(MCRow val1, MCRow val2) {
		return me()._isSame(val1, val2);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCRow)}
	 */
	public static boolean isNull(MCRow val) {
		return me()._isNull(val);
	}

	// 共通 MCRow（ここまで）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isColSame(MCRow, MCRow, String...)}
	 */
	public static boolean isColSame(MCRow row1, MCRow row2, String... cols) {
		return me()._isColSame(row1, row2, cols);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isColSame(MCRow, String[], MCRow, String[])}
	 */
	public static boolean isColSame(MCRow row1, String[] cols1, MCRow row2, String[] cols2) {
		return me()._isColSame(row1, cols1, row2, cols2);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCList)}
	 */
	public static boolean isNull(MCList list) {
		return me()._isNull(list);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(Comparable)}
	 */
	public static boolean isNull(Comparable val) {
		return me()._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(Comparable, Comparable)}
	 */
	public static Comparable nvl(Comparable val, Comparable defVal) {
		return me()._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(Comparable, Comparable)}
	 */
	public static boolean isSame(Comparable val1, Comparable val2) {
		return me()._isSame(val1, val2);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNullAnd(Comparable...)}
	 */
	public static boolean isNullAnd(Comparable<?>... vals) {
		return me()._isNullAnd(vals);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNullOr(Comparable...)}
	 */
	public static boolean isNullOr(Comparable<?>... vals) {
		return me()._isNullOr(vals);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isLike(String, String)}
	 */
	public static boolean isLike(String arg0, String arg1) {
		return me()._isLike(arg0, arg1, true);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isLikeNoArray(String, String)}
	 */
	public static boolean isLikeNoArray(String arg0, String arg1) {
		return me()._isLike(arg0, arg1, false);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#toRegexForOracleLike(String)}
	 */
	public static String toRegexForOracleLike(String str) {
		return me()._toRegexForOracleLike(str);
	}

	/**
	 * インデントを追加する。
	 * @param indentNum インデント数
	 * @param str インデント追加される文字列
	 * @return インデントを追加した文字列
	 */
	public static String putIndent(MCNumber indentNum, String str) {
		return me()._putIndent(indentNum, str);
	}

	//putIndentは連続で呼ばれるため、毎回newしないようにキャッシュ
	StringBuilder _sbForPutIndent = new StringBuilder();

	/**
	 * インデントを追加する。
	 * @param indentNum インデント数
	 * @param str インデント追加される文字列
	 * @return インデントを追加した文字列
	 */
	protected String _putIndent(MCNumber indentNum, String str) {

		if (isNull(str)) return null;

		int lv = indentNum.intValue();
		for (int i = 0; i < lv; i++) {
			_sbForPutIndent.append(" ");
		}
		_sbForPutIndent.append(str);
		String rtn = _sbForPutIndent.toString();
		_sbForPutIndent.delete(0, _sbForPutIndent.length());
		return rtn;
	}

	// FMCB CUSTOM END

}