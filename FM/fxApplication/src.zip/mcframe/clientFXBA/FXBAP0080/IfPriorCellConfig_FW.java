package mcframe.clientFXBA.FXBAP0080;

import java.awt.Color;
import java.math.RoundingMode;

import javax.swing.border.Border;

import mcframe.clientCore.beans.MCMode;
import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientCore.beans.text.MCDateFormat;
import mcframe.clientCore.beans.text.MCNumberFormat;
import mcframe.clientCore.beans.text.MCTimestampFormat;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.resource.MCFormatConst.MCZeroType;

public interface IfPriorCellConfig_FW {
	/**
	 * 特定のセルに対して優先的に設定したいモードを返す。<br>
	 * デフォルトのモードを採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return モード
	 * @see #getPriorDeleteMode(int, MCColumnConfig, MCTable)
	 */
	public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table);

	/**
	 * Deleteステータスの行のときに、特定のセルに対して優先的に設定したいモードを返す。<br>
	 * デフォルトのモードを採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return モード
	 * @see #getPriorMode(int, MCColumnConfig, MCTable)
	 */
	public MCMode getPriorDeleteMode(int index, MCColumnConfig column, MCTable table);
	/**
	 * 特定のセルに対して優先的に設定したい背景色を返す。<br>
	 * デフォルトの背景色を採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param selected 選択されている場合にtrue
	 * @param mode モード
	 * @return 背景色
	 * @deprecated 下記のメソッドを利用してください。<p>
	 * <ul>
	 * <li>選択行の背景色を制御する場合<br>
	 * {@link #getSelectedRowPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>削除対象行の背景色を制御する場合<br>
	 * {@link #getDeletedRowPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>その他の背景色を制御する場合<br>
	 * {@link #getPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * </ul>
	 */
	@Deprecated
	public Color getPriorBG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode);

	/**
	 * 特定のセルに対して優先的に設定したい背景色を返す。<br>
	 * デフォルトの背景色を採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 */
	public Color getPriorBG(int index, MCColumnConfig column, MCTable table, MCMode mode);

	/**
	 * フォーカスのあるセルに対して優先的に設定したい背景色を返す。<br>
	 * デフォルトの背景色を採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 */
	public Color getFocusedPriorBG(int index, MCColumnConfig column, MCTable table, MCMode mode);
	
	/**
	 * 特定のセルに対して優先的に設定したい文字の色を返す。<br>
	 * デフォルトの文字の色を採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param selected 選択されている場合にtrue
	 * @param mode モード
	 * @return 文字の色
	 * @deprecated 下記のメソッドを利用してください。<p>
	 * <ul>
	 * <li>選択行の文字の色を制御する場合<br>
	 * {@link #getSelectedRowPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>削除対象行の文字の色を制御する場合<br>
	 * {@link #getDeletedRowPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>その他の文字の色を制御する場合<br>
	 * {@link #getPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * </ul>
	 */
	@Deprecated
	public Color getPriorFG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode);

	/**
	 * 特定のセルに対して優先的に設定したい前景色を返す。<br>
	 * デフォルトの前景色を採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 前景色
	 */
	public Color getPriorFG(int index, MCColumnConfig column, MCTable table, MCMode mode);

	/**
	 * フォーカスのあるセルに対して優先的に設定したい前景色を返す。<br>
	 * デフォルトの前景色を採用する場合はnullを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 前景色
	 */
	public Color getFocusedPriorFG(int index, MCColumnConfig column, MCTable table, MCMode mode);
	
	/**
	 * 特定のセルに対して優先的に設定したい入力可能桁数（小数点以下の桁数）を返す。<br>
	 * デフォルトの入力可能桁数を採用する場合は -1 を返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 入力可能桁数（小数点以下の桁数）
	 */
	public int getPriorScale(int index, MCColumnConfig column, MCTable table);

	/**
	 * 特定のセルに対して優先的に設定したい入力可能文字数
	 * （数値カラムの場合は入力可能桁数（整数部の桁数と小数点以下の桁数の合計値））を返す。<br>
	 * デフォルトの入力可能文字数を採用する場合は-1を返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 入力可能文字数（数値カラムの場合は入力可能桁数（整数部の桁数と小数点以下の桁数の合計値））
	 */
	public int getPriorLength(int index, MCColumnConfig column, MCTable table);

	/**
	 * 特定のセルに対して優先的に設定したいマイナス値の入力可否を返す。<br>
	 * デフォルトの設定を採用する場合は null を返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return マイナス値の入力可否
	 */
	public Boolean getPriorMinusEnable(
			int index, MCColumnConfig column, MCTable<?> table);
	
	/**
	 * 特定のセルに対して優先的に設定したい枠を返す。<br>
	 * デフォルトの枠を採用する場合はsuperを返す実装をすること。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 枠
	 */
	public Border getPriorEditorBorder(int index, MCColumnConfig column, MCTable table);
	
	/**
	 * 特定の数値セルに対して優先的に設定したいフォーマットを返します。<p>
	 * デフォルトのフォーマットを採用する場合はsuperを返す実装をすること。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return フォーマットまたは null
	 */
	public MCNumberFormat getPriorNumberFormat(int index, MCColumnConfig column, 
			MCTable table, MCMode mode);

	/**
	 * 特定の日付セルに対して優先的に設定したいフォーマットを返します。<p>
	 * デフォルトのフォーマットを採用する場合はsuperを返す実装をすること。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return フォーマットまたは null
	 */
	public MCDateFormat getPriorDateFormat(int index, MCColumnConfig column, 
			MCTable table, MCMode mode);

	/**
	 * 特定のタイムスタンプセルに対して優先的に設定したいフォーマットを返します。<p>
	 * デフォルトのフォーマットを採用する場合はsuperを返す実装をすること。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return フォーマットまたは null
	 */
	public MCTimestampFormat getPriorTimestampFormat(int index, MCColumnConfig column, 
			MCTable table, MCMode mode);
	
	/**
	 * 特定の日付セルのカレンダポップアップの初期フォーカスの日付について、
	 * 優先的に設定したい日付を返します。<p>
	 * デフォルトの日付を採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return カレンダポップアップの初期フォーカスの日付、または null
	 */
	public MCDate getPriorInitDateCalendarFocus(
			int index, MCColumnConfig column, MCTable table);
	
	/**
	 * 特定のタイムスタンプセルのカレンダポップアップの初期フォーカスの日付について、
	 * 優先的に設定したい日付を返します。<p>
	 * デフォルトの日付を採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return カレンダポップアップの初期フォーカスの日付、または null
	 */
	public MCTimestamp getPriorInitTimestampCalendarFocus(
			int index, MCColumnConfig column, MCTable table);
	
	/**
	 * 特定の数値セルのコンボリスト用のフォーマットについて、
	 * 優先的に設定したいフォーマットを返します。<p>
	 * デフォルトのフォーマットを採用する場合は、super を返す実装をすること。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return　数値セルのコンボリスト用のフォーマット、または null
	 */
	public MCNumberFormat getPriorListNumberFormat(int index,
			MCColumnConfig column, MCTable<?> table);
	
	/**
	 * 特定の日付セルのコンボリスト用のフォーマットについて、
	 * 優先的に設定したいフォーマットを返します。<p>
	 * デフォルトのフォーマットを採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 日付セルのコンボリスト用のフォーマット、または null
	 */
	public MCDateFormat getPriorListDateFormat(int index,
			MCColumnConfig column, MCTable<?> table);
	
	/**
	 * 特定のタイムスタンプセルのコンボリスト用のフォーマットについて、
	 * 優先的に設定したいフォーマットを返します。<p>
	 * デフォルトのフォーマットを採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return タイムスタンプセルのコンボリスト用のフォーマット、または null
	 */
	public MCTimestampFormat getPriorListTimestampFormat(int index,
			MCColumnConfig column, MCTable<?> table);
	
	/**
	 * 表示可能桁数（小数点以下の桁数）を返します。
	 * 特定の数値セルに対して、優先的に設定したい表示可能桁数を返します。<p>
	 * デフォルトの表示可能桁数を採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 表示可能桁数（小数点以下の桁数）
	 */
	public int getPriorViewScale(
			int index, MCColumnConfig column, MCTable<?> table);
	
	/**
	 * 数値を表示するときの小数点以下のゼロ値の表示方法を返します。
	 * 特定の数値セルに対して、優先的に設定したい小数点以下のゼロ値の表示方法を返します。<p>
	 * デフォルトの表示方法を採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 小数点以下のゼロ値の表示方法
	 */
	public MCZeroType getPriorViewZeroType(
			int index, MCColumnConfig column, MCTable<?> table);
	
	/**
	 * 数値を表示するときの端数処理の方法を返します。
	 * 特定の数値セルに対して、優先的に設定したい端数処理の方法を返します。<p>
	 * デフォルトの端数処理方法を採用する場合は、super を返す実装をすること。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 端数処理の方法
	 */
	public RoundingMode getPriorViewRoundingMode(
			int index, MCColumnConfig column, MCTable<?> table);


	/**
	 * ステータスカラムの優先的に設定したい文字の色を返します。<br>
	 * 背景色が見つからなかった場合は null を返します。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param selected 選択されている場合は true、選択されていない場合は false
	 * @param status ステータス
	 * @return 色または null
	 */
	Color getPriorStatusColumnForeground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status);

	/**
	 * ステータスカラムの優先的に設定したい背景色を返します。<br>
	 * 背景色が見つからなかった場合は null を返します。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param selected 選択されている場合は true、選択されていない場合は false
	 * @param status ステータス
	 * @return 色または null
	 */
	Color getPriorStatusColumnBackground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status);

	/**
	 * 選択行のセルに対して優先的に設定したい文字の色を返します。<p>
	 * 文字の色が見つからなかった場合は null を返します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色、または null
	 */
	Color getSelectedRowPriorFG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode);
	
	/**
	 * 選択行のセルに対して優先的に設定したい背景色を返します。<p>
	 * 背景色が見つからなかった場合は null を返します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色、または null
	 */
	Color getSelectedRowPriorBG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode);

	/**
	 * 削除行のセルに対して優先的に設定したい文字の色を返します。<p>
	 * 文字の色が見つからなかった場合は null を返します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色、または null
	 */
	Color getDeletedRowPriorFG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode);
	
	/**
	 * 削除行のセルに対して優先的に設定したい背景色を返します。<p>
	 * 背景色が見つからなかった場合は null を返します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色、または null
	 */
	Color getDeletedRowPriorBG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode);

	/**
	 * セルの文字の色を背景色と同じにする場合は true を返します。<p>
	 * デフォルトの設定を採用する場合は null を返してください。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return セルの文字の色を背景色と同じにする場合は true
	 */
	Boolean getPriorReverseFG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode);
	
}
