package mcframe.clientFXBA.FXBAP0080;

public interface IfPriorCellConfig extends IfPriorCellConfig_FW {

}
