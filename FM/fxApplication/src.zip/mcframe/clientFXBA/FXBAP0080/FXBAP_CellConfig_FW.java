package mcframe.clientFXBA.FXBAP0080;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

import javax.swing.border.Border;

import mcframe.clientCore.beans.text.MCDateFormat;
import mcframe.clientCore.beans.text.MCNumberFormat;
import mcframe.clientCore.beans.text.MCTimestampFormat;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.commonCore.resource.MCFormatConst.MCZeroType;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_CellConfig"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_CellConfig_FW extends FXBAP_CellConfig_FW_A implements IfPriorCellConfig {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_CellConfig_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// 入力補助関連（ここから）
	protected Map<MCColumnConfig, FXBAP_PanelBase.ISPanelLinker> getISPanelColumnConfigMap() {
		return null;
	}

	/**
	 * 入力補助画面が起動するセルのBorder
	 */
	private Border _ISPanelBorder;

	/**
	 * 入力補助画面が起動するセルのBorder
	 */
	protected Border getISPanelBorder() {
		if (_ISPanelBorder == null) {
			_ISPanelBorder = new mcframe.clientCore.beans.border.MCISFieldBorder();
		}
		return _ISPanelBorder;
	}

	// 入力補助関連（ここまで）
	// セルコンフィグの多重化対応（ここから）

	/**
	 * キーのテーブルオブジェクト毎にキーのテーブルとその下層のテーブルにセットされているセルコンフィグの中で、
	 * {@link IfPriorCellConfig} を実装しているセルコンフィグの配列のマップ。
	 * 配列の先頭が、上位（部品）側で後方が下位（部品利用側）です。
	 */
	private Map<MCTable<?>, IfPriorCellConfig[]> _prioCellConfigMap;

	/**
	 * キーのテーブルオブジェクト毎にキーのテーブルとその下層のテーブルにセットされているセルコンフィグの中で、
	 * {@link IfPriorCellConfig} を実装しているセルコンフィグの配列のマップ。
	 * 配列の先頭が、上位（部品）側で後方が下位（部品利用側）です。
	 */
	protected Map<MCTable<?>, IfPriorCellConfig[]> prioCellConfigMap() {
		if (_prioCellConfigMap == null) {
			_prioCellConfigMap = new HashMap<MCTable<?>, IfPriorCellConfig[]>();
		}
		return _prioCellConfigMap;
	}

	/**
	 * 引数のテーブルとその下層のテーブルにセットされているセルコンフィグの中で、
	 * {@link IfPriorCellConfig} を実装しているセルコンフィグの配列を返す。配列の順番は、
	 * 配列の先頭が、上位（部品）側で後方が下位（部品利用側）です。
	 * @param tbl
	 * @return
	 */
	protected IfPriorCellConfig[] prioCellConfigHierarchy(MCTable<?> tbl) {
		Map<MCTable<?>, IfPriorCellConfig[]> m = prioCellConfigMap();
		IfPriorCellConfig[] ans;
		if (m.containsKey(tbl)) {
			ans = m.get(tbl);
		}
		else {
			List<IfPriorCellConfig> list = new ArrayList<IfPriorCellConfig>();
			MCTable<?> t = tbl;
			while (true) {
				MCCellConfig conf = t.getCellConfig();
				if (conf instanceof IfPriorCellConfig) {
					list.add((IfPriorCellConfig) conf);
				}
				MCTable<?> under = t.getUnderTable();
				if (under == null) {
					break;
				}
				t = under;
			}
			ans = list.toArray(new IfPriorCellConfig[0]);
			m.put(tbl, ans);
		}
		return ans;
	}

	/**
	 * デフォルトのモードを取得する<br>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return デフォルトのモード
	 */
	protected MCMode getDefaultMode(int index, MCColumnConfig column, MCTable table) {

		return null;

	}

	/**
	 * セル毎のモード制御のために本来isCellEditableで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトのモードを採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return モード
	 * @see #getCustomDeleteMode(int, MCColumnConfig, MCTable)
	 */
	protected MCMode getCustomMode(int index, MCColumnConfig column, MCTable table) {

		return null;

	}

	/**
	 * Deleteステータスの行のときに、セル毎のモード制御のために本来isCellEditableで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトのモードを採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return モード
	 * @see #getCustomMode(int, MCColumnConfig, MCTable)
	 */
	protected MCMode getCustomDeleteMode(int index, MCColumnConfig column, MCTable table) {

		return null;

	}
	/**
	 * 優先モードが設定されている場合は優先モードを採用する<br>
	 * カスタムモードが設定されている場合はカスタムモードを採用する<br>
	 * 優先モードもカスタムモードも設定されていない場合は親クラスのisCellEditableを採用する<br>
	 * 本クラスは下位クラスでは使用できない。<br>
	 * 本来下位クラスのisCellEditableで行う実装はgetCustomModeにて行うこと。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return モード
	 * @deprecated  共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorMode(int, MCColumnConfig, MCTable)}または、
	 * {@link #getDefaultMode(int, MCColumnConfig, MCTable)}または、
	 * {@link #getCustomMode(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public MCMode isCellEditable(int index, MCColumnConfig column, MCTable table) {

		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		
		MCMode rtn = null;

		if (table.getRow(index).isStatusDelete()) {
			rtn = _isDeleteRowCellEditable(index, column, table, prioConfigs);
		}
		else {
			rtn = isCellEditable(index, column, table, prioConfigs);
		}
		return rtn;
	}

	/**
	 * Deleteステータスの場合のisCellEditableの処理です。<p>
	 * 
	 * {@link #_isCellEditable(int, MCColumnConfig, MCTable, IfPriorCellConfig[])}とは異なり、
	 * {@link #getDefaultMode(int, MCColumnConfig, MCTable) }は呼ばれません。
	 * 
	 * @param index
	 * @param column
	 * @param table
	 * @param prioConfigs
	 * @return　モード
	 * @see #_isCellEditable(int, MCColumnConfig, MCTable, IfPriorCellConfig[])
	 */
	protected MCMode _isDeleteRowCellEditable(int index, MCColumnConfig column, MCTable table, IfPriorCellConfig[] prioConfigs){

		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			MCMode prior = prioConf.getPriorDeleteMode(index, column, table);
			if (prior != null) {
				return prior;
			}
		}
	
		// getCustomDeleteModeでモードが取得できた場合はその値、出来ない場合はsuperのisCellEditableの値
		MCMode custom = getCustomDeleteMode(index, column, table);
		return (custom != null) ? custom : super.isCellEditable(index, column, table);
	
	}
	
	/**
	 * Deleteステータス以外の場合のisCellEditableの値を
	 * 機能制限パタンの設定を考慮した結果を返します。
	 * 
	 * @param index index
	 * @param column column
	 * @param table table
	 * @param prioConfigs prioConfigs
	 * @return モード
	 */
	// #7023-2262追加
	private MCMode isCellEditable(int index, MCColumnConfig column, MCTable table, IfPriorCellConfig[] prioConfigs){
		// Deleteステータス以外の場合のモードを取得
		MCMode mode = _isCellEditable(index, column, table, prioConfigs);
		if (!MCMode.isNull(mode) && column.getModeInfo(mode).getStatus() == MCMode.ENABLE_STATUS) {
			// 入力可能モードの場合、機能制限パタンが設定されている場合READ_ONLYを優先する。
			return column.isReadOnlyColumn() ? MCMode.READ_ONLY : mode;
		}
		return mode;
	}
	
	/**
	 * Deleteステータス以外の場合のisCellEditableの処理です。
	 * 
	 * @param index
	 * @param column
	 * @param table
	 * @param prioConfigs
	 * @return　モード
	 * @see #_isDeleteRowCellEditable(int, MCColumnConfig, MCTable, IfPriorCellConfig[])
	 */
	protected MCMode _isCellEditable(int index, MCColumnConfig column, MCTable table, IfPriorCellConfig[] prioConfigs){
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			MCMode prior = prioConf.getPriorMode(index, column, table);
			if (prior != null) {
				return prior;
			}
		}
	
		// デフォルトモードが取得できた場合は、そのモードを採用する
		MCMode def = getDefaultMode(index, column, table);
		if (def != null) {
			return def;
		}
	
		// getCustomModeでモードが取得できた場合はその値、出来ない場合はsuperのisCellEditableの値
		MCMode custom = getCustomMode(index, column, table);
		return (custom != null) ? custom : super.isCellEditable(index, column, table);
	
	}

	/**
	 * セルの背景色の制御のために本来はgetCellBackgroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの背景色を採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param selected 選択されている場合にtrue
	 * @param mode モード
	 * @return 背景色
	 * @deprecated 下記のメソッドを利用してください。<p>
	 * <ul>
	 * <li>選択行の背景色を制御する場合<br>
	 * {@link #getSelectedRowCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>削除対象行の背景色を制御する場合<br>
	 * {@link #getDeletedRowCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>その他の背景色を制御する場合<br>
	 * {@link #getCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * </ul>
	 */
	@Deprecated
	protected Color getCustomBG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode) {

		return null;

	}

	/**
	 * セルの背景色を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorBG(int, MCColumnConfig, MCTable, boolean ,MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomBG(int, MCColumnConfig, MCTable, boolean ,MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getCellBackground(int, MCColumnConfig, MCTable,boolean , MCMode)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param selected 選択されている場合にtrue
	 * @param mode モード
	 * @return 背景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorBG(int, MCColumnConfig, MCTable,boolean , MCMode)}または、
	 * {@link #getCustomBG(int, MCColumnConfig, MCTable,boolean , MCMode)}を使うことを想定）
	 */
	@Override
	public Color getCellBackground(int index, MCColumnConfig column,
			MCTable table, boolean selected, MCMode mode) {

		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getPriorBG(index, column, table, selected, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getCustomBG(index, column, table, selected, mode);
		return (custom != null) ? custom : super.getCellBackground(index, column, table,
				selected, mode);

	}

	/**
	 * セルの背景色の制御のために本来はgetCellBackgroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの背景色を採用する。
	 *
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 */
	protected Color getCustomBG(int index, MCColumnConfig column, MCTable table,
			MCMode mode) {
		return null;
	}

	/**
	 * セルの背景色を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getCellForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorBG(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomBG(int, MCColumnConfig, MCTable, MCMode)}を使うことを想定）
	 */
	@Override
	public Color getCellBackground(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {

		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getPriorBG(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getCustomBG(index, column, table, mode);
		return (custom != null) ? custom : super.getCellBackground(index, column, table,
				mode);

	}
	

	/**
	 * フォーカスのあるセルの背景色の制御のために本来はgetFocusedCellBackgroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの背景色を採用する。
	 *
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 */
	protected Color getFocusedCustomBG(int index, MCColumnConfig column, MCTable table,
			MCMode mode) {
		return null;
	}
	/**
	 * フォーカスのあるセルの背景色を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getFocusedPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getFocusedCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getFocusedCellForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getFocusedPriorBG(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getFocusedCustomBG(int, MCColumnConfig, MCTable, MCMode)}を使うことを想定）
	 */
	@Override
	public Color getFocusedCellBackground(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {

		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getFocusedPriorBG(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getFocusedCustomBG(index, column, table, mode);
		return (custom != null) ? custom : super.getFocusedCellBackground(index, column, table,
				mode);
	}

	/**
	 * セルの文字の色の制御のために本来はgetCellBackgroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの前景色を採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param selected 選択されている場合にtrue
	 * @param mode モード
	 * @return 文字の色
	 * @deprecated 下記のメソッドを利用してください。<p>
	 * <ul>
	 * <li>選択行の文字の色を制御する場合<br>
	 * {@link #getSelectedRowCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>削除対象行の文字の色を制御する場合<br>
	 * {@link #getDeletedRowCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * <li>その他の文字の色を制御する場合<br>
	 * {@link #getCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * </li>
	 * </ul>
	 */
	@Deprecated
	protected Color getCustomFG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode) {

		return null;

	}

	/**
	 * セルの文字の色を返します。<p>
	 * セルの文字の色を背景色と同じにするように指定している場合は、セルの背景色を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorFG(int, MCColumnConfig, MCTable, boolean ,MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomFG(int, MCColumnConfig, MCTable, boolean ,MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getCellForeground(int, MCColumnConfig, MCTable,boolean , MCMode)}
	 * を呼び出す。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param selected 選択されている場合にtrue
	 * @param mode モード
	 * @return 前景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorFG(int, MCColumnConfig, MCTable,boolean , MCMode)}または、
	 * {@link #getCustomFG(int, MCColumnConfig, MCTable,boolean , MCMode)}を使うことを想定）
	 */
	@Override
	public Color getCellForeground(int index, MCColumnConfig column,
			MCTable table, boolean selected, MCMode mode) {

		if (isReverseFG(index, column, table, mode)) {
			return getCellBackground(index, column, table, selected, mode);
		}
		
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getPriorFG(index, column, table, selected, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getCustomFG(index, column, table, selected, mode);
		return (custom != null) ? custom : super.getCellForeground(index, column, table,
				selected, mode);

	}

	/**
	 * セルの前景色の制御のために本来はgetCellForegroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの前景色を採用する。
	 *
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 前景色
	 */
	protected Color getCustomFG(int index, MCColumnConfig column, MCTable table,
			MCMode mode) {
		return null;
	}

	/**
	 * セルの文字の色を返します。<p>
	 * セルの文字の色を背景色と同じにするように指定している場合は、セルの背景色を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getCellForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 前景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorFG(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomFG(int, MCColumnConfig, MCTable, MCMode)}を使うことを想定）
	 */
	@Override
	public Color getCellForeground(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {

		if (isReverseFG(index, column, table, mode)) {
			return getCellBackground(index, column, table, mode);
		}
		
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getPriorFG(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getCustomFG(index, column, table, mode);
		return (custom != null) ? custom : super.getCellForeground(index, column, table,
				mode);

	}
	/**
	 * フォーカスのあるセルのセルの前景色の制御のために本来はgetCellForegroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの前景色を採用する。
	 *
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 前景色
	 */
	protected Color getFocusedCustomFG(int index, MCColumnConfig column, MCTable table,
			MCMode mode) {
		return null;
	}

	/**
	 * フォーカスのあるセルのセルの文字の色を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getFocusedPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getFocusedCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getFocusedCellForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return 前景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorFG(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomFG(int, MCColumnConfig, MCTable, MCMode)}を使うことを想定）
	 */
	@Override
	public Color getFocusedCellForeground(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {

		if (isReverseFG(index, column, table, mode)) {
			return getFocusedCellBackground(index, column, table, mode);
		}
		
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getFocusedPriorFG(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getFocusedCustomFG(index, column, table, mode);
		return (custom != null) ? custom : super.getFocusedCellForeground(index, column, table,
				mode);

	}
	/**
	 * セルの入力可能桁数（小数点以下の桁数）の制御のために本来はgetCellScaleで行う実装をこのメソッドで行うこと。<br>
	 * -1の場合はデフォルトのスケールを採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 入力可能桁数（小数点以下の桁数）
	 */
	protected int getCustomScale(int index, MCColumnConfig column, MCTable table) {
		return -1;
	}

	/**
	 * セルの入力可能桁数（小数点以下の桁数）を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorScale(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が非負ではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomScale(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が非負ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getCellScale(int, MCColumnConfig, MCTable)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 入力可能桁数（小数点以下の桁数）
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorScale(int, MCColumnConfig, MCTable)}または、
	 * {@link #getCustomScale(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public int getCellScale(int index, MCColumnConfig column, MCTable table) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			int prior = prioConf.getPriorScale(index, column, table);
			if (prior >= 0) {
				return prior;
			}
		}
		int custom = getCustomScale(index, column, table);
		return (custom >= 0) ? custom : super.getCellScale(index, column, table);

	}

	/**
	 * セルの入力可能文字数（数値カラムの場合は入力可能桁数（整数部の桁数と小数点以下の桁数の合計値））
	 * の制御のために本来はgetCellLengthで行う実装をこのメソッドで行うこと。<br>
	 * -1の場合はデフォルトの文字数を採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 入力可能文字数（数値カラムの場合は入力可能桁数（整数部の桁数と小数点以下の桁数の合計値））
	 */
	protected int getCustomLength(int index, MCColumnConfig column, MCTable table) {
		return -1;
	}

	/**
	 * セルの入力可能文字数（数値カラムの場合は入力可能桁数（整数部の桁数と小数点以下の桁数の合計値））
	 * を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorLength(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が非負ではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomLength(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が非負ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getCellLength(int, MCColumnConfig, MCTable)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 入力可能文字数（数値カラムの場合は入力可能桁数（整数部の桁数と小数点以下の桁数の合計値））
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorLength(int, MCColumnConfig, MCTable)}または、
	 * {@link #getCustomLength(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public int getCellLength(int index, MCColumnConfig column, MCTable table) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			int prior = prioConf.getPriorLength(index, column, table);
			if (prior >= 0) {
				return prior;
			}
		}
		int custom = getCustomLength(index, column, table);
		return (custom >= 0) ? custom : super.getCellLength(index, column, table);

	}
	
	/**
	 * セルのマイナス値の入力可否の制御のために、本来はisCellMinusEnableで行う実装をこのメソッドで行うこと。<br>
	 * このメソッドが null を返した場合は、デフォルトの設定を採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return マイナス値の入力可否
	 */
	protected Boolean getCustomMinusEnable(
			int index, MCColumnConfig column, MCTable<?> table) {
		return null;
	}
	
	/**
	 * セルのマイナス値の入力可否を返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorMinusEnable(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、 {@link #getCustomMinusEnable(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの {@link #isCellMinusEnable(int, MCColumnConfig, MCTable)}
	 * を呼び出す。
	 * </P>
	 *
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return マイナス値の入力可否
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorMinusEnable(int, MCColumnConfig, MCTable)}または、
	 * {@link #getCustomMinusEnable(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	@Deprecated
	public boolean isCellMinusEnable(
			int index, MCColumnConfig column, MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			Boolean e = c.getPriorMinusEnable(index, column, table);
			if (e != null) {
				return e.booleanValue();
			}
		}
		
		Boolean e = getCustomMinusEnable(index, column, table);
		return e != null 
				? e.booleanValue() 
				: super.isCellMinusEnable(index, column, table);
	}

	/**
	 * セルの文字数の制御のために本来はgetEditorBorderで行う実装をこのメソッドで行うこと。<br>
	 * -1の場合はデフォルトの文字数を採用する。
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 枠
	 */
	protected Border getCustomEditorBorder(int index, MCColumnConfig column, MCTable table) {
		Border ans = null;
		MCRootPanel columnPanel = column.getRootPanel();
		if (columnPanel instanceof FXBAP_PanelBase) {
			FXBAP_PanelBase panel = (FXBAP_PanelBase) columnPanel;
			FXBAP_PanelBase.ISPanelLinker linker = panel.getISPanelColumnConfigMap().get(
					column);
			if (linker != null && linker.isEnable()) {
				ans = getISPanelBorder();
			}
		}
		return ans;
	}

	/**
	 * エディタのボーダを返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorEditorBorder(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomEditorBorder(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getEditorBorder(int, MCColumnConfig, MCTable)}
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return 枠
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorEditorBorder(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomEditorBorder(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public Border getEditorBorder(int index, MCColumnConfig column, MCTable table) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Border prior = prioConf.getPriorEditorBorder(index, column, table);
			if (prior != null) {
				return prior;
			}
		}
		Border custom = getCustomEditorBorder(index, column, table);
		return (custom != null) ? custom : super.getEditorBorder(index, column, table);

	}

	/**
	 * セルのフォーマットの制御のために本来はgetCellNumberFormatで行う実装をこのメソッドで行うこと。<br>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return フォーマット
	 */
	protected MCNumberFormat getCustomNumberFormat(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	/**
	 * エディタの数値フォーマットを返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorNumberFormat(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomNumberFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスのgetCellNumberFormat
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return フォーマット
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorNumberFormat(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomNumberFormat(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public MCNumberFormat getCellNumberFormat(int index, MCColumnConfig column, 
			MCTable table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			MCNumberFormat prior = prioConf.getPriorNumberFormat(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		MCNumberFormat custom = getCustomNumberFormat(index, column, table);
		return (custom != null) ? custom : super.getCellNumberFormat(index, column, table, mode);

	}

	/**
	 * セルのフォーマットの制御のために本来はgetCellNumberFormatで行う実装をこのメソッドで行うこと。<br>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return フォーマット
	 */
	protected MCDateFormat getCustomDateFormat(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	/**
	 * フォーマットを返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorDateFormat(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomDateFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスのgetCellDateFormat
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return フォーマット
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorDateFormat(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomDateFormat(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public MCDateFormat getCellDateFormat(int index, MCColumnConfig column, 
			MCTable table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			MCDateFormat prior = prioConf.getPriorDateFormat(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		MCDateFormat custom = getCustomDateFormat(index, column, table);
		return (custom != null) ? custom : super.getCellDateFormat(index, column, table, mode);

	}

	/**
	 * セルのフォーマットの制御のために本来はgetCellTimestampFormatで行う実装をこのメソッドで行うこと。<br>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return フォーマット
	 */
	protected MCTimestampFormat getCustomTimestampFormat(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	/**
	 * フォーマットを返します。
	 * <P>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorTimestampFormat(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomTimestampFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスのgetCellTimestampFormat
	 * を呼び出す。
	 * </P>
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @param mode モード
	 * @return フォーマット
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorTimestampFormat(int, MCColumnConfig, MCTable, MCMode)}または、
	 * {@link #getCustomTimestampFormat(int, MCColumnConfig, MCTable)}を使うことを想定）
	 */
	@Override
	public MCTimestampFormat getCellTimestampFormat(int index, MCColumnConfig column, 
			MCTable table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			MCTimestampFormat prior = prioConf.getPriorTimestampFormat(index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		MCTimestampFormat custom = getCustomTimestampFormat(index, column, table);
		return (custom != null) ? custom : super.getCellTimestampFormat(index, column, table, mode);

	}
	
	/**
	 * 日付セルのカレンダポップアップの初期フォーカスの日付の制御のために、
	 * 本来は {@link #getInitDateCalendarFocus(int, MCColumnConfig, MCTable)} 
	 * で行う実装をこのメソッドで行うこと。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return カレンダポップアップの初期フォーカスの日付、または null
	 */
	public MCDate getCustomInitDateCalendarFocus(
			int index, MCColumnConfig column, MCTable table) {
		return null;
	}
	
	/**
	 * 日付セルのカレンダポップアップの初期フォーカスの日付を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorInitDateCalendarFocus(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、 {@link #getCustomInitDateCalendarFocus(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getInitDateCalendarFocus を呼び出します。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return カレンダポップアップの初期フォーカスの日付、または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorInitDateCalendarFocus(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomInitDateCalendarFocus(int, MCColumnConfig, MCTable)}
	 *  を使うことを想定）
	 */
	@Deprecated
	@Override
	public MCDate getInitDateCalendarFocus(
			int index, MCColumnConfig column, MCTable table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			MCDate v = c.getPriorInitDateCalendarFocus(index, column, table);
			if (v != null) {
				return v;
			}
		}
		MCDate v = getCustomInitDateCalendarFocus(index, column, table);
		return v != null ? v : super.getInitDateCalendarFocus(
				index, column, table);
	}

	/**
	 * タイムスタンプセルのカレンダポップアップの初期フォーカスの日付の制御のために、
	 * 本来は 
	 * {@link #getInitTimestampCalendarFocus(int, MCColumnConfig, MCTable)}
	 * で行う実装をこのメソッドで行うこと。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return カレンダポップアップの初期フォーカスの日付、または null
	 */
	protected MCTimestamp getCustomInitTimestampCalendarFocus(int index,
			MCColumnConfig column, MCTable table) {
		return null;
	}
	
	/**
	 * タイムスタンプセルのカレンダポップアップの初期フォーカスの日付を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorInitTimestampCalendarFocus(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、 {@link #getCustomInitTimestampCalendarFocus(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getInitTimestampCalendarFocus を呼び出します。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return カレンダポップアップの初期フォーカスの日付、または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorInitTimestampCalendarFocus(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomInitTimestampCalendarFocus(int, MCColumnConfig, MCTable)}
	 *  を使うことを想定）
	 */
	@Override
	public MCTimestamp getInitTimestampCalendarFocus(int index,
			MCColumnConfig column, MCTable table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			MCTimestamp v = c.getPriorInitTimestampCalendarFocus(
					index, column, table);
			if (v != null) {
				return v;
			}
		}
		MCTimestamp v = getCustomInitTimestampCalendarFocus(
				index, column, table);
		return v != null ? v : super.getInitTimestampCalendarFocus(
				index, column, table);
	}

	/**
	 * 数値セルのコンボリスト用のフォーマットの制御のために、本来は
	 * {@link #getCellListNumberFormat(int, MCColumnConfig, MCTable)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 数値セルのコンボリスト用のフォーマット、または null
	 */
	protected MCNumberFormat getCustomListNumberFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}
	
	/**
	 * 数値セルのコンボリスト用のフォーマットを返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorListNumberFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、 {@link #getCustomListNumberFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getCellListNumberFormat を呼び出します。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 数値セルのコンボリスト用のフォーマット、または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorListNumberFormat(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomListNumberFormat(int, MCColumnConfig, MCTable)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	public MCNumberFormat getCellListNumberFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			MCNumberFormat f = c.getPriorListNumberFormat(
					index, column, table);
			if (f != null) {
				return f;
			}
		}
		MCNumberFormat f = getCustomListNumberFormat(index, column, table);
		return f != null 
				? f : super.getCellListNumberFormat(index, column, table);
	}

	/**
	 * 日付セルのコンボリスト用のフォーマットの制御のために、本来は
	 * {@link #getCellListDateFormat(int, MCColumnConfig, MCTable)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 日付セルのコンボリスト用のフォーマット、または null
	 */
	protected MCDateFormat getCustomListDateFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}
	
	/**
	 * 日付セルのコンボリスト用のフォーマットを返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorListDateFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * {@link #getCustomListDateFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getCellListDateFormat を呼び出します。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 数値セルのコンボリスト用のフォーマット、または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorListDateFormat(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomListDateFormat(int, MCColumnConfig, MCTable)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	public MCDateFormat getCellListDateFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			MCDateFormat f = c.getPriorListDateFormat(index, column, table);
			if (f != null) {
				return f;
			}
		}
		MCDateFormat f = getCustomListDateFormat(index, column, table);
		return f != null 
				? f : super.getCellListDateFormat(index, column, table);
	}

	/**
	 * タイムスタンプセルのコンボリスト用のフォーマットの制御のために、本来は
	 * {@link #getCellListTimestampFormat(int, MCColumnConfig, MCTable)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return タイムスタンプセルのコンボリスト用のフォーマット、または null
	 */
	protected MCTimestampFormat getCustomListTimestampFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}
	
	/**
	 * タイムスタンプセルのコンボリスト用のフォーマットを返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorListTimestampFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * {@link #getCustomListTimestampFormat(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getCellListTimestampFormat を呼び出します。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 数値セルのコンボリスト用のフォーマット、または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorListTimestampFormat(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomListTimestampFormat(int, MCColumnConfig, MCTable)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	public MCTimestampFormat getCellListTimestampFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			MCTimestampFormat f = c.getPriorListTimestampFormat(
					index, column, table);
			if (f != null) {
				return f;
			}
		}
		MCTimestampFormat f = getCustomListTimestampFormat(
				index, column, table);
		return f != null 
				? f : super.getCellListTimestampFormat(index, column, table);
	}
	
	/**
	 * 表示可能桁数（小数点以下の桁数）の制御のために、本来は
	 * {@link #getCellViewScale(int, MCColumnConfig, MCTable)} 
	 * で行う実装をこのメソッドで行うこと。
	 * 
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 表示可能桁数（小数点以下の桁数）
	 */
	protected int getCustomViewScale(int index, MCColumnConfig column,
			MCTable<?> table) {
		return -1;
	}
	
	/**
	 * 表示可能桁数（小数点以下の桁数）を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorViewScale(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が -1 ではない場合はその値を採用します。<br>
	 * {@link #getCustomViewScale(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が -1 ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getCellViewScale を呼び出します。
	 *
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 表示可能桁数（小数点以下の桁数）
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorViewScale(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomViewScale(int, MCColumnConfig, MCTable)}
	 * を使うことを想定）
	 */
	@Override
	@Deprecated
	public int getCellViewScale(int index, MCColumnConfig column,
			MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			int s = c.getPriorViewScale(index, column, table);
			if (s != -1) {
				return s;
			}
		}
		int s = getCustomViewScale(index, column, table);
		return s != -1 ? s : super.getCellViewScale(index, column, table);
	}

	/**
	 * 数値を表示するときの小数点以下のゼロ値の表示方法について、本来は
	 * {@link #getCellViewZeroType(int, MCColumnConfig, MCTable)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 小数点以下のゼロ値の表示方法
	 */
	protected MCZeroType getCustomViewZeroType(
			int index, MCColumnConfig column, MCTable<?> table) {
		return null;
	}
	
	/**
	 * 数値を表示するときの小数点以下のゼロ値の表示方法を返します。
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorViewZeroType(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * {@link #getCustomViewZeroType(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getCellViewZeroType を呼び出します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 小数点以下のゼロ値の表示方法
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorViewZeroType(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomViewZeroType(int, MCColumnConfig, MCTable)}
	 * を使うことを想定）
	 */
	@Override
	@Deprecated
	public MCZeroType getCellViewZeroType(int index, MCColumnConfig column,
			MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			MCZeroType p = c.getPriorViewZeroType(index, column, table);
			if (p != null) {
				return p;
			}
		}
		MCZeroType p = getCustomViewZeroType(index, column, table);
		return p != null ? p : super.getCellViewZeroType(index, column, table);
	}

	/**
	 * ステータスカラムのForegroundを返します。
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorStatusColumnForeground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * {@link #getCustomStatusColumnForeground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getStatusColumnForeground を呼び出します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param selected 選択されている場合は true、選択されていない場合は false
	 * @param status ステータス
	 * @return 色または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorStatusColumnForeground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * または、
	 * {@link #getCustomStatusColumnForeground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * を使うことを想定）
	 */
	@Override
	@Deprecated
	public Color getStatusColumnForeground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			Color p = c.getPriorStatusColumnForeground(index, column, table, selected, status);
			if (p != null) {
				return p;
			}
		}
		Color p = getCustomStatusColumnForeground(index, column, table, selected, status);
		return p != null ? p : super.getStatusColumnForeground(index, column, table, selected,status);
	}

	/**
	 * ステータスカラムのForegroundを返します。
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorStatusColumnBackground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * {@link #getCustomStatusColumnBackground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getStatusColumnBackground を呼び出します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param selected 選択されている場合は true、選択されていない場合は false
	 * @param status ステータス
	 * @return 色または null
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorStatusColumnBackground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * または、
	 * {@link #getCustomStatusColumnBackground(int, MCColumnConfig, MCTable, boolean, Status)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	public Color getStatusColumnBackground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			Color p = c.getPriorStatusColumnBackground(index, column, table, selected, status);
			if (p != null) {
				return p;
			}
		}
		Color p = getCustomStatusColumnBackground(index, column, table, selected, status);
		return p != null ? p : super.getStatusColumnBackground(index, column, table, selected,status);
	}
	/**
	 * 数値を表示するときの端数処理の方法について、本来は
	 * {@link #getCellViewRoundingMode(int, MCColumnConfig, MCTable)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 端数処理の方法
	 */
	protected RoundingMode getCustomViewRoundingMode(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}

	/**
	 * 数値を表示するときの端数処理の方法を返します。
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorViewRoundingMode(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * {@link #getCustomViewRoundingMode(int, MCColumnConfig, MCTable)}
	 * を呼び出し、その値が null ではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの getCellViewRoundingMode を呼び出します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @return 端数処理の方法
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorViewRoundingMode(int, MCColumnConfig, MCTable)}
	 * または、
	 * {@link #getCustomViewRoundingMode(int, MCColumnConfig, MCTable)}
	 * を使うことを想定）
	 */
	@Override
	@Deprecated
	public RoundingMode getCellViewRoundingMode(int index,
			MCColumnConfig column, MCTable<?> table) {
		IfPriorCellConfig[] a = prioCellConfigHierarchy(table);
		for (int i = a.length - 1; i >= 0; i--) {
			IfPriorCellConfig c = a[i];
			RoundingMode m = c.getPriorViewRoundingMode(index, column, table);
			if (m != null) {
				return m;
			}
		}
		RoundingMode m = getCustomViewRoundingMode(index, column, table);
		return m != null 
				? m : super.getCellViewRoundingMode(index, column, table);
	}

	@Deprecated
	@Override
	public Color getPriorBG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode) {
		return null;
	}

	@Override
	public Color getPriorBG(int index, MCColumnConfig column, MCTable table, MCMode mode) {
		return null;
	}

	@Override
	public Color getFocusedPriorBG(int index, MCColumnConfig column, MCTable table, MCMode mode) {
		return null;
	}

	@Override
	public Border getPriorEditorBorder(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	@Deprecated
	@Override
	public Color getPriorFG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode) {
		return null;
	}

	@Override
	public Color getPriorFG(int index, MCColumnConfig column, MCTable table, MCMode mode) {
		return null;
	}

	@Override
	public Color getFocusedPriorFG(int index, MCColumnConfig column, MCTable table, MCMode mode) {
		return null;
	}
	
	@Override
	public int getPriorLength(int index, MCColumnConfig column, MCTable table) {
		return -1;
	}

	@Override
	public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	@Override
	public MCMode getPriorDeleteMode(int index, MCColumnConfig column, MCTable table) {
		return null;
	}
	
	@Override
	public MCDateFormat getPriorDateFormat(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {
		return null;
	}

	@Override
	public MCNumberFormat getPriorNumberFormat(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {
		return null;
	}

	@Override
	public MCTimestampFormat getPriorTimestampFormat(int index, MCColumnConfig column,
			MCTable table, MCMode mode) {
		return null;
	}

	@Override
	public int getPriorScale(int index, MCColumnConfig column, MCTable table) {
		return -1;
	}
	
	@Override
	public MCDate getPriorInitDateCalendarFocus(
			int index, MCColumnConfig column, MCTable table) {
		return null;
	}
	
	@Override
	public MCTimestamp getPriorInitTimestampCalendarFocus(
			int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	@Override
	public MCNumberFormat getPriorListNumberFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}

	@Override
	public MCDateFormat getPriorListDateFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}

	@Override
	public MCTimestampFormat getPriorListTimestampFormat(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}

	@Override
	public int getPriorViewScale(int index, MCColumnConfig column,
			MCTable<?> table) {
		return -1;
	}

	@Override
	public MCZeroType getPriorViewZeroType(int index, MCColumnConfig column,
			MCTable<?> table) {
		return null;
	}

	@Override
	public RoundingMode getPriorViewRoundingMode(int index,
			MCColumnConfig column, MCTable<?> table) {
		return null;
	}

	@Override
	public Boolean getPriorMinusEnable(int index, MCColumnConfig column,
			MCTable<?> table) {
		return null;
	}


	@Override
	public Color getPriorStatusColumnForeground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status) {
		return null;
	}
	@Override
	public Color getPriorStatusColumnBackground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status) {
		return null;
	}

	/**
	 * セルの文字数の制御のために本来はgetStatusColumnForegroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの色を採用する。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param selected 選択されている場合は true、選択されていない場合は false
	 * @param status ステータス
	 * @return 色または null
	 */
	protected Color getCustomStatusColumnForeground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status) {
		return null;
	}

	/**
	 * セルの文字数の制御のために本来はgetStatusColumnBackgroundで行う実装をこのメソッドで行うこと。<br>
	 * nullの場合はデフォルトの色を採用する。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param selected 選択されている場合は true、選択されていない場合は false
	 * @param status ステータス
	 * @return 色または null
	 */
	protected Color getCustomStatusColumnBackground(int index, MCColumnConfig column,
			MCTable<?> table, boolean selected, Status status) {
		return null;
	}

	@Override
	public Color getSelectedRowPriorFG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}

	/**
	 * 選択行のセルの文字の色の制御のために、本来は 
	 * {@link #getSelectedRowForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色
	 */
	protected Color getSelectedRowCustomFG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}
	
	/**
	 * 選択行のセルの文字の色を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getSelectedRowPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getSelectedRowCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getSelectedRowForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getSelectedRowPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * または、
	 * {@link #getSelectedRowCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	protected Color getSelectedRowForeground(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getSelectedRowPriorFG(
					index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getSelectedRowCustomFG(index, column, table, mode);
		return (custom != null) 
				? custom 
				: super.getSelectedRowForeground(index, column, table, mode);
	}

	@Override
	public Color getSelectedRowPriorBG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}

	/**
	 * 選択行のセルの背景色の制御のために、本来は 
	 * {@link #getSelectedRowBackground(int, MCColumnConfig, MCTable, MCMode)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 */
	protected Color getSelectedRowCustomBG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}
	
	/**
	 * 選択行のセルの背景色を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getSelectedRowPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getSelectedRowCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getSelectedRowBackground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getSelectedRowPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * または、
	 * {@link #getSelectedRowCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	protected Color getSelectedRowBackground(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getSelectedRowPriorBG(
					index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getSelectedRowCustomBG(index, column, table, mode);
		return (custom != null) 
				? custom 
				: super.getSelectedRowBackground(index, column, table, mode);
	}

	@Override
	public Color getDeletedRowPriorFG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}
	
	/**
	 * 削除行のセルの文字の色の制御のために、本来は 
	 * {@link #getDeletedRowForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色
	 */
	protected Color getDeletedRowCustomFG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}

	/**
	 * 削除行のセルの文字の色を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getDeletedRowPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getDeletedRowCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getDeletedRowForeground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getDeletedRowPriorFG(int, MCColumnConfig, MCTable, MCMode)}
	 * または、
	 * {@link #getDeletedRowCustomFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を使うことを想定）
	 */
	@Deprecated
	@Override
	protected Color getDeletedRowForeground(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getDeletedRowPriorFG(
					index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getDeletedRowCustomFG(index, column, table, mode);
		return (custom != null) 
				? custom 
				: super.getDeletedRowForeground(index, column, table, mode);
	}

	@Override
	public Color getDeletedRowPriorBG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}
	
	/**
	 * 削除行のセルの背景色の制御のために、本来は 
	 * {@link #getDeletedRowBackground(int, MCColumnConfig, MCTable, MCMode)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 背景色
	 */
	protected Color getDeletedRowCustomBG(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		return null;
	}

	/**
	 * 削除行のセルの文字の色を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getDeletedRowPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getDeletedRowCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、上位クラスの{@link #getDeletedRowBackground(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出す。
	 * 
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return 文字の色
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getDeletedRowPriorBG(int, MCColumnConfig, MCTable, MCMode)}
	 * または、
	 * {@link #getDeletedRowCustomBG(int, MCColumnConfig, MCTable, MCMode)}
	 * を使うことを想定）
	 */
	@Override
	protected Color getDeletedRowBackground(int index, MCColumnConfig column,
			MCTable<?> table, MCMode mode) {
		IfPriorCellConfig[] prioConfigs = prioCellConfigHierarchy(table);
		for (int i = prioConfigs.length - 1; i >= 0; i--) {
			IfPriorCellConfig prioConf = prioConfigs[i];
			Color prior = prioConf.getDeletedRowPriorBG(
					index, column, table, mode);
			if (prior != null) {
				return prior;
			}
		}
		Color custom = getDeletedRowCustomBG(index, column, table, mode);
		return (custom != null) 
				? custom 
				: super.getDeletedRowBackground(index, column, table, mode);
	}

	@Override
	public Boolean getPriorReverseFG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
		return null;
	}
	
	/**
	 * セルの文字の色の反転（背景色と同じ色を返す）の制御のために、本来は
	 * {@link #isReverseFG(int, MCColumnConfig, MCTable, MCMode)}
	 * で行う実装をこのメソッドで行うこと。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return セルの文字の色を背景色と同じにする場合は true
	 */
	protected Boolean getCustomReverseFG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
		return null;
	}
	
	/**
	 * セルの文字の色を背景色と同じにする場合は true を返します。<p>
	 * 埋込画面（埋込カラム）の場合、最下層のテーブルから順にセルコンフィグを取得し、
	 * そのセルコンフィグが {@link IfPriorCellConfig} を実装している場合は、そのセルコンフィグの
	 * {@link IfPriorCellConfig#getPriorReverseFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は、{@link #getCustomReverseFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を呼び出し、その値がnullではない場合はその値を採用します。<br>
	 * それ以外の場合は false を返します。
	 *
	 * @param index 処理対象行
	 * @param column テーブルカラム
	 * @param table テーブル
	 * @param mode モード
	 * @return セルの文字の色を背景色と同じにする場合は true
	 * @deprecated 共通親クラスのみでオーバーライドすることを想定（個別の画面では、
	 * {@link IfPriorCellConfig#getPriorReverseFG(int, MCColumnConfig, MCTable, MCMode)}
	 * または、
	 * {@link #getCustomReverseFG(int, MCColumnConfig, MCTable, MCMode)}
	 * を使うことを想定）
	 */
	@Deprecated
	protected boolean isReverseFG(
			int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
		
		IfPriorCellConfig[] pa = prioCellConfigHierarchy(table);
		for (int i = pa.length - 1; i >= 0; i--) {
			Boolean v = pa[i].getPriorReverseFG(index, column, table, mode);
			if (v != null) {
				return v;
			}
		}
		
		Boolean v = getCustomReverseFG(index, column, table, mode);
		return v != null ? v : false;
	}
	
	// セルコンフィグの多重化対応（ここまで）

}