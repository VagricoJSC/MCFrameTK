package mcframe.clientFXBA.FXBAP0050;
import mcframe.commonCore.annotation.EI;

@EI
public interface IfRLBase extends IfRLBase_FW {

}
