package mcframe.clientFXBA.FXBAP0050;

import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientCore.container.MCConstRow;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.commonCore.container.MCList;

public interface IfRLBase_FW {
	/**
	 * 更新直後の画面ステータス。
	 */
	public void setFIXStatus();

	/**
	 * 検索結果を表示し、値の編集を行うリスト。
	 * <P>テーブルに紐づくリストを指定する必要がある。</P>
	 */
	public MCList<? extends MCConstRow> getDtlL();

	public String getFIXStatus();

	public void setAdjustWidth();

	/** 
	 * tableをクリアが成功した場合の後処理 <p>
	 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス
	public boolean clearSub(MCTable table);

	/**
	 * rowを行コピー処理の後処理
	 * @param newRow 行コピーして新規に作成されたRow
	 */
	public <E extends MCConstRow> E copyRowSub(E newRow);

	/** キー変更を元に戻してよいかダイアログを出し、その時に「はい」が押下されたかどうか */
	public boolean confirmUndoKeyUpd();

	/**
	 * アプリケーションが使用するデフォルトのセルコンフィグ
	 * @deprecated 共通親クラスのみがオーバーライド呼び出し可能
	 */
	public FXBAP_CellConfig createDefaultAppCellConfig();

	/** DtlTableカラムのうち、指定カラムと変更前キー、更新関係のカラムを除いたカラムコンフィグの配列を返します。 */
	public MCColumnConfig[] getExptColumnConfigs(MCColumnConfig... cols);

	public String[] getDtlRKeyColumns();

	/**変更前キー項目名配列を返します。*/
	public String[] getBeforeKeyColumns(String[] keyCols);

	/**リストDtlLに関連付けられるTableを返します。*/
	@SuppressWarnings("unchecked")
	// 戻り値のMCTableのジェネリクス
	public MCTable getDtlTable();

	/**リストDtlLに関連付けられるTableをfillSpaceします。*/
	public void fillSpace();

	/**画面起動、画面クリア時のフォーカスを設定します。*/
	public void setOpenFocus();
	
	/**ソート順の設定をします。*/
	public void setSortColumn();
	
	/** tableの項目のカラムコンフィグの配列を返します。 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス、MCListのジェネリクス
	public MCColumnConfig[] getColumnConfigs(MCTable t, String... cols);

	/**toStringWithMsgLabelで作成された配列を改行で連結したStringを返します。*/
	public String toStringWithMsgLabelNoArray(int idx, MCColumnConfig... cols);

}
