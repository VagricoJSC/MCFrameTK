package mcframe.clientFXBA.FXBAP0050;

import static mcframe.commonFX.notice.FX_Msg.*;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0010.FXBAP_Updater;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCMessageList;

public class FXBAP_RLUpdater_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Updater<P, O> {
	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_RLUpdater_FW(P panel, O operation) {
		super(panel, operation);
		if (panel instanceof IfRLBase) {
			_implRLPanel = (IfRLBase) panel;
		}
		else {
			throw new MCAppException(FXBAP0077);
		}
	}

	protected IfRLBase _implRLPanel;

	/**
	 * チェック用のリストを返します。<p>
	 * 
	 */
	protected MCList getDtlLForUpdCheck() {
		if (_updChkList == null) {
			_updChkList = _implRLPanel.getDtlL().subList(MCRow.Status.CREATE,
					MCRow.Status.MODIFY);
		}
		return _updChkList;
	}

	protected MCList _updChkList;
	
	@Override
	protected void checkReq(MCMessageList msgList, MCContainer cont) {
		if (cont == _implRLPanel.getDtlL()) {
			msgList.addAll(panel.checkReq(getDtlLForUpdCheck()));
		}
		else {
			super.checkReq(msgList, cont);
		}
	}

	/** キーの重複チェック処理を追加しています。 */
	@Override
	protected void checkForCallStack(MCMessageList msgList) {
		
		super.checkForCallStack(msgList);
		checkDuplicate(msgList);

	}

	/** キーの重複チェックを行います。 */
	protected void checkDuplicate(MCMessageList msgList) {
		MCTable<?> tbl = _implRLPanel.getDtlTable();
		String[] keys = _implRLPanel.getDtlRKeyColumns();
		panel.checkDuplicate(msgList, tbl, keys);
	}

	@Override
	protected void setupUpParam(MCContainer cont) {
		if (cont == _implRLPanel.getDtlL()) {
			param().addUpBlock(panel.exceptEmpty(
					_implRLPanel.getDtlL()).statusChangedList());
		}
		else {
			super.setupUpParam(cont);
		}
	}

	/**
	 * 更新後のＧＵＩ部品のモード設定
	 */
	@Override
	protected void setMode() {
		super.setMode();
		
		setModeSub();
	}

	protected void setModeSub(){
		_implRLPanel.setFIXStatus();
	}

	/**
	 * 更新後のフォーカス移動を行います。
	 * 
	 */
	@Override
	protected void moveFocus() {
		super.moveFocus();
		
		moveFocusSub();
	}

	protected void moveFocusSub(){
		panel.focusFirstComponent();
	}

}
