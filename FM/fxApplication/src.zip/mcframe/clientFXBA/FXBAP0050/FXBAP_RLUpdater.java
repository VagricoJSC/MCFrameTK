package mcframe.clientFXBA.FXBAP0050;

import mcframe.clientCore.beans.*;

import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;

import mcframe.commonCore.annotation.EI;
@EI
public class FXBAP_RLUpdater<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_RLUpdater_FW<P, O> {
	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_RLUpdater(P panel, O operation) {
		super(panel, operation);
	}

}
