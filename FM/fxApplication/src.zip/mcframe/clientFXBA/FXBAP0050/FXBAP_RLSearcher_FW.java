package mcframe.clientFXBA.FXBAP0050;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil_FW.isNull;
import static mcframe.commonFX.notice.FX_Msg.*;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCAppException;

public class FXBAP_RLSearcher_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Searcher<P, O> {

	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_RLSearcher_FW(P panel, O operation) {
		super(panel, operation);
		if (panel instanceof IfRLBase) {
			_implRLPanel = (IfRLBase) panel;
		}
		else {
			throw new MCAppException(FXBAP0076);
		}
	}

	protected IfRLBase _implRLPanel;

	/**
	 * 検索後処理。下り電文を画面表示する前に加工します。
	 */
	@Override
	protected void afterCall() {
		super.afterCall();
		afterCallSub();

	}

	/**キー項目の値を、変更前キー項目に設定します。*/
	protected void afterCallSub() {
		MCContainer cont = param().getContainerParam().getDownBlock(0);

		if (cont instanceof MCList) {
			MCList<MCRow> l = (MCList) cont;

			String[] keyCols = _implRLPanel.getDtlRKeyColumns();
			String[] bKeyCols = _implRLPanel.getBeforeKeyColumns(keyCols);

			for (MCRow r : l) {
				for (int i = 0; i < keyCols.length; i++) {

					String kc = keyCols[i];
					String bkc = bKeyCols[i];

					r.setValue(bkc, r.getValue(kc));
				}

			}
		}
	}

	/**
	 * 検索後、DtlTableをfillSpaceして初期ステータスにします。
	 */
	@Override
	protected void setMode() {
		_implRLPanel.fillSpace();
		panel.mcInitStatus();
	}

	@Override
	protected void setModeNoDown() {
		_implRLPanel.fillSpace();
		panel.mcInitStatus();
	}

	/**
	 * 検索後、結果があった場合のフォーカス移動を行います。<p>
	 * 
	 */
	@Override
	protected void moveFocus() {
		super.moveFocus();
		
		MCTable<?> t = _implRLPanel.getDtlTable();
		if (!isNull(t.getList())) {
			t.selectLeftmostColumn(0);
		}
	}

	/**
	 * 検索後、結果がなかった場合のフォーカス移動を行います。<p>
	 * 
	 */
	@Override
	protected void moveFocusNoDown() {
		super.moveFocusNoDown();
		
		panel.focusFirstComponent();
	}

}
