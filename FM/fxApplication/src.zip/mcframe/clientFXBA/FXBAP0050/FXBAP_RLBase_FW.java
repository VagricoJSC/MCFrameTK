package mcframe.clientFXBA.FXBAP0050;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFXBA.FXBAP0060.FXBAP_RLUtil;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_RLBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_RLBase_FW extends FXBAP_RLBase_FW_A implements IfRLBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_RLBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	/**
	 * @deprecated 基本的に {@link #getRLUtil()}lを使うことを想定
	 */
	protected FXBAP_RLUtil _RLUtil;

	protected FXBAP_RLUtil getRLUtil() {
		if (_RLUtil == null) {
			_RLUtil = createInputSupportUtil();
		}
		return _RLUtil;
	}
	
	protected FXBAP_RLUtil createInputSupportUtil() {
		FXBAP_RLUtil p = new FXBAP_RLUtil();
		p.setPanel(this);
		return p;
	}
	
	
	
	
	/**
	 * 更新直後の画面ステータス。
	 */
	public abstract void setFIXStatus();

	/**
	 * 検索結果を表示し、値の編集を行うリスト。
	 * <P>テーブルに紐づくリストを指定する必要がある。</P>
	 */
	public abstract MCList<? extends MCConstRow> getDtlL();

	public String getFIXStatus() {
		return getRLUtil().defGetFIXStatus();
	}

	@Override
	public void setAdjustWidth() {
		super.setAdjustWidth();
		getRLUtil().defSetAdjustWidth();
	}

	@Override
	public void afterOpen() {
		super.afterOpen();
		getRLUtil().defAfterOpen();
		
	}
	
	
	/** 画面クリア後に初期ステータスにし、fillSpaceをしています。 */
	@Override
	public void screenClearSetDefault() {
		super.screenClearSetDefault();
		getRLUtil().defScreenClearSetDefault();

	}

	/** 画面Open後にfocusFirstComponentをしています。 */
	public void setOpenFocus() {
		getRLUtil().defSetOpenFocus();
	}
	
	/** 
	 * 行を削除します。 
	 * <p>
	 *  キー変更行である場合、キーを変更前にもどして削除ステータスにします。
	 */
	@Override
	public <E extends mcframe.clientCore.container.MCConstRow> E deleteRow(
			MCTable<E> table) {
		if(getRLUtil().defDeleteRow(table)){
			return super.deleteRow(table);
		}
		return null;
	}

	/** 
	 * tableをクリアします。 <p>
	 *  fillSpaceをし、初期ステータスにします。
	 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス
	@Override
	public boolean clear(MCTable table) {
		if (super.clear(table)) {
			return clearSub(table);
		}
		return false;
	}

	/** 
	 * tableをクリアします。 <p>
	 *  fillSpaceをし、初期ステータスにします。
	 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス
	public boolean clearSub(MCTable table) {
		return getRLUtil().defClearSub(table);
	}

	// ////////////////////

	/**
	 * rowをコピーします。
	 * <p>
	 * キー項目及び、更新日時などはコピーされません。
	 */
	@Override
	public <E extends MCConstRow> E copyRow(MCTable<E> t) {
		E dest = super.copyRow(t);
		return copyRowSub(dest);
	}

	/**
	 * rowを行コピー処理の後処理
	 * @param newRow 行コピーして新規に作成されたRow
	 */
	public <E extends MCConstRow> E copyRowSub(E row) {
		return getRLUtil().defCopyRowSub(row);

	}

	/** キー変更を元に戻してよいかダイアログを出します。 */
	public boolean confirmUndoKeyUpd() {
		return getRLUtil().defConfirmUndoKeyUpd();
	}

	// ////////////////
	// Dtlブロック関係
	// ////////////////
	/**リストDtlLに関連付けられるTableを返します。*/
	@SuppressWarnings("unchecked")
	// 戻り値のMCTableのジェネリクス
	public MCTable getDtlTable() {
		return getRLUtil().defGetDtlTable();
	}

	/**
	 * アプリケーションが使用するデフォルトのセルコンフィグ
	 * @deprecated 共通親クラスのみがオーバーライド呼び出し可能
	 */
	@Override
	public FXBAP_CellConfig createDefaultAppCellConfig() {
		return getRLUtil().defCreateDefaultAppCellConfig();
	}

	/**リストDtlLに関連付けられるTableをfillSpaceします。*/
	public void fillSpace() {
		getRLUtil().defFillSpace();
	}

	/**
	 * @deprecated {@link #fillSpace()}で実装してください。
	 */
	@Deprecated 
	@Override
	protected void fillSpaceForOpen() {
		getRLUtil().defFillSpaceForOpen();
	}
	
	
	/**キー項目でソートします。*/
	@Override
	public void setSortColumn() {
		getRLUtil().defSetSortColumn();
	}
	
	/** tableの項目のカラムコンフィグの配列を返します。 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス、MCListのジェネリクス
	public MCColumnConfig[] getColumnConfigs(MCTable t, String... cols) {
		return getRLUtil().defGetColumnConfigs(t, cols);
	}

	// ////////////////
	// その他
	// ////////////////
	/** DtlTableカラムのうち、指定カラムと変更前キー、更新関係のカラムを除いたカラムコンフィグの配列を返します。 */
	public MCColumnConfig[] getExptColumnConfigs(MCColumnConfig... cols) {
		return getRLUtil().defGetExptColumnConfigs(cols);
	}

	public String[] getDtlRKeyColumns() {
		return getRLUtil().defGetDtlRKeyColumns();
	}

	/**変更前キー項目名配列を返します。*/
	public String[] getBeforeKeyColumns(String[] keyCols) {
		return getRLUtil().defGetBeforeKeyColumns(keyCols);
	}

	/**toStringWithMsgLabelで作成された配列を改行で連結したStringを返します。*/
	public String toStringWithMsgLabelNoArray(int idx, MCColumnConfig... cols) {
		return getRLUtil().defToStringWithMsgLabelNoArray(idx, cols);
	}

}