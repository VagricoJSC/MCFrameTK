package mcframe.clientFXBA.FXBAP0100;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.layout.MCAutoLayout;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.Icon;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

import mcframe.clientCore.MCSingleStartup;
import mcframe.clientCore.beans.popup.MCMenu;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.popup.MCPopupMenu;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.MCMenuItemModel;
import mcframe.clientCore.resource.MCMenuModel;
import mcframe.clientCore.resource.MCMenuItemModel.MCMenuType;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0030.IfISPanelWithPaging;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0090.FXBAP_KeyAction;
import mcframe.clientFXUC.FXUCP0070.SrchCndInfo;
import mcframe.clientFXUC.FXUCP0090.FXUCP_VerticalViewUtil;
import mcframe.clientFXUC.FXUCP0210.FXUCP_PersonalizeUtil;
import mcframe.clientFXUC.FXUCP0220.FXUCP_PersonalizeGroupUtil;
import mcframe.clientFXUC.FXUCP0220.GrpInfoR;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_PopupConfig"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_PopupConfig_FW extends FXBAP_PopupConfig_FW_A
		implements MCAPListener {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_PopupConfig_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	/**
	 * テーブルのポップアップメニューを作成します。
	 *
	 * @param menu ポップアップメニュー
	 * @param table テーブル
	 * @return ポップアップメニュー
	 * @deprecated 特に機能が実装されていません。
	 */
	@Deprecated
	@Override
	public MCPopupMenu configurePopup(MCPopupMenu menu, MCPopupBeans compo) {
		if (compo instanceof MCButton) {
			return configurePopup(menu, (MCButton) compo);
		}
		return super.configurePopup(menu, compo);
	}

	/**
	 * 画面のポップアップメニューを作成します。
	 *
	 * @param menu ポップアップメニュー
	 * @param panel 画面
	 * @return ポップアップメニュー
	 */
	@Override
	public MCPopupMenu configurePopup(MCPopupMenu menu, MCRootPanel panel) {
		MCPopupMenu myMenu = super.configurePopup(menu, panel);

		if (ignorePanelPopup()) {
			return myMenu;
		}

		MCRootPanel bp = panel.getBaseRootPanel();

		if (!bp.isPersonalizeLoadError() && !ignoreSrchCnd(bp)) {
			setInputValMenu(myMenu, bp);
		}
		else {
			myMenu.removeMenu(getSrchCndMenu());
		}

		// ブックマーク管理
		if (!ignoreBookmark()) {
			setupBookMarkMenu(myMenu, bp);
		}
		else {
			myMenu.removeMenu(getBookMarkMenu());
		}

		if (!ignorePanelVerticalView(bp)) {
			MCTextPopupMenuItem itm = getPanelVerticalViewMenu();
			if (!myMenu.contains(itm)) {
				myMenu.add(itm);
				itm.updateResource();
			}
		}
		else {
			myMenu.removeMenuItem(getPanelVerticalViewMenu());
		}

		if (!ignoreScreenURL(bp)) {
			MCTextPopupMenuItem itm = getScreenURLMenu();
			if (!myMenu.contains(itm)) {
				myMenu.add(itm);
				itm.updateResource();
			}
		}
		else {
			myMenu.removeMenuItem(getScreenURLMenu());
		}

		// 検索枠展開
		if (!ignoreExpandMenu(bp)) {
			setExpandMenu(myMenu, bp);
		}
		else {
			myMenu.removeMenu(getExpandMenu());
		}

		if (!ignoreLayoutDebug(bp)) {
			MCTextPopupMenuItem itm = getLayoutDebugMenu();
			if (!myMenu.contains(itm)) {
				myMenu.add(itm);
				itm.updateResource();
			}
		}
		else {
			myMenu.removeMenuItem(getLayoutDebugMenu());
		}

		customPopup(myMenu, panel);
		return myMenu;
	}

	/**
	 * ポップアップメニューをカスタマイズするときにOverrideするメソッドです。<br>
	 * {@link #configurePopup(MCPopupMenu, MCRootPanel)}
	 * @param menu
	 * @param panel
	 */
	protected void customPopup(MCPopupMenu menu, MCRootPanel panel) {

	}

	/**
	 * テーブルの入力可能セルのポップアップメニューを作成します。
	 *
	 * @param menu ポップアップメニュー
	 * @param table テーブル
	 * @param index 行のインデックス値
	 * @param column テーブルカラム
	 * @deprecated 特に機能が実装されていません。
	 * @return ポップアップメニュー
	 */
	@Deprecated
	@Override
	public MCPopupMenu configurePopup(MCPopupMenu menu, MCTable table, int index,
			MCColumnConfig column) {
		MCPopupMenu myMenu = super.configurePopup(menu, table, index, column);
		return myMenu;
	}

	/**
	 * テーブルのポップアップメニューを作成します。<br>
	 * 特に理由がない限り {@link #customPopup(MCPopupMenu, MCTable)}でカスタマイズを
	 * 実装することを推奨します。
	 * @param menu ポップアップメニュー
	 * @param table テーブル
	 * @return ポップアップメニュー
	 */
	@Override
	public MCPopupMenu configurePopup(MCPopupMenu menu, MCTable table) {
		MCPopupMenu myMenu = super.configurePopup(menu, table);

		if (ignoreTablePopup()) {
			return myMenu;
		}

		if (!ignoreFindCell()) {
			MCTextPopupMenuItem itm = getFindCellMenu();
			if (!myMenu.contains(itm)) {
				_menu2Table.put(itm, table);
				myMenu.add(itm);
				itm.updateResource();
			}
		}
		else {
			myMenu.removeMenuItem(getFindCellMenu());
		}

		if (!ignoreTableVerticalView(table)) {
			MCTextPopupMenuItem itm = getTableVerticalViewMenu();
			if (!myMenu.contains(itm)) {
				_menu2Table.put(itm, table);
				myMenu.add(itm);
				itm.updateResource();
			}
		}
		else {
			myMenu.removeMenuItem(getTableVerticalViewMenu());
		}

		customPopup(myMenu, table);
		return myMenu;
	}

	/**
	 * ポップアップメニューをカスタマイズするときにOverrideするメソッドです。<br>
	 * {@link #configurePopup(MCPopupMenu, MCTable)}
	 * @param menu
	 * @param table
	 */
	protected void customPopup(MCPopupMenu menu, MCTable table) {

	}

	/**
	 * ボタンのポップアップメニューを作成します。<br>
	 * 特に理由がない限り {@link #customPopup(MCPopupMenu, MCButton)}でカスタマイズを
	 * 実装することを推奨します。
	 * @param menu ポップアップメニュー
	 * @param button ボタン
	 * @return ポップアップメニュー
	 */
	public MCPopupMenu configurePopup(MCPopupMenu menu, MCButton button) {
		MCPopupMenu myMenu = super.configurePopup(menu, button);
		customPopup(myMenu, button);
		return myMenu;
	}

	/**
	 * ポップアップメニューをカスタマイズするときにOverrideするメソッドです。<br>
	 * {@link #configurePopup(MCPopupMenu, MCButton)}
	 * @param menu
	 * @param button
	 */
	protected void customPopup(MCPopupMenu menu, MCButton button) {

	}

	/**
	 * @deprecated 親クラス用で使用しているキャッシュ用のインスタンスです。
	 */
	@Deprecated
	protected Map<MCTextPopupMenuItem, MCTable> _menu2Table = new HashMap<>();

	// ///////////////////////
	// ///////////////////////
	// ///////////////////////

	/**
	 * @deprecated 親クラス用で使用しているキャッシュ用のインスタンスです。
	 */
	@Deprecated
	protected Map<String, MCTextPopupMenuItem> _openPopupCache = new HashMap<>();

	/**
	 * @deprecated キャッシュ用のインスタンスです。
	 */
	@Deprecated
	protected Map<MCTextPopupMenuItem, MCButton> _menu2Button = new HashMap<>();

	/**
	 * 画面遷移のためのポップアップメニューを作成する簡易メソッドです。
	 * 過去に、同一のモジュールＩＤ 及び画面ＩＤでメニューを作成している場合は、
	 * そのインスタンスをメニューに追加します。<br>
	 * ラベル名は画面と同一となり、メニュー選択時のイベントは、
	 * {@link MCTable#getBaseRootPanel()}に通知されます。<br>
	 * <p>
	 * 以下、実装サンプル
	 * </p>
	 * <pre>
	 * public class MyPopup extends FXBAP_PopupConfig{
	 * 	protected void customPopup(MCPopupMenu menu, MCTable table) {
	 * 		super.customPopup(menu,table);
	 * 		// 常に表示される
	 * 		if (_hbp0010 == null) {
	 * 			_hbp0010 = addOpenPopupMenu(menu, table, "H", "HBP0010");
	 * 		}
	 * 		// flgによって追加する／しないを変える
	 * 		if (flg) {
	 * 			if (_hbp0020 == null) {
	 * 				_hbp0020 = addOpenPopupMenu(menu, table, "H", "HBP0020");
	 * 			}
	 * 			else {
	 * 				if (menu.contains(_hbp0020)) {
	 * 					menu.add(_hbp0020);
	 * 				}
	 * 			}
	 * 		}
	 * 		else {
	 * 			if (_hbp0020 != null) {
	 * 				menu.remove(_hbp0020);
	 * 			}
	 * 		}
	 * 	}
	 * }
	 * protected MCTextPopupMenuItem _hbp0010;
	 * protected MCTextPopupMenuItem _hbp0020;
	 *
	 * // イベントの実装
	 * public void doAPEvent1(MCAPBeans compo, MCEventInfo info) {
	 * 	super.doAPEvent(compo, info) {
	 * 	if (compo == _hbp0010) {
	 * 		openPanel("H", "HBP0010");
	 * 	}
	 * }
	 * // ポップアップコンフィグをテーブルにセット
	 * protected void setPopupConfig(MCPopupBeans beans) {
	 * 	if(beans == TargetTable){
	 * 		TargetTable.setPopupConfig(createPopupConfig());
	 * 	}
	 * 	else {
	 * 		super.setPopupConfig(beans);
	 * 	}
	 * }
	 * protected MCPopupConfig createPopupConfig(){
	 * 	return new MyPopup();
	 * }
	 * </pre>
	 * @param menu 追加先のポップアップメニュー
	 * @param table ポップアップメニューが配置されているテーブル
	 * @param moduleId 遷移先の画面のモジュールＩＤ
	 * @param screenId 遷移先の画面の画面ＩＤ
	 */
	protected MCTextPopupMenuItem addOpenPopupMenu(MCPopupMenu menu, MCTable table,
			String moduleId, String screenId) {

		// 本来はMCLabel用のキーだが、キャッシュのキーにも使う
		String key = MCConst.createKey(moduleId, screenId);

		MCTextPopupMenuItem item;
		item = _openPopupCache.get(key);
		if (item == null) {
			item = new MCTextPopupMenuItem(moduleId + "." + screenId);
			item.addAPListener(table.getBaseRootPanel());
			item.setText(MCConst.label.getLabel(key));
			menu.add(item);
			item.updateResource();
		}
		else {
			item.add(item);
		}
		return item;
	}

	/**
	 * 画面遷移のためのポップアップメニューを作成する簡易メソッドです。
	 * 過去に、同一のモジュールＩＤ 及び画面ＩＤでメニューを作成している場合は、
	 * そのインスタンスをメニューに追加します。<br>
	 * ラベル名は画面と同一となり、メニュー選択時のイベントは、
	 * 引数のパネルに通知されます。
	 * <p>
	 * 使用例が {@link #addOpenPopupMenu(MCPopupMenu, MCTable, String, String)} にあります。
	 * </p>
	 *
	 * @param menu 追加先のポップアップメニュー
	 * @param table パネル
	 * @param moduleId 遷移先の画面のモジュールＩＤ
	 * @param screenId 遷移先の画面の画面ＩＤ
	 */
	protected MCTextPopupMenuItem addOpenPopupMenu(MCPopupMenu menu, MCRootPanel panel,
			String moduleId, String screenId) {

		// 本来はMCLabel用のキーだが、キャッシュのキーにも使う
		String key = MCConst.createKey(moduleId, screenId);

		MCTextPopupMenuItem item;
		item = _openPopupCache.get(key);
		if (item == null) {
			item = new MCTextPopupMenuItem(moduleId + "." + screenId);
			item.addAPListener(panel);
			item.setText(MCConst.label.getLabel(key));
			menu.add(item);
			item.updateResource();
		}
		else {
			item.add(item);
		}
		return item;
	}

	// ///////////////////////
	// ///////////////////////
	// ///////////////////////

	@Override
	public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
		if (compo == getFindCellMenu()) {
			MCTable tbl = _menu2Table.get(compo);
			doAP_findCell(compo, info, tbl);
		}
		else if (compo == getSrchCndPanelMenu()) {
			doAP_srchCnd(info);
		}
		else if (compo == getSrchCndInitCndMenu()) {
			doAP_srchCndInitCnd(info);
		}
		else if (compo == getTableVerticalViewMenu()) {
			MCTable<?> tbl = _menu2Table.get(compo);
			doAP_tableVerticalView(compo, info, tbl);
		}
		else if (compo == getPanelVerticalViewMenu()) {
			doAP_panelVerticalView(info);
		}
		else if (compo == getScreenURLMenu()) {
			doAP_panelScreenURL(info);
		}
		else if (compo == getLayoutDebugMenu()) {
			doAP_panelLayoutDebug(info);
		}
		else if (compo == getAddBookMarkMenu()) {
			doAP_panelAddBookMark(info);
		}
		else if (compo == getOpenBookMarkMenu()) {
			doAP_panelOpenBookMark(info);
		}
		else if (compo == getExpandDefaultMenuItem()) {
			doAP_panelExpand(info, false);
		}
		else if (compo == getExpandNotCloseMenuItem()) {
			doAP_panelExpand(info, true);
		}
	}

	// ///////////////////////
	// ///////////////////////
	// ///////////////////////

	/**
	 * 「入力値設定」のポップアップメニューを設定します。
	 * @param myMenu ポップアップメニュー
	 * @param bp 画面
	 */
	protected void setInputValMenu(MCPopupMenu myMenu, MCRootPanel bp) {
		MCMenu m = getSrchCndMenu();
		if (!myMenu.contains(m)) {
			myMenu.add(m);
			m.updateResource();
		}

		m.removeAll();

		MCTextPopupMenuItem itm = getSrchCndPanelMenu();
		m.add(itm);
		itm.updateResource();

		Color fg = itm.getForeground();
		Color bg = itm.getBackground();
		Font f = itm.getFont();

		IfSrchCndBase p = (IfSrchCndBase) bp;
		List<SrchCndInfo> l = p.getSrchCndInfoListWithoutBarcode();

		int cnt = 0;

		for (SrchCndInfo i : l) {
			String n = i.getSettingInfoName();
			if (isNull(n)) {
				continue;
			}

			cnt++;

			itm = new MCTextPopupMenuItem(
					MCConst.createKey(i.getSettingUnitType(), i.getSettingInfoID()));
			itm.addAPListener(new SrchCndMenuAPListener());
			m.add(itm);
			itm.updateResource();

			itm.setForeground(fg);
			itm.setBackground(bg);
			itm.setFont(f);

			itm.setText(i.getSettingInfoUnitName());
		}

		itm = getSrchCndInitCndMenu();
		m.add(itm);
		itm.updateResource();

		if (cnt > 0) {
			m.addSeparator("rootpanel.POPUP_SRCH_CND_SEPARATOR");
		}
	
	}
	
	/**
	 * 画面の「入力値設定」メニューアイテムを無効にする場合は true を返します。
	 *
	 * @param panel 画面
	 * @return 画面の「入力値設定」メニューアイテムを無効にする場合は true
	 */
	protected boolean ignoreSrchCnd(MCRootPanel panel) {
		if (_ignoreSrchCnd) {
			return true;
		}
		if (!(panel instanceof IfSrchCndBase)) {
			return true;
		}
		return ((IfSrchCndBase) panel).ignoreSrchCnd();
	}

	/**
	 * 画面の「入力値設定」メニューアイテムの無効フラグです。
	 * @deprecated {@link #ignoreSrchCnd(MCRootPanel)} を利用してください。
	 */
	@Deprecated
	protected boolean _ignoreSrchCnd = false;

	/**
	 * 画面の「入力値設定」メニューアイテムを無効にする場合は true 設定します。
	 *
	 * @param flg 画面の「入力値設定」メニューアイテムを無効にする場合は true
	 */
	public void ignoreSrchCnd(boolean flg) {
		_ignoreSrchCnd = flg;
	}

	// 7.0.1 パーソナライズグループで使用するためpublicにする。
	public boolean isIgnoreSrchCnd(MCRootPanel panel) {
		return ignoreSrchCnd(panel);
	}

	/**
	 * 「検索条件」のメニューです。
	 * @deprecated {@link #getSrchCndMenu()} を使用してください。
	 */
	@Deprecated
	protected MCMenu _popupSrchCnd = null;

	/**
	 * 「検索条件」のメニューを返します。
	 *
	 * @return 「検索条件」のメニュー
	 */
	public MCMenu getSrchCndMenu() {
		if (_popupSrchCnd == null) {
			_popupSrchCnd = new MCMenu("rootpanel.POPUP_SRCH_CND");
		}
		return _popupSrchCnd;
	}

	/**
	 * 「検索条件登録」のポップアップメニューです。
	 * @deprecated {@link #getSrchCndPanelMenu()} を使用してください。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupSrchCndPanel = null;

	/**
	 * 「検索条件登録」のポップアップメニューを返します。
	 *
	 * @return 「検索条件登録」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getSrchCndPanelMenu() {
		if (_popupSrchCndPanel == null) {
			_popupSrchCndPanel = new MCTextPopupMenuItem(
					"rootpanel.POPUP_SRCH_CND_PANEL");
			_popupSrchCndPanel.addAPListener(this);
			_popupSrchCndPanel.updateResource();
		}
		return _popupSrchCndPanel;
	}

	/**
	 * 「検索条件を初期状態に戻す」のポップアップメニューです。
	 * @deprecated {@link #getSrchCndInitCndMenu()} を使用してください。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupSrchCndInitCnd = null;

	/**
	 *  「検索条件を初期状態に戻す」のポップアップメニューを返します。
	 *
	 * @return  「検索条件を初期状態に戻す」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getSrchCndInitCndMenu() {
		if (_popupSrchCndInitCnd == null) {
			_popupSrchCndInitCnd = new MCTextPopupMenuItem(
					"rootpanel.POPUP_SRCH_CND_INIT_CND");
			_popupSrchCndInitCnd.addAPListener(this);
			_popupSrchCndInitCnd.updateResource();
		}
		return _popupSrchCndInitCnd;
	}

	public class SrchCndMenuAPListener implements MCAPListener {

		@Override
		public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
			String n = compo.getName();
			IfSrchCndBase p = (IfSrchCndBase) compo.getBaseRootPanel();
			List<SrchCndInfo> l = p.getSrchCndInfoList();
			for (SrchCndInfo i : l) {
				if (isSame(n, MCConst.createKey(i.getSettingUnitType(),
						i.getSettingInfoID()))) {
					p._applySrchCndInfo(i);
					return;
				}
			}
		}
	}

	/**
	 * 入力値設定のポップアップメニューが選択されたときに実行されます。
	 *
	 * @param info イベント情報
	 */
	public void doAP_srchCnd(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		MCRootPanel p = bp.createPanel("FS", "FSBAP0310", MCRootPanel.MODELESS);
		bp.showChildPanel(p, MCRootPanel.SCREEN_SINGLE);
	}

	/**
	 * 「検索条件を初期状態に戻す」のポップアップメニューが選択されたときに実行されます。
	 *
	 * @param info イベント情報
	 */
	protected void doAP_srchCndInitCnd(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		if (bp instanceof IfSrchCndBase) {
			IfSrchCndBase p = (IfSrchCndBase) bp;
			MCMessage m = p._applySrchCndInfo(null);
			if (m != null) {
				bp.dialog(m);
			}
		}
	}

	// ///////////////////////
	// ///////////////////////
	// ///////////////////////

	/**
	 * 「ブックマーク」のポップアップメニューを設定します。
	 *
	 * @param myMenu ポップアップメニュー
	 * @param bp 画面
	 */
	protected void setupBookMarkMenu(MCPopupMenu myMenu, MCRootPanel bp) {
		if (!MCMenuModel.isLoad()
				|| MCMenuModel.getItemModel(bp.getModuleID(), bp.getScreenID()) == null) {
			return;
		}
		MCRootPanel bm = MCBeansUtil.getRootPanel("FS", "FSBCP0090");
		if (bm == null) {
			MCMenu bk = getBookMarkMenu();
			if (!myMenu.contains(bk)) {
				myMenu.add(bk);
				bk.updateResource();
			}
			if (!bk.contains(getAddBookMarkMenu())) {
				bk.add(getAddBookMarkMenu());
			}
			setupSrchCndBookMarkMenuItem(myMenu, bk, bp);
			setupPersonalizeGroupBookMarkMenuItem(myMenu, bk, bp);
			if (!bk.contains(getOpenBookMarkMenu())) {
				bk.addSeparator("rootpanel.POPUP_OPEN_BOOKMARK");
				bk.add(getOpenBookMarkMenu());
			}
		}
		else {
			myMenu.removeMenu(getBookMarkMenu());
		}
	}

	/**
	 * 「ブックマーク」のメニューです。
	 * @deprecated {@link #getBookMarkMenu()} を使用してください。
	 */
	@Deprecated
	protected MCMenu _popupBookMark = null;

	/**
	 * 「ブックマーク」のメニューを返します。
	 *
	 * @return 「ブックマーク」のメニュー
	 */
	public MCMenu getBookMarkMenu() {
		if (_popupBookMark == null) {
			_popupBookMark = new MCMenu("rootpanel." + MCBeansConsts.POPUP_BOOKMARK);
		}
		return _popupBookMark;
	}

	/**
	 * 「追加」のポップアップメニューです。
	 * @deprecated {@link #getAddBookMarkMenu()} を使用してください。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupAddBookMark = null;

	/**
	 * 「追加」のポップアップメニューを返します。
	 *
	 * @return 「追加」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getAddBookMarkMenu() {
		if (_popupAddBookMark == null) {
			_popupAddBookMark = new MCTextPopupMenuItem("rootpanel.POPUP_ADD_BOOKMARK");
			_popupAddBookMark.addAPListener(this);
			_popupAddBookMark.updateResource();
		}
		return _popupAddBookMark;
	}

	/**
	 * 「追加」メニューを選択したときの処理です。
	 *
	 * @param info イベントインフォ
	 */
	public void doAP_panelAddBookMark(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		MCMenuItemModel model = new MCMenuItemModel(null, MCMenuType.ITEM);
		model.setAttribute(MCMenuItemModel.ATT_MODULE, bp.getModuleID());
		model.setAttribute(MCMenuItemModel.ATT_SCREEN, bp.getScreenID());
		model.setAttribute(MCMenuItemModel.ATT_TITLE, bp.getTitle());
		model.enable(true);
		model.authority(true);

		mcframe.clientCore.resource.MCConst.menu.addBookMark(model);
	}

	/**
	 * 「入力値設定を指定して追加」のメニューを設定します。
	 *
	 * @param myMenu ポップアップメニュー
	 * @param bkMenu ブックマークメニュー
	 * @param bp 画面
	 */
	protected void setupSrchCndBookMarkMenuItem(MCPopupMenu myMenu, MCMenu bkMenu,
			MCRootPanel bp) {
		if (!bp.isPersonalizeLoadError() && !ignoreSrchCnd(bp)) {
			IfSrchCndBase p = (IfSrchCndBase) bp;
			List<SrchCndInfo> l = p.getSrchCndInfoListWithoutBarcode();

			MCMenu menu = getSrchCndBookMarkMenu();
			if (l.isEmpty()) {
				myMenu.removeMenu(menu);
				return;
			}
			if (!bkMenu.contains(menu)) {
				bkMenu.add(menu);
				menu.updateResource();
			}
			else {
				menu.removeAll();
			}

			for (SrchCndInfo i : l) {
				String n = i.getSettingInfoName();
				if (isNull(n)) {
					continue;
				}

				MCTextPopupMenuItem itm = new MCTextPopupMenuItem(i.getSettingInfoID());
				itm.addAPListener(new SrchCndBookMarkMenuAPListener());
				menu.add(itm);
				itm.updateResource();

				itm.setText(i.getSettingInfoUnitName());
			}
		}
	}

	/**
	 * 「入力値設定を指定して追加」のメニューです。
	 * @deprecated {@link #getSrchCndBookMarkMenu()} を使用してください。
	 */
	@Deprecated
	protected MCMenu _popupSrchCndBookMark = null;

	/**
	 * 「入力値設定を指定して追加」のメニューを返します。
	 *
	 * @return 「入力値設定を指定して追加」のメニュー
	 */
	public MCMenu getSrchCndBookMarkMenu() {
		if (_popupSrchCndBookMark == null) {
			_popupSrchCndBookMark = new MCMenu("rootpanel.POPUP_SRCH_CND_BOOKMARK");
		}
		return _popupSrchCndBookMark;
	}

	/**
	 * 「入力値設定を指定して追加」のリスナクラスです。
	 */
	public class SrchCndBookMarkMenuAPListener implements MCAPListener {

		@Override
		public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
			MCRootPanel bp = info.getComponent().getBaseRootPanel();
			MCMenuItemModel model = new MCMenuItemModel(null, MCMenuType.ITEM);
			model.setAttribute(MCMenuItemModel.ATT_MODULE, bp.getModuleID());
			model.setAttribute(MCMenuItemModel.ATT_SCREEN, bp.getScreenID());
			model.setAttribute(MCMenuItemModel.ATT_TITLE, bp.getTitle());
			model.setAttribute(MCMenuItemModel.ATT_METHOD, compo.getName());
			model.enable(true);
			model.authority(true);

			mcframe.clientCore.resource.MCConst.menu.addBookMark(model);
		}
	}

	/**
	 * 「パーソナライズグループを指定して追加」のメニューを設定します。
	 *
	 * @param myMenu ポップアップメニュー
	 * @param bkMenu ブックマークメニュー
	 * @param bp 画面
	 */
	protected void setupPersonalizeGroupBookMarkMenuItem(MCPopupMenu myMenu,
			MCMenu bkMenu, MCRootPanel bp) {
		if (!bp.isPersonalizeLoadError()) {
			MCList<GrpInfoR> l = FXUCP_PersonalizeGroupUtil
					.getPersonalizeGroupList(bp.getModuleID(), bp.getScreenID());

			MCMenu menu = getPersonalizeGroupBookMarkMenu();
			if (l.isEmpty()) {
				myMenu.removeMenu(menu);
				return;
			}
			if (!bkMenu.contains(menu)) {
				bkMenu.add(menu);
				menu.updateResource();
			}
			else {
				menu.removeAll();
			}

//			l.sort(GrpInfoR.$per_grp_nm);
			for (GrpInfoR i : l) {
				String n = i.per_grp_nm();
				if (isNull(n)) {
					continue;
				}

				MCTextPopupMenuItem itm = new MCTextPopupMenuItem(i.per_grp_id());
				itm.addAPListener(new PersonalizeGroupBookMarkMenuAPListener());
				menu.add(itm);
				itm.updateResource();

				itm.setText(FXUCP_PersonalizeUtil.getSettingInfoUnitName(i.per_grp_nm(),
						i.setting_unit_type()));
//				itm.setText(i.per_grp_nm());
			}
		}
	}

	/**
	 * 「パーソナライズグループを指定して追加」のメニューです。
	 * @deprecated {@link #getPersonalizeGroupBookMarkMenu()} を使用してください。
	 */
	@Deprecated
	protected MCMenu _popupPersonalizeGroupBookMark = null;

	/**
	 * 「パーソナライズグループを指定して追加」のメニューを返します。
	 *
	 * @return 「パーソナライズグループを指定して追加」のメニュー
	 */
	public MCMenu getPersonalizeGroupBookMarkMenu() {
		if (_popupPersonalizeGroupBookMark == null) {
			_popupPersonalizeGroupBookMark = new MCMenu(
					"rootpanel.POPUP_PERSONALIZE_GROUP_BOOKMARK");
		}
		return _popupPersonalizeGroupBookMark;
	}

	/**
	 * 「パーソナライズグループを指定して追加」のリスナクラスです。
	 */
	public class PersonalizeGroupBookMarkMenuAPListener implements MCAPListener {

		@Override
		public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
			MCRootPanel bp = info.getComponent().getBaseRootPanel();
			MCMenuItemModel model = new MCMenuItemModel(null, MCMenuType.ITEM);
			model.setAttribute(MCMenuItemModel.ATT_MODULE, bp.getModuleID());
			model.setAttribute(MCMenuItemModel.ATT_SCREEN, bp.getScreenID());
			model.setAttribute(MCMenuItemModel.ATT_TITLE, bp.getTitle());
			model.setAttribute(MCMenuItemModel.ATT_CLASSNAME, compo.getName());
			model.enable(true);
			model.authority(true);

			mcframe.clientCore.resource.MCConst.menu.addBookMark(model);
		}
	}

	/**
	 * 「メニュー・ブックマーク管理」のポップアップメニューです。
	 * @deprecated {@link #getOpenBookMarkMenu()} を使用してください。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupOpenBookMark = null;

	/**
	 * 「メニュー・ブックマーク管理」のポップアップメニューを返します。
	 *
	 * @return 「メニュー・ブックマーク管理」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getOpenBookMarkMenu() {
		if (_popupOpenBookMark == null) {
			_popupOpenBookMark = new MCTextPopupMenuItem("rootpanel.POPUP_OPEN_BOOKMARK");
			_popupOpenBookMark.addAPListener(this);
			_popupOpenBookMark.updateResource();
		}
		return _popupOpenBookMark;
	}

	/**
	 * 「メニュー・ブックマーク管理」を選択したときの処理です。
	 *
	 * @param info イベントインフォ
	 */
	public void doAP_panelOpenBookMark(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		MCRootPanel p = bp.createPanel("FS", "FSBCP0090", MCFrameType.MODELESS);
		bp.showPanel(p, MCRootPanel.SINGLE);
	}

	// ///////////////////////
	// ///////////////////////
	// ///////////////////////

	/**
	 * テーブルの「セル検索」メニューアイテムを無効にする場合は true を返します。
	 * 
	 * @return テーブルの「セル検索」メニューアイテムを無効にする場合は true
	 */
	protected boolean ignoreFindCell() {
		return _ignoreFindCell;
	}

	/**
	 * テーブルの「セル検索」メニューアイテムの無効フラグです。
	 * 
	 * @deprecated 基本的に {@link #ignoreFindCell()} を使用する
	 */
	@Deprecated
	protected boolean _ignoreFindCell = false;

	/**
	 * テーブルの「セル検索」メニューアイテムを無効にする場合は true を設定します。
	 * 
	 * @param flg 「セル検索」メニューアイテムを無効にする場合は true
	 */
	public void ignoreFindCell(boolean flg) {
		_ignoreFindCell = flg;
	}

	/**
	 * @deprecated {@link #getFindCellMenu()}を使うことを想定
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupFindCell;

	/**
	 * 「セル検索」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getFindCellMenu() {
		if (_popupFindCell == null) {
			_popupFindCell = new MCTextPopupMenuItem("table.POPUP_FIND_CELL");
			_popupFindCell.addAPListener(this);
			_popupFindCell.updateResource();
		}
		return _popupFindCell;
	}

	public void doAP_findCell(MCAPBeans compo, MCEventInfo info, MCTable tbl) {
		FXBAP_KeyAction a = new FXBAP_KeyAction();
		a.findCell(tbl);
	}

	/**
	 * テーブルの「縦表示」メニューアイテムの無効フラグです。
	 * @deprecated 基本的に {@link #ignoreTableVerticalView(MCTable)} を使用する
	 */
	@Deprecated
	protected boolean _ignoreTableVerticalView = false;

	/**
	 * テーブルの「縦表示」メニューアイテムを無効にする場合は true を返します。
	 *
	 * @param tbl テーブル
	 * @return テーブルの「縦表示」メニューアイテムを無効にする場合は true
	 */
	protected boolean ignoreTableVerticalView(MCTable<?> tbl) {
		if (!(tbl.getBaseRootPanel() instanceof FXBAP_PanelBase)
				|| !(tbl.getCellConfig() instanceof FXBAP_CellConfig)) {
			return true;
		}
		return _ignoreTableVerticalView;
	}

	/**
	 * テーブルの「縦表示」メニューアイテムを無効にする場合は true を設定します。
	 * 
	 * @param flg テーブルの「縦表示」メニューアイテムを無効にする場合は true
	 */
	public void ignoreTableVerticalView(boolean flg) {
		_ignoreTableVerticalView = flg;
	}

	/**
	 * テーブルの「縦表示」のポップアップメニューです。
	 * @deprecated {@link #getTableVerticalViewMenu()} を利用することを想定。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupTableVerticalView;

	/**
	 * テーブルの「縦表示」のポップアップメニューを返します。
	 *
	 * @return テーブルの「縦表示」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getTableVerticalViewMenu() {
		if (_popupTableVerticalView == null) {
			_popupTableVerticalView = new MCTextPopupMenuItem(
					"table.POPUP_VERTICAL_VIEW");
			_popupTableVerticalView.addAPListener(this);
			_popupTableVerticalView.updateResource();
		}
		return _popupTableVerticalView;
	}

	/**
	 * テーブルの「縦表示」のポップアップメニューが選択されたときに実行されます。
	 *
	 * @param info イベント情報
	 */
	public void doAP_tableVerticalView(MCAPBeans compo, MCEventInfo info,
			MCTable<?> tbl) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		MCRootPanel p = bp.createPanel(
				"FS", "FSBAP0370", MCRootPanel.SCREEN_MODAL, FXBAP_PanelBase.T1, null,
				tbl);
		bp.showChildPanel(p, MCRootPanel.MULTI);
	}

	/**
	 * 画面の「縦表示」メニューアイテムの無効フラグです。
	 * 
	 * @deprecated 基本的に {@link #ignorePanelVerticalView(MCRootPanel)} を使用する
	 */
	@Deprecated
	protected boolean _ignorePanelVerticalView = false;

	/**
	 * 画面の「縦表示」メニューアイテムを無効にする場合は true を返します。
	 *
	 * @param pnl 画面
	 * @return 画面の「縦表示」メニューアイテムを無効にする場合は true
	 */
	protected boolean ignorePanelVerticalView(MCRootPanel pnl) {
		if (!(pnl instanceof FXBAP_PanelBase)) {
			return true;
		}
		if (!FXUCP_VerticalViewUtil.isTargetPanel(pnl)) {
			return true;
		}
		return _ignorePanelVerticalView;
	}

	/**
	 * 画面の「縦表示」メニューアイテムを無効にする場合は true を設定します。
	 * 
	 * @param flg 画面の「縦表示」メニューアイテムを無効にする場合は true
	 */
	public void ignorePanelVerticalView(boolean flg) {
		_ignorePanelVerticalView = flg;
	}

	/**
	 * 画面の「縦表示」のポップアップメニューです。
	 * @deprecated {@link #getPanelVerticalViewMenu()} を利用することを想定。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupPanelVerticalView;

	/**
	 * 画面の「縦表示」のポップアップメニューを返します。
	 *
	 * @return 画面の「縦表示」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getPanelVerticalViewMenu() {
		if (_popupPanelVerticalView == null) {
			_popupPanelVerticalView = new MCTextPopupMenuItem(
					"rootpanel.POPUP_VERTICAL_VIEW");
			_popupPanelVerticalView.addAPListener(this);
			_popupPanelVerticalView.updateResource();
		}
		return _popupPanelVerticalView;
	}

	/**
	 * 画面の「縦表示」のポップアップメニューが選択されたときに実行されます。
	 *
	 * @param info イベント情報
	 */
	public void doAP_panelVerticalView(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		MCRootPanel p = bp.createPanel(
				"FS", "FSBAP0380", MCRootPanel.SCREEN_MODAL, FXBAP_PanelBase.T1);
		bp.showChildPanel(p, MCRootPanel.MULTI);
	}

	/**
	 * ポップアップメニューに「縦表示」を出さないかどうか
	 * @param flg 「縦表示」を出さない場合は true 出す場合は false
	 */
	public void ignoreVerticalView(boolean flg) {
		ignoreTableVerticalView(flg);
		ignorePanelVerticalView(flg);
	}

	/**
	 * 画面の「画面のURLをコピー」メニューアイテムの無効フラグです。
	 * @deprecated 基本的に {@link #ignoreScreenURL(MCRootPanel)} を使用する
	 */
	@Deprecated
	protected boolean _ignoreScreenURL = false;

	/**
	 * 画面の「画面のURLをコピー」メニューアイテムを無効にする場合は true を返します。
	 *
	 * @param pnl 画面
	 * @return 画面の「画面のURLをコピー」メニューアイテムを無効にする場合は true
	 */
	protected boolean ignoreScreenURL(MCRootPanel pnl) {
		if (!MCSingleStartup.isPortMode() || !(pnl instanceof FXBAP_PanelBase)
				|| !(pnl instanceof IfSrchCndBase)) {
			return true;
		}
		return _ignorePanelVerticalView;
	}

	/**
	 * 画面の「画面のURLをコピー」メニューアイテムを無効にする場合は true を設定します。
	 * 
	 * @param flg 画面の「画面のURLをコピー」メニューアイテムを無効にする場合は true
	 */
	public void ignoreScreenURL(boolean flg) {
		_ignorePanelVerticalView = flg;
	}

	/**
	 * 画面の「画面のURLをコピー」のポップアップメニューです。
	 * @deprecated {@link #getScreenURLMenu()} を利用することを想定。
	 */
	@Deprecated
	protected MCTextPopupMenuItem _popupScreenURL;

	/**
	 * 画面の「画面のURLをコピー」のポップアップメニューを返します。
	 *
	 * @return 画面の「画面のURLをコピー」のポップアップメニュー
	 */
	public MCTextPopupMenuItem getScreenURLMenu() {
		if (_popupScreenURL == null) {
			_popupScreenURL = new MCTextPopupMenuItem("rootpanel.POPUP_SCREEN_URL");
			_popupScreenURL.addAPListener(this);
			_popupScreenURL.updateResource();
		}
		return _popupScreenURL;
	}

	/**
	 * 画面の「画面のURLをコピー」のポップアップメニューが選択されたときに実行されます。
	 *
	 * @param info イベント情報
	 */
	public void doAP_panelScreenURL(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		if (!(bp instanceof IfSrchCndBase) || !(bp instanceof FXBAP_PanelBase)) {
			return;
		}

		FXBAP_PanelBase pb = (FXBAP_PanelBase) bp;
		String url = pb.getScreenURL();
		if (url != null) {
			// クリップボードにURLをコピー
			try {
				Clipboard clp = Toolkit.getDefaultToolkit().getSystemClipboard();
				clp.setContents(new StringSelection(url), null);
			}
			catch (java.lang.IllegalStateException e) {
				// メモ：何らかの原因（多くは何かのプログラム（含むMCFrame以外のプログラム）の不具合）で
				// クリップボードが空にできない状況が発生する場合がある。
				// その時に以下の例外が発生する。
				// java.lang.IllegalStateException: cannot open system clipboard
				MCLog.write(e);
				//throw new MCAppException(e);
			}
		}
	}

/************************************** 検索枠展開 ************/
	/**
	 * 「検索枠展開」のポップアップメニューを設定します。
	 * @param myMenu ポップアップメニュー
	 * @param bp 画面
	 */
	protected void setExpandMenu(MCPopupMenu myMenu, MCRootPanel bp) {
		MCMenu mn = getExpandMenu();
		if (!myMenu.contains(mn)) {
			myMenu.add(mn);
			mn.updateResource();
		}
		MCTextPopupMenuItem itm = getExpandDefaultMenuItem();
		if (!mn.contains(itm)) {
			mn.add(itm);
			mn.updateResource();
		}
		itm = getExpandNotCloseMenuItem();
		if (!mn.contains(itm)) {
			mn.add(itm);
			mn.updateResource();
		}
		// 設定中のモードにアイコンを付ける
		if (bp instanceof mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase) {
			mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase p 
				= (mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase)bp;

			if (p.getExpandMode()) {
				getExpandNotCloseMenuItem().setIcon("POPUP_SELECT");
				getExpandDefaultMenuItem().setIcon((Icon) null);
			}
			else {
				getExpandNotCloseMenuItem().setIcon((Icon) null);
				getExpandDefaultMenuItem().setIcon("POPUP_SELECT");
			}
		}
	}

	@Deprecated
	protected MCMenu _popupExpandMenu;
	@Deprecated
	protected MCTextPopupMenuItem _popupExpandDefaultMenuItem;
	@Deprecated
	protected MCTextPopupMenuItem _popupExpandNotCloseMenuItem;

	/**
	 * 「検索枠展開」ポップアップメニューを返します。
	 * @since  7.0.1.2
	 * @return ポップアップメニューアイテム
	 */
	public MCMenu getExpandMenu() {
		if (_popupExpandMenu == null) {
			_popupExpandMenu = new MCMenu("rootpanel.POPUP_EXPAND");
		}
		return _popupExpandMenu;
	}

	/**
	 * 「検索枠展開-デフォルト」のポップアップメニューアイテムを返します。
	 * @since  7.0.1.2
	 * @return ポップアップメニューアイテム
	 */
	public MCTextPopupMenuItem getExpandDefaultMenuItem() {
		if (_popupExpandDefaultMenuItem == null) {
			_popupExpandDefaultMenuItem = new MCTextPopupMenuItem(
					"rootpanel.POPUP_EXPAND_DEFAULT");
			_popupExpandDefaultMenuItem.addAPListener(this);
			_popupExpandDefaultMenuItem.updateResource();
		}
		return _popupExpandDefaultMenuItem;
	}

	/**
	 * 「検索枠展開-自動で閉じない」のポップアップメニューアイテムを返します。
	 * @since  7.0.1.2
	 * @return ポップアップメニューアイテム
	 */
	public MCTextPopupMenuItem getExpandNotCloseMenuItem() {
		if (_popupExpandNotCloseMenuItem == null) {
			_popupExpandNotCloseMenuItem = new MCTextPopupMenuItem(
					"rootpanel.POPUP_EXPAND_NOT_CLOSE");
			_popupExpandNotCloseMenuItem.addAPListener(this);
			_popupExpandNotCloseMenuItem.updateResource();
		}
		return _popupExpandNotCloseMenuItem;
	}
	
	/**
	 * 「検索枠展開」メニューを無効にする場合は true を返します。<p>
	 * 埋め込み画面にFXBAP0130（検索枠展開部品）が無い場合はtrueを返します。
	 *
	 * @since     7.0.1.2
	 * @param panel 画面
	 * @return　「検索枠展開」メニューを無効にする場合は true
	 */
	protected boolean ignoreExpandMenu(MCRootPanel panel) {
		// TODO 再帰的に埋め込み画面を探したい
		int cnt = (int) Arrays.stream(panel.getPartsPanels())
				.filter(p -> p instanceof mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit)
				.count();
		return (cnt < 1);
	}

	/**
	 * 「検索枠展開」のメニューアイテムを選択したときの処理です。
	 * @since     7.0.1.2
	 * @param info イベント情報
	 * @param mode 検索枠を自動で閉じるかどうか
	 */
	public void doAP_panelExpand(MCEventInfo info, boolean mode) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		if (bp instanceof mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase) {
			mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase p =
					(mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase) bp;
			p.setExpandMode(mode);
		}
	}
	
	/**
	 * ボタンの配置されている画面が入力補助画面かどうか返します。
	 *
	 * @param b ボタン
	 * @return 入力補助画面に配置されている場合true
	 */
	protected boolean isISPanel(MCButton b) {
		MCRootPanel rootpanel = MCBeansUtil.getBaseRootPanel(b);
		return rootpanel instanceof IfISPanelWithPaging;
	}

	// ここからレイアウトデバッグメソッド
	protected boolean ignoreLayoutDebug(MCRootPanel pnl) {
		boolean b = MCConfig.common.getBoolean("log.devlog_layout");
		return b == false;
	}

	protected MCTextPopupMenuItem _popupLayoutDebug;

	public MCTextPopupMenuItem getLayoutDebugMenu() {
		if (_popupLayoutDebug == null) {
			_popupLayoutDebug = new MCTextPopupMenuItem("rootpanel.POPUP_LAYOUT_DEBUG");
			_popupLayoutDebug.addAPListener(this);
			_popupLayoutDebug.updateResource();
		}
		return _popupLayoutDebug;
	}

	public void doAP_panelLayoutDebug(MCEventInfo info) {
		MCRootPanel bp = info.getComponent().getBaseRootPanel();
		MCAutoLayout.checkOverrap(bp);
	}
	// ここまでレイアウトデバッグメソッド
}