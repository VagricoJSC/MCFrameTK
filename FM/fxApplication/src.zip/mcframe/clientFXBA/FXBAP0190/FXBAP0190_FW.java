package mcframe.clientFXBA.FXBAP0190;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.MCValueSupply;

import javax.swing.Box;
import javax.swing.BoxLayout;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0190"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0190_FW extends FXBAP0190_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * ラベル
	 */
	public MCLabel Value_value_Label = null;

	/**
	 * パラメータ
	 */
	protected MCValueSupply.DateVS _param = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0190_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXBAP0190_FW(mcframe.clientFXBA.FXBAP0190.ValueR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		super.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BoxLayout(ValuePanel, BoxLayout.X_AXIS));

		Value_value_Label = beansFactory.createLabel("Value.value_Label");

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// Value_value.setMaximumSize(Value_value.getPreferredSize());

		ValuePanel.add(Value_value_Label);
		ValuePanel.add(_createRigidArea(LAYOUT_MARGIN, LAYOUT_MARGIN, 100, null));
//		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_value);

		// 日付フィールドの幅を調整する場合はこの行のコメントアウトを外す。
		//_putMaxMap(Value_value, Value_value.getPreferredSize());

		// 7013-0007 ここまで

	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return new MCModeBeans[] { Value_value };
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param };
	}

	@Override
	public void setParam(MCValueSupply...param) {
		_param = (MCValueSupply.DateVS) param[0];
		Value_value_Label.setText(_param.name());	// 表示名称の設定
		Value_value.setMessageName(_param.name());	// メッセージ用表示名称の設定

		// パラメータの型に応じてMCDateに変換
		MCDate value = (_param instanceof MCValueSupply.TimestampVS)
				? MCDate.valueOf((MCTimestamp)_param.value())
				: (MCDate) _param.value();
		getValueR().value(value);
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		return (_param.required() && getValueR().value() == null)
				? Value_value : null;
	}

	@Override
	public void updateParam() {
		// パラメータの型に応じてMCTimestampに変換
		_param.value((_param instanceof MCValueSupply.TimestampVS)
				? MCTimestamp.valueOf(getValueR().value())
				: getValueR().value());
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

}