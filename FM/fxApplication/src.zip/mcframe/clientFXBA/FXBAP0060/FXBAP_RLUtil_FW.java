package mcframe.clientFXBA.FXBAP0060;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.isColSame;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.isSame;
import static mcframe.commonFX.notice.FX_Msg.*;

import java.util.HashMap;

import javax.swing.JComponent;

import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0050.IfRLBase;
import mcframe.clientFXBA.FXBAP0070.FXBAP_RLCellConfig;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonFXBA.FXBAC0050.FXBAC_RLBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_RLUtil"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_RLUtil_FW extends FXBAP_RLUtil_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_RLUtil_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	protected FXBAP_PanelBase _panel;

	protected FXBAP_PanelBase getPanel() {
		if (_panel == null) {
			throw new MCAppException(FXBAP0073);
		}
		return _panel;
	}

	protected IfRLBase _implRLBase;

	protected IfRLBase getImplRLBase() {
		if (_implRLBase == null) {
			throw new MCAppException(FXBAP0073);
		}
		return _implRLBase;
	}

	/**
	 * @param p 利用している画面のインスタンス。 {@link IfRLBase}を
	 * 実装している必要がある。
	 */
	public void setPanel(FXBAP_PanelBase p) {
		_panel = p;
		if (p instanceof IfRLBase) {
			_implRLBase = (IfRLBase) p;
		}
		else {
			throw new MCAppException(FXBAP0072);
		}
	}

	// ////////////////

	/** 引数の項目名の変更前キーカラム名を返します。 */
	protected String getBeforeKeyColumn(String keyCol) {
		return keyCol + FXBAC_RLBase.getBkSuffix();
	}

	/**
	 * 画面共通の更新日時カラム名を取得します。<p>
	 */
	public String getUpdTsColumn() {
		return FXBAC_RLBase.getUpdTsColumn();
	}

	/**
	 * 画面共通の登録日時カラム名を取得します。<p>
	 */
	public String getInsTsColumn() {
		return FXBAC_RLBase.getInsTsColumn();
	}

	/**
	 * 画面共通の更新カウンタカラム名を取得します。<p>
	 */
	public String getUpdCntrColumn() {
		return FXBAC_RLBase.getUpdCntrColumn();
	}

	/**
	 * 画面共通の登録担当者ＣＤカラム名を取得します。<p>
	 */
	public String getInsUsrCdColumn() {
		return FXBAC_RLBase.getInsUsrCdColumn();
	}

	/**
	 * 画面共通の更新担当者ＣＤカラム名を取得します。<p>
	 */
	public String getUpdUsrCdColumn() {
		return FXBAC_RLBase.getUpdUsrCdColumn();
	}

	/**
	 * 更新関係のカラム名の配列です。
	 */
	private final String[] UPD_COLNAMES = new String[] {
			getInsUsrCdColumn(), getInsTsColumn(), getUpdCntrColumn(),
			getUpdUsrCdColumn(), getUpdTsColumn()
	};

	/**更新関係のカラム名の配列を取得します。*/
	protected String[] getUpdColNames() {
		return UPD_COLNAMES;
	}

	// //////////////////////////
	// 以降Panelとの連携メソッド
	// //////////////////////////

	/**
	 * 更新直後の画面ステータス。
	 */
	protected void setFIXStatus() {
		getImplRLBase().setFIXStatus();
	}

	/**
	 * 検索結果を表示し、値の編集を行うリスト。
	 * <P>テーブルに紐づくリストを指定する必要がある。</P>
	 */
	protected MCList<? extends MCConstRow> getDtlL() {
		return getImplRLBase().getDtlL();
	}

	protected String getFIXStatus() {
		return getImplRLBase().getFIXStatus();
	}

	public String defGetFIXStatus() {
		return "FIX";
	}

	/** 自動幅調整をoffにしています。 */
	protected void setAdjustWidth() {
		getImplRLBase().setAdjustWidth();
	}

	/** デフォルト実装：何もしない */
	public void defSetAdjustWidth() {
	}

	protected void afterOpen() {
		getPanel().afterOpen();
	}

	/** 
	 * デフォルト実装：何もしない。<br>
	 */
	public void defAfterOpen() {
//		fillSpace();
	}

	protected void setOpenFocus() {
		getPanel().setOpenFocus();
	}

	/** 
	 * デフォルト実装：画面Open後にfocusFirstComponentをする。<br>。
	 */
	public void defSetOpenFocus() {
		getPanel().focusFirstComponent();
	}

	protected void screenClearSetDefault() {
		getPanel().screenClearSetDefault();
	}

	/** 
	 * デフォルト実装：何もしない。<br>
	 * superを呼び出した後に呼び出す。
	 */
	public void defScreenClearSetDefault() {
//		fillSpace();
	}

	protected <E extends MCConstRow> E deleteRow(MCTable<E> table) {
		return getPanel().deleteRow(table);
	}

	/** 
	 * デフォルト実装：キー変更行である場合、キーを変更前にもどします。
	 * </P>
	 */
	public <E extends MCConstRow> boolean defDeleteRow(MCTable<E> table) {
		E sr = table.getSelectedMCRow();

		if (table.getRowCount() == 0) {
			return true;
		}

		if (sr == null) {
			table.selectLeftmostColumn(table.getRowCount() - 1);
			sr = table.getSelectedMCRow();
		}
		
		if (sr.isStatusModify() && isKeyUpd(sr)) {
			if (confirmUndoKeyUpd()) {
				stockBeforeDelete(table, sr);
				undoKeyUpd(sr);
				return true;
			}
			else {
				return false;
			}
		}
		if (sr.isStatusDelete()) {
			restoreData(table, sr, true);
		}
		return true;
	}
	
	/**
	 * Rowをストックします。
	 */
	@SuppressWarnings("unchecked")
	protected <E extends MCConstRow> void stockBeforeDelete(MCTable<E> table, E sr) {
		FXBAP_PanelBase base = getPanel();
		MCList<MCConstRow> tl = (MCList<MCConstRow>)table.getList();
		String bid = base.getBlockId(tl);
		String dbid = base.getBlockId(getDtlL());
		if (bid != null && bid.equals(dbid)){
			MCList<MCConstRow> l = base.getStock(bid);
			if (l == null) {
				l = tl.createInstance();
				base.setStock(bid, l);
	
				final MCList<MCConstRow> sl = l; 
				
				//テーブルのリストと連携するためのリスナ
				tl.addListListener(new MCListListener() {
	
					@Override
					public void rowRemoved(MCListEvent event) {
						_rowRemoved(event);
						
					}
	
					@Override
					public void rowRemoved(MCListEvent[] events) {
						for(MCListEvent event : events) {
							_rowRemoved(event);
						}
						
					}
					
					
	
					@Override
					public void rowSet(MCListEvent event) {
						_rowRemoved(event);
						
					}
					
					private void _rowRemoved(MCListEvent e) {
						if (sl.size() > 0) {
							MCRow[] rs = e.getRemoveRows();
							String[] bKeyCols = null;
							for (MCRow r : rs) {
								if (bKeyCols == null) {
									bKeyCols = getBeforeKeyColumns((MCConstRow)r);
								}
								Comparable<?>[] al = new Comparable<?>[bKeyCols.length];
								for (int i = 0; i < bKeyCols.length; i++) {
									al[i] = r.getValue(bKeyCols[i]);
								}
								MCRow sr = sl.getFirst(bKeyCols, al);
								sl.remove(sr);
							}
						}
					}
	
					@Override
					public void listCleared(MCListEvent event) {
						sl.clear();
						
					}
	
					@Override
					public void rowAdded(MCListEvent event) {
					}
					
					@Override
					public void listSorted(MCListEvent event) {
						
					}
					
				});
			}
			
			l.add((MCConstRow)sr.clone());
		}
	}

	
	/**
	 * ストックしたRowの値で引数targetRowのデータを上書きします。
	 * 
	 * デフォルト実装：キーの値のみ上書き
	 */
	protected <E extends MCConstRow> void restoreData(MCTable<E> table, E targetRow, boolean isRowRemoving) {
		FXBAP_PanelBase base = getPanel();
		MCList<E> tl = table.getList();
		String bid = base.getBlockId(tl);
		String dbid = base.getBlockId(getDtlL());
		if (dbid != null && dbid.equals(bid)){
			MCList<MCConstRow> l = base.getStock(bid);
			if (l != null && l.size() > 0) {
				String[] bKeyCols = getBeforeKeyColumns(targetRow);
				if (!isRowRemoving || tl.contains(targetRow)) {
					Comparable<?>[] al = new Comparable<?>[bKeyCols.length];
					for (int i = 0; i < bKeyCols.length; i++) {
						al[i] = targetRow.getValue(bKeyCols[i]);
					}
					MCConstRow stockr = l.getFirst(bKeyCols, al);
					
					if (stockr != null) {
						for (String k : targetRow.getKeys()) {
							targetRow.setValue(k, stockr.getValue(k));
						}
						if (isRowRemoving) {
							l.remove(stockr);
						}
					}
				}
			}
		}
	}
	
	protected String[] getBeforeKeyColumns(MCConstRow r) {

		String[] keyCols = r.getKeys().toArray(_dummyStringArray);
		return getBeforeKeyColumns(keyCols);
		
	}

	protected void mcInitStatus() {
		getPanel().mcInitStatus();
	}

	/** 
	 * tableのクリアが成功した場合の後処理 <p>
	 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス
	public boolean defClearSub(MCTable table) {
		if (table == null) {
			return false;
		}
		getImplRLBase().fillSpace();
		mcInitStatus();
		return true;
	}

	protected <E extends MCConstRow> E copyRowSub(E newRow) {
		return getImplRLBase().copyRowSub(newRow);
	}

	/**
	 * rowを行コピー処理の後処理
	 * <p>
	 * デフォルト実装：更前キー項目及び、更新関係のデータを削除する。
	 * </p>
	 * superを呼び出した後に呼び出す。
	 * @param newRow 行コピーして新規に作成されたRow
	 */
	public <E extends MCConstRow> E defCopyRowSub(E newRow) {
		if (newRow == null) {
			return null;
		}
		updColToNull(newRow);
		return newRow;
	}

	/** 変更前キー項目及び、更新関係のデータを削除します。 */
	protected <E extends MCConstRow> void updColToNull(E dest) {
		String[] bkeyCols = getBeforeKeyColumns(getDtlRKeyColumns());
		String[] delCols = MCCollectionUtil.concat(getUpdColNames(),
				bkeyCols);
		MCTable<E> t = getDtlTable();
		restoreData(t, dest, false);
		
		for (String s : delCols) {
			MCMeta meta = dest.getMeta(s);
			if (meta == null) {
				continue;
			}
			else if (MCDataType.BOOLEAN == meta.type()) {
				dest.setValue(s, false);
			}
			else {
				dest.setValue(s, null);
			}
		}
	}

	/** キー変更を元に戻してよいかダイアログを出します。 */
	protected boolean confirmUndoKeyUpd() {
		return getImplRLBase().confirmUndoKeyUpd();
	}

	/** キー変更を元に戻してよいかダイアログを出します。 */
	public boolean defConfirmUndoKeyUpd() {
		return getPanel().confirm(new MCMessage(FXBAP0018)) == MCMessageBox.YES_OPTION;
	}

	/**変更前キー項目名配列を返します。*/
	protected String[] getBeforeKeyColumns(String[] keyCols) {
		return getImplRLBase().getBeforeKeyColumns(keyCols);
	}

	/**変更前キー項目名配列を返します。*/
	public String[] defGetBeforeKeyColumns(String[] keyCols) {
		String[] bk = new String[keyCols.length];

		for (int i = 0; i < keyCols.length; i++) {
			bk[i] = getBeforeKeyColumn(keyCols[i]);
		}
		return bk;
	}

	/** キーの変更がある場合trueを返します。 */
	protected boolean isKeyUpd(MCRow r) {
		String[] keyCols = getDtlRKeyColumns();
		String[] bKeyCols = getBeforeKeyColumns(keyCols);
		return !isColSame(r, keyCols, r, bKeyCols);
	}

	/** キー変更を元に戻します。 */
	protected void undoKeyUpd(MCRow r) {
		String[] keyCols = getDtlRKeyColumns();
		String[] bKeyCols = getBeforeKeyColumns(keyCols);
		for (int i = 0; i < keyCols.length; i++) {
			Comparable<?> b = r.getValue(bKeyCols[i]);
			r.setValue(keyCols[i], b);
		}
	}

	// ////////////////

	// ////////////////
	// Dtlブロック関係
	// ////////////////

	/** DtlTableのキー項目を返します。 */
	protected String[] _ks;

	protected String[] _dummyStringArray = {};

	protected String[] getDtlRKeyColumns() {
		return getImplRLBase().getDtlRKeyColumns();
	}

	public String[] defGetDtlRKeyColumns() {
		if (_ks == null) {
			MCConstRow r = getDtlL().createRow();
			_ks = r.getKeys().toArray(_dummyStringArray);
		}
		return _ks;
	}

	/**リストDtlLに関連付けられるTableを返します。*/
	@SuppressWarnings("unchecked")
	// 戻り値のMCTableのジェネリクス
	protected MCTable getDtlTable() {
		return getImplRLBase().getDtlTable();
	}

	/**リストDtlLに関連付けられるTableを返します。*/
	@SuppressWarnings("unchecked")
	// 戻り値のMCTableのジェネリクス
	public MCTable defGetDtlTable() {
		return getTable(getDtlL());
	}

	//使い道がないので作成しない。
//	public void fillSpaceForOpen() {
//		getImplRLBase().fillSpaceForOpen();
//	}
	/**
	 * {@link #fillSpace()}を実行します。
	 */
	public void defFillSpaceForOpen() {
		fillSpace();
	}
	
	/**リストDtlLに関連付けられるTableをfillSpaceします。*/
	protected void fillSpace() {
		getImplRLBase().fillSpace();
	}

	/**
	 * リストDtlLに関連付けられるTableをfillSpaceします。
	 */
	public void defFillSpace() {
		getDtlTable().fillSpace();
	}

	/**ソート順設定をします。*/
	protected void setSortColumn() {
		getImplRLBase().setSortColumn();
	}

	/**キー項目でソートします。*/
	public void defSetSortColumn() {
		MCTable t = getDtlTable();
		for (MCColumnConfig c : getColumnConfigs(t, getDtlRKeyColumns())) {
			getDtlTable().addSortColumn(c, MCList.SortType.ASC);
		}
	}

	/**
	 * アプリケーションが使用するデフォルトのセルコンフィグ
	 * @deprecated 共通親クラスのみがオーバーライド呼び出し可能
	 */
	@Deprecated
	protected FXBAP_CellConfig createDefaultAppCellConfig() {
		return getImplRLBase().createDefaultAppCellConfig();
	}

	/**
	 * アプリケーションが使用するデフォルトのセルコンフィグ
	 * @deprecated 共通親クラスのみがオーバーライド呼び出し可能
	 */
	@Deprecated
	public FXBAP_CellConfig defCreateDefaultAppCellConfig() {
		FXBAP_RLCellConfig cellConf = new FXBAP_RLCellConfig();
		cellConf.setPanel(getPanel());
		return cellConf;
	}

	// ////////////////
	// その他
	// ////////////////

	/**リストに関連付けられるTableを返します。*/
	@SuppressWarnings("unchecked")
	// MCTableへのキャスト
	protected MCTable getTable(MCList list) {
		JComponent c = getPanel().getComponent(list);
		if (c instanceof MCTable) {
			MCTable t = (MCTable) c;
			return t;
		}
		throw new MCAppException(FXBAP0037);
	}

	/** tableの項目のカラムコンフィグの配列を返します。 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス、MCListのジェネリクス
	protected MCColumnConfig[] getColumnConfigs(MCTable t, String... cols) {
		return getImplRLBase().getColumnConfigs(t, cols);
	}

	/** tableの項目のカラムコンフィグの配列を返します。 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス、MCListのジェネリクス
	public MCColumnConfig[] defGetColumnConfigs(MCTable t, String... cols) {

		List<MCColumnConfig> cfgList = new ArrayList<MCColumnConfig>();

		MCList l = t.getList();
		if (l == null) {
			return new MCColumnConfig[0];
		}
		t.getBaseRootPanel().getBlockId(l);
		l.createRow();
		for (String col : cols) {

			for (MCColumnConfig cfg : t.getColumnConfigs()) {
				if (isSame(cfg.getBaseRowColumnName(), col)) {
					cfgList.add(cfg);
					continue;
				}
			}

		}

		return cfgList.toArray(new MCColumnConfig[0]);

	}

	/** DtlTableカラムのうち、指定カラムと変更前キー、更新関係のカラムを除いたカラムコンフィグの配列を返します。 */
	protected MCColumnConfig[] getExptColumnConfigs(MCColumnConfig... cols) {
		return getImplRLBase().getExptColumnConfigs(cols);
	}

	/** DtlTableカラムのうち、指定カラムと変更前キー、更新関係のカラムを除いたカラムコンフィグの配列を返します。 */
	@SuppressWarnings("unchecked")
	// MCTableのジェネリクス
	public MCColumnConfig[] defGetExptColumnConfigs(MCColumnConfig... cols) {

		MCTable t = getDtlTable();
		List<MCColumnConfig> cfgList = getExptColumnConfigList(t, cols);

		String[] delCols = MCCollectionUtil.concat(getUpdColNames(),
				getBeforeKeyColumns(getDtlRKeyColumns()));
		for (MCColumnConfig c : getColumnConfigs(t, delCols)) {
			cfgList.remove(c);

		}
		return cfgList.toArray(new MCColumnConfig[0]);

	}

	/** tableの指定カラムコンフィグ以外のカラムコンフィグのリストを返します。 */
	@SuppressWarnings("unchecked")
	// 戻り値のMCTableのジェネリクス
	protected List<MCColumnConfig> getExptColumnConfigList(MCTable t,
			MCColumnConfig... cols) {
		List<MCColumnConfig> cfgList = new ArrayList<MCColumnConfig>();

		for (MCColumnConfig col : t.getColumnConfigs()) {
			cfgList.add(col);

		}
		for (MCColumnConfig exptCol : cols) {
			cfgList.remove(exptCol);

		}
		return cfgList;
	}

	/**toStringWithMsgLabelで作成された配列を改行で連結したstringを返します。*/
	public String toStringWithMsgLabelNoArray(int idx, MCColumnConfig... cols) {
		return getImplRLBase().toStringWithMsgLabelNoArray(idx, cols);
	}

	/**toStringWithMsgLabelで作成された配列を改行で連結したStringを返します。*/
	public String defToStringWithMsgLabelNoArray(int idx, MCColumnConfig... cols) {
		String[] cs = getPanel().toStringWithMsgLabel(idx, cols);
		StringBuilder b = new StringBuilder();
		for (String c : cs) {
			b.append(c).append("\n");

		}
		return b.toString();

	}

}