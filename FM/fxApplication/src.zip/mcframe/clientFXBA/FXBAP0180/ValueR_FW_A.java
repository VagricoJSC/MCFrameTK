package mcframe.clientFXBA.FXBAP0180;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Value"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ValueR_FW_A extends MCConstRow {

	/**
	 * 論理値 論理値.<p>
	 *
	 */
	public static final String $value = "value";


	public static final MCMeta value_META = createBooleanMeta($value);

	protected static final ConstMetaList<ValueR> constMetas = new ConstMetaList<ValueR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			value_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ValueR_FW_A(ConstMetaList<? extends ValueR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ValueR clone() {
		return (ValueR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ValueR createInstance() {
		return (ValueR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ValueR getValues(String... names) {
		return (ValueR) super.getValues(names);
	}



	/**
	 * 論理値 論理値.<p>
	 *
	 */
	public boolean value() {
		return getConstBoolean(offset + 0, $value);
	}

	/**
	 * 論理値 論理値.<p>
	 *
	 */
	public void value(boolean value) {
		setConstBoolean(offset + 0, $value, value);
	}


	public boolean getBoolean(String name) {
		if ($value.equalsIgnoreCase(name)) {
			return value();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($value.equalsIgnoreCase(name)) {
			return value();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($value.equalsIgnoreCase(name)) {
			value(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($value.equalsIgnoreCase(name)) {
			value(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

