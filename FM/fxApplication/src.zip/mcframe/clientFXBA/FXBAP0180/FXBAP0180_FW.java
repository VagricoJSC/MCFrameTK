package mcframe.clientFXBA.FXBAP0180;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.MCValueSupply;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0180"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0180_FW extends FXBAP0180_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * パラメータ
	 */
	protected MCValueSupply.BooleanVS _param = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0180_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXBAP0180_FW(mcframe.clientFXBA.FXBAP0180.ValueR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		super.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BorderLayout(LAYOUT_MARGIN, 0));

		// 自動生成時の幅をリセット
		Value_value.setPreferredSize(null);

		ValuePanel.add(Value_value, BorderLayout.CENTER);
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return new MCModeBeans[] { Value_value };
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param };
	}

	@Override
	public void setParam(MCValueSupply...param) {
		_param = (MCValueSupply.BooleanVS) param[0];
		Value_value.setText(_param.name());			// 表示名称の設定
		Value_value.setMessageName(_param.name());	// メッセージ用表示名称の設定

		ValueR valueR = getValueR();
		Boolean boo = (Boolean) _param.value();
		valueR.value(boo.booleanValue());
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		return null;
	}

	@Override
	public void updateParam() {
		_param.value(Boolean.valueOf(getValueR().value()));
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

}