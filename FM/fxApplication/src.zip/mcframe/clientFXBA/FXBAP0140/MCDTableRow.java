package mcframe.clientFXBA.FXBAP0140;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;


/**
 * 動的コンテナ用のRowクラスです。
 * 
 */
@SuppressWarnings({"all"})
public class MCDTableRow extends MCConstRow {

//******************************************************************************
//* Meta生成 *******************************************************************
//******************************************************************************

	/**
	 * 文字列型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @param length 桁数
	 * @return 生成したメタ
	 */
	public static final MCMeta stringMeta(String name, int length) {
		return createStringMeta(name, length);
	}

	/**
	 * 文字列型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta stringMeta(String name) {
		return createStringMeta(name);
	}

	/**
	 * 数値型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @param length 桁数
	 * @param scale 小数桁数
	 * @param minus 負値を許容する場合 true
	 * @return 生成したメタ
	 */
	public static final MCMeta numberMeta(
							String name, int length, int scale, boolean minus) {
		return createNumberMeta(name, length, scale, minus);
	}

	/**
	 * 数値型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta numberMeta(String name) {
		return createNumberMeta(name);
	}

	/**
	 * 日付型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta dateMeta(String name) {
		return createDateMeta(name);
	}

	/**
	 * TIMESTAMP型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta timestampMeta(String name) {
		return createTimestampMeta(name);
	}

	/**
	 * ブール型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta booleanMeta(String name) {
		return createBooleanMeta(name);
	}

	/**
	 * バイナリ型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta binaryMeta(String name) {
		return createBinaryMeta(name);
	}

	/**
	 * ROW型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @param rowclass InnerRowクラス
	 * @return 生成したメタ
	 */
	public static final MCMeta innerRowMeta(String name,
										Class<? extends MCConstRow> rowclass) {
		return createInnerRowMeta(name, rowclass);
	}

	/**
	 * 通信時に暗号化する文字列型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @param length 桁数
	 * @return 生成したメタ
	 */
	public static final MCMeta cryptStringMeta(
													String name, int length) {
		return createCryptStringMeta(name, length);
	}

	/**
	 * 通信時に暗号化する文字列型固定カラムのメタを返します。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta cryptStringMeta(String name) {
		return createCryptStringMeta(name);
	}


	/**
	 * 共有メタ情報の固定カラムのメタを返します。
	 *
	 * ROW型以外の共有メタが対象です。
	 *
	 * @param name カラム名
	 * @param meta 共有メタ
	 * @return 生成したメタ
	 */
	public static final MCMeta commonMeta(String name, MCMeta meta) {
		return createCommonMeta(name, meta);
	}

	/**
	 * 共有メタ情報の固定カラムのメタを返します。
	 *
	 * ROW型の共有メタが対象です。
	 *
	 * @param name カラム名
	 * @param meta 共有メタ
	 * @param rowclass InnerRowクラス
	 * @return 生成したメタ
	 */
	public static final MCMeta commonMeta(String name, MCMeta meta,
										Class<? extends MCConstRow> rowclass) {
		return createCommonMeta(name, meta, rowclass);
	}

	/**
	 * 選択カラム用のメタを返します。
	 * ブール型です。DBマッピング種別を持ちません。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta selectorMeta(String name) {
		// Booleanと同じ、ただしDB型はなし
		return commonMeta(name,
			new MCMeta(name, name, MCDataType.BOOLEAN, MCMeta.BOOLEAN_LENGTH, MCMeta.BOOLEAN_SCALE, MCMeta.BOOLEAN_MINUS_ENABLE, null)
		);
	}

	/**
	 * クライアントで追加する名称連携カラム用のメタを返します。
	 * 文字列型です。DBマッピング種別を持ちません。
	 *
	 * @param name カラム名
	 * @return 生成したメタ
	 */
	public static final MCMeta linkNameMeta(String name) {
		// Stringと同じ、ただしDB型はなし
		return commonMeta(name,
			new MCMeta(name, name, MCDataType.STRING, MCMeta.UNLIMITED_LENGTH, MCMeta.STRING_SCALE, MCMeta.STRING_MINUS_ENABLE, null)
		);
	}



	/**
	 * 固定メタリストを生成します。
	 *
	 * @param metas メタ
	 * @param alias 別名
	 * @return メタリスト
	 */
	protected static ConstMetaList<MCDTableRow> createMetaList(MCMeta[] metas, String[][] alias) {
		return new ConstMetaList<MCDTableRow>(
				MCConstRow.constMetas,
				metas,
				alias
// 動的コンテナなので固有のメタ、エイリアスは持たない
//				new MCMeta[]{
//					str_META,
//					num_META,
//					boo_META,
//					dt_META,
//					ts_META
//				},
//				new String[][]{
//					{
//					},
//					{
//					}
//				}
			);
	}

	/**
	 * キーリストを生成します。
	 *
	 * @param keys キー
	 * @return キーリスト
	 */
	protected static MCKeyList createKeyList(String[] keys) {
		return new MCKeyList(
				null,
				keys
			);
	}

	/**
	 * 新しいRowを生成します。
	 *
	 * @return 新しいインスタンス
	 */
	public static MCDTableRow create() {
		MCDTableRow row = new MCDTableRow(null, null, null);
		return row;
	}

	/**
	 * 新しいRowを生成し別のRowの内容を設定します。
	 *
	 * @param proto 設定するRow
	 * @return 内容を設定した新しいインスタンス
	 */
	public static <T extends MCRow> MCDTableRow createByName(T proto) {
		MCDTableRow row = MCDTableRow.create();
		copyByName(row, proto);
		return row;
	}


	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
// 動的コンテナなので静的なメタはない
//		return constMetas.toNameArray();
		return new String[0];
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
// 動的コンテナなので静的なメタはない
//		return constMetas.toMetaArray();
		return new MCMeta[0];
	}

// 動的コンテナなので静的なオフセットはない
//	/**
//	 * 実際のカラム位置を知るためオフセットです。
//	 */
//	private static final int offset = constMetas.offset();


	/**
	 * 固定カラムのメタリスト
	 */
	protected final ConstMetaList<MCDTableRow> constMetas;

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected final MCKeyList KEYS;


// Rowの継承は行わない
//	/**
//	 * コンストラクタです。
//	 */
//	protected MCDTableRow(ConstMetaList<? extends DtlR> metas) {
//		super(metas);
//	}
	/**
	 * コンストラクタです。
	 * 
	 * @param metas メタ
	 * @param alias 別名
	 * @param keys キー
	 */
	public MCDTableRow(MCMeta[] metas, String[][] alias, String[] keys) {
		this(createMetaList(metas, alias), keys);
	}
	/**
	 * コンストラクタです。
	 * 
	 * @param metas メタリスト
	 * @param keys キー
	 */
	protected MCDTableRow(ConstMetaList<MCDTableRow> metas, String[] keys) {
		super(metas);
		constMetas = metas;
		KEYS = createKeyList(keys);
	}
	/**
	 * コンストラクタです。
	 * 
	 * 引数 src の設定を元に生成します。
	 * 
	 * @param src 元になるインスタンス
	 */
	protected MCDTableRow(MCDTableRow src) {
		super(src.constMetas);
		constMetas = src.constMetas;
		KEYS = src.KEYS;
	}

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	@Override
	public MCDTableRow clone() {
		return (MCDTableRow) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	@Override
	public MCDTableRow createInstance() {
		// MCRowはクラスの固定カラム定義を元に生成するが、
		// 動的コンテナのため、このインスタンスの定義を元に生成する
		return new MCDTableRow(this);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	@Override
	public MCDTableRow getValues(String... names) {
		return (MCDTableRow) super.getValues(names);
	}



	// 動的コンテナなのでgetter/setterはない



}

