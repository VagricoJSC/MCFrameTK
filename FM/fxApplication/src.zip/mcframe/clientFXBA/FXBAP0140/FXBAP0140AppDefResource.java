package mcframe.clientFXBA.FXBAP0140;

import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.container.MCIndexKey;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.resource.ctrl.MCReadableResource;


/**
 * テーブルリソースのアプリケーション定義リソースを管理します。
 * 
 */
public class FXBAP0140AppDefResource {

	/**
	 * Appリソース格納コンテナ
	 */
	private final MCList<AppR> _appL;

	/**
	 * Appリソース検索用インデックス
	 */
	private final MCIndexKey _appIndex;


	/**
	 * コンストラクタです。
	 * 
	 * @param appL Appリソース格納コンテナ
	 */
	FXBAP0140AppDefResource(MCList<AppR> appL) {
		_appL = appL;// クローンしたほうがよい？
		_appIndex = _appL.createIndex(AppR.$key);
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値（文字列）。設定がない場合 null
	 */
	protected String getSourceString(String...keys) {
		String key = MCConst.createKey(keys);
		AppR appR = _appL.getFirst(_appIndex, key);
		return (appR != null) ? appR.val() : null;
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public String getString(String...keys) {
		return getSourceString(keys);
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public MCNumber getNumber(String...keys) {
		String val = getSourceString(keys);
		return MCNumber.valueOf(val);
	}

	/**
	 * 値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public boolean getBoolean(String...keys) {
		String val = getSourceString(keys);
		return (val != null) ? Boolean.parseBoolean(val) : false;
	}

	/**
	 * 配列値を返します。
	 *
	 * @param key キー
	 * @return 値。設定がない場合 null
	 */
	public String[] getStringArray(String...keys) {
		String val = getSourceString(keys);
		if (val == null) {
			return null;
		}
		String[] vals = MCStringUtil.split(MCReadableResource.ARRAY_ESCAPE,
											MCReadableResource.ARRAY_DELIMITER, val);
		for (int i = 0; i < vals.length; i++) {
			vals[i] = MCStringUtil.trim(vals[i]);
		}
		return vals;
	}

}