// FMSE PANEL_EI
package mcframe.clientFXBA.FXBAP0140;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.commonCore.annotation.EI;
import mcframe.clientFXBA.FXBAP0130.*;


/**
 * 画面"FXBAP0140"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FXBAP0140 extends FXBAP0140_FW {

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0140() {
		super();
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXBAP0140(String name) {
		super(name);
	}

	public class FX_FXBAL0140_Srch02Bridge extends FXBAP0140_FW.FX_FXBAL0140_Srch02Bridge {
	}
	public class FX_FXBAL0140_Srch03Bridge extends FXBAP0140_FW.FX_FXBAL0140_Srch03Bridge {
	}
	public class FX_FXBAL0140_Upd01Bridge extends FXBAP0140_FW.FX_FXBAL0140_Upd01Bridge {
	}
	public class FX_FXBAL0140_Srch13Bridge extends FXBAP0140_FW.FX_FXBAL0140_Srch13Bridge {
	}

}