package mcframe.clientFXBA.FXBAP0140;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FXBAP0140]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FX.FXBAL0140.Srch02.UP.BLOCK0")){
			return FX_FXBAL0140_Srch02_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch02_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.DOWN.BLOCK1")){
			return FX_FXBAL0140_Srch02_DOWN_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch02.DOWN.BLOCK2")){
			return FX_FXBAL0140_Srch02_DOWN_BLOCK2();
		}
		else if (id.equals("FX.FXBAL0140.Srch03.UP.BLOCK0")){
			return FX_FXBAL0140_Srch03_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch03.UP.BLOCK1")){
			return FX_FXBAL0140_Srch03_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch03.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch03_DOWN_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Upd01.UP.BLOCK0")){
			return FX_FXBAL0140_Upd01_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Upd01.UP.BLOCK1")){
			return FX_FXBAL0140_Upd01_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch13.UP.BLOCK0")){
			return FX_FXBAL0140_Srch13_UP_BLOCK0();
		}
		else if (id.equals("FX.FXBAL0140.Srch13.UP.BLOCK1")){
			return FX_FXBAL0140_Srch13_UP_BLOCK1();
		}
		else if (id.equals("FX.FXBAL0140.Srch13.DOWN.BLOCK0")){
			return FX_FXBAL0140_Srch13_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
				
	
	static final MCOperationInfo FX_FXBAL0140_Srch02_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch02", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch02_UP_BLOCK0() {
		/** Ope.のBlock [Info] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("moduleid", "moduleid"),
				MCItemDef.create("screenid", "screenid"),
				MCItemDef.create("table", "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch02_DOWN_BLOCK0() {
	/** Ope.のBlock [Info] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("moduleid", "moduleid"),
				MCItemDef.create("screenid", "screenid"),
				MCItemDef.create("table", "table"),
				MCItemDef.create("upd", "upd"),
				MCItemDef.create("duplicate", "duplicate"),
				MCItemDef.create("cell", "cell")
			}
			,
			MCBlockDef.create("Info")
		);
	}
	public static MCContainerDef FX_FXBAL0140_Srch02_DOWN_BLOCK1() {
	/** Ope.のBlock [Def] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("id", "id"),
				MCItemDef.create("name", "name"),
				MCItemDef.create("key", "key"),
				MCItemDef.create("meta", "meta"),
				MCItemDef.create("type", "type"),
				MCItemDef.create("format", "format"),
				MCItemDef.create("mode", "mode"),
				MCItemDef.create("cond", "cond"),
				MCItemDef.create("opt", "opt")
			}
			,
			MCBlockDef.create("Def")
		);
	}
	public static MCContainerDef FX_FXBAL0140_Srch02_DOWN_BLOCK2() {
	/** Ope.のBlock [App] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch02",
			new MCItemDef[]{
				MCItemDef.create("key", "key"),
				MCItemDef.create("val", "val")
			}
			,
			MCBlockDef.create("App")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Srch03_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch03", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch03_UP_BLOCK0() {
		/** Ope.のBlock [Info] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("moduleid", "moduleid"),
				MCItemDef.create("screenid", "screenid"),
				MCItemDef.create("table", "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}

	public static MCContainerDef FX_FXBAL0140_Srch03_UP_BLOCK1() {
		/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("id", "id"),
				MCItemDef.create("type", "type"),
				MCItemDef.create("opt", "opt"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Param")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch03_DOWN_BLOCK0() {
	/** Ope.のBlock [Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch03",
			new MCItemDef[]{
				MCItemDef.create("rowno", "rowno"),
				MCItemDef.create("id", "id"),
				MCItemDef.create("type", "type"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Cont")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Upd01_INFO = new MCOperationInfo("FX", "FXBAL0140", "Upd01", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Upd01_UP_BLOCK0() {
		/** Ope.のBlock [Info] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("moduleid", "moduleid"),
				MCItemDef.create("screenid", "screenid"),
				MCItemDef.create("table", "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}

	public static MCContainerDef FX_FXBAL0140_Upd01_UP_BLOCK1() {
		/** Ope.のBlock [Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Upd01",
			new MCItemDef[]{
				MCItemDef.create("rowno", "rowno"),
				MCItemDef.create("id", "id"),
				MCItemDef.create("type", "type"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Cont")
		);
	}
	
	static final MCOperationInfo FX_FXBAL0140_Srch13_INFO = new MCOperationInfo("FX", "FXBAL0140", "Srch13", "000000", new PDef());

	public static MCContainerDef FX_FXBAL0140_Srch13_UP_BLOCK0() {
		/** Ope.のBlock [Info] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch13",
			new MCItemDef[]{
				MCItemDef.create("moduleid", "moduleid"),
				MCItemDef.create("screenid", "screenid"),
				MCItemDef.create("table", "table")
			}
			,
			MCBlockDef.create("Info")
		);
	}

	public static MCContainerDef FX_FXBAL0140_Srch13_UP_BLOCK1() {
		/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch13",
			new MCItemDef[]{
				MCItemDef.create("id", "id"),
				MCItemDef.create("type", "type"),
				MCItemDef.create("opt", "opt"),
				MCItemDef.create("STRING", "STRING"),
				MCItemDef.create("NUMBER", "NUMBER"),
				MCItemDef.create("BOOLEAN", "BOOLEAN"),
				MCItemDef.create("DATE", "DATE"),
				MCItemDef.create("TIMESTAMP", "TIMESTAMP"),
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Param")
		);
	}


	public static MCContainerDef FX_FXBAL0140_Srch13_DOWN_BLOCK0() {
	/** Ope.のBlock [Rslt] に対する電文項目定義 */
		return new MCGeneralContainerDef("FX", "FXBAL0140", "Srch13",
			new MCItemDef[]{
				MCItemDef.create("BINARY", "BINARY")
			}
			,
			MCBlockDef.create("Down")
		);
	}
	//FMCB DEF_CLASSES END
}

