package mcframe.clientFXBA.FXBAP0140;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Info"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoR_FW_A extends MCConstRow {

	/**
	 *  モジュールID.<p>
	 *
	 */
	public static final String $moduleid = "moduleid";
	/**
	 *  画面ID.<p>
	 *
	 */
	public static final String $screenid = "screenid";
	/**
	 *  テーブル.<p>
	 *
	 */
	public static final String $table = "table";
	/**
	 *  更新可.<p>
	 *
	 */
	public static final String $upd = "upd";
	/**
	 *  キー重複可.<p>
	 *
	 */
	public static final String $duplicate = "duplicate";
	/**
	 *  セルコンフィグ.<p>
	 *
	 */
	public static final String $cell = "cell";


	public static final MCMeta moduleid_META = createStringMeta($moduleid);
	public static final MCMeta screenid_META = createStringMeta($screenid);
	public static final MCMeta table_META = createStringMeta($table);
	public static final MCMeta upd_META = createBooleanMeta($upd);
	public static final MCMeta duplicate_META = createBooleanMeta($duplicate);
	public static final MCMeta cell_META = createStringMeta($cell);

	protected static final ConstMetaList<InfoR> constMetas = new ConstMetaList<InfoR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			moduleid_META,
			screenid_META,
			table_META,
			upd_META,
			duplicate_META,
			cell_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoR_FW_A(ConstMetaList<? extends InfoR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR clone() {
		return (InfoR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR createInstance() {
		return (InfoR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR getValues(String... names) {
		return (InfoR) super.getValues(names);
	}



	/**
	 *  モジュールID.<p>
	 *
	 */
	public String moduleid() {
		return getConstString(offset + 0, $moduleid);
	}

	/**
	 *  モジュールID.<p>
	 *
	 */
	public void moduleid(String value) {
		setConstString(offset + 0, $moduleid, value);
	}


	/**
	 *  画面ID.<p>
	 *
	 */
	public String screenid() {
		return getConstString(offset + 1, $screenid);
	}

	/**
	 *  画面ID.<p>
	 *
	 */
	public void screenid(String value) {
		setConstString(offset + 1, $screenid, value);
	}


	/**
	 *  テーブル.<p>
	 *
	 */
	public String table() {
		return getConstString(offset + 2, $table);
	}

	/**
	 *  テーブル.<p>
	 *
	 */
	public void table(String value) {
		setConstString(offset + 2, $table, value);
	}


	/**
	 *  更新可.<p>
	 *
	 */
	public boolean upd() {
		return getConstBoolean(offset + 3, $upd);
	}

	/**
	 *  更新可.<p>
	 *
	 */
	public void upd(boolean value) {
		setConstBoolean(offset + 3, $upd, value);
	}


	/**
	 *  キー重複可.<p>
	 *
	 */
	public boolean duplicate() {
		return getConstBoolean(offset + 4, $duplicate);
	}

	/**
	 *  キー重複可.<p>
	 *
	 */
	public void duplicate(boolean value) {
		setConstBoolean(offset + 4, $duplicate, value);
	}


	/**
	 *  セルコンフィグ.<p>
	 *
	 */
	public String cell() {
		return getConstString(offset + 5, $cell);
	}

	/**
	 *  セルコンフィグ.<p>
	 *
	 */
	public void cell(String value) {
		setConstString(offset + 5, $cell, value);
	}


	public String getString(String name) {
		if ($moduleid.equalsIgnoreCase(name)) {
			return moduleid();
		}
		if ($screenid.equalsIgnoreCase(name)) {
			return screenid();
		}
		if ($table.equalsIgnoreCase(name)) {
			return table();
		}
		if ($cell.equalsIgnoreCase(name)) {
			return cell();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($upd.equalsIgnoreCase(name)) {
			return upd();
		}
		if ($duplicate.equalsIgnoreCase(name)) {
			return duplicate();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($moduleid.equalsIgnoreCase(name)) {
			return moduleid();
		}
		if ($screenid.equalsIgnoreCase(name)) {
			return screenid();
		}
		if ($table.equalsIgnoreCase(name)) {
			return table();
		}
		if ($cell.equalsIgnoreCase(name)) {
			return cell();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($upd.equalsIgnoreCase(name)) {
			return upd();
		}
		if ($duplicate.equalsIgnoreCase(name)) {
			return duplicate();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($moduleid.equalsIgnoreCase(name)) {
			moduleid(value);
			return;
		}
		if ($screenid.equalsIgnoreCase(name)) {
			screenid(value);
			return;
		}
		if ($table.equalsIgnoreCase(name)) {
			table(value);
			return;
		}
		if ($cell.equalsIgnoreCase(name)) {
			cell(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($upd.equalsIgnoreCase(name)) {
			upd(value);
			return;
		}
		if ($duplicate.equalsIgnoreCase(name)) {
			duplicate(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($moduleid.equalsIgnoreCase(name)) {
			moduleid(value);
			return;
		}
		if ($screenid.equalsIgnoreCase(name)) {
			screenid(value);
			return;
		}
		if ($table.equalsIgnoreCase(name)) {
			table(value);
			return;
		}
		if ($cell.equalsIgnoreCase(name)) {
			cell(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($upd.equalsIgnoreCase(name)) {
			upd(value);
			return;
		}
		if ($duplicate.equalsIgnoreCase(name)) {
			duplicate(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

