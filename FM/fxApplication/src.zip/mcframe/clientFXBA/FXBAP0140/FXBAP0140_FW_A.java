package mcframe.clientFXBA.FXBAP0140;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.BorderLayout;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFXBA.FXBAP0140.FXBAP0140_FW.FX_FXBAL0140_Srch02Caller;
import mcframe.clientFXBA.FXBAP0140.FXBAP0140_FW.FX_FXBAL0140_Srch03Caller;
import mcframe.clientFXBA.FXBAP0140.FXBAP0140_FW.FX_FXBAL0140_Upd01Caller;
import mcframe.clientFXBA.FXBAP0140.FXBAP0140_FW.FX_FXBAL0140_Srch13Caller;

/**
 * 画面"FXBAP0140"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXBAP0140_FW_A extends mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXBAP0140";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Top]ブロック関連のField定義
	public MCPanel TopPanel = null;
	// [Top]ブロックの項目のField定義
	// [Fold]ブロック関連のField定義
	public MCPanel FoldPanel = null;
	public MCPanel FoldBasePanel = null;
	public MCScrollPane FoldScrollPane = null;
	// [Fold]ブロックの項目のField定義
	// [Ctrl]ブロック関連のField定義
	public MCPanel CtrlPanel = null;
	// [Ctrl]ブロックの項目のField定義
	public mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit Ctrl_ctrl_PPanel;
	// [Bottom]ブロック関連のField定義
	public MCPanel BottomPanel = null;
	// [Bottom]ブロックの項目のField定義
	// [Dtl]ブロック関連のField定義
	public MCPanel DtlPanel = null;
	// [Dtl]ブロックの項目のField定義
	/** [UPD]モードを表す定数 */
	public static final String UPD = "UPD";
	/** [FIX]モードを表す定数 */
	public static final String FIX = "FIX";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{UPD, FIX};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FX_FXBAL0140_Srch02]のCallerの作成 */
	protected FXBAP0140_FW.FX_FXBAL0140_Srch02Caller createFX_FXBAL0140_Srch02() {
		FXBAP0140_FW.FX_FXBAL0140_Srch02Caller<FXBAP0140, FX_FXBAL0140_Srch02Bridge>
		caller = ((FXBAP0140_FW)this).new FX_FXBAL0140_Srch02Caller<FXBAP0140, FX_FXBAL0140_Srch02Bridge>(
					(FXBAP0140)this, new FX_FXBAL0140_Srch02Bridge());
		return caller;
	}
	/** [FX_FXBAL0140_Srch02]の呼び出し */
	protected void callFX_FXBAL0140_Srch02() {
		MCCaller caller = createFX_FXBAL0140_Srch02();
		caller.exec();
	}
	/** [FX_FXBAL0140_Srch03]のCallerの作成 */
	protected FXBAP0140_FW.FX_FXBAL0140_Srch03Caller createFX_FXBAL0140_Srch03() {
		FXBAP0140_FW.FX_FXBAL0140_Srch03Caller<FXBAP0140, FX_FXBAL0140_Srch03Bridge>
		caller = ((FXBAP0140_FW)this).new FX_FXBAL0140_Srch03Caller<FXBAP0140, FX_FXBAL0140_Srch03Bridge>(
					(FXBAP0140)this, new FX_FXBAL0140_Srch03Bridge());
		return caller;
	}
	/** [FX_FXBAL0140_Srch03]の呼び出し */
	protected void callFX_FXBAL0140_Srch03() {
		MCCaller caller = createFX_FXBAL0140_Srch03();
		caller.exec();
	}
	/** [FX_FXBAL0140_Upd01]のCallerの作成 */
	protected FXBAP0140_FW.FX_FXBAL0140_Upd01Caller createFX_FXBAL0140_Upd01() {
		FXBAP0140_FW.FX_FXBAL0140_Upd01Caller<FXBAP0140, FX_FXBAL0140_Upd01Bridge>
		caller = ((FXBAP0140_FW)this).new FX_FXBAL0140_Upd01Caller<FXBAP0140, FX_FXBAL0140_Upd01Bridge>(
					(FXBAP0140)this, new FX_FXBAL0140_Upd01Bridge());
		return caller;
	}
	/** [FX_FXBAL0140_Upd01]の呼び出し */
	protected void callFX_FXBAL0140_Upd01() {
		MCCaller caller = createFX_FXBAL0140_Upd01();
		caller.exec();
	}
	/** [FX_FXBAL0140_Srch13]のCallerの作成 */
	protected FXBAP0140_FW.FX_FXBAL0140_Srch13Caller createFX_FXBAL0140_Srch13() {
		FXBAP0140_FW.FX_FXBAL0140_Srch13Caller<FXBAP0140, FX_FXBAL0140_Srch13Bridge>
		caller = ((FXBAP0140_FW)this).new FX_FXBAL0140_Srch13Caller<FXBAP0140, FX_FXBAL0140_Srch13Bridge>(
					(FXBAP0140)this, new FX_FXBAL0140_Srch13Bridge());
		return caller;
	}
	/** [FX_FXBAL0140_Srch13]の呼び出し */
	protected void callFX_FXBAL0140_Srch13() {
		MCCaller caller = createFX_FXBAL0140_Srch13();
		caller.exec();
	}
	/** [Info]ブロックのコンテナField定義 */
	private final mcframe.clientFXBA.FXBAP0140.InfoR aInfoR;
	/** [Param]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXBA.FXBAP0140.ParamR> aParamL;
	/** [Cont]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXBA.FXBAP0140.ContR> aContL;
	/** [Def]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXBA.FXBAP0140.DefR> aDefL;
	/** [App]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXBA.FXBAP0140.AppR> aAppL;
	/** [Down]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXBA.FXBAP0140.ContR> aDownL;

	/**
	 * 項目コピーによってaInfoRを設定します。
	 *
	 * aInfoRのインスタンスは変更されません。
	 *
	 * @param row InfoR
	 */
	public void setInfoR(mcframe.clientFXBA.FXBAP0140.InfoR row) {
		if (row != null) {
			MCRow.copyall(getInfoR(), row);
		}
	}

	/**
	 * [Info]ブロックのコンテナaInfoRを返します。
	 *
	 * @return InfoR
	 */
	public mcframe.clientFXBA.FXBAP0140.InfoR getInfoR() {
		return aInfoR;
	}

	/**
	 * aInfoRを作成します。
	 *
	 * @return InfoR
	 */
	public mcframe.clientFXBA.FXBAP0140.InfoR createInfoR() {
		return mcframe.clientFXBA.FXBAP0140.InfoR.create();
	}

	/**
	 * コピーによってaParamLを設定します。
	 *
	 * aParamLのインスタンスは変更されません。
	 *
	 * @param dataset ParamL
	 */
	public void setParamL(MCList<mcframe.clientFXBA.FXBAP0140.ParamR> aList) {
		if (getParamL() != aList) {
			getParamL().setAll(aList);
		}
	}

	/**
	 * [Param]ブロックのコンテナaParamLを返します。
	 *
	 * @return ParamL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.ParamR> getParamL() {
		return aParamL;
	}

	/**
	 * aParamRを作成します。
	 *
	 * @return ParamR
	 */
	public mcframe.clientFXBA.FXBAP0140.ParamR createParamR() {
		return mcframe.clientFXBA.FXBAP0140.ParamR.create();
	}

	/**
	 * aParamLを作成します。
	 *
	 * @return ParamL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.ParamR> createParamL() {
		return MCList.create(mcframe.clientFXBA.FXBAP0140.ParamR.class);
	}

	/**
	 * コピーによってaContLを設定します。
	 *
	 * aContLのインスタンスは変更されません。
	 *
	 * @param dataset ContL
	 */
	public void setContL(MCList<mcframe.clientFXBA.FXBAP0140.ContR> aList) {
		if (getContL() != aList) {
			getContL().setAll(aList);
		}
	}

	/**
	 * [Cont]ブロックのコンテナaContLを返します。
	 *
	 * @return ContL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.ContR> getContL() {
		return aContL;
	}

	/**
	 * aContRを作成します。
	 *
	 * @return ContR
	 */
	public mcframe.clientFXBA.FXBAP0140.ContR createContR() {
		return mcframe.clientFXBA.FXBAP0140.ContR.create();
	}

	/**
	 * aContLを作成します。
	 *
	 * @return ContL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.ContR> createContL() {
		return MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class);
	}

	/**
	 * コピーによってaDefLを設定します。
	 *
	 * aDefLのインスタンスは変更されません。
	 *
	 * @param dataset DefL
	 */
	public void setDefL(MCList<mcframe.clientFXBA.FXBAP0140.DefR> aList) {
		if (getDefL() != aList) {
			getDefL().setAll(aList);
		}
	}

	/**
	 * [Def]ブロックのコンテナaDefLを返します。
	 *
	 * @return DefL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.DefR> getDefL() {
		return aDefL;
	}

	/**
	 * aDefRを作成します。
	 *
	 * @return DefR
	 */
	public mcframe.clientFXBA.FXBAP0140.DefR createDefR() {
		return mcframe.clientFXBA.FXBAP0140.DefR.create();
	}

	/**
	 * aDefLを作成します。
	 *
	 * @return DefL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.DefR> createDefL() {
		return MCList.create(mcframe.clientFXBA.FXBAP0140.DefR.class);
	}

	/**
	 * コピーによってaAppLを設定します。
	 *
	 * aAppLのインスタンスは変更されません。
	 *
	 * @param dataset AppL
	 */
	public void setAppL(MCList<mcframe.clientFXBA.FXBAP0140.AppR> aList) {
		if (getAppL() != aList) {
			getAppL().setAll(aList);
		}
	}

	/**
	 * [App]ブロックのコンテナaAppLを返します。
	 *
	 * @return AppL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.AppR> getAppL() {
		return aAppL;
	}

	/**
	 * aAppRを作成します。
	 *
	 * @return AppR
	 */
	public mcframe.clientFXBA.FXBAP0140.AppR createAppR() {
		return mcframe.clientFXBA.FXBAP0140.AppR.create();
	}

	/**
	 * aAppLを作成します。
	 *
	 * @return AppL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.AppR> createAppL() {
		return MCList.create(mcframe.clientFXBA.FXBAP0140.AppR.class);
	}

	/**
	 * コピーによってaDownLを設定します。
	 *
	 * aDownLのインスタンスは変更されません。
	 *
	 * @param dataset DownL
	 */
	public void setDownL(MCList<mcframe.clientFXBA.FXBAP0140.ContR> aList) {
		if (getDownL() != aList) {
			getDownL().setAll(aList);
		}
	}

	/**
	 * [Down]ブロックのコンテナaDownLを返します。
	 *
	 * @return DownL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.ContR> getDownL() {
		return aDownL;
	}

	/**
	 * aDownRを作成します。
	 *
	 * @return DownR
	 */
	public mcframe.clientFXBA.FXBAP0140.ContR createDownR() {
		return mcframe.clientFXBA.FXBAP0140.ContR.create();
	}

	/**
	 * aDownLを作成します。
	 *
	 * @return DownL
	 */
	public MCList<mcframe.clientFXBA.FXBAP0140.ContR> createDownL() {
		return MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoR())) ret.add(getInfoR());
		if(!MCCollectionUtil.contains(ret, getParamL())) ret.add(getParamL());
		if(!MCCollectionUtil.contains(ret, getContL())) ret.add(getContL());
		if(!MCCollectionUtil.contains(ret, getDefL())) ret.add(getDefL());
		if(!MCCollectionUtil.contains(ret, getAppL())) ret.add(getAppL());
		if(!MCCollectionUtil.contains(ret, getDownL())) ret.add(getDownL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoR()) return "Info";
		if(aCnt == getParamL()) return "Param";
		if(aCnt == getContL()) return "Cont";
		if(aCnt == getDefL()) return "Def";
		if(aCnt == getAppL()) return "App";
		if(aCnt == getDownL()) return "Down";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Info")) return getInfoR();
		if(bId.equals("Param")) return getParamL();
		if(bId.equals("Cont")) return getContL();
		if(bId.equals("Def")) return getDefL();
		if(bId.equals("App")) return getAppL();
		if(bId.equals("Down")) return getDownL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(TopPanel);
		ret.add(FoldPanel);
		ret.add(CtrlPanel);
		ret.add(BottomPanel);
		ret.add(DtlPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0140_FW_A() {
		aInfoR = createInfoR();
		aParamL = createParamL();
		aContL = createContL();
		aDefL = createDefL();
		aAppL = createAppL();
		aDownL = createDownL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXBAP0140_FW_A(String name) {
		aInfoR = createInfoR();
		aParamL = createParamL();
		aContL = createContL();
		aDefL = createDefL();
		aAppL = createAppL();
		aDownL = createDownL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXBAP0140_FW.jbCreateTop((FXBAP0140)this);
		FXBAP0140_FW.jbCreateFold((FXBAP0140)this);
		FXBAP0140_FW.jbCreateCtrl((FXBAP0140)this);
		FXBAP0140_FW.jbCreateBottom((FXBAP0140)this);
		FXBAP0140_FW.jbCreateDtl((FXBAP0140)this);
	}

	/**
	 * [Top]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTop(FXBAP0140 p) {
	}

	/**
	 * [Fold]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateFold(FXBAP0140 p) {
	}

	/**
	 * [Ctrl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCtrl(FXBAP0140 p) {
		p.Ctrl_ctrl_PPanel = mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit.create();
		p.Ctrl_ctrl_PPanel.setName("Ctrl.ctrl");
	}

	/**
	 * [Bottom]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBottom(FXBAP0140 p) {
	}

	/**
	 * [Dtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDtl(FXBAP0140 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXBAP0140 create(){
		FXBAP0140 p = new FXBAP0140();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXBAP0140 create(String name){
		FXBAP0140 p = new FXBAP0140(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXBAP0140_FW.jbfInitTop((FXBAP0140)this);
		FXBAP0140_FW.jbfInitFold((FXBAP0140)this);
		FXBAP0140_FW.jbfInitCtrl((FXBAP0140)this);
		FXBAP0140_FW.jbfInitBottom((FXBAP0140)this);
		FXBAP0140_FW.jbfInitDtl((FXBAP0140)this);
		FXBAP0140_FW.jbInitTop((FXBAP0140)this);
		FXBAP0140_FW.jbInitFold((FXBAP0140)this);
		FXBAP0140_FW.jbInitCtrl((FXBAP0140)this);
		FXBAP0140_FW.jbInitBottom((FXBAP0140)this);
		FXBAP0140_FW.jbInitDtl((FXBAP0140)this);
	}

	/**
	 * [Top]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTop(FXBAP0140 p) {
		// ブロック関連の初期化
		p.TopPanel = p.beansFactory.createPanel("Top");
		// ブロックの項目の初期化
	}

	/**
	 * [Fold]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitFold(FXBAP0140 p) {
		// ブロック関連の初期化
		p.FoldPanel = p.beansFactory.createPanel("Fold");
		p.FoldBasePanel = p.beansFactory.createPanel("Fold.base");
		p.FoldScrollPane = p.beansFactory.createScrollPane("Fold.scroll");
		// ブロックの項目の初期化
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCtrl(FXBAP0140 p) {
		// ブロック関連の初期化
		p.CtrlPanel = p.beansFactory.createPanel("Ctrl");
		// ブロックの項目の初期化
	}

	/**
	 * [Bottom]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBottom(FXBAP0140 p) {
		// ブロック関連の初期化
		p.BottomPanel = p.beansFactory.createPanel("Bottom");
		// ブロックの項目の初期化
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDtl(FXBAP0140 p) {
		// ブロック関連の初期化
		p.DtlPanel = p.beansFactory.createPanel("Dtl");
		// ブロックの項目の初期化
	}

	/**
	 * [Top]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTop(FXBAP0140 p) {
		// ブロック関連の初期化
		p.add(p.TopPanel);
		p.setLastBeans(p.TopPanel);
		p.TopPanel.setNextBeans(p.BottomPanel);
		p.TopPanel.setLayoutPosition("T+");
		// ブロックの項目の初期化
		p.TopPanel.add(p.FoldBasePanel);
		p.FoldBasePanel.add(p.FoldScrollPane);
		p.FoldScrollPane.setBorder(null);
		p.FoldScrollPane.setViewportView(p.FoldPanel);
		p.FoldBasePanel.setLayoutPosition("C");
		p.TopPanel.setLastBeans(p.FoldPanel);
		p.FoldPanel.setNextBeans(p.CtrlPanel);
		p.TopPanel.add(p.CtrlPanel, null);
	}

	/**
	 * [Fold]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitFold(FXBAP0140 p) {
		// ブロック関連の初期化
		p.FoldPanel.setValueCheck(false);
		p.FoldPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCtrl(FXBAP0140 p) {
		// ブロック関連の初期化
		p.CtrlPanel.setValueCheck(false);
		p.CtrlPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.CtrlPanel.setLayout(new BorderLayout());
		p.CtrlPanel.add(p.Ctrl_ctrl_PPanel, BorderLayout.SOUTH);
		p.CtrlPanel.setLastBeans(p.Ctrl_ctrl_PPanel);
	}

	/**
	 * [Bottom]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBottom(FXBAP0140 p) {
		// ブロック関連の初期化
		p.add(p.BottomPanel);
		p.BottomPanel.setLayoutPosition("B+");
		// ブロックの項目の初期化
		p.BottomPanel.add(p.DtlPanel, null);
		p.BottomPanel.setLastBeans(p.DtlPanel);
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDtl(FXBAP0140 p) {
		// ブロック関連の初期化
		p.DtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	@Override
	public void layoutAfterOpen() {
		super.layoutAfterOpen();
		Ctrl_ctrl_PPanel.expandInit();
		Ctrl_ctrl_PPanel.setDefaultDividerLocation();
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXBAP0140_FW.mcInitTop((FXBAP0140)this);
		FXBAP0140_FW.mcInitFold((FXBAP0140)this);
		FXBAP0140_FW.mcInitCtrl((FXBAP0140)this);
		FXBAP0140_FW.mcInitBottom((FXBAP0140)this);
		FXBAP0140_FW.mcInitDtl((FXBAP0140)this);

		// [UPD]ステータスのモードの設定
		FXBAP0140_FW.statusInitUPD_Top((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Fold((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Ctrl((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Bottom((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Dtl((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Info((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Param((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Cont((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Def((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_App((FXBAP0140)this);
		FXBAP0140_FW.statusInitUPD_Down((FXBAP0140)this);

		// [FIX]ステータスのモードの設定
		FXBAP0140_FW.statusInitFIX_Top((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Fold((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Ctrl((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Bottom((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Dtl((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Info((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Param((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Cont((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Def((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_App((FXBAP0140)this);
		FXBAP0140_FW.statusInitFIX_Down((FXBAP0140)this);

	}

	/**
	 *  [Top]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTop(FXBAP0140 p) {
	}

	/**
	 *  [Fold]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitFold(FXBAP0140 p) {
	}

	/**
	 *  [Ctrl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCtrl(FXBAP0140 p) {
		p.Ctrl_ctrl_PPanel.Ope_srch.addAllListener(p);
	}

	/**
	 *  [Bottom]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBottom(FXBAP0140 p) {
	}

	/**
	 *  [Dtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDtl(FXBAP0140 p) {
	}

	/**
	 * [UPD]ステータスの[Top]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Top(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Fold]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Fold(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Ctrl(FXBAP0140 p){
		p.Ctrl_ctrl_PPanel.putStatus(UPD, mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit.ENABLE);

	}

	/**
	 * [UPD]ステータスの[Bottom]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Bottom(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Dtl(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Info(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Param]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Param(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Cont]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Cont(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Def]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Def(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[App]ブロックのモードの設定
	 */
	protected static void statusInitUPD_App(FXBAP0140 p){

	}

	/**
	 * [UPD]ステータスの[Down]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Down(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Top]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Top(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Fold]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Fold(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Ctrl(FXBAP0140 p){
		p.Ctrl_ctrl_PPanel.putStatus(FIX, mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit.ENABLE);

	}

	/**
	 * [FIX]ステータスの[Bottom]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Bottom(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Dtl(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Info(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Param]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Param(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Cont]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Cont(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Def]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Def(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[App]ブロックのモードの設定
	 */
	protected static void statusInitFIX_App(FXBAP0140 p){

	}

	/**
	 * [FIX]ステータスの[Down]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Down(FXBAP0140 p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return UPD;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[UPD]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setUPDStatus() {
		status = UPD;
		setAllStatus(status);
	}

	/**
	 * この画面を[FIX]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setFIXStatus() {
		status = FIX;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (UPD.equals(status)) {
			setUPDStatus();
		}
		else if (FIX.equals(status)) {
			setFIXStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Ctrl_ctrl_PPanel.Ope_srch) doCtrl_ctrl_Ope_srch(info);
	}

	/**
	 * [Ctrl]パネルの[ctrl_Ope_srch]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCtrl_ctrl_Ope_srch(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FX.FXBAL0140.Srch02")) {
			return new FX_FXBAL0140_Srch02Bridge();
		}
		if (id.equals("FX.FXBAL0140.Srch03")) {
			return new FX_FXBAL0140_Srch03Bridge();
		}
		if (id.equals("FX.FXBAL0140.Upd01")) {
			return new FX_FXBAL0140_Upd01Bridge();
		}
		if (id.equals("FX.FXBAL0140.Srch13")) {
			return new FX_FXBAL0140_Srch13Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FX_FXBAL0140_Srch02]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Srch02Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FX_FXBAL0140_Srch02;

		/** コンストラクタ */
		protected FX_FXBAL0140_Srch02Bridge() {
			p_FX_FXBAL0140_Srch02 = new MCParam(PDef.FX_FXBAL0140_Srch02_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FX_FXBAL0140_Srch02_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFXBA.FXBAP0140.InfoR.create());
			// Down
			param.addDownBlock(mcframe.clientFXBA.FXBAP0140.InfoR.create());
			param.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.DefR.class));
			param.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.AppR.class));

			p_FX_FXBAL0140_Srch02 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FX_FXBAL0140_Srch02.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FX_FXBAL0140_Srch02.addUpBlock(getInfoR());
		}

		protected MCContainer up(int i) {
			return p_FX_FXBAL0140_Srch02.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FX_FXBAL0140_Srch02.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFXBA.FXBAP0140.InfoR up0() {
			return (mcframe.clientFXBA.FXBAP0140.InfoR)up(0);
		}

		protected mcframe.clientFXBA.FXBAP0140.InfoR down0() {
			return (mcframe.clientFXBA.FXBAP0140.InfoR)down(0);
		}
		protected MCList<mcframe.clientFXBA.FXBAP0140.DefR> down1() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.DefR>)down(1);
		}
		protected MCList<mcframe.clientFXBA.FXBAP0140.AppR> down2() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.AppR>)down(2);
		}

		protected void setupDownParam() {
			p_FX_FXBAL0140_Srch02.addDownBlock(mcframe.clientFXBA.FXBAP0140.InfoR.create());
			p_FX_FXBAL0140_Srch02.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.DefR.class));
			p_FX_FXBAL0140_Srch02.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.AppR.class));
		}
		protected MCParam param() {
			return p_FX_FXBAL0140_Srch02;
		}

		protected void show() {
			setInfoR((mcframe.clientFXBA.FXBAP0140.InfoR)p_FX_FXBAL0140_Srch02.getContainerParam().getDownBlock(0));
			setDefL((MCList<mcframe.clientFXBA.FXBAP0140.DefR>)p_FX_FXBAL0140_Srch02.getContainerParam().getDownBlock(1));
			setAppL((MCList<mcframe.clientFXBA.FXBAP0140.AppR>)p_FX_FXBAL0140_Srch02.getContainerParam().getDownBlock(2));
		}

		protected void clear() {
			getInfoR().clear();
			getDefL().clear();
			getAppL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoR());
			result.add(getDefL());
			result.add(getAppL());
			return result;
		}
	}
	/**
	 * [FX_FXBAL0140_Srch03]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Srch03Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FX_FXBAL0140_Srch03;

		/** コンストラクタ */
		protected FX_FXBAL0140_Srch03Bridge() {
			p_FX_FXBAL0140_Srch03 = new MCParam(PDef.FX_FXBAL0140_Srch03_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FX_FXBAL0140_Srch03_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFXBA.FXBAP0140.InfoR.create());
			param.addUpBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ParamR.class));
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class));

			p_FX_FXBAL0140_Srch03 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FX_FXBAL0140_Srch03.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FX_FXBAL0140_Srch03.addUpBlock(getInfoR());
			p_FX_FXBAL0140_Srch03.addUpBlock(getParamL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FX_FXBAL0140_Srch03.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FX_FXBAL0140_Srch03.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFXBA.FXBAP0140.InfoR up0() {
			return (mcframe.clientFXBA.FXBAP0140.InfoR)up(0);
		}
		protected MCList<mcframe.clientFXBA.FXBAP0140.ParamR> up1() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.ParamR>)up(1);
		}

		protected MCList<mcframe.clientFXBA.FXBAP0140.ContR> down0() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.ContR>)down(0);
		}

		protected void setupDownParam() {
			p_FX_FXBAL0140_Srch03.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class));
		}
		protected MCParam param() {
			return p_FX_FXBAL0140_Srch03;
		}

		protected void show() {
			setContL((MCList<mcframe.clientFXBA.FXBAP0140.ContR>)p_FX_FXBAL0140_Srch03.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getContL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoR());
			result.add(getParamL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getContL());
			return result;
		}
	}
	/**
	 * [FX_FXBAL0140_Upd01]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Upd01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FX_FXBAL0140_Upd01;

		/** コンストラクタ */
		protected FX_FXBAL0140_Upd01Bridge() {
			p_FX_FXBAL0140_Upd01 = new MCParam(PDef.FX_FXBAL0140_Upd01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FX_FXBAL0140_Upd01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFXBA.FXBAP0140.InfoR.create());
			param.addUpBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class));
			// Down

			p_FX_FXBAL0140_Upd01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FX_FXBAL0140_Upd01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FX_FXBAL0140_Upd01.addUpBlock(getInfoR());
			p_FX_FXBAL0140_Upd01.addUpBlock(getContL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FX_FXBAL0140_Upd01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FX_FXBAL0140_Upd01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFXBA.FXBAP0140.InfoR up0() {
			return (mcframe.clientFXBA.FXBAP0140.InfoR)up(0);
		}
		protected MCList<mcframe.clientFXBA.FXBAP0140.ContR> up1() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.ContR>)up(1);
		}


		protected void setupDownParam() {
		}
		protected MCParam param() {
			return p_FX_FXBAL0140_Upd01;
		}

		protected void show() {
		}

		protected void clear() {
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoR());
			result.add(getContL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			return result;
		}
	}
	/**
	 * [FX_FXBAL0140_Srch13]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Srch13Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FX_FXBAL0140_Srch13;

		/** コンストラクタ */
		protected FX_FXBAL0140_Srch13Bridge() {
			p_FX_FXBAL0140_Srch13 = new MCParam(PDef.FX_FXBAL0140_Srch13_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FX_FXBAL0140_Srch13_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFXBA.FXBAP0140.InfoR.create());
			param.addUpBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ParamR.class));
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class));

			p_FX_FXBAL0140_Srch13 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FX_FXBAL0140_Srch13.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FX_FXBAL0140_Srch13.addUpBlock(getInfoR());
			p_FX_FXBAL0140_Srch13.addUpBlock(getParamL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FX_FXBAL0140_Srch13.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FX_FXBAL0140_Srch13.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFXBA.FXBAP0140.InfoR up0() {
			return (mcframe.clientFXBA.FXBAP0140.InfoR)up(0);
		}
		protected MCList<mcframe.clientFXBA.FXBAP0140.ParamR> up1() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.ParamR>)up(1);
		}

		protected MCList<mcframe.clientFXBA.FXBAP0140.ContR> down0() {
			return (MCList<mcframe.clientFXBA.FXBAP0140.ContR>)down(0);
		}

		protected void setupDownParam() {
			p_FX_FXBAL0140_Srch13.addDownBlock(MCList.create(mcframe.clientFXBA.FXBAP0140.ContR.class));
		}
		protected MCParam param() {
			return p_FX_FXBAL0140_Srch13;
		}

		protected void show() {
			setDownL((MCList<mcframe.clientFXBA.FXBAP0140.ContR>)p_FX_FXBAL0140_Srch13.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getDownL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getInfoR());
			result.add(getParamL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getDownL());
			return result;
		}
	}
}