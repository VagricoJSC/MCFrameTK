package mcframe.clientFXBA.FXBAP0140;

import mcframe.commonCore.notice.MCException;


/**
 * 汎用DBテーブル編集部品の通信後処理を定義します。
 * 
 */
public interface FXBAP0140CallAfterListener {

	/**
	 * 定義取得の正常終了後に呼ばれます。
	 */
	public default void resultSuccessDef() {}

	/**
	 * 定義取得の正常終了後、画面初期化完了後に呼ばれます。
	 */
	public default void resultSuccessInit() {}

	/**
	 * 検索の正常終了後に呼ばれます。
	 */
	public default void resultSuccessSrch() {}

	/**
	 * 検索結果が0件の正常終了後に呼ばれます。
	 */
	public default void resultNoDataFoundSrch() {}

	/**
	 * 検索の異常終了後に呼ばれます。
	 * @param ex 発生した例外
	 */
	public default void handleMCExSrch(MCException ex) {}


	/**
	 * 更新の正常終了後に呼ばれます。
	 */
	public default void resultSuccessUpd() {}

	/**
	 * 更新の異常終了後に呼ばれます。
	 * @param ex 発生した例外
	 */
	public default void handleMCExUpd(MCException ex) {}

}