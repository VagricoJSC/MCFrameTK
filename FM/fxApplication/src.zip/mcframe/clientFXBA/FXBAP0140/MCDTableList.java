package mcframe.clientFXBA.FXBAP0140;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.notice.MCException;
import static mcframe.commonCore.notice.Core_Msg.*;


/**
 * 動的コンテナ用のListクラスです。
 * 
 */
public class MCDTableList extends MCList<MCDTableRow> {

	/**
	 * 新しいインスタンスを生成します。
	 *
	 * @param row 格納するRowのプロトタイプ
	 * @return 生成したインスタンス
	 */
	public static MCDTableList create(MCDTableRow row) {
		return new MCDTableList(row);
	}


	/**
	 * createInstance用のプロトタイプのキャッシュ
	 * 
	 * MCListのcreateInstanceはRowクラスの固定カラムを前提に生成するが、
	 * 動的コンテナはRowインスタンスにメタ定義を持つため、
	 * キャッシュしたこのインスタンスで生成する。
	 * MCListが保持しているプロトタイプでも生成できるが、
	 * private変数なので継承クラスからアクセスできないため、
	 * 独自にキャッシュする。
	 */
	private final MCDTableRow _proto;

	/**
	 * コンストラクタです。
	 * 
	 * @param row 格納するRowのプロトタイプ
	 */
	protected MCDTableList(MCDTableRow row) {
		this(row, 10);
	}

	/**
	 * コンストラクタです。
	 * 
	 * @param row 格納するRowのプロトタイプ
	 * @param initCapacity 初期容量
	 */
	protected MCDTableList(MCDTableRow row, int initCapacity) {
		super(row, initCapacity);
		_proto = row.createInstance();
	}

	@Override
	public MCDTableList createInstance() {
		try {
			return new MCDTableList(_proto);
		} catch (Exception t) {
			throw new MCException(t, FCBBC0032, msgBindClassName());
		}
	}

}