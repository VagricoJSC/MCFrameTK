package mcframe.clientFXBA.FXBAP0140;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFXBA.FXBAP0130.*;


//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.commonFX.notice.FX_Msg.*;

import mcframe.commonFXBA.FXBAC0140.FXBAC_ContainerColumnMapper;
import mcframe.commonFXBA.FXBAC0140.FXBAC_TableEdit;
import mcframe.clientCore.beans.table.AbsMCPackageProxy;
import mcframe.clientFXBA.FXBAP0010.FXBAP_CallerNoPanel;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientFXBA.FXBAP0150.ConditionEditor;
import mcframe.clientFXBA.FXBAP0150.FXBAP0150;
import mcframe.clientFXBA.FXBAP0160.FXBAP0160;
import mcframe.clientFXBA.FXBAP0170.FXBAP0170;
import mcframe.clientFXBA.FXBAP0200.FXBAP0200;
import mcframe.clientFXBA.FXBAP0220.FXBAP0220;
import mcframe.clientFXBA.FXBAP0230.FXBAP0230;
import mcframe.commonCore.container.io.MCContainerColumnInfo;
import mcframe.commonCore.container.io.MCContainerIOConfig;
import mcframe.commonCore.container.io.MCCsvReader;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.param.MCParam;
import mcframe.commonCore.sys.MCFactory;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListPutter;
import mcframe.clientCore.beans.list.MCListType;
import mcframe.clientCore.beans.popup.MCPopupMenu;
import mcframe.clientCore.beans.dashboard.MCDashboardUtil;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.clientCore.requester.MCDownloader;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;

import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JViewport;
import javax.swing.border.Border;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0140"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0140_FW extends FXBAP0140_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 対象のモジュールID
	 */
	private String _mid = null;
	/**
	 * 対象の画面ID
	 */
	private String _sid = null;
	/**
	 * 対象のテーブル
	 */
	private String _table = null;
	/**
	 * 更新可・不可
	 * サーバから取得した定義をキャッシュ（画面クリア対応）
	 */
	private boolean _upd = false;
	/**
	 * キー重複可・不可
	 * サーバから取得した定義をキャッシュ（画面クリア対応）
	 */
	private boolean _duplicate = false;
	/**
	 * セルコンフィグ
	 * サーバから取得した定義をキャッシュ
	 */
	private String _cell = null;
	/**
	 * 初期検索条件
	 * サーバから定義取得後、検索条件組み立て処理（initConditionParts）で使用する
	 * そのため、CallAfterListener#resultSuccessDef()のタイミングで追加、変更が可能
	 */
	private MCRow _cond = null;

	// 動的テーブル用Field定義
	public MCScrollPane DtlScrollPane = null;
	public MCTable2<MCDTableRow> DtlTable = null;

	/**
	 * UPDステータスにするための土台画面のステータス
	 */
	private String UPD_BASE = UPD;
	/**
	 * FIXステータスにするための土台画面のステータス
	 */
	private String FIX_BASE = FIX;
	/**
	 * 土台画面
	 */
	private MCRootPanel _base = this;
	/**
	 * 通信後処理用リスナ
	 */
	private FXBAP0140CallAfterListener callAfter = null;
	/**
	 * Appリソース
	 */
	private FXBAP0140AppDefResource _appDefRes = null;
	/**
	 * 入力値設定、カラム順・サイズ、パーソナライズグループの有効/無効の切り替えフラグ
	 */
	private boolean _enablePersonalizeGroup = false;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0140_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FXBAP0140_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START
		// 動的テーブル生成
		createDtlTable();
		DtlTable.setRowName(name);
		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FX_FXBAL0140_Srch02]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Srch02Caller<P extends FXBAP0140, B extends FX_FXBAL0140_Srch02Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FX_FXBAL0140_Srch02Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();
			// 画面構築時は同期（キーボード操作を受け付けないようにする）
			setScreenAsync(false);
		}

		@Override
		protected int getProgressType() {
			// プログレスダイアログにキャンセルボタンを表示しない
			return MCMessageBox.NO_BUTTON_DIALOG;
		}

		@Override
		protected void lockScreen() {
			setLock(true);
		}

		@Override
		protected void unlockScreen() {
			setLock(false);
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();

			// resultSuccessDefの前に生成すること
			_appDefRes = new FXBAP0140AppDefResource(getAppL());

			if (callAfter != null) {
				callAfter.resultSuccessDef();
			}

			// サーバから取得した結果を退避
			// ※resultSuccessDefでの編集を考慮
			_upd = getInfoR().upd();
			_duplicate = getInfoR().duplicate();
			_cell = getInfoR().cell();

			afterOpenByFX_FXBAL0140_Srch02();

			if (callAfter != null) {
				callAfter.resultSuccessInit();
			}
		}

	}

	/**
	 * [FX_FXBAL0140_Srch03]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Srch03Caller<P extends FXBAP0140, B extends FX_FXBAL0140_Srch03Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FX_FXBAL0140_Srch03Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();

			// FC7011#041 検索パフォーマンス改善
			// 検索条件設定
			setSrchCondition();

			// 準下りブロックに追加（一覧クリアのため）
			addDownContainer(getDtlL());
		}

		@Override
		protected void setLimitDLSize() {
			super.setLimitDLSize();
			MCNumber dl = param().getLimitDLSize();
			if (dl == null) {
				dl = MCConfig.client.getNumber("net.response.limitSize");
			}
			if (dl != null) {
				if (dl.gt(0)) {
					// 受信上限数設定あり
					// カラムが直列になるので、その分受信上限を増やす
					int cols = getDefL().size();
					param().setLimitDLSize(dl.multiply(cols));
				}
			}
		}

		@Override
		protected void show() {
			super.show();

			MCDTableList list = getDtlL();
			MCDTableList temp = list.createInstance();

			MCList<ContR> contL = (MCList<ContR>) getDownParams().get(0);
			MCIndexKey rowno_idx = contL.createIndex(ContR.$rowno);
			MCList<ContR> rowL = null;
			int rowno = 0;
			while ((rowL = contL.subList(rowno_idx, MCNumber.valueOf(rowno++))).size() > 0) {
				MCDTableRow row = list.createRow();
				for (ContR rowR : rowL) {
					String id = rowR.id();
					MCDataType type = MCDataType.valueOf(rowR.type());
					switch (type) {
						case STRING:
							row.setString(id, rowR.STRING());
							setNameColumn(row, id);
							break;
						case NUMBER:
							row.setNumber(id, rowR.NUMBER());
							break;
						case BOOLEAN:
							row.setBoolean(id, rowR.BOOLEAN());
							break;
						case DATE:
							row.setDate(id, rowR.DATE());
							break;
						case TIMESTAMP:
							row.setTimestamp(id, rowR.TIMESTAMP());
							break;
						case BINARY:
							row.setBinary(id, rowR.BINARY());
							break;
						default:
							// InnerRowは対応しない
							break;
					}
				}
				temp.add(row);
			}
			list.addAll(temp);
			contL.removeIndex(rowno_idx);
			sort();
		}

		@Override
		protected void setMode() {
			super.setMode();

			if (getInfoR().upd()) {
				//setUPDStatus();
				_base.setStatus(UPD_BASE);
			}
			else {
				//setFIXStatus();
				_base.setStatus(FIX_BASE);
			}

			DtlTable.selectLeftmostColumn(0);
			DtlTable.adjustWidth();
		}

		@Override
		protected void setModeNoDown() {
			super.setModeNoDown();

			if (getInfoR().upd()) {
				//setUPDStatus();
				_base.setStatus(UPD_BASE);
			}
			else {
				//setFIXStatus();
				_base.setStatus(FIX_BASE);
			}

			CtrlPanel.focusFirstComponent();
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();
			if (callAfter != null) {
				callAfter.resultSuccessSrch();
			}

			// 検索結果がある場合、検索枠を畳む
			Ctrl_ctrl_PPanel.expand(false);
		}

		@Override
		protected void resultNoDataFound() {
			super.resultNoDataFound();
			if (callAfter != null) {
				callAfter.resultNoDataFoundSrch();
			}
		}

		@Override
		protected void handleMCEx(MCException ex) {
			// FC7011#006 通信エラー時のリスナ呼び出し
			try {
				super.handleMCEx(ex);
			}
			catch (MCException ex2) {
				if (callAfter != null) {
					callAfter.handleMCExSrch(ex2);
				}
				throw ex2;
			}
		}

	}

	/**
	 * [FX_FXBAL0140_Srch13]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Srch13Caller<P extends FXBAP0140, B extends FX_FXBAL0140_Srch13Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		/**
		 * CSV読込み用コンテナ
		 */
		private MCDTableList _temp = null;

		protected FX_FXBAL0140_Srch13Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();

			// 検索条件設定
			setSrchCondition();

			// 準下りブロックに追加（一覧クリアのため）
			addDownContainer(getDtlL());
		}

		@Override
		protected void callMain() {
			super.callMain();

//			ContR contR = ContR.class.cast(getDownParams().get(0));
//			MCBinary bin = contR.BINARY();
			MCList<ContR> contL = MCList.class.cast(getDownParams().get(0));
			if (contL.isEmpty()) {
				return;
			}
			MCBinary bin = contL.get(0).BINARY();
			MCDTableList list = getDtlL();
			_temp = list.createInstance();
			loadCSV(_temp, bin);
		}

		@Override
		protected void show() {
			super.show();

			MCDTableList list = getDtlL();
			list.addAll(_temp);
			sort();
		}

		@Override
		protected void setMode() {
			super.setMode();

			if (getInfoR().upd()) {
				//setUPDStatus();
				_base.setStatus(UPD_BASE);
			}
			else {
				//setFIXStatus();
				_base.setStatus(FIX_BASE);
			}

			DtlTable.selectLeftmostColumn(0);
			DtlTable.adjustWidth();
		}

		@Override
		protected void setModeNoDown() {
			super.setModeNoDown();

			if (getInfoR().upd()) {
				//setUPDStatus();
				_base.setStatus(UPD_BASE);
			}
			else {
				//setFIXStatus();
				_base.setStatus(FIX_BASE);
			}

			CtrlPanel.focusFirstComponent();
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();
			if (callAfter != null) {
				callAfter.resultSuccessSrch();
			}

			// 検索結果がある場合、検索枠を畳む
			Ctrl_ctrl_PPanel.expand(false);
		}

		@Override
		protected void resultNoDataFound() {
			super.resultNoDataFound();
			if (callAfter != null) {
				callAfter.resultNoDataFoundSrch();
			}
		}

		@Override
		protected void handleMCEx(MCException ex) {
			// FC7011#006 通信エラー時のリスナ呼び出し
			try {
				super.handleMCEx(ex);
			}
			catch (MCException ex2) {
				if (callAfter != null) {
					callAfter.handleMCExSrch(ex2);
				}
				throw ex2;
			}
		}

	}

	/**
	 * [FX_FXBAL0140_Upd01]の定型処理のInnerClass
	 */
	protected class FX_FXBAL0140_Upd01Caller<P extends FXBAP0140, B extends FX_FXBAL0140_Upd01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Updater<P, B> {

		// 通信対象のリスト（電文変換前）
		protected MCList<MCDTableRow> dtableL;

		protected FX_FXBAL0140_Upd01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void initCaller() {
			super.initCaller();

			MCList<ContR> contL = getContL();
			contL.clear();

			dtableL = getDtlL().statusChangedList();
			for (int i = 0; i < dtableL.size(); i++) {
				MCDTableRow dtableR = dtableL.get(i);

				Status status = dtableR.getStatus();
				int guino = dtableR.getGUIIndex();
				for (MCMeta meta : Dtl_METAs) {
					if (meta.dbType() == null) {
						// DBの型を持たない > DBにない項目
						continue;
					}
					String id = meta.name();
					ContR contR = contL.createRow();
					contR.rowno(i);
					contR.id(id);
					contR.type(meta.type().toString());
					switch (meta.type()) {
						case STRING:
							contR.STRING(dtableR.getString(id));
							break;
						case NUMBER:
							contR.NUMBER(dtableR.getNumber(id));
							break;
						case BOOLEAN:
							contR.BOOLEAN(dtableR.getBoolean(id));
							break;
						case DATE:
							contR.DATE(dtableR.getDate(id));
							break;
						case TIMESTAMP:
							contR.TIMESTAMP(dtableR.getTimestamp(id));
							break;
						case BINARY:
							contR.BINARY(dtableR.getBinary(id));
							break;
						default:
							// InnerRowは対応しない
							break;
					}
					contR.setStatus(status);
					contR.setGUIIndex(guino);
					contR.setRefTime(dtableR.getRefTime());
					contL.add(contR);
				}
			}
		}

		@Override
		protected void checkForCallStack(MCMessageList msgList) {
			super.checkForCallStack(msgList);
			// FC7011#041 キー重複許可
			// 重複チェック（キー重複不可の場合）
			if (!_duplicate) {
				panel.checkDuplicate(msgList, DtlTable, Dtl_keys);
			}
		}

		@Override
		protected void checkReq(MCMessageList msgList) {
			super.checkReq(msgList);
			// 必須チェック
			msgList.addAll(panel.checkReq(dtableL));
		}


		@Override
		protected void statusClear() {
			super.statusClear();
			MCTimestamp now = bridge.p_FX_FXBAL0140_Upd01.getCommitTime();
			MCList<MCDTableRow> dtlL = getDtlL();
			dtlL.removeAll(dtlL.subList(MCRow.DELETE));
			dtlL.setStatus(MCRow.NONE);
			dtlL.setRefTime(now);
		}

		@Override
		protected void setMode() {
			super.setMode();

			//setFIXStatus();
			_base.setStatus(FIX_BASE);

			CtrlPanel.focusFirstComponent();
		}

		@Override
		protected void resultSuccess() {
			super.resultSuccess();
			if (callAfter != null) {
				callAfter.resultSuccessUpd();
			}
		}

		@Override
		protected void handleMCEx(MCException ex) {
			// FC7011#006 通信エラー時のリスナ呼び出し
			try {
				super.handleMCEx(ex);
			}
			catch (MCException ex2) {
				if (callAfter != null) {
					callAfter.handleMCExUpd(ex2);
				}
				throw ex2;
			}
		}

	}

	// FC7011#041 検索パフォーマンス改善
	/**
	 * サーバ上のCSVファイルをダウンロードしリストにロードします。
	 *
	 * @param temp 読み込むリスト
	 * @param bin サーバのCSVを示すバイナリ
	 */
	protected void loadCSV(MCDTableList temp, MCBinary bin) {
		MCDownloader downloader = new MCDownloader(bin);
		File down = downloader.exec(null, null);

		MCCsvReader<MCDTableRow> reader = new MCCsvReader<MCDTableRow>(temp, down);
		MCContainerIOConfig csvconf = new MCContainerIOConfig();
		reader.setContainerColumnMapper(new FXBAC_ContainerColumnMapper<MCDTableRow>() {
			// 文字列用のカラム情報をカスタマイズ
			// 連携項目に値を設定する
			@Override
			protected MCContainerColumnInfo makeConstColumnInfo(String column, MCMeta meta,
					MCContainerIOConfig config) {
				if (meta.type() == MCDataType.STRING) {
					return new MCContainerColumnInfo(column, meta.type(), "", config) {
						private final String col = column;
						@Override
						public void map(MCRow row, String value) {
							super.map(row, value);
							setNameColumn(row, col);
						}
					};
				}
				return super.makeConstColumnInfo(column, meta, config);
			}
		});
		MCMessageList msglist = reader.read(csvconf);
		if (!msglist.isEmpty()) {
			// 読み込みエラー
			MCException ex = new MCException(FXBAP0105);
			ex.addCauseMessageList(msglist);
			throw ex;
		}
	}

	// FC7011#041 検索パフォーマンス改善
	/**
	 * 名称連携項目に名称を設定します。
	 *
	 * @param row Row
	 * @param idcol 連携元項目名
	 * @return 設定した場合（連携項目があった場合）true
	 */
	protected boolean setNameColumn(MCRow row, String idcol) {
		// 連携元情報
		DefR defR = comboL.getFirst(comboL_idx, idcol);
		if (defR == null) {
			// コンボリストに該当行がない
			return false;
		}
		String id = row.getString(idcol);
		if (id == null) {
			// 項目名なし
			return false;
		}

		// 名称連携情報
		String[] opt = analyzeComboOption(defR);
		String[] links = analyzeComboColumn(opt[FXBAC_TableEdit.DEFOPT_COMBO_LINK]);
		if (links.length <= FXBAC_TableEdit.DEFOPT_COMBO_COL_NAME) {
			// 連携項目なし
			return false;
		}
		String[] aliases = analyzeComboColumn(opt[FXBAC_TableEdit.DEFOPT_COMBO_ALIAS]);

		// リスト取得
		MCList<?> cmbL = getComboList(defR,
				MCRow.create(),
				columnMap.get(idcol).getEventInfo());
		MCRow cmbR = cmbL.getFirst(aliases[FXBAC_TableEdit.DEFOPT_COMBO_COL_ID], id);
		if (cmbR == null) {
			// 該当行なし
			return false;
		}

		// 連携
		for (int i = 1; i < aliases.length; i++) {
			String link = links[i];
			String alias = aliases[i];
			MCMeta meta = row.getMeta(link);
			if (meta == null) {
			}
			else switch (meta.type()) {
				case STRING:
					row.setString(link, cmbR.getString(alias));
					break;
				case NUMBER:
					row.setNumber(link, cmbR.getNumber(alias));
					break;
				case BOOLEAN:
					row.setBoolean(link, cmbR.getBoolean(alias));
					break;
				case DATE:
					row.setDate(link, cmbR.getDate(alias));
					break;
				case TIMESTAMP:
					row.setTimestamp(link, cmbR.getTimestamp(alias));
					break;
				case BINARY:
					row.setBinary(link, cmbR.getBinary(alias));
					break;
				default:
					// InnerRowは対応しない
					break;
			}
		}
		return true;
	}

	// FC7011#041 検索パフォーマンス改善
	/**
	 * 画面の検索条件を通信用コンテナに設定します。
	 *
	 * @since 7.0.1.2
	 */
	protected void setSrchCondition() {
		MCList<ParamR> paramL = getParamL();
		paramL.clear();

		for (MCValueSupply cond : _condList) {
			if (cond.value() == null) {
				continue;
			}

			ParamR paramR = paramL.createRow();
			paramR.id(cond.column());
			switch (cond.type()) {
				case MCDashboardUtil.TYPE_STRING:
				case MCDashboardUtil.TYPE_STRING_COMBO:
				case MCDashboardUtil.TYPE_STRING_AREA:
					paramR.type(MCDataType.STRING.toString());
					paramR.STRING((String) cond.value());
					break;
				case MCDashboardUtil.TYPE_NUMBER:
					paramR.type(MCDataType.NUMBER.toString());
					paramR.NUMBER((MCNumber) cond.value());
					break;
				case MCDashboardUtil.TYPE_BOOLEAN:
					MCValueSupply.BooleanVS booParam = (MCValueSupply.BooleanVS) cond;
					if (!booParam.isUsed()) {
						continue;
					}
					paramR.type(MCDataType.BOOLEAN.toString());
					paramR.BOOLEAN((Boolean) cond.value());
					break;
				case MCDashboardUtil.TYPE_DATE:
				case MCDashboardUtil.TYPE_TIMESTAMP:
					String id = paramR.id();
					boolean to = id.endsWith(FXBAC_TableEdit.COND_DATE_TO);
					if (to) {
						id = id.substring(0, id.length() - FXBAC_TableEdit.COND_DATE_TO.length());
						paramR.id(id);
						paramR.opt(FXBAC_TableEdit.DEFOPT_DATE_TO);
					}
					else {
						paramR.opt(FXBAC_TableEdit.DEFOPT_DATE_FROM);
					}
					switch (cond.type()) {
						case MCDashboardUtil.TYPE_DATE:
							paramR.type(MCDataType.DATE.toString());
							paramR.DATE((MCDate) cond.value());
							break;
						case MCDashboardUtil.TYPE_TIMESTAMP:
							paramR.type(MCDataType.TIMESTAMP.toString());
							paramR.TIMESTAMP((MCTimestamp) cond.value());
							break;
					}
					break;
				case MCDashboardUtil.TYPE_BINARY:
					paramR.type(MCDataType.BINARY.toString());
					paramR.BINARY((MCBinary) cond.value());
					break;
				default:
					break;
			}
			paramL.add(paramR);
		}
	}


	/**
	 * Panel[Ctrl]のボタン[ctrl_Ope_srch]の押下時の処理
	 */
	@Override
	public void doCtrl_ctrl_Ope_srch(MCEventInfo info) {
		// 検索条件入力値の反映
		for (ConditionEditor editor : _condParts) {
			editor.updateParam();
		}

		// FC7011#041 検索パフォーマンス改善
//		callFX_FXBAL0140_Srch03();
		callFX_FXBAL0140_Srch13();
	}


	@Override
	protected void jbInit() {
		super.jbInit();

		// 動的テーブル設定
		// jbfInit
		DtlScrollPane = beansFactory.createScrollPane("Dtl.scroll");
		createDtlTable();
		// jbInit
		DtlPanel.add(DtlScrollPane);
		DtlPanel.setLastBeans(DtlTable);
		DtlScrollPane.setViewportView(DtlTable);
	}

	@Override
	protected void mcInit() {
		// 動的テーブル設定
		// 追加部品のサイズ設定
		// 各部品のサイズはmcInitを呼ぶ前に設定される
		DtlScrollPane.setPreferredSize(DtlPanel.getPreferredSize());
		DtlScrollPane.setSize(DtlPanel.getSize());

		super.mcInit();

		// 動的テーブル設定
		// イベントリスナ設定
		DtlTable.addAllListener(this);
	}

	@Override
	public void layoutInit() {
		// 動的テーブル設定
		// 本来はmcInitの直後にフレームワーク内でリソースの値を設定している
		DtlScrollPane.setPreferredSize(DtlPanel.getPreferredSize());
		DtlScrollPane.setSize(DtlPanel.getSize());

		// BorderLayoutに依存させるためリソース値を破棄
		FoldPanel.setPreferredSize(new Dimension(0, 0));
		FoldPanel.setSize(new Dimension(0, 0));

		// 7013-2275(SP3高解像度対応不具合まとめ)
		getBaseRootPanel().setGeneralTable(true); //汎用テーブル画面であることを示す。

		super.layoutInit();
	}

	@Override
	protected void setPopupMenuVisible() {
		super.setPopupMenuVisible();
		getBaseRootPanel().setPopupConfig(new TableEditorPopupConfig());
	}

	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
// メニューの引数に対応するためRowは使用しない
//			if (bind != null) {
//				initTableInfo(
//						bind.getStringNE("moduleid"),
//						bind.getStringNE("screenid"),
//						bind.getStringNE("table")
//					);
//			}
			if (args == null || args.length < 3) {
				// 引数不正
				throw new MCAppException(msgUnknownOpenParam());
			}
			initTbledit((String) args[0], (String) args[1], (String) args[2], bind);
		}
		else {
			// タイプ不正
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	/**
	 * 画面なしでサーバーとの通信を行うメソッド。
	 */
	protected void callSrch02NoPanel() {
		MCParam p = new MCParam(PDef.FX_FXBAL0140_Srch02_INFO);
		FXBAP_CallerNoPanel caller = new FXBAP_CallerNoPanel(p);
		p.addUpBlock(getInfoR());
		p.addDownBlock(getInfoR());
		p.addDownBlock(getDefL());
		p.addDownBlock(getAppL());
		caller.exec();

		// resultSuccessDefの前に生成すること
		_appDefRes = new FXBAP0140AppDefResource(getAppL());

		if (callAfter != null) {
			callAfter.resultSuccessDef();
		}

		// サーバから取得した結果を退避
		// ※resultSuccessDefでの編集を考慮
		_upd = getInfoR().upd();
		_duplicate = getInfoR().duplicate();
		_cell = getInfoR().cell();

		afterOpenByFX_FXBAL0140_Srch02();

		if (callAfter != null) {
			callAfter.resultSuccessInit();
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		if (_mid == null || _sid == null || _table == null) {
			throw new MCException(FXBAP0103, _mid, _sid, _table);
		}

		InfoR infoR = getInfoR();
		infoR.moduleid(_mid);
		infoR.screenid(_sid);
		infoR.table(_table);
		infoR.upd(_upd);
		infoR.cell(_cell);

		if (getDtlL() != null) {
			getDtlL().clear();
		}
	}

	/**
	 * 入力値設定、カラム順・サイズ、パーソナライズグループを有効化するメソッド。
	 *
	 */
	public void enablePersonalizeGroup() {
		_enablePersonalizeGroup = true;
		callSrch02NoPanel();
	}

	@Override
	public void layoutAfterOpen() {
		// 画面タイトル
		String title = getTableObjName(null) + " - " + getFrame().getTitle();
		setFrameTitle(title);

		if (_enablePersonalizeGroup) {
			// callFX_FXBAL0140_Srch02の中の、layputAfterOpenでやるべき残処理
			// パーソナライズグループの配置情報設定を無効にする処理
			getBaseRootPanel().enablePersonalizeLocation = false;
			// 検索条件枠更新
			updateConditionParts();

			// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
			initMaximumSizeConditionParts();
			afterOpenByFX_FXBAL0140_Srch02Sub();
		}
		else {
			// 先に画面を表示し、定義を検索
			callFX_FXBAL0140_Srch02();
		}
	}

	/**
	 * 画面表示後通信の後処理です。
	 *
	 */
	protected void afterOpenByFX_FXBAL0140_Srch02() {
		// 動的テーブル設定
		initConditionParts();
		initDTable();

		if (!_enablePersonalizeGroup) {
			afterOpenByFX_FXBAL0140_Srch02Sub();
		}
	}

	private void afterOpenByFX_FXBAL0140_Srch02Sub(){
		// 更新可・不可の設定をキャッシュ
		// 更新可・不可に応じ、土台画面にモードを設定
		if (getInfoR().upd()) {
			//setUPDStatus();
			_base.setStatus(UPD_BASE);
		}
		else {
			//setFIXStatus();
			_base.setStatus(FIX_BASE);
		}

		super.layoutAfterOpen();

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 画面部品を生成した後に初期のフォント比率で再レイアウトする。
		MCRootPanel base = getBaseRootPanel();
		int ratio =  base.getFontRatio();
		if (ratio != 100) {
			// 部品が100のままのサイズになるため一旦100に戻してから再計算する。
			base.updatePanel(100, ratio);
			base.updatePanel(ratio, 100);

			// 7013-2275(SP3高解像度対応不具合まとめ)
			// フォント比率変更によるdivider位置を再調整する。
			base.setNeedResetDividerLocation(true);
			MCBeansUtil.setInitSplitPane(base, true);
		}
	}

	/**
	 * 更新処理を実行します。
	 *
	 */
	public void doUpdate() {
		callFX_FXBAL0140_Upd01();
	}

	/**
	 * UPDステータス変更時に使用する、土台画面のステータスを設定します。
	 *
	 * @param status 土台画面のステータス
	 */
	public void setUPDBaseStatus(String status) {
		UPD_BASE = status;
		_base = getBaseRootPanel();
	}
	/**
	 * FIXステータス変更時に使用する、土台画面のステータスを設定します。
	 *
	 * @param status 土台画面のステータス
	 */
	public void setFIXBaseStatus(String status) {
		FIX_BASE = status;
		_base = getBaseRootPanel();
	}

	/**
	 * 初期化します。
	 *
	 * <p>
	 * 検索条件に初期値を設定する場合は、設定する項目を引数 cond に
	 * 一時カラムで追加し、値を設定してください。
	 * 設定した値はgetInitCondition()で取得できます。<br>
	 * 検索条件はサーバから定義取得後、検索条件組み立て処理で設定されます。
	 * そのため、CallAfterListener#resultSuccessDef()のタイミングで
	 * 追加、変更が可能です。<br>
	 *
	 * @param mid モジュールID（土台画面）
	 * @param sid 画面ID（土台画面）
	 * @param table テーブル
	 * @param cond 初期検索条件。設定しない場合は null
	 */
	public void initTbledit(String mid, String sid, String table, MCRow cond) {
		_mid = mid;
		_sid = sid;
		_table = table;
		_cond = (cond != null) ? cond.clone() : MCRow.create();

		valueInit();
	}

	/**
	 * 対象のテーブルの名前を返します。
	 *
	 * @return テーブル名
	 */
	public String getTableName() {
		return _table;
	}

	/**
	 * 検索条件値を返します。
	 *
	 * <p>
	 * 戻り値にCallAfterListener#resultSuccessDef()のタイミングで
	 * 値を設定すると、検索条件の初期値に設定できます。
	 *
	 * @return 検索条件値
	 */
	public MCRow getInitCondition() {
		return _cond;
	}

	/**
	 * テーブルに選択カラムを追加します。
	 *
	 * この部品標準の機能（更新、行削除等）とは連動しません。
	 *
	 * @param col カラム名
	 * @param name 表示名称
	 */
	public void setTableRowSelector(String col, String name) {
		sel_col = col;
		sel_name = (name == null) ? sel_col : name;
	}
	/**
	 * 選択カラムで選択されているRowを返します。
	 *
	 * @return 選択されているRowのList。
	 *         未選択時は空のList。
	 *         選択カラム未設定時は null
	 */
	public MCList<MCDTableRow> getSelected() {
		if (sel_col == null) {
			return null;
		}
		return (aDtlL == null)
						? MCList.create(MCDTableRow.class)
						: aDtlL.subList(sel_col, true);
	}
	/**
	 * 全選択カラムを選択します
	 *
	 * 選択カラム未設定時は何もしません。
	 */
	public void doSelectAll() {
		if (sel_col == null) {
			return;
		}
		MCColumnConfig column = columnMap.get(sel_col);
		for (MCDTableRow r : DtlTable.getViewRows()) {
			// FC7011#041 編集不可のcheckカラムは全選択のときにスキップする
			MCMode mode = column.getMode();
			if (mode == MCMode.ENABLE || mode == MCMode.REQUIRED) {
				setValueEx(column, r.getGUIIndex(), true);
			}
		}
	}
	/**
	 * 全選択カラムを選択解除します。
	 *
	 * 選択カラム未設定時は何もしません。
	 */
	public void doDeselectAll() {
		if (sel_col == null) {
			return;
		}
		MCColumnConfig column = columnMap.get(sel_col);
		for (MCDTableRow r : DtlTable.getViewRows()) {
			// FC7011#041 編集不可のcheckカラムは全解除のときにスキップする
			MCMode mode = column.getMode();
			if (mode == MCMode.ENABLE || mode == MCMode.REQUIRED) {
				setValueEx(column, r.getGUIIndex(), false);
			}
		}
	}

	/**
	 * 通信処理終了のリスナを設定します。
	 *
	 * @param listener リスナ
	 */
	public void setCallAfterListener(FXBAP0140CallAfterListener listener) {
		callAfter = listener;
	}

	/**
	 * テーブルリソースのアプリケーション定義リソースを返します。
	 *
	 * @return リソース
	 */
	public FXBAP0140AppDefResource getAppDefResource() {
		return _appDefRes;
	}


	/**
	 * 選択カラム項目の場合 true を返します。
	 *
	 * @param defR 項目定義
	 * @return 選択カラム以外の場合 false
	 */
	protected boolean isSelector(DefR defR) {
		return (defR.opt() == FXBAC_TableEdit.DEFOPT_SELECTOR);
	}
	/**
	 * 名称連携用カラム項目の場合 true を返します。
	 *
	 * @param defR 項目定義
	 * @return 名称連携用カラム以外の場合 false
	 */
	protected boolean isLinkName(DefR defR) {
		return (defR.opt() == FXBAC_TableEdit.DEFOPT_LINKNAME);
	}
	/**
	 * コンボボックスを使用する項目の場合 true を返します。
	 *
	 * 検索条件のみ、一覧のみ、両方にかかわらず、使用する場合は ture を返します。
	 *
	 * @param defR 項目定義
	 * @return コンボボックスを使用しない場合 false
	 */
	protected boolean isCombo(DefR defR) {
		String opt = defR.opt();
		return (opt != null && opt.startsWith( FXBAC_TableEdit.DEFOPT_COMBO + FXBAC_TableEdit.DEFOPT_SEP));
	}
	/**
	 * 検索条件にコンボボックスを使用する項目の場合 true を返します。
	 *
	 * @param defR 項目定義
	 * @return コンボボックスを使用しない場合 false
	 */
	protected boolean isCondCombo(DefR defR) {
		String[] opt = analyzeComboOption(defR);
		if (opt == null) {
			return false;
		}
		return isCondCombo(opt[FXBAC_TableEdit.DEFOPT_COMBO_USE]);
	}
	/**
	 * 検索条件にコンボボックスを使用する場合 true を返します。
	 *
	 * @param opt コンボボックス項目定義オプションの値
	 * @return コンボボックスを使用しない場合 false
	 */
	protected boolean isCondCombo(String opt) {
		return (FXBAC_TableEdit.DEFOPT_COMBO_USE_BOTH.equals(opt) ||
				FXBAC_TableEdit.DEFOPT_COMBO_USE_COND.equals(opt));
	}
	/**
	 * 一覧にコンボボックスを使用する項目の場合 true を返します。
	 *
	 * @param defR 項目定義
	 * @return コンボボックスを使用しない場合 false
	 */
	protected boolean isDtlCombo(DefR defR) {
		String[] opt = analyzeComboOption(defR);
		if (opt == null) {
			return false;
		}
		return isDtlCombo(opt[FXBAC_TableEdit.DEFOPT_COMBO_USE]);
	}
	/**
	 * 一覧にコンボボックスを使用する場合 true を返します。
	 *
	 * @param opt コンボボックス項目定義オプションの値
	 * @return コンボボックスを使用しない場合 false
	 */
	protected boolean isDtlCombo(String opt) {
		return (FXBAC_TableEdit.DEFOPT_COMBO_USE_BOTH.equals(opt) ||
				FXBAC_TableEdit.DEFOPT_COMBO_USE_DTL.equals(opt));
	}
	/**
	 * コンボボックス用オプション設定を解析します。
	 *
	 * 解析結果の配列には次の順に値が格納されます。
	 * <dl>
	 * <dt>1番目</dt>
	 * <dd>適用箇所 [both(検索,一覧) / cond(検索) / dtl(一覧)]</dd>
	 * <dt>2番目</dt>
	 * <dd>[リストロジック].[メソッド]</dd>
	 * <dt>3番目</dt>
	 * <dd>[項目名],[名称用連携項目名]</dd>
	 * <dt>4番目</dt>
	 * <dd>[リストロジックカラム：コード],[リストロジックカラム：名称]</dd>
	 * </dl>
	 *
	 * @param defR 項目定義
	 * @return 解析結果の配列。コンボボックスを使用しない場合 null
	 */
	protected String[] analyzeComboOption(DefR defR) {
		if (!isCombo(defR)) {
			return null;
		}
		String[] opts = MCStringUtil.split(FXBAC_TableEdit.DEFOPT_SEP, defR.opt());
		return Arrays.copyOfRange(opts, 1, opts.length);
	}
	/**
	 * コンボボックス用オプションの項目設定を解析します。
	 * link設定およびalias設定の解析に使用します。
	 *
	 * 解析結果の配列には次の順に値が格納されます。
	 * <dl>
	 * <dt>1番目</dt>
	 * <dd>コンボボックスの項目名</dd>
	 * <dt>2番目</dt>
	 * <dd>名称用連携項目名</dd>
	 * <dt>3番目以降</dt>
	 * <dd>その他の連携項目名</dd>
	 * </dl>
	 *
	 * @param link link設定またはalias設定
	 * @return 解析結果の配列
	 */
	protected String[] analyzeComboColumn(String link) {
		return link.split(",");
	}

	/**
	 * テーブルの構成要素の名前を返します。
	 *
	 * @param colid カラム名。テーブル名を取得する場合は null
	 * @return 名前
	 */
	private String getTableObjName(String colid) {
		String tblid = getInfoR().table();
		if (colid != null) {
			int idx = colid.indexOf('.');
			if (idx >= 0) {
				// 外部結合カラムの場合
				tblid = colid.substring(0, idx);
				colid = colid.substring(idx + 1);
			}
		}

		String tbl = (tblid != null) ? tblid.toUpperCase() : null;
		String col = (colid != null) ? colid.toUpperCase() : null;
		String label = getDBLabel(tbl, col);
		return (label != null)
				? label
				: (col == null) ? tbl : col;
	}



//******************************************************************************
// 動的条件
//******************************************************************************
	/**
	 * 検索条件部品
	 */
	protected List<ConditionEditor> _condParts = new ArrayList<ConditionEditor>();
	/**
	 * 検索条件オブジェクト
	 */
	protected List<MCValueSupply> _condList = new ArrayList<MCValueSupply>();
	/**
	 * 検索条件部品配置のマージン
	 */
	protected int _cond_margin = MCConst.app.getInteger("FX.FXBAP0140.cond.margin", 5);
	/**
	 * 検索枠列幅
	 */
	protected int _cond_colwidth = MCConst.app.getInteger("FX.FXBAP0140.cond.colwidth", 350);
	/**
	 * 検索枠列数
	 */
	protected int _cond_size = 0;
	/**
	 * 検索条件部品を初期化します。
	 *
	 * getDefL()で取得した定義に従います。
	 */
	protected void initConditionParts() {
		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 画面サイズ変更検知リスナ設定
//		Ctrl_ctrl_PPanel.getExpandSplitPane().addComponentListener(new ComponentListener() {
//			@Override
//			public void componentResized(ComponentEvent e) {
//				updateConditionParts();
//			}
//			@Override
//			public void componentMoved(ComponentEvent e) {
//			}
//			@Override
//			public void componentShown(ComponentEvent e) {
//			}
//			@Override
//			public void componentHidden(ComponentEvent e) {
//			}
//		});

		// 7.0.1.2 フォント比率対応
//		FoldPanel.addComponentListener(new ComponentListener() {
//			@Override
//			public void componentResized(ComponentEvent e) {
//				resizeConditionParts();
//			}
//			@Override
//			public void componentMoved(ComponentEvent e) {
//			}
//			@Override
//			public void componentShown(ComponentEvent e) {
//			}
//			@Override
//			public void componentHidden(ComponentEvent e) {
//			}
//		});

		// 検索条件作成
		MCList<DefR> defL = getDefL();
		for (int i = 0; i < defL.size(); i++) {
			DefR defR = defL.get(i);
			if (!defR.cond()) {
				continue;
			}

			// 検索条件
			MCValueSupply param = createParam(defR, _cond);
			if (param == null) {
				continue;
			}
			_condList.add(param);

			// エディタ
			ConditionEditor editor = null;
			MCDataType type = MCDataType.valueOf(defR.type());
			switch (type) {
			case DATE:
			case TIMESTAMP:
				// TOパラメータ追加
				DefR defR2 = defR.clone();
				defR2.id(defR2.id() + FXBAC_TableEdit.COND_DATE_TO);
				MCValueSupply paramTo = createParam(defR2, _cond);
				_condList.add(paramTo);
				editor = createEditor(defR, param, paramTo);
				break;
			default:
				editor = createEditor(defR, param);
				break;
			}
			if (editor == null) {
				continue;
			}
			_condParts.add(editor);
		}

		if (_enablePersonalizeGroup) {
			int cond_size = _cond_size;
			if (cond_size == 0) {
				cond_size = 1;
			}

			// 検索枠列パネル作成
			MCPanel[] conds = createCondPanel(cond_size);
			for (int i = 0; i < _condParts.size(); i++) {
				ConditionEditor editor = _condParts.get(i);
				int j = i % conds.length;
				conds[j].add((Component) editor);
			}

		}
		else {
			// 検索条件枠更新
			updateConditionParts();

			// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
			initMaximumSizeConditionParts();
		}
	}
	/**
	 * 検索条件オブジェクトを生成します。
	 *
	 * @param defR 項目定義
	 * @param cond 初期検索条件
	 * @return 検索条件オブジェクト
	 */
	protected MCValueSupply createParam(DefR defR, MCRow cond) {
		String vstype = null;
		MCDataType type = MCDataType.valueOf(defR.type());
		switch (type) {
		case STRING:
			vstype = (isCondCombo(defR))
								? MCDashboardUtil.TYPE_STRING_COMBO
								: MCDashboardUtil.TYPE_STRING;
			break;
		case NUMBER:
			vstype = MCDashboardUtil.TYPE_NUMBER;
			break;
		case BOOLEAN:
			vstype = MCDashboardUtil.TYPE_BOOLEAN;
			break;
		case DATE:
			vstype = MCDashboardUtil.TYPE_DATE;
			break;
		case TIMESTAMP:
			vstype = MCDashboardUtil.TYPE_TIMESTAMP;
			break;
		default:
			// BinaryとInnerRowは対応しない
			break;
		}
		MCValueSupply param = MCValueSupply.create(
									defR.id(),
									getTableObjName(defR.name()),
									vstype,
									false,
									true,
									// FC7011#041 運用日付を画面から取得
									getToday());
		if (param == null) {
			return null;
		}

		switch (type) {
		case STRING:
			if (cond != null) {
				param.value(cond.getStringNE(param.column()));
			}
			break;
		case NUMBER:
			if (cond != null) {
				param.value(cond.getNumberNE(param.column()));
			}
			break;
		case BOOLEAN:
			boolean used = false;
			if (cond != null) {
				// 初期値がある場合は検索条件に利用
				if (used = (cond.getMeta(param.column()) != null)) {
					param.value(cond.getBooleanNE(param.column()));
				}
			}
			MCValueSupply.BooleanVS booParam = (MCValueSupply.BooleanVS) param;
			booParam.setUsed(used);
			break;
		case DATE:
			if (cond != null) {
				param.value(cond.getDateNE(param.column()));
			}
			break;
		case TIMESTAMP:
			if (cond != null) {
				param.value(cond.getTimestampNE(param.column()));
			}
			break;
		default:
			break;
		}
		return param;
	}
	/**
	 * 検索条件部品を生成します。
	 *
	 * @param defR 項目定義
	 * @param params 検索条件オブジェクト
	 * @return 検索条件部品
	 */
	protected ConditionEditor createEditor(DefR defR, MCValueSupply...params) {
		ConditionEditor editor = null;

		// エディタ生成
		MCDataType type = MCDataType.valueOf(defR.type());
		switch (type) {
		case STRING:
			if (isCondCombo(defR)) {
				editor = FXBAP0200.create();
				// 検索条件初期値設定時にコンボのイベントを発動させるため、
				// setParam前にコンボの初期化を行う
				initComboEditor((FXBAP0200) editor, defR);
			}
			else {
				editor = FXBAP0160.create();
				initTextEditor((FXBAP0160)editor);
			}
			break;
		case NUMBER:
			editor = FXBAP0170.create();
			break;
		case BOOLEAN:
			editor = FXBAP0220.create();
			break;
		case DATE:
		case TIMESTAMP:
			editor = FXBAP0230.create();
			break;
		default:
			break;
		}
		if (editor == null) {
			return null;
		}

		// エディタ初期化
		// エディタ初期化時は便宜的に部品の初期ステータスを関連付ける
		editor.initEditor(getInitStatus(), params);
		// createGUIKeyの戻り値が一意になるように名前を付ける
		editor.setName(defR.id());
		// FC7011#006 画面の全ステータスとエディタのステータスを関連付ける
		String editorStatus = editor.getStatusFor(params);
		MCRootPanel root = (MCRootPanel) editor;
		for (String status : getStatusSet()) {
			root.putStatus(status, editorStatus);
		}
		return editor;
	}
	/**
	 * コンボボックス検索条件部品を初期化します。
	 *
	 * @param editor コンボボックス検索条件部品
	 * @param defR 項目定義
	 */
	protected void initComboEditor(FXBAP0200 editor, DefR defR) {
		String[] opts = analyzeComboOption(defR);
		if (opts == null) {
			return;
		}
		editor.setListLogic(opts[FXBAC_TableEdit.DEFOPT_COMBO_LOGIC],
							opts[FXBAC_TableEdit.DEFOPT_COMBO_ALIAS]);
		editor.Value_value.setListType(MCListType.FREE);
		editor.setPluralValueEnable(editor.Value_value, true);
	}
	
	/**
	 * テキストフィールド検索条件部品を初期化します。
	 * 
	 * @param editor テキストフィールド検索条件部品
	 */
	protected void initTextEditor(FXBAP0160 editor) {
		editor.setPluralValueEnable(editor.Value_value, true);
	}
	
	/**
	 * 検索条件枠を更新します。
	 *
	 * @return レイアウト変更があった場合 true
	 */
	protected boolean updateConditionParts() {

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		Dimension margin = new Dimension(_cond_margin, _cond_margin);

		// FC7011#006 フォント拡大時の調整
		// フォント拡大率
//		int raito = getBaseRootPanel().getFontRatio();
		int ratio = getBaseRootPanel().getLayoutRatio();

//		MCPanel base = FoldBasePanel;
		MCPanel base = FoldPanel;

		// 画面サイズに合わせ、検索枠列数を調整
		int newsize = base.getSize().width / (_cond_colwidth * ratio / 100);
		if (_enablePersonalizeGroup) {
			MCPanel parentPanel = MCBeansUtil.getPanel(this);
			newsize = parentPanel.getSize().width / (_cond_colwidth * ratio / 100);
		}
		if (newsize == 0) {
			newsize = 1;
		}
		if (newsize == _cond_size) {
			return false;
		}
		_cond_size = newsize;

		for (ConditionEditor editor : _condParts) {
			editor.updateParam();
		}
		base.removeAll();

		base.setLayout(new BoxLayout(base, BoxLayout.X_AXIS));
		//BoxLayout2でBoxLayoutのデバッグ可能
//		base.setLayout(new BoxLayout2(base, BoxLayout.X_AXIS));

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		int condPartsSize = _condParts.size();
		if(condPartsSize % _cond_size != 0) {
			condPartsSize += (condPartsSize % _cond_size);
		}

		// 検索枠列パネル作成
		MCPanel[] conds = createCondPanel(_cond_size);
		int[] h = new int[_cond_size];

		// 検索条件追加
		ConditionEditor last = null;
		for (int i = 0; i < condPartsSize; i++) {
			if(i < _condParts.size()) {
				ConditionEditor editor = _condParts.get(i);

				int j = i % conds.length;
				// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
				// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//				conds[j].add(Box.createRigidArea(margin));
				conds[j].add(_createRigidArea(margin.width , margin.height, ratio, null));
				h[j] += margin.height;
				conds[j].add((Component) editor);
				h[j] += editor.getMaximumSize().height;

				// タブオーダー
				if (last == null) {
					conds[j].setLastBeans(editor);
				}
				else {
					last.setNextBeans(editor);
				}
				last = editor;
			} else {
				ConditionEditor editor = new FXBAP0150();
				editor.initEditor(getInitStatus(), new MCValueSupply[0] );

				// サイズは第一部品と同じにする。
				ConditionEditor editor2 = _condParts.get(0);
				((MCRootPanel) editor).setSize(editor2.getSize());
				// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
				// フォント比率100の時のサイズを設定
				((MCRootPanel) editor).setDefaultRatioSize(editor2.getDefaultBounds());

				int j = i % conds.length;
				// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
				// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//				conds[j].add(Box.createRigidArea(margin));
				conds[j].add(_createRigidArea(margin.width , margin.height, ratio, null));
				h[j] += margin.height;
				conds[j].add((Component) editor);
				h[j] += editor.getMaximumSize().height;
			}
		}

		// 検索枠列サイズ調整
		for (int i= 0; i < conds.length; i++) {
			// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//			conds[i].add(Box.createRigidArea(margin));
			conds[i].add(_createRigidArea(margin.width , margin.height, ratio, null));
			h[i] += margin.height;

			Dimension d = conds[i].getPreferredSize();
			d.height = h[i];
			Border b = conds[i].getBorder();
			if (b != null) {
				Insets insets = b.getBorderInsets(conds[i]);
				d.height += (insets.top + insets.bottom);
			}
			conds[i].setPreferredSize(d);
			conds[i].setSize(d);
		}

		// 検索枠サイズ調整
		Arrays.sort(h);
		int panel_h =  h[h.length - 1];
		Component[] bases = { FoldPanel, FoldScrollPane, FoldBasePanel };
		for (Component c : bases) {
			Dimension d = c.getPreferredSize();
			d.height = panel_h;
			c.setPreferredSize(d);
			c.setSize(d);
		}

		Dimension d = TopPanel.getSize();
		d.height = 0;
		for (Component c : TopPanel.getComponents()) {
			d.height += c.getSize().height;
		}
		TopPanel.setPreferredSize(d);
		TopPanel.setSize(d);
		TopPanel.getParent().setPreferredSize(d);
		TopPanel.getParent().setSize(d);

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 高解像度対応 CtrlPanelがFoldBasePanelの下に来るためCtrlPanelのy位置を0から変更する。
		CtrlPanel.setLocation(CtrlPanel.getX(), TopPanel.getHeight() - CtrlPanel.getHeight());

		// 7013-0007 フォント比率変更に対応させるためinitializedを実行する。
		for(MCPanel cond : conds) {
			cond.initialized();
		}

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007 Foldをフォント比率変更に対応させる。
		// widthは初期値を使用
		// heightは部品追加の最大高さを使用
//		base.setPreferredSize(base.getSize());
		Rectangle br = base.getDefaultRatioBounds();
		Dimension bd = base.getSize();
		base.setDefaultRatioSize(new Rectangle(0,0,br.width,bd.height));

		return true;
	}

	// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	//フォント比率が変更された場合に呼ばれるメソッド
	// 部品のmaximumSizeをフォント比率対応する。
//	@Override
//	protected void _updatePanelMaxSize(int ratio) {
//		super._updatePanelMaxSize(ratio);
//		// resizeConditionParts();
//	}

	// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// BoxLayoutが部品の最大サイズで調整されるための初期値設定。
	protected void initMaximumSizeConditionParts() {
		int font_ratio = getBaseRootPanel().getFontRatio();

		// フォント比率100のときのサイズを設定
		if (font_ratio == 100) {
			for (ConditionEditor editor : _condParts) {
				_putMaxMap((Component) editor, editor.getSize());
			}

		} else {
			for (ConditionEditor editor : _condParts) {
				// 100のサイズに比率を掛け合わせ。
				Dimension d = ((MCResourceBeans) editor).getDefaultSize();
				Dimension d2 = new Dimension((int) Math.ceil(d.width * font_ratio / 100.0),
						(int) Math.ceil(d.height * font_ratio / 100.0));
				_putMaxMap((Component) editor, d2);
			}
		}
	}

	/**
	 * 検索枠列パネル作成メソッド
	 * 
	 * @param cond_size 検索枠列数
	 * @return 検索枠列パネル
	 */
	private MCPanel[] createCondPanel(int cond_size) {
		// 検索枠列パネル作成
		MCPanel base = FoldPanel;

		MCPanel[] conds = new MCPanel[cond_size];
		for (int i = 0; i < cond_size; i++) {
			MCPanel cond = beansFactory.createPanel("CondPanel" + i);
			conds[i] = cond;
			if (i == 0) {
				base.setFirstBeans(cond);
			}
			else {
				conds[i - 1].setNextBeans(cond);
			}

			cond.removeAll();
			cond.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
			cond.setLayout(new BoxLayout(cond, BoxLayout.Y_AXIS));
			cond.setBorder(BorderFactory.createEmptyBorder(0, _cond_margin, 0, _cond_margin));
			base.add(cond);
		}
		return conds;
	}

//******************************************************************************
// 動的テーブル
//******************************************************************************
	/**
	 * 動的テーブル用コンテナ
	 */
	private MCDTableList aDtlL;
	/**
	 * コピーによってaDtlLを設定します。
	 *
	 * aDtlLのインスタンスは変更されません。
	 *
	 * @param dataset DtlL
	 */
	public void setDtlL(MCDTableList aList) {
		if (getDtlL() != aList) {
			getDtlL().setAll(aList);
		}
	}
	/**
	 * [Dtl]ブロックのコンテナaDtlLを返します。
	 *
	 * @return DtlL
	 */
	public MCDTableList getDtlL() {
		return aDtlL;
	}
	/**
	 * aDtlLを作成します。
	 *
	 * @return DtlL
	 */
	public MCDTableList createDtlL(MCDTableRow row) {
		if (aDtlL == null) {
			aDtlL = MCDTableList.create(row);
		}
		return aDtlL;
	}

	/**
	 * 動的テーブルのカラムのメタ
	 * 選択カラムも含みます。
	 */
	protected MCMeta[] Dtl_METAs;
	/**
	 * 動的テーブルのキー項目
	 */
	protected String[] Dtl_keys;
	/**
	 * カラムコンフィグマップ
	 * キー：カラム名、値：カラムコンフィグ
	 * 選択カラムも含みます。
	 */
	protected Map<String, MCColumnConfig> columnMap = new LinkedHashMap<String, MCColumnConfig>();

	/**
	 * 選択カラム名
	 * 非表示の場合は null
	 */
	protected String sel_col = null;
	/**
	 * 選択カラム表示名称
	 */
	protected String sel_name = null;

	/**
	 * ListPutterのマップ
	 * キー：カラムコンフィグ 値：ListPutter
	 */
	protected Map<MCColumnConfig, MCListPutter> putterDtls = new HashMap<MCColumnConfig, MCListPutter>();
	/**
	 * コンボリストのマップ
	 * キー：項目定義Row 値：コンボリスト
	 */
	protected Map<DefR, MCList> comboDefMap = new HashMap<DefR, MCList>();
	/**
	 * コンボボックス項目定義
	 */
	protected MCList<DefR> comboL = MCList.create(DefR.class);
	/**
	 * コンボボックス項目定義インデックス
	 * キー：ID
	 */
	protected MCIndexKey comboL_idx = null;

	/**
	 * DtlTableを初期化します。
	 */
	protected void createDtlTable(){
		if(DtlTable == null){
			DtlTable = beansFactory.createTable2("Dtl.table");
		}
	}
	/**
	 * 動的テーブルを生成します。
	 */
	protected void initDTable() {
		createColumnInfo();
		createDtlL(new MCDTableRow(Dtl_METAs, null, Dtl_keys));

		jbInitDTable();
		mcInitDTable();
		setTableConfigDTable();
		listInitDTable();
		
		if (_enablePersonalizeGroup) {
			setPopupConfig(DtlTable);
		}
		else {
			initDTableSub();
		}
	}

	protected void initDTableSub() {
		class PProxy extends AbsMCPackageProxy {
			@Override
			protected void setUserSortPolicy(
					MCTable<?> table) {
				super.setUserSortPolicy(table);
			}
			@Override
			protected void setUserRowSignal(
					MCTable<?> table) {
				super.setUserRowSignal(table);
			}
		}
		PProxy px = new PProxy();

		putCachedVisibleColumnConfigs(DtlTable, SORT_ORDER_PANEL, null); // キャッシュクリア
		DtlTable.setSortPolicyDefault(); // カスタマイズ実装の設定に戻す
		px.setUserSortPolicy(DtlTable); // パーソナライズ反映

		putCachedVisibleColumnConfigs(DtlTable, ROW_SIGNAL_PANEL, null); // キャッシュクリア
		px.setUserRowSignal(DtlTable); // パーソナライズ反映
		
		DtlTable.setPopupConfig(new TableEditorPopupConfig());
	}
	/**
	 * 項目定義から一覧用のカラムコンフィグを生成します。
	 * メタやキー情報など関連する情報も取得します。
	 */
	protected void createColumnInfo() {
		MCList<DefR> metaL = MCList.create(DefR.class);

		// テーブル用カラム定義
		MCList<DefR> defL = getDefL();
		MCIndexKey id_idx = defL.createIndex(DefR.$id);
		DefR selR = null;
		if (sel_col != null) {
			// 選択カラム追加
			selR = defL.createRow();
			selR.id(sel_col);
			selR.name(sel_name);
			selR.key(false);
			selR.meta(sel_col);
			selR.type(MCDataType.BOOLEAN.toString());
			selR.format(null);
			selR.mode("E");
			selR.cond(false);
			selR.opt(FXBAC_TableEdit.DEFOPT_SELECTOR);
			metaL.add(selR);
		}
		for (DefR defR : defL) {
			metaL.add(defR);
			if (isDtlCombo(defR)) {
				String[] opts = analyzeComboOption(defR);
				String[] links = analyzeComboColumn(opts[FXBAC_TableEdit.DEFOPT_COMBO_LINK]);
				if (links.length > FXBAC_TableEdit.DEFOPT_COMBO_COL_NAME) {
					String nameid = links[FXBAC_TableEdit.DEFOPT_COMBO_COL_NAME];
					if (!defL.contains(id_idx, nameid)) {
						// 名称連携カラム追加
						DefR nameR = defL.createRow();
						nameR.id(nameid);
						nameR.name(defR.name());
						nameR.key(false);
						nameR.meta(nameid);
						nameR.type(MCDataType.STRING.toString());
						nameR.format(null);
						nameR.mode("RO");
						nameR.cond(false);
						nameR.opt(FXBAC_TableEdit.DEFOPT_LINKNAME);
						metaL.add(nameR);
					}
				}
			}
		}
		defL.removeIndex(id_idx);

		// メタとカラムコンフィグの生成
		int metalen = metaL.size();
		Dtl_METAs = new MCMeta[metalen];
		List<String> keyList = new ArrayList<String>(metalen);
		for (int i = 0; i < metalen; i++) {
			DefR metaR = metaL.get(i);

			if (metaR.key()) {
				// テーブルのキー項目
				keyList.add(metaR.id());
			}

			// メタ
			MCMeta meta = createMeta(metaR);
			Dtl_METAs[i] = meta;

			// カラムコンフィグ
			MCColumnConfig conf = null;
			if (meta != null) {
				conf = createColumnConfig(metaR, meta);
				if (metaR == selR) {
					// 選択カラムはステータスを変更しない
					conf.setIgnoreStatus(true);
				}
				if (conf.getColumnType() == MCColumnType.TEXT_COMBO) {
					// コンボボックス定義
					comboL.add(metaR);
				}
			}
			columnMap.put(metaR.id(), conf);

			// テーブルに追加
			DtlTable.addColumnConfig(conf);

			// カラム初期化
			setColumnMode(conf, metaR.mode());
			if (!_enablePersonalizeGroup) {
				conf.initialized();
			}
		}
		Dtl_keys = keyList.toArray(new String[keyList.size()]);
		comboL_idx = comboL.createIndex(DefR.$id);

		// コンボリスト設定 (全カラムコンフィグ作成後)
		for (DefR metaR : comboL) {
			MCColumnConfig conf = columnMap.get(metaR.id());

			// 連携項目追加
			String[] opts = analyzeComboOption(metaR);
			String[] links = analyzeComboColumn(opts[FXBAC_TableEdit.DEFOPT_COMBO_LINK]);
			for (int i = 1; i < links.length; i++) {
				MCColumnConfig link = columnMap.get(links[i]);
				if (link != null) {
					conf.addLinkBeans(link);// 連携項目追加
				}
			}
			// listInitの処理
			conf.setListVisibleColumn(MCListLogic.getViewColumnName());
			conf.getListConfig().setPutter(getListPutter(conf));
		}

		// 7012-2055 行選択カラムをスクロール固定
		MCColumnConfig sel_cf = columnMap.get(sel_col);
		if (sel_cf != null) {
			DtlTable.setUnscrollColumn(sel_cf);
		}
	}
	/**
	 * 項目定義からメタを生成します。
	 *
	 * @param defR 項目定義
	 * @return メタ
	 */
	private MCMeta createMeta(DefR defR) {
		MCMeta meta = null;
		String id = defR.id();
		String format = defR.format();
		MCDataType type = MCDataType.valueOf(defR.type());
		switch (type) {
			case STRING:
				meta = (isLinkName(defR))
							? MCDTableRow.linkNameMeta(id)	// 名称連携用
							: (format == null)
									? MCDTableRow.stringMeta(id)
									: MCDTableRow.stringMeta(id,
											Integer.parseInt(format));
				break;
			case NUMBER:
				String numLength = getLengthStr(format);
				if (numLength == null) {
					meta = MCDTableRow.numberMeta(id);
				}
				else {
					String[] f = numLength.split(",");
					boolean minus = false;
					int a = Integer.parseInt(f[0]);
					if (a < 0) {
						minus = true;
						a *= -1;
					}
					int b = (f.length < 2) ? 0 : Integer.parseInt(f[1]);
					meta = MCDTableRow.numberMeta(id, a, b, minus);
				}
				break;
			case BOOLEAN:
				meta = (isSelector(defR))
							? MCDTableRow.selectorMeta(id)	// 選択カラム用
							: MCDTableRow.booleanMeta(id);
				break;
			case DATE:
				meta = MCDTableRow.dateMeta(id);
				break;
			case TIMESTAMP:
				meta = MCDTableRow.timestampMeta(id);
				break;
			case BINARY:
				meta = MCDTableRow.binaryMeta(id);
				break;
			default:
				break;
		}
		return meta;
	}
	
	/**
	 * 数値項目のformatの記述から、カラムの桁数の設定を取得します。
	 * formatの記述は、以下のいずれかの記述で設定します。
	 *   - [MCFormatの書式名];[桁数]
	 *   - [MCFormatの書式名]
	 *   - [桁数]
	 * @param formatStr 専用リソースファイルのformatの設定
	 * @return 桁数の記述。桁数が未設定の場合はnull。
	 */
	private String getLengthStr(String formatStr) {
		if (formatStr == null || formatStr.equals("")) {
			return null;
		}

		String[] f = formatStr.split(";");
		if (f.length > 1) {
			return f[1];
		}

		// f[0]のカンマを""にreplaceしてからparseIntして、成功すればf[0]が桁。
		String result = f[0];
		try {
			String s = f[0].replaceAll(",", "");
			Integer.parseInt(s);
		}
		catch (NumberFormatException e) {
			result = null;
		}
		return result;
	}
	
	/**
	 * カラムコンフィグを生成します。
	 *
	 * @param defR 項目定義
	 * @param meta メタ
	 * @return カラムコンフィグ
	 */
	private MCColumnConfig createColumnConfig(DefR defR, MCMeta meta) {
		MCColumnConfig conf = beansFactory.createTableColumn(
				"Dtl." + defR.id(), metaToColumnType(meta, defR));
		conf.setMeta(meta);
		conf.setHeaderName(isSelector(defR)
								? sel_name
								: getTableObjName(defR.name()));
		switch (conf.getColumnType()) {
			case TEXT_COMBO:
				conf.setListListener(this);
				break;
			case DATE:
			case TIMESTAMP:
				conf.setFormatID(defR.format());
				break;
			case NUMBER:
				String f = getFormatStr(defR.format());
				if (f != null) {
					conf.setFormatID(f);
				}
				break;
			default:
				break;
		}
		return conf;
	}

	/**
	 * 数値項目のformatの記述から、カラムの書式の設定を取得します。
	 * formatの記述は、以下のいずれかの記述で設定します。
	 *   - [MCFormatの書式名];[桁数]
	 *   - [MCFormatの書式名]
	 *   - [桁数]
	 * @param formatStr 専用リソースファイルのformatの設定
	 * @return 書式の設定。書式が未設定の場合はnull。
	 */
	private String getFormatStr(String formatStr) {
		if (formatStr == null || formatStr.equals("")) {
			return null;
		}

		String[] f = formatStr.split(";");
		if (f.length > 1) {
			return f[0];
		}

		// f[0]のカンマを""にreplaceしてからparseIntして、成功すればf[0]が桁。
		String result = null;
		try {
			String s = f[0].replaceAll(",", "");
			Integer.parseInt(s);
		}
		catch (NumberFormatException e) {
			result = f[0];
		}
		return result;
	}

	/**
	 * メタの型定義をカラムタイプに変換します。
	 *
	 * @param meta メタ
	 * @param defR 項目定義
	 * @return カラムタイプ
	 */
	private MCColumnType metaToColumnType(MCMeta meta, DefR defR) {
		MCColumnType type = null;
		switch (meta.type()) {
			case STRING:
				type = (isDtlCombo(defR))
							? MCColumnType.TEXT_COMBO : MCColumnType.TEXT;
				break;
			case NUMBER:
				type = MCColumnType.NUMBER;
				break;
			case BOOLEAN:
				type = MCColumnType.CHECK;
				break;
			case DATE:
				type = MCColumnType.DATE;
				break;
			case TIMESTAMP:
				type = MCColumnType.TIMESTAMP;
				break;
			case BINARY:
				type = MCColumnType.IMAGE_VIEW;
				break;
			default:
				// InnerRowは対応しない
				break;
		}
		return type;
	}
	/**
	 * カラムにモードを設定します。
	 *
	 * 引数 mode によって、FIX時とUPD時のモードを決定します。
	 *
	 * @param conf カラムコンフィグ
	 * @param mode モード
	 */
	private void setColumnMode(MCColumnConfig conf, String mode) {
		if (conf == null) {
			return;
		}
		MCMode fix = MCMode.READ_ONLY;
		MCMode upd = MCMode.ENABLE;
		if (mode == null) {
		}
		else switch (mode) {
			case "E":
				fix = MCMode.READ_ONLY;
				upd = MCMode.ENABLE;
				break;
			case "R":
				fix = MCMode.READ_ONLY;
				upd = MCMode.REQUIRED;
				break;
			case "RO":
				fix = MCMode.READ_ONLY;
				upd = MCMode.READ_ONLY;
				break;
			case "D":
				fix = MCMode.DISABLE;
				upd = MCMode.DISABLE;
				break;
			case "I":
				fix = MCMode.INVISIBLE;
				upd = MCMode.INVISIBLE;
				break;
			default:
				break;
		}
		conf.putMode(this, FIX, fix);
		conf.putMode(this, UPD, upd);
	}

	/**
	 * 動的テーブル用 jbInit
	 */
	protected void jbInitDTable() {
		jbfInitDtl_();
		jbInitDtl_();
	}
	protected void jbfInitDtl_() {
		// メタと同時に生成
	}
	protected void jbInitDtl_() {
		// モデル設定
		DtlTable.setList(getDtlL());

		// セルコンフィグ設定
		String cellclass = getInfoR().cell();
		if (cellclass == null) {
			cellclass = FXBAP0140CellConfig.class.getName();
		}
		FXBAP0140CellConfig cell =
				MCFactory.create(FXBAP0140CellConfig.class, cellclass);
		DtlTable.setCellConfig(cell);
	}

	/**
	 * 動的テーブル用 mcInit
	 */
	protected void mcInitDTable() {
		mcInitDtl_();

		// ステータスは createColumnInfo で設定
	}
	protected void mcInitDtl_() {
		for (MCColumnConfig conf : columnMap.values()) {
			conf.addAllListener(this);
			conf.setListListener(this);
			if (conf.getDataType() == MCDataType.NUMBER) {
				conf.setMinusEnable(true);
			}
		}
	}

	/**
	 * 動的テーブル用 setTableConfig
	 */
	protected void setTableConfigDTable() {
		// カラムコンフィグは createColumnInfo で設定
	}

	/**
	 * 動的テーブル用 listInit
	 */
	protected void listInitDTable() {
		// ListPutterは createColumnInfo で設定
	}

	/**
	 * ListPutterを返します。
	 *
	 * @param column カラムコンフィグ
	 * @return ListPutter。カラムコンフィグに対するListPutterがない場合 null
	 */
	protected MCListPutter getListPutter(MCColumnConfig column) {
		MCListPutter putter = putterDtls.get(column);
		if (putter == null) {
			DefR defR = getDefL().getFirst(DefR.$id, column.getRowColumnName());
			String[] opts = analyzeComboOption(defR);
			String[] alias = analyzeComboColumn(opts[FXBAC_TableEdit.DEFOPT_COMBO_ALIAS]);
			putter = createListPutter(column, alias);
			putterDtls.put(column, putter);
		}
		return putter;
	}
	/**
	 * ListPutterを生成します。
	 *
	 * 引数 columns にはリストロジックが返すコンテナのカラム名を設定します。
	 * 順番は次のようにします。
	 * <dl>
	 * <dt>1番目</dt>
	 * <dd>画面部品と対になるカラム</dd>
	 * <dt>2番目</dt>
	 * <dd>画面部品の表示名称と対になるカラム</dd>
	 * <dt>3番目～</dt>
	 * <dd>連携項目と対になるカラム</dd>
	 * </dl>
	 * 2番目以降の並び順は、引数 compo に対する addLinkBeans() で設定する
	 * 連携項目の順番と合わせる必要があります。
	 *
	 * @param compo リストを設定する画面部品
	 * @param columns リストロジックから取得するカラム名の配列
	 * @return ListPutter
	 */
	protected MCListPutter createListPutter(MCLinkBeans compo, String... columns) {
		return new MCListPutter(compo, columns);
	}
	/**
	 * コンボ用リストを返します。
	 *
	 * @param combo コンボボックス
	 * @param row 抽出条件
	 * @param info EventInfo
	 * @return リスト
	 */
	@Override
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if (list != null) return list;
		for (MCColumnConfig conf : columnMap.values()) {
			if (combo == conf) {
				if (conf.getColumnType() != MCColumnType.TEXT_COMBO) {
					break;
				}
				DefR defR = comboL.getFirst(comboL_idx, conf.getRowColumnName());
				return getComboList(defR, row, info);
			}
		}
		return null;
	}
	/**
	 * コンボ用リストを返します。
	 *
	 * @param listmethod リストロジックとメソッド
	 * @param row 抽出条件
	 * @param info EventInfo
	 * @return リスト
	 */
	public MCList getComboList(DefR defR, MCRow row, MCEventInfo info){
		String[] opts = analyzeComboOption(defR);
		if (opts == null) {
			return null;
		}

		MCList list = comboDefMap.get(defR);
		if (list != null) {
			return list;
		}

		String listmethod = opts[FXBAC_TableEdit.DEFOPT_COMBO_LOGIC];
		int ext = listmethod.lastIndexOf('.');
		String clazz = listmethod.substring(0, ext);
		String method = listmethod.substring(ext + 1);

		// 抽出条件
		String[] conds = MCStringUtil.split(FXBAC_TableEdit.DEFOPT_COMBO_CONDS_SEP,
											opts[FXBAC_TableEdit.DEFOPT_COMBO_CONDS]);
		for (String cond : conds) {
			if (cond != null) {
				String[] conditem =  cond.split(FXBAC_TableEdit.DEFOPT_COMBO_CONDS_ITEMSEP, 2);
				row.addStringColumn(conditem[1], conditem[0]);
			}
		}

		MCListLogic ll = (MCListLogic) MCFactory.invokeStatic(MCListLogic.class, "create",
				new Class<?>[] { String.class, MCRootPanel.class },
				new Object[] { clazz, this }
		);
		list = (MCList) MCFactory.invoke(ll, method,
				new Class<?>[] { MCRow.class, MCEventInfo.class },
				new Object[] { row, info }
		);
		comboDefMap.put(defR, list);
		return list;
	}

// 汎用テーブルは動的に生成されるため呼ばれない
//	@Override
//	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
//		FXBAP_PopupConfig conf = super.createFXBAP_PopupConfig(beans);
//		if (beans == DtlTable) {
//			// パーソナライズ不可
//			conf.ignoreColumnWidth(true);
//			conf.ignoreSortOrder(true);
//			conf.ignoreRowFilter(true);
//			conf.ignoreRowSignal(true);
//		}
//		return conf;
//	}

	/**
	 * 汎用テーブル用のポップアップコンフィグです。
	 *
	 */
	public class TableEditorPopupConfig extends FXBAP_PopupConfig {

		@Override
		protected void customPopup(MCPopupMenu menu, MCRootPanel panel) {
			if (!_enablePersonalizeGroup) {
				menu.removeMenu(getSrchCndMenu());
			}
			menu.removeMenuItem(getPanelVerticalViewMenu());
			menu.removeMenu(getBookMarkMenu());
		}

		@Override
		protected void customPopup(MCPopupMenu menu, MCTable table) {
			// パーソナライズ不可
			if (!_enablePersonalizeGroup) {
				menu.removeMenu(table.getColumnWidthMenu());
			}
// 701-00821 2017/03/21 フィルタとソート順は利用可能にする
//			menu.removeMenu(table.getSortOrderMenu());
//			menu.removeMenu(table.getRowFilterMenu());
			menu.removeMenuItem(table.getRowSignalMenuItem());
			//　シグナルを削除しようとしているが、実際には表示されている。
			// 汎用テーブル編集の存在しない項目の扱いは他の画面と同じであり、利用に問題はない。
		}

	}

}