package mcframe.clientFXBA.FXBAP0140;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Def"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class DefR_FW_A extends MCConstRow {

	/**
	 *  項目ID.<p>
	 *
	 */
	public static final String $id = "id";
	/**
	 *  表示名.<p>
	 *
	 */
	public static final String $name = "name";
	/**
	 *  キー.<p>
	 *
	 */
	public static final String $key = "key";
	/**
	 *  メタ名.<p>
	 *
	 */
	public static final String $meta = "meta";
	/**
	 *  データ型.<p>
	 *
	 */
	public static final String $type = "type";
	/**
	 *  書式.<p>
	 *
	 */
	public static final String $format = "format";
	/**
	 *  画面モード.<p>
	 *
	 */
	public static final String $mode = "mode";
	/**
	 *  検索条件.<p>
	 *
	 */
	public static final String $cond = "cond";
	/**
	 *  オプション.<p>
	 *
	 */
	public static final String $opt = "opt";


	public static final MCMeta id_META = createStringMeta($id);
	public static final MCMeta name_META = createStringMeta($name);
	public static final MCMeta key_META = createBooleanMeta($key);
	public static final MCMeta meta_META = createStringMeta($meta);
	public static final MCMeta type_META = createStringMeta($type);
	public static final MCMeta format_META = createStringMeta($format);
	public static final MCMeta mode_META = createStringMeta($mode);
	public static final MCMeta cond_META = createBooleanMeta($cond);
	public static final MCMeta opt_META = createStringMeta($opt);

	protected static final ConstMetaList<DefR> constMetas = new ConstMetaList<DefR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			id_META,
			name_META,
			key_META,
			meta_META,
			type_META,
			format_META,
			mode_META,
			cond_META,
			opt_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected DefR_FW_A(ConstMetaList<? extends DefR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DefR clone() {
		return (DefR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DefR createInstance() {
		return (DefR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DefR getValues(String... names) {
		return (DefR) super.getValues(names);
	}



	/**
	 *  項目ID.<p>
	 *
	 */
	public String id() {
		return getConstString(offset + 0, $id);
	}

	/**
	 *  項目ID.<p>
	 *
	 */
	public void id(String value) {
		setConstString(offset + 0, $id, value);
	}


	/**
	 *  表示名.<p>
	 *
	 */
	public String name() {
		return getConstString(offset + 1, $name);
	}

	/**
	 *  表示名.<p>
	 *
	 */
	public void name(String value) {
		setConstString(offset + 1, $name, value);
	}


	/**
	 *  キー.<p>
	 *
	 */
	public boolean key() {
		return getConstBoolean(offset + 2, $key);
	}

	/**
	 *  キー.<p>
	 *
	 */
	public void key(boolean value) {
		setConstBoolean(offset + 2, $key, value);
	}


	/**
	 *  メタ名.<p>
	 *
	 */
	public String meta() {
		return getConstString(offset + 3, $meta);
	}

	/**
	 *  メタ名.<p>
	 *
	 */
	public void meta(String value) {
		setConstString(offset + 3, $meta, value);
	}


	/**
	 *  データ型.<p>
	 *
	 */
	public String type() {
		return getConstString(offset + 4, $type);
	}

	/**
	 *  データ型.<p>
	 *
	 */
	public void type(String value) {
		setConstString(offset + 4, $type, value);
	}


	/**
	 *  書式.<p>
	 *
	 */
	public String format() {
		return getConstString(offset + 5, $format);
	}

	/**
	 *  書式.<p>
	 *
	 */
	public void format(String value) {
		setConstString(offset + 5, $format, value);
	}


	/**
	 *  画面モード.<p>
	 *
	 */
	public String mode() {
		return getConstString(offset + 6, $mode);
	}

	/**
	 *  画面モード.<p>
	 *
	 */
	public void mode(String value) {
		setConstString(offset + 6, $mode, value);
	}


	/**
	 *  検索条件.<p>
	 *
	 */
	public boolean cond() {
		return getConstBoolean(offset + 7, $cond);
	}

	/**
	 *  検索条件.<p>
	 *
	 */
	public void cond(boolean value) {
		setConstBoolean(offset + 7, $cond, value);
	}


	/**
	 *  オプション.<p>
	 *
	 */
	public String opt() {
		return getConstString(offset + 8, $opt);
	}

	/**
	 *  オプション.<p>
	 *
	 */
	public void opt(String value) {
		setConstString(offset + 8, $opt, value);
	}


	public String getString(String name) {
		if ($id.equalsIgnoreCase(name)) {
			return id();
		}
		if ($name.equalsIgnoreCase(name)) {
			return name();
		}
		if ($meta.equalsIgnoreCase(name)) {
			return meta();
		}
		if ($type.equalsIgnoreCase(name)) {
			return type();
		}
		if ($format.equalsIgnoreCase(name)) {
			return format();
		}
		if ($mode.equalsIgnoreCase(name)) {
			return mode();
		}
		if ($opt.equalsIgnoreCase(name)) {
			return opt();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($cond.equalsIgnoreCase(name)) {
			return cond();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($id.equalsIgnoreCase(name)) {
			return id();
		}
		if ($name.equalsIgnoreCase(name)) {
			return name();
		}
		if ($meta.equalsIgnoreCase(name)) {
			return meta();
		}
		if ($type.equalsIgnoreCase(name)) {
			return type();
		}
		if ($format.equalsIgnoreCase(name)) {
			return format();
		}
		if ($mode.equalsIgnoreCase(name)) {
			return mode();
		}
		if ($opt.equalsIgnoreCase(name)) {
			return opt();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($cond.equalsIgnoreCase(name)) {
			return cond();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		if ($name.equalsIgnoreCase(name)) {
			name(value);
			return;
		}
		if ($meta.equalsIgnoreCase(name)) {
			meta(value);
			return;
		}
		if ($type.equalsIgnoreCase(name)) {
			type(value);
			return;
		}
		if ($format.equalsIgnoreCase(name)) {
			format(value);
			return;
		}
		if ($mode.equalsIgnoreCase(name)) {
			mode(value);
			return;
		}
		if ($opt.equalsIgnoreCase(name)) {
			opt(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($cond.equalsIgnoreCase(name)) {
			cond(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		if ($name.equalsIgnoreCase(name)) {
			name(value);
			return;
		}
		if ($meta.equalsIgnoreCase(name)) {
			meta(value);
			return;
		}
		if ($type.equalsIgnoreCase(name)) {
			type(value);
			return;
		}
		if ($format.equalsIgnoreCase(name)) {
			format(value);
			return;
		}
		if ($mode.equalsIgnoreCase(name)) {
			mode(value);
			return;
		}
		if ($opt.equalsIgnoreCase(name)) {
			opt(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($cond.equalsIgnoreCase(name)) {
			cond(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

