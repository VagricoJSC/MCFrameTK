package mcframe.clientFXBA.FXBAP0140;

import mcframe.clientCore.beans.MCMode;
import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.clientCore.beans.table.MCTable;

/**
 * 汎用テーブル編集画面用のセルコンフィグです。
 * 
 */
public class FXBAP0140CellConfig extends mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig {

	@Override
	public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {
		MCDTableRow row = (MCDTableRow) table.getRow(index);
		if (row.getKeys().contains(column.getRowColumnName())) {
			// キー項目
			if (!row.isStatusCreate() && !row.isStatusGUICreate()) {
				// 新規行以外は編集不可
				return MCMode.READ_ONLY;
			}
		}

		return super.getPriorMode(index, column, table);
	}

}
