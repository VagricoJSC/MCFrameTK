package mcframe.clientFXBA.FXBAP0220;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FXBAP0220"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXBAP0220_FW_A extends mcframe.clientFXBA.FXBAP0150.FXBAP0150{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXBAP0220";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Value]ブロック関連のField定義
	public MCPanel ValuePanel = null;
	// [Value]ブロックの項目のField定義
	/**
	 * 論理値 論理値.<p>
	 *
	 */
	public MCButtonGroup Value_value_Group = null;
	public MCRadioButton Value_value_true = null;
	public MCRadioButton Value_value_false = null;
	public MCRadioButton Value_value_both = null;
	/** [EDITABLE]モードを表す定数 */
	public static final String EDITABLE = "EDITABLE";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{EDITABLE, READ_ONLY};
	
	/** [Value]ブロックのコンテナField定義 */
	private final mcframe.clientFXBA.FXBAP0220.ValueR aValueR;

	/**
	 * 項目コピーによってaValueRを設定します。
	 *
	 * aValueRのインスタンスは変更されません。
	 *
	 * @param row ValueR
	 */
	public void setValueR(mcframe.clientFXBA.FXBAP0220.ValueR row) {
		if (row != null) {
			MCRow.copyall(getValueR(), row);
		}
	}

	/**
	 * [Value]ブロックのコンテナaValueRを返します。
	 *
	 * @return ValueR
	 */
	public mcframe.clientFXBA.FXBAP0220.ValueR getValueR() {
		return aValueR;
	}

	/**
	 * aValueRを作成します。
	 *
	 * @return ValueR
	 */
	public mcframe.clientFXBA.FXBAP0220.ValueR createValueR() {
		return mcframe.clientFXBA.FXBAP0220.ValueR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getValueR())) ret.add(getValueR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getValueR()) return "Value";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Value")) return getValueR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ValuePanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0220_FW_A() {
		aValueR = createValueR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXBAP0220_FW_A(mcframe.clientFXBA.FXBAP0220.ValueR row){
		aValueR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXBAP0220_FW.jbCreateValue((FXBAP0220)this);
	}

	/**
	 * [Value]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateValue(FXBAP0220 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FXBAP0220 create(mcframe.clientFXBA.FXBAP0220.ValueR row){
		FXBAP0220 p = new FXBAP0220(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXBAP0220 create(){
		FXBAP0220 p = new FXBAP0220();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXBAP0220_FW.jbfInitValue((FXBAP0220)this);
		FXBAP0220_FW.jbInitValue((FXBAP0220)this);
	}

	/**
	 * [Value]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitValue(FXBAP0220 p) {
		// ブロック関連の初期化
		p.ValuePanel = p.beansFactory.createPanel("Value");
		// ブロックの項目の初期化
		p.Value_value_Group = p.beansFactory.createButtonGroup("Value.value");
		p.Value_value_true = p.beansFactory.createRadioButton("Value.value_true");
		p.Value_value_false = p.beansFactory.createRadioButton("Value.value_false");
		p.Value_value_both = p.beansFactory.createRadioButton("Value.value_both");
	}

	/**
	 * [Value]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitValue(FXBAP0220 p) {
		// ブロック関連の初期化
		p.add(p.ValuePanel);
		p.setLastBeans(p.ValuePanel);
		p.ValuePanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.ValuePanel.setLastBeans(p.Value_value_Group);
		p.Value_value_Group.setFirstBeans(p.Value_value_true);
		p.Value_value_true.setActionCommand("1");
		p.Value_value_Group.add(p.Value_value_true);
		p.ValuePanel.add(p.Value_value_true);
		p.Value_value_true.setNextBeans(p.Value_value_false);
		p.Value_value_false.setActionCommand("2");
		p.Value_value_Group.add(p.Value_value_false);
		p.ValuePanel.add(p.Value_value_false);
		p.Value_value_false.setNextBeans(p.Value_value_both);
		p.Value_value_both.setActionCommand("3");
		p.Value_value_Group.add(p.Value_value_both);
		p.ValuePanel.add(p.Value_value_both);
		p.Value_value_Group.setRow(p.getValueR(), mcframe.clientFXBA.FXBAP0220.ValueR.value_META);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXBAP0220_FW.mcInitValue((FXBAP0220)this);

		// [EDITABLE]ステータスのモードの設定
		FXBAP0220_FW.statusInitEDITABLE_Value((FXBAP0220)this);

		// [READ_ONLY]ステータスのモードの設定
		FXBAP0220_FW.statusInitREAD__ONLY_Value((FXBAP0220)this);

	}

	/**
	 *  [Value]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitValue(FXBAP0220 p) {
		p.Value_value_Group.addAllListener(p);
		p.Value_value_true.addAllListener(p);
		p.Value_value_false.addAllListener(p);
		p.Value_value_both.addAllListener(p);
	}

	/**
	 * [EDITABLE]ステータスの[Value]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_Value(FXBAP0220 p){
		p.Value_value_Group.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Value]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Value(FXBAP0220 p){
		p.Value_value_Group.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return EDITABLE;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Value_value_Group) return doValue_value_VC(info);
		return true;
	}

	/**
	 * [Value]パネルの[value]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doValue_value_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Value_value_Group) doValue_value_NC(info);
	}

	/**
	 * [Value]パネルの[value]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Value_value_Group) doValue_value_NE(info);
	}

	/**
	 * [Value]パネルの[value]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Value_value_Group) doValue_value_NX(info);
	}

	/**
	 * [Value]パネルの[value]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doValue_value_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}