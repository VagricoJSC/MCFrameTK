package mcframe.clientFXBA.FXBAP0220;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.MCValueSupply;

import javax.swing.BoxLayout;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0220"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0220_FW extends FXBAP0220_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * ラベル
	 */
	protected MCLabel Value_value_Label = null;
	/**
	 * 値用パネル
	 */
	protected MCPanel Value_value_Panel = null;

	/**
	 * パラメータ
	 */
	protected MCValueSupply.BooleanVS _param = null;

	/**
	 * ラジオボタン値：true
	 */
	protected String _true;
	/**
	 * ラジオボタン値：false
	 */
	protected String _false;
	/**
	 * ラジオボタン値：両方
	 */
	protected String _both;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0220_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXBAP0220_FW(mcframe.clientFXBA.FXBAP0220.ValueR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		super.layoutInit();

		ValuePanel.removeAll();

		ValuePanel.setLayout(new BoxLayout(ValuePanel, BoxLayout.X_AXIS));

		Value_value_Label = beansFactory.createLabel("Value.value_Label");

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		ValuePanel.add(Value_value_Label);
		ValuePanel.add(_createRigidArea(LAYOUT_MARGIN, LAYOUT_MARGIN, 100, null));
//		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_value_true);
		ValuePanel.add(_createRigidArea(LAYOUT_MARGIN, LAYOUT_MARGIN, 100, null));
//		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_value_false);
		ValuePanel.add(_createRigidArea(LAYOUT_MARGIN, LAYOUT_MARGIN, 100, null));
//		ValuePanel.add(Box.createRigidArea(new Dimension(LAYOUT_MARGIN, LAYOUT_MARGIN)));
		ValuePanel.add(Value_value_both);

		//フォント比率変更に対応させる
		// BoxLayout使用の場合にmaxサイズの調整が必須になる。

		// 7013-2313(MF_C01_214_高解像度のテストNGまとめ)
		// ラジオボタンサイズはgetPreferredSizeで取り出せない
//		_putMaxMap(Value_value_true, Value_value_true.getPreferredSize());
//		_putMaxMap(Value_value_false, Value_value_false.getPreferredSize());
//		_putMaxMap(Value_value_both, Value_value_both.getPreferredSize());
		_putMaxMap(Value_value_true, Value_value_true.getSize());
		_putMaxMap(Value_value_false, Value_value_false.getSize());
		_putMaxMap(Value_value_both, Value_value_both.getSize());

		// 自身もフォント比率変更対象になる
		_putMaxMap(this, this.getPreferredSize());

		// 7013-0007 ここまで
	}

	//デバッグメソッド
	@Override
	public void updateBounds(int ratio) {
		super.updateBounds(ratio);
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		getValueR().value(_both);
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return new MCModeBeans[] { Value_value_Group };
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param };
	}

	@Override
	public void setParam(MCValueSupply...param) {
		_param = (MCValueSupply.BooleanVS) param[0];
		Value_value_Label.setText(_param.name());			// 表示名称の設定
		Value_value_Group.setMessageName(_param.name());	// メッセージ用表示名称の設定

		_true = Value_value_true.getActionCommand();
		_false = Value_value_false.getActionCommand();
		_both = Value_value_both.getActionCommand();

		String val = _both;
		if (_param.isUsed()) {
			Boolean boo = (Boolean) _param.value();
			val = (boo.booleanValue()) ? _true : _false;
		}
		getValueR().value(val);
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		return null;
	}

	@Override
	public void updateParam() {
		String val = getValueR().value();

		boolean used = !_both.equals(val);
		_param.setUsed(used);
		if (used) {
			_param.value(_true.equals(val));
		}
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

}