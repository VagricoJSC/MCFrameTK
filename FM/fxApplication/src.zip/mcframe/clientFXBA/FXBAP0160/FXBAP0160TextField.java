package mcframe.clientFXBA.FXBAP0160;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;

import mcframe.clientCore.beans.MCTextField;

public class FXBAP0160TextField extends MCTextField {

	protected String _hint = null;

	public FXBAP0160TextField(String name, String _hint) {
		super(name);
		this._hint = _hint;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		// ヒント表示
		if (hasFocus()) {
			return;
		}
		if (getText().length() > 0) {
			return;
		}
		if (_hint == null || _hint.length() <= 0) {
			return;
		}
		Graphics2D g2 = (Graphics2D) g.create();
		Insets i = getInsets();
		Font font = getFont();
		FontRenderContext frc = g2.getFontRenderContext();
		TextLayout tl = new TextLayout(_hint, font, frc);
		g2.setPaint(Color.LIGHT_GRAY);
		int baseline = getBaseline(getWidth(), getHeight());
		tl.draw(g2, i.left + 1, baseline);
		g2.dispose();
	}
}
