package mcframe.clientFXBA.FXBAP0160;

import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.TextLayout;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.MCValueSupply;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0160"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0160_FW extends FXBAP0160_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * ラベル
	 */
	protected MCLabel Value_value_Label = null;

	/**
	 * パラメータ
	 */
	protected MCValueSupply.StringVS _param = null;

	/**
	 * ヒント
	 */
	protected String _hint = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0160_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXBAP0160_FW(mcframe.clientFXBA.FXBAP0160.ValueR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected void jbInit() {
		super.jbInit();

		// TextFieldのカスタマイズ
		// jbInitValue での生成処理と同じ手順を行う
//		Value_value = new MCTextField(Value_value.getName()) {
//			protected void paintComponent(Graphics g) {
//				super.paintComponent(g);
//
//				// ヒント表示
//				if (hasFocus()) {
//					return;
//				}
//				if (getText().length() > 0) {
//					return;
//				}
//				if (_hint == null || _hint.length() <= 0) {
//					return;
//				}
//				Graphics2D g2 = (Graphics2D) g.create();
//				Insets i = getInsets();
//				Font font = getFont();
//				FontRenderContext frc = g2.getFontRenderContext();
//				TextLayout tl = new TextLayout(_hint, font, frc);
//				g2.setPaint(Color.LIGHT_GRAY);
//				int baseline = getBaseline(getWidth(), getHeight());
//				tl.draw(g2, i.left + 1, baseline);
//				g2.dispose();
//			}
//		};
		Value_value = FXBAP0160CompatibilityUtil.createFXBAP0160TextField(Value_value.getName(), _hint);
		ValuePanel.setFirstBeans(Value_value);
		ValuePanel.setLastBeans(Value_value);
		Value_value.setRow(getValueR(), ValueR.value_META);
	}

	@Override
	public void layoutInit() {
		super.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BorderLayout(LAYOUT_MARGIN, 0));

		Value_value_Label = beansFactory.createLabel("Value.value_Label");
		Value_value.setLabel(Value_value_Label);

		ValuePanel.add(Value_value_Label, BorderLayout.WEST);
		ValuePanel.add(Value_value, BorderLayout.CENTER);
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return new MCModeBeans[] { Value_value };
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param };
	}

	/**
	 * ガジェットパラメータを設定します。
	 *
	 * <p>
	 * パラメータは複数設定できます。インデックスで用途が異なります。
	 * <ol start=0>
	 * <li>パラメータ値</li>
	 * <li>ヒント値（String）</li>
	 * </dl>
	 *
	 * @param param ガジェットパラメータ
	 */
	@Override
	public void setParam(MCValueSupply...param) {
		_param = (MCValueSupply.StringVS) param[0];
		Value_value_Label.setText(_param.name());	// 表示名称の設定
		Value_value.setMessageName(_param.name());	// メッセージ用表示名称の設定

		getValueR().value((String) _param.value());

		if (param.length >= 2 && param[1] != null) {
			// ヘルプ設定
			_hint = (String) ((MCValueSupply.StringVS) param[1]).value();
		}
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		return (_param.required() && getValueR().value() == null)
				? Value_value : null;
	}

	@Override
	public void updateParam() {
		_param.value(getValueR().value());
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

}