package mcframe.clientFXBA.FXBAP0160;

import mcframe.clientCore.beans.MCTextField;

public class FXBAP0160CompatibilityUtil {
	public static MCTextField createFXBAP0160TextField(String Value_value, String _hint) {
		return new FXBAP0160TextField(Value_value, _hint);
	}
}
