package mcframe.clientFXBA.FXBAP0010;

public interface IfTmplBase_FW {
	
	/**
	 * モジュールＩＤを返します。
	 * 
	 * @return モジュールＩＤ
	 */
	public String getModuleID();
	
	/**
	 * スクリーンＩＤを返します。
	 * 
	 * @return スクリーンＩＤ
	 */
	public String getScreenID();

}