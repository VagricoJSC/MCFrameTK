package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.MCMessageBox;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

public abstract class FXBAP_RootUpdater_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge> extends FXBAP_Caller<P, O> {

	public FXBAP_RootUpdater_FW(P panel, O operation) {
		super(panel, operation);
	}
	@Override
	protected void initCaller() {
		super.initCaller();
		setScreenAsync(true);
	}

	/**
	 * サーバロジック実行前処理を実行します。
	 *
	 *　falseを返した場合はサーバロジックを実行しません。<br>
	 * 
	 */
	@Override
	protected boolean beforeExecMain() {
		clearEmptyRowStatus();
		initCaller();
		if (!execConfirm()) {
			return false;
		}
		if (!checkForCall()) {
			return false;
		}
		beforeCallParts();
		setupParam();
		if (isUpParamEmpty()) {
			showNoUpDataMsg();
			return false;
		}
		if (!checkUpListParamEmpty()) {
			return false;
		}
		
		beforeCall();
		MCMessageList msgList = checkScaleAndLength();
		if (msgList.size() > 0) {
			panel.message(msgList);
			return false;
		}
	
		if (!checkLimitULSize() || !checkInvisibleRowInUpParam()) {
			return false;
		}

		if (isAsync() && isCsvOutForAsync()) {
			if (!csvOutForAsync()) {
				// 非同期実行して結果確認したいが、確認に利用するCSVが出力できなかった
				return false;
			}
		}
		return true;
	}

	/**
	 * プログレスダイアログを設定します。
	 */
	@Override
	protected void addProgressPanel() {
		super.addProgressPanelMain();
	}
	
	/**
	 * 処理を実行するかどうかを確認します。
	 * <P>
	 * メッセージの内容のみを変更したい場合は、{@link #msgExecConfirm()} をオーバーライドしてください。
	 *
	 * @return 削除処理を行う場合はtrue、行わない場合はfalse
	 */
	protected boolean execConfirm() {
		MCMessage msg = msgExecConfirm();
		return confirm(msg) == MCMessageBox.YES_OPTION;
	}
	
	/**
	 * 上り電文のリストコンテナが０件かどうかをチェックする。 falseを返すとサーバー通信をしない。
	 * <p>
	 * デフォルト実装：<br>
	 * <li>上り電文にリストコンテナが存在しない場合は、true</li>
	 * <li>上り電文にリストコンテナが１つ以上存在する場合、 全てのリストコンテナが０件の場合はfalse</li>
	 * </p>
	 *
	 */
	protected boolean checkUpListParamEmpty() {
		boolean hasList = false; // リストがあるかどうか
		boolean isListEmpty = true;
		for (MCContainer c : getUpParams()) {
			if (c instanceof MCList<?>) {
				hasList = true;
				MCList<?> list = (MCList<?>) c;
				if (!list.isEmpty()) {
					isListEmpty = false;
					break;
				}
			}
		}
		boolean ans = true;
		if (hasList && isListEmpty) {
			ans = false;
			showNoUpListDataMsg();
		}
		return ans;
	}
	
	abstract protected MCMessage msgExecConfirm();
	abstract public int confirm(MCMessage msg) ;
	abstract protected void showNoUpListDataMsg();
	abstract protected void showNoUpDataMsg();

}
