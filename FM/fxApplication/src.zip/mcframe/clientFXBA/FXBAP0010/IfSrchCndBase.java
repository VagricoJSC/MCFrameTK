package mcframe.clientFXBA.FXBAP0010;

import mcframe.commonCore.annotation.EI;

/**
 * 入力値設定機能を利用する画面に実装するインタフェースです。
 */
@EI
public interface IfSrchCndBase extends IfSrchCndBase_FW {
	
}