package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.annotation.EI;

@EI
public abstract class FXBAP_Printer<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Printer_FW<P, O> {
	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Printer(P panel, O operation) {
		super(panel, operation);
	}

}
