package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.annotation.EI;

@EI
public abstract class FXBAP_Deleter<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Deleter_FW<P, O> {
	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Deleter(P panel, O operation) {
		super(panel, operation);
	}
}
