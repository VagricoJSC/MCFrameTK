package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.message.MCProgressInfo;
import mcframe.commonCore.notice.*;
import mcframe.clientCore.beans.*;


public class FXBAP_BatchCaller_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends mcframe.clientFXBA.FXBAP0010.FXBAP_Caller<P, O> {
	/**
	 * コンストラクタです。
	 *
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_BatchCaller_FW(P panel, O bridge) {
		super(panel, bridge);
	}
	/**
	 * サーバロジック実行前処理を実行します。
	 *
	 *　falseを返した場合はサーバロジックを実行しません。<br>
	 * 
	 */
	@Override
	protected boolean beforeExecMain() {
		if (!execConfirm()) {
			return false;
		}
		initCaller();
		if (!checkForCall()) {
			return false;
		}
		setupParam();
		beforeCall();
		if (!checkLimitULSize()) {
			return false;
		}
		return true;
	}
	
	@Override
	protected MCCallBackType callPanelUpdateAction() {
		setMode();
		moveFocus();
		showEndMsg();
		resultSuccess();
		return MCCallBackType.SUCCESS;
	}

	/**
	 * 正常終了した時のメッセージを表示します。
	 */
	@Override
	protected void showEndMsg() {
		if (hasMessage()) {
			showDownMsg();
		}
		else {
			openEndMsgDialog();
		}
	}

	/**
	 * バッチ系の処理の実行を確認するメッセージ
	 */
	protected MCMessage msgExecConfirm() {
		return panel.msgBatchExecConfirm();
	}

	/**
	 * バッチ系の処理の実行を確認ダイアログを表示し、
	 * オペレータの選択結果を返す。
	 */
	protected boolean execConfirm() {
		MCMessage msg = msgExecConfirm();
		return panel.confirm(msg) == MCMessageBox.YES_OPTION;
	}

	/**
	 * バッチ系の処理の実行し正常終了した時のメッセージ
	 */
	public MCMessage msgBatchExeced() {
		return panel.msgBatchExeced();
	}

	/**
	 * バッチ系の処理の実行し正常終了した時のメッセージを表示する
	 */
	protected void openEndMsgDialog() {
		panel.dialog(msgBatchExeced());
	}

	/**
	 * サーバーから下ってきたメッセージ（メッセージプールに入っているメッセージ）を表示する
	 */
	@Override
	protected void showDownMsg() {
		panel.message(getMessages());
	}

	/**
	 * サーバー処理で例外が発生した場合の、処理を行う。 特に理由がない限り、例外をthrowする。
	 * <p>
	 * デフォルト実装：<br>
	 * {@link #setModeMCEx(MCException)} と {@link #setFocusMCEx(MCException)} を呼び出し、
	 * 例外をthrowする
	 * </p>
	 *
	 * @param ex サーバーで発生した例外
	 */
	protected void handleMCEx(MCException ex) {
		setModeMCEx(ex);
		setFocusMCEx(ex);
		throw ex;
	}

	/**
	 * サーバー処理で例外が発生した場合の、モード設定を行う。
	 * <p>
	 * デフォルト実装：<br>
	 * 何もしない
	 * </P>
	 * @param ex サーバーで発生した例外
	 */
	protected void setModeMCEx(MCException ex) {
	}

	/**
	 * サーバー処理で例外が発生した場合の、処理を行う。 特に理由がない限り、例外をthrowする。
	 * <p>
	 * デフォルト実装：<br>
	 * 何もしない
	 * </p>
	 * @param ex サーバーで発生した例外
	 */
	protected void setFocusMCEx(MCException ex ) {
	}
}