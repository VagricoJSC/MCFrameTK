package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.MCMessageBox;
import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

@EI
public abstract class FXBAP_RootUpdater<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge> extends FXBAP_RootUpdater_FW<P, O> {

	public FXBAP_RootUpdater(P panel, O operation) {
		super(panel, operation);
	}
}
