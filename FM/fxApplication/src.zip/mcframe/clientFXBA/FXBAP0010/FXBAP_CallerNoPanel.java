package mcframe.clientFXBA.FXBAP0010;

import mcframe.commonCore.param.MCParam;
import mcframe.commonCore.annotation.EI;

/**
 * MCRootPanelがなくても使えるCaller
 */
@EI
public class FXBAP_CallerNoPanel extends FXBAP_CallerNoPanel_FW {

	public FXBAP_CallerNoPanel(MCParam p) {
		super(p);
	}

}
