package mcframe.clientFXBA.FXBAP0010;

public interface IfProgressInfo_FW {

	/**
	 * 
	 * プログレスダイアログを使用したかどうかを設定します。
	 * 
	 * @param use プログレスダイアログを使用したかどうか
	 */
	void usedProgress(boolean wasused);
	/**
	 * プログレスダイアログを使用したかどうかを返します。
	 * 
	 * 
	 * @return 使用した場合true
	 */
	boolean usedProgress();
}
