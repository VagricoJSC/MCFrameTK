package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCapAgent;
import mcframe.clientCore.beans.MCMessageBox;
import mcframe.clientCore.requester.MCCaller;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.param.MCParam;

/**
 * 通信定型処理クラスの委譲クラスです。
 */
abstract public class FXBAP_CallerDelegate_FW {

	protected FXBAP_CallerDelegate_FW() {}
	
	/**
	 * 電文上限数のAppClientリソース設定を返します。<p>
	 * 次の設定のリソース値を返します。<br>
	 * [サブモジュールＩＤ].[画面ＩＤ].[通信処理クラス].limit(引数の文字列)<br>
	 * 例）XP.XPP0010.FXBAP_Searcher.limitUL<br>
	 * 未設定の場合はMCNumber.ZEROを返します。<br>
	 * @param typDLOrUL UL(上り電文を表す)またはDL（下り電文を表す）。
	 * @param caller 対象の通信処理クラス。
	 * @return 上限数のAppClientリソース設定
	 */
	public MCNumber getResourceLimitSize(String typDLOrUL, 
			@SuppressWarnings("rawtypes") MCCaller caller) {
		//Callerランタイムクラス
		Class<?> cls = caller.getClass();
		//リソース設定を見つけるまでループ
		while(cls != null && 
				!MCCaller.class.getName().equals(
						cls.getName())) {
			
			String pkg = cls.getPackage().getName();
			String pre = pkg.substring(0, pkg.lastIndexOf('.'));
			String submod = pre.substring(pre.lastIndexOf('.') + ".client".length());
			String screen = pkg.substring(pkg.lastIndexOf('.')+1);
			String clsnm = cls.getSimpleName();
			String lkey = "limit" + typDLOrUL;
			
			MCNumber rv = MCConst.app.getNumber(
					MCConst.createKey(submod, screen, clsnm, lkey));
			if (!FXUCP_DataUtil.isNull(rv)) {
				return rv;
			}
			cls = cls.getSuperclass();
		}
		return MCNumber.ZERO;
	}
	
	/**
	 * 下り電文容量のチェックを行います。処理を続行する場合は、 trueを返し、処理を中断する場合はfalseを返します。
	 * <P>
	 * <li>下り電文の容量が設定値をオーバーしていない場合はtrueを返す。</li>
	 * <li>下り電文の容量が設定値よりオーバーしていた場合は、 ユーザに確認ダイアログを提示して全件ダウンロードを
	 * 選択した場合、（全件ダウンロードを実行した後）trueを返す。</li>
	 * </P>
	 * @param param パラメータ
	 * @return 処理続行の場合true。処理中断の場合false
	 */
	public boolean checkCapTerminate(MCParam param) {
		boolean ans;
		MCCapAgent ca = new MCCapAgent(param);
		if (ca.isCapOver()) {
			if (ca.confirm() == MCMessageBox.YES_OPTION) {
				ca.request();
				ans = true;
			}
			else {
				ans = false;
			}
		}
		else {
			ans = true;
		}
		return ans;
	}
}
