package mcframe.clientFXBA.FXBAP0010;
import mcframe.commonCore.annotation.EI;

@EI
public interface IfToolbarItem extends IfToolbarItem_FW{
}
