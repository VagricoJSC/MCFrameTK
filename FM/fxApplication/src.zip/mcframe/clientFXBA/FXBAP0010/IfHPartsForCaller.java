package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCaller;
import mcframe.commonCore.notice.MCMessageList;

public interface IfHPartsForCaller {
	/**
	 * 通信前チェック処理。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出される。
	 * 通信定型処理から呼び出される。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出す。
	 * </P>
	 * @param list メッセージを格納するためのリスト
	 * @param caller 通信処理クラス。
	 */
	@SuppressWarnings("rawtypes")
	public void checkForCallStack(MCMessageList list, MCCaller caller);

	/**
	 * 通信前処理。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出される。
	 * 通信定型処理から呼び出される。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出す。
	 * </P>
	 * @param caller 通信処理クラス。
	 */
	@SuppressWarnings("rawtypes")
	public void beforeCallParts(MCCaller caller);

	/**
	 * 通信後処理。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出される。
	 * 通信定型処理から呼び出される。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出す。
	 * </P>
	 * @param caller 通信処理クラス。
	 */
	@SuppressWarnings("rawtypes")
	public void afterCallParts(MCCaller caller);

}
