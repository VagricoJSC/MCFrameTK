package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCErrorHandler;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCMessageList;

public class FXBAP_ErrorHandler_FW extends MCErrorHandler {

	public FXBAP_ErrorHandler_FW(MCRootPanel panel) {
		super(panel);
	}
	
	@Override
	protected void handleException(MCException e) {
		MCMessageList ml = e.getCauseMessageList();
		if (ml != null && !ml.isEmpty()) {
			
			MCRootPanel p = getRootPanel();
			if (p instanceof FXBAP_PanelBase) {	
				((FXBAP_PanelBase)p).sortMessageList(ml);
				e.setCauseMessageList(ml);
			}
		}
		super.handleException(e);
	}
	
}
