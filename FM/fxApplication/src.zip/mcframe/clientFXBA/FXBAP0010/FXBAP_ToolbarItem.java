package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.commonCore.annotation.EI;

@EI
public class FXBAP_ToolbarItem extends FXBAP_ToolbarItem_FW {

	public FXBAP_ToolbarItem(MCRootPanel mainPanel) {
		super(mainPanel);
	}
}
