package mcframe.clientFXBA.FXBAP0010;


public interface IfProgressInfo extends IfProgressInfo_FW{
	
}