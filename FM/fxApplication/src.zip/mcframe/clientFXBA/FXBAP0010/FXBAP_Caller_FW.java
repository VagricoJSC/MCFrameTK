package mcframe.clientFXBA.FXBAP0010;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

import java.awt.Component;
import java.awt.Rectangle;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JComponent;

import mcframe.clientCore.beans.MCCaller;
import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientCore.report.MCClientReportInfoR;
import mcframe.clientCore.report.MCClientReportManager;
import mcframe.clientCore.requester.report.MCReportCaller;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCSortPolicy;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCLog;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCParam;
import mcframe.commonCore.pio.util.MCDPType;
import mcframe.commonCore.pio.util.MCPioUtil;
import mcframe.commonCore.report.container.MCReportType;

public class FXBAP_Caller_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends mcframe.clientCore.beans.MCCaller<P, O> {

	/**
	 * 印刷（クライアントサーバ印刷）をする場合の情報を保持する
	 */
	protected List<MCClientReportInfoR> _reportInfo;

	/**
	 * 印刷（サーバ印刷）をした場合の情報を保持する
	 */
	protected List<MCClientReportInfoR> _serverReportInfo;

	/**
	 *ダイレクトダウンロードをする場合の出力ディレクトリを保持する
	 */
	protected File _downloadDir;

	/**
	 * 印刷（クライアントサーバ印刷）をする場合はtrueをセットします。
	 * @deprecated 基本的に {@link #getPrintFlg()}
	 *  {@link #setPrint(boolean)} を使用してください。
	 */
	@Deprecated
	protected boolean _printFlg = false;

	/**
	 * 委譲クラス
	 */
	protected FXBAP_CallerDelegate _delegate = new FXBAP_CallerDelegate();

	/**
	 * コンテナに関連する部品画面
	 */
	private Map<MCContainer, MCRootPanel[]> _relatePartsPanels;

	/**
	 * 印刷（クライアントサーバ印刷）をする場合はtrueをセットします。
	 */
	protected boolean getPrintFlg() {
		return _printFlg;
	}

	/**
	 * 印刷（クライアントサーバ印刷）をする場合はtrueをセットします。
	 * @param flg
	 */
	protected void setPrint(boolean flg) {
		_printFlg = flg;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Caller_FW(P panel, O operation) {
		super(panel, operation);

	}

	/**
	 * 対象のリスト から 「行ステータスがDeleteではない」「isEmpty がfalseである」の２つを 満たす行のリストを返します。
	 *
	 * @param <R>
	 * @param list 対象のリスト
	 * @return リスト
	 */
	protected <R extends MCRow> MCList<R> exceptDeleteAndEmpty(MCList<R> list) {
		return panel.exceptDeleteAndEmpty(list);
	}

	/**
	 * 対象のリスト から 「行ステータスがDeleteではない」「emptyRowと同値ではない」の２つを 満たす行のリストを返します。
	 *
	 * @param <R>
	 * @param list
	 * @return リスト
	 */
	protected <R extends MCRow> MCList<R> exceptDeleteAndEmpty(MCList<R> list,
			MCRow emptyRow) {
		return panel.exceptDeleteAndEmpty(list, emptyRow);
	}

	// 追加コンテナ関連⇒内部実装要再検討（ここから）
	private List<MCContainer> _upAddConts;

	protected List<MCContainer> getAddUpContainer() {
		if (_upAddConts == null) {
			_upAddConts = new ArrayList<>();
		}
		return _upAddConts;
	}

	protected void clearAddUpContainer() {
		_upAddConts = null;
	}

	/**
	 * 直接上り電文にはならないが、上り電文と同等の扱いを
	 * したいコンテナを追加する。<br>
	 * MCList を追加した場合は、{@link #clearEmptyRowStatus(MCList)}
	 * を呼び出す。
	 * @param cont
	 */
	@SuppressWarnings("rawtypes")
	protected void addUpContainer(MCContainer... cont) {
		for (MCContainer c : cont) {
			getAddUpContainer().add(c);
			if (c instanceof MCList) {
				MCList ls = (MCList) c;
				clearEmptyRowStatus(ls);
			}
		}
	}

	private List<MCContainer> _downAddConts;

	protected List<MCContainer> getAddDownContainer() {
		if (_downAddConts == null) {
			_downAddConts = new ArrayList<>();
		}
		return _downAddConts;
	}

	protected void clearAddDownContainer() {
		_downAddConts = null;
	}

	protected void addDownContainer(MCContainer... cont) {
		for (MCContainer c : cont) {
			getAddDownContainer().add(c);
		}
	}

	/** 追加分も含む */
	private List<MCContainer> _downAllBlocks = new ArrayList<>();

	protected List<MCContainer> getAllDownBlocks() {
		_downAllBlocks.clear();
		_downAllBlocks.addAll(getDownBlocks());
		_downAllBlocks.addAll(getAddDownContainer());
		return _downAllBlocks;
	}

	/**
	 * パラメータの下りコンテナ及び {@link #addDownContainer(MCContainer...)}
	 * で追加されたコンテナに含まれる List コンテナを返します。
	 *
	 * @return List コンテナ
	 */
	@SuppressWarnings("rawtypes")
	protected List<MCList> getAllDownListBlocks() {
		List<MCList> ret = new ArrayList<>();
		for (MCContainer cont : getAllDownBlocks()) {
			if (cont instanceof MCList) {
				ret.add((MCList) cont);
			}
		}
		return ret;
	}

	/** 追加分も含む */
	private List<MCContainer> _downAllParams = new ArrayList<>();

	protected List<MCContainer> getAllDownParams() {
		_downAllParams.clear();
		_downAllParams.addAll(getDownParams());
		_downAllParams.addAll(getAddDownContainer());
		return _downAllParams;
	}

	/** 追加分も含む */
	private List<MCContainer> _upAllBlocks = new ArrayList<>();

	protected List<MCContainer> getAllUpBlocks() {
		_upAllBlocks.clear();
		_upAllBlocks.addAll(getUpBlocks());
		_upAllBlocks.addAll(getAddUpContainer());
		return _upAllBlocks;
	}

	/**
	 * パラメータの上りコンテナ及び {@link #addUpContainer(MCContainer...)}
	 * で追加されたコンテナに含まれる List コンテナを返します。
	 *
	 * @return List コンテナ
	 */
	@SuppressWarnings("rawtypes")
	protected List<MCList> getAllUpListBlocks() {
		List<MCList> ret = new ArrayList<>();
		for (MCContainer cont : getAllUpBlocks()) {
			if (cont instanceof MCList) {
				ret.add((MCList) cont);
			}
		}
		return ret;
	}

	/** 追加分も含む */
	private List<MCContainer> _upAllParams = new ArrayList<>();

	protected List<MCContainer> getAllUpParams() {
		_upAllParams.clear();
		_upAllParams.addAll(getDownParams());
		_upAllParams.addAll(getAddDownContainer());
		return _upAllParams;
	}

	private List<MCContainer> _allDownContainerWithoutUpCont;

	protected List<MCContainer> getAllDownContainerWithoutUpCont() {
		if (_allDownContainerWithoutUpCont == null) {
			List<MCContainer> ret = new ArrayList<>();
			for (MCContainer downCont : getAllDownBlocks()) {
				boolean ans = true;
				for (MCContainer upCont : getAllUpBlocks()) {
					if (downCont == upCont) {
						ans = false;
						break;
					}
				}
				if (ans) {
					ret.add(downCont);
				}
			}
			_allDownContainerWithoutUpCont = ret;
		}
		return _allDownContainerWithoutUpCont;
	}

	// 追加コンテナ関連⇒内部実装要再検討（ここまで）

	/**
	 * 処理結果を格納する箇所をクリアします。
	 * <p>
	 * デフォルト実装：
	 * <li>下りブロック（追加分含む）を全てクリアする。但し、上り電文ブロック（追加分含む） のブロックはクリアしない。</li>
	 * <li>クリア対象がテーブルに紐づくコンテナの場合は、テーブルのスクロールを左上になるように移動させる。</li>
	 * </p>
	 */
	@Override
	protected void clear() {
		for (MCContainer c : getAllDownContainerWithoutUpCont()) {
			if (c instanceof MCList) {
				MCList<?> ls = (MCList<?>) c;
				ls.clear();
				// テーブルの場合は、スクロールを左上に戻す
				JComponent comp = panel.getComponent(ls);
				if (comp instanceof MCTable) {
					MCTable<?> tbl = (MCTable<?>) comp;
					Rectangle rect = new Rectangle(0, 0, 0, 0);
					tbl.scrollRectToVisible(rect);
				}
			}
			else if (c instanceof MCRow) {
				MCRow r = (MCRow) c;
				r.clearAll();
			}
		}
	}

	/**
	 * ロジックが正常終了をして、結果があった場合、
	 * 全ての処理が終了した最後に呼び出されるメソッド。
	 */
	protected void resultSuccess() {

	}

	/**
	 * 処理結果を表示するためのブロックが変更されたかどうかを調査し、
	 * 変更されたと判断された場合は true を返します。<p>
	 * 下り電文ブロック（追加分を含む）を対象とします。
	 * ただし、上り電文ブロック（追加分を含む）に指定されているブロックは対象外となります。<p>
	 * ブロックのステータスが NONE の場合は変更されていない、
	 * NONE 以外の場合は変更されたと判断されます。
	 * ブロックに紐づく GUI 部品が全て入力不可の場合は、コンテナのステータスに関係なく、
	 * 変更されていないと判断されます。
	 *
	 * @return 処理結果を表示するためのブロックが変更されていないと判断された場合は false
	 */
	@Override
	protected boolean isDownBlockChanged() {
		for (MCContainer c : getAllDownContainerWithoutUpCont()) {
			if (c instanceof MCList) {
				MCList<?> list = (MCList<?>) c;
				JComponent comp = panel.getComponent(list);
				if (comp instanceof MCTable) {
					if (panel.isChanged((MCTable<?>) comp)) return true;
				}
				else if (comp == null) {
					// 画面に紐づかないコンテナはチェック対象外なので何もしない
				}
				else {
					if (!c.isStatusNone()) return true;
				}
			}
			else if (c instanceof MCRow) {
				if (panel.isChanged((MCRow) c)) return true;
			}
			else {
				if (!c.isStatusNone()) return true;
			}
		}
		return false;
	}

	@Override
	protected boolean isDownBlockEmpty() {
		for (MCContainer c : getAllDownBlocks()) {
			if (!c.isEmpty()) return false;
		}
		return true;
	}

	@Override
	protected boolean isUpBlockChanged() {
		for (MCContainer c : getAllUpBlocks()) {
			if (c instanceof MCList) {
				MCList<?> list = (MCList<?>) c;
				JComponent comp = panel.getComponent(list);
				if (comp instanceof MCTable) {
					if (panel.isChanged(comp, true)) return true;
				}
				else {
					if (!c.isStatusNone()) return true;
				}
			}
			else {
				if (!c.isStatusNone()) return true;
			}
		}
		return false;
	}

	@Override
	protected boolean isUpBlockEmpty() {
		for (MCContainer c : getAllUpBlocks()) {
			if (!c.isEmpty()) return false;
		}
		return true;
	}

	/**
	 * Callerの初期化をします。非表示ブロックへのデータのコピーなど
	 */
	@Override
	protected void initCaller() {
		clearAddDownContainer();
		clearAddUpContainer();
	}

	/**
	 * 通信を行うためのチェックを行います。
	 * <p>
	 * デフォルト実装：{@link #checkForCallStack(MCMessageList)}を呼び出し、戻り値のリストが
	 * １件以上ある場合はメッセージダイアログを出し、falseを返す。それ以外はtrue
	 * </p>
	 *
	 * @return 通信可能な場合 true 通信を行わない場合 false
	 */
	@Override
	protected boolean checkForCall() {
		boolean ans = true;
		MCMessageList msgList = new MCMessageList();
		checkForCallStack(msgList);
		if (msgList.size() > 0) {
			showStackMsg(msgList);
			ans = false;
		}
		return ans;
	}

	/**
	 * {@link #checkForCallStack(MCMessageList)}で
	 * 収集したメッセージを表示する。
	 * <P>
	 * デフォルト実装ではメッセージリストをそのまま表示します。
	 * </P>
	 * @param msgList
	 */
	protected void showStackMsg(MCMessageList msgList) {
		if (msgList == null || msgList.isEmpty()) return;
		panel.message(msgList);
	}

	/**
	 * 複数のチェックを行い、エラーがあった場合のメッセージを msgList に格納します。
	 * <P>
	 * デフォルト実装：{@link #checkReq(MCMessageList) checkReq(MCMessageList)}を呼び出す。
	 * </P>
	 *
	 * @param msgList
	 */
	protected void checkForCallStack(MCMessageList msgList) {
		checkReq(msgList);
		checkForCallStackParts(msgList);
	}

	/**
	 * 必須チェックを行います。
	 * 必須項目が空白だった場合は、指定されたメッセージリストにメッセージを格納します。<p>
	 * デフォルト実装：<br>
	 * 全ての上りブロックについて
	 * {@link #checkReq(MCMessageList, MCContainer)} を実行します。
	 *
	 * @param msgList メッセージリスト
	 */
	protected void checkReq(MCMessageList msgList) {
		for (MCContainer c : getAllUpBlocks()) {
			checkReq(msgList, c);
		}
	}

	/**
	 * 必須チェックを行います。
	 * 必須項目が空白だった場合は、指定されたメッセージリストにメッセージを格納します。<p>
	 * デフォルト実装：<br>
	 * {@link FXBAP_PanelBase#checkReq(MCContainer...)} を実行します。
	 * ただし、リストブロックの空行と削除ステータスの行はチェック対象から除外します。
	 *
	 * @param msgList メッセージリスト
	 * @param cont コンテナ
	 */
	protected void checkReq(MCMessageList msgList, MCContainer cont) {
		MCMessageList l;
		if (cont instanceof MCList<?>) {
			l = panel.checkReq(panel.exceptDeleteAndEmpty((MCList<?>) cont));
		}
		else {
			l = panel.checkReq(cont);
		}
		if (l != null) {
			msgList.addAll(l);
		}
	}

	/**
	 * 電文を初期化します。
	 *
	 */
	@Override
	protected void setupParam() {
		setupReqSrcIdForParam();
		clearUpBlocksParamRowIndex();
		setupUpParam();
		setupDownParam();
		setLimitParamSize();
	}

	/**
	 * 電文に呼び出し元画面ＩＤをセットします
	 */
	protected void setupReqSrcIdForParam() {
		param().setReqSrcId(panel.getScreenID());
	}
	
	/**
	 * 画面の上りコンテナのParamRowIndexをクリアします。
	 */
	protected void clearUpBlocksParamRowIndex() {
		for (MCContainer c : getUpBlocks()) {
			clearUpBlocksParamRowIndex(c);
		}
	}
	
	protected void clearUpBlocksParamRowIndex(MCContainer cont) {
		if (cont instanceof MCList<?>) {
			for (MCRow o : (MCList<?>)cont) {
				o.setParamRowIndex(-1);
			}
		}
		else if (cont instanceof MCRow) {
			((MCRow)cont).setParamRowIndex(-1);
		}
	}

	/**
	 * 電文に上りコンテナをセットします。<p>
	 * デフォルト実装：<br>
	 * 画面上の上りコンテナについて
	 * {@link #setupUpParam(MCContainer)} を実行します。
	 */
	protected void setupUpParam() {
		for (MCContainer c : getUpBlocks()) {
			setupUpParam(c);
		}
	}

	/**
	 * 電文に上りコンテナをセットします。<p>
	 * デフォルト実装：<br>
	 * 指定されたコンテナがリストコンテナの場合は、空行を省いたリストをセットします。
	 * それ以外の場合は、指定されたコンテナをセットします。
	 *
	 * @param cont コンテナ
	 */
	protected void setupUpParam(MCContainer cont) {
		MCContainer c;
		if (cont instanceof MCList<?>) {
			c = panel.exceptEmpty((MCList<?>) cont);
		}
		else {
			c = cont;
		}
		param().addUpBlock(c);
	}

	/**
	 * 電文に下りコンテナをセットします。<p>
	 * デフォルト実装：<br>
	 * 画面上の下りコンテナについて
	 * {@link #setupDownParam(MCContainer)} を実行します。
	 */
	protected void setupDownParam() {
		for (MCContainer c : getDownBlocks()) {
			setupDownParam(c);
		}
	}

	/**
	 * 電文に下りコンテナをセットします。<p>
	 * デフォルト実装：<br>
	 * 指定されたコンテナを利用して、新しいコンテナのインスタンスを作成します。
	 * そして、作成したインスタンスを下りコンテナにセットします。
	 *
	 * @param cont コンテナ
	 */
	protected void setupDownParam(MCContainer cont) {
		if (cont instanceof MCList<?>) {
			param().addDownBlock(((MCList<?>) cont).createInstance());
		}
		else if (cont instanceof MCRow) {
			param().addDownBlock(((MCRow) cont).createInstance());
		}
		else {
			param().addDownBlock(cont);
		}
	}

	/**
	 * 正常終了した時のメッセージを表示します。
	 */
	protected void showMsg() {
		if (hasMessage()) {
			showDownMsg();
		}
		// 非同期実行の場合はcallPanelUpdateActionForAsyncRsltでメッセージ出力
		// ここだと画面表示前にダイアログが出力されてしまう。
		else if (!isAsyncRsltMode()) {
			showEndMsg();
		}
	}

	/**
	 * サーバーから下ってきたメッセージ（メッセージプールに入っているメッセージ）を表示する
	 */
	@Override
	protected void showDownMsg() {
		// メモ 不足分を再取得するならばcallの直後に取得しないと、後から
		// 取得した文が後処理などをされないので困るので他で、該当処理をやっている
		// （だからここではshowFWDownMsg()に該当する処理はしない。）
		// showFWDownMsg();

		// メモ インフラの仕様とは異なり、メッセージプールが
		// 存在するときしかこのメソッドは呼び出されないので、showAppDownMsg()
		// の処理は展開して実装する。
		// showAppDownMsg();

		panel.message(getMessages());
	}

	/**
	 * 下り電文コンテナのデータをGUI部品と連携するコンテナに設定します。<p>
	 */
	@Override
	protected void show() {
		showReplace();
	}

	/**
	 * 通信後のモードを設定します。<p>
	 */
	@Override
	protected void setMode() {

	}

	/**
	 * 通信後のフォーカス設定を行います。<p>
	 * <P>
	 * デフォルト実装：何もしない
	 * </P>
	 */
	protected void moveFocus() {
	}

	/**
	 * 通信後のフォーカス設定を行います。<p>
	 * バーコード画面でのcallerのフォーカス移動を行います。
	 * 6.4.0
	 */
	protected void moveFocusForBarcode() {
		if (panel.isBarcodeMode()) {
			// バーコード画面のみで使用する。
			panel.setBarcodeFocus();
		}
	}

	@Override
	protected MCCallBackType callAfterAction() {
		super.callAfterAction();
		callAfterActionCmn(false);
		return MCCallBackType.SUCCESS;
	}

	@Override
	protected MCCallBackType callPanelUpdateAction() {
		callPanelUpdateActionCmn(false);
		return MCCallBackType.SUCCESS;
	}

	/**
	 * {@link #callAfterAction()}および
	 * {@link #callAfterActionForAsyncRslt()}から呼び出される共通処理のメソッドです。
	 * @param isAsyncResultMode　非同期実行の結果確認かどうか
	 */
	protected void callAfterActionCmn(boolean isAsyncResultMode) {
		afterCallParts();
	}

	/**
	 * {@link #callPanelUpdateAction()}および
	 * {@link #callPanelUpdateActionForAsyncRslt()}から呼び出される共通処理のメソッドです。
	 * @param isAsyncResultMode　非同期実行の結果確認かどうか
	 */
	protected void callPanelUpdateActionCmn(boolean isAsyncResultMode) {
		show();
		setMode();
		moveFocus();
		showMsg();
		if (!isAsyncResultMode) {
			print();
		}
		resultSuccess();
	}

	@Override
	protected void callAfterActionForAsyncRslt() {
		super.callAfterActionForAsyncRslt();
		callAfterActionCmn(true);
	}

	@Override
	protected MCMessage callPanelUpdateActionForAsyncRslt() {
		super.callPanelUpdateActionForAsyncRslt();
		callPanelUpdateActionCmn(true);
		if (!hasMessage()) {
			return getAsyncSuccessMsg();
		}
		else {
			return null;
		}
	}

	/**
	 * 非同期取り込みが正常終了した際のメッセージです。
	 */
	protected MCMessage getAsyncSuccessMsg() {
		return new MCMessage(mcframe.commonFX.notice.FX_Msg.FXUDD9002);
	}

	/**
	 * 上り電文対象のリストのブロックでisEmptyのRowがあったら、
	 * その属性値をクリアしします。
	 */
	@SuppressWarnings("rawtypes")
	protected void clearEmptyRowStatus() {
		for (MCContainer cont : getAllUpBlocks()) {
			if (cont instanceof MCList) {
				MCList list = (MCList) cont;
				clearEmptyRowStatus(list);
			}
		}
	}

	/**
	 * リストの中のでisEmptyのRowがあったら、
	 * その属性値をクリアしします。
	 */
	@SuppressWarnings("rawtypes")
	protected void clearEmptyRowStatus(MCList ls) {
		for (Object obj : ls) {
			if (obj instanceof MCRow) {
				MCRow r = (MCRow) obj;
				if (r.isEmpty()) {
					r.clearAll();
					r.setStatus(Status.GUICREATE);
				}
			}
		}
	}

	/**
	 * 電文上限数の設定をします。<p>
	 * デフォルト実装：
	 * AppClientリソースの受信、送信上限数設定を反映する。
	 */
	@Override
	protected void setLimitParamSize() {
		setLimitULSize();
		setLimitDLSize();
	}

	/**
	 * 上り電文上限数の設定をします。
	 * <p>
	 * デフォルト実装：<br>
	 * 次のAppClientリソースを読み込み、上限数を設定します。<br>
	 * [サブモジュールＩＤ].[画面ＩＤ].[通信処理クラス].limitUL<br>
	 * 設定値は、ConfigClientリソースの以下の設定よりも優先されます。<br>
	 * net.request.limitSize<br>
	 * リソース値が0の場合は、未設定にします。<br>
	 * リソース値が未設定の場合は何もしません。<br>
	 */
	protected void setLimitULSize() {
		MCNumber rv = _delegate.getResourceLimitSize("UL", this);
		if (rv.isZero()) {
			param().setLimitULSize(null);
		}
		else {
			param().setLimitULSize(rv);
		}
	}

	/**
	 * 下り電文上限数の設定をします。
	 * <p>
	 * デフォルト実装：<br>
	 * 次のAppClientリソースを読み込み、上限数を設定します。<br>
	 * [サブモジュールＩＤ].[画面ＩＤ].[通信処理クラス].limitDL<br>
	 * 設定値は、ConfigClientリソースの以下の設定よりも優先されます。<br>
	 * net.response.limitSize<br>
	 * リソース値が0の場合は、未設定にします。<br>
	 * リソース値が未設定の場合は何もしません。<br>
	 */
	protected void setLimitDLSize() {
		MCNumber rv = _delegate.getResourceLimitSize("DL", this);
		if (rv.isZero()) {
			param().setLimitDLSize(null);
		}
		else {
			param().setLimitDLSize(rv);
		}
	}

	@Override
	protected void call() {
		if (getPrintFlg()) {
			if (_reportInfo == null) {
				_reportInfo = new ArrayList<>();
			}

			// 印刷ロジック呼び出し
			MCReportCaller caller = new MCReportCaller(param(), panel.getErrorHandler());
			caller.exec();
			setDownReportInfo(caller.getDownClientReportInfo());
		}
		else {
			super.call();
		}
	}

	/**
	 * 印刷情報を印刷パターンごとに振り分けます。
	 *
	 * @param rInfo
	 */
	protected void setDownReportInfo(List<MCClientReportInfoR> rInfo) {
		_reportInfo = new ArrayList<>();
		_serverReportInfo = new ArrayList<>();
		for (MCClientReportInfoR r : rInfo) {
			if (r.reportType() == MCReportType.SERVER) {
				_serverReportInfo.add(r);
			}
			else {
				_reportInfo.add(r);
			}
		}
	}

	/**
	 * 印刷の必要性を判断し、印刷を行う
	 */
	protected void print() {
		if (getPrintFlg()) {
			printSub();
		}
	}

	/**
	 * 印刷を行う
	 */
	protected void printSub() {
		if (!isDownClientPrintDataEmpty()) {
			// 再印刷の場合もrequestメソッドを使用する
			if (getPrintFlg()) {
				MCClientReportManager.request(_reportInfo);
			}
		}
		else {
			printDataEmpty();
		}
	}

	/**
	 * 印刷データが存在しなかった場合の処理
	 *
	 */
	protected void printDataEmpty() {
		//ここでは、何もしない
	}

	/**
	 * サーバからの印刷データが無い場合は、trueを返します。
	 *
	 * @return サーバからの印刷データが無い場合は、true
	 */
	protected boolean isDownPrintDataEmpty() {
		return isDownClientPrintDataEmpty() && (_serverReportInfo.size() == 0);
	}

	/**
	 * サーバからのクライアント-サーバ印刷の印刷データが無い場合は、trueを返します。
	 *
	 * @return クライアント-サーバ印刷の印刷データが無い場合は、true
	 */
	protected boolean isDownClientPrintDataEmpty() {
		return (_reportInfo.size() == 0);
	}

	/**
	 * 下り電文上限チェックで続行不可と判断された場合の後処理
	 * <P>
	 * デフォルト実装：処理を中止した旨を伝えるダイアログを出す。
	 * </P>
	 */
	@Override
	protected void afterCapError() {
		panel.dialog(panel.msgProcessTerminated());
	}

	/**
	 * 検索結果のブロックがテーブルの場合、列幅自動調整を行います。<p>
	 * <font color=red>
	 * このメソッド内でダイアログを表示させる処理を行ってはいけません。
	 * </font>
	 */
	protected void adjustList() {

		List<MCTable<?>> _adjustedSyncMains = new ArrayList<>();

		for (MCContainer cont : getAllDownBlocks()) {
			if (cont instanceof MCList) {
				JComponent listComp = panel.getComponent((MCList<?>) cont);

				if (listComp instanceof MCTable) {

					MCTable<?> t = (MCTable<?>) listComp;
					if (t.isHSyncTable()) {
						MCTable<?> mt = t.getHSyncMainTable();
						if (mt == null) {
							mt = t;
						}
						if (!_adjustedSyncMains.contains(mt)) {
							mt.adjustWidth();
							_adjustedSyncMains.add(mt);
						}

					}
					else {
						t.adjustWidth();
					}
				}
			}
		}
	}

	// ユーティリティ（ここから）
	/**
	 * 下り電文に、対応する上り電文のGUIIndexをコピーします。
	 *
	 */
	@SuppressWarnings({
			"unchecked", "rawtypes"
	})
	protected void setGUIIndexAtDownParam() {
		for (MCContainer cont : getDownParams()) {
			if (cont instanceof MCRow) {
				MCRow r = (MCRow) cont;
				int paramIdx = r.getParamIndex();
				if (0 <= paramIdx && paramIdx < getUpParams().size()) {

					MCContainer upCont = getUpParams().get(paramIdx);
					if (upCont instanceof MCRow) {
						r.setGUIIndex(((MCRow) upCont).getGUIIndex());
					}
					else if (upCont instanceof MCList) {
						MCList<?> upList = (MCList<?>) upCont;
						if (r.getParamRowIndex() < upList.size()) {
							int pRowIdx = r.getParamRowIndex();
							if (0 <= pRowIdx) {
								r.setGUIIndex(upList.get(pRowIdx).getGUIIndex());
							}
						}
					}
				}
			}
			else if (cont instanceof MCList) {
				MCList<MCRow> list = (MCList) cont;
				for (MCRow r : list) {
					int paramIdx = r.getParamIndex();
					if (0 <= paramIdx && paramIdx < getUpParams().size()) {
						MCContainer upCont = getUpParams().get(paramIdx);
						if (upCont instanceof MCRow) {
							r.setGUIIndex(((MCRow) upCont).getGUIIndex());
						}
						else if (upCont instanceof MCList) {
							MCList<?> upList = (MCList<?>) upCont;
							if (r.getParamRowIndex() < upList.size()) {
								int pRowIdx = r.getParamRowIndex();
								if (0 <= pRowIdx) {
									r.setGUIIndex(upList.get(pRowIdx).getGUIIndex());
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * {@link MCCaller#show}（{@link MCCaller#bridge}）
	 * と同等の処理を行います。
	 */
	protected void bridgeShow() {
		super.show();
	}

	/**
	 * ユーティリティ：画面上の内容を下り電文で置き換え、テーブルのソートを実行する
	 */
	protected void showReplace() {
		bridgeShow();
		showReplaceSub();
		sort();
	}

	/**
	 * {@link #showReplace()}の中で {@link #bridgeShow()}と {@link #sort()}
	 * の間に処理を追加する時に使用します。
	 * <p>
	 * デフォルトでは何もしません。
	 */
	protected void showReplaceSub() {
	}

	/**
	 * ソートを実行します。
	 * <P>
	 * Overrideする場合の注意事項：<br>
	 * 基本的に本メソッドはオーバーライドしないと思われます（動きを無効にしたい場合ぐらい）。
	 * システム的に必須なソートは {@link #afterCall()} に、コンテナのソートの機能を
	 * 用いてソートをします。<br>
	 * 画面仕様としてのデフォルトのソート順を指定するには {@link FXBAP_PanelBase#setSortColumn()}
	 * メソッドに実装します。<br>
	 * ソートロジックをカスタマイズする場合は、 {@link FXBAP_PanelBase#sort(MCTable, MCSortPolicy)}
	 * に実装してください。
	 * </P>
	 */
	@Override
	protected void sort() {
		if (panel == null) {
			return;
		}
		for (MCContainer c : getAllDownBlocks()) {
			if (!(c instanceof MCList)) {
				continue;
			}
			Component o = panel.getComponent((MCList<?>) c);
			if (!(o instanceof MCTable)) {
				continue;
			}
			MCTable<?> t = (MCTable<?>) o;
			MCSortPolicy p = t.getSortPolicy();
			if (p == null) {
				p = new MCSortPolicy();
			}
			else {
				p = p.clone();
			}
			if (p.size() == 0) {
				if (isSortByVisibleColumn()) {
					for (MCColumnConfig conf : t.getVisibleColumnConfigs()) {
						if (!conf.isLinkRowColumn()) {
							continue;
						}
						p.add(SortType.ASC, conf.getBaseRowColumnName());
					}
				}
			}
			panel.sort(t, p);
		}
	}

	/**
	 * テーブルに表示されているカラムでソートする場合は true を返します。<p>
	 * <font color="red">
	 * テーブルにソート順が設定されている場合は、テーブルのソート順が優先されます。
	 * このメソッドが true を返した場合は、
	 * {@link MCTable#getVisibleColumnConfigs()} の順番で昇順にソートされます。
	 * </font><p>
	 * デフォルトでは false を返します。
	 *
	 * @return テーブルに表示されているカラムでソートしない場合は false
	 */
	protected boolean isSortByVisibleColumn() {
		try {
			return panel.getPgmSettingBoolean(panel, "sort_by_visible_column");
		}
		catch (MCAppException e) {
			MCLog.write(e);
			return false;
		}
	}

	/**
	 * ユーティリティ：画面に表示してある内容を保持しつつ、下り電文のデータを画面上に表示します。
	 */
	@SuppressWarnings({
			"unchecked", "rawtypes"
	})
	protected void showMerge() {
		setGUIIndexAtDownParam();
		for (int i = 0; i < getDownParams().size(); i++) {
			MCContainer cont = getDownParams().get(i);
			if (cont instanceof MCRow) {
				merge((MCRow) getDownBlocks().get(i), (MCRow) cont, getDownItemNames(i));

			}
			else if (cont instanceof MCList) {
				merge(i, (MCList) getDownBlocks().get(i), (MCList) cont,
						getDownItemNames(i));
			}
		}
	}

	/**
	 * コピー元のリストの全行をコピー先のリストにマージします。
	 * <P>
	 * <li>コピー元のリストの行データのGUI INDEX と同一のGUI INDEXを持つ行がコピー先にある場合、
	 * その行にコピー元の行データのcolsで与えられたカラムのデータ及び行の属性情報をコピーします。</li>
	 * <li>コピー元のリストの行データのGUI INDEX と同一のGUI INDEXを持つ行がコピー先にない場合は、 コピー先のテーブルにコピー元の行を追加します。</li>
	 *
	 * @param blockNum ブロック番号
	 * @param destL コピー先のリスト
	 * @param srcL コピー元のリスト
	 * @param cols コピーするカラム
	 */
	protected void merge(int blockNum, MCList<MCRow> destL, MCList<MCRow> srcL,
			String... cols) {
		if (srcL.isEmpty()) {
			return;
		}
		if (destL.isEmpty()) {
			destL.addAll(srcL);
			return;
		}

		MergeRowSearcher<MCRow> searcher = getMergeRowSearcher();
		MCList<MCRow> unMatchList = srcL.createInstance();
		searcher.setDestL(blockNum, destL);
		for (MCRow src : srcL) {
			MCRow dest = searcher.getMergeRow(src, cols);
			if (dest != null) {
				merge(dest, src, cols);
			}
			else {
				unMatchList.add(src);
			}
		}

		destL.addAll(unMatchList);
		if (isAsyncRsltMode()) {
			causeRowRelateDestRow(destL);
		}
	}

	/**
	 * 非同期実行の結果確認時に、画面に復元したRowとメッセージのcauseRowを関連付けます。
	 * @param destL コピー先のリスト
	 */
	protected void causeRowRelateDestRow(MCList<MCRow> destL) {
		for (MCMessage msg : param().getMessageParam().getMessage()) {
			MCRow causeRow = msg.getCauseRow();
			if (causeRow == null) {
				continue;
			}
			for (MCRow destR : destL) {
				if (destR.getParamIndex() == causeRow.getParamIndex()
						&& destR.getParamRowIndex() == causeRow.getParamRowIndex()) {
					causeRow.relateContainer(destR);
				}
			}
		}
	}

	/**
	 * コピー対象のRowを探すためのクラスを返します。
	 *
	 * @return コピー対象のRowを探すためのクラス
	 */
	protected <E extends MCRow> MergeRowSearcher<E> getMergeRowSearcher() {
		return new DefaultMergeRowSearcher<>();
	}

	/**
	 * コピー対象のRowを探すためのインタフェースです。
	 */
	public interface MergeRowSearcher<E extends MCRow> {

		/**
		 * コピー先のリストを設定します。
		 *
		 * @param blockNum ブロック番号
		 * @param destL コピー先のリスト
		 */
		public void setDestL(int blockNum, MCList<E> destL);

		/**
		 * コピー先のRowを返します。
		 *
		 * @param src コピー元のRow
		 * @param cols コピーするカラム
		 * @return コピー先のRow
		 */
		public E getMergeRow(E src, String... cols);

		/**
		 * コピー元のRowやコピー先のRowをリスト内で一意に識別するためのキーを返します。
		 *
		 * @param row Rowコンテナ
		 * @param cols コピーするカラム
		 * @return キー
		 */
		public Object getKey(E row, String... cols);
	}

	public class DefaultMergeRowSearcher<E extends MCRow> implements MergeRowSearcher<E> {

		protected Map<Integer, E> _map = new HashMap<>();

		public DefaultMergeRowSearcher() {
		}

		@Override
		public void setDestL(int blockNum, MCList<E> destL) {
			destL.stream().forEach(d -> _map.put(getKey(d), d));
		}

		@Override
		public Integer getKey(E row, String... cols) {
			return row.getParamRowIndex();
		}

		@Override
		public E getMergeRow(E src, String... cols) {
			return _map.get(getKey(src));
		}

	}

	/**
	 * ユーティリティ：コピー元のRowからコピー先のRowに指定されたカラムの内容と行属性をコピーする
	 *
	 * @param dest コピー先のRow
	 * @param src コピー元のRow
	 * @param cols コピーするカラム
	 */
	protected void merge(MCRow dest, MCRow src, String... cols) {
		if (src != null) {
			if (isAsyncRsltMode()) {
				// 非同期実行の場合、ステータスのみ下り電文からコピーする。
				// ※GUIIndexが、下り電文の値(-1)で上書きされてしまうことを防ぐ。
				dest.setStatus(src.getStatus());
				dest.setValues(cols, src, cols);
			}
			else {
				dest.setValues(cols, src, cols);
				if (!keepDownAttributes()) {
					dest.setAttributes(src);
				}
			}
		}
	}

	/**
	 * ユーティリティ：上り電文項目の項目名を取得する
	 *
	 * @param blockNum ブロック番号
	 * @return 項目名
	 */
	protected String[] getUpItemNames(int blockNum) {
		MCItemDef[] itemDef = getUpItems(blockNum);
		List<String> ret = new ArrayList<>();
		for (int i = 0; i < itemDef.length; i++) {
			String ps = itemDef[i].toParamString();
			if (!isNull(ps)) {
				ret.add(ps);
			}
		}
		return ret.toArray(new String[0]);
	}

	/**
	 * ユーティリティ：下り電文項目の項目名を取得する
	 *
	 * @param blockNum ブロック番号
	 * @return 項目名
	 */
	protected String[] getDownItemNames(int blockNum) {
		MCItemDef[] itemDef = getDownItems(blockNum);
		List<String> ret = new ArrayList<>();
		for (int i = 0; i < itemDef.length; i++) {
			String ps = itemDef[i].toParamString();
			if (!isNull(ps)) {
				ret.add(ps);
			}
		}
		ArrayList<String> l = _customDownItemNames[blockNum];
		if (l != null) {
			ret.addAll(l);
		}
		return ret.toArray(new String[0]);
	}

	/**
	 * ユーティリティ：上り電文項目情報を取得する
	 *
	 * @param blockNum ブロック番号
	 * @return 電文項目情報
	 */
	protected MCItemDef[] getUpItems(int blockNum) {
		String contDefId = MCPioUtil.toDefId(param(), MCDPType.UP, blockNum);
		MCDef def = param().getDef();
		MCContainerDef contDef = def.getDef(contDefId);
		return contDef.transItems();
	}

	/**
	 * ユーティリティ：下り電文項目情報を取得する
	 *
	 * @param blockNum ブロック番号
	 * @return 電文項目情報
	 */
	protected MCItemDef[] getDownItems(int blockNum) {
		String contDefId = MCPioUtil.toDefId(param(), MCDPType.DW, blockNum);
		MCDef def = param().getDef();
		MCContainerDef contDef = def.getDef(contDefId);
		return contDef.transItems();
	}

	@SuppressWarnings("unchecked")
	ArrayList<String>[] _customDownItemNames = new ArrayList[10];

	/**
	 * マージ対象項目を追加します。
	 *
	 * {@link #showMerge()}メソッドでのマージ対象項目を追加します。
	 *
	 * @since     6.4.0
	 * @param blockIdx ブロックIndex
	 * @param nms 項目
	 */
	public void addDownItemNames(int blockIdx, String... nms) {
		if (nms == null) {
			return;
		}
		if (_customDownItemNames.length <= blockIdx) {
			_customDownItemNames = Arrays.copyOf(_customDownItemNames,
					_customDownItemNames.length + 1);
		}
		ArrayList<String> l = _customDownItemNames[blockIdx];
		if (l == null) {
			l = new ArrayList<>();
			_customDownItemNames[blockIdx] = l;
		}
		for (String n : nms) {
			if (!l.contains(n)) {
				l.add(n);
			}
		}
	}

	/**
	 * 上り電文のデータの桁数チェックを行います。 <br>
	 */
	protected MCMessageList checkScaleAndLength() {
		MCMessageList msgList = null;
		for (int i = 0; i < getUpBlocks().size(); i++) {
			MCContainer c = getUpParams().get(i);
			MCMessageList t = panel.checkScaleAndLength(c, getUpItemNames(i));
			if (t != null && t.size() > 0) {
				if (msgList == null) {
					msgList = t;
				}
				else {
					msgList.addAll(t);
				}
			}
		}
		if (msgList == null) {
			msgList = new MCMessageList();
		}
		return msgList;
	}

	// ユーティリティ（ここまで）

	// コンテナ属性の維持の設定（ここから）

	private boolean _keepUpRefTime = false;

	private boolean _keepDownAttributes = false;

	/**
	 * 電文の特定の属性（上り電文の参照日時、下り電文の全ての属性）を通信前の状態のまま維持するかどうかを設定する。<br/>
	 * 維持する場合はtrueを設定する。デフォルトは維持しない。<br/>
	 * 上り電文の参照日時の維持についてはkeepUpRowRefTimeと振舞いは同じ。<br/>
	 * 下り電文の属性の維持についてはkeepDownAttributesと振舞いは同じ。<br/>
	 * <br/>
	 * 本メソッドは、サーバで行った計算結果を画面に反映するボタンなど、ユーザの入力
	 * を補助するための通信に使うことを目的としている。<br/>
	 * そのような通信では参照日時やステータスなどのコンテナの属性を上書きしたくないケースが多い。<br/>
	 * 上り電文の電文位置情報については、サーバ側でメッセージを下らせた場合に使用するので、維持しない。
	 *
	 *
	 * @param boo 上り電文の参照日時を更新するかどうか
	 * @see keepUpRowRefTime
	 * @see keepDownAttributes
	 */
	protected void keepAttributes(boolean boo) {
		keepUpRowRefTime(boo);
		keepDownAttributes(boo);
	}

	/**
	 * 上り電文の参照日時を通信前の状態のまま維持するかどうかを設定する。<br/>
	 * 維持する場合はtrueを設定する。デフォルトは維持しない。<br/>
	 * 維持する場合、setCommitTimeの中で画面のコンテナの参照日時を変更しない。<br/>
	 *
	 * @param boo 上り電文の参照日時を維持するかどうか
	 */
	protected void keepUpRowRefTime(boolean boo) {
		_keepUpRefTime = boo;
	}

	/**
	 * 上り電文の参照日時を通信前の状態のまま維持する場合は true を返す。
	 *
	 * @return 上り電文の参照日時を維持するかどうか
	 */
	protected boolean keepUpRowRefTime() {
		return _keepUpRefTime;
	}

	/**
	 * 下り電文の属性を通信前の状態のまま維持するかどうかを設定する。<br/>
	 * 維持する場合はtrueを設定する。デフォルトは維持しない。<br/>
	 * 維持する場合、showMergeの中で画面のコンテナの属性を変更しない。<br/>
	 *
	 * @param boo 下り電文の参照日時を維持するかどうか
	 */
	protected void keepDownAttributes(boolean boo) {
		_keepDownAttributes = boo;
	}

	/**
	 * 下り電文の属性を通信前の状態のまま維持する場合は true を返す。
	 *
	 * @return 下り電文の参照日時を維持するかどうか
	 */
	protected boolean keepDownAttributes() {
		return _keepDownAttributes;
	}

	@Override
	protected void setCommitTime(MCParam p) {
		if (!keepUpRowRefTime()) {
			setCommitTime(p, p.getCommitTime());
		}
	}

	// コンテナ属性の維持の設定（ここまで）

	// 埋込画面　ここから

	@Override
	protected boolean beforeExecMain() {
		initCaller();
		if (!checkForCall()) {
			return false;
		}
		beforeCallParts();
		setupParam();
		beforeCall();
		if (!checkLimitULSize() || !checkInvisibleRowInUpParam()) {
			return false;
		}
		if (isAsync() && isCsvOutForAsync()) {
			// 非同期実行して結果確認に利用するCSVが出力できたかどうか
			// superの処理を呼んでいないので、ここにも要る。
			return csvOutForAsync();
		}
		return true;
	}

	/**
	 * 上り電文に関連するコンテナに関連のある埋込画面の
	 * {@link IfHPartsForCaller#beforeCallParts(MCCaller)}または
	 * {@link IfDPartsForCaller#beforeCallParts(mcframe.commonCore.container.MCRowMatcher, MCCaller)}を
	 * 呼び出します。
	 */
	protected void beforeCallParts() {
		List<MCContainer> ups = getAllUpBlocks();
		for (int i = 0; i < ups.size(); i++) {
			MCContainer cont = ups.get(i);
			for (MCRootPanel parts : getRelatePartsPanels(cont)) {
				if (parts instanceof IfHPartsForCaller) {
					IfHPartsForCaller hParts = (IfHPartsForCaller) parts;
					hParts.beforeCallParts(this);
				}
				else if (parts instanceof IfDPartsForCaller) {
					IfDPartsForCaller dParts = (IfDPartsForCaller) parts;
					dParts.beforeCallParts(panel.getExceptRootEmptyMatcher(), this);
				}
			}
		}
	}

	/**
	 * cont に関連する埋込画面を返す
	 * @param cont コンテナ
	 * @return 埋込画面
	 */
	protected MCRootPanel[] getRelatePartsPanels(MCContainer cont) {
		Map<MCContainer, MCRootPanel[]> map = relatePartsPanels();
		map.get(cont);

		MCRootPanel[] a = new MCRootPanel[] {};
		for (Map.Entry<MCContainer, MCRootPanel[]> ent : map.entrySet()) {
			if (ent.getKey() == cont) {
				a = ent.getValue();
			}
		}
		return a;
	}

	/**
	 * コンテナに関連する埋込画面のマップを返します。
	 *
	 * @return コンテナに関連する埋込画面のマップ
	 */
	protected Map<MCContainer, MCRootPanel[]> relatePartsPanels() {
		if (_relatePartsPanels == null) {
			// keyに使用しているMCContainerは、中の値が変更されるとhashCodeが
			// 変更されてしまう。
			// 通常のHashMapに関しては、例えば検索結果を表示した後に、
			// 部品のMCRootPanelを取得しようとしても取得できない。
			// それを解消するためにインスタンス一致でMapにするIdentityHashMap
			// を使用する必要がある
			_relatePartsPanels = new IdentityHashMap<>();
			List<MCContainer> ups = getAllUpBlocks();
			for (int i = 0; i < ups.size(); i++) {
				MCContainer cont = ups.get(i);
				if (!_relatePartsPanels.containsKey(cont)) {
					_relatePartsPanels.put(cont, panel.getPartsPanels(cont));
				}
			}
			List<MCContainer> downs = getAllDownBlocks();
			for (int i = 0; i < downs.size(); i++) {
				MCContainer cont = downs.get(i);
				if (!_relatePartsPanels.containsKey(cont)) {
					_relatePartsPanels.put(cont, panel.getPartsPanels(cont));
				}
			}
		}

		return _relatePartsPanels;
	}

	/**
	 * 上り電文に関連するコンテナに関連のある埋込画面の
	 * {@link IfHPartsForCaller#afterCallParts(MCCaller)}または
	 * {@link IfDPartsForCaller#afterCallParts(mcframe.commonCore.container.MCRowMatcher, MCCaller)}を
	 * 呼び出します。
	 */
	protected void afterCallParts() {
		List<MCContainer> downs = getAllDownBlocks();
		for (int i = 0; i < downs.size(); i++) {
			MCContainer cont = downs.get(i);
			for (MCRootPanel parts : getRelatePartsPanels(cont)) {
				if (parts instanceof IfHPartsForCaller) {
					IfHPartsForCaller hParts = (IfHPartsForCaller) parts;
					hParts.afterCallParts(this);
				}
				else if (parts instanceof IfDPartsForCaller) {
					IfDPartsForCaller dParts = (IfDPartsForCaller) parts;
					dParts.afterCallParts(panel.getExceptRootEmptyMatcher(), this);
				}
			}
		}
	}

	/**
	 * 上り電文に関連するコンテナに関連のある埋込画面の
	 * {@link IfHPartsForCaller#checkForCallStack(MCMessageList,MCCaller)}または
	 * {@link IfDPartsForCaller#checkForCallStack(MCMessageList, mcframe.commonCore.container.MCRowMatcher, MCCaller)}を
	 * 呼び出します。
	 * @param list エラーメッセージを格納するためのリスト
	 */
	protected void checkForCallStackParts(MCMessageList list) {
		List<MCContainer> ups = getAllUpBlocks();
		for (int i = 0; i < ups.size(); i++) {
			MCContainer cont = ups.get(i);
			for (MCRootPanel parts : getRelatePartsPanels(cont)) {
				if (parts instanceof IfHPartsForCaller) {
					IfHPartsForCaller hParts = (IfHPartsForCaller) parts;
					hParts.checkForCallStack(list, this);
				}
				else if (parts instanceof IfDPartsForCaller) {
					IfDPartsForCaller dParts = (IfDPartsForCaller) parts;
					dParts.checkForCallStack(list,
							panel.getExceptRootDeleteAndEmptyMatcher(), this);
				}
			}
		}
	}
	// 埋込画面　ここまで
}