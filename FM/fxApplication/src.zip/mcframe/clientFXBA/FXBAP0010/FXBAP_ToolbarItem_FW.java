package mcframe.clientFXBA.FXBAP0010;

import static mcframe.commonFX.notice.FX_Msg.*;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import mcframe.clientCore.beans.MCPanel;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCLog;
import mcframe.clientFXUC.FXUCP0030.IfToolbarBeansHolder;
// ブックマーク
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.clientFXUC.FXUCP0040.FXUCP_ToolBarUtil;
import mcframe.clientFXUC.FXUCP0040.OpenScreenInfoR;
import mcframe.clientFXUC.FXUCP0040.OpenScreenParamR;

public abstract class FXBAP_ToolbarItem_FW {

	private MCRootPanel _mainPanel;
	/**
	 * コンストラクタです。
	 *
	 */
	public FXBAP_ToolbarItem_FW(MCRootPanel mainPanel) {
		super();
		_mainPanel = mainPanel;
	}

	protected List<IfToolbarItem> _toolbarItemList = new ArrayList<IfToolbarItem>();
	
	protected List<IfToolbarItem> getToolbarItemList() {
		return _toolbarItemList != null ? _toolbarItemList
				: (_toolbarItemList = new ArrayList<>());
	}

	/**
	 * 個人で設定するカスタムツールバーのボタンを初期化
	 */
	protected void toolbarItemsPersonalLink(List<IfToolbarBeansHolder> list) {

		// ブックマーク
		List<MCPanel> lp = new ArrayList<>();
		for (IfToolbarBeansHolder h : list) {
			if (h.comp() instanceof MCPanel) {
				lp.add((MCPanel)h.comp());
			}
		}
		MCPanel bookp = null;
		for (MCPanel p : lp) {
			if ("Bookmark".equals(p.getName())) {
				bookp = p;
				break;
			}
 		}

		
		if (bookp != null) {
			//　設定済みのボタンを削除して再設定する
			for (Component bc : bookp.getComponents()) {
				if (bc.getName()
						.startsWith(FXUCP_ToolBarUtil.BOOKMARK_OPEN_SCREEN_NM_PRF)) {
					bookp.remove(bc);
				}
			}

			OpenScreenInfoR proto = OpenScreenInfoR.create();
			proto.base_module_id(_mainPanel.getModuleID());
			proto.base_screen_id(_mainPanel.getScreenID());

			// 全ての設定単位をロード
			MCList<OpenScreenInfoR> infoL = FXUCP_ToolBarUtil.loadOpenScreenInfo(proto);
			FXUCP_ToolBarUtil.resetOpenScreenBtnCounter((FXBAP_PanelBase) _mainPanel); // 7.0.1

			MCList<OpenScreenInfoR> sysL = infoL.subList(
					r -> FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(r.setting_unit_type()));
			MCList<OpenScreenInfoR> extL = infoL.subList(
					r -> FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(r.setting_unit_type()));
			MCList<OpenScreenInfoR> usrL = infoL.subList(
					r -> FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(r.setting_unit_type()));
			if (usrL.size() != 0) {
				addBookMarkButton(bookp, usrL);
			}
			if (extL.size() != 0) {
				addBookMarkButton(bookp, extL);
			}
			if (sysL.size() != 0) {
				addBookMarkButton(bookp, sysL);
			}
		}
		// ブックマークここまで

		for(String s : getToolbarItemClass()) {
			Class c;
			try {
				c = Class.forName(s);
				if(c != null) {
					IfToolbarItem p = (IfToolbarItem)c.newInstance();
					p.toolbarItemsPersonalLink(_mainPanel,list);
					getToolbarItemList().add(p);
				}
			} catch (ClassNotFoundException
					| InstantiationException | IllegalAccessException e) {
				// 7013-1991 BEGIN
				MCLog.write(FXBAP0106, s);
//				MCLog.write(e);
				// 7013-1991 END
				// エラーの場合は画面が開けなくなるためthrowしない
			}
		}
	}

	/**
	 * ツールバーに画面遷移設定のボタンを追加します。
	 * <p>
	 * ログインユーザが当該画面を開く権限を付与されている場合のみボタン追加します。
	 * 
	 * @param bookp カスタムツールバーのボタン枠
	 * @param infoL 遷移設定のList
	 */
	void addBookMarkButton(MCPanel bookp, MCList<OpenScreenInfoR> infoL) {
		for (int i = 0; i < infoL.size(); i++) {
			OpenScreenInfoR info = infoL.get(i);
			if (!mcframe.clientCore.acl.MCACLManager.authorize(
					info.open_module_id(), info.open_screen_id(), "show", "toolbar")) {
				continue;
			}

			MCList<OpenScreenParamR> params = FXUCP_ToolBarUtil.loadOpenScreenParam(info, i);
			bookp.add(FXUCP_ToolBarUtil.createOpenScreenBtn((FXBAP_PanelBase) _mainPanel, info, params));
		}
	}

	/**
	 *  Toolbarのアイテムの初期化
	 *  画面が開いた後に呼ばれる
	 */
	public void afterOpen() {
		for (IfToolbarItem p : getToolbarItemList()) {
			try {
				if (p != null) {
					p.afterOpen();
				}
			}
			catch (Exception ex) {
				// 一部のツールにエラーがあっても続きを行う。
				// ユーザクラスでリソースでプラグインの指定がされてあってもクラスがない場合がある。
				// throw不要
				MCLog.developDebug(ex);
			}
		}
	}

	/**
	 *  Toolbarのアイテムのリリース
	 *  画面が閉じる前に呼ばれる
	 * @return
	 */
	public boolean beforeClose() {
		// 7012-0856 (【ロボット】ロボット（画面の操作記録・再生）の品質を強化する)
		// メモリーリーク対応
		for (IfToolbarItem p : getToolbarItemList()) {
			if (p != null) {
				p.beforeClose();
			}
		}

		_toolbarItemList = null;

		return true;
	}

	// constからtoolbar item情報を得る。
	protected List<String>getToolbarItemClass() {

		final String key_item = "item";

		List<String> ans = new ArrayList<String>();
		MCRow proto = MCRow.create();

		String rootKey = createRootResourceKey(proto);
		String[] baseKeys = MCConst.plugin.findPattern(MCConst.createKey(rootKey, "*"));
			for (String key : baseKeys) {
				String base = MCConst.plugin.getString(key,null);
				if (base == null) {
					// 値未設定は連携項目なし
					continue;
				}
				ans.add(base);
			}

	//	}
		return ans;
	}

	// 画面Toolbarパーソナライズ
	protected static String TOOLBAR_ITEM = "toolbar_item";

	protected String createRootResourceKey(MCRow row) {
		return MCConst.createKey(TOOLBAR_ITEM);
	}
}