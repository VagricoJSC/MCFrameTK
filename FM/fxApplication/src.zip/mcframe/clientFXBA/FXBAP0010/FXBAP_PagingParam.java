package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.table.MCTable;
import mcframe.commonCore.container.MCSortPolicy;

public class FXBAP_PagingParam extends FXBAP_PagingParam_FW {

	/**
	 * {@link FXBAP_PagingParam_FW#FXBAP_PagingParam_FW(String, Class, MCTable...)}
	 */
	public FXBAP_PagingParam(String blkId, Class<? extends FXBAP_Searcher> clr, MCTable... tbls) {
		super(blkId, clr, tbls);
	}

	/**
	 * {@link FXBAP_PagingParam_FW#FXBAP_PagingParam_FW(String, Class)}
	 */
	public FXBAP_PagingParam(String blkId, Class<? extends FXBAP_Searcher> clr) {
		super(blkId, clr);
	}

	/**
	 * {@link FXBAP_PagingParam_FW#FXBAP_PagingParam_FW(String, int, Class, MCTable...)}
	 */
	public FXBAP_PagingParam(String blkId, int size, Class<? extends FXBAP_Searcher> clr,
			MCTable... tbls) {
		super(blkId, size, clr, tbls);
	}

	/**
	 * {@link FXBAP_PagingParam_FW#FXBAP_PagingParam_FW(String, int, Class)}
	 */
	public FXBAP_PagingParam(String blkId, int size, Class<? extends FXBAP_Searcher> clr) {
		super(blkId, size, clr);
	}

}
