package mcframe.clientFXBA.FXBAP0010;

public interface IfTmplBase extends IfTmplBase_FW {
	
}