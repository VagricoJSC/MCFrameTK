package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.commonCore.annotation.EI;

@EI
public class FXBAP_ErrorHandler extends FXBAP_ErrorHandler_FW {

	public FXBAP_ErrorHandler(MCRootPanel panel) {
		super(panel);
	}

}
