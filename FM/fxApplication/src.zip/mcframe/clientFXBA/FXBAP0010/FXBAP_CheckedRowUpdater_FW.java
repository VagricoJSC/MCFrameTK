package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.container.*;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.notice.*;
import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * 上り電文のうち、１つのブロックで、更新対象の行にチェックをつけた行のみ上り電文セットするように することができます。
 * 
 * @param
 * <P>
 * パネルクラス
 * @param <O> ブリッジクラス
 */
public abstract class FXBAP_CheckedRowUpdater_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Updater<P, O> {

	public FXBAP_CheckedRowUpdater_FW(P panel, O operation) {
		super(panel, operation);
	}

	@Override
	protected void setupUpParam() {
		for (MCContainer c : getUpBlocks()) {
			if (c == getCheckedRowList()) {
				param().addUpBlock(getCheckedRows());
				continue;
			}
			if (c instanceof MCList) {
				param().addUpBlock(panel.exceptEmpty((MCList<?>) c));
			}
			else {
				param().addUpBlock(c);
			}
		}
	}

	@Override
	protected boolean isUpBlockStatusNone() {
		// ピックアップされたリストの状態でしか判断しません
		// （それ以外の判断は必要なし）
		return (getCheckedRows().size() == 0);
	}

	@Override
	public MCMessage msgNoDataChange() {
		return new MCMessage(FXBAP0038);
	}

	@Override
	protected void checkReq(MCMessageList msgList) {
		for (MCContainer cont : getAllUpBlocks()) {
			if (cont == getCheckedRowList()) {
				msgList.addAll(panel.checkReq(getCheckedRows()));
				continue;
			}
			if (cont instanceof MCList) {
				msgList.addAll(panel.checkReq((panel
						.exceptDeleteAndEmpty((MCList<?>) cont))));
			}
			else {
				msgList.addAll(panel.checkReq(cont));
			}
		}
	}

	// ユーティリティ---------------------------------
	private MCList<? extends MCConstRow> _pickedList;

	/**
	 * {@link #getCheckedRowListBlock()}で指定したブロックの中で {@link #getCheckColumn()}で指定された
	 * カラムが true の行を集めたリストを返します。
	 * 
	 * @return リスト
	 */
	public MCList<? extends MCConstRow> getCheckedRows() {
		if (_pickedList == null) {
			_pickedList = getCheckedRowList().subList(getCheckColumn(), true);
		}
		return _pickedList;
	}

	/**
	 * {@link #getCheckedRows()}の戻り値のRowの型を指定することができるメソッドです。
	 * 
	 * @param <E> {@link #getCheckedRowListBlock()}で指定したリストのRowクラス又はそのスーパークラス
	 * @param clazz 戻り値のRowクラス
	 * @return {@link #getCheckedRows()}参照
	 */
	@SuppressWarnings("unchecked")
	// return のところのキャスト
	public <E extends MCConstRow> MCList<E> getCheckedRows(Class<E> clazz) {
		MCList<? extends MCConstRow> ls = getCheckedRows();
		if (ls != null && !ls.isEmpty() && clazz != null) {
			MCConstRow r = ls.get(0);
			if (!clazz.isInstance(r)) {
				throw new MCAppException(FXBAP0039, r.getClass().getName(), clazz
						.getName());
			}
		}
		return (MCList<E>) ls;
	}

	@Override
	protected boolean checkForCall() {
		if (!checkCheckedRowSize()) {
			return false;
		}
		return super.checkForCall();
	}

	protected boolean checkCheckedRowSize() {
		if (getCheckedRows().isEmpty()) {
			panel.dialog(msgNoDataChange());
			return false;
		}
		return true;
	}

	/**
	 * 「チェック」のカラム名（デフォルトは"check"。）
	 */
	protected String getCheckColumn() {
		return "check";
	}

	/**
	 * 「更新対象の行にチェック」をするリストの上り電文のブロック番号（デフォルトは「0」）
	 */
	protected int getCheckedRowListBlock() {
		return 0;
	}

	/**
	 * 対象のリストの画面コンテナを返す。
	 */
	@SuppressWarnings("unchecked")
	protected MCList<? extends MCConstRow> getCheckedRowList() {
		return (MCList<? extends MCConstRow>) getUpBlocks().get(getCheckedRowListBlock());
	}

}
