package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCaller;
import mcframe.commonCore.container.MCRowMatcher;
import mcframe.commonCore.notice.MCMessageList;

public interface IfDPartsForCaller {
	/**
	 * 通信前チェック処理。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出される。
	 * 通信定型処理から呼び出される。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出す。
	 * </P>
	 * @param list メッセージを格納するためのリスト
	 * @param matcher 通信対象を取得するための {@link MCRowMatcher}。（但し、通信対象以外の行も取得される可能性があり）
	 * @param caller 通信処理クラス。
	 */
	@SuppressWarnings("rawtypes")
	public void checkForCallStack(MCMessageList list, MCRowMatcher matcher,
			MCCaller caller);

	/**
	 * 通信前処理。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出される。
	 * 通信定型処理から呼び出される。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出す。
	 * </P>
	 * @param matcher 通信対象を取得するための {@link MCRowMatcher}。（但し、通信対象以外の行も取得される可能性があり）
	 * @param caller 通信処理クラス。
	 */
	@SuppressWarnings("rawtypes")
	public void beforeCallParts(MCRowMatcher matcher, MCCaller caller);

	/**
	 * 通信後処理。
	 * <P>
	 * 自身のコンテナが通信の下り電文に含まれている場合に呼び出される。
	 * 通信定型処理から呼び出される。
	 * </P>
	 * <P>
	 * デフォルトの処理、この埋込画面が直接使用している
	 * 埋込画面クラスの同名メソッドを呼び出す。
	 * </P>
	 * @param matcher 通信対象を取得するための {@link MCRowMatcher}。（但し、通信対象以外の行も取得される可能性があり）
	 * @param caller 通信処理クラス。
	 */
	@SuppressWarnings("rawtypes")
	public void afterCallParts(MCRowMatcher matcher, MCCaller caller);
}
