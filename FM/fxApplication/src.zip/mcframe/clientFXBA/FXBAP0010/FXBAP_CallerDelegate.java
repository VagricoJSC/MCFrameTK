package mcframe.clientFXBA.FXBAP0010;

import mcframe.commonCore.annotation.EI;

/**
 * 通信定型処理クラスの委譲クラスです。
 */
@EI
public class FXBAP_CallerDelegate extends FXBAP_CallerDelegate_FW {
	protected FXBAP_CallerDelegate() {}
}
