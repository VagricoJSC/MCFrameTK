package mcframe.clientFXBA.FXBAP0010;

import mcframe.commonCore.annotation.EI;

@EI
public interface FXBAP_ISPanel extends FXBAP_ISPanel_FW{

}
