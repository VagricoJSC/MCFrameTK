package mcframe.clientFXBA.FXBAP0010;

public interface IfPagingAgentHolder extends IfPagingAgentHolder_FW{

}
