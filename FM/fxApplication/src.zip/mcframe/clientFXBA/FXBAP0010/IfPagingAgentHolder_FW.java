package mcframe.clientFXBA.FXBAP0010;

import java.util.List;
import java.util.Map;

import mcframe.clientCore.beans.MCPagingAgent;

public interface IfPagingAgentHolder_FW {
	
	/**
	 * 実装クラスがページングエージェントを保持するクラスとして有効かどうかを返します。
	 * @return ページングエージェントホルダーとして有効かどうか
	 */
	public boolean isPagingAgentHolder() ;
	
	/**
	 * Calleｒクラスをキーとして対応するページングエージェントを保持するマップを返します。
	 * @return マップ
	 */
	public Map<Class, MCPagingAgent> getPagingAgentContainer();
	
	/**
	 * 引数のCallerのruntimeクラスに対応したページングエージェントを返します。<p>
	 * nullを返す場合は引数のCallerはページングしません。<br>
	 * ページング機能を使用する場合、{{@link #getPagingCallTyp(FXBAP_PageSearcher)}がNEWを返す場合には、
	 * 新規作成したページングエージェント、PREV、NEXTの場合にはNEWの時に作成したページングエージェントを返します。
	 * @param Callerのruntimeクラス
	 * @return ページングエージェントまたはnull
	 */
	public MCPagingAgent getPagingAgent(Class clr);
		
	/**
	 * ページング検索通信処理クラスを実行します。<p>
	 * 
	 * @param eventPanel 呼び出し元画面
	 */
	public void callPagingSearcher(FXBAP_PanelBase eventPanel);
	
	/**
	 *ページングの新規検索、次へ、前へを表す定数を設定します。
	 * nullを指定した場合は引数のCallerはページングしません。<br>
	 * @param p　新規検索、次へ、前へを表す定数
	 */
	public void setPagingCallTyp(FXBAP_Searcher.PagingCallTyp p);
	
	/**
	 * ページングの新規検索、次へ、前へを表す定数を返します。<p>
	 * nullを返す場合は引数のCallerはページングしません。<br>
	 * @param clr Caller
	 * @return　新規検索、次へ、前へを表す定数
	 */
	public FXBAP_Searcher.PagingCallTyp getPagingCallTyp();

	/**
	 * ページング設定を返します。<p>
	 * @return　ページング情報
	 */
	public List<FXBAP_PagingParam> getPagingParam();

	/**
	 * 既存のページング情報をクリアします。
	 */
	public void clearPagingParam();

	/**
	 * 既存のページング情報をクリアし、新たに設定します。
	 * @param ps　ページング情報
	 */
	public void setPagingParam(FXBAP_PagingParam... ps);
	/**
	 * ページング情報を設定します。<p>
	 * 既存の同一通信処理、ブロックIDの情報は上書きされます。
	 * @param ps　ページング情報
	 */
	public void addPagingParam(FXBAP_PagingParam... ps);
	/**
	 * ページング情報を削除します。
	 * 引数psの同一通信処理、ブロックIDの情報を削除します。
	 * @param ps　ページング情報
	 */
	public void removePagingParam(FXBAP_PagingParam... ps);
}
