package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.annotation.EI;

/**
 * 上り電文のうち、１つのブロックで、更新対象の行にチェックをつけた行のみ上り電文セットするように することができます。
 * 
 * @param
 * <P>
 * パネルクラス
 * @param <O> ブリッジクラス
 */
@EI
public abstract class FXBAP_CheckedRowPrinter<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_CheckedRowPrinter_FW<P, O> {

	public FXBAP_CheckedRowPrinter(P panel, O operation) {
		super(panel, operation);
	}
}
