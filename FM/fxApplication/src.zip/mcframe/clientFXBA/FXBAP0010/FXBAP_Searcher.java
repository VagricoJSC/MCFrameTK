package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.*;
import mcframe.commonCore.annotation.EI;

@EI
public class FXBAP_Searcher<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge> extends
		FXBAP_Searcher_FW<P, O> {
	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Searcher(P panel, O operation) {
		super(panel, operation);
	}


}
