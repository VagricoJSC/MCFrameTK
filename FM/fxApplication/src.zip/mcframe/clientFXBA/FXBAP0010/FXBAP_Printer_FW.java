package mcframe.clientFXBA.FXBAP0010;

import static mcframe.commonFX.notice.FX_Msg.*;

import java.util.ArrayList;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.MCMessageBox;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.report.MCClientReportInfoR;
import mcframe.clientCore.report.MCClientReportManager;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

public class FXBAP_Printer_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Caller<P, O> {
	/**
	 * コンストラクタです。
	 *
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Printer_FW(P panel, O operation) {
		super(panel, operation);
	}

	/**
	 * 下り電文上限チェックによる、後続処理続行可不可判定（続行可能がtrue）
	 */
	protected boolean _isNotCapError = false;

	/**
	 * バックグラウンドで印刷オペレーションを実行するかどうか
	 */
	private boolean _backgroundPrint = false;

	/**
	 * プログレスダイアログを設定します。
	 */
	@Override
	protected void addProgressPanel() {
		if (!getBackgroundPrint()) {
			super.addProgressPanelMain();
		}
	}

	/**
	 * バックグラウンドで印刷オペレーションを実行する場合はtrueをセットします。
	 * <p>
	 * {@link #getPrintFlg()}の戻り値がtrueでない場合は無効です。
	 *
	 * @param flg
	 */
	protected void setBackgroundPrint(boolean flg) {
		_backgroundPrint = flg;
	}

	/**
	 * バックグラウンドで印刷オペレーションを実行する場合はtrueを返します。
	 *
	 * @return
	 */
	protected boolean getBackgroundPrint() {
		return _backgroundPrint;
	}

	/**
	 * MXUPdaterの処理を行います。
	 */
	@Override
	protected boolean beforeExecMain() {
		clearEmptyRowStatus();
		initCaller();
		if (!execConfirm()) {
			return false;
		}
		if (!checkForCall()) {
			return false;
		}
		setupParam();
		beforeCallParts();
		if (isUpParamEmpty() || checkUpListParamEmpty() == false) {
			showNoUpDataMsg();
			return false;
		}

		beforeCall();
		MCMessageList msgList = checkScaleAndLength();
		if (msgList.size() > 0) {
			panel.message(msgList);
			return false;
		}

		if (!checkLimitULSize() || !checkInvisibleRowInUpParam()) {
			return false;
		}

		return true;
	}

	@Override
	protected MCCallBackType callPanelUpdateAction() {
		unlockScreen();
		show();
		statusClear();
		setMode();
		moveFocus();
		showMsg();
		if (!getBackgroundPrint() && !isDownClientPrintDataEmpty()) {
			print();
		}
		resultSuccess();
		return MCCallBackType.SUCCESS;
	}

	/**
	 * 下り電文上限数の設定をします。
	 * <p>
	 * デフォルト実装：リミットなしにする
	 * </p>
	 */
	@Override
	protected void setLimitDLSize() {
		param().setLimitDLSize(MCNumber.valueOf(-1));
	}

	/**
	 * ステータスをクリアします。
	 * <p>
	 * デフォルト実装：何もしない
	 * </p>
	 */
	protected void statusClear() {
		// 何もしない
	}

	/**
	 * 上り電文のリストコンテナが０件かどうかをチェックする。 falseを返すとサーバー通信をしない。
	 * <p>
	 * デフォルト実装：<br>
	 * <li>上り電文にリストコンテナが存在しない場合は、true</li>
	 * <li>上り電文にリストコンテナが１つ以上存在する場合、 全てのリストコンテナが０件の場合はfalse</li>
	 * </p>
	 *
	 * @return
	 */
	protected boolean checkUpListParamEmpty() {
		boolean hasList = false; // リストがあるかどうか
		boolean isListEmpty = true;
		for (MCContainer c : getUpParams()) {
			if (c instanceof MCList<?>) {
				hasList = true;
				MCList<?> list = (MCList<?>) c;
				if (!list.isEmpty()) {
					isListEmpty = false;
					break;
				}
			}
		}
		boolean ans = true;
		if (hasList && isListEmpty) {
			ans = false;
			showNoUpListDataMsg();
		}
		return ans;
	}

	/**
	 * サーバー処理で例外が発生した場合の、処理を行う。 特に理由がない限り、例外をthrowする。
	 *
	 * @param ex
	 */
	@Override
	protected void handleMCEx(MCException ex) {
		throw ex;
	}

	/**
	 * 通信を行うためのチェックを行います。
	 * <p>
	 * デフォルト実装：
	 * <li>{@link #checkForCallStack(MCMessageList)}を呼び出し、戻り値のリストが
	 * １件以上ある場合はメッセージダイアログを出し、falseを返す。</li>
	 * <li>上記以外はtrue</li>
	 * </p>
	 *
	 * @return 通信可能な場合 true 通信を行わない場合 false
	 */
	@Override
	protected boolean checkForCall() {
		if (super.checkForCall() == false) {
			return false;
		}
		return true;
	}

	/**
	 * 上り電文の全てのブロックのステータスがNONEの場合はtrue
	 *
	 * @return
	 */
	protected boolean isUpBlockStatusNone() {
		return panel.isStatusNone(getAllUpBlocks());
	}

	/**
	 * 複数のチェックを行い、エラーがあった場合のメッセージを msgList に格納します。
	 * <P>
	 * デフォルト実装：{@link #checkReq(MCMessageList) checkReq(MCMessageList)}を呼び出す。
	 * </P>
	 *
	 * @param msgList
	 */
	@Override
	protected void checkForCallStack(MCMessageList msgList) {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.checkForCallStack(msgList);
	}

	/**
	 * 必須チェックを行い、必須の箇所が空白だった場合は、そのメッセージを msgListに 格納します。
	 * <P>
	 * デフォルト実装：全ての上りブロックで{@link FXBAP_PanelBase#checkReq(MCContainer[]) FXBAP_PanelBase#checkReq}を呼び出す。
	 * </P>
	 *
	 * @param msgList
	 */
	@Override
	protected void checkReq(MCMessageList msgList) {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.checkReq(msgList);
	}

	/**
	 * [YES]/[NO] ダイアログを表示します。
	 *
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 */
	public int confirm(String id, Object... binds) {
		return confirm(new MCMessage(id, binds));
	}

	/**
	 * [YES]/[NO] ダイアログを表示します。
	 *
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 */
	@SuppressWarnings("deprecation")
	public int confirm(MCMessage msg) {
		MCDialogButton btn = panel.getConfirmFocus(msg);
		if (btn == null) {
			btn = panel.getConfirmFocus(FXBAP_Printer);
		}
		return panel.confirm(btn, msg);
	}

	/** クラス名 */
	// メモ：リソースをとるのに必要
	protected static final String FXBAP_Printer = "FXBAP_Printer";

	/**
	 * 更新処理を実行するかどうかを確認します。
	 * <P>
	 * メッセージの内容のみを変更したい場合は、{@link #msgExecConfirm()} をオーバーライドしてください。
	 *
	 * @return 削除処理を行う場合はtrue、行わない場合はfalse
	 */
	protected boolean execConfirm() {
		MCMessage msg = msgExecConfirm();
		return confirm(msg) == MCMessageBox.YES_OPTION;
	}

	/**
	 * 印刷処理の実行を確認するメッセージを返す。
	 */
	protected MCMessage msgExecConfirm() {
		return panel.msgPrintConfirm();
	}

	/**
	 * メッセージリストの先頭に処理終了を伝えるメッセージを追加する
	 */
	@Override
	protected void showDownMsg() {
		MCMessageList msgList = getMessages();
		panel.sortMessageList(msgList);
		MCMessage msg = msgPrintedWithMessages();
		if (msg != null) {
			msgList.add(0, msg);
		}
		panel.messageNoSort(msgList);
	}

	/**
	 * 更新ロジックが終了したときのメッセージを表示します。
	 */
	@Override
	protected void showEndMsg() {
		// デフォルトでは何も出さない
	}

	/**
	 * 上り電文情報が存在しないときの処理を行います。<br>
	 * メッセージを表示します。
	 */
	protected void showNoUpDataMsg() {
		panel.dialog(msgNoPrintData());
	}

	/**
	 * バックグラウンドで処理を実行しとときの処理を行います。<br>
	 * メッセージを表示します。
	 */
	protected void showBackgroundPrintMsg() {
		panel.dialog(msgBackgroundPrint());
	}

	/**
	 * バックグラウンドで処理を実行した旨のメッセージを返します。
	 *
	 * @return
	 */
	protected MCMessage msgBackgroundPrint() {
		return new MCMessage(FXBAP0100);
	}

	/**
	 * 登録対象の明細が存在しない場合のメッセージを表示します。
	 */
	protected void showNoUpListDataMsg() {
		panel.dialog(FXBAP0083);
	}

	/**
	 * 登録対象が存在しない場合のメッセージ
	 */
	public MCMessage msgNoPrintData() {
		return panel.msgNoPrintData();
	}

	/**
	 * サーバからの印刷データが存在しない場合のメッセージ
	 */
	public MCMessage msgNoDownPrintData() {
		return panel.msgNoDownPrintData();
	}

	/**
	 * 印刷処理が終了したが、サーバーからメッセージがあった場合に、その先頭に使用するメッセージ。
	 */
	public MCMessage msgPrintedWithMessages() {
		return new MCMessage(FXBAP0082);
	}

	/**
	 * Callerの初期化をします。非表示ブロックへのデータのコピーなど
	 */
	@Override
	protected void initCaller() {
		super.initCaller();
		setPrint(true);
	}

	@Override
	protected void call() {
		if (getPrintFlg() && getBackgroundPrint()) {
			// バックグラウンド実行
			MCClientReportManager.request(param());
			setDownReportInfo(new ArrayList<MCClientReportInfoR>());
		}
		else {
			super.call();
		}
	}

	/**
	 * 更新後処理。下り電文を画面表示する前に加工する
	 */
	@Override
	protected void afterCall() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.afterCall();
	}

	/**
	 * 更新前処理。上り電文の作成直前の処理。
	 */
	@Override
	protected void beforeCall() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.beforeCall();
	}

	/**
	 * 電文の初期化
	 */
	@Override
	protected void setupParam() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.setupParam();
	}

	/**
	 * 更新結果を画面用のコンテナにのせかえる
	 */
	@Override
	protected void show() {
		showMerge();
	}

	/**
	 * 通信後のフォーカス設定を行う。
	 * <p>
	 * デフォルト実装：何もしない。（setModeで画面ステータスを変更することで）
	 * </p>
	 * <p>
	 * setModeで設定されるフォーカス位置では困る場合のみ実装する。
	 * </p>
	 */
	@Override
	protected void moveFocus() {
	}

	/**
	 * 正常終了した時のメッセージを表示します。
	 */
	@Override
	protected void showMsg() {
		if (getBackgroundPrint()) {
			showBackgroundPrintMsg();
		}
		else if (!isDownPrintDataEmpty()) {
			if (hasMessage()) {
				showDownMsg();
			}
			else {
				showEndMsg();
			}
		}
		else {
			showNoDownPrintDataMsg();
		}
	}

	/**
	 * 印刷対象が存在しなかったときのメッセージを表示します。
	 */
	protected void showNoDownPrintDataMsg() {
		if (hasMessage()) {
			MCMessageList msgList = getMessages();
			panel.sortMessageList(msgList);
			MCMessage msg = msgNoDownPrintData();
			if (msg != null) {
				msgList.add(0, msg);
			}
			panel.messageNoSort(msgList);
		}
		else {
			panel.dialog(msgNoDownPrintData());
		}
	}
}
