package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientFXBA.FXBAP0040.FXBAP_ISPanelInfo;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;

public interface FXBAP_ISPanel_FW {

	public default MCList getList(MCRow bind, MCRootPanel parentPanel) {
		return getList(bind, parentPanel, true);
	}
	
	public MCList getList(MCRow bind, MCRootPanel parentPanel, boolean isInputMode);

	public MCList getList(MCRow bind, MCRootPanel parentPanel, FXBAP_ISPanelInfo info);

	/**
	 * このインターフェースを実装しているクラスのインスタンス
	 */
	public FXBAP_PanelBase getImplPanel();

}
