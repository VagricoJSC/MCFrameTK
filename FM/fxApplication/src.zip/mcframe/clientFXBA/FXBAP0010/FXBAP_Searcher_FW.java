package mcframe.clientFXBA.FXBAP0010;

import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

import java.util.List;

import javax.swing.JComponent;

import mcframe.clientCore.beans.MCListBeans;
import mcframe.clientCore.beans.MCMessageBox;
import mcframe.clientCore.beans.MCPagingAgent;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.sys.MCFactory;
import mcframe.commonCore.util.MCCollectionUtil;

public class FXBAP_Searcher_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Caller<P, O> {
	/**
	 * コンストラクタです。
	 *
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Searcher_FW(P panel, O operation) {
		super(panel, operation);
	}

	/**
	 * サーバロジック実行前処理を実行します。
	 *
	 *　falseを返した場合はサーバロジックを実行しません。<br>
	 *
	 */
	@Override
	protected boolean beforeExecMain() {
		clearEmptyRowStatus();
		initCaller();
		if (!execConfirm()) {
			return false;
		}
		if (!checkForCall()) {
			return false;
		}
		clear();
		beforeCallParts();
		setupParam();
		beforeCall();

		if (!checkLimitULSize() || !checkInvisibleRowInUpParam()) {
			return false;
		}
		return true;
	}

	/**
	 *
	 * プログレスダイアログを設定します。
	 *
	 * @since     6.4.0
	 */
	@Override
	protected void addProgressPanel() {
		super.addProgressPanelMain();
	}

	/**
	 * プログレスダイアログをキャンセルボタン付きに設定します。
	 */
	@Override
	protected int getProgressType() {
		return MCMessageBox.CANCEL_DIALOG;
	}

	@Override
	protected MCCallBackType callCanceledAction() {
		setModeNoDown();
		moveFocusNoDown();
		showCanceledMsg();
//		showNoDownDataMsg();
		resultNoDataFound();
		return MCCallBackType.SUCCESS;
	}

	@Override
	protected MCCallBackType callDLCanceledAction() {
		setModeNoDown();
		moveFocusNoDown();
		afterCapError();
		return MCCallBackType.SUCCESS;
	}

	@Override
	protected MCCallBackType callAfterAction() {
		if (!isDownParamEmpty()) {
			preAfterCall();
			afterCall();
			afterCallParts();
		}
		return MCCallBackType.SUCCESS;
	}

	@Override
	protected MCCallBackType callPanelUpdateAction() {
		unlockScreen();
		if (!isDownParamEmpty()) {
			show();
			setMode();
			adjustList();
			moveFocus();
			moveFocusForBarcode(); // barcode用のmoveFocus 6.4.0
			showMsg();
			print();
			resultSuccess();
		}
		else {
			setModeNoDown();
			moveFocusNoDown();
			showNoDownDataMsg();
			resultNoDataFound();
		}
		return MCCallBackType.SUCCESS;
	}

	@SuppressWarnings({
			"rawtypes", "unchecked"
	})
	protected void preAfterCall() {

		if (isNewSrch()) {
			return;
		}

		final String typKey = "paging.nontarget";
//		画面のコンテナを電文コンテナにコピーするときの動作設定
//		・キーの優先順
//		[mod.Id].[scr.Id].[mod.Id].[lgc.Id].[ope.Id].paging.nontarget
//		[mod.Id].[scr.Id].paging.nontarget
//		X.paging.nontarget
//		・設定値
//		CLONE_PARAM:CLONEした画面コンテナのMCRowを電文コンテナに設定後、電文対象外項目をクリア
//		CLONE_ALL  :CLONEした画面コンテナのMCRowを電文コンテナに設定
//		SET        :画面コンテナのMCRowを電文コンテナに設定
//		NONE       :コピーしない
//		基本的にMCListブロックの設定だが、MCRowブロックの場合も電文対象外項目クリア設定は有効
		final String typCP = "CLONE_PARAM";
		final String typCA = "CLONE_ALL";
		final String typSA = "SET";
		final String typNO = "NONE";

		//リソース設定を取得
		String typ = panel.getPgmSettingStringNE(panel, null, param().getModuleId(),
				param().getLogicId(), param().getOperationId(), typKey);
		if (FXUCP_DataUtil.isNull(typ)) {
			typ = panel.getPgmSettingStringNE(panel, null, typKey);
		}
		if (FXUCP_DataUtil.isNull(typ)) {
			typ = MCConst.app.getString(MCConst.createKey("FX", typKey), typNO);
		}

		//ページング対象外の電文コンテナを調整しない場合は終了
		if (typNO.equalsIgnoreCase(typ)) {
			return;
		}

		//ページング対象のブロックＩＤ配列作成
		List<FXBAP_PagingParam> pps = getPagingAgentHolder().getPagingParam();
		String[] blkIds = new String[pps.size()];
		for (int j = 0; j < pps.size(); j++) {
			FXBAP_PagingParam pp = pps.get(j);
			blkIds[j] = pp.getTargetBlockId();
		}

		//ブロックを順に調べ、ページング対象外ブロックの場合、画面コンテナを電文コンテナにコピー
		int i = 0;
		while (true) {
			mcframe.commonCore.param.MCContainerDef def = param().getDef()
					.getDefNE(MCDef.toDefId(param(), false, i));
			if (def == null) {
				break;
			}
			MCBlockDef blkDef = def.block();
			if (blkDef == null) {
				i++;
				continue;
			}
			String tgtBlkId = blkDef.toParamString();
			if (!MCCollectionUtil.contains(tgtBlkId, blkIds)) {
				MCContainer defc = getDown(bridge, i);
				MCContainer panelc = panel.getContainer(tgtBlkId);
				//コンテナがMCRowの場合
				if (defc instanceof MCRow && panelc instanceof MCRow) {
					MCRow dr = (MCRow) defc;
					MCRow.copyvalue(dr, (MCRow) panelc);
					//電文対象外項目の値をクリアする
					if (typCP.equalsIgnoreCase(typ)) {
						MCItemDef[] idefs = def.transItems();
						for (String drcol : dr.getConstColumnPathArray()) {
							MCItemDef idef = null;
							for (MCItemDef df : idefs) {
								if (FXUCP_DataUtil.isSame(df.id, drcol)) {
									idef = df;
									break;
								}
							}
							if (idef == null) {
								if (MCDataType.BOOLEAN == dr.getMeta(drcol).type()) {
									dr.setValue(drcol, false);
								}
								else {
									dr.setValue(drcol, null);
								}
							}
						}
					}
				}
				//コンテナがMCListの場合
				else if (defc instanceof MCList && panelc instanceof MCList) {
					MCList dl = (MCList) defc;
					MCList pl = (MCList) panelc;
					if (typSA.equalsIgnoreCase(typ)) {
						dl.setAll(pl);
					}
					else if (typCA.equalsIgnoreCase(typ)) {
						dl.setAll(pl.clone());
					}
					else if (typCP.equalsIgnoreCase(typ)) {
						if (pl.size() < 1) {
							continue;
						}
						dl.setAll(pl.clone());
						MCRow dr = pl.get(0);
						MCItemDef[] idefs = def.transItems();
						for (String drcol : dr.getConstColumnPathArray()) {
							MCItemDef idef = null;
							for (MCItemDef df : idefs) {
								if (FXUCP_DataUtil.isSame(df.id, drcol)) {
									idef = df;
									break;
								}
							}
							if (idef == null) {
								if (MCDataType.BOOLEAN == dr.getMeta(drcol).type()) {
									dl.setValue(drcol, false);
								}
								else {
									dl.setValue(drcol, null);
								}
							}
						}

					}
				}
			}
			i++;
		}
	}

	/**
	 * ロジックが正常終了をして、結果がなかった場合、
	 * 全ての処理が終了した最後に呼び出されるメソッド。
	 */
	protected void resultNoDataFound() {

	}

	/**
	 * 検索後のフォーカス設定を行います。<p>
	 * <font color=red>
	 * このメソッド内でダイアログを表示させる処理を行ってはいけません。
	 * </font>
	 * <p>
	 * デフォルト実装：ページングの「次へ」「前へ」処理の場合、{@link #moveFocusForPrevNext()}を実行する。
	 * </p>
	 * <p>
	 * 画面の実装ではステータス変更処理でフォーカス移動するのが基本なので、<br>
	 * setModeで設定されるフォーカス位置では困る場合のみ実装してください。
	 * </p>
	 */
	@Override
	protected void moveFocus() {
		if (!isNewSrch()) {
			moveFocusForPrevNext();
		}

		// 7.0.1 バーコード対応
		if (panel.isBarcodeMode()) {
			panel.setBarcodeFocus();
		}

	}

	/**
	 * 検索結果がある場合のＧＵＩ部品のモード設定
	 */
	@Override
	protected void setMode() {
		if (!isNewSrch()) {
			return;
		}
		super.setMode();
	}

	/**
	 * 検索結果が存在しない場合のＧＵＩ部品のモード設定
	 */
	protected void setModeNoDown() {
		if (!isNewSrch()) {
			return;
		}
	}

	/**
	 * 検索結果が存在しない場合のフォーカス設定
	 * <P>
	 * デフォルト実装：<br>
	 * 何もしない
	 * </P>
	 */
	protected void moveFocusNoDown() {
	}

	/**
	 * 通信処理で例外が発生した場合の、処理を行う。 特に理由がない限り、例外をthrowする。
	 * <p>
	 * デフォルト実装：<br>
	 * {@link #moveFocusNoDown()}を呼び出す
	 * </p>
	 * @param ex サーバーで発生した例外
	 */
	protected void setFocusMCEx(MCException ex) {
		moveFocusNoDown();
	}

	/**
	 * 通信処理で例外が発生した場合の、処理を行う。 特に理由がない限り、例外をthrowする。
	 * <p>
	 * デフォルト実装：<br>
	 * {@link #setModeMCEx(MCException)} と {@link #setFocusMCEx(MCException)} を呼び出し、
	 * 例外をthrowする
	 * </p>
	 *
	 * @param ex 通信処理で発生した例外
	 */
	@Override
	protected void handleMCEx(MCException ex) {
		setModeMCEx(ex);
		setFocusMCEx(ex);
		throw ex;
	}

	/**
	 * 通信処理で例外が発生した場合の、モード設定を行う。
	 * <p>
	 * デフォルト実装：<br>
	 * {@link #setModeNoDown()}を呼び出す
	 * </P>
	 * @param ex サーバーで発生した例外
	 */
	protected void setModeMCEx(MCException ex) {
		setModeNoDown();
	}

	/**
	 * 検索ロジックの実行を確認するメッセージを表示します。
	 *
	 * @return 検索ロジックを実行する場合はtrue、実行しない場合はfalse
	 */
	protected boolean execConfirm() {
		return isDownBlockChanged() ? panel.confirmRegDataClear() : true;
	}

	/**
	 * 検索結果が存在しなかったときのメッセージを表示します。
	 */
	protected void showNoDownDataMsg() {
		panel.dialog(FXBAP0033);
	}

	/**
	 * 通信を行うためのチェックを行います。
	 * <p>
	 * デフォルト実装：{@link #checkForCallStack(MCMessageList)}を呼び出し、
	 * MCMessageListにメッセージが１件以上ある場合はメッセージダイアログを出し、falseを返す。
	 * それ以外はtrue。ページングの「次へ」「前へ」処理の場合は何もせずtrue。
	 * </p>
	 *
	 * @return 通信可能な場合 true 通信を行わない場合 false
	 */
	@Override
	protected boolean checkForCall() {
		if (!isNewSrch()) {
			return true;
		}
		return super.checkForCall();
	}

	/**
	 * 通信前チェックの前に行いたい処理を記述します。（例：チェックに必要なデフォルト値を入れる）
	 */
	@Override
	protected void initCaller() {
		super.initCaller();

		setScreenAsync(true);

		//ページングエージェントの取得
		IfPagingAgentHolder holder = getPagingAgentHolder();
		if (holder != null && holder.getPagingParam() != null
				&& holder.getPagingParam().size() > 0) {
			_pagingAgent = holder.getPagingAgent(this.getClass());
			if (_pagingAgent != null) {
				_pagingAgent.setCaller(this);
			}
		}
	}

	/**
	 * {@inheritDoc}<p>
	 * ページングの「次へ」「前へ」処理時に、
	 * ページング対象コンテナの変更のみをチェックするようにしています。
	 */
	@SuppressWarnings("rawtypes")
	@Override
	protected boolean isDownBlockChanged() {
		if (isNewSrch()) {
			return super.isDownBlockChanged();
		}
		else {
			IfPagingAgentHolder holder = getPagingAgentHolder();
			List<FXBAP_PagingParam> pps = holder.getPagingParam();
			for (int i = 0; i < pps.size(); i++) {
				String[] ba = pps.get(i).getDispBlockIds();
				for (int bai = 0; bai < ba.length; bai++) {
					MCContainer pc = panel.getContainer(ba[bai]);
					if (pc instanceof MCList) {
						MCList s = (MCList) pc;
						JComponent comp = panel.getComponent(s);
						if (comp != null) {
							if (comp instanceof MCTable) {
								if (panel.isChanged((MCTable<?>) comp)) return true;
							}
							else {
								if (!s.isStatusNone()) return true;
							}
						}
					}
				}
			}
			return false;
		}
	}

	/**
	 * {@inheritDoc}<p>
	 * ページングをする設定の場合、ページングエージェントに処理を委譲します。
	 */
	@SuppressWarnings("rawtypes")
	@Override
	protected void callMain() {
		IfPagingAgentHolder holder = getPagingAgentHolder();

		if (willPaging()) {
			PagingCallTyp typ = holder.getPagingCallTyp();
			List<FXBAP_PagingParam> pps = holder.getPagingParam();

			//ソートポリシーの設定
			for (FXBAP_PagingParam p : pps) {
				MCContainer pc = panel.getContainer(getSortPolicyTarget(p));
				if (pc instanceof MCList) {
					MCList s = (MCList) pc;
					JComponent c = panel.getComponent(s);
					if (c instanceof MCTable) {
						p.setSortPolicy(((MCTable) c).getSortPolicy());
					}
					//カスタマイズ用メソッド呼び出し
					setPagingSortPolicy(p);
				}
			}

			if (typ == PagingCallTyp.NEW) {
				_pagingAgent.callPaging(param(), pps);
			}
			else if (typ == PagingCallTyp.PREV) {
				_befRtn = getPageSizeRtn(pps);
				_befFrom = getPageFrom(pps);
				_pagingAgent.doPrevious(param(), pps);
			}
			else if (typ == PagingCallTyp.NEXT) {
				_befRtn = getPageSizeRtn(pps);
				_befFrom = getPageFrom(pps);
				_pagingAgent.doNext(param(), pps);
			}
		}
		else {
			super.callMain();
		}
	}

	/**
	 * ページングで使用するソートポリシーを保持するテーブルのブロックIDを返します。
	 * @param p ページング情報
	 * @return ブロックID
	 */
	protected String getSortPolicyTarget(FXBAP_PagingParam p) {
		return p.getDispBlockIds()[0];
	}

	/**
	 * ページングキャッシュのソートポリシーを設定します。<p>
	 * 引数pには、{@link #getSortPolicyTarget(FXBAP_PagingParam)}の返す
	 * ブロックIDに対応するテーブルのソートポリシーが設定されています。<br>
	 * 変更したい場合に実装してください。
	 * @param p ページング情報
	 */
	protected void setPagingSortPolicy(FXBAP_PagingParam p) {

	}

	/**
	 * {@inheritDoc}
	 * ページング検索「次へ」「前へ」の場合、ページング対象のデータのみを画面に反映させます。<br>
	 * また、ページングエージェントに結果件数を設定します。<br>
	 */
	@SuppressWarnings({
			"rawtypes", "unchecked"
	})
	@Override
	protected void bridgeShow() {
		IfPagingAgentHolder holder = getPagingAgentHolder();
		if (isNewSrch()) {
			super.bridgeShow();
			if (holder != null && _pagingAgent != null) {
				List<FXBAP_PagingParam> pps = holder.getPagingParam();
				for (int i = 0; i < pps.size(); i++) {
					FXBAP_PagingParam pp = pps.get(i);
					int pidx = pp.getParamBlockIndex(param());
					MCContainer d = getDown(bridge, pidx);
					if (d instanceof MCList) {
						int dsize = ((MCList) d).size();
						_pagingAgent.setPageSizeRtn(pidx, dsize);
					}
				}
			}
		}
		else {
			List<FXBAP_PagingParam> pps = holder.getPagingParam();
			for (int i = 0; i < pps.size(); i++) {
				FXBAP_PagingParam pp = pps.get(i);

				MCContainer pc = panel.getContainer(pps.get(i).getTargetBlockId());
				if (pc instanceof MCList) {
					MCList s = (MCList) pc;
					int pidx = pp.getParamBlockIndex(param());
					MCContainer cd = getDown(bridge, pidx);
					if (cd instanceof MCList) {
						MCList d = (MCList) cd;
						s.setAll(d);
						//受信上限数チェックにより一時的にサイズが0になることがある。
						//結果取得を続行した場合はサイズを修正する必要がある。
						_pagingAgent.setPageSizeRtn(pidx, d.size());
						//受信上限数チェックで結果取得を続行した場合はサイズを修正し、次回のチェックを回避する。
						_pagingAgent.setPageSizeBef(pidx);
					}
				}
			}
		}

	}

	@Override
	protected void afterCapError() {
		if (willPaging()) {
			IfPagingAgentHolder holder = getPagingAgentHolder();
			List<FXBAP_PagingParam> pps = holder.getPagingParam();
			if (pps != null && _pagingAgent != null) {
				for (int i = 0; i < pps.size(); i++) {
					FXBAP_PagingParam pp = pps.get(i);
					int pidx = pp.getParamBlockIndex(param());
					//初回検索のときはnull
					if (_befRtn != null) {
						//結果取得を拒否した場合は結果件数を元に戻す必要がある。
						_pagingAgent.setPageSizeRtn(pidx, _befRtn[i]);
						//結果取得を拒否した場合はfromを元に戻す必要がある。
						_pagingAgent.setFrom(pidx, _befFrom[i]);
					}
				}
			}
		}
		super.afterCapError();
	}

	/**
	 * {@inheritDoc}<p>
	 * ページングの「次へ」「前へ」処理の場合は何もしません。
	 */
	@Override
	protected void clear() {
		if (isNewSrch()) {
			super.clear();
		}
	}

	/**
	 * プログレスダイアログでキャンセルされたときのメッセージを表示します。
	 */
	protected void showCanceledMsg() {

	}

	@Override
	protected MCMessage msgProcessInterruptionByProgressFailure() {
		return new MCMessage(FXBAP0099);
	}

	// -- ページング用（ここから）

	public enum PagingCallTyp {
		NEW, PREV, NEXT
	}

	/**
	 * ページングエージェント（nullの場合はページングしない）
	 */
	protected MCPagingAgent _pagingAgent;

	/**
	 * 次へ、前へ処理開始前の検索結果件数
	 */
	protected int[] _befRtn;

	/**
	 * 次へ、前へ処理開始前の表示開始位置
	 */
	protected int[] _befFrom;

	protected IfPagingAgentHolder getPagingAgentHolder() {
		return panel;
	}

	/**
	 * 前回検索結果の件数を取得します。
	 * @param pps
	 * @return
	 */
	protected int[] getPageSizeRtn(List<FXBAP_PagingParam> pps) {
		int[] rtn = new int[pps.size()];
		for (int i = 0; i < pps.size(); i++) {
			rtn[i] = _pagingAgent.pageSizeRtn(pps.get(i).getParamBlockIndex(param()));
		}
		return rtn;
	}

	/**
	 * 表示開始位置を取得します。
	 * @param pps
	 * @return
	 */
	protected int[] getPageFrom(List<FXBAP_PagingParam> pps) {
		int[] rtn = new int[pps.size()];
		for (int i = 0; i < pps.size(); i++) {
			rtn[i] = _pagingAgent.from(pps.get(i).getParamBlockIndex(param()));
		}
		return rtn;
	}

	/**
	 * ページング時の初回検索またはページング未使用かどうかを判定する。
	 * @return ページング時の初回検索またはページング未使用の場合true
	 */
	protected boolean isNewSrch() {
		IfPagingAgentHolder holder = getPagingAgentHolder();
		return !willPaging() || holder.getPagingCallTyp() == PagingCallTyp.NEW;
	}

	/**
	 * ページングするかどうかを返します。<p>
	 * @return ページングする場合true
	 */
	protected boolean willPaging() {
		IfPagingAgentHolder holder = getPagingAgentHolder();
		return _pagingAgent != null && holder.getPagingParam() != null
				&& holder.getPagingParam().size() > 0
				&& holder.getPagingCallTyp() != null;
	}

	/**
	 * 「次へ」「前へ」処理で実行される、ページング対象選択処理です。<p>
	 * @see #moveFocusForPrevNextImpl(MCTable)
	 */
	@SuppressWarnings("rawtypes")
	protected void moveFocusForPrevNext() {

		IfPagingAgentHolder holder = getPagingAgentHolder();
		List<FXBAP_PagingParam> pps = holder.getPagingParam();
		for (int i = 0; i < pps.size(); i++) {
			String[] ba = pps.get(i).getDispBlockIds();
			for (int bai = 0; bai < ba.length; bai++) {
				String bi = pps.get(i).getDispBlockIds()[bai];
				MCContainer pc = panel.getContainer(bi);
				if (pc instanceof MCList) {
					MCList s = (MCList) pc;
					if (!s.isEmpty()) {

						MCListBeans<?> c = (MCListBeans<?>) panel.getComponent(s);
						if (c instanceof MCTable) {
							moveFocusForPrevNextImpl((MCTable) c);
						}
					}
				}
			}
		}
	}

	/**
	 * {@link #moveFocusForPrevNext()}から実行される選択行変更処理です。<p>
	 * デフォルト実装：ブロックインデックスが最小のテーブルの1行目を選択(フォーカスは移動しない)
	 *
	 * @param c 行選択対象テーブル
	 */
	@SuppressWarnings("rawtypes")
	protected void moveFocusForPrevNextImpl(MCTable c) {
		c.selectRowNoFocus(0);
	}

	/**
	 * 引数のブロックIndexの下り電文コンテナを取得します。
	 * @return 下り電文コンテナ
	 */
	protected MCContainer getDown(O bridge, int blk) {
		return (MCContainer) MCFactory.invoke(bridge, "down", new Class[] {
				int.class
		}, new Integer[] {
				blk
		});
	}
	// -- ページング用（ここまで）
}
