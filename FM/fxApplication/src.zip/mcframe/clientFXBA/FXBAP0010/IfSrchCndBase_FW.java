package mcframe.clientFXBA.FXBAP0010;

import java.util.List;

import mcframe.clientCore.beans.MCTabOrderBeans;
import mcframe.commonCore.lang.MCCalendarDate;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
import mcframe.clientFXUC.FXUCP0070.SrchCndInfo;

/**
 * 入力値設定機能を利用する画面に実装するインタフェースです。
 */
public interface IfSrchCndBase_FW {

	/**
	 * モジュールＩＤを返します。
	 *
	 * @return モジュールＩＤ
	 */
	public String getModuleID();

	/**
	 * スクリーンＩＤを返します。
	 *
	 * @return スクリーンＩＤ
	 */
	public String getScreenID();

	/**
	 * 検索ボタンのボタンアクションを実行します。
	 */
	public void doSrchAction();

	/**
	 * 画面クリア処理を実行します。
	 * 画面クリア処理が実行された場合は true を返します。
	 *
	 * @return 画面クリア処理がキャンセルされた場合は false
	 */
	public boolean screenClear();

	/**
	 * 画面クリア処理を実行します。
	 * 画面クリア処理が実行された場合は true を返します。
	 * シナリオテスト用
	 *
	 * @return 画面クリア処理がキャンセルされた場合は false
	 */
	public boolean screenClearForScenarioTest();

	/**
	 * クライアントの運用日付を返します。
	 *
	 * @param type データ型
	 * @return クライアントの運用日付
	 */
	public <E extends MCCalendarDate<E>> E today(MCDataType type);

	/**
	 * 入力値設定機能を無効にする場合は true を返します。
	 *
	 * @return 入力値設定機能を有効にする場合は false
	 */
	public boolean ignoreSrchCnd();

	/**
	 * 画面の GUI 部品をタブ移動順に格納したリストを返します。
	 *
	 * @return GUI 部品をタブ移動順に格納したリスト
	 */
	public List<MCTabOrderBeans> getTabOrderBeans();

	/**
	 * 入力値設定画面に「枠名」列を表示するかどうか判断します。
	 * 「枠名」列を表示する場合は true を返します。
	 *
	 * @return 「枠名」列を表示しない場合は false
	 */
	public boolean isPanelNameVisibleInSrchCnd();

	/**
	 * 入力値設定に関するパーソナライズ情報を設定します。
	 *
	 * @param info 入力値設定に関するパーソナライズ情報
	 */
	public void _setSrchCndInfo(SrchCndInfo info);

	public void _setSrchCndInfoId(MCResourceLayerType type, String id);

	/**
	 * 画面に適用されている入力値設定に関するパーソナライズ情報を返します。
	 * <p>
	 * 入力値設定に関するパーソナライズ情報が画面に適用されていない場合は null を返します。
	 *
	 * @return 画面に適用されている入力値設定に関するパーソナライズ情報、または null
	 */
	public SrchCndInfo getSrchCndInfo();

	/**
	 * 初期設定対象の入力値設定に関するパーソナライズ情報を返します。
	 * <p>
	 * 初期設定対象のパーソナライズ情報が見つからなかった場合は null を返します。
	 *
	 * @return 入力値設定に関するパーソナライズ情報、または null
	 */
	public SrchCndInfo getInitSrchCndInfo();
	
	/**
	 * メニューに登録されているパーソナライズグループに属する入力値設定に関するパーソナライズ情報を返します。
	 * 
	 * @return 入力値設定に関するパーソナライズ情報、または null
	 */
	public SrchCndInfo getMenuSrchCndInfo();

	/**
	 * 入力値設定に関するパーソナライズ情報のリストを設定します。
	 *
	 * @return 入力値設定に関するパーソナライズ情報のリスト
	 */
	public void _setSrchCndInfoList(List<SrchCndInfo> list);

	/**
	 * 入力値設定に関するパーソナライズ情報のリストを返します。
	 *
	 * @return 入力値設定に関するパーソナライズ情報のリスト
	 */
	public List<SrchCndInfo> getSrchCndInfoList();

	/**
	 * 入力値設定に関するパーソナライズ情報のリストを返します。
	 * バーコード用の設定を含まない
	 *
	 * @return 入力値設定に関するパーソナライズ情報のリスト
	 */
	public List<SrchCndInfo> getSrchCndInfoListWithoutBarcode();


	/**
	 * 入力値設定に関するパーソナライズ情報を画面に設定します。
	 *
	 * @param 入力値設定に関するパーソナライズ情報
	 * @return メッセージ
	 */
	public MCMessage _applySrchCndInfo(SrchCndInfo info);
}