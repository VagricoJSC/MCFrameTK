package mcframe.clientFXBA.FXBAP0010;

import java.awt.Component;
import java.util.List;

import mcframe.clientCore.beans.MCBeansUtil;
import mcframe.clientCore.beans.MCButton;
import mcframe.clientCore.beans.MCPanel;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientFXUC.FXUCP0030.IfToolbarBeansHolder;

public interface IfToolbarItem_FW {

	/**
	 *
	 * ツールバーのitemインタフェース。
	 * このメソッドがツールバー作成時に呼ばれる。
	 */
	public void toolbarItemsPersonalLink(MCRootPanel _mainPanel, List<IfToolbarBeansHolder> list);
	
	/**
	 * 対象のボタンを取得する
	 */
	default MCButton getTargetToolbarButton(List<IfToolbarBeansHolder> list, String target) {

		for (IfToolbarBeansHolder h : list) {
			if (h.comp() instanceof MCButton) {
				MCButton b = (MCButton) h.comp();
				if (b.getName().contains(target)) {
					return b;
				}
			}
			else if (h.comp() instanceof MCPanel) {
				for (MCButton b : 
					MCBeansUtil.getAllComponents(MCButton.class, (MCPanel)h.comp())) {
					if (b.getName().contains(target)) {
						return b;
					}
				}
			}
		}
		return null;
	}
	/**
	 * 対象のパネルを取得する
	 */
	default MCPanel getTargetToolbarPanel(List<IfToolbarBeansHolder> list, String prefix) {

		for (IfToolbarBeansHolder h : list) {
			if (h.comp() instanceof MCPanel) {
				if (prefix.startsWith(h.comp().getName())) {
					return (MCPanel)h.comp();
				}
			}
		}
		return null;
	}
	/**
	 *  画面が開いた後に呼ばれる
	 */
	public void afterOpen();

	/**
	 *  画面が閉じる前に呼ばれる
	 * @return trueを返す。
	 */
	public boolean beforeClose();
}
