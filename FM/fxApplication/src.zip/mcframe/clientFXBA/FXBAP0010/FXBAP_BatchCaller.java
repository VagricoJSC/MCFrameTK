package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.annotation.EI;

@EI
public class FXBAP_BatchCaller<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge> extends
FXBAP_BatchCaller_FW<P, O>{

	public FXBAP_BatchCaller(P panel, O bridge) {
		super(panel, bridge);
	}
	

}
