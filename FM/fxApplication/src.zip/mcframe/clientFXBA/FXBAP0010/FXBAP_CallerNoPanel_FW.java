package mcframe.clientFXBA.FXBAP0010;

import java.util.*;

import mcframe.clientCore.beans.*;
import mcframe.clientCore.requester.MCCaller;
import mcframe.commonCore.container.*;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonCore.param.MCParam;

import mcframe.commonCore.lang.MCNumber;

/**
 * MCRootPanelがなくても使えるCaller
 */
public class FXBAP_CallerNoPanel_FW extends MCCaller {
	/**
	 * サーバ通信用のCaller<br>
	 * 親クラスとは違いexecでErrorHandlerを使用している
	 */

	protected MCErrorHandler _eh;

	public FXBAP_CallerNoPanel_FW(MCParam p) {
		super(p);
	}
	/**
	 * 委譲クラス
	 */
	protected FXBAP_CallerDelegate _delegate = new FXBAP_CallerDelegate();
	/**
	 * 電文上限数の設定をします。<p>
	 * デフォルト実装：
	 * AppClientリソースの受信上限数設定を反映する。
	 */
	protected void setLimitParamSize() {
		setLimitDLSize();
	}

	/**
	 * 上り電文上限数の設定をします。
	 * <p>
	 * デフォルト実装：<br>
	 * 次のAppClientリソースを読み込み、上限数を設定します。<br>
	 * [サブモジュールＩＤ].[画面ＩＤ].[通信処理クラス].limitUL<br>
	 * 設定値は、ConfigClientリソースの以下の設定よりも優先されます。<br>
	 * net.request.limitSize<br>
	 * リソース値が未設定または0の場合は何もしません。<br>
	 */
	protected void setLimitULSize() {
		MCNumber rv = _delegate.getResourceLimitSize("UL", this);
		if (!rv.isZero()) {
			param().setLimitULSize(rv);
		}
	}
	/**
	 * 下り電文上限数の設定をします。
	 * <p>
	 * デフォルト実装：<br>
	 * 次のAppClientリソースを読み込み、上限数を設定します。<br>
	 * [サブモジュールＩＤ].[画面ＩＤ].[通信処理クラス].limitDL<br>
	 * 設定値は、ConfigClientリソースの以下の設定よりも優先されます。<br>
	 * net.response.limitSize<br>
	 * リソース値が0の場合は、未設定にします。<br>
	 * リソース値が未設定の場合は何もしません。<br>
	 */
	protected void setLimitDLSize() {
		MCNumber rv = _delegate.getResourceLimitSize("DL", this);
		if (rv.isZero()) {
			param().setLimitDLSize(null);
		}
		else{
			param().setLimitDLSize(rv);
		}
	}
	/**
	 * 下り電文容量のチェックを行います。処理を続行する場合は、 trueを返し、処理を中断する場合はfalseを返します。
	 * <P>
	 * デフォルト実装：
	 * </P>
	 * 
	 * @return 処理続行の場合true。処理中断の場合false
	 */
	protected boolean checkCap() {
		return _delegate.checkCapTerminate(param());
	}
	/**
	 * 受信上限数チェックでキャンセルした場合の処理を実装します。<p>
	 * デフォルト実装：何もしない。
	 */
	protected void capDLCanceled() {
		
	}
	
	@Override
	public void exec() {
		setLimitParamSize();
		call(_eh);
		if (!checkCap()) {
			capDLCanceled();
			return;
		}
		setGUIIndexAtDownParam();
		showDownMsg();
		showEndMsg();
	}

	protected void showDownMsg() {
		if (hasMessage()) {
			getPanel().message(getMessages());
		}
	}

	protected boolean hasMessage() {
		return getMessages().size() != 0;
	}

	protected MCMessageList getMessages() {
		return param().getMessageParam().getMessage();
	}

	protected void showEndMsg() {

	}

	protected List<MCContainer> getDownParams() {
		return param().getContainerParam().down();
	}

	protected List<MCContainer> getUpParams() {
		return param().getContainerParam().up();
	}

	// CPP_Callerからコピー（ここから）
	/**
	 * 下り電文に対応する上り電文のGUIIndexをコピーする
	 */
	protected void setGUIIndexAtDownParam() {
		for (MCContainer cont : getDownParams()) {
			if (cont instanceof MCRow) {
				MCRow r = (MCRow) cont;
				int paramIdx = r.getParamIndex();
				if (0 <= paramIdx && paramIdx < getUpParams().size()) {

					MCContainer upCont = getUpParams().get(paramIdx);
					if (upCont instanceof MCRow) {
						r.setGUIIndex(((MCRow) upCont).getGUIIndex());
					}
					else if (upCont instanceof MCList) {
						MCList<?> upList = (MCList<?>) upCont;
						if (r.getParamRowIndex() < upList.size()) {
							int pRowIdx = r.getParamRowIndex();
							if (0 <= pRowIdx) {
								r.setGUIIndex(upList.get(pRowIdx).getGUIIndex());
							}
						}
					}
				}
			}
			else if (cont instanceof MCList) {
				MCList<MCRow> list = (MCList) cont;
				for (MCRow r : list) {
					int paramIdx = r.getParamIndex();
					if (0 <= paramIdx && paramIdx < getUpParams().size()) {
						MCContainer upCont = getUpParams().get(paramIdx);
						if (upCont instanceof MCRow) {
							r.setGUIIndex(((MCRow) upCont).getGUIIndex());
						}
						else if (upCont instanceof MCList) {
							MCList<?> upList = (MCList<?>) upCont;
							if (r.getParamRowIndex() < upList.size()) {
								int pRowIdx = r.getParamRowIndex();
								if (0 <= pRowIdx) {
									r.setGUIIndex(upList.get(pRowIdx).getGUIIndex());
								}
							}
						}
					}
				}
			}
		}
	}

	// CPP_Callerからコピー（ここまで）

	private MCRootPanel _panel;

	protected MCRootPanel getPanel() {
		if (_panel == null) {
			_panel = new MCRootPanelImple();
		}
		return _panel;
	}

	@SuppressWarnings("serial")
	public class MCRootPanelImple extends MCRootPanel {
		public MCRootPanelImple() {
			super();
		}

		@Override
		public String getModuleID() {
			return null;
		}

		@Override
		public String getScreenID() {
			return null;
		}

		@Override
		public String getSubmoduleID() {
			return null;
		}
	}

}
