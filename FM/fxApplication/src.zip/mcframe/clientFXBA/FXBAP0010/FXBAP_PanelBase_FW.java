package mcframe.clientFXBA.FXBAP0010;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase.*;

import mcframe.clientFXUC.FXUCP0040.OpenScreenParamR;
import java.util.Arrays;
import java.util.EventListener;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

import mcframe.clientCore.MCSingleStartup;
import mcframe.clientCore.beans.layout.MCAutoLayout;
import mcframe.clientCore.beans.layout.MCLayout;
import mcframe.clientCore.beans.layout.MCLayoutLocationR;
import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListConfig;
import mcframe.clientCore.beans.list.MCListPutter;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.resource.MCPersonalizeGroupInfo;
import mcframe.clientCore.container.MCRowListener;
import mcframe.clientCore.container.MCRowStatusListener;
import mcframe.clientCore.mining.IfMCMiningBase;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.sys.MCSys;
import mcframe.clientFXBA.FXBAP0040.FXBAP_ISPanelInfo;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientFXBA.FXBAP0110.FXBAP_ListListener;
import mcframe.clientFXUB.FXUBP0000.IfParts;
import mcframe.clientFXUB.FXUBP0000.IfPartsBase;
import mcframe.clientFXUC.FXUCP0030.IfToolBar;
import mcframe.clientFXUC.FXUCP0030.IfToolbarBeansHolder;
import mcframe.clientFXUC.FXUCP0030.FXUCP_GeneralLayout;
import mcframe.clientFXUC.FXUCP0030.IfHeaderBar;
import mcframe.clientFXUC.FXUCP0040.FXUCP_ToolBarUtil;
import mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil;
import mcframe.clientFXUC.FXUCP0070.SrchCndR;
import mcframe.clientFXUC.FXUCP0070.SrchCndInfo;
import mcframe.clientFXUC.FXUCP0130.FXUCP_Paging;
import mcframe.clientFXUC.FXUCP0170.FXUCP_ValidaterUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.param.MCParam;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
import mcframe.commonCore.sys.MCFactory;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.commonFX.constant.FX_Const;
import mcframe.commonFX.notice.FX_Msg;
import mcframe.commonFXUC.FXUCC0020.FXUCC_ResourceUtil;
import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_PanelBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_PanelBase_FW extends FXBAP_PanelBase_FW_A
		implements IfToolBar, IfHeaderBar, IfSrchCndBase, IfPagingAgentHolder, IfMCMiningBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected FXBAP_ToolbarItem _toolbarItem;

	/** リソースタイプです。 検索枠展開のモードを表します。*/
	private final String _expandunitKey = getModuleID() + "." + getScreenID() + ".expandunit.mode";

	/** 検索枠展開モードです。デフォルトはfalse（画面実装のとおり動く） */
	private boolean _expandunitMode = MCConst.beans.getBoolean(_expandunitKey, false);

	/** 画面起動時に既存画面を再作成するかどうかのフラグです。デフォルトはtrue（再作成する） */
	private static final boolean OPEN_PANEL_RECREATE_SCREEN = MCConst.app.getBoolean("FX.FXBAP0010.open_panel_recreate_screen", true);

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_PanelBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// 画面処理メソッドはこれより下に定義してください
	// ＜目次＞
	// トレース用
	// ユーティリティ
	// Listからの抽出
	// メッセージ関連
	// コンテナコピー
	// テーブル関連
	// ツリー関連
	// 画面の初期化関連
	// 入力補助画面関連のメソッド
	// 画面クリア関連
	// ツールバー関連

	// トレース用(START)
	protected void initTrace(MCRootPanel panel, String methodName) {
		MCLog.write(FXBAP0088, methodName, panel.getClass().getName());
	}

	// トレース用( END )

	// ユーティリティ(START) ====================================
	/**
	 * パネル内の全ての入力項目を入力できないようにします（＝固めます）。
	 * <P>
	 * <li>パネルの中にテーブルがある場合は、全てのカラムのモードをを {@link MCMode#READ_ONLY}にします。
	 * 但し、モードが{@link MCMode#INVISIBLE}または{@link MCMode#DISABLE}の
	 * カラムに対しては何もしません。
	 * </li>
	 * <li>パネルの中にある全ての {@link MCRowBeans} のモードを {@link MCMode#READ_ONLY}にします
	 * (但しボタンは{@link MCMode#DISABLE}にします)。
	 * 但し、モードが{@link MCMode#INVISIBLE}または{@link MCMode#DISABLE}の
	 * オブジェクトに対しては何もしません。また、{@link MCPanel} {@link MCRootPanel} {@link MCTabbedPane}に
	 * 対しては何もしません。
	 * </li>
	 * </P>
	 */
	protected void setFix(MCPanel... panels) {
		if (panels == null || panels.length == 0) {
			return;
		}
		for (MCPanel panel : panels) {
			MCModeBeans[] modeBeans;
			modeBeans = MCBeansUtil.getAllComponents(MCModeBeans.class, panel);
			if (modeBeans != null) {
				for (MCModeBeans bean : modeBeans) {
					if (bean instanceof MCPanel) {
						continue;
					}
					else if (bean instanceof MCRootPanel) {
						continue;
					}
					else if (bean instanceof MCTabbedPane) {
						continue;
					}
					else if (bean instanceof MCTable) {
						MCTable<?> tbl = (MCTable<?>) bean;
						if (tbl != tbl.getBaseTable()) {
							continue;
						}
						for (MCColumnConfig conf : tbl.getColumnConfigs()) {
							if (MCMode.DISABLE == conf.getMode()
									|| MCMode.INVISIBLE == conf.getMode()) {
								// 何もしない
							}
							else {
								conf.setMode(MCMode.READ_ONLY);
							}
						}
					}
					else if (bean instanceof MCLabel) {
						MCLabel lbl = (MCLabel) bean;
						Component comp = lbl.getLabelFor();
						if (comp instanceof MCModeBeans) {
							// MCModeBeansが紐づいているラベルの場合は、
							// MCModeBeansが変化したときにラベルの設定が
							// 変わるので何もしない
							continue;
						}
					}
					else if (bean instanceof MCButton) {
						if (MCMode.INVISIBLE == bean.getMode()) {
							// 何もしない
						}
						else {
							bean.setMode(MCMode.DISABLE);
						}
					}
					else {
						if (MCMode.DISABLE == bean.getMode()
								|| MCMode.INVISIBLE == bean.getMode()) {
							// 何もしない
						}
						else {
							bean.setMode(MCMode.READ_ONLY);
						}
					}
				}
			}
		}
	}

	/**
	 * パネル内に存在するMCModeBeans（含む埋込画面の中の物）に
	 * デフォルトのモードを設定する<br>
	 * デフォルトのモードはgetDefaultModeで取得できたモード
	 *
	 * @see #getDefaultMode(MCModeBeans)
	 * @param panels デフォルトモードを設定する対象のMCModeBeans
	 */
	protected void setDefaultMode(MCPanel... panels) {
		if (panels == null || panels.length == 0) {
			return;
		}
		for (MCPanel panel : panels) {
			MCModeBeans[] modeBeans;
			modeBeans = MCBeansUtil.getAllComponents(MCModeBeans.class, panel);
			if (modeBeans != null) {
				for (MCModeBeans bean : modeBeans) {
					if (bean instanceof MCPanel) {
						continue;
					}
					else if (bean instanceof MCRootPanel) {
						continue;
					}
					else if (bean instanceof MCTabbedPane) {
						continue;
					}
					else if (bean instanceof MCTable) {
						MCTable<?> tbl = (MCTable<?>) bean;
						if (tbl != tbl.getBaseTable()) {
							continue;
						}
						for (MCColumnConfig conf : tbl.getColumnConfigs()) {
							setDefaultMode(conf);
						}
					}
					else if (bean instanceof MCLabel) {
						MCLabel lbl = (MCLabel) bean;
						Component comp = lbl.getLabelFor();
						if (comp instanceof MCModeBeans) {
							// MCModeBeansが紐づいているラベルの場合は、
							// MCModeBeansが変化したときにラベルの設定が
							// 変わるので何もしない
							continue;
						}
					}
					else if (bean instanceof MCButton) {
						setDefaultMode(bean);
					}
					else {
						setDefaultMode(bean);
					}
				}
			}
		}
	}

	/**
	 * 部品から最下層の画面までの階層を格納するフィールド
	 *
	 * @deprecated
	 */
	@Deprecated
	protected MCRootPanel[] _layerList;

	/**
	 * 最下層から本画面までの階層を格納するリストを返す<br>
	 * 最下層から順番（最下層＞埋め込み画面１＞埋め込み画面２･･･）に格納されたリスト
	 *
	 * @return 最下層から本画面までの階層を格納するリスト
	 */
	protected MCRootPanel[] getPanelLayerList() {
		if (_layerList != null) {
			return _layerList;
		}
		_layerList = getPanelLayerList(this);

		return _layerList;

	}

	/**
	 * 最下層から本画面までの階層を格納するリストを返す<br>
	 * 最下層から順番（最下層＞埋め込み画面１＞埋め込み画面２･･･）に格納されたリスト
	 *
	 * @return 最下層から本画面までの階層を格納するリスト
	 */
	protected MCRootPanel[] getPanelLayerList(MCRootPanel p) {
		MCRootPanel[] layerList = MCBeansUtil.getRootPanelLayer(p);
		MCCollectionUtil.reverse(layerList);
		return layerList;
	}

	/**
	 * MCModeBeansにデフォルトのモードを設定する<br>
	 * デフォルトのモードはgetDefaultModeで取得できたモード
	 *
	 * @see getDefaultMode
	 * @param mb デフォルトモードを設定する対象のMCModeBeans
	 */
	protected void setDefaultMode(MCModeBeans mb) {

		MCMode def = getDefaultMode(mb);
		if (def != null) {
			mb.setMode(def);
		}
	}

	/**
	 * MCModeBeansからデフォルトのモードを取得する<br>
	 * 最下層＞第二階層＞...＞最上位の埋め込み画面の優先順位で設定されたステータスでのモードが採用される
	 *
	 * @return 引数のMCModeBeansのデフォルトのモード
	 */
	protected MCMode getDefaultMode(MCModeBeans mb) {
		MCRootPanel p = mb.getRootPanel();
		return getDefaultMode(mb, getPanelLayerList(p));

	}

	/**
	 * rowの指定されたカラム以外の項目をクリアする
	 *
	 * @param row クリア対象のrow
	 * @param cols クリアしないカラム名
	 */
	public void clearRowExcept(MCRow row, String... cols) {
		List<String> list = new ArrayList<>(Arrays.asList(cols));
		clearRowExcept(row, list, "");
	}

	/**
	 * 事前条件 path != null
	 * @deprecated 代替として {@link #clearRowExcept(MCRow, String...)}を使用してください。
	 * （共通親クラスのみ使用可能）
	 */
	@Deprecated
	public void clearRowExcept(MCRow row, List<String> cols, String path) {
		if (cols.size() == 0) {
			row.clear();
			return;
		}
		String[] all = row.getNameArray();
		String dot = path.equals("") ? "" : ".";

		for (String column : all) {
			if (cols.contains(path + dot + column)) {
				cols.remove(column);
			}
			else {
				MCMeta m = row.getMeta(column);
				if (MCDataType.BOOLEAN == m.type()) {
					row.setBoolean(column, false);
				}
				else if (MCDataType.ROW == m.type()) {
					String p = MCRow.createColumnPath(path, column);
					clearRowExcept(row.getInnerRow(column), cols, p);
				}
				else {
					// ここではカラム名の妥当性はチェックしないのでsetValueEx
					// は使わない。
					row.setValue(column, null);
				}
			}
		}

		// クリアした結果が空の場合、rowをクリアする
		if (row.isEmpty()) {
			row.clear();
		}
	}

	/**
	 * rowのキー以外の項目をクリアする
	 *
	 * @param row クリア対象のrow
	 */
	public void clearRowExceptKey(MCConstRow row) {
		String[] keys = row.getKeys().toArray(new String[0]);
		clearRowExcept(row, keys);
	}

	/**
	 * RootRowのキー以外の項目をクリアする
	 *
	 * @param row クリア対象のrow
	 */
	public void clearRootRowExceptKey(MCRow row) {
		MCRow root = row.getRootRow();
		if (root instanceof MCConstRow) {
			clearRowExceptKey((MCConstRow) root);
		}
		else {
			row.clearAll();
			row.setStatus(MCRow.GUICREATE);
		}
	}

	/**
	 * ベーステーブルの指定行のrowのキー以外の項目をクリアする
	 *
	 * @param table クリア対象の行を持つテーブル
	 * @param index クリア対象の行
	 */
	public void clearBaseRowExceptKey(MCTable<?> table, int index) {

		mcframe.clientCore.container.MCConstRow row = table.getBaseTable().getRow(index);
		clearRowExceptKey(row);
	}

	/**
	 * 指定されたテーブルセルの値の文字列表現を返します。
	 * テーブルセルにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。<p>
	 * テーブルセルにフォーマット指定がなく、値が null の場合は "null" を返します。
	 *
	 * @param column テーブルカラム
	 * @param index 行のインデックス値
	 * @return テーブルセルの値の文字列表現
	 */
	public String toString(MCColumnConfig column, int index) {
		if (column == null) {
			return null;
		}

		String v = toStringImpl(column, index);
		return v != null ? v : String.valueOf(v);
	}

	/**
	 * 指定されたテーブルセルの値の文字列表現を返します。
	 * テーブルセルにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。<p>
	 * テーブルセルにフォーマット指定がなく、値が null の場合は "null" になります。
	 *
	 * @param index 行のインデックス値
	 * @param columns テーブルカラムの配列
	 * @return テーブルセルの値の文字列表現の配列
	 */
	public String[] toString(int index, MCColumnConfig... columns) {
		if (columns == null) {
			return null;
		}

		String[] a = new String[columns.length];
		for (int i = 0; i < columns.length; i++) {
			a[i] = toString(columns[i], index);
		}
		return a;
	}

	/**
	 * 指定されたテーブルセルの値の文字列表現を返します。
	 * テーブルセルにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。<p>
	 * メッセージ用名称と値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 *
	 * @param column テーブルカラム
	 * @param index 行のインデックス値
	 * @return テーブルセルの値の文字列表現
	 */
	public String toStringWithMsgLabel(MCColumnConfig column, int index) {
		String m = null;
		String v = null;
		if (column != null) {
			m = column.getMessageByLocale();
			v = toStringImpl(column, index);
		}
		return FXUCP_ValidaterUtil.toStringWithMsgLabel(m, v);
	}

	/**
	 * 指定されたテーブルセルの値の文字列表現を返します。
	 * テーブルセルにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。
	 *
	 * @param column テーブルカラム
	 * @param index 行のインデックス値
	 * @return テーブルセルの値の文字列表現
	 */
	protected String toStringImpl(MCColumnConfig column, int index) {
		if (column == null) {
			return null;
		}

		MCDataType y = column.getDataType();
		Comparable<?> v = column.getValue(index);

		if (MCDataType.DATE.equals(y)) {
			return column.getDateFormat(index).doOutputFormat((MCDate) v);
		}
		if (MCDataType.TIMESTAMP.equals(y)) {
			return column.getTimestampFormat(index).doOutputFormat((MCTimestamp) v);
		}
		if (MCDataType.NUMBER.equals(y)) {
			return column.getNumberFormat(index).doInputFormat((MCNumber) v,
					column.getScale(index));
		}

		return v != null ? v.toString() : null;
	}

	/**
	 * 指定されたテーブルセルの値の文字列表現を返します。
	 * テーブルセルにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。<p>
	 * メッセージ用名称と値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 *
	 * @param index 行のインデックス値
	 * @param columns テーブルカラムの配列
	 * @return テーブルセルの値の文字列表現の配列
	 */
	public String[] toStringWithMsgLabel(int index, MCColumnConfig... columns) {
		if (columns == null) {
			return new String[0];
		}

		String[] a = new String[columns.length];
		for (int i = 0; i < columns.length; i++) {
			a[i] = toStringWithMsgLabel(columns[i], index);
		}
		return a;
	}

	/**
	 * フィールドの値の文字列表現を返します。
	 * フィールドにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。
	 *
	 * @param compo フィールド
	 * @return フィールドの値の文字列表現
	 */
	public String toString(MCRowBeans compo) {
		if (compo == null) {
			return null;
		}

		if (compo instanceof MCTextField) {
			return toString((MCTextField) compo);
		}
		if (compo instanceof MCTextComboBox) {
			return toString((MCTextComboBox) compo);
		}
		if (compo instanceof MCCalendarField<?>) {
			return toString((MCCalendarField<?>) compo);
		}
		if (compo instanceof MCCalendarComboBox<?>) {
			return toString((MCCalendarComboBox<?>) compo);
		}
		if (compo instanceof MCNumberField) {
			return toString((MCNumberField) compo);
		}
		if (compo instanceof MCNumberComboBox) {
			return toString((MCNumberComboBox) compo);
		}

		Comparable<?> v = compo.getViewValue();
		return v != null ? v.toString() : null;
	}

	/**
	 * テキストフィールドの値の文字列表現を返します。
	 *
	 * @param compo テキストフィールド
	 * @return テキストフィールドの値の文字列表現
	 */
	protected String toString(MCTextField compo) {
		return compo != null ? compo.getValue() : null;
	}

	/**
	 * テキストコンボボックスの値の文字列表現を返します。
	 *
	 * @param compo テキストコンボボックス
	 * @return テキストコンボボックスの値の文字列表現
	 */
	protected String toString(MCTextComboBox compo) {
		return compo != null ? compo.getValue() : null;
	}

	/**
	 * 数値フィールドの値の文字列表現を返します。
	 * 数値フィールドに設定されているフォーマットで整形した文字列を返します。
	 *
	 * @param compo 数値フィールド
	 * @return 数値フィールドの値の文字列表現
	 */
	protected String toString(MCNumberField compo) {
		return compo != null ? compo.getNumberFormat().doInputFormat(compo.getValue(),
				compo.getScale()) : null;
	}

	/**
	 * 数値コンボボックスの値の文字列表現を返します。
	 * 数値コンボボックスに設定されているフォーマットで整形した文字列を返します。
	 *
	 * @param compo 数値コンボボックス
	 * @return 数値コンボボックスの値の文字列表現
	 */
	protected String toString(MCNumberComboBox compo) {
		return compo != null ? compo.getNumberFormat().doInputFormat(compo.getValue(),
				compo.getScale()) : null;
	}

	/**
	 * 日付フィールドの値の文字列表現を返します。
	 * 日付フィールドに設定されているフォーマットで整形した文字列を返します。
	 *
	 * @param compo 日付フィールド
	 * @return 日付フィールドの値の文字列表現
	 */
	protected String toString(MCCalendarField<?> compo) {
		return compo != null ? compo.doFormat(compo.getValue()) : null;
	}

	/**
	 * 日付コンボボックスの値の文字列表現を返します。
	 * 日付コンボボックスに設定されているフォーマットで整形した文字列を返します。
	 *
	 * @param compo 日付コンボボックス
	 * @return 日付コンボボックスの値の文字列表現
	 */
	protected String toString(MCCalendarComboBox<?> compo) {
		return compo != null ? compo.doFormat(compo.getValue()) : null;
	}

	/**
	 * フィールドの値の文字列表現を返します。
	 * フィールドにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。
	 *
	 * @param compos フィールドの配列
	 * @return フィールドの値の文字列表現の配列
	 */
	public String[] toString(MCRowBeans... compos) {
		if (compos == null) {
			return new String[0];
		}

		String[] a = new String[compos.length];
		for (int i = 0; i < compos.length; i++) {
			a[i] = toString(compos[i]);
		}
		return a;
	}

	/**
	 * フィールドの値の文字列表現を返します。
	 * フィールドにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。<p>
	 * メッセージ用名称と値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 *
	 * @param compo フィールド
	 * @return フィールドの値の文字列表現
	 */
	public String toStringWithMsgLabel(MCRowBeans compo) {
		String m = null;
		String v = null;
		if (compo != null) {
			m = compo.getMessageByLocale();
			v = toString(compo);
		}
		return FXUCP_ValidaterUtil.toStringWithMsgLabel(m, v);
	}

	/**
	 * フィールドの値の文字列表現を返します。
	 * フィールドにフォーマットが設定されている場合は、フォーマットで整形した文字列を返します。<p>
	 * メッセージ用名称と値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 *
	 * @param compos フィールドの配列
	 * @return フィールドの値の文字列表現の配列
	 */
	public String[] toStringWithMsgLabel(MCRowBeans... compos) {
		if (compos == null) {
			return new String[0];
		}

		String[] a = new String[compos.length];
		for (int i = 0; i < compos.length; i++) {
			a[i] = toStringWithMsgLabel(compos[i]);
		}
		return a;
	}

	/**
	 * テーブルサイズ変更を実行します。
	 */
	public void tableSizeChange() {
		MCLayouter.tableSizeChange(this, this);
	}

	/**
	 * インフラで提供されているデフォルトのisChangedメソッドです。
	 *
	 * @param check
	 * @return
	 */
	public boolean isChangedDefault(boolean check) {
		return super.isChanged(check);
	}

	/**
	 * 変更があったかどうかをチェックします。
	 * <P>
	 * インフラのデフォルトのisChangedメソッドとは、以下の通り、MCTableに関する isChangedの判定が異なります。
	 * <li>インフラ：テーブルの行ステータスのみで判断</li>
	 * <li>本メソッド：テーブルは、すべてのカラムがREAD_ONLY または DISABLEの場合は、テーブルの行ステータスにかかわらず、
	 * 「変更なし」と判断。MCRowBeansかつMCModeBeansのものでREAD_ONLY または DISABLEの場合は、行ステータスにかかわらず
	 * 「変更なし」と判断。</li>
	 * </P>
	 */
	@Override
	public boolean isChanged(boolean check) {
		return (check && !isValueCheck()) ? false : isChanged(this, check);
	}

	/**
	 * 変更があったかどうかをチェックします。
	 * <P>
	 * インフラのデフォルトのisChangedメソッドとは、以下の通り、MCTableに関する isChangedの判定が異なります。
	 * <li>インフラ：テーブルの行ステータスのみで判断</li>
	 * <li>本メソッド：テーブルは、すべてのカラムがREAD_ONLY または DISABLEの場合は、テーブルの行ステータスにかかわらず、
	 * 「変更なし」と判断。MCRowBeansかつMCModeBeansのものでREAD_ONLY または DISABLEの場合は、行ステータスにかかわらず
	 * 「変更なし」と判断。</li>
	 * </P>
	 */
	public boolean isChanged(Container cont, boolean check) {
		// メモ：更新直後では、行ステータスは表示するが、閉じる時の確認などはしてほしくない。
		if (cont != null) {
			Component[] compos = cont.getComponents();
			if (compos != null && compos.length != 0) {
				HashSet<MCContainer> set = new HashSet<>();
				for (Component c : compos) {
					debugIsChanged(c, 429, null);
				}
				for (Component c : compos) {
					if (c instanceof MCRowBeans) {
						// インフラの実装と大きく違うところ（ここから）
						if (c instanceof MCModeBeans) {
							MCModeBeans modeBeans = (MCModeBeans) c;
							if (MCMode.DISABLE == modeBeans.getMode()
									|| MCMode.READ_ONLY == modeBeans.getMode()
									|| MCMode.INVISIBLE == modeBeans.getMode()) {
								debugIsChanged(c, 436, false);
								continue;
							}
						}
						// インフラの実装と大きく違うところ（ここまで）
						MCRow r = ((MCRowBeans) c).getBaseRow();
						if (r != null) {
							set.add(r);
						}
					}
					// インフラの実装と大きく違うところ（ここから）
					else if (c instanceof MCFixedColumnTable) {
						continue;
					}
					else if (c instanceof MCTable) {
						boolean ret = isChanged((MCTable<?>) c);
						debugIsChanged(c, 448, ret);
						if (ret) {
							return true;
						}
						continue;
					}
					// インフラの実装と大きく違うところ（ここまで）
					else if (c instanceof MCListBeans) {
						MCList<?> dataset = ((MCListBeans<?>) c).getList();
						if (dataset != null) {
							set.add(dataset);
						}
					}
					// インフラの実装と大きく違うところ（ここから）
					else if (c instanceof FXBAP_PanelBase) {
						FXBAP_PanelBase p = (FXBAP_PanelBase) c;
						if (p.isChanged()) {
							debugIsChanged(c, 438, true);
							return true;
						}
					}
					else if (c instanceof MCBlockBeans) {
						MCBlockBeans b = (MCBlockBeans) c;
						if (!b.isValueCheck()) {
							// チェック不要な場合
							debugIsChanged(c, 471, false);
							continue;
						}
						if (isChanged((Container) c, check)) {
							return true;
						}
					}
					// インフラの実装と大きく違うところ（ここまで）
					else if (c instanceof Container) {
						if (isChanged((Container) c, check)) {
							debugIsChanged(c, 171, true);
							return true;
						}
					}
				}
				Iterator<MCContainer> i = set.iterator();
				while (i.hasNext()) {
					MCContainer c = i.next();
					if (!c.isStatusNone()) {
						debugIsChanged(c, 181, true);
						return true;
					}
					debugIsChanged(c, 499, false);
				}
			}
			debugIsChanged(cont, 500, false);
			return false;
		}
		debugIsChanged(cont, 503, false);
		return false;
	}

	/**
	 * isChangedの処理が意図した動きになっているかを確認するためのトレースログ
	 *
	 * @deprecated デバッグ用
	 */
	@Deprecated
	private void debugIsChanged(Object c, int id, Boolean ret) {
		// メモ：ログの見方
		// isChangedがfalseで終わる場合、nullに対応するfalseが必ずあるはず。
		// （ない場合は、途中で検索が意図せず終了してしまっている）
		String objNm;
		if (c instanceof Container) {
			objNm = ((Container) c).getName();
		}
		else if (c instanceof MCContainer) {
			objNm = "MCContainer";
		}
		else {
			objNm = null;
		}

		MCLog.write(FXBAP0089, id, objNm, ret);
	}

	/**
	 * テーブルが変更されたかどうかを調査し、変更されたと判断された場合は true を返します。<p>
	 * テーブルに対応するリストのステータスが NONE の場合は変更されていない、
	 * NONE 以外の場合は変更されたと判断されます。
	 * 全てのカラムが入力不可の場合は、リストのステータスに関係なく、変更されていないと判断されます。
	 *
	 * @param tbl テーブル
	 * @return テーブルが変更されていないと判断された場合は false
	 */
	public boolean isChanged(MCTable<?> tbl) {
		if (tbl == null) {
			return false;
		}
		MCList<?> list = tbl.getList();
		if (list == null) {
			return false;
			// メモ：list.isStatusNONE は、listの中を全部調査するので、先にカラムの調査を行う。
			// (＝全行の調査より全カラムの調査の方が低負荷と判断しての実装)
		}

		MCModeInfo mi = tbl.getModeInfo();
		if (mi != null && MCMode.INVISIBLE_STATUS == mi.getStatus()) {
			return false;
		}

		boolean ans = false;
		for (MCColumnConfig config : tbl.getVisibleColumnConfigs()) {
			// すべてのカラムが DISABLE または READ_ONLE INVISIBLEの場合は、変更なしと判断する。
			MCModeInfo cmi = config.getModeInfo();
			if (cmi != null && MCMode.ENABLE_STATUS != cmi.getStatus()) {
				// 何もしない
			}
			else {
				ans = list.isStatusNone() ? false : true;
				break;
			}
		}
		return ans;
	}

	/**
	 * ロウが変更されたかどうかを調査し、変更されたと判断された場合は true を返します。<p>
	 * ロウのステータスが NONE の場合は変更されていない、
	 * NONE 以外の場合は変更されたと判断されます。
	 * ロウが GUI 部品と紐づいていない場合や、ロウに紐づく GUI 部品が全て入力不可の場合は、
	 * ロウのステータスに関係なく、変更されていないと判断されます。
	 *
	 * @param r ロウ
	 * @return ロウが変更されていないと判断された場合は false
	 */
	public boolean isChanged(MCRow r) {
		if (r == null) {
			return false;
		}
		if (r.isStatusNone()) {
			return false;
		}

		boolean ans = false; // メモ：１つもＧＵＩ部品に紐づいていない場合false
		for (MCMeta meta : r.getMetaArray()) {
			if (MCDataType.ROW == meta.type()) {
				ans = isChanged(r.getInnerRow(meta.name()));
				if (ans == true) {
					return true;
				}
			}
			else {
				JComponent comp = getComponent(r, meta.name());
				if (comp == null) {
					continue;
				}
				if (comp instanceof MCModeBeans) {
					MCModeBeans gui = (MCModeBeans) comp;
					MCModeInfo mi = gui.getModeInfo();
					if (mi != null && MCMode.ENABLE_STATUS != mi.getStatus()) {
						continue;
					}
					// ans = r.isStatusNone() ? false : true;
					ans = true; // ループの前で検査しているので「r.isStatusNone()」は必ずfalse
					break;
				}
			}
		}
		return ans;
	}

	public static final String RESOURCE_KEY_FOR_DISP_STR = "disp_string";

	/**
	 * MCLabelリソースからラベル文字列を取得します。
	 * <p>
	 * 画面の継承関係によって、以下の順番にリソースキーを探します。
	 * <p>
	 * ○画面の継承関係
	 * <pre>
	 *     MCRootPanel
	 *         ↑extends
	 *    WBP0000_FW_A    モジュール ID：W、スクリーン ID：WBP0000
	 *         ↑extends
	 *     WBP0000_FW
	 *         ↑extends
	 *       WBP0000
	 *         ↑extends
	 *    ZBP0000_PJ_A    モジュール ID：Z、スクリーン ID：ZBP0000
	 *         ↑extends
	 *     ZBP0000_PJ
	 *         ↑extends
	 *       ZBP0000
	 * </pre>
	 * <p>
	 * ○リソースキーを探す順番
	 * <p>
	 * <ol>
	 * <li>&LT;Z&GT;&LT;ZBP0000&GT;&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;W&GT;&LT;WBP0000&GT;&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;Z&GT;&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;W&GT;&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;Z&GT;&LT;ZBP0000&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;Z&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;リソースキー&GT;</li>
	 * </ol>
	 * <p>
	 * リソースキーが見つかった場合は、見つかったリソースキーのラベル文字列を返します。
	 * リソースキーが見つからなかった場合は null を返します。
	 *
	 * @param resourceKey リソースキー
	 * @return リソース値、または null
	 */
	public String getDispString(String resourceKey) {
		String[][] msa = getModuleAndScreenIDs();

		String sfx = MCConst.createKey(RESOURCE_KEY_FOR_DISP_STR, resourceKey);
		String key = null;
		for (String[] ms : msa) {
			String k = MCConst.createKey(ms[0], ms[1], sfx);
			if (MCConst.label.containsKey(k)) {
				key = k;
				break;
			}
		}
		if (key == null) {
			for (String[] ms : msa) {
				String k = MCConst.createKey(ms[0], sfx);
				if (MCConst.label.containsKey(k)) {
					key = k;
					break;
				}
			}
		}
		if (key == null) {
			if (MCConst.label.containsKey(sfx)) {
				key = sfx;
			}
		}

		if (key != null) {
			String v = MCConst.label.getLabel(key);
			if (v == null) {
				MCLog.write(new MCMessage(FXBAP0026, key));
			}
			return v;
		}
		else {
			MCLog.write(new MCMessage(FXBAP0027, getModuleID(), getScreenID(),
					RESOURCE_KEY_FOR_DISP_STR, resourceKey));
			return getDispString(getModuleID(), getScreenID(), resourceKey);
		}
	}

	/**
	 * MCLabelリソースからラベル文字列を取得します。
	 * <p>
	 * 以下の順番にリソースキーを探します。
	 * <ol>
	 * <li>&LT;モジュールＩＤ&GT;&LT;画面ＩＤ&GT;&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;モジュールＩＤ&GT;&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;disp_string&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;モジュールＩＤ&GT;&LT;画面ＩＤ&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;モジュールＩＤ&GT;&LT;リソースキー&GT;</li>
	 * <li>&LT;リソースキー&GT;</li>
	 * </ol>
	 * <p>
	 * リソースキーが見つかった場合は、見つかったリソースキーのラベル文字列を返します。
	 * リソースキーが見つからなかった場合は null を返します。
	 *
	 * @param m モジュールＩＤ
	 * @param s 画面ＩＤ
	 * @param r リソースキー
	 * @return リソース値、または null
	 */
	public String getDispString(String m, String s, String r) {
		String key = MCConst.label.findHierarchy(m, s,
				MCConst.createKey(RESOURCE_KEY_FOR_DISP_STR, r));
		if (isNull(key)) {
			key = MCConst.label.findHierarchy(m, s, RESOURCE_KEY_FOR_DISP_STR, r);
		}
		String ret = null;
		if (isNull(key)) {
			MCLog.write(new MCMessage(FXBAP0027, m, s, RESOURCE_KEY_FOR_DISP_STR, r));
		}
		else {
			ret = MCConst.label.getLabel(key);
			if (ret == null) {
				MCLog.write(new MCMessage(FXBAP0026, key));
			}
		}
		return ret;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public String getPgmSettingString(FXBAP_PanelBase panel, String... keys) {
		return panelBaseUtil().getPgmSettingString(panel.getModuleAndScreenIDs(), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public String getPgmSettingStringNE(FXBAP_PanelBase panel, String def,
			String... keys) {
		return panelBaseUtil().getPgmSettingStringNE(panel.getModuleAndScreenIDs(), def,
				keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public MCNumber getPgmSettingNumber(FXBAP_PanelBase panel, String... keys) {
		return panelBaseUtil().getPgmSettingNumber(panel.getModuleAndScreenIDs(), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public MCNumber getPgmSettingNumberNE(FXBAP_PanelBase panel, MCNumber def,
			String... keys) {
		return panelBaseUtil().getPgmSettingNumberNE(panel.getModuleAndScreenIDs(), def,
				keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public Color getPgmSettingColor(FXBAP_PanelBase panel, String... keys) {
		return panelBaseUtil().getPgmSettingColor(panel.getModuleAndScreenIDs(), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public Color getPgmSettingColorNE(FXBAP_PanelBase panel, Color def, String... keys) {
		return panelBaseUtil().getPgmSettingColorNE(panel.getModuleAndScreenIDs(), def,
				keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public int getPgmSettingInt(FXBAP_PanelBase panel, String... keys) {
		return panelBaseUtil().getPgmSettingInt(panel.getModuleAndScreenIDs(), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public int getPgmSettingIntNE(FXBAP_PanelBase panel, int def, String... keys) {
		return panelBaseUtil().getPgmSettingIntNE(panel.getModuleAndScreenIDs(), def,
				keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public boolean getPgmSettingBoolean(FXBAP_PanelBase panel, String... keys) {
		return panelBaseUtil().getPgmSettingBoolean(panel.getModuleAndScreenIDs(), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public boolean getPgmSettingBooleanNE(FXBAP_PanelBase panel, boolean def,
			String... keys) {
		return panelBaseUtil().getPgmSettingBooleanNE(panel.getModuleAndScreenIDs(), def,
				keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public char getPgmSettingChar(FXBAP_PanelBase panel, String... keys) {
		return panelBaseUtil().getPgmSettingChar(panel.getModuleAndScreenIDs(), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値を取得する際に使用するリソースキーは、[モジュールＩＤ.画面ＩＤ.keys]になります。
	 * 指定された画面のモジュールＩＤ、画面ＩＤのリソースキーが存在しない場合は、
	 * 継承関係の上位の画面のモジュールＩＤ、画面ＩＤのリソースキーを検索します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param panel リソース取得対象の画面
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public char getPgmSettingCharNE(FXBAP_PanelBase panel, char def, String... keys) {
		return panelBaseUtil().getPgmSettingCharNE(panel.getModuleAndScreenIDs(), def,
				keys);
	}

	/**
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	protected static FXBAP_PanelBaseUtil _panelBaseUtil;

	/**
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	protected static FXBAP_PanelBaseUtil panelBaseUtil() {
		if (_panelBaseUtil == null) {
			_panelBaseUtil = new FXBAP_PanelBaseUtil();
		}
		return _panelBaseUtil;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingString(FXBAP_PanelBase, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public static String getPgmSettingString(Class<? extends Object> clazz,
			String... keys) {
		return panelBaseUtil().getPgmSettingString(clazz, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingStringNE(FXBAP_PanelBase, String, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public static String getPgmSettingStringNE(Class<?> clazz, String def,
			String... keys) {
		return panelBaseUtil().getPgmSettingStringNE(
				MCBeansUtil.getModuleAndScreenIDs(clazz), def, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingNumber(FXBAP_PanelBase, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public static MCNumber getPgmSettingNumber(Class<?> clazz, String... keys) {
		return panelBaseUtil().getPgmSettingNumber(clazz, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingNumberNE(FXBAP_PanelBase, MCNumber, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public static MCNumber getPgmSettingNumberNE(Class<?> clazz, MCNumber def,
			String... keys) {
		return panelBaseUtil().getPgmSettingNumberNE(
				MCBeansUtil.getModuleAndScreenIDs(clazz), def, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingColor(FXBAP_PanelBase, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public static Color getPgmSettingColor(Class<?> clazz, String... keys) {
		return panelBaseUtil().getPgmSettingColor(clazz, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingColorNE(FXBAP_PanelBase, Color, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public static Color getPgmSettingColorNE(Class<?> clazz, Color def, String... keys) {
		return panelBaseUtil().getPgmSettingColorNE(
				MCBeansUtil.getModuleAndScreenIDs(clazz), def, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingInt(FXBAP_PanelBase, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public static int getPgmSettingInt(Class<?> clazz, String... keys) {
		return panelBaseUtil().getPgmSettingInt(clazz, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingIntNE(FXBAP_PanelBase, int, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public static int getPgmSettingIntNE(Class<?> clazz, int def, String... keys) {
		return panelBaseUtil()
				.getPgmSettingIntNE(MCBeansUtil.getModuleAndScreenIDs(clazz), def, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingBoolean(FXBAP_PanelBase, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public static boolean getPgmSettingBoolean(Class<?> clazz, String... keys) {
		return panelBaseUtil().getPgmSettingBoolean(clazz, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingBooleanNE(FXBAP_PanelBase, boolean, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public static boolean getPgmSettingBooleanNE(Class<?> clazz, boolean def,
			String... keys) {
		return panelBaseUtil().getPgmSettingBooleanNE(
				MCBeansUtil.getModuleAndScreenIDs(clazz), def, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingChar(FXBAP_PanelBase, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public static char getPgmSettingChar(Class<?> clazz, String... keys) {
		return panelBaseUtil().getPgmSettingChar(clazz, keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。<p>
	 * <b>できれば
	 * {@link #getPgmSettingCharNE(FXBAP_PanelBase, char, String...)}
	 * を使用してください。</b>
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	public static char getPgmSettingCharNE(Class<?> clazz, char def, String... keys) {
		return panelBaseUtil()
				.getPgmSettingCharNE(MCBeansUtil.getModuleAndScreenIDs(clazz), def, keys);
	}

	/**
	 * 全てのコンテナのステータスがNONEの場合true<br>
	 * 引数がnullの場合、要素がない場合true nullの要素は無視<br>
	 *
	 * @param containers
	 * @return
	 */
	protected boolean isStatusNone(MCContainer... containers) {
		if (containers == null) {
			return true;
		}
		for (MCContainer c : containers) {
			if (c == null) {
				continue;
			}
			if (!c.isStatusNone()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 全てのコンテナのステータスがNONEの場合true<br>
	 * 引数がnullの場合、要素がない場合true nullの要素は無視<br>
	 *
	 * @param containers
	 * @return
	 */
	public boolean isStatusNone(List<MCContainer> containers) {
		if (containers == null) {
			return true;
		}
		return isStatusNone(containers.toArray(new MCContainer[0]));
	}

	/**
	 * コンテナに紐付いているGUIコンポーネントのモードが「REQUIRED(必須)」になっているにも 関わらず、未入力の箇所があるとメッセージを作成します。
	 *
	 * @return
	 */
	public MCMessageList checkReq(MCContainer... containers) {
		MCMessageList msgList = new MCMessageList();

		for (MCContainer cont : containers) {
			if (cont instanceof MCList) {
				MCList<?> list = (MCList<?>) cont;
				JComponent listComp = getComponent(list);
				if (listComp instanceof MCTable) {
					msgList.addAll(checkReq((MCTable<?>) listComp));
				}
				else if (listComp == null && list.size() > 0) {
					// メモ：list が GUI部品に紐付くコンテナそのものの場合は、listCompが取得できる。
					// list が GUI部品に紐付くコンテナではない場合はnullが返る
					MCRow r = list.get(0);
					if (r.getNameArray().length > 0) {
						listComp = getComponent(r, r.getNameArray()[0]);
					}
					if (listComp instanceof MCTable) {
						msgList.addAll(checkReq((MCTable<?>) listComp, list));
					}
					else {
						// GUIを持たないコンテナの場合、listComp == null
						if (listComp != null) {
							throw new MCAppException(msgUnknownClass(listComp));
						}
					}
				}
				else {
					// GUIを持たないコンテナの場合、listComp == null
					if (listComp != null) {
						throw new MCAppException(msgUnknownClass(listComp));
					}
				}
			}
			else if (cont instanceof MCRow) {
				msgList.addAll(checkReq((MCRow) cont));
			}
		}
		return msgList;
	}

	/**
	 * テーブルの全ての行をチェックします。<br>
	 * セルのモードが入力必須モードであるにも関わらず、
	 * 値が設定されていない項目がある場合に、メッセージを作成します。<p>
	 * テーブルに null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param table テーブル
	 * @return メッセージリスト
	 */
	public MCMessageList checkReq(MCTable<? extends MCConstRow> table) {
		return table != null ? checkReq(table, table.getList()) : new MCMessageList();
	}

	/**
	 * カラムの指定された行をチェックします。<br>
	 * セルのモードが入力必須モードであるにも関わらず、
	 * 値が設定されていない項目がある場合に、メッセージを作成します。<p>
	 * カラムに null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param index カラムのチェック対象の行位置
	 * @param columns カラム
	 * @return メッセージリスト
	 */
	public MCMessageList checkReqWithCellMode(int index, MCColumnConfig... columns) {
		MCMessageList list = new MCMessageList();
		if (columns == null) {
			return list;
		}
		for (MCColumnConfig c : columns) {
			MCTable<?> t = c.getTable();
			if (t != null) {
				if (isReqMode(t.isCellEditable(index, c)) && isNull(c.getValue(index))) {
					list.add(msgNoDataAtReq(t.getBaseTable().getRow(index), c));
				}
			}
		}
		return list;
	}

	/**
	 * 指定されたモードが入力必須モードの場合は true を返します。
	 *
	 * @param mode モード
	 * @return 指定されたモードが入力必須モードではない場合は false
	 */
	protected boolean isReqMode(MCMode mode) {
		return MCCollectionUtil.contains(mode, getReqMode());
	}

	/**
	 * テーブルの指定された List コンテナの GUIIndex の行をチェックします。
	 * セルのモードが入力必須モードであるにも関わらず、
	 * 値が設定されていない項目がある場合にメッセージを作成します。<p>
	 * テーブル、または、List コンテナに null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param tbl テーブル
	 * @param list List コンテナ
	 * @return メッセージリスト
	 * @throws MCAppException [FXBAP0056]
	 * テーブルが保持する Row コンテナ以外の Row コンテナを指定した場合
	 */
	public MCMessageList checkReq(MCTable<? extends MCConstRow> table,
			MCList<? extends MCRow> list) {
		MCMessageList ans = new MCMessageList();
		if (table == null || list == null) {
			return ans;
		}
		for (MCRow o : list) {
			ans.addAll(checkReq(table, o));
		}
		return ans;
	}

	/**
	 * テーブルの指定された Row コンテナの GUIIndex の行をチェックします。
	 * セルのモードが入力必須モードであるにも関わらず、
	 * 値が設定されていない項目がある場合にメッセージを作成します。<p>
	 * テーブル、または、Row コンテナに null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param table テーブル
	 * @param row Row コンテナ
	 * @return メッセージリスト
	 * @throws MCAppException [FXBAP0056]
	 * テーブルが保持する Row コンテナ以外の Row コンテナを指定した場合
	 */
	public MCMessageList checkReq(MCTable<? extends MCConstRow> table, MCRow row) {
		if (table == null || row == null) {
			return new MCMessageList();
		}
		int gui = row.getGUIIndex();
		if (gui < 0 || table.getList().size() <= gui) {
			throw new MCAppException(row, null, FXBAP0056, table.getName(),
					row.getClass().getName(), row.toString());
		}
		return checkReqWithCellMode(table.getRow(gui).getGUIIndex(),
				table.getVisibleColumnConfigs());
	}

	/**
	 * Row コンテナに紐づいている GUI 部品のモードが入力必須モードであるにも関わらず、
	 * 値が設定されていない項目がある場合にメッセージを作成します。<p>
	 * Row コンテナに null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param row Row コンテナ
	 * @return メッセージリスト
	 */
	public MCMessageList checkReq(MCRow row) {
		MCMessageList ans = new MCMessageList();
		if (row == null) {
			return ans;
		}
		for (MCMeta m : row.getMetaArray()) {
			if (MCDataType.ROW == m.type()) {
				ans.addAll(checkReq(row.getInnerRow(m.name())));
			}
			else {
				JComponent c = getComponent(row, m.name());
				if (c == null) {
					continue;
				}
				else if (c instanceof MCTable) {
					ans.addAll(checkReq((MCTable<?>) c, row));
					return ans;
				}
				else if (c instanceof MCModeBeans) {
					MCModeBeans o = (MCModeBeans) c;
					if (isReqMode(o.getMode())) {
						if (isNull(row.getValue(m.name()))) {
							if (o instanceof MCRowBeans) {
								ans.add(msgNoDataAtReq((MCRowBeans) o));
							}
							else {
								throw new MCAppException(msgUnknownClass(o));
							}
						}
					}
				}
				else {
					throw new MCAppException(msgUnknownClass(c));
				}
			}
		}
		return ans;
	}

	/**
	 * GUI 部品に値が設定されていない場合は、メッセージを作成します。
	 * <font color="red">
	 * このメソッドは モードの判定を行いません。
	 * </font><p>
	 * GUI 部品に null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param beans GUI 部品
	 * @return メッセージリスト
	 */
	public MCMessageList checkReq(MCRowBeans... beans) {
		MCMessageList list = new MCMessageList();
		if (beans == null) {
			return list;
		}
		for (MCRowBeans b : beans) {
			if (isNull(b.getRowValue())) {
				list.add(msgNoDataAtReq(b));
			}
		}
		return list;
	}

	/**
	 * カラムの指定された行に値が設定されていない場合は、メッセージを作成します。
	 * <font color="red">
	 * このメソッドは モードの判定を行いません。
	 * </font><p>
	 * カラムに null を指定した場合は、空のメッセージリストを返します。
	 *
	 * @param index カラムのチェック対象の行位置
	 * @param columns カラム
	 * @return メッセージリスト
	 */
	public MCMessageList checkReq(int index, MCColumnConfig... columns) {
		MCMessageList list = new MCMessageList();
		if (columns == null) {
			return list;
		}
		for (MCColumnConfig c : columns) {
			if (isNull(c.getValue(index))) {
				list.add(msgNoDataAtReq(c.getBaseTable().getRow(index), c));
			}
		}
		return list;
	}

	/**
	 * 正の数字を入力すべきところに０を入力していないかを検査する。０を入力していた場合、メッセージを返します。
	 *
	 * @param beans 見出しの項目
	 * @return
	 */
	public MCMessageList checkPositive(MCRowBeans... beans) {
		MCMessageList list = new MCMessageList();
		for (MCRowBeans b : beans) {
			Comparable<?> v = b.getRowValue();
			if (v instanceof MCNumber) {
				MCNumber num = (MCNumber) v;
				if (!num.isPositive()) {
					list.add(msgNotPositiveEx(b));
				}
			}
		}
		return list;
	}

	/**
	 * 正の数字を入力すべきところに０を入力していないかを検査する。０を入力していた場合、メッセージを返します。
	 *
	 * @param idx カラムのチェック対象の行番号（リストの行番号。GUIIndexではない。）
	 * @param columns カラム
	 */
	public MCMessageList checkPositive(int idx, MCColumnConfig... columns) {
		MCMessageList ans;
		if (columns == null || columns.length < 1) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = columns[0].getBaseTable();
			ans = checkPositive(tbl.getRow(idx), columns);
		}
		return ans;
	}

	/**
	 * 正の数字を入力すべきところに０を入力していないかを検査する。０を入力していた場合、メッセージを返します。
	 *
	 * @param row カラムのチェック対象の行
	 * @param columns カラム
	 */
	public MCMessageList checkPositive(MCRow row, MCColumnConfig... columns) {
		MCMessageList ans = new MCMessageList();
		MCRow baseRow = row.getRootRow();
		for (MCColumnConfig c : columns) {
			Comparable<?> v = baseRow.getValue(c.getBaseRowColumnName());
			if (v instanceof MCNumber) {
				MCNumber num = (MCNumber) v;
				if (!num.isPositive()) {
					ans.add(msgNotPositiveEx(baseRow, c));
				}
			}
		}
		return ans;
	}

	/**
	 * 正の数字を入力すべきところに０を入力していないかを検査する。０を入力していた場合、メッセージを返します。
	 * <P>
	 * listに格納されているRowインスタンスは、MCColumnConfigから取得できるテーブルに使用されている Rowインスタンスそのものである必要があります。
	 * </P>
	 *
	 * @param list チェック対象のデータが入ったリスト
	 * @param columns カラム
	 */
	public MCMessageList checkPositive(MCList<? extends MCConstRow> list,
			MCColumnConfig... columns) {
		MCMessageList ans = new MCMessageList();
		for (MCConstRow r : list) {
			int idx = r.getGUIIndex();
			for (MCColumnConfig c : columns) {
				Comparable<?> v = c.getValue(idx);
				if (v instanceof MCNumber) {
					MCNumber num = (MCNumber) v;
					if (!num.isPositive()) {
						MCTable<?> tbl = c.getBaseTable();
						ans.add(msgNotPositiveEx(tbl.getRow(idx), c));
					}
				}
			}
		}
		return ans;
	}

	/**
	 * コンテナに存在する全てのカラムに対して、その保持している値がメタ情報に指定された scale及びlength以内であるかどうかをチェックします。<br>
	 * scale又はlengthを超える値がセットされている場合は、メッセージを返します。
	 *
	 * @param cont チェック対象のコンテナ
	 * @return
	 */
	public MCMessageList checkScaleAndLength(MCContainer... cont) {
		MCMessageList ans = null;
		for (MCContainer c : cont) {
			MCMessageList m = checkScaleAndLength(c, (String) null);
			if (m != null && m.size() > 0) {
				if (ans == null) {
					ans = m;
				}
				else {
					ans.addAll(m);
				}
			}
		}
		return ans == null ? new MCMessageList() : ans;
	}

	/**
	 * コンテナに存在するcolsで指定したカラムに対して、その保持している値がメタ情報に指定された scale及びlength以内であるかどうかをチェックします。<br>
	 * scale又はlengthを超える値がセットされている場合は、メッセージを返します。
	 * <p>
	 * 指定したカラムがInnerRowを指す場合、InnerRowの全カラムを検証します。
	 * <p>
	 * 引数 cols が指定されなかった場合および null((String[]) null) の場合は 全カラムの値を検証します。
	 *
	 * @param cont チェック対象のコンテナ
	 * @param cols 検証するカラム名
	 * @return
	 */
	public MCMessageList checkScaleAndLength(MCContainer cont, String... cols) {
		MCMessageList ans = null;
		MCMessageList m = null;
		if (cont instanceof MCRow) {
			MCRow row = (MCRow) cont;
			m = row.validate(cols);
		}
		else if (cont instanceof MCList) {
			MCList<?> list = (MCList<?>) cont;
			m = list.validate(cols);
		}
		if (m != null && m.size() > 0) {
			ans = new MCMessageList();
			for (MCMessage msg : m) {
				MCRow r = msg.getCauseRow();
				String c = msg.getCauseColumn();

				if (FCBBC0063.equals(msg.getID())) {
					// FCBBC0063
					// String型が文字数に違反している場合

					//複数値かもしれないので、再度、桁チェック。
					JComponent comp = getComponent(r, c);
					if (comp instanceof MCPluralValueField) {
						if (((MCPluralValueField) comp).isPluralValueEnable()) {
							//再度、桁チェック。
							MCMeta me = r.getMeta(c);
							String[] vs = MCStringUtil.arrayValueSplit(r.getStringNE(c));
							boolean boo = false;
							for (String v : vs) {
								if (v != null && me.length() < v.length()) {
									boo = true;
									break;
								}
							}
							if (boo) {
								ans.add(msgTooLongString(r, c));
							}
						}
					}
					else {
						ans.add(msgTooLongString(r, c));
					}
				}
				else if (FCBBC0064.equals(msg.getID())) {
					// FCBBC0064
					// Number型が桁数に違反している場合
					ans.add(msgInvalidNumberPrecision(r, c));
				}
				else if (FCBBC0062.equals(msg.getID())) {
					// FCBBC0062
					// カラムがRowにない場合
					// メモ：実装エラーなので例外とする
					throw new MCAppException(msg);
				}
				else {
					// FCBBC0065
					// 負値を許容しないNumber型が負値の場合
					// 他
					// メモ：その他の例外はチェック対象外なので無視
				}
			}
		}
		return ans == null ? new MCMessageList() : ans;
	}

	/**
	 * 次のいずれかを選択してください。（行：[行数]）<br>
	 * [beansのメッセージラベル]<br>
	 * [beansのメッセージラベル]<br>
	 * ...<br>
	 */
	public MCMessage msgAtLeastOne(int i, MCColumnConfig... beans) {
		StringBuilder sb = new StringBuilder();
		String sep = "";
		for (MCColumnConfig b : beans) {
			sb.append(sep + b.getMessageByLocale());
			sep = MCStringUtil.LF_CODE;
		}
		return FXUCP_ValidaterUtil.msgAtLeastOneInput(sb.toString(), i);
	}

	/**
	 * [messageByLocale]の中のいずれかを選択してください。
	 */
	public MCMessage msgAtLeastOne(MCPanel p) {
		return msgAtLeastOne(p.getMessageByLocale());
	}

	/**
	 * [messageByLocale]の中のいずれかの値を入力してください。
	 */
	public MCMessage msgAtLeastOneInput(MCPanel b) {
		return msgAtLeastOneInput(b.getMessageByLocale());
	}

	/**
	 * [messageByLocale]の中のいずれかを選択してください。
	 */
	public MCMessage msgAtLeastOne(MCBorderLine b) {
		return msgAtLeastOne(b.getMessageByLocale());
	}

	/**
	 * [messageByLocale]の中のいずれかの値を入力してください。
	 */
	public MCMessage msgAtLeastOneInput(MCBorderLine b) {
		return msgAtLeastOneInput(b.getMessageByLocale());
	}

	/**
	 * [messageByLocale]の中のいずれかを選択してください。
	 */
	public MCMessage msgAtLeastOne(MCLabel b) {
		return msgAtLeastOne(b.getMessageByLocale());
	}

	/**
	 * [messageByLocale]の中のいずれかの値を入力してください。
	 */
	public MCMessage msgAtLeastOneInput(MCLabel b) {
		return msgAtLeastOneInput(b.getMessageByLocale());
	}

	/**
	 * [messageByLocale]の中のいずれかを選択してください。
	 */
	public MCMessage msgAtLeastOne(String messageByLocale) {
		return new MCMessage(FXBAP0061, messageByLocale);
	}

	/**
	 * [messageByLocale]の中のいずれかの値を入力してください。
	 */
	public MCMessage msgAtLeastOneInput(String messageByLocale) {
		return new MCMessage(FXBAP0058, messageByLocale);
	}

	/**
	 * [messageByLocale]の中のいずれかの値を入力してください。
	 */
	public MCMessage msgAtLeastOne(int i, String messageByLocale) {
		return new MCMessage(FXBAP0043, i + 1, messageByLocale);
	}

	/**
	 * [messageByLocale]の中のいずれかの値を入力してください。
	 */
	public MCMessage msgAtLeastOneInput(int i, String messageByLocale) {
		return FXUCP_ValidaterUtil.msgAtLeastOneInput(messageByLocale, i);
	}

	/**
	 * 次のいずれかを選択してください。<br>
	 * [チェックボックスのメッセージラベル]<br>
	 * [チェックボックスのメッセージラベル]<br>
	 * ...<br>
	 */
	public MCMessage msgAtLeastOne(MCCheckBox... cbs) {
		StringBuilder sb = new StringBuilder();
		String sep = "";
		for (MCCheckBox cb : cbs) {
			sb.append(sep + cb.getMessageByLocale());
			sep = MCStringUtil.LF_CODE;
		}
		return new MCMessage(FXBAP0060, sb.toString());
	}

	/**
	 * 次のいずれかを選択してください。<br>
	 * [beansのメッセージラベル]<br>
	 * [beansのメッセージラベル]<br>
	 * ...<br>
	 */
	public MCMessage msgAtLeastOneInput(MCRowBeans... beans) {
		StringBuilder sb = new StringBuilder();
		String sep = "";
		for (MCRowBeans b : beans) {
			sb.append(sep + b.getMessageByLocale());
			sep = MCStringUtil.LF_CODE;
		}
		return FXUCP_ValidaterUtil.msgAtLeastOneInput(sb.toString());
	}

	/**
	 * beansの中の複数のbeansに値が入力されていたときのエラーメッセージ
	 */
	public MCMessage msgTooManyInputs(MCRowBeans... beans) {
		StringBuilder sb = new StringBuilder();
		String sep = "";
		for (MCRowBeans b : beans) {
			sb.append(sep + b.getMessageByLocale());
			sep = MCStringUtil.LF_CODE;
		}
		MCRow r = beans[0].getBaseRow();
		String col = beans[0].getBaseRowColumnName();

		return FXUCP_ValidaterUtil.msgTooManyInputs(r, col, sb.toString());
	}

	/**
	 * beansの中の複数のbeansに値が入力されていたときのエラーメッセージ
	 */
	public MCMessage msgTooManyInputs(MCRow causeRow, MCColumnConfig... conf) {
		StringBuilder sb = new StringBuilder();
		String sep = "";
		for (MCColumnConfig b : conf) {
			sb.append(sep + b.getMessageByLocale());
			sep = MCStringUtil.LF_CODE;
		}
		return FXUCP_ValidaterUtil.msgTooManyInputs(causeRow,
				conf[0].getBaseRowColumnName(), sb.toString(),
				causeRow.getGUIIndex() + 1);
	}

	/**
	 * 次のいずれかを選択してください。（行：[行数]）<br>
	 * [beansのメッセージラベル]<br>
	 * [beansのメッセージラベル]<br>
	 * ...<br>
	 */
	public MCMessage msgAtLeastOneInput(int i, MCColumnConfig... beans) {
		StringBuilder sb = new StringBuilder();
		String sep = "";
		for (MCColumnConfig b : beans) {
			sb.append(sep + b.getMessageByLocale());
			sep = MCStringUtil.LF_CODE;
		}
		return FXUCP_ValidaterUtil.msgAtLeastOneInput(sb.toString(), i);
	}

	/**
	 * 引数のコンボボックスに一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上チェックが入っている場合、及び、コンボボックスの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param messageByLocale メッセージ用の文字列
	 * @param cbs コンボボックス
	 */
	public MCMessageList checkAtLeastOne(String messageByLocale, MCCheckBox... cbs) {
		if (cbs == null || cbs.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOne(cbs);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOne(messageByLocale);
			MCRow r = cbs[0].getBaseRow();
			String col = cbs[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;

	}

	/**
	 * 引数のbeansに一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param messageByLocale メッセージ用の文字列
	 * @param beans
	 */
	public MCMessageList checkAtLeastOneInput(String messageByLocale,
			MCRowBeans... beans) {
		if (beans == null || beans.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOneInput(beans);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOneInput(messageByLocale);
			MCRow r = beans[0].getBaseRow();
			String col = beans[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;

	}

	/**
	 * 引数のカラムコンフィグの指定行に一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param messageByLocale メッセージ用の文字列
	 * @param i チェック対象行
	 * @param beans
	 */
	public MCMessageList checkAtLeastOneInput(String messageByLocale, int i,
			MCColumnConfig... beans) {
		if (beans == null || beans.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOneInput(i, beans);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOneInput(i, messageByLocale);
			MCTable<?> tbl = beans[0].getBaseTable();
			MCRow r = null;
			if (tbl != null) {
				r = tbl.getRow(i);
			}
			String col = beans[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;

	}

	/**
	 * 引数のカラムコンフィグの指定行に一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param messageByLocale メッセージ用の文字列
	 * @param tar チェック対象行
	 * @param beans
	 */
	public MCMessageList checkAtLeastOneInput(String messageByLocale, MCRow tar,
			MCColumnConfig... beans) {
		return checkAtLeastOneInput(messageByLocale, tar.getGUIIndex(), beans);
	}

	/**
	 * 対象のパネル上に存在するのチェックボックス（含む、パネル内に存在する部品画面内のチェックボックス）に
	 * 一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上チェックが入っている場合、及び、チェックボックスの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param p パネル
	 */
	public MCMessageList checkAtLeastOne(MCPanel p) {
		if (p == null) {
			return new MCMessageList();
		}
		MCCheckBox[] beans = MCBeansUtil.getAllComponents(MCCheckBox.class, p);
		MCMessageList ret = checkAtLeastOne(p.getMessageByLocale(), beans);
		return ret;
	}

	/**
	 * 対象のパネル上に存在するのMCRowBeans（含む、パネル内に存在する部品画面内のMCRowBeans）に
	 * 一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param p パネル
	 */
	public MCMessageList checkAtLeastOneInput(MCPanel p) {
		if (p == null) {
			return new MCMessageList();
		}
		MCRowBeans[] beans = MCBeansUtil.getAllComponents(MCRowBeans.class, p);
		MCMessageList ret = checkAtLeastOneInput(p.getMessageByLocale(), beans);
		return ret;
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param beans
	 * @param tar チェック対象の行
	 */
	public MCMessageList checkAtLeastOne(MCRow tar, MCColumnConfig... beans) {
		return checkAtLeastOne(tar.getGUIIndex(), beans);
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param beans
	 * @param i チェック対象の行
	 */
	public MCMessageList checkAtLeastOne(int i, MCColumnConfig... beans) {
		if (beans == null || beans.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOne(i, beans);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOne(i, beans);
			MCTable<?> tbl = beans[0].getBaseTable();
			MCRow r = null;
			if (tbl != null) {
				r = tbl.getRow(i);
			}
			String col = beans[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;
	}

	/**
	 * 引数のチェックボックスに一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上チェックが入っている場合、及び、チェックボックスの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param bl ボーダーライン（枠線）（メッセージに使用）
	 * @param beans チェックボックス
	 */
	public MCMessageList checkAtLeastOne(MCBorderLine bl, MCCheckBox... beans) {
		MCMessageList ret = checkAtLeastOne(bl.getMessageByLocale(), beans);
		return ret;
	}

	/**
	 * 引数のbeansに一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param bl ボーダーライン（枠線）（メッセージに使用）
	 * @param beans
	 */
	public MCMessageList checkAtLeastOneInput(MCBorderLine bl, MCRowBeans... beans) {
		MCMessageList ret = checkAtLeastOneInput(bl.getMessageByLocale(), beans);
		return ret;
	}

	/**
	 * 引数のチェックボックスに一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上チェックが入っている場合、及び、チェックボックスの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param lbl ラベル（メッセージに使用）
	 * @param beans チェックボックス
	 */
	public MCMessageList checkAtLeastOne(MCLabel lbl, MCCheckBox... beans) {
		MCMessageList ret = checkAtLeastOne(lbl.getMessageByLocale(), beans);
		return ret;
	}

	/**
	 * 引数のbeansに一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param lbl ラベル（メッセージに使用）
	 * @param beans
	 */
	public MCMessageList checkAtLeastOneInput(MCLabel lbl, MCRowBeans... beans) {
		MCMessageList ret = checkAtLeastOneInput(lbl.getMessageByLocale(), beans);
		return ret;
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param lbl ラベル（メッセージに使用）
	 * @param i 対象行
	 * @param beans カラムコンフィグ
	 */
	public MCMessageList checkAtLeastOneInput(MCLabel lbl, int i,
			MCColumnConfig... beans) {
		MCMessageList ret = checkAtLeastOneInput(lbl.getMessageByLocale(), i, beans);
		return ret;
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param lbl ラベル（メッセージに使用）
	 * @param tar 対象行
	 * @param beans カラムコンフィグ
	 */
	public MCMessageList checkAtLeastOneInput(MCLabel lbl, MCRow tar,
			MCColumnConfig... beans) {
		MCMessageList ret = checkAtLeastOneInput(lbl.getMessageByLocale(),
				tar.getGUIIndex(), beans);
		return ret;
	}

	/**
	 * 引数のチェックボックスに一つもチェックが入っていない場合はメッセージを返します。
	 * １つ以上チェックが入っている場合、及び、チェックボックスの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param beans チェックボックス
	 */
	public MCMessageList checkAtLeastOne(MCCheckBox... beans) {
		if (beans == null || beans.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOne(beans);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOne(beans);
			MCRow r = beans[0].getBaseRow();
			String col = beans[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;
	}

	/**
	 * 引数のbeansに一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param beans
	 */
	public MCMessageList checkAtLeastOneInput(MCRowBeans... beans) {
		if (beans == null || beans.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOneInput(beans);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOneInput(beans);
			MCRow r = beans[0].getBaseRow();
			String col = beans[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param beans
	 * @param i チェック対象の行
	 */
	public MCMessageList checkAtLeastOneInput(int i, MCColumnConfig... beans) {
		if (beans == null || beans.length == 0) {
			return new MCMessageList();
		}
		MCMessageList ret = new MCMessageList();
		boolean ans = isAtLeastOneInput(i, beans);
		if (ans) {
			return ret;
		}
		else {
			MCMessage msg = msgAtLeastOneInput(i, beans);
			MCTable<?> tbl = beans[0].getBaseTable();
			MCRow r = null;
			if (tbl != null) {
				r = tbl.getRow(i);
			}
			String col = beans[0].getBaseRowColumnName();
			msg.setCauseRow(r, col);
			ret.add(msg);
		}
		return ret;
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つも値が入っていない場合はメッセージを返します。
	 * １つ以上値が入っている場合、及び、beansの配列がnull又は長さが0の場合は
	 * 空のメッセージリストを返します。
	 * @param beans
	 * @param tar チェック対象の行
	 */
	public MCMessageList checkAtLeastOneInput(MCRow tar, MCColumnConfig... beans) {
		return checkAtLeastOneInput(tar.getGUIIndex(), beans);
	}

	/**
	 * 指定された画面項目のうち、値が設定されている項目が２個以上ある場合はエラーメッセージを返します。
	 *
	 * @param beans 画面項目
	 * @return メッセージリスト
	 */
	public MCMessageList checkTooManyInputs(MCRowBeans... beans) {
		if (beans == null || beans.length < 1) {
			return new MCMessageList();
		}

		int cnt = 0;
		MCMessageList l = new MCMessageList();
		for (MCRowBeans c : beans) {
			if (!isNull(c.getRowValue())) {
				if (++cnt > 1) {
					l.add(msgTooManyInputs(beans));
					return l;
				}
			}
		}
		return l;
	}

	/**
	 * 指定された行のカラムのうち、値が設定されているカラムが２個以上ある場合はエラーメッセージを返します。
	 *
	 * @param idx チェック対象の行番号
	 * @param columns カラム
	 * @return メッセージリスト
	 */
	public MCMessageList checkTooManyInputs(int idx, MCColumnConfig... columns) {
		if (columns == null || columns.length < 1) {
			return new MCMessageList();
		}

		return checkTooManyInputs(columns[0].getBaseTable().getRow(idx), columns);
	}

	/**
	 * 指定された行のカラムのうち、値が設定されているカラムが２個以上ある場合はエラーメッセージを返します。
	 * <p>
	 *
	 * 引数のMCRowは、MCColumnConfigから取得できるテーブルに使用されているMCRowである必要があります。
	 *
	 * @param row チェック対象の行
	 * @param columns カラム
	 * @return メッセージリスト
	 */
	public MCMessageList checkTooManyInputs(MCRow row, MCColumnConfig... columns) {
		if (columns == null || columns.length < 1) {
			return new MCMessageList();
		}

		MCMessageList l = new MCMessageList();
		_checkTooManyInputs(l, row, columns);
		return l;
	}

	@Deprecated
	protected void _checkTooManyInputs(MCMessageList list, MCRow row,
			MCColumnConfig... columns) {
		int cnt = 0;
		MCRow o = row.getRootRow();
		for (MCColumnConfig c : columns) {
			if (!isNull(o.getValue(c.getBaseRowColumnName()))) {
				if (++cnt > 1) {
					list.add(msgTooManyInputs(row, columns));
					return;
				}
			}
		}
	}

	/**
	 * 指定されたリストの各行のカラムのうち、値が設定されているカラムが２個以上ある場合はエラーメッセージを返します。
	 * <p>
	 *
	 * 引数のMCListに格納されているMCRowは、MCColumnConfigから取得できるテーブルに使用されている
	 * MCRowである必要があります。
	 *
	 * @param list チェック対象のMCRowが格納されたリスト
	 * @param columns カラム
	 * @return メッセージリスト
	 */
	public MCMessageList checkTooManyInputs(MCList<? extends MCConstRow> list,
			MCColumnConfig... columns) {
		if (columns == null || columns.length < 1) {
			return new MCMessageList();
		}

		MCMessageList l = new MCMessageList();
		for (MCConstRow o : list) {
			_checkTooManyInputs(l, o, columns);
		}
		return l;
	}

	/**
	 * 引数のチェックボックスが一つでもチェックされていたらtrueを返します。
	 */
	protected boolean isAtLeastOne(MCCheckBox[] beans) {
		boolean ans = false;
		if (beans != null) {
			for (MCCheckBox b : beans) {
				boolean val = b.getValue();
				if (val) {
					ans = true;
					break;
				}
			}
		}
		return ans;
	}

	/**
	 * 引数のカラムコンフィグの指定行が一つでもチェックされていたらtrueを返します。
	 * boolean の値ではない場合、そのカラムコンフィグはチェックなしとみなされます。
	 */
	protected boolean isAtLeastOne(int i, MCColumnConfig[] beans) {
		boolean ans = false;
		if (beans != null) {
			for (MCColumnConfig b : beans) {
				Comparable<?> c = b.getValue(i);
				if (c instanceof Boolean) {
					boolean v = (Boolean) c;
					if (v) {
						ans = true;
						break;
					}
				}
			}
		}
		return ans;
	}

	/**
	 * 引数のBeans一つでも値が入力されていたらtrueを返します。
	 */
	protected boolean isAtLeastOneInput(MCRowBeans[] beans) {
		boolean ans = false;
		if (beans != null) {
			for (MCRowBeans b : beans) {
				if (!isNull(b.getRowValue())) {
					ans = true;
					break;
				}
			}
		}
		return ans;
	}

	/**
	 * 引数のカラムコンフィグの指定行に一つでも値が入力されていたらtrueを返します。
	 */
	protected boolean isAtLeastOneInput(int i, MCColumnConfig[] beans) {
		boolean ans = false;
		if (beans != null) {
			for (MCColumnConfig b : beans) {
				if (!isNull(b.getValue(i))) {
					ans = true;
					break;
				}
			}
		}
		return ans;
	}

	/**
	 * 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1 または dt2 がnullの場合</li>
	 * <li>dt1 及び dt2 が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	 * @param num1 本来小さい日付(before)
	 * @param num2 本来大きい日付(after)
	 * @return
	 */
	public MCMessageList checkBeforeAfter(MCRowBeans dt1, MCRowBeans dt2) {
		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null) {
			return msgList;
		}
		Comparable<?> c1 = dt1.getRowValue();
		Comparable<?> c2 = dt2.getRowValue();
		if (c1 == null || c2 == null) {
			return msgList;
		}

		if (isCalendarDate(c1, c2)) {
			if (c1 instanceof MCDate) {
				MCDate mcdt1 = (MCDate) c1;
				MCDate mcdt2 = (MCDate) c2;
				if (mcdt2.lt(mcdt1)) {
					msgList.add(msgNotBefore(dt1, dt2));
				}
			}
			else if (c1 instanceof MCTimestamp) {
				MCTimestamp mcdt1 = (MCTimestamp) c1;
				MCTimestamp mcdt2 = (MCTimestamp) c2;
				if (mcdt2.lt(mcdt1)) {
					msgList.add(msgNotBefore(dt1, dt2));
				}
			}
		}
		return msgList;
	}

	/**
	* 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	* <P>
	* 尚、以下の場合も、空のメッセージリストを返します。
	* <li>dt1 または dt2 がnullの場合</li>
	* <li>dt1 及び dt2 が保持している値の少なくとも１つがnullの場合</li>
	* </P>
	*
	* @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	* @param dt1 本来小さい日付(before)
	* @param dt2 本来大きい日付(after)
	* @param mcRowNum
	* @return
	*/
	public MCMessageList checkBeforeAfter(MCRowBeans dt1, MCColumnConfig dt2,
			int mcRowNum) {
		MCMessageList ans;
		if (dt1 == null || dt2 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = dt2.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(mcRowNum);
			ans = checkBeforeAfter(dt1, dt2, row);
		}
		return ans;
	}

	/**
	* 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	* <P>
	* 尚、以下の場合も、空のメッセージリストを返します。
	* <li>dt1 または dt2 がnullの場合</li>
	* <li>dt1 及び dt2 が保持している値の少なくとも１つがnullの場合</li>
	* </P>
	*
	* @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	* @param dt1 本来小さい日付(before)
	* @param mcRowNum
	* @param dt2 本来大きい日付(after)
	* @return
	*/
	public MCMessageList checkBeforeAfter(MCColumnConfig dt1, int mcRowNum,
			MCRowBeans dt2) {
		MCMessageList ans;
		if (dt1 == null || dt2 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = dt1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(mcRowNum);
			ans = checkBeforeAfter(dt1, row, dt2);
		}
		return ans;
	}

	/**
	 * 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1 または dt2 がnullの場合</li>
	 * <li>dt1 及び dt2 が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	 * @param num1 本来小さい日付(before)
	 * @param num2 本来大きい日付(after)
	 * @param row
	 * @return
	 */
	public MCMessageList checkBeforeAfter(MCRowBeans dt1, MCColumnConfig dt2, MCRow row) {
		// メモ：本メソッドの戻り値は、おそらく最大で１件であろうと
		// 思われるので、戻り値はMCMessageのにした方がMCMessageListのnewのコストが
		// 削減できるので良いという指摘もあるが、
		// それをしてしまうと、エラーがなかった場合は、nullを戻す
		// 仕様になってしまい、呼び出し側で戻り値を評価する必要が出てきてしまうので
		// その実装が嫌なのでMCMessageListを返すようにする。
		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null) return msgList;
		if (row == null) return msgList;
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = dt1.getRowValue();
		Comparable<?> c2 = baseRow.getValue(dt2.getBaseRowColumnName());

		if (c1 == null || c2 == null) return msgList;
		MCDate mcdt1;
		MCDate mcdt2;
		if (c1 instanceof MCDate) {
			mcdt1 = (MCDate) c1;
		}
		else {
			throw new MCAppException(msgUnknownClass(c1));
		}
		if (c2 instanceof MCDate) {
			mcdt2 = (MCDate) c2;
		}
		else {
			throw new MCAppException(msgUnknownClass(c2));
		}

		if (mcdt2.lt(mcdt1)) {
			String msgDt1 = dt1.getMessageByLocale();
			String msgDt2 = dt2.getMessageByLocale();

			MCMessage ans = msgNotBefore(msgDt1, msgDt2);
			MCTable<?> tbl = dt2.getTable();
			if (tbl != null) {
				ans.setCauseRow(baseRow, dt2.getBaseRowColumnName());
			}
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1 または dt2 がnullの場合</li>
	 * <li>dt1 及び dt2 が保持している値の少c１つがnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	 * @param dt1 本来小さい日付(before)
	x	 * @param row
	 * @param dt2 本来大きい日付(after)
	 * @return
	 */
	public MCMessageList checkBeforeAfter(MCColumnConfig dt1, MCRow row, MCRowBeans dt2) {
		// メモ：本メソッドの戻り値は、おそらく最大で１件であろうと
		// 思われるので、戻り値はMCMessageのにした方がMCMessageListのnewのコストが
		// 削減できるので良いという指摘もあるが、
		// それをしてしまうと、エラーがなかった場合は、nullを戻す
		// 仕様になってしまい、呼び出し側で戻り値を評価する必要が出てきてしまうので
		// その実装が嫌なのでMCMessageListを返すようにする。
		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null) return msgList;
		if (row == null) return msgList;
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(dt1.getBaseRowColumnName());
		Comparable<?> c2 = dt2.getRowValue();

		if (c1 == null || c2 == null) return msgList;
		MCDate mcdt1;
		MCDate mcdt2;
		if (c1 instanceof MCDate) {
			mcdt1 = (MCDate) c1;
		}
		else {
			throw new MCAppException(msgUnknownClass(c1));
		}
		if (c2 instanceof MCDate) {
			mcdt2 = (MCDate) c2;
		}
		else {
			throw new MCAppException(msgUnknownClass(c2));
		}

		if (mcdt2.lt(mcdt1)) {
			String msgDt1 = dt1.getMessageByLocale();
			String msgDt2 = dt2.getMessageByLocale();

			MCMessage ans = msgNotBefore(msgDt1, msgDt2);
			MCTable<?> tbl = dt1.getTable();
			if (tbl != null) {
				ans.setCauseRow(baseRow, dt1.getBaseRowColumnName());
			}
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * チェック対象の日付が運用日付以降であるかのチェック<br>
	 * チェック対象の日付が運用日付以降の場合は、メッセージリストにメッセージを追加した物を返します。<br>
	 * 運用日付より前の場合は空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1がnullの場合</li>
	 * <li>dt1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @param dt1 チェック対象の日付
	 * @return
	 */
	public MCMessageList checkAfterToday(MCDateField dt1) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null) {
			return msgList;
		}
		MCDate mcdt1 = dt1.getRowValue();

		if (mcdt1 == null) {
			return msgList;
		}

		if (mcdt1.lt(getToday())) {
			String msgDt1 = getMessageByLocaleNE(dt1);
			MCMessage ans = FXUCP_ValidaterUtil.msgNotAfterToday(msgDt1,
					toYMDString(mcdt1), toYMDString(getToday()), true);
			setCauseRow(ans, dt1);
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * チェック対象の日付が運用日付以前であるかのチェック<br>
	 * チェック対象の日付が運用日付より後の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以前の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1がnullの場合</li>
	 * <li>dt1が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @param dt1 チェック対象の日付
	 * @return
	 */
	public MCMessageList checkBeforeToday(MCDateField dt1) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null) {
			return msgList;
		}
		MCDate mcdt1 = dt1.getRowValue();

		if (mcdt1 == null) {
			return msgList;
		}

		if (mcdt1.gt(getToday())) {
			String msgDt1 = getMessageByLocaleNE(dt1);
			MCMessage ans = FXUCP_ValidaterUtil.msgNotBeforeToday(msgDt1,
					toYMDString(mcdt1), toYMDString(getToday()), true);
			setCauseRow(ans, dt1);
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付であることのチェック
	 * <p>
	 * 条件を満たさない場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 条件を満たす場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * メッセージのcauseRowは、dt2より取得します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1またはdt2がnullの場合</li>
	 * <li>dt1またはdt2が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @param dt1
	 * @param dt2
	 * @return
	 */
	public MCMessageList check2DtBeforeToday(MCDateField dt1, MCDateField dt2) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null) return msgList;
		MCDate mcdt1 = dt1.getRowValue();
		MCDate mcdt2 = dt2.getRowValue();
		if (mcdt1 == null || mcdt2 == null) return msgList;

		if (mcdt2.gte(mcdt1) && mcdt2.lte(getToday())) {
			// OK
		}
		else {
			String msgDt1 = getMessageByLocaleNE(dt1);
			String msgDt2 = getMessageByLocaleNE(dt2);

			MCMessage ans = FXUCP_ValidaterUtil.msgNot2DtBeforeToday(msgDt1, msgDt2,
					toYMDString(mcdt1), toYMDString(mcdt2), toYMDString(getToday()),
					true);
			setCauseRow(ans, dt2);
			msgList.add(ans);
		}

		return msgList;
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3のであるかをチェックします。<br>
	 * 条件を満たさない場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 条件を満たす場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1,dt2,dt3のいずれかがnullの場合</li>
	 * <li>dt1,dt2,dt3のいずれかが保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @param dt1
	 * @param dt2
	 * @param dt3
	 * @return
	 */
	public MCMessageList check3Dt(MCDateField dt1, MCDateField dt2, MCDateField dt3) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null || dt3 == null) return msgList;
		MCDate mcdt1 = dt1.getRowValue();
		MCDate mcdt2 = dt2.getRowValue();
		MCDate mcdt3 = dt3.getRowValue();

		if (mcdt1 == null || mcdt2 == null || mcdt3 == null) return msgList;

		if (mcdt2.gte(mcdt1) && mcdt2.lte(mcdt3)) {
			// OK
		}
		else {
			String msgDt1 = getMessageByLocaleNE(dt1);
			String msgDt2 = getMessageByLocaleNE(dt2);
			String msgDt3 = getMessageByLocaleNE(dt3);

			MCMessage ans = FXUCP_ValidaterUtil.msgNot3DtBeforeAfter(msgDt1, msgDt2,
					msgDt3, toYMDString(mcdt1), toYMDString(mcdt2), toYMDString(mcdt3),
					true);
			setCauseRow(ans, dt2);
			msgList.add(ans);
		}

		return msgList;

	}

	/**
	 * チェック対象の日付が運用日付以前であるか(チェック対象の日付 ≦ 運用日付)のチェック(テーブル用)<br>
	 * チェック対象の日付が運用日付より後の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以前の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1がnullの場合</li>
	 * <li>dt1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値がMCDateではない場合
	 * @param dt1 チェック対象の日付
	 * @param index 行インデックス
	 * @return
	 */
	public MCMessageList checkBeforeToday(MCColumnConfig dt1, int index) {

		MCMessageList ans;
		if (dt1 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = dt1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(index);
			ans = checkBeforeToday(dt1, row);
		}
		return ans;
	}

	/**
	 * チェック対象の日付が運用日付以前であるか(チェック対象の日付 ≦ 運用日付)のチェック(テーブル用)<br>
	 * チェック対象の日付が運用日付より後の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以前の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1がnullの場合</li>
	 * <li>dt1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値がMCDateではない場合
	 * @param dt1 チェック対象の日付
	 * @param row
	 * @return
	 */
	public MCMessageList checkBeforeToday(MCColumnConfig dt1, MCRow row) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null) {
			return msgList;
		}
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(dt1.getBaseRowColumnName());

		if (c1 == null) {
			return msgList;
		}
		MCDate mcdt1 = getDate(c1);

		if (mcdt1.gtDate(getToday())) {
			String msgDt1 = dt1.getMessageByLocale();
			MCMessage ans = FXUCP_ValidaterUtil.msgNotBeforeToday(msgDt1,
					toYMDString(mcdt1), toYMDString(getToday()), baseRow.getGUIIndex(),
					true);
			setCauseRow(ans, dt1, baseRow);
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * チェック対象の日付が運用日付以降であるか(チェック対象の日付 ≧ 運用日付)のチェック(テーブル用)<br>
	 * チェック対象の日付が運用日付より前の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以降の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1がnullの場合</li>
	 * <li>dt1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値がMCDateではない場合
	 * @param dt1 チェック対象の日付
	 * @param index 行インデックス
	 * @return
	 */
	public MCMessageList checkAfterToday(MCColumnConfig dt1, int index) {

		MCMessageList ans;
		if (dt1 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = dt1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(index);
			ans = checkAfterToday(dt1, row);
		}
		return ans;

	}

	/**
	 * チェック対象の日付が運用日付以降であるか(チェック対象の日付 ≧ 運用日付)のチェック(テーブル用)<br>
	 * チェック対象の日付が運用日付より前の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以降の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1がnullの場合</li>
	 * <li>dt1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値がMCDateではない場合
	 * @param dt1 チェック対象の日付
	 * @param row
	 * @return
	 */
	public MCMessageList checkAfterToday(MCColumnConfig dt1, MCRow row) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null) {
			return msgList;
		}
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(dt1.getBaseRowColumnName());

		if (c1 == null) {
			return msgList;
		}
		MCDate mcdt1 = getDate(c1);

		if (mcdt1.ltDate(getToday())) {
			String msgDt1 = dt1.getMessageByLocale();
			MCMessage ans = FXUCP_ValidaterUtil.msgNotAfterToday(msgDt1,
					toYMDString(mcdt1), toYMDString(getToday()), baseRow.getGUIIndex(),
					true);
			setCauseRow(ans, dt1, baseRow);
			msgList.add(ans);
		}
		return msgList;

	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付であることのチェック
	 * <p>
	 * 条件を満たさない場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 条件を満たす場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * メッセージのcauseRowは、dt2より取得します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1またはdt2がnullの場合</li>
	 * <li>dt1またはdt2が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @param dt1
	 * @param dt2
	 * @param index 行インデックス
	 * @return
	 */
	public MCMessageList check2DtBeforeToday(MCColumnConfig dt1, MCColumnConfig dt2,
			int index) {

		MCMessageList ans;
		if (dt1 == null || dt2 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = dt1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(index);
			ans = check2DtBeforeToday(dt1, dt2, row);
		}
		return ans;

	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付であることのチェック
	 * <p>
	 * 条件を満たさない場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 条件を満たす場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * メッセージのcauseRowは、dt2より取得します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1またはdt2がnullの場合</li>
	 * <li>dt1またはdt2が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @param dt1
	 * @param dt2
	 * @param row
	 * @return
	 */
	public MCMessageList check2DtBeforeToday(MCColumnConfig dt1, MCColumnConfig dt2,
			MCRow row) {

		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null) {
			return msgList;
		}

		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(dt1.getBaseRowColumnName());
		Comparable<?> c2 = baseRow.getValue(dt2.getBaseRowColumnName());

		if (c1 == null || c2 == null) {
			return msgList;
		}

		MCDate mcdt1 = getDate(c1);
		MCDate mcdt2 = getDate(c2);

		if (mcdt2.gteDate(mcdt1) && mcdt2.lteDate(getToday())) {
			// OK
		}
		else {
			String msgDt1 = getMessageByLocaleNE(dt1);
			String msgDt2 = getMessageByLocaleNE(dt2);

			MCMessage ans = FXUCP_ValidaterUtil.msgNot2DtBeforeToday(msgDt1, msgDt2,
					toYMDString(mcdt1), toYMDString(mcdt2), toYMDString(getToday()),
					baseRow.getGUIIndex(), true);
			setCauseRow(ans, dt2, row);
			msgList.add(ans);
		}

		return msgList;
	}

	/**
	 * 日時が運用日付以前であるか（日時の時分秒を切り捨てた日付≦運用日付）のチェック<br>
	 * 日時の時分秒を切り捨てた日付が運用日付より後の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以前の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>tm1がnullの場合</li>
	 * <li>tm1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @param tm1 日時
	 * @return
	 */
	public MCMessageList checkTmBeforeToday(MCDateField tm1) {
		MCMessageList msgList = new MCMessageList();

		if (tm1 == null) {
			return msgList;
		}
		MCDate val = tm1.getRowValue();

		if (val == null) {
			return msgList;
		}
		//比較対象の日時の時分秒を切り捨てる。
		MCDate mcdt1 = val.trunc(MCDateFieldType.DAY);

		if (mcdt1.gt(getToday())) {
			String msgTm1 = getMessageByLocaleNE(tm1);

			//メッセージに出力する場合は、時分秒を切り捨てない。
			MCMessage ans = FXUCP_ValidaterUtil.msgNotBeforeToday(msgTm1,
					tm1.getCalendarFormat().doOutputFormat(val), toYMDString(getToday()),
					true);
			setCauseRow(ans, tm1);
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * 日時が運用日付以前であるか（日時の時分秒を切り捨てた日付≦運用日付）のチェック(テーブル用)<br>
	 * 日時の時分秒を切り捨てた日付が運用日付より後の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以前の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>tm1がnullの場合</li>
	 * <li>tm1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @exception tm1が保持している値がMCDateではない場合
	 * @param tm1 日時
	 * @param index 行インデックス
	 * @return
	 */
	public MCMessageList checkTmBeforeToday(MCColumnConfig tm1, int index) {

		MCMessageList ans;
		if (tm1 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = tm1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(index);
			ans = checkTmBeforeToday(tm1, row);
		}
		return ans;
	}

	/**
	 * 日時が運用日付以前であるか（日時の時分秒を切り捨てた日付≦運用日付）のチェック(テーブル用)<br>
	 * 日時の時分秒を切り捨てた日付が運用日付より後の場合はメッセージリストにメッセージを追加した物を返します。 <br>
	 * 運用日付以前の場合は、空（＝サイズが０）のメッセージリストを返します。<br>
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>tm1がnullの場合</li>
	 * <li>tm1が保持している値がnullの場合</li>
	 * </P>
	 *
	 * @exception tm1が保持している値がMCDateではない場合
	 * @param tm1 日時
	 * @param row
	 * @return
	 */
	public MCMessageList checkTmBeforeToday(MCColumnConfig tm1, MCRow row) {

		MCMessageList msgList = new MCMessageList();

		if (tm1 == null) {
			return msgList;
		}
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(tm1.getBaseRowColumnName());

		if (c1 == null) {
			return msgList;
		}
		MCDate val = getDate(c1);
		//比較対象の日時の時分秒を切り捨てる。
		MCDate mcdt1 = val.trunc(MCDateFieldType.DAY);

		if (mcdt1.gtDate(getToday())) {
			String msgTm1 = tm1.getMessageByLocale();

			//メッセージに出力する場合は、時分秒を切り捨てない。
			MCMessage ans = FXUCP_ValidaterUtil.msgNotBeforeToday(msgTm1,
					tm1.getDateFormat().doOutputFormat(val), toYMDString(getToday()),
					baseRow.getGUIIndex(), true);
			setCauseRow(ans, tm1, baseRow);
			msgList.add(ans);
		}
		return msgList;
	}

	/**
	 * ComparableからMCDateにキャストして返します。 cのインスタンスがMCDateでない場合はExceptionをスローします。
	 *
	 * @param c
	 * @return
	 */
	protected MCDate getDate(Comparable<?> c) {

		if (c instanceof MCDate) {
			return (MCDate) c;
		}
		else {
			throw new MCAppException(msgUnknownClass(c));
		}
	}

	/**
	 * MCBeansからロケールにあわせたメッセージを取得します。beansがnullの場合はnullを返します。
	 *
	 * @param beans
	 * @return
	 */
	protected String getMessageByLocaleNE(MCBeans beans) {

		if (beans == null) {
			return null;
		}
		else {
			return beans.getMessageByLocale();
		}

	}

	/**
	 * 引数のMCMessageに、MCDateFieldから取得したcauseRowを設定します
	 *
	 * @param msg
	 * @param f
	 */
	protected void setCauseRow(MCMessage msg, MCDateField f) {

		if (f != null) {
			msg.setCauseRow(f.getBaseRow(), f.getBaseRowColumnName());

		}
	}

	/**
	 * 引数のMCMessageに、MCColumnConfigとindexから取得したcauseRowを設定します
	 *
	 * @param msg
	 * @param config
	 * @param baseRow
	 */
	protected void setCauseRow(MCMessage msg, MCColumnConfig config, MCRow baseRow) {

		if (config != null) {
			MCTable<?> tbl = config.getTable();
			if (tbl != null) {
				msg.setCauseRow(baseRow, config.getBaseRowColumnName());
			}
		}
	}

	/**
	 * ０以外の数字を入力すべきところに０を入力していないかを検査する。
	 * ０を入力していた場合、メッセージを返します。
	 *
	 * @param beans 見出しの項目
	 * @return
	 */
	public MCMessageList checkNotZero(MCRowBeans... beans) {
		MCMessageList list = new MCMessageList();
		for (MCRowBeans b : beans) {
			Comparable<?> v = b.getRowValue();
			if (v instanceof MCNumber) {
				MCNumber num = (MCNumber) v;
				if (num.isZero()) {
					list.add(msgZeroEx(b));
				}
			}
		}
		return list;
	}

	/**
	 * ０以外の数字を入力すべきところに０を入力していないかを検査する。
	 * ０を入力していた場合、メッセージを返します。
	 *
	 * @param idx カラムのチェック対象の行番号（リストの行番号。GUIIndexではない。）
	 * @param columns カラム
	 */
	public MCMessageList checkNotZero(int idx, MCColumnConfig... columns) {
		MCMessageList ans;
		if (columns == null || columns.length < 1) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = columns[0].getBaseTable();
			ans = checkNotZero(tbl.getRow(idx), columns);
		}
		return ans;
	}

	/**
	 * ０以外の数字を入力すべきところに０を入力していないかを検査する。
	 * ０を入力していた場合、メッセージを返します。
	 *
	 * @param row カラムのチェック対象の行
	 * @param columns カラム
	 */
	public MCMessageList checkNotZero(MCRow row, MCColumnConfig... columns) {
		MCMessageList ans = new MCMessageList();
		MCRow baseRow = row.getRootRow();
		for (MCColumnConfig c : columns) {
			Comparable<?> v = baseRow.getValue(c.getBaseRowColumnName());
			if (v instanceof MCNumber) {
				MCNumber num = (MCNumber) v;
				if (num.isZero()) {
					ans.add(msgZeroEx(baseRow, c));
				}
			}
		}
		return ans;
	}

	/**
	 * ０以外の数字を入力すべきところに０を入力していないかを検査する。
	 * ０を入力していた場合、メッセージを返します。
	 * <P>
	 * listに格納されているRowインスタンスは、MCColumnConfigから
	 * 取得できるテーブルに使用されている Rowインスタンスそのものである必要があります。
	 * </P>
	 *
	 * @param list チェック対象のデータが入ったリスト
	 * @param columns カラム
	 */
	public MCMessageList checkNotZero(MCList<? extends MCConstRow> list,
			MCColumnConfig... columns) {
		MCMessageList ans = new MCMessageList();
		for (MCConstRow r : list) {
			int idx = r.getGUIIndex();
			for (MCColumnConfig c : columns) {
				Comparable<?> v = c.getValue(idx);
				if (v instanceof MCNumber) {
					MCNumber num = (MCNumber) v;
					if (num.isZero()) {
						MCTable<?> tbl = c.getBaseTable();
						ans.add(msgZeroEx(tbl.getRow(idx), c));
					}
				}
			}
		}
		return ans;
	}

	/**
	 * 見出し項目で０以外の値を入れるべき所に０以下の値が入っていた場合のエラーメッセージを作ります。
	 * <p>
	 * メッセージ本文：<br>
	 * ０以外の数字を入力してください。<br>
	 * 項目名：{1}
	 * </p>
	 */
	public MCMessage msgZeroEx(MCRowBeans gui) {
		MCMessage msg = FXUCP_ValidaterUtil.msgZero(gui.getMessageByLocale());
		msg.setCauseRow(gui.getBaseRow(), gui.getBaseRowColumnName());
		return msg;
	}

	/**
	 * テーブルで０以外の値を入れるべき所に０以下の値が入っていた場合のエラーメッセージを作ります。
	 * <p>
	 * メッセージ本文：<br>
	 * ０以外の数字を入力してください。<br>
	 * 列名：{1}<br>
	 * 行：{2}<br>
	 * </p>
	 */
	public MCMessage msgZeroEx(MCRow causeRow, MCColumnConfig conf) {
		conf.getMessageByLocale();
		MCMessage msg = FXUCP_ValidaterUtil.msgZero(conf.getMessageByLocale(),
				causeRow.getGUIIndex());
		msg.setCauseRow(causeRow.getRootRow(), conf.getBaseRowColumnName());
		return msg;
	}

	/**
	 * 引数のオブジェクトが日付型かつ同じ型（MCDate同士、MCTimestamp同士）で
	 * あれば、trueを返します。<BR>
	 * それ以外は、falseを返します。<BR>
	 * オブジェクトがnullの場合でも、falseを返します。
	 *
	 * @param c1 比較するオブジェクト１
	 * @param c2 比較するオブジェクト２
	 * @return 日付型かつ同じ型であれば、true
	 */
	public boolean isCalendarDate(Comparable<?> c1, Comparable<?> c2) {
		if (c1 == null || c2 == null) {
			return false;
		}

		if (!(c1 instanceof MCDate || c1 instanceof MCTimestamp)) {
			throw new MCAppException(msgUnknownClass(c1));
		}
		if (!(c2 instanceof MCDate || c2 instanceof MCTimestamp)) {
			throw new MCAppException(msgUnknownClass(c1));
		}

		if (c1 instanceof MCDate) {
			if (c2 instanceof MCDate) {
				return true;
			}
		}

		if (c1 instanceof MCTimestamp) {
			if (c2 instanceof MCTimestamp) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>dt1 または dt2 がnullの場合</li>
	 * <li>dt1 及び dt2 が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	 * @param num1 本来小さい日付(before)
	 * @param num2 本来大きい日付(after)
	 * @param row
	 * @return
	 */
	public MCMessageList checkBeforeAfter(MCColumnConfig dt1, MCColumnConfig dt2,
			MCRow row) {
		// メモ：本メソッドの戻り値は、おそらく最大で１件であろうと
		// 思われるので、戻り値はMCMessageのにした方がMCMessageListのnewのコストが
		// 削減できるので良いという指摘もあるが、
		// それをしてしまうと、エラーがなかった場合は、nullを戻す
		// 仕様になってしまい、呼び出し側で戻り値を評価する必要が出てきてしまうので
		// その実装が嫌なのでMCMessageListを返すようにする。
		MCMessageList msgList = new MCMessageList();

		if (dt1 == null || dt2 == null) {
			return msgList;
		}
		if (row == null) {
			return msgList;
		}
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(dt1.getBaseRowColumnName());
		Comparable<?> c2 = baseRow.getValue(dt2.getBaseRowColumnName());

		if (c1 == null || c2 == null) {
			return msgList;
		}

		if (isCalendarDate(c1, c2)) {
			if (c1 instanceof MCDate) {
				MCDate mcdt1 = (MCDate) c1;
				MCDate mcdt2 = (MCDate) c2;
				if (mcdt2.lt(mcdt1)) {
					msgList.add(msgNotBefore(dt1, dt2, baseRow.getGUIIndex()));
				}
			}
			else if (c1 instanceof MCTimestamp) {
				MCTimestamp mcdt1 = (MCTimestamp) c1;
				MCTimestamp mcdt2 = (MCTimestamp) c2;
				if (mcdt2.lt(mcdt1)) {
					msgList.add(msgNotBefore(dt1, dt2, baseRow.getGUIIndex()));
				}
			}
		}
		return msgList;
	}

	/**
	* 本来大きい日付が本来小さい日付より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	* <P>
	* 尚、以下の場合も、空のメッセージリストを返します。
	* <li>dt1 または dt2 がnullの場合</li>
	* <li>dt1 及び dt2 が保持している値の少なくとも１つがnullの場合</li>
	* </P>
	*
	* @exception dt1が保持している値 または dt2 が保持している値の少なくとも１つがMCDateではない場合
	* @param num1 本来小さい日付(before)
	* @param num2 本来大きい日付(after)
	* @param mcRowNum
	* @return
	*/
	public MCMessageList checkBeforeAfter(MCColumnConfig dt1, MCColumnConfig dt2,
			int mcRowNum) {
		MCMessageList ans;
		if (dt1 == null || dt2 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = dt1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(mcRowNum);
			ans = checkBeforeAfter(dt1, dt2, row);
		}
		return ans;
	}

	/**
	 * 本来大きい数値が本来小さい数値より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>num1 または num2 がnullの場合</li>
	 * <li>num1 及び num2 が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @exception num1が保持している値 または num2 が保持している値の少なくとも１つがMCNumberではない場合
	 * @param num1 本来小さい数値(small)
	 * @param num2 本来大きい数値(large)
	 * @return
	 */
	public MCMessageList checkSmallLarge(MCRowBeans num1, MCRowBeans num2) {
		MCMessageList msgList = new MCMessageList();

		if (num1 == null || num2 == null) {
			return msgList;
		}
		Comparable<?> c1 = num1.getRowValue();
		Comparable<?> c2 = num2.getRowValue();
		if (c1 == null || c2 == null) {
			return msgList;
		}
		MCNumber mcnum1;
		MCNumber mcnum2;
		if (c1 instanceof MCNumber) {
			mcnum1 = (MCNumber) c1;
		}
		else {
			throw new MCAppException(msgUnknownClass(c1));
		}
		if (c2 instanceof MCNumber) {
			mcnum2 = (MCNumber) c2;
		}
		else {
			throw new MCAppException(msgUnknownClass(c2));
		}

		if (mcnum2.lt(mcnum1)) {
			msgList.add(msgNotSmall(num1, num2));
		}
		return msgList;
	}

	/**
	 * 本来大きい数値が本来小さい数値より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	 * <P>
	 * 尚、以下の場合も、空のメッセージリストを返します。
	 * <li>num1 または num2 がnullの場合</li>
	 * <li>num1 及び num2 が保持している値の少なくとも１つがnullの場合</li>
	 * </P>
	 *
	 * @exception num1が保持している値 または num2 が保持している値の少なくとも１つがMCNumberではない場合
	 * @param num1 本来小さい数値(small)
	 * @param num2 本来大きい数値(large)
	 * @param row
	 * @return
	 */
	public MCMessageList checkSmallLarge(MCColumnConfig num1, MCColumnConfig num2,
			MCRow row) {
		// メモ：本メソッドの戻り値は、おそらく最大で１件であろうと
		// 思われるので、戻り値はMCMessageのにした方がMCMessageListのnewのコストが
		// 削減できるので良いという指摘もあるが、
		// それをしてしまうと、エラーがなかった場合は、nullを戻す
		// 仕様になってしまい、呼び出し側で戻り値を評価する必要が出てきてしまうので
		// その実装が嫌なのでMCMessageListを返すようにする。
		MCMessageList msgList = new MCMessageList();

		if (num1 == null || num2 == null) {
			return msgList;
		}
		if (row == null) {
			return msgList;
		}
		MCRow baseRow = row.getRootRow();
		Comparable<?> c1 = baseRow.getValue(num1.getBaseRowColumnName());
		Comparable<?> c2 = baseRow.getValue(num2.getBaseRowColumnName());

		if (c1 == null || c2 == null) {
			return msgList;
		}
		MCNumber mcnum1;
		MCNumber mcnum2;
		if (c1 instanceof MCNumber) {
			mcnum1 = (MCNumber) c1;
		}
		else {
			throw new MCAppException(msgUnknownClass(c1));
		}
		if (c2 instanceof MCNumber) {
			mcnum2 = (MCNumber) c2;
		}
		else {
			throw new MCAppException(msgUnknownClass(c2));
		}

		if (mcnum2.lt(mcnum1)) {
			msgList.add(msgNotSmall(num1, num2, baseRow.getGUIIndex()));
		}
		return msgList;
	}

	/**
	* 本来大きい数値が本来小さい数値より小さい場合は、メッセージリストにメッセージを追加した物を返します。 それ以外は、空（＝サイズが０）のメッセージリストを返します。
	* <P>
	* 尚、以下の場合も、空のメッセージリストを返します。
	* <li>num1 または num2 がnullの場合</li>
	* <li>num1 及び num2 が保持している値の少なくとも１つがnullの場合</li>
	* </P>
	*
	* @exception num1が保持している値 または num2 が保持している値の少なくとも１つがMCNumberではない場合
	* @param num1 本来小さい数値(small)
	* @param num2 本来大きい数値(large)
	* @param mcRowNum
	* @return
	*/
	public MCMessageList checkSmallLarge(MCColumnConfig num1, MCColumnConfig num2,
			int mcRowNum) {
		MCMessageList ans;
		if (num1 == null || num2 == null) {
			ans = new MCMessageList();
		}
		else {
			MCTable<?> tbl = num1.getBaseTable();
			MCRow row = (tbl == null) ? null : tbl.getRow(mcRowNum);
			ans = checkSmallLarge(num1, num2, row);
		}
		return ans;
	}

	// ユーティリティ(END) ====================================
	// Listからの抽出(START)===================================
	/**
	 * 各grpColの値のグループ で maxColumnの値 が最大のものを集めたlistを返します。
	 * <P>
	 * 戻り値のリストの順番は、対象のリストの並び順を加味しません
	 * </P>
	 * @param list subList対象のリスト
	 * @param maxColumn 比較対象のカラム名
	 * @param grpColumn グループのカラム名
	 */
	protected <R extends MCRow, L extends MCList<R>> L subListMax(L list, String maxCol,
			String... grpColumn) {
		return subListMaxOrMin(list, MCList.SortType.DESC, maxCol, grpColumn);
	}

	/**
	 * 各grpColの値のグループ で maxColumnの値 が最小のものを集めたlistを返します。
	 * <P>
	 * 戻り値のリストの順番は、対象のリストの並び順を加味しません
	 * </P>
	 * @param list subList対象のリスト
	 * @param minColumn 比較対象のカラム名
	 * @param grpColumn グループのカラム名
	 */
	protected <R extends MCRow, L extends MCList<R>> L subListMin(L list, String minCol,
			String... grpColumn) {
		return subListMaxOrMin(list, MCList.SortType.ASC, minCol, grpColumn);
	}

	/**
	 *
	 * @param list subList対象のリスト
	 * @param type ソート条件
	 * @param minColumn 比較対象のカラム名
	 * @param grpColumn グループのカラム名
	 * @deprecated 共通親クラスのみでの使用を想定。{@link #subListMin(MCList, String, String...)}
	 * 又は {@link #subListMax(MCList, String, String...)}を使用してください。
	 */
	@Deprecated
	@SuppressWarnings("unchecked")
	protected <R extends MCRow, L extends MCList<R>> L subListMaxOrMin(L list,
			MCList.SortType type, String minOrMaxCol, String... grpColumn) {
		if (list == null) {
			return null;
		}
		L down = (L) list.createInstance();

		if (minOrMaxCol == null && list.size() == 0) {
			return down;
		}
		String[] cols;
		if (grpColumn == null) {
			cols = new String[] {
					minOrMaxCol
			};
		}
		else {
			cols = new String[grpColumn.length + 1];
			for (int i = 0; i < grpColumn.length; i++) {
				cols[i] = grpColumn[i];
			}
			cols[grpColumn.length] = minOrMaxCol;
		}

		MCRow prevRow = null;
		if (type == null) {
			throw new MCAppException("");
		}
		MCRowComparator<R> comparator = type.getComparator(cols);
		MCIndexKey idx = list.createIndex(comparator);
		if (grpColumn == null) {
			down.add(list.get(0));
		}
		else {
			for (Iterator<R> itr = list.iterator(idx); itr.hasNext();) {
				R r = itr.next();
				if (!isColSame(prevRow, r, grpColumn)) {
					down.add(r);
				}
				prevRow = r;
			}
		}
		return down;
	}

	/**
	 * cmlColで指定したカラムに、listのcolの値を累積した値をセットする。
	 * <li>listがnullまたは空の場合は何もしない。</li>
	 * <li>list中のすべてのrowにカラムcol, cmlColが存在すること。かつNUMBER型であること。</li>
	 * <li>colがnullの場合は0を加算する。</li>
	 *
	 * @param list 対象のリスト
	 * @param col 累積するカラム
	 * @param cmlCol 累積値をセットするカラム
	 */
	public <R extends MCRow> void setCmlValue(MCList<R> list, String col, String cmlCol) {
		// cml : cumulative 累積的な
		if (list == null || list.isEmpty()) {
			return;
		}
		setCmlValue(list, col, cmlCol, 0, list.size() - 1);
	}

	/**
	 * cmlColで指定したカラムに、listのcolの値を累積した値をセットする（frIdx～toIdxの範囲）。
	 * <li>listがnullまたは空の場合は何もしない。</li>
	 * <li>list中のすべてのrowにカラムcol, cmlColが存在すること。かつNUMBER型であること。</li>
	 * <li>colがnullの場合は0を加算する。</li>
	 *
	 * @param list 対象のリスト
	 * @param col 累積するカラム
	 * @param cmlCol 累積値をセットするカラム
	 * @param frIdx 累積計算開始行（0以上をセットする）
	 * @param toIdx 累積計算終了行（この行を含む）
	 */
	public <R extends MCRow> void setCmlValue(MCList<R> list, String col, String cmlCol,
			int frIdx, int toIdx) {
		if (list == null || list.isEmpty()) {
			return;
		}

		MCNumber sum;
		if (frIdx < 1) {
			sum = MCNumber.ZERO;
		}
		else {
			sum = list.get(frIdx - 1).getNumber(cmlCol);
			if (sum == null) {
				sum = MCNumber.ZERO;
			}
		}
		for (int i = frIdx; i <= toIdx; i++) {
			if (list.get(i).getNumber(col) != null) {
				sum = sum.add(list.get(i).getNumber(col));
			}
			list.get(i).setNumber(cmlCol, sum);
		}
	}

	/**
	 * リストの中から条件に合致したデータのリストを返します。
	 * 条件はOracleの like 演算子の右辺と同じ物が使えます。
	 * つまり、「A%Z」を指定した場合は、「A」で始まり「Z」で終了する
	 * 文字列のリストが返ります。
	 *
	 * @param list リスト
	 * @param condition 条件
	 */
	public List<String> subListByLike(List<String> list, String condition) {
		List<String> ret = new ArrayList<>();
		if (list == null || list.size() == 0 || condition == null) {
			return ret;
		}
		String regex = toRegexForOracleLike(condition);
		for (String s : list) {
			if (s.matches(regex)) {
				ret.add(s);
			}
		}
		return ret;
	}

	/**
	 * リストの比較対象のカラムのデータが条件に合致した
	 * 行のリストを返します。
	 * 条件はOracleの like 演算子の右辺と同じ物が使えます。
	 * つまり、「A%Z」を指定した場合は、「A」で始まり「Z」で終了する
	 * 文字列のリストが返ります。
	 *
	 * @param list リスト
	 * @param column 比較対象のカラム
	 * @param condition 条件
	 */
	public <E extends MCRow> MCList<E> subListByLike(MCList<E> list, String column,
			String condition) {
		MCList<E> ret = list.createInstance();
		if (list.size() == 0 || condition == null) {
			return ret;
		}
		String regex = toRegexForOracleLike(condition);
		for (E r : list) {
			if (r.getString(column).matches(regex)) {
				ret.add(r);
			}
		}
		return ret;
	}

	/**
	 * 対象のリスト から 「行ステータスがDeleteではない」「表示上空行ではない」
	 * の２つを 満たす行のリストを返します。<br>
	 * row の isEmpty が true である場合に「空行」とみなします。
	 *
	 * @param <R>
	 * @param list 対象のリスト
	 * @return Deleteステータスか表示列の値が全て空の行をを除いたリスト
	 */
	public <R extends MCConstRow> MCList<R> exceptDeleteAndViewEmpty(MCTable<R> tbl) {
		if (tbl == null) {
			return null;
		}
		MCList<R> list = tbl.getList();
		MCList<R> ans = list.createInstance();
		MCColumnConfig[] confs = tbl.getVisibleColumnConfigs();
		ArrayList<String> cl = new ArrayList<>();
		for (int i = 0; i < confs.length; i++) {
			if (confs[i].isLinkRowColumn()) {
				cl.add(confs[i].getBaseRowColumnName());
			}
		}
		String[] cols = cl.toArray(new String[cl.size()]);

		for (R row : list) {
			if (!row.isStatusDelete()) {
				MCRow rRow = row.getRootRow();
				if (!rRow.isEmpty(cols)) {
					ans.add(row);
				}
			}
		}
		return ans;
	}

	/**
	 * 対象のリスト から 表示上空行ではない行のリストを返します。<br>
	 * row の isEmpty が true である場合に「空行」とみなします。
	 *
	 * @param <R>
	 * @param list 対象のリスト
	 * @return 表示列の値が全て空の行を除いたリスト
	 */
	public <R extends MCConstRow> MCList<R> exceptViewEmpty(MCTable<R> tbl) {
		if (tbl == null) {
			return null;
		}
		MCList<R> list = tbl.getList();
		MCList<R> ans = list.createInstance();
		MCColumnConfig[] confs = tbl.getVisibleColumnConfigs();
		ArrayList<String> cl = new ArrayList<>();
		for (int i = 0; i < confs.length; i++) {
			if (confs[i].isLinkRowColumn()) {
				cl.add(confs[i].getBaseRowColumnName());
			}
		}
		String[] cols = cl.toArray(new String[cl.size()]);
		for (R row : list) {
			MCRow rRow = row.getRootRow();
			if (!rRow.isEmpty(cols)) {
				ans.add(row);
			}
		}
		return ans;
	}

	/**
	 * row のテーブルの表示可能なカラムの値がすべてnull又はfalseの場合に
	 * trueを返します。
	 *
	 * @param <R> テーブルの行クラス
	 * @param tbl テーブル（null不可）
	 * @param row 検査対象の行
	 * @return テーブルの表示可能なカラムの値がすべてnull又はfalseの場合はtrue
	 */
	public <R extends MCConstRow> boolean isViewEmpty(MCTable<R> tbl, R row) {
		if (tbl == null) {
			throw new MCAppException(FXBAP0084);
		}

		// 表示、非表示はカラムごとにチェックする。
		// カラム名の配列を作成せず、必要に応じてカラム名を取得する。
		MCRow rRow = row.getRootRow();
		MCColumnConfig[] ca = tbl.getColumnConfigs();
		for (MCColumnConfig c : ca) {
			if (!MCMode.isInvisible(c) && c.isLinkRowColumn()) {
				String n = c.getBaseRowColumnName();
				if (!rRow.isEmpty(n)) {
					return false;
				}
			}
		}
		return true;
//		MCColumnConfig[] confs = tbl.getVisibleColumnConfigs();
//		String[] cols = new String[confs.length];
//		for (int i = 0; i < confs.length; i++) {
//			cols[i] = confs[i].getBaseRowColumnName();
//		}
//		MCRow rRow = row.getRootRow();
//		return rRow.isEmpty(cols);
	}

	/**
	 * テーブルの指定行のRowの値が、テーブルの表示可能なカラムにおいてすべて
	 * null又はfalseの場合にtrueを返します。
	 *
	 * @param tbl テーブル（null不可）
	 * @param idx 検査対象の行
	 * @return テーブルの表示可能なカラムの値がすべてnull又はfalseの場合はtrue
	 */
	public <R extends MCConstRow> boolean isViewEmpty(MCTable<R> tbl, int idx) {
		if (tbl == null) {
			throw new MCAppException(FXBAP0084);
		}
		return isViewEmpty(tbl, tbl.getRow(idx));
	}

	/**
	 * コンテナに関連する見出し用の画面部品のうち、表示項目にnull 又は false の
	 * 場合にtrueを返します。
	 * <P>
	 * リスト用の画面部品に紐づいているコンテナを引数にセットすると例外が発生します。
	 * リスト用の画面部品に紐づいているコンテナについてチェックをする場合は、
	 * {@link #isViewEmpty(MCTable, int)} 又は {@link #isViewEmpty(MCTable, MCConstRow)}
	 * を使用してください。
	 *
	 * @param row 見出し項目に紐づくコンテナ
	 * @return 表示項目がすべてnull又はfalseの場合はtrue
	 */
	public boolean isViewEmpty(MCRow row) {
		List<String> cols = new ArrayList<>();
		for (String col : row.getColumnPathArray()) {
			JComponent jcomp = getComponent(row, col);
			if (jcomp == null) {
				// 紐づくGUIがない場合
				continue;
			}
			if (jcomp instanceof MCRowBeans) {
				MCRowBeans rb = (MCRowBeans) jcomp;
				if (rb instanceof MCModeBeans) {
					MCModeBeans mb = (MCModeBeans) rb;
					if (mb.getModeInfo().getStatus() == MCMode.INVISIBLE_STATUS) {
						// 非表示は無視
					}
					else {
						cols.add(rb.getBaseRowColumnName());
					}
				}
				else {
					// MCRowBeansなのにMCModeBeansでないものは存在しない
					throw new MCAppException(msgUnknownClass(rb));
				}
			}
			else {
				throw new MCAppException(FXBAP0094);
			}
		}
		if (cols.size() > 0) {
			return row.getRootRow().isEmpty(cols.toArray(new String[0]));
		}
		return true;
	}

	/**
	 * デフォルトモードが入力可能なモードの場合は true を返す。
	 *
	 * @param compo GUI 部品
	 * @return デフォルトモードが入力可能なモードではない場合は false
	 */
	protected boolean isDefaultModeEditable(MCModeBeans compo) {
		MCMode def = getDefaultMode(compo);
		if (def == null) {
			return false;
		}
		return compo.getModeInfo(def).getStatus() == MCMode.ENABLE_STATUS;
	}

	/**
	 * 引数のテーブルのベーステーブルの行が「空行」ではない場合の、行のリスト を返します。（テーブルに紐づく行の型と戻り値の行の型は同一です。）
	 *
	 * @param <R>
	 * @param table 対象のリスト
	 * @return
	 */
	public <R extends MCConstRow> MCList<R> exceptBaseEmpty(MCTable<R> table) {
		MCList<?> baseL = table.getBaseTable().getList();
		MCList<R> l = table.getList().createInstance();

		for (int i = 0; i < baseL.size(); i++) {
			if (!baseL.get(i).isEmpty()) {
				l.add(table.getList().get(i));
			}
		}

		return l;
	}

	/**
	 * 対象のリスト から 「空行」 を取り除いたリストを返します。<br>
	 * row の isEmpty が true である場合に「空行」とみなします。
	 *
	 * @param <R>
	 * @param list 対象のリスト
	 * @return
	 */
	public <R extends MCRow> MCList<R> exceptEmpty(MCList<R> list) {
		MCList<R> ans = list.createInstance();
		for (R row : list) {
			if (!row.isEmpty()) {
				ans.add(row);
			}
		}
		return ans;
	}

	/**
	 * 対象のリスト から 「空行」 を取り除いたリストを返します。<br>
	 * emptyRow と同値である場合に「空行」とみなします。
	 *
	 * @param <R>
	 * @param list 対象のリスト
	 * @pram emptyRow 「空行」と同じデータを持ったインスタンス
	 * @return
	 */
	public <R extends MCRow> MCList<R> exceptEmpty(MCList<R> list, MCRow emptyRow) {
		MCList<R> ans = list.createInstance();
		for (R row : list) {
			if (!isSame(row, emptyRow)) {
				ans.add(row);
			}
		}
		return ans;
	}

	/**
	 * 対象のリスト から 「行ステータスがDeleteではない」「空行ではない」の２つを 満たす行のリストを返します。<br>
	 * row の isEmpty が true である場合に「空行」とみなします。
	 *
	 * @param <R>
	 * @param list 対象のリスト
	 * @return
	 */
	public <R extends MCRow> MCList<R> exceptDeleteAndEmpty(MCList<R> list) {
		MCList<R> ans = list.createInstance();
		for (R row : list) {
			if (!row.isStatusDelete()) {
				if (!row.isEmpty()) {
					ans.add(row);
				}
			}
		}
		return ans;
	}

	/**
	 * 対象のリスト から 「行ステータスがDeleteではない」「空行ではない」の２つを 満たす行のリストを返します。<br>
	 * emptyRow と同値である場合に「空行」とみなします。
	 *
	 * @param <R>
	 * @param list
	 * @pram emptyRow 「空行」と同じデータを持ったインスタンス
	 * @return
	 */
	public <R extends MCRow> MCList<R> exceptDeleteAndEmpty(MCList<R> list,
			MCRow emptyRow) {
		MCList<R> ans = list.createInstance();
		for (R row : list) {
			if (!row.isStatusDelete()) {
				if (!isSame(row, emptyRow)) {
					ans.add(row);
				}
			}
		}
		return ans;
	}

	// Listからの抽出(END)===================================
	// メッセージ関連(START)===================================

	/**
	 * マルチメッセージダイアログでメッセージを表示します。<p>
	 * メッセージリストをソートします。
	 *
	 * @param list メッセージリスト
	 * @see #sortMessageList(MCMessageList)
	 */
	@Override
	public void message(MCMessageList list) {
		sortMessageList(list);
		messageNoSort(list);
	}

	/**
	 * マルチメッセージダイアログでメッセージを表示します。<p>
	 * メッセージリストをソートします。
	 *
	 * @param list メッセージリスト
	 * @param type マルチメッセージダイアログの作成方法
	 * @see #sortMessageList(MCMessageList)
	 */
	@Override
	public void message(MCMessageList list, MCFrameType type) {
		sortMessageList(list);
		messageNoSort(list, type);
	}

	/**
	 * マルチメッセージダイアログでメッセージを表示します。<p>
	 * 例外に紐付くメッセージリストが存在する場合は、そのメッセージリストをソートします。
	 *
	 * @param e 例外
	 * @see #sortMessageList(MCMessageList)
	 */
	@Override
	public void message(MCException e) {
		if (e == null) {
			super.message(e);
			return;
		}
		MCMessageList msgList = e.getCauseMessageList();
		sortMessageList(msgList);
		msgList.add(0, e.getMCMessage());
		messageNoSort(msgList);
	}

	/**
	 * マルチメッセージダイアログでメッセージを表示します。<p>
	 * 例外に紐付くメッセージリストが存在する場合は、そのメッセージリストをソートします。
	 *
	 * @param e 例外
	 * @param type マルチメッセージダイアログの作成方法
	 * @see #sortMessageList(MCMessageList)
	 */
	@Override
	public void message(MCException e, MCFrameType type) {
		if (e == null) {
			super.message(e, type);
			return;
		}
		MCMessageList msgList = e.getCauseMessageList();
		sortMessageList(msgList);
		msgList.add(0, e.getMCMessage());
		messageNoSort(msgList, type);
	}

	/**
	 * マルチメッセージダイアログでメッセージを表示します。<p>
	 * メッセージリストをソートしません。
	 *
	 * @param list メッセージリスト
	 */
	public void messageNoSort(MCMessageList list) {
		super.message(list);
	}

	/**
	 * マルチメッセージダイアログでメッセージを表示します。<p>
	 * メッセージリストをソートしません。
	 *
	 * @param list メッセージリスト
	 * @param type マルチメッセージダイアログの作成方法
	 */
	public void messageNoSort(MCMessageList list, MCFrameType type) {
		super.message(list, type);
	}

	/**
	 * メッセージリストを、メッセージのcauseRow causeColumnを元に画面に表示されている部品の順番にソートします。
	 * <p>
	 * 以下の優先度で判断する。
	 * <ol>
	 * <li>MCMessageAdapter MCMessageがnullの場合は「下」</li>
	 * <li>causeRowがnullなのが「上」</li>
	 * <li>getContainers() でより前のコンテナにマッチした方が「上」。</li>
	 * <li>【見出し項目の場合】ＧＵＩコンポーネントが取得できない場合は「下」</li>
	 * <li>【見出し項目の場合】タブオーダがマイナスなのは「下」</li>
	 * <li>【リストの場合】GUIIndexが小さい方が「上」</li>
	 * <li>【リストの場合】causeColumnがnullの方が「上」</li>
	 * <li>【テーブルの場合】テーブルのより前（左）のcolumnConfig にマッチした方が「上」</li>
	 * <li>最終的に決まらない場合は任意</li>
	 * </ol>
	 * </p>
	 *
	 * @param msgList メッセージリスト
	 */
	public void sortMessageList(MCMessageList msgList) {
		if (msgList.size() > 1) {
			MCMessageAdapter[] msgAdpt = new MCMessageAdapter[msgList.size()];
			for (int i = 0; i < msgList.size(); i++) {
				msgAdpt[i] = createMCMessageAdapter(msgList.get(i), this);
			}
			Arrays.sort(msgAdpt, createMCMessageAdapterComparator(this));
			msgList.clear();
			for (MCMessageAdapter ma : msgAdpt) {
				msgList.add(ma.msg());
			}
		}

	}

	/**
	 * MCMessageAdapter のファクトリメソッド
	 *
	 * @deprecated 共通親クラス内のみでの使用を想定しています。
	 * @deprecated MCMessageAdapter
	 * @param msg
	 * @param basePanel
	 * @return
	 */
	@Deprecated
	protected MCMessageAdapter createMCMessageAdapter(MCMessage msg,
			MCRootPanel basePanel) {
		return new MCMessageAdapter(msg, basePanel);
	}

	/**
	 * MCMessageAdapterComparator のファクトリメソッド
	 *
	 * @deprecated 共通親クラス内のみでの使用を想定しています。
	 * @param basePanel
	 * @return
	 */
	@Deprecated
	protected MCMessageAdapterComparator createMCMessageAdapterComparator(
			MCRootPanel basePanel) {
		return new MCMessageAdapterComparator(basePanel);
	}

	/**
	 * @deprecated 共通親クラス内のみでの使用を想定しています。
	 */
	@Deprecated
	public class MCMessageAdapter {
		public MCMessageAdapter(MCMessage msg, MCRootPanel basePanel) {
			_msg = msg;
			_basePanel = basePanel;
		}

		private MCMessage _msg;

		public MCMessage msg() {
			return _msg;
		}

		private MCRootPanel _basePanel;

		public MCRootPanel basePanel() {
			return _basePanel;
		}

		/**
		 * causeRowに対応するＧＵＩコンポーネントのキャッシュ
		 * @deprecated 基本的に comp() を使うことを想定
		 */
		@Deprecated
		protected JComponent _comp;

		/**
		 * causeRowに対応するＧＵＩコンポーネントを検索してあったらtrue
		 * （trueの場合はキャッシュがあるので検索をしない）
		 */
		protected boolean _isCompSearched = false;

		/**
		 * causeRowに対応するＧＵＩコンポーネントを返す。
		 * @return
		 */
		public JComponent comp() {
			if (!_isCompSearched) {
				MCMessage msg = msg();
				String causeColumn = msg.getCauseColumn();
				if (isNull(causeColumn)) {
					String[] nArray = msg.getCauseRow().getNameArray();
					if (nArray.length > 0) {
						causeColumn = nArray[0];
					}
				}
				_comp = basePanel().getComponent(msg.getCauseRow(), causeColumn);
				_isCompSearched = true;
			}
			return _comp;
		}

	}

	/**
	 * @deprecated 共通親クラス内のみでの使用を想定しています。
	 */
	@Deprecated
	public class MCMessageAdapterComparator
			implements java.util.Comparator<MCMessageAdapter> {
		public MCMessageAdapterComparator(MCRootPanel baseRootPanel) {
			_p = baseRootPanel;
		}

		// compareは2つのオブジェクトを引数に取り、最初の引数が「小さい」 ときには負の整数を、
		// 「等しい」ときには0を、「大きい」ときには
		// 正の整数を返すように実装します。
		protected static final int _0_TOP = -1;

		protected static final int _0_BOTTOM = 1;

		protected static final int _0_SAME = 0;

		protected MCRootPanel _p;

		private Map<MCList<?>, MCListBeans<?>> _listBeansMap;

		public Map<MCList<?>, MCListBeans<?>> listBeansMap() {
			if (_listBeansMap == null) {
				_listBeansMap = new IdentityHashMap<>();
			}
			return _listBeansMap;
		}

		public MCListBeans<?> getListBeans(MCList<?> list) {
			if (listBeansMap().containsKey(list)) {
			}
			else {
				JComponent comp = _p.getComponent(list);
				if (comp instanceof MCListBeans) {
					listBeansMap().put(list, (MCListBeans<?>) comp);
				}
				else {
					if (comp != null) {
						throw new MCAppException(msgUnknownClass(comp));
					}
				}
			}
			return listBeansMap().get(list);
		}

		@Override
		public int compare(MCMessageAdapter msgAdpt0, MCMessageAdapter msgAdpt1) {
			// デバッグ用（ここから）
			// int ret = compareSub(msgAdpt0, msgAdpt1);
			// return ret;
			// }
			// public int compareSub(MCMessageAdapter msgAdpt0, MCMessageAdapter msgAdpt1)
			// {
			// 前提：causeRow / causeColumn は、base であること
			// デバッグ用（ここまで）

			// 仕様１：MCMessageAdapter MCMessageがnullの場合は「下」
			if (msgAdpt0 == null) {
				return msgAdpt1 == null ? _0_SAME : _0_BOTTOM;
			}
			else if (msgAdpt1 == null) {
				return _0_TOP;
			}
			MCMessage msg0 = msgAdpt0.msg();
			MCMessage msg1 = msgAdpt1.msg();
			if (msg0 == null) {
				return msg1 == null ? _0_SAME : _0_BOTTOM;
			}
			else if (msg1 == null) {
				return _0_TOP;
			}
			// この時点で msgAdpt0 msgAdpt1 msg0 msg1は nullではない
			MCRow row0 = msg0.getCauseRow();
			MCRow row1 = msg1.getCauseRow();

			// 仕様２：causeRowがnullなのが「上」
			if (row0 == null) {
				return _0_TOP;
			}
			else if (row1 == null) {
				return _0_BOTTOM;
			}
			// この時点で row0 row1 は nullではない

			// 仕様？：同じ場合
			if (row0 == row1 && isSame(msg0.getCauseColumn(), msg1.getCauseColumn())) {
				return _0_SAME;
			}

			for (MCContainer cont : _p.getContainers()) {
				if (cont instanceof MCRow) {
					MCRow panelRow = (MCRow) cont;
					if (row0 == panelRow) {
						if (row1 != panelRow) {
							// 仕様３：getContainers() で先にマッチした方が「上」。
							return _0_TOP;
						}
						// 同じコンテナの場合
						// 仕様４：causeColumnがnullなのが「上」
						String col0 = msg0.getCauseColumn();
						String col1 = msg1.getCauseColumn();
						if (col0 == null) {
							return col1 == null ? _0_SAME : _0_TOP;
						}
						else if (col1 == null) {
							return _0_BOTTOM;
						}
						// この時点で col0 col1 は nullではない
						JComponent comp0 = msgAdpt0.comp();
						JComponent comp1 = msgAdpt1.comp();
						// 仕様５：コンポーネントが取得できない場合は「下」
						if (comp1 == null) {
							return comp0 == null ? _0_SAME : _0_TOP;
						}
						else if (comp0 == null) {
							return _0_BOTTOM;
						}

						if (comp0 == comp1) {
							return _0_SAME;
						}

						for (MCTabOrderBeans tab : _p.getTabOrderBeans()) {
							// tabOrderが若い方が上
							if (tab == comp0) {
								return _0_TOP;
							}
							if (tab == comp1) {
								return _0_BOTTOM;
							}
						}
						// 仕様８：最終的に決まらない場合は任意
						return _0_TOP;
					}
					else if (row1 == panelRow) {
						// 仕様３：getContainers() で先にマッチした方が「上」。
						return _0_BOTTOM;
					}
				}
				else if (cont instanceof MCList) {
					MCList<?> list = (MCList<?>) cont;
					MCListBeans<?> beans = getListBeans(list);
					if (beans == null) {
						continue;
					}
					if (msgAdpt0.comp() == beans) {
						if (msgAdpt1.comp() != beans) {
							// 仕様３：getContainers() で先にマッチした方が「上」。
							return _0_TOP;
						}
						// 同じコンテナの場合
						// 仕様４－０：guiIndexが小さい方が「上」
						if (row0.getGUIIndex() < row1.getGUIIndex()) {
							return _0_TOP;
						}
						else if (row1.getGUIIndex() < row0.getGUIIndex()) {
							return _0_BOTTOM;
						}
						// 仕様４：causeColumnがnullなのが「上」
						String col0 = msg0.getCauseColumn();
						String col1 = msg1.getCauseColumn();
						if (col0 == null) {
							return col1 == null ? _0_SAME : _0_TOP;
						}
						else if (col1 == null) {
							return _0_BOTTOM;
						}

						if (isSame(col0, col1)) {
							return _0_SAME;
						}

						// この時点で col0 col1 は nullではない
						if (beans instanceof MCTable) {
							MCTable<?> tbl = (MCTable<?>) beans;
							// 仕様７：より左の方が「上」
							for (MCColumnConfig conf : tbl.getColumnConfigs()) {
								if (isSame(conf.getBaseRowColumnName(), col0)) {
									return _0_TOP;
								}
								else if (isSame(conf.getBaseRowColumnName(), col1)) {
									return _0_BOTTOM;
								}
							}
							// 仕様８：最終的に決まらない場合は任意
							return _0_TOP;
						}
						throw new MCAppException(msgUnknownClass(beans));
					}
					else if (msgAdpt1.comp() == beans) {
						// 仕様３：getContainers() で先にマッチした方が「上」。
						return _0_BOTTOM;
					}

				}
				else {
					throw new MCAppException(msgUnknownClass(cont));
				}
			}
			// 仕様８：最終的に決まらない場合は任意
			return _0_TOP;
		}
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ<br>
	 * メッセージのcauseRow causeColumnには何もセットしません。
	 * <p>
	 * メッセージ<br>
	 * dt1 は dt2 の日付以降を入力してください。
	 * </p>
	 *
	 * @param dt1 本来、過去であるべき日付の名称
	 * @param dt2 本来、未来であるべき日付の名称
	 */
	public MCMessage msgNotBefore(String dt1, String dt2) {
		return FXUCP_ValidaterUtil.msgNotBefore(dt1, dt2, true);
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージを作成します。<br>
	 * メッセージに関連付ける Row の情報は下記の通りです。<p>
	 * <ol>
	 * <li>dt1 が入力不可能、かつ、dt2 が入力可能な場合<br>
	 * dt2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>dt1 が null ではない場合<br>
	 * dt1 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>dt2 が null ではない場合<br>
	 * dt2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * </ol>
	 *
	 * @param dt1 本来、過去日であるべき項目
	 * @param dt2 本来、未来日であるべき項目
	 * @return メッセージ
	 */
	public MCMessage msgNotBefore(MCRowBeans dt1, MCRowBeans dt2) {
		String msgDt1 = (dt1 == null) ? "" : dt1.getMessageByLocale();
		String msgDt2 = (dt2 == null) ? "" : dt2.getMessageByLocale();
		MCMessage ans = msgNotBefore(msgDt1, msgDt2);
		MCRowBeans c = null;
		if (!isEditable(dt1) && isEditable(dt2)) {
			c = dt2;
		}
		else if (dt1 != null) {
			c = dt1;
		}
		else if (dt2 != null) {
			c = dt2;
		}
		if (c != null) {
			ans.setCauseRow(c.getBaseRow(), c.getBaseRowColumnName());
		}
		return ans;
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージを作成します。<br>
	 * メッセージに関連付ける Row の情報は下記の通りです。<p>
	 * <ol>
	 * <li>dt1 が入力不可能、かつ、dt2 が入力可能な場合<br>
	 * dt2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>dt1 が null ではない、かつ、dt1 がテーブルに配置されている場合<br>
	 * dt1 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>dt2 が null ではない、かつ、dt2 がテーブルに配置されている場合<br>
	 * dt2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * </ol>
	 * <pre>
	 * // 使用例
	 * MCMessageList msgList = new MCMessageList();
	 * for (RsltR row : getRsltL()) {
	 * 	if (row.to_dt().before(row.fr_dt())) {
	 * 		MCMessageList.add(msgNotBefore(column_Rslt_fr_dt, column_Rslt_to_dt, row
	 * 				.getGUIIndex()));
	 * 	}
	 * }
	 * </pre>
	 *
	 * @param dt1 本来、過去日であるべきカラム
	 * @param dt2 本来、未来日であるべきカラム
	 * @param causeIndex 対象行のインデックス値
	 * @return メッセージ
	 */
	public MCMessage msgNotBefore(MCColumnConfig dt1, MCColumnConfig dt2,
			int causeIndex) {
		String msgDt1 = (dt1 == null) ? "" : dt1.getMessageByLocale();
		String msgDt2 = (dt2 == null) ? "" : dt2.getMessageByLocale();

		MCMessage ans = msgNotBefore(msgDt1, msgDt2);
		MCColumnConfig c = null;
		if (!isEditable(dt1, causeIndex) && isEditable(dt2, causeIndex)) {
			c = dt2;
		}
		else if (dt1 != null) {
			c = dt1;
		}
		else if (dt2 != null) {
			c = dt2;
		}
		if (c != null) {
			MCTable<?> t = c.getBaseTable();
			if (t != null) {
				ans.setCauseRow(t.getList().get(causeIndex).getRootRow(),
						c.getBaseRowColumnName());
			}
		}
		return ans;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ<br>
	 * メッセージのcauseRow causeColumnには何もセットしません。
	 * <p>
	 * メッセージ<br>
	 * num1 は num2 の数値以降を入力してください。
	 * </p>
	 *
	 * @param num1 本来は小さい数値の名称
	 * @param num2 本来は大きい数値の名称
	 */
	public MCMessage msgNotSmall(String num1, String num2) {
		return FXUCP_ValidaterUtil.msgNotSmall(num1, num2, true);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージを作成します。<br>
	 * メッセージに関連付ける Row の情報は下記の通りです。<p>
	 * <ol>
	 * <li>num1 が入力不可能、かつ、num2 が入力可能な場合<br>
	 * num2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>num1 が null ではない場合<br>
	 * num1 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>num2 が null ではない場合<br>
	 * num2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * </ol>
	 *
	 * @param num1 本来、小さい数値の項目
	 * @param num2 本来、大きい数値の項目
	 * @return メッセージ
	 */
	public MCMessage msgNotSmall(MCRowBeans num1, MCRowBeans num2) {
		String msgNum1 = (num1 == null) ? "" : num1.getMessageByLocale();
		String msgNum2 = (num2 == null) ? "" : num2.getMessageByLocale();
		MCMessage ans = msgNotSmall(msgNum1, msgNum2);
		MCRowBeans n = null;
		if (!isEditable(num1) && isEditable(num2)) {
			n = num2;
		}
		else if (num1 != null) {
			n = num1;
		}
		else if (num2 != null) {
			n = num2;
		}
		if (n != null) {
			ans.setCauseRow(n.getBaseRow(), n.getBaseRowColumnName());
		}
		return ans;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージを作成します。<br>
	 * メッセージに関連付ける Row の情報は下記の通りです。<p>
	 * <ol>
	 * <li>num1 が入力不可能、かつ、num2 が入力可能な場合<br>
	 * dt2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>num1 が null ではない、かつ、dt1 がテーブルに配置されている場合<br>
	 * num1 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * <li>num2 が null ではない、かつ、num2 がテーブルに配置されている場合<br>
	 * num2 の Row コンテナとカラム名をメッセージに関連付けます。
	 * </li>
	 * </ol>
	 * <pre>
	 * // 使用例
	 * MCMessageList msgList = new MCMessageList();
	 * for (RsltR row : getRsltL()) {
	 * 	if (row.l_num().before(row.s_num())) {
	 * 		MCMessageList.add(msgNotSmall(column_Rslt_s_num, column_Rslt_l_num, row
	 * 				.getGUIIndex()));
	 * 	}
	 * }
	 * </pre>
	 *
	 * @param num1 本来、小さい数値のカラム
	 * @param num2 本来、大きい数値のカラム
	 * @param causeIndex 対象行のインデックス値
	 * @return メッセージ
	 */
	public MCMessage msgNotSmall(MCColumnConfig num1, MCColumnConfig num2,
			int causeIndex) {
		String msgNum1 = (num1 == null) ? "" : num1.getMessageByLocale();
		String msgNum2 = (num2 == null) ? "" : num2.getMessageByLocale();

		MCMessage ans = msgNotSmall(msgNum1, msgNum2);
		MCColumnConfig n = null;
		if (!isEditable(num1, causeIndex) && isEditable(num2, causeIndex)) {
			n = num2;
		}
		else if (num1 != null) {
			n = num1;
		}
		else if (num2 != null) {
			n = num2;
		}
		if (n != null) {
			MCTable<?> t = n.getBaseTable();
			if (t != null) {
				ans.setCauseRow(t.getList().get(causeIndex).getRootRow(),
						n.getBaseRowColumnName());
			}
		}
		return ans;
	}

	/**
	 * 処理対象の行が選択されていない場合のメッセージ。
	 * <P>
	 * FXBAP0035 対象の行を選択してください。
	 */
	public MCMessage msgNoSelectedRow() {
		return new MCMessage(FXBAP0035);
	}

	/**
	 * 予期せぬ型がセットされていた場合のエラーメッセージ
	 */
	public MCMessage msgUnknownClass(Object unknownClassObject) {
		String t;
		if (unknownClassObject == null) {
			t = "null";
		}
		else {
			t = unknownClassObject.getClass().getSimpleName();
		}
		return new MCMessage(FXBAP0024, t);
	}

	/**
	 * 画面起動のパラメータに予期せぬ値がセットされた場合。
	 */
	public MCMessage msgUnknownOpenParam() {
		return new MCMessage(FXBAP0029, Arrays.toString(getAllParams()));
	}

	/**
	 * 削除対象が存在しない場合のメッセージ
	 */
	public MCMessage msgNoDeleteData() {
		return new MCMessage(FXBAP0017);
	}

	/**
	 * 登録対象が存在しない場合のメッセージ
	 */
	public MCMessage msgNoUpdateData() {
		return new MCMessage(FXBAP0015);
	}

	/**
	 * 印刷対象が存在しない場合のメッセージ
	 */
	public MCMessage msgNoPrintData() {
		return new MCMessage(FXBAP0083);
	}

	/**
	 * 値の変更されている箇所がないことを伝えるメッセージ
	 */
	public MCMessage msgNoDataChange() {
		return new MCMessage(FXBAP0011);
	}

	/**
	 * 削除処理の実行を確認するメッセージを返す。
	 */
	public MCMessage msgDeleteConfirm() {
		return new MCMessage(FXBAP0005);
	}

	/**
	 * 登録処理の実行を確認するメッセージを返す。
	 */
	public MCMessage msgUpdateConfirm() {
		return new MCMessage(FXBAP0006);
	}

	/**
	 * 印刷処理の実行を確認するメッセージを返す。
	 */
	public MCMessage msgPrintConfirm() {
		return new MCMessage(FXBAP0078);
	}

	/**
	 * サーバからの印刷データが存在しない場合のメッセージ
	 */
	public MCMessage msgNoDownPrintData() {
		return new MCMessage(FXBAP0086);
	}

	/**
	 * バッチ系の処理の実行を確認するメッセージ
	 */
	public MCMessage msgBatchExecConfirm() {
		return new MCMessage(FXBAP0096);
	}

	/**
	 * バッチ系の処理の実行し正常終了した時のメッセージ
	 */
	public MCMessage msgBatchExeced() {
		return new MCMessage(FXUDD9002);
	}

	/**
	 * 削除処理が終了したときのメッセージ
	 */
	public MCMessage msgDeleted() {
		return new MCMessage(FXBAP0022);
	}

	/**
	 * 登録処理が終了した時のメッセージ
	 */
	public MCMessage msgUpdated() {
		return new MCMessage(FXBAP0021);
	}

	/**
	 * 登録できなかったときのメッセージ
	 */
	public MCMessage msgUpdateFailed() {
		return new MCMessage(FXBAP0012);
	}

	/**
	 * 削除できなかったときのメッセージ
	 */
	public MCMessage msgDeleteFailed() {
		return new MCMessage(FXBAP0097);
	}

	/**
	 * 見出し項目で必須項目が未入力であった場合のエラーメッセージを作ります。
	 * <p>
	 * メッセージ本文：<br>
	 * 必須項目に値が入力されていません。項目名：{1}
	 * </p>
	 */
	public MCMessage msgNoDataAtReq(MCRowBeans gui) {
		return FXUCP_ValidaterUtil.msgNoDataAtReq(gui);
	}

	/**
	 * テーブルのある行の必須項目が未入力であった場合のエラーメッセージを作ります。
	 * <p>
	 * メッセージ本文：<br>
	 * 必須項目に値が入力されていません。行：{1} 列名：{2}
	 * </p>
	 */
	public MCMessage msgNoDataAtReq(MCRow causeRow, MCColumnConfig conf) {
		return FXUCP_ValidaterUtil.msgNoDataAtReq(causeRow, conf);
	}

	/**
	 * 見出し項目で０より大きい値を入れるべき所に０以下の値が入っていた場合のエラーメッセージを作ります。
	 * <p>
	 * メッセージ本文：<br>
	 * ０より大きい数字を入力してください。<br>
	 * 項目名：{1}
	 * </p>
	 */
	public MCMessage msgNotPositiveEx(MCRowBeans gui) {
		MCMessage msg = FXUCP_ValidaterUtil.msgNotPositive(gui.getMessageByLocale());
		msg.setCauseRow(gui.getBaseRow(), gui.getBaseRowColumnName());
		return msg;
	}

	/**
	 * テーブルで０より大きい値を入れるべき所に０以下の値が入っていた場合のエラーメッセージを作ります。
	 * <p>
	 * メッセージ本文：<br>
	 * ０より大きい数字を入力してください。<br>
	 * 列名：{1}<br>
	 * 行：{2}<br>
	 * </p>
	 */
	public MCMessage msgNotPositiveEx(MCRow causeRow, MCColumnConfig conf) {
		conf.getMessageByLocale();
		MCMessage msg = FXUCP_ValidaterUtil.msgNotPositive(conf.getMessageByLocale(),
				causeRow.getGUIIndex());
		msg.setCauseRow(causeRow.getRootRow(), conf.getBaseRowColumnName());
		return msg;
	}

	/**
	 * 入力フィールドに設定される最大文字数より多い文字を設定された場合のメッセージ
	 * <p>
	 * 使用するメッセージ：{@link FX_Msg#FXUCC0025} 又は {@link FX_Msg#FXUCC0026} 又は
	 * {@link FX_Msg#FXBAP0050}
	 * </p>
	 */
	public MCMessage msgTooLongString(MCRow row, String col) {
		MCRow msgCauseRow = null;
		String msgCauseColumn = null;
		String msgLabel = null;
		int inputLength = -1;
		int metaLength = -1;
		int guiIdx = -1;
		Comparable<?> val = null;
		boolean isGuiFound = false;

		if (row != null) {
			msgCauseRow = row.getRootRow();
			if (col != null) {
				msgCauseColumn = MCRow.createColumnPath(row.getRootRowColumnPath(), col);
				val = msgCauseRow.getValue(msgCauseColumn);

				MCMeta meta = msgCauseRow.getMeta(msgCauseColumn);
				if (MCDataType.STRING == meta.type()) {
					String str = msgCauseRow.getString(msgCauseColumn);
					if (str != null) {
						inputLength = str.length();
					}
					metaLength = meta.length();
				}

				JComponent comp = getComponent(msgCauseRow, msgCauseColumn);
				if (comp instanceof MCRowBeans) {
					MCRowBeans beans = (MCRowBeans) comp;
					msgLabel = beans.getMessageByLocale();
					isGuiFound = true;
				}
				else if (comp instanceof MCTable) {
					MCTable<?> baseTable = ((MCTable<?>) comp).getBaseTable();
					MCColumnConfig conf = baseTable.getColumnConfig(meta);
					if (conf != null) {
						msgLabel = conf.getMessageByLocale();
					}
					guiIdx = msgCauseRow.getGUIIndex();
					isGuiFound = true;
				}
			}
		}
		MCMessage msg;
		if (isGuiFound) {
			if (guiIdx >= 0) {
				msg = FXUCP_ValidaterUtil.msgTooLongString(msgLabel, guiIdx, val,
						inputLength, metaLength);

			}
			else {
				msg = FXUCP_ValidaterUtil.msgTooLongString(msgLabel, val, inputLength,
						metaLength);
			}
		}
		else {
			String className = null;
			String rowValue = null;
			if (row != null) {
				className = row.getClass().getName();
				rowValue = row.toString();
			}
			MCLog.write(FXBAP0054, className, rowValue, col);
			if (val != null) {
				msg = new MCMessage(FXBAP0050, val, inputLength, metaLength);
			}
			else {
				msg = new MCMessage(FXBAP0050);
			}

		}
		msg.setCauseRow(msgCauseRow, msgCauseColumn);
		return msg;
	}

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 * <p>
	 * 使用するメッセージ：{@link FX_Msg#FXBAP0051} 又は {@link FX_Msg#FXUCC0023} 又は
	 * {@link FX_Msg#FXUCC0024}
	 *
	 * @param row
	 * @param col
	 * @return
	 */
	public MCMessage msgInvalidNumberPrecision(MCRow row, String col) {
		MCRow msgCauseRow = null;
		String msgCauseColumn = null;
		String msgLabel = null;
		int metaLength = -1;
		int metaScale = -1;
		int guiIdx = -1;
		Comparable<?> val = null;
		boolean isGuiFound = false;

		if (row != null) {
			msgCauseRow = row.getRootRow();
			if (col != null) {
				msgCauseColumn = MCRow.createColumnPath(row.getRootRowColumnPath(), col);
				val = msgCauseRow.getValue(msgCauseColumn);

				MCMeta meta = msgCauseRow.getMeta(msgCauseColumn);
				if (MCDataType.NUMBER == meta.type()) {
					metaLength = meta.length();
					metaScale = meta.scale();
				}

				JComponent comp = getComponent(msgCauseRow, msgCauseColumn);
				if (comp instanceof MCRowBeans) {
					MCRowBeans beans = (MCRowBeans) comp;
					msgLabel = beans.getMessageByLocale();
					isGuiFound = true;
				}
				else if (comp instanceof MCTable) {
					MCTable<?> baseTable = ((MCTable<?>) comp).getBaseTable();
					MCColumnConfig conf = baseTable.getColumnConfig(meta);
					if (conf != null) {
						msgLabel = conf.getMessageByLocale();
					}
					guiIdx = msgCauseRow.getGUIIndex();
					isGuiFound = true;
				}
			}
		}
		MCMessage msg;
		if (isGuiFound) {
			if (guiIdx >= 0) {
				msg = FXUCP_ValidaterUtil.msgInvalidNumberPrecision(msgLabel, guiIdx, val,
						metaLength, metaScale);
			}
			else {
				msg = FXUCP_ValidaterUtil.msgInvalidNumberPrecision(msgLabel, val,
						metaLength, metaScale);
			}
		}
		else {
			String className = null;
			String rowValue = null;
			if (row != null) {
				className = row.getClass().getName();
				rowValue = row.toString();
			}
			MCLog.write(FXBAP0054, className, rowValue, col);
			if (val != null) {
				msg = new MCMessage(FXBAP0051, val, metaLength - metaScale, metaScale);
			}
			else {
				msg = new MCMessage(FXBAP0051);
			}
		}
		msg.setCauseRow(msgCauseRow, msgCauseColumn);
		return msg;
	}

	/**
	 * 処理を中止したときのメッセージ
	 *
	 * @return
	 */
	public MCMessage msgProcessTerminated() {
		return new MCMessage(FXBAP0028);
	}

	/**
	 * ファイル出力時に、データが存在しない場合のエラーメッセージ
	 * （メッセージレベル W）。
	 */
	public MCMessage msgNoDataForFileOut() {
		return new MCMessage(FXBAP0079);
	}

	/**
	 * ファイル取込時に、不正なデータがあったことをオペレータに
	 * 通知するメッセージ。（別途、不正なデータの詳細は、
	 * オペレータが確認できるところに出力されていることが前提）
	 */
	public MCMessage msgHasInvalidDataInFile() {
		return new MCMessage(FXBAP0080);
	}

	/**
	 * ファイル取込時に、データが存在しない場合のエラーメッセージ
	 * （メッセージレベル W）。
	 */
	public MCMessage msgNoDataForFileIn() {
		return new MCMessage(FXBAP0081);
	}

	/**
	 * [YES]/[NO] ダイアログを表示します。表示時のフォーカスがあたっている
	 * ボタンを指定することができます。
	 * <P>
	 * リソースにより、フォーカスを当てるボタンを決定できるので
	 * 特に理由がない限り、このメソッドを使用することを推奨しません。
	 * </P>
	 *
	 * @param button 初期フォーカスボタン
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 *
	 * @deprecated xAppsでは、リソースにより、フォーカスを当てるボタンを決定するので
	 * 特に理由がない限り、このメソッドを使用することを推奨しません。
	 * {@link #confirm(MCMessage)}を使って下さい。
	 */
	@Deprecated
	@Override
	public int confirm(MCDialogButton button, MCMessage msg) {
		return super.confirm(button, msg);
	}

	/**
	 * [YES]/[NO] ダイアログを表示します。
	 *
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 * @see #confirm(MCDialogButton, MCMessage)
	 * @see #confirm(String, Object[])
	 * @see #confirm(MCDialogButton, String, Object[])
	 */
	@Override
	public int confirm(String id, Object... binds) {
		return confirm(new MCMessage(id, binds));
	}

	/**
	 * [YES]/[NO] ダイアログを表示します。
	 *
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 * @see #confirm(MCDialogButton, MCMessage)
	 * @see #confirm(String, Object[])
	 * @see #confirm(MCDialogButton, String, Object[])
	 */
	@Override
	public int confirm(MCMessage msg) {
		MCDialogButton btn = getConfirmFocus(msg);
		if (btn == null) {
			btn = getConfirmFocus(FXBAP_PanelBase_CLASS_NAME);
		}
		return super.confirm(btn, msg);
	}

	/** MCAppConst でのタグ */
	protected static final String $CONFIRM_FOCUS = "confirm_focus";

	/** 画面共通親クラスのモジュールＩＤ */
	// メモ：リソースをとるのに必要
	protected static final String FXBAP_PanelBase_MODULE_ID = "FX";

	/** 画面共通親クラスの画面ＩＤ */
	// メモ：リソースをとるのに必要
	protected static final String FXBAP_PanelBase_SCREEN_ID = "FXBAP0010";

	/** 画面共通親クラスのクラス名 */
	// メモ：リソースをとるのに必要
	protected static final String FXBAP_PanelBase_CLASS_NAME = "FXBAP_PanelBase";

	/**
	 * メッセージに対応する設定がない場合は null を返します。
	 */
	public MCDialogButton getConfirmFocus(MCMessage msg) {
		String key = MCConst.createKey(FXBAP_PanelBase_MODULE_ID,
				FXBAP_PanelBase_SCREEN_ID, $CONFIRM_FOCUS, msg.getID());
		;
		MCDialogButton ret = null;
		if (MCConst.app.containsKey(key)) {
			String s = MCConst.app.getString(key);
			if (s != null) {
				boolean setting = Boolean.parseBoolean(s);
				ret = setting ? MCDialogButton.YES : MCDialogButton.NO;
			}
		}
		return ret;
	}

	/**
	 * confirmダイアログの初期フォーカスをリソースから取得します。
	 * <P>
	 * キーに対応するリソースがない場合は例外が発生します。
	 * </P>
	 *
	 * @param key 追加のキー
	 */
	public MCDialogButton getConfirmFocus(String... key) {
		String[] k;
		if (key == null) {
			k = new String[] {
					$CONFIRM_FOCUS
			};
		}
		else {
			k = new String[key.length + 1];
			k[0] = $CONFIRM_FOCUS;
			for (int i = 0; i < key.length; i++) {
				k[i + 1] = key[i];
			}
		}
		boolean setting = getPgmSettingBoolean((FXBAP_PanelBase) this, k);
		return setting ? MCDialogButton.YES : MCDialogButton.NO;
	}

	/**
	 * 編集中の登録用のデータ（＝除く検索枠のデータ）を消去してよいかダイアログを出す。
	 *
	 * @return 消去してよい場合true。それ以外false
	 */
	public boolean confirmRegDataClear() {
		return confirm(new MCMessage(FXBAP0034)) == MCMessageBox.YES_OPTION;
	}

	/**
	 * 画面のクリアをしてよいかダイアログを出す。
	 *
	 * @return 画面クリアしてよい場合 true それ以外 false
	 */
	public boolean confirmScreenClear() {
		return confirm(new MCMessage(FXBAP0009)) == MCMessageBox.YES_OPTION;
	}

	/**
	 * テーブルをクリアしてよいかダイアログを出す。
	 *
	 * @return 画面クリアしてよい場合 true それ以外 false
	 */
	public boolean confirmTableClear() {
		return confirm(new MCMessage(FXBAP0019)) == MCMessageBox.YES_OPTION;
	}

	// メッセージ関連(END)===================================
	// コンテナコピー(START) ====================================
	/**
	 * Rowの内容をコピーします。 値と属性をコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * <p>
	 * <strong>警告:</strong> このメソッドは画面行位置(GUIIndex)を変更します。
	 * コピー先のRowが画面上のテーブルに使用されている場合、画面上の情報と
	 * 不整合が生じるおそれがあるため、使用することは推奨されません。
	 * {@link #copyValue(MCRow, MCRow, MCRowMapper)}を使用してください。
	 *
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#copy(MCRow, MCRow)
	 */
	protected <D extends MCRow, S extends MCRow> void copy(D dest, S src,
			MCRowMapper<D, S> rm) {
		rm.copy(dest, src);
	}

	/**
	 * Rowの内容をコピーします。 値のみコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * <p>
	 * <strong>警告:</strong> このメソッドは画面行位置(GUIIndex)を変更します。
	 * コピー先のRowが画面上のテーブルに使用されている場合、画面上の情報と
	 * 不整合が生じるおそれがあるため、使用することは推奨されません。
	 *
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#copy(MCRow, MCRow)
	 */
	protected <D extends MCRow, S extends MCRow> void copyValue(D dest, S src,
			MCRowMapper<D, S> rm) {
		rm.copyValue(dest, src);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void setAll(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAll((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void setAllValue(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void setAll(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAll((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * コピー元の内容をコピー先をクリアした後に、追加します。
	 * <p>
	 * 引数 dest が null の場合は何も行いません。<br>
	 * 引数 src が null の場合はクリアは行いますが、何も追加しません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void setAllValue(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		if (dest != null) {
			dest.clear();
		}
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void addAll(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAll((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void addAllValue(
			D dest, S src, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) src);
	}

	/**
	 * JOINされているListの内容をコピーします。
	 * <p>
	 * 引数 dest、引数 key のいずれかまたは両方が null の場合は何も行いません。 <br>
	 * RowMapper の中で明示的にコピーしない限り、RowのAttributeはコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param dest コピー先
	 * @param key JOINキー
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#join(MCList, MCJoinKey)
	 */
	@SuppressWarnings("unchecked")
	// joinメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow> void join(
			D dest, MCJoinKey<S> key, MCRowMapper<DR, SR> rm) {
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.join((MCList<DR>) dest, (MCJoinKey<MCList<SR>>) key);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされます。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void addAll(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAll((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * コピー元の内容をコピー先に追加します。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 * RowのAttributeがコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param src コピー元
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAllValue(MCList, MCList)
	 */
	@SuppressWarnings("unchecked")
	// addAllメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void addAllValue(
			D dest, S srcList, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.addAllValue((MCList<DR>) dest, (MCList<SR>) srcList);
	}

	/**
	 * JOINされているListの内容をコピーします。
	 * <p>
	 * 引数 dest、引数 key のいずれかまたは両方が null の場合は何も行いません。 <br>
	 * RowMapper の中で明示的にコピーしない限り、RowのAttributeはコピーされません。
	 *
	 * @param <S> コピー元のListの型
	 * @param <D> コピー先のListの型
	 * @param <SR> コピー元のListのRow型
	 * @param <DR> コピー先のListのRow型
	 * @param <W> コピー時に使用する固定的な値の型
	 * @param dest コピー先
	 * @param key JOINキー
	 * @param constVal コピー時に使用する固定的な値
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#join(MCList, MCJoinKey)
	 */
	@SuppressWarnings("unchecked")
	// joinメソッドの引数のキャスト
	protected <D extends MCList<? extends DR>, S extends MCList<? extends SR>, DR extends MCRow, SR extends MCRow, W extends Object> void join(
			D dest, MCJoinKey<S> key, W constVal, FXUCC_RowMapperWith<DR, SR, W> rm) {
		rm.setWith(constVal);
		MCListMapper<DR, SR> m = new MCListMapper<>(rm);
		m.join((MCList<DR>) dest, (MCJoinKey<MCList<SR>>) key);
	}

	/**
	 * Rowの内容をコピーします。 値と属性をコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * <p>
	 * <strong>警告:</strong> このメソッドは画面行位置(GUIIndex)を変更します。
	 * コピー先のRowが画面上のテーブルに使用されている場合、画面上の情報と
	 * 不整合が生じるおそれがあるため、使用することは推奨されません。
	 * {@link #copyValue(MCRow, MCRow, Object, FXUCC_RowMapperWith)}を使用してください。
	 *
	 * @param dest コピー先
	 * @param src1 コピー元1(valueCopyメソッドの引数になる)
	 * @param src2 コピー元2(RowMapperのフィールドにセットされる)
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	protected <D extends MCRow, S extends MCRow, W extends Object> void copy(D dest,
			S src1, W src2, FXUCC_RowMapperWith<D, S, W> rm) {
		rm.setWith(src2);
		rm.copy(dest, src1);
	}

	/**
	 * Rowの内容をコピーします。 値のみコピーします。
	 * <p>
	 * 引数 dest、引数 src のいずれかまたは両方が null の場合は何も行いません。<br>
	 *
	 * @param dest コピー先
	 * @param src1 コピー元1(valueCopyメソッドの引数になる)
	 * @param src2 コピー元2(RowMapperのフィールドにセットされる)
	 * @param rm RowMapper
	 * @see mcframe.commonCore.container.MCListMapper#addAll(MCList, MCList)
	 */
	protected <D extends MCRow, S extends MCRow, W extends Object> void copyValue(D dest,
			S src1, W src2, FXUCC_RowMapperWith<D, S, W> rm) {
		rm.setWith(src2);
		rm.copyValue(dest, src1);
	}

	// コンテナコピー(END) ====================================
	// setValue関連(START)
	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	@SuppressWarnings({
			"unchecked", "rawtypes"
	})
	public void setValueEx(MCRowBeans bean, Comparable val) {
		// val のクラスキャストExをMCのエラーに変えてあげる必要があるかもしれない
		if (bean instanceof MCTextField) {
			setValueEx((MCTextField) bean, (String) val);
		}
		else if (bean instanceof MCTextArea) {
			setValueEx((MCTextArea) bean, (String) val);
		}
		else if (bean instanceof MCPasswordField) {
			setValueEx((MCPasswordField) bean, (String) val);
		}
		else if (bean instanceof MCNumberField) {
			// Integerとかをケアした方が良いかもしれない
			setValueEx((MCNumberField) bean, (MCNumber) val);
		}
		else if (bean instanceof AbsMCComboBox) {
			setValueEx((AbsMCComboBox) bean, val);
		}
		else if (bean instanceof MCCheckBox) {
			boolean b = (Boolean) val;
			setValueEx((MCCheckBox) bean, b);
		}
		else if (bean instanceof MCTimestampField) {
			setValueEx((MCTimestampField) bean, (MCTimestamp) val);
		}
		else if (bean instanceof MCDateField) {
			setValueEx((MCDateField) bean, (MCDate) val);
		}
		else if (bean instanceof MCButtonGroup) {
			setValueEx((MCButtonGroup) bean, (String) val);
		}
		else {
			throw new MCAppException(msgUnknownClass(bean));
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValuesEx(MCLinkBeans bean, MCRow val) {
		// val のクラスキャストExをMCのエラーに変えてあげる必要があるかもしれない
		if (bean instanceof MCTextField) {
			setValuesEx((MCTextField) bean, val);
		}
		else if (bean instanceof AbsMCComboBox<?>) {
			setValuesEx((AbsMCComboBox<?>) bean, val);
		}
		else {
			throw new MCAppException(msgUnknownClass(bean));
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCTextField bean, String val) {
		String org = bean.getRowValue();
		try {
			// 例外処理があるので setValueEx を使わないで良い
			MCMessageList msg = bean.setValue(val);
//			if (MCListType.FREE != bean.getListConfig().getListType()) {
			handleSetValueMessageList(bean, val, msg);
//			}
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValuesEx(MCTextField bean, MCRow val) {
		String org = bean.getRowValue();
		try {
			// 例外処理をしているので setValuesEx を使わない
			MCMessageList msg = bean.setValues(val);
//			if (MCListType.FREE != bean.getListConfig().getListType()) {
			handleSetValueMessageList(bean, val, msg);
//			}
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCTextArea bean, String val) {
		String org = bean.getRowValue();
		try {
			// 例外処理を実装しているので setValueEx を使わない
			MCMessageList msg = bean.setValue(val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCPasswordField bean, String val) {
		String org = bean.getRowValue();
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValue(val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * コンボボックスに値を設定します。
	 * 値を設定できない場合は、例外を発生させます。
	 *
	 * @param bean コンボボックス
	 * @param val 値
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public <T extends Comparable<?>> void setValueEx(AbsMCComboBox<T> bean, T val) {
		T org = bean.getRowValue();
		try {
			MCMessageList msg = bean.setValue(val);
//			if (MCListType.FREE != bean.getListType()) {
			handleSetValueMessageList(bean, val, msg);
//			}
		}
		catch (MCException ex) {
			try {
				bean.setValue(org);
			}
			catch (MCException e) {
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * コンボボックスに値を設定します。
	 * 値を設定できない場合は、例外を発生させます。
	 *
	 * @param bean コンボボックス
	 * @param val 値
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public <T extends Comparable<?>> void setValuesEx(AbsMCComboBox<T> bean, MCRow val) {
		T org = bean.getRowValue();
		try {
			MCMessageList msg = bean.setValues(val);
//			if (MCListType.FREE != bean.getListConfig().getListType()) {
			handleSetValueMessageList(bean, val, msg);
//			}
		}
		catch (MCException ex) {
			try {
				bean.setValue(org);
			}
			catch (MCException e) {
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCCheckBox bean, boolean val) {
		boolean org = bean.getRowValue();
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValue(val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCButtonGroup bean, String val) {
		String org = bean.getRowValue();
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValue(val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCNumberField bean, MCNumber val) {
		MCNumber org = bean.getRowValue();
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValue(val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	// getValueの X へのキャスト
	public <X extends MCCalendarDate<?>> void setValueEx(MCCalendarField<X> bean, X val) {
		X org = bean.getRowValue();
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValue(val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 以下のメソッド内で実行したsetValueで、エラーメッセージがあった場合は、
	 * 例外を発生させます。それ以外は、何もしません。
	 * <li>{@link #setValueEx(MCTextField, String)}</li>
	 * <li>{@link #setValuesEx(MCTextField, MCRow)}</li>
	 * <li>{@link #setValueEx(MCTextArea, String)}</li>
	 * <li>{@link #setValueEx(MCPasswordField, String)}</li>
	 * <li>{@link #setValueEx(AbsMCComboBox, Comparable)}</li>
	 * <li>{@link #setValuesEx(AbsMCComboBox, MCRow)}</li>
	 * <li>{@link #setValueEx(MCCheckBox, String)}</li>
	 * <li>{@link #setValueEx(MCButtonGroup, String)}</li>
	 * <li>{@link #setValueEx(MCNumberField, MCNumber)}</li>
	 * <li>{@link #setValueEx(MCCalendarField, MCCalendarDate)}</li>
	 * @throws FXBAP0059 値の設定に失敗した場合（メッセージレベル W）
	 */
	protected void handleSetValueMessageList(MCRowBeans bean, Comparable<?> val,
			MCMessageList msg) {
		if (msg.size() > 0) {
			MCAppException ae = new MCAppException(FXBAP0059);
			ae.setCauseMessageList(msg);
			throw ae;
		}
	}

	/**
	 * 値を設定します。 全ての行に値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValueEx(MCColumnConfig bean, Comparable<?> val) {
		MCTable<?> tbl = bean.getTable();
		if (tbl == null) {
			return;
		}
		int listSize = tbl.getList().size();
		Comparable<?>[] org = new Comparable<?>[listSize];
		int currentIdx = 0;
		try {
			for (currentIdx = 0; currentIdx < listSize; currentIdx++) {
				org[currentIdx] = bean.getValue(currentIdx);
				// 例外処理をしているので setValueEx を使わない
				MCMessageList msg = bean.setValue(currentIdx, val);
				handleSetValueMessageList(bean, val, msg);
			}
		}
		catch (MCException ex) {
			for (int i = 0; i <= currentIdx; i++) {
				try {
					// 元に入っていた値なので、基本的にセットできるはず。
					// なので setValueEx 使わない
					bean.setValue(i, org[i]);
				}
				catch (MCException e) {
					// 念のため
					MCLog.write(e);
				}
			}
			throw ex;
		}
	}

	/**
	 * 値を設定します。 全ての行に値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, Comparable, MCMessageList)
	 */
	public void setValuesEx(MCColumnConfig bean, MCRow val) {
		MCTable<?> tbl = bean.getTable();
		if (tbl == null) {
			return;
		}
		int listSize = tbl.getList().size();
		Comparable<?>[] org = new Comparable<?>[listSize];
		int currentIdx = 0;
		try {
			for (currentIdx = 0; currentIdx < listSize; currentIdx++) {
				org[currentIdx] = bean.getValue(currentIdx);
				// 例外処理をしているので setValuesEx を使わない
				MCMessageList msg = bean.setValues(currentIdx, val);
				handleSetValueMessageList(bean, val, msg);
			}
		}
		catch (MCException ex) {
			for (int i = 0; i <= currentIdx; i++) {
				try {
					// 元に入っていた値なので、基本的にセットできるはず。
					// なので setValueEx 使わない
					bean.setValue(i, org[i]);
				}
				catch (MCException e) {
					// 念のため
					MCLog.write(e);
				}
			}
			throw ex;
		}
	}

	/**
	 * 以下のメソッド内で実行したsetValueで、エラーメッセージがあった場合は、
	 * 例外を発生させます。それ以外は、何もしません。
	 * <li>{@link #setValueEx(MCColumnConfig, Comparable)}</li>
	 * <li>{@link #setValuesEx(MCColumnConfig, Comparable)}</li>
	 * @throws FCBAC0145 数字の桁あふれの場合はそのままメッセージを出す（メッセージレベル W）
	 * @throws FXBAP0059 それ以外でエラーが起きた場合（メッセージレベル E）
	 */
	protected void handleSetValueMessageList(MCColumnConfig bean, Comparable<?> val,
			MCMessageList msg) {
		if (msg.size() > 0) {
			MCAppException ae = new MCAppException(FXBAP0059);
			ae.setCauseMessageList(msg);
			throw ae;
		}
	}

	/**
	 * 値を設定します。 引数で指定された行に値を設定します。
	 * 値がセットできない場合は例外を発生させます。
	 *
	 * @param bean 値を設定するBeans
	 * @param idx 対象の行
	 * @param val 設定する値
	 *
	 * @see #handleSetValueMessageList(MCRowBeans,int, Comparable, MCMessageList)
	 */
	public void setValueEx(MCColumnConfig bean, int idx, Comparable<?> val) {
		Comparable<?> org = bean.getValue(idx);
		try {
			// 例外処理をしているので setValueEx を使わない
			MCMessageList msg = bean.setValue(idx, val);
			handleSetValueMessageList(bean, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(idx, org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}

			throw ex;
		}
	}

	/**
	 * 値を設定します。 引数で指定された行に値を設定します。
	 * 値がセットできない場合は例外を発生させます。
	 *
	 *
	 * @param bean 値を設定するBeans
	 * @param idx 対象の行
	 * @param val 設定する値
	 *
	 * @see #handleSetValueMessageList(MCRowBeans, int, Comparable, MCMessageList)
	 */
	public void setValuesEx(MCColumnConfig bean, int idx, MCRow val) {
		Comparable<?> org = bean.getValue(idx);
		try {
			// 例外処理をしているので setValuesEx を使わない
			MCMessageList msg = bean.setValues(idx, val);
			handleSetValueMessageList(bean, idx, val, msg);
		}
		catch (MCException ex) {
			try {
				// 元に入っていた値なので、基本的にセットできるはず。
				// なので setValueEx 使わない
				bean.setValue(idx, org);
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	/**
	 * 以下のメソッド内で実行したsetValueで、エラーメッセージがあった場合は、
	 * 例外を発生させます。それ以外は、何もしません。
	 * <li>{@link #setValueEx(MCColumnConfig, int,Comparable)}</li>
	 * <li>{@link #setValuesEx(MCColumnConfig, int,Comparable)}</li>
	 * @throws FCBAC0145 数字の桁あふれの場合はそのままメッセージを出す（メッセージレベル W）
	 * @throws FXBAP0059 それ以外でエラーが起きた場合（メッセージレベル E）
	 */
	protected void handleSetValueMessageList(MCColumnConfig bean, int idx,
			Comparable<?> val, MCMessageList msg) {
		if (msg.size() > 0) {
			MCAppException ae = new MCAppException(FXBAP0059);
			ae.setCauseMessageList(msg);
			throw ae;
		}
	}

	/**
	 * 値を設定します。 値がセットできない場合は例外を発生させます。
	 *
	 * @param causeBeans 値をセットするBeans（例外時に使用する）
	 * @param putter 値の設定をするために使用するputter
	 * @param i putterで使用する対象行（MCRowBeansの場合は-1）
	 * @param row putterにセットする値
	 */
	@SuppressWarnings({
			"rawtypes", "unchecked"
	})
	public void setValuesEx(MCLinkBeans causeBeans, MCListPutter putter, int i,
			MCRow row) {
		Comparable<?> org = null;
		if (causeBeans instanceof MCColumnConfig) {
			org = ((MCColumnConfig) causeBeans).getValue(i);
		}
		else if (causeBeans instanceof MCField) {
			org = ((MCField) causeBeans).getRowValue();
		}
		else if (causeBeans instanceof AbsMCComboBox<?>) {
			org = ((AbsMCComboBox) causeBeans).getRowValue();
		}
		try {
			// 例外処理をしているので setValuesEx は使わない
			MCMessageList msg = putter.setValues(i, row);
			if (msg.size() > 0) {
				MCAppException ae = new MCAppException(FXBAP0059);
				ae.setCauseMessageList(msg);
				throw ae;
			}
		}
		catch (MCException ex) {
			try {
				if (causeBeans instanceof MCColumnConfig) {
					// 元に入っていた値なので、セットできる
					// はずなので setValueEx使わない
					((MCColumnConfig) causeBeans).setValue(i, org);
				}
				else if (causeBeans instanceof MCTextField) {
					// 元に入っていた値なので、セットできる
					// はずなので setValueEx使わない
					((MCTextField) causeBeans).setValue((String) org);
				}
				else if (causeBeans instanceof AbsMCComboBox<?>) {
					// 元に入っていた値なので、セットできる
					// はずなので setValueEx使わない
					((AbsMCComboBox) causeBeans).setValue(org);
				}
				else if (causeBeans instanceof MCDateField) {
					// 元に入っていた値なので、セットできる
					// はずなので setValueEx使わない
					((MCDateField) causeBeans).setValue((MCDate) org);
				}
				else if (causeBeans instanceof MCTimestampField) {
					// 元に入っていた値なので、セットできる
					// はずなので setValueEx使わない
					((MCTimestampField) causeBeans).setValue((MCTimestamp) org);
				}
				else if (causeBeans instanceof MCNumberField) {
					// 元に入っていた値なので、セットできる
					// はずなので setValueEx使わない
					((MCNumberField) causeBeans).setValue((MCNumber) org);
				}
				else {
					throw new MCAppException(msgUnknownClass(causeBeans));
				}
			}
			catch (MCException e) {
				// 念のため
				MCLog.write(e);
			}
			throw ex;
		}
	}

	// setValue関連(END)
	// テーブル関連(START)
	/**
	 * {@link #getVisibleColumnConfigs(MCTable, String)}用のキャッシュ
	 * @deprecated {@link #getCachedVisibleColumnConfigs(MCTable, String)}
	 * {@link #putCachedVisibleColumnConfigs(MCTable, String, Set)} を使うことを想定
	 */
	@Deprecated
	@SuppressWarnings("rawtypes")
	Map<String, Map<MCTable, Set<MCColumnConfig>>> _cacheVsbleColConf;

	/**
	 * {@link #getVisibleColumnConfigs(MCTable, String)}用のキャッシュを取得する
	 * <P>
	 * type には下記の定数を指定してください。
	 * <br><br>
	 * <ul>
	 * <li> {@link #SORT_ORDER_PANEL} </li>
	 * <li> {@link #COLUMN_WIDTH_PANEL} </li>
	 * <li> {@link #ROW_FILTER_PANEL} </li>
	 * <li> {@link #SUM_INFO_PANEL} </li>
	 * </ul>
	 * </P>
	 * @param tbl
	 * @param type
	 * @return キャッシュがない場合は nullが返ります
	 */
	@SuppressWarnings("rawtypes")
	protected Set<MCColumnConfig> getCachedVisibleColumnConfigs(MCTable tbl,
			String type) {
		if (_cacheVsbleColConf == null) {
			Map<String, Map<MCTable, Set<MCColumnConfig>>> m;
			m = new HashMap<>();
			_cacheVsbleColConf = m;
		}
		Map<MCTable, Set<MCColumnConfig>> m = _cacheVsbleColConf.get(type);
		if (m == null) {
			m = new HashMap<>();
			_cacheVsbleColConf.put(type, m);
		}
		Set<MCColumnConfig> s = m.get(tbl);
		return s;
	}

	/**
	 * テーブルのvisibleColumnConfigのデフォルトを返します。戻り値は以下のうち、
	 * １つ以上を満たすMCColumnConfigの集合になります。
	 * <li> 実装仕様書の画面ステータスで一度でも「表示する」と指定したカラム</li>
	 * @param tbl
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	protected Set<MCColumnConfig> getDefaultVisibleColumnConfigs(MCTable tbl) {
		Set<MCColumnConfig> org = new HashSet<>();
		for (MCColumnConfig conf : tbl.getColumnConfigs()) {
			if (isVisibleInBaseAllStatuses(conf)) {
				org.add(conf);
			}
		}
		return org;
	}

	/**
	 * {@link #getVisibleColumnConfigs(MCTable, String)}用のキャッシュを保存する
	 * <P>
	 * type には下記の定数を指定してください。
	 * <br><br>
	 * <ul>
	 * <li> {@link #SORT_ORDER_PANEL} </li>
	 * <li> {@link #COLUMN_WIDTH_PANEL} </li>
	 * <li> {@link #ROW_FILTER_PANEL} </li>
	 * <li> {@link #SUM_INFO_PANEL} </li>
	 * </ul>
	 * </P>
	 * @param tbl
	 * @param type
	 * @param configs
	 * @return キャッシュがない場合は nullが返ります
	 */
	@SuppressWarnings("rawtypes")
	protected void putCachedVisibleColumnConfigs(MCTable tbl, String type,
			Set<MCColumnConfig> configs) {
		if (_cacheVsbleColConf == null) {
			Map<String, Map<MCTable, Set<MCColumnConfig>>> m;
			m = new HashMap<>();
			_cacheVsbleColConf = m;
		}
		Map<MCTable, Set<MCColumnConfig>> m = _cacheVsbleColConf.get(type);
		if (m == null) {
			m = new HashMap<>();
			_cacheVsbleColConf.put(type, m);
		}
		m.put(tbl, configs);
	}

	/**
	 * 画面上で表示されることのあるMCColumnConfigの配列を返します。
	 * この配列は、ソート順設定画面やカラム幅変更画面に使用されます。
	 * <P>
	 * 実装上の注意<br>
	 * このメソッドは、以下のような動きをします。
	 * <li>引数のテーブルとタイプ毎に表示するMCColumnConfigの集合をキャッシュします。</li>
	 * <li>キャッシュが存在しない場合は、{@link #getDefaultVisibleColumnConfigs(MCTable)}の戻り値
	 * とともに、 {@link #customVisibleColumnConfigs(MCTable, String, Set)} を呼び出し、結果を
	 * キャッシュします。 </li>
	 * <li>キャッシュあるいは新規に作成した、MCColumnConfigの集合を、現在のカラムの
	 * 並び順にあわせた順番に並べ替えた物をこのメソッドの戻り値とする</li>
	 *
	 * つまり、戻り値を編集する場合は、基本的に{@link #customVisibleColumnConfigs(MCTable, String, Set)}
	 * で編集することを想定しています。
	 * </P>
	 * <P>
	 * type には下記の定数を指定してください。
	 * <br><br>
	 * <ul>
	 * <li> {@link #SORT_ORDER_PANEL} </li>
	 * <li> {@link #COLUMN_WIDTH_PANEL} </li>
	 * <li> {@link #ROW_FILTER_PANEL} </li>
	 * <li> {@link #SUM_INFO_PANEL} </li>
	 * </ul>
	 * </P>
	 * @param table テーブル
	 * @param type タイプ
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public MCColumnConfig[] getVisibleColumnConfigs(MCTable table, String type) {

		Set<MCColumnConfig> set = getCachedVisibleColumnConfigs(table, type);
		if (set == null) {
			set = getDefaultVisibleColumnConfigs(table);
			customVisibleColumnConfigs(table, type, set);
			putCachedVisibleColumnConfigs(table, type, set);
		}
		MCColumnConfig[] ret;
		if (set != null) {
			List<MCColumnConfig> retList = new ArrayList<>();
			for (MCColumnConfig conf : table.getColumnConfigs()) {
				if (set.contains(conf)) {
					retList.add(conf);
				}
			}
			ret = retList.toArray(new MCColumnConfig[0]);
		}
		else {
			ret = super.getVisibleColumnConfigs(table, type);
		}
		return ret;
	}

	/**
	 * {@link #getVisibleColumnConfigs(MCTable,String)}の戻り値をカスタマイズするための
	 * メソッドです。
	 * 引数の MCColumnConfig の集合をテーブルのカラム順にソートした
	 * 物が {@link #getVisibleColumnConfigs(MCTable,String)} の戻り値となります。
	 * <P>
	 * type には下記の定数を指定してください。
	 * <br><br>
	 * <ul>
	 * <li> {@link #SORT_ORDER_PANEL} </li>
	 * <li> {@link #COLUMN_WIDTH_PANEL} </li>
	 * <li> {@link #ROW_FILTER_PANEL} </li>
	 * <li> {@link #SUM_INFO_PANEL} </li>
	 * </ul>
	 * </P>
	 * @param tbl テーブル
	 * @param type
	 * @param confSet テーブルの中にある表示される可能性があるColumnConfigの集合
	 */
	@SuppressWarnings("rawtypes")
	protected void customVisibleColumnConfigs(MCTable table, String type,
			Set<MCColumnConfig> confSet) {
		// デフォルトは何もしない
	}

	/**
	 * ベースパネルの全ての画面ステータスで一度でも表示される
	 * カラムコンフィグであるかどうか。
	 */
	protected boolean isVisibleInBaseAllStatuses(MCColumnConfig conf) {
		return isVisibleInBaseAllStatuses((MCModeBeans) conf);
	}

	/**
	 * ベースパネルの全ての画面ステータスで一度でも表示される
	 * 画面部品であるかどうか。
	 */
	protected boolean isVisibleInBaseAllStatuses(MCModeBeans conf) {
		MCRootPanel[] baseToPartsPanel = getPanelLayerList(conf.getRootPanel());
		MCRootPanel base = conf.getBaseRootPanel();
		MCRootPanel upper;
		Set<String> upperStatuses;

		if (baseToPartsPanel.length > 1) {
			upper = baseToPartsPanel[1];
			upperStatuses = new HashSet<>();
		}
		else {
			upper = null;
			upperStatuses = null;
		}

		Set<String> status = base.getStatusSet();
		if (status.size() != 0) {
			// baseの階層で設定されているかどうか？
			for (String s : status) {
				MCMode m = conf.getMode(base, s);
				if (m != null) {
					MCModeInfo mInfo = conf.getModeInfo(m);
					if (MCMode.INVISIBLE_STATUS != mInfo.getStatus()) {
						return true;
					}
				}
				else {
					if (upper != null) {
						String us = upper.getStatus(s);
						if (!isNull(us)) {
							upperStatuses.add(us);
						}
					}
				}
			}

			if (upperStatuses == null || upperStatuses.size() == 0) {
				String s = base.getInitStatus();
				if (isNull(s)) {
					s = status.toArray(new String[status.size()])[0];
				}
				MCMode m = conf.getMode(base, s);
				if (m != null) {
					if (MCMode.INVISIBLE_STATUS == conf.getModeInfo(m).getStatus()) {
						return false;
					}
				}
			}

		}
		else {
			if (MCMode.INVISIBLE_STATUS != conf.getModeInfo().getStatus()) {
				return true;
			}
		}

		for (int i = 1; i < baseToPartsPanel.length; i++) {
			MCRootPanel currentPanel = baseToPartsPanel[i];
			String[] statuses = upperStatuses.toArray(new String[0]);
			upperStatuses.clear();
			MCRootPanel upperPanel;
			if ((i + 1) < baseToPartsPanel.length) {
				upperPanel = baseToPartsPanel[i + 1];
			}
			else {
				upperPanel = null;
			}

			if (statuses.length != 0) {
				for (String s : statuses) {
					MCMode m = conf.getMode(currentPanel, s);
					if (m != null) {
						MCModeInfo mInfo = conf.getModeInfo(m);
						if (MCMode.INVISIBLE_STATUS != mInfo.getStatus()) {
							return true;
						}
					}
					else {
						if (upperPanel != null) {
							String us = upperPanel.getStatus(s);
							if (!isNull(us)) {
								upperStatuses.add(us);
							}
						}
					}
				}

				if (upperStatuses == null || upperStatuses.size() == 0) {
					String s = currentPanel.getInitStatus();
					if (isNull(s)) {
						s = status.toArray(new String[status.size()])[0];
					}
					MCMode m = conf.getMode(currentPanel, s);
					if (m != null) {
						if (MCMode.INVISIBLE_STATUS == conf.getModeInfo(m).getStatus()) {
							return false;
						}
					}
				}

			}
			else {
				if (MCMode.INVISIBLE_STATUS != conf.getModeInfo().getStatus()) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * ベースパネルの全ての画面ステータスで一度でも表示される
	 * 画面部品であるかどうか。
	 * デフォルト値はtrueにして返す。
	 * 6.4.0
	 */
	protected boolean isVisibleInBaseAllStatuses2(MCModeBeans conf) {
		MCRootPanel[] baseToPartsPanel = getPanelLayerList(conf.getRootPanel());
		MCRootPanel base = conf.getBaseRootPanel();
		MCRootPanel upper;
		Set<String> upperStatuses;

		if (baseToPartsPanel.length > 1) {
			upper = baseToPartsPanel[1];
			upperStatuses = new HashSet<>();
		}
		else {
			upper = null;
			upperStatuses = null;
		}

		Set<String> status = base.getStatusSet();
		if (status.size() != 0) {
			// baseの階層で設定されているかどうか？
			for (String s : status) {
				MCMode m = conf.getMode(base, s);
				if (m != null) {
					MCModeInfo mInfo = conf.getModeInfo(m);
					if (MCMode.INVISIBLE_STATUS != mInfo.getStatus()) {
						return true;
					}
				}
				else {
					if (upper != null) {
						String us = upper.getStatus(s);
						if (!isNull(us)) {
							upperStatuses.add(us);
						}
					}
				}
			}

			if (upperStatuses == null || upperStatuses.size() == 0) {
				String s = base.getInitStatus();
				if (isNull(s)) {
					s = status.toArray(new String[status.size()])[0];
				}
				MCMode m = conf.getMode(base, s);
				if (m != null) {
					if (MCMode.INVISIBLE_STATUS == conf.getModeInfo(m).getStatus()) {
						return false;
					}
				}
			}

		}
		else {
			if (MCMode.INVISIBLE_STATUS != conf.getModeInfo().getStatus()) {
				return true;
			}
		}

		for (int i = 1; i < baseToPartsPanel.length; i++) {
			MCRootPanel currentPanel = baseToPartsPanel[i];
			String[] statuses = upperStatuses.toArray(new String[0]);
			upperStatuses.clear();
			MCRootPanel upperPanel;
			if ((i + 1) < baseToPartsPanel.length) {
				upperPanel = baseToPartsPanel[i + 1];
			}
			else {
				upperPanel = null;
			}

			int invisibleCount = 0;
			if (statuses.length != 0) {
				for (String s : statuses) {
					MCMode m = conf.getMode(currentPanel, s);
					if (m != null) {
						MCModeInfo mInfo = conf.getModeInfo(m);
						if (MCMode.INVISIBLE_STATUS != mInfo.getStatus()) {
							return true;
						}
						invisibleCount++;
					}
					else {
						if (upperPanel != null) {
							String us = upperPanel.getStatus(s);
							if (!isNull(us)) {
								upperStatuses.add(us);
							}
						}
					}
				}
				if (upperStatuses == null || upperStatuses.size() == 0) {
					String s = currentPanel.getInitStatus();
					if (isNull(s)) {
						s = status.toArray(new String[status.size()])[0];
					}
					MCMode m = conf.getMode(currentPanel, s);
					if (m != null) {
						if (MCMode.INVISIBLE_STATUS == conf.getModeInfo(m).getStatus()) {
							return false;
						}
					}
					// 埋め込み画面で全ステータスがinvisible
					if(invisibleCount == statuses.length) {
						return false;
					}
				}
			}
			else {
				if (MCMode.INVISIBLE_STATUS != conf.getModeInfo().getStatus()) {
					return true;
				}
			}
		}
		return true;
	}

	/**
	 * リストリスナーを返します。このリスナーをセットしたリストは、
	 * 引数で指定されたリスナーがリストに所属するRowにセットされます。
	 * @param listeners {@linlk MCRowListener} または {@link MCRowStatusListener} のどちらかあるいは両方を
	 * 実装しているリスナーインスタンス
	 * @exception MCAppException  FXBAP0063 :  {@linlk MCRowListener} または {@link MCRowStatusListener}以外の
	 * {@link EventListener}がセットされた場合。
	 */
	protected MCListListener createListListener(EventListener... listeners) {
		FXBAP_ListListener listListener = new FXBAP_ListListener();
		if (listeners != null && listeners.length > 0) {
			for (EventListener listener : listeners) {
				boolean isSet = false;
				if (listener instanceof MCRowListener) {
					listListener.addRowListener((MCRowListener) listener);
					isSet = true;
				}
				if (listener instanceof MCRowStatusListener) {
					listListener.addRowStatusListener((MCRowStatusListener) listener);
					isSet = true;
				}
				if (!isSet) {
					throw new MCAppException(FXBAP0063);
				}
			}
		}
		return listListener;
	}

	/**
	 * リストリスナーをテーブルにセットします。このリスナーをセットしたリストは、
	 * 引数で指定されたリスナーがリストに所属するRowにセットされます。
	 * @param tbl テーブル
	 * @param listeners {@linlk MCRowListener} または {@link MCRowStatusListener} のどちらかあるいは両方を
	 * 実装しているリスナーインスタンス
	 * @exception MCAppException  FXBAP0063 :  {@linlk MCRowListener} または {@link MCRowStatusListener}以外の
	 * {@link EventListener}がセットされた場合。
	 */
	@SuppressWarnings("rawtypes")
	protected void setListListener(MCTable tbl, EventListener... listeners) {
		FXBAP_ListListener listListener = createFXBAP_ListListener(tbl);
		if (listeners != null && listeners.length > 0) {
			for (EventListener listener : listeners) {
				boolean isSet = false;
				if (listener instanceof MCRowListener) {
					listListener.addRowListener((MCRowListener) listener);
					isSet = true;
				}
				if (listener instanceof MCRowStatusListener) {
					listListener.addRowStatusListener((MCRowStatusListener) listener);
					isSet = true;
				}
				if (!isSet) {
					throw new MCAppException(FXBAP0063);
				}
			}
		}
		tbl.addListListener(listListener);
	}

	/**
	 * {@link #setListListener(MCTable,EventListener...)}で使用するリストリスナーのクラスを
	 * 変更する場合はこのメソッドをオーバーライドします。
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	protected FXBAP_ListListener createFXBAP_ListListener(MCTable tl) {
		return new FXBAP_ListListener();
	}

	/** 複数のメッセージ用名称をメッセージで表示する際に使用する区切り文字列 */
	protected String labelSeparator() {
		return " , ";
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合、メッセージリストにエラーメッセージを格納します。
	 * <P>
	 * リストはテーブルのsubListであることを想定しています。それ以外がセットされた場合、 例外が発生する可能性があります。
	 * </P>
	 *
	 * @param MCMessageList 結果を格納するメッセージリスト
	 * @param tblList リスト
	 * @param tbl テーブル
	 * @param cols 重複を許さないカラム
	 */
	public <E extends MCConstRow> void checkDuplicate(MCMessageList msgList,
			MCList<E> tblList, MCTable<E> tbl, String... cols) {
		if (msgList == null) {
			msgList = new MCMessageList();
		}
		if (tbl == null) {
			return;
		}
		if (tblList == null) {
			return;
		}
		if (tblList.size() < 2) {
			return;
		}
		if (cols == null) {
			return;
		}
		if (cols.length < 1) {
			return;
		}

		//チェック対象のカラムコンフィグを取得
		MCRow tblr = tblList.get(0);
		Map<String, MCColumnConfig> targetConf = new HashMap<>();
		for (String col : cols) {
			String baseColumnName;
			baseColumnName = tblr.getRootRowColumnPath(col);
			for (MCColumnConfig c : tbl.getColumnConfigs()) {
				if (isSame(c.getBaseRowColumnName(), baseColumnName)) {
					targetConf.put(col, c);
					break;
				}
			}
		}

		//重複チェック開始
		//リストをソートしたくないので、MCIndexKeyでソートしている
		MCIndexKey idx = tblList.createIndex(cols);
		E preRow = null;
		String labels = null;
		for (Iterator<E> itr = tblList.iterator(idx); itr.hasNext();) {
			E row = itr.next();

			//チェック対象の項目が、必須でnullの場合はチェックしない。(checkReqで引っかかるため)
			boolean req_is_null = false;
			for (String col : cols) {
				MCColumnConfig c = targetConf.get(col);
				MCMode m = tbl.isCellEditable(row.getGUIIndex(), c);
				if (isReqMode(m)) {
					if (isNull(row.getValue(col))) {
						req_is_null = true;
						break;
					}
				}
			}
			if (req_is_null) {
				continue;
			}

			if (preRow != null) {
				if (isColSame(preRow, row, cols)) {
					if (labels == null) {
						StringBuilder sb = new StringBuilder();
						String sep = "";
						for (String col : cols) {
							MCColumnConfig conf = targetConf.get(col);

							if (conf != null) {
								sb.append(sep);
								sb.append(conf.getMessageByLocale());
								sep = labelSeparator();
							}
							else {
								MCLog.write(FXBAP0042, col);
							}
						}
						labels = sb.toString();
					}

					int rowIdx1 = preRow.getGUIIndex();
					int rowIdx2 = row.getGUIIndex();
					if (rowIdx1 < rowIdx2) {
						MCMessage msg = FXUCP_ValidaterUtil.msgDuplicate(labels, rowIdx1,
								rowIdx2);
						msg.setCauseRow(preRow, cols[0]);
						msgList.add(msg);
					}
					else {
						MCMessage msg = FXUCP_ValidaterUtil.msgDuplicate(labels, rowIdx2,
								rowIdx1);
						msg.setCauseRow(row, cols[0]);
						msgList.add(msg);
					}
				}
			}
			preRow = row;
		}
	}

	/**
	 * 入力必須を表すモードの配列です。
	 */
	protected final MCMode[] _req_mode_arr = new MCMode[] {
			MCMode.REQUIRED
	};

	/**
	 * 入力必須を表すモードの配列を返します。
	 *
	 * @return 入力必須を表すモードの配列
	 */
	protected MCMode[] getReqMode() {
		return _req_mode_arr;
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合、メッセージリストにエラーメッセージを格納します。
	 * <P>
	 * リストはテーブルのsubListであることを想定しています。それ以外がセットされた場合、 例外が発生する可能性があります。
	 * </P>
	 *
	 * @param MCMessageList 結果を格納するメッセージリスト
	 * @param tblList リスト
	 * @param tbl テーブル
	 * @param cols 重複を許さないカラム
	 */
	public <E extends MCConstRow> void checkDuplicate(MCMessageList msgList,
			MCList<E> tblList, MCTable<E> tbl, List<String> cols) {
		checkDuplicate(msgList, tblList, tbl, cols.toArray(new String[0]));
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合、メッセージリストにエラーメッセージを格納します。
	 * <P>
	 * チェックの対象はテーブルのisEmptyではないすべての行です。
	 * </P>
	 *
	 * @param MCMessageList 結果を格納するメッセージリスト
	 * @param tbl テーブル
	 * @param cols 重複を許さないカラム
	 */
	public <E extends MCConstRow> void checkDuplicate(MCMessageList msgList,
			MCTable<E> tbl, String... cols) {
		if (msgList == null) {
			msgList = new MCMessageList();
		}
		if (tbl == null) {
			return;
		}
		MCList<E> list = tbl.getList();
		checkDuplicate(msgList, exceptEmpty(list), tbl, cols);
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合、メッセージリストにエラーメッセージを格納します。
	 * <P>
	 * チェックの対象はテーブルのisEmptyではないすべての行です。
	 * </P>
	 *
	 * @param MCMessageList 結果を格納するメッセージリスト
	 * @param tbl テーブル
	 * @param cols 重複を許さないカラム
	 */
	public <E extends MCConstRow> void checkDuplicate(MCMessageList msgList,
			MCTable<E> tbl, List<String> cols) {
		checkDuplicate(msgList, tbl, cols.toArray(new String[0]));
	}

	/**
	 * テーブルのデータをクリアします。テーブルのデータをクリアした場合は true を返します。<p>
	 * デフォルト実装<br>
	 * <ul>
	 * <li>テーブルに変更があった場合は、確認メッセージを表示する（「いいえ」ならクリアしない）。</li>
	 * </ul>
	 *
	 * @param table テーブル
	 * @return テーブルのデータをクリアしなかった場合は false
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public boolean clear(MCTable table) {
		if (table == null) {
			return false;
		}
		MCList<?> list = table.getList();
		if (list.isStatusNone() || confirmTableClear()) {
			table.clear();
			return true;
		}
		return false;
	}

	/**
	 * リストのデータクリアを行います。テーブルに直接紐付くリストの場合は、テーブルの明細クリア処理 を行います。<br>
	 * <p>
	 * <B>{@link #clear(MCTable)}または、{@link MCList#clear()} の使用をお勧めします。</B>
	 * （getComponent で対応するテーブルがあるかどうかを判断しているため）
	 * </p>
	 * <p>
	 * テーブルに直接紐付くリストの場合のデフォルト実装：
	 * <li>テーブルに変更があった場合は、確認メッセージを出す。（「いいえ」ならクリアしない）</li>
	 * </p>
	 *
	 * @param table テーブル
	 * @return テーブルのデータをクリアしなかった場合は false
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public boolean clear(MCList list) {
		JComponent comp = getComponent(list);
		if (comp instanceof MCTable) {
			return clear((MCTable<?>) comp);
		}
		if (list == null) {
			return false;
		}
		list.clear();
		return true;
	}

	/**
	 * 選択行の値をコピーした行をテーブルに追加します。<br>
	 * 属性はコピーされません。（但し、行追加なので行ステータスはCREATE）
	 * <p>
	 * テーブルがnullの場合、選択行が存在しない場合はnullを返します。
	 *
	 * @param table テーブル
	 * @return コピーしたRow(テーブルがnull 及び 選択行がない場合は、null)
	 */
	@Override
	public <E extends MCConstRow> E copyRow(MCTable<E> t) {
		if (t == null) {
			return null;
		}
		E src = t.getSelectedMCRow();
		if (src == null) {
			return null;
		}
		E dest = t.getList().createRow();

		if (!src.isEmpty()) {
			MCConstRow.copyvalue(dest, src);
			dest.setStatus(Status.CREATE);
		}
		//NCイベントがここで起こる
		//MCConstRow.copyvalueの前に持っていかないこと
		t.insertRow(dest);

		return dest;
	}

	/**
	 * 指定された行を指定箇所に移動させる
	 *
	 * @param <E>
	 * @param tbl
	 * @param fromIdx 移動前の行番号（0～tbl.getList().size()-1）
	 * @param toIdx 移動後の行番号（0～tbl.getList().size()-1）
	 * @return 移動を行ったらtrue それ以外false
	 */
	protected <E extends MCConstRow> boolean moveRow(MCTable<E> tbl, int fromIdx,
			int toIdx) {
		// テーブルが存在しない。行が存在しない場合。
		if (tbl == null || tbl.getList().isEmpty()) {
			return false;
		}
		// 変更がない場合
		if (fromIdx == toIdx) {
			return false;
		}
		// 範囲外の値が与えられた場合
		MCList<E> ls = tbl.getList();
		if (fromIdx < 0 || ls.size() <= fromIdx) {
			return false;
		}
		if (toIdx < 0 || ls.size() <= toIdx) {
			return false;
		}

		// 実処理
		E frRow = tbl.getRow(fromIdx);
		ls.remove(fromIdx);
		ls.add(toIdx, frRow);

		tbl.selectLeftmostColumn(toIdx);
		return true;
	}

	/**
	 * 指定された行を指定された行数分移動させる
	 * @param <E>
	 * @param tbl
	 * @param tarIdxes 移動対象の行番号（0～tbl.getList().size()-1）
	 * @param move どれだけ動かすか？（正の数字だと下に移動。負の数字だと上に移動）
	 * @return 移動を行ったらtrue それ以外false
	 */
	protected <E extends MCConstRow> boolean moveRows(MCTable<E> tbl, int[] tarIdxes,
			int move) {
		// テーブルが存在しない。行が存在しない場合。
		if (tbl == null || tbl.getList().isEmpty()) {
			return false;
		}

		boolean ret = false;
		int[] newIdxes = new int[tarIdxes.length];
		MCList<E> ls = tbl.getList();

		if (move < 0) {
			int prevIdx = -1;
			for (int i = 0; i < tarIdxes.length; i++) {
				int idx = tarIdxes[i];
				int newIdx = idx + move;
				if (newIdx < 0) {
					newIdx = 0;
				}
				if (newIdx <= prevIdx) {
					newIdx = prevIdx + 1;
				}
				if (newIdx < idx) {
					// 入れ替え
					E frRow = tbl.getRow(idx);
					ls.remove(idx);
					ls.add(newIdx, frRow);
					ret = true;
				}
				// 値の保存
				newIdxes[i] = newIdx;
				prevIdx = newIdx;
			}
		}
		else {
			int prevIdx = ls.size();
			for (int i = tarIdxes.length - 1; i >= 0; i--) {
				int idx = tarIdxes[i];
				int newIdx = idx + move;
				if (newIdx >= ls.size()) {
					newIdx = ls.size();
				}
				if (newIdx >= prevIdx) {
					newIdx = prevIdx - 1;
				}
				if (newIdx > idx) {
					// 入れ替え
					E frRow = tbl.getRow(idx);
					ls.remove(idx);
					ls.add(newIdx, frRow);
					ret = true;
				}
				// 値の保存
				newIdxes[i] = newIdx;
				prevIdx = newIdx;
			}

		}
		tbl.selectRowsNoFocus(newIdxes);
		return ret;
	}

	/**
	 * テーブルの選択行を１行上に移動させる
	 *
	 * @param <E>
	 * @param tbl
	 * @return 移動を行ったらtrue それ以外false
	 */
	protected <E extends MCConstRow> boolean moveUp(MCTable<E> tbl) {
		// テーブルが存在しない。行が存在しない場合。
		if (tbl == null || tbl.getList().isEmpty()) {
			return false;
		}
		boolean ans = moveRows(tbl, tbl.getMCSelectedRows(), -1);
		return ans;
	}

	/**
	 * テーブルの選択行を一番上に移動させる
	 *
	 * @param <E>
	 * @param tbl
	 * @return 移動を行ったらtrue それ以外false
	 */
	protected <E extends MCConstRow> boolean moveTop(MCTable<E> tbl) {
		// テーブルが存在しない。行が存在しない場合。
		if (tbl == null || tbl.getList().isEmpty()) {
			return false;
		}
		boolean ans = moveRows(tbl, tbl.getMCSelectedRows(), -1 * tbl.getList().size());
		return ans;
	}

	/**
	 * テーブルの選択行を１行下に移動させる
	 *
	 * @param <E>
	 * @param tbl
	 * @return 移動を行ったらtrue それ以外false
	 */
	protected <E extends MCConstRow> boolean moveDown(MCTable<E> tbl) {
		if (tbl == null || tbl.getList().isEmpty()) {
			return false;
		}
		boolean ans = moveRows(tbl, tbl.getMCSelectedRows(), 1);
		return ans;

	}

	/**
	 * テーブルの選択行を一番下に移動させる
	 *
	 * @param <E>
	 * @param tbl
	 * @return 移動を行ったらtrue それ以外false
	 */
	protected <E extends MCConstRow> boolean moveBottom(MCTable<E> tbl) {
		// テーブルが存在しない。行が存在しない場合。
		if (tbl == null || tbl.getList().isEmpty()) {
			return false;
		}
		boolean ans = moveRows(tbl, tbl.getMCSelectedRows(), tbl.getList().size());
		return ans;
	}

	// テーブル関連(END)
	// ツリー関連(START)
	/**
	 * ツリー内のノードに複数のデータをまとめて表示する
	 * 時のラベルに使用するデータを作成し、指定されたカラムにセットします。
	 * <br>
	 * ラベル文字列にする際にMCColumnConfigのフォーマットを使用して
	 * 文字列化します。
	 * <P>
	 * 補足：このメソッドはツリーに対応するデータを別途、
	 * テーブルで表示している場合にしようすることを想定しています。
	 * </P>
	 * @param list 対象のリスト
	 * @param labelCol ノードラベルに使用する文字列を格納するカラム名
	 * @param cfgs ラベルにするデータが格納されているカラムコンフィグ
	 */
	public <R extends MCRow, L extends MCList<R>> void setNodeLabel(L list,
			String labelCol, MCColumnConfig... cfgs) {
		if (isNull(list)) {
			return;
		}

		if (cfgs == null || cfgs.length <= 0) {
			return;
		}

		for (R r : list) {
			r.setStringNE(labelCol, createNodeLabel(r.getGUIIndex(), cfgs));

		}
	}

	/**
	 * ツリー内のノードに複数のデータをまとめて表示する
	 * 時のラベルを返す。
	 * <br>
	 * ラベル文字列にする際にMCColumnConfigのフォーマットを使用して
	 * 文字列化します。
	 * <P>
	 * 補足：このメソッドはツリーに対応するデータを別途、
	 * テーブルで表示している場合にしようすることを想定しています。
	 * </P>
	 * @param index ラベルにするデータが格納されている行数
	 * @param vals cfgs ラベルにするデータが格納されているカラムコンフィグ
	 */
	public String createNodeLabel(int index, MCColumnConfig... cfgs) {

		if (cfgs == null || cfgs.length <= 0) {
			return null;
		}

		List<String> vals = new ArrayList<>();

		for (MCColumnConfig c : cfgs) {
			vals.add(toString(c, index));

		}
		return createNodeLabel(vals.toArray(new String[0]));
	}

	/**
	 * ツリー内のノードに複数のデータをまとめて表示する
	 * 時のラベルを返す。
	 * @param vals ノードに表示するデータの文字列表現
	 */
	public String createNodeLabel(String... vals) {
		if (vals == null || vals.length <= 0) {
			return null;
		}

		String delim = "";
		StringBuilder label = new StringBuilder();
		for (String v : vals) {
			String t = v == null ? "" : v;
			label.append(delim).append(t);
			delim = getNodeLableDelimiter();

		}
		return label.toString();
	}

	/**
	 * ツリー内のノードに複数のデータをまとめて表示する
	 * 時に使用する、データの区切り文字列。
	 */
	protected String getNodeLableDelimiter() {
		// リソース化することを検討する
		return " - ";
	}

	// ツリー関連(END)
	// 画面の初期化関連(START)

	/**
	 * 画面の初期化処理が終了した後に実行します。
	 * 埋込画面も含めて画面全体が初期化された状態で実行されます。
	 * この画面に埋込画面が配置されている場合は埋込画面の
	 * {@link MCRootPanel#afterInit()} が先に実行されます。
	 * <br>
	 * <p>
	 * xAppsでは、各画面でこのメソッドを直接オーバーライドすることは推奨
	 * しません。このメソッド内で呼び出される各種メソッドをオーバーライド
	 * して使用してください。
	 * </p>
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 * 各画面では、このメソッドから呼び出される適切なメソッドを
	 * オーバーライドすることを検討してください。
	 */
	@Deprecated
	@Override
	public void afterInit() {
		initTrace(this, "afterInit");
		if (getBaseRootPanel() != this) {
			if (getBaseRootPanel() instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase basePanel = (FXBAP_PanelBase) getBaseRootPanel();
				basePanel.partsInitMain();
				basePanel.setupPartsMain();
			}
		}
		super.afterInit();
		listenerInit();

		if (this == getBaseRootPanel()) {
			for (FXBAP_PanelBase p : MCBeansUtil.getAllComponents(FXBAP_PanelBase.class,
					this)) {
				p.setAdjustWidth();
				p.setSortColumn();
			}
			setAdjustWidth();
			setSortColumn();
			for (MCRootPanel p : getPartsColumnRootPanels()) {
				if (p instanceof FXBAP_PanelBase) {
					FXBAP_PanelBase app = (FXBAP_PanelBase) p;
					app._customSetAdjustWidth();
					app._customSetSortColumn();
				}
			}
		}
	}

	/**
	 * partsInitを実行したかどうかを判定するフラグ （実行したらtrue）
	 * @deprecated FXBAP_PanelBase_FW のみが使用することを想定
	 */
	@Deprecated
	protected boolean _isPartsInitFlg = false;

	/**
	 * {@link #partsInit()}メソッドを呼び出すためのメソッドです。
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 */
	@Deprecated
	protected void partsInitMain() {
		// partsInitは埋め込み側から実行していく
		initTrace(this, "partsInitMain");

		if (_isPartsInitFlg == true) {
			return;
		}
		for (MCRootPanel p : getPartsPanels()) {
			if (p instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase appPanel = (FXBAP_PanelBase) p;
				appPanel.partsInitMain();
			}
		}
		partsInit();
		_isPartsInitFlg = true;
	}

	/**
	 * 埋め込み画面の初期化処理（埋め込み画面自身の初期化処理。
	 * 埋め込み画面を利用している画面が埋め込み画面を初期化するものではない）
	 * <P>
	 * 埋め込み画面のみ実装可。通常の画面は実装不可
	 */
	protected void partsInit() {
		initTrace(this, "partsInit");
	}

	/**
	 * setUpPartsしたら true
	 * @deprecated FXBAP_PanelBase_FW のみが使用することを想定
	 */
	@Deprecated
	protected boolean _isSetupPartsFlg = false;

	/**
	 * {@link #setupParts()}メソッドを呼び出すためのメソッドです。
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 */
	@Deprecated
	protected void setupPartsMain() {
		// setUpPartsは利用側から実行していく
		initTrace(this, "setUpPartsMain");
		if (_isSetupPartsFlg == true) {
			return;
		}
		setupParts();

		for (MCRootPanel p : getPartsPanels()) {
			if (p instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase appPanel = (FXBAP_PanelBase) p;
				appPanel.setupPartsMain();
			}
		}
		_isSetupPartsFlg = true;
	}

	/**
	 * 埋め込み画面のセットアップ処理（埋め込み画面利用画面が
	 * 埋め込み画面に対して何か設定をする場合に使う）
	 */
	protected void setupParts() {
		initTrace(this, "setUpParts");
	}

	/**
	 * イベントリスナーを張る処理を書きます
	 * <p>
	 * デフォルト実装：何もしない
	 * </p>
	 */
	protected void listenerInit() {
		initTrace(this, "listenerInit");
	}

	/**
	 * 画面を表示した後に実行されます。
	 * <br>
	 * なお、画面を表示するときの初期値を設定する場合は
	 * {@link #beforeOpen()} で設定してください。
	 * 画面を表示した後に値を設定した場合は画面がちらつくことがあります。
	 *
	 * <p>
	 * xAppsでは、各画面でこのメソッドを直接オーバーライドすることは推奨
	 * しません。このメソッド内で呼び出される各種メソッドをオーバーライド
	 * して使用してください。
	 * </p>
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 * 各画面では、このメソッドから呼び出される適切なメソッドを
	 * オーバーライドすることを検討してください。
	 */
	@Deprecated
	@Override
	public void afterOpen() {
		initTrace(this, "afterOpen");
		try {
			super.afterOpen();

			if (this == getBaseRootPanel()) {
				layoutAfterOpen();
				fillSpaceForOpen();
				setOpenFocus();
				afterOpenByInitParam();
			}

			if (_toolbarItem != null) {
				_toolbarItem.afterOpen();
			}
		}
		catch (MCException ex) {
			handleMCExAfterOpen(ex);
		}
	}

	/**
	 * 画面表示後のレイアウト処理を実装します。
	 */
	@Override
	public void layoutAfterOpen() {

		// 6.4.0
		if (getFrame() != null) {
			JScrollPane sp = getFrame().getScrollPane();
			// 横スクロールバーが表示されている場合は自動拡大する。
			boolean b = sp.getHorizontalScrollBar().isVisible();
			if (b == true) {
				int w = sp.getVerticalScrollBar().getPreferredSize().width;
				Dimension fs = getFrame().getSize();
				getFrame().setSize(fs.width + w, fs.height);
			}
		}
	}

	/**
	 * 画面初期化処理である {@link #afterOpen()} の中で例外が発生した
	 * 場合の処理を記述します。<br>
	 * 特に理由がない限り、引数の例外をthrowしてください。
	 * @param ex
	 * @return
	 */
	protected void handleMCExAfterOpen(MCException ex) {
		throw ex;
	}

	/** 遅延実行リスト */
	private List<MCButton> _doBehindList;

	/** 遅延実行リスト */
	protected List<MCButton> doBehindList() {
		if (_doBehindList == null) {
			_doBehindList = new ArrayList<>();
		}
		return _doBehindList;
	}

	/**
	 * 遅延実行リストをクリアします。
	 */
	protected void clearDoBehindList() {
		doBehindList().clear();
	}

	/**
	 * 指定されたボタンを遅延実行リストから除去します。
	 *
	 * @param btn 除去するボタン
	 */
	protected void removeDoBehind(MCButton btn) {
		doBehindList().remove(btn);
	}

	/**
	 * 遅延実行リストに処理を追加します。
	 */
	public void addDoBehind(MCButton... btn) {
		if (btn != null) {
			List<MCButton> ls = doBehindList();
			for (MCButton b : btn) {
				ls.add(b);
			}
		}
	}

	/**
	 * 画面連携時に、画面起動引数を用いて画面表示後の処理をします。
	 * <P>
	 * この処理の中ではメッセージダイアログなど出しても正常に表示されます。
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 * 各画面では、このメソッドから呼び出される適切なメソッドを
	 * オーバーライドすることを検討してください。
	 */
	@Deprecated
	public void afterOpenByInitParam() {
		initTrace(this, "afterOpenByInitParam()");
		Object[] objs = getAllParams();
		if (objs == null || objs.length == 0) {
			doBehind();
			setUserSrchCnd();
			return;
		}
		String openTyp = null;
		MCRow bind = null;
		Object[] args = null;
		if (objs.length > 2) {
			args = MCCollectionUtil.subArray(objs, 2, objs.length, Object.class);
		}
		else {
			args = null;
		}
		if (objs.length > 1) {
			if (objs[1] == null || objs[1] instanceof MCRow) {
				bind = (MCRow) objs[1];
			}
			else {
				throw new MCAppException(msgUnknownOpenParam());
			}
		}
		else {
			bind = null;
		}
		if (objs[0] instanceof String) {
			openTyp = (String) objs[0];
			afterOpenByInitParamCustom(openTyp, bind, args);
		}
		else {
			if (objs[0] != null) {
				throw new MCAppException(msgUnknownOpenParam());
			}
			else {
				// nullの場合は、起動引数なしと同じとみなす
				doBehind();

				setUserSrchCnd();
			}
		}
	}

	/**
	 * 起動モードが指定されている際に{@link #afterOpenByInitParam()}から呼び出されます。
	 * @param openTyp 起動モード
	 * @param bind 値のバインド
	 * @param args その他引数
	 */
	protected void afterOpenByInitParamCustom(String openTyp, MCRow bind,
			Object... args) {

		if (MCScreenOpener.SCREEN_OPEN_BY_SCREEN_OPENER.equals(openTyp)) {
			doBehind();
		}
		else {
			afterOpenByInitParam(openTyp, bind, args);
		}
	}

	/**
	 * 画面連携時に、画面起動引数を用いて画面表示後の処理をします。
	 * <P>
	 * この処理の中ではメッセージダイアログなど出しても正常に表示されます。
	 * </P>
	 * <P>
	 * デフォルト実装：遅延実行リストにあるものを実行する
	 */
	protected void afterOpenByInitParam(String openTyp, MCRow bind, Object... args) {
		doBehind();
	}

	/**
	 * 遅延実行リストにあるものを実行します。
	 */
	protected void doBehind() {
		if (isEventNeedToBehind()) {
			doBehindList().forEach(btn -> {
				MCBehindEventInfo info = new MCBehindEventInfo() {
					@Override
					protected void doBehindEvent() {
						btn.doAP();
					}
				};
				addBehindEventInfo(info);
			});
		}
		else {
			doBehindList().forEach(btn -> {
				btn.doAP();
			});
		}
		clearDoBehindList();
	}

	/**
	 * 画面起動時のフォーカスをセットします。
	 * <P>
	 * デフォルト実装：何もしない
	 * </P>
	 */
	public void setOpenFocus() {
		initTrace(this, "setOpenFocus");
	}

	/**
	 * アプリケーションの初期化処理を実行します。
	 * カスタマイズで初期化処理を追加する場合は
	 * このメソッドをオーバーライドしてください。
	 * <p>
	 * xAppsでは、各画面でこのメソッドを直接オーバーライドすることは推奨
	 * しません。このメソッド内で呼び出される各種メソッドをオーバーライド
	 * して使用してください。
	 * </p>
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 * 各画面では、このメソッドから呼び出される適切なメソッドを
	 * オーバーライドすることを検討してください。
	 */
	@Deprecated
	@Override
	protected void customInit() {
		initTrace(this, "customInit");
		super.customInit();
		labelInit();
		setCellConfig();
		if (this == this.getBaseRootPanel()) {
			setPopupConfig();
			setBeansIO();
		}
	}

	/**
	 * 画面部品に対して、
	 * {@link MCFileIOBeans#setBeansReader(MCBeansReader)}
	 * 及び
	 * {@link MCFileIOBeans#setBeansWriter(MCBeansWriter)}
	 * を実行するためのメソッドです。
	 * <P>
	 * ベース画面のみ呼び出されます。
	 * </P>
	 */
	protected void setBeansIO() {
		initTrace(this, "setBeansIO");
		// デフォルトでは何もしない。
	}

	/**
	 * ラベルを変更する。
	 */
	protected void labelInit() {
		initTrace(this, "labelInit");
	}

	/**
	 * 埋め込み画面の入力補助画面情報を集めます
	 *
	 * @deprecated 共通親クラス内のみで呼び出し、
	 * 継承可能。各画面ではlinkBeansToISPanelを使用してください
	 */
	@Deprecated
	protected void linkBeansToISPanelMain() {
		initTrace(this, "linkBeansToISPanelMain");
		if (_pluralValueEnable != null) {
			for (Map.Entry<MCLinkBeans, Boolean> e : _pluralValueEnable.entrySet()) {
				MCLinkBeans b = e.getKey();
				setPluralValueEnableAfter(b, e.getValue().booleanValue(),
						b instanceof MCTextComboBox
								? ((MCTextComboBox) b).getListConfig().getListPutter()
								: null);
			}
		}
		linkBeansToISPanel();
	}

	/**
	 * 入力補助画面と画面部品の紐付けを行う
	 * <p>
	 * デフォルト実装：何もしない
	 * </p>
	 */
	protected void linkBeansToISPanel() {
		initTrace(this, "linkBeansToISPanel");
	}

	/**
	 * 入力補助画面に紐付くオブジェクトに色を塗ります
	 * <p>
	 * デフォルト実装<br>
	 * 入力補助画面に紐付くRowBeansの枠を赤くする
	 * </p>
	 */
	protected void setLinkedISPanelColor() {
		initTrace(this, "setLinkedISPanelColor");
		for (MCRowBeans beans : getISPanelRowBeansMap().keySet()) {
			ISPanelLinker linker = getISPanelRowBeansMap().get(beans);
			if (linker != null && linker.isEnable() && !(linker.isPluralValue()
					&& (linker.moduleId().equals(getPluralValueScreenID()[0])
							&& linker.screenId().equals(getPluralValueScreenID()[1])))) {
				if (beans instanceof MCPluralValueField) {
					MCPluralValueField f = (MCPluralValueField) beans;
					if (f.isPluralValueEnable()) {
						f.setBorder(createPluralValueISBorder());
					}
					else {
						f.setBorder(createISBorder());
					}
				}
				else if (beans instanceof MCLinkBeans) {
					MCLinkBeans linkBeans = (MCLinkBeans) beans;
					linkBeans.setBorder(createISBorder());
				}
			}
		}
	}

	/**
	 * 入力補助画面が起動する GUI 部品に設定するボーダを作成します。
	 *
	 * @return 入力補助画面が起動する GUI 部品に設定するボーダ
	 */
	public Border createISBorder() {
		return new mcframe.clientCore.beans.border.MCISFieldBorder();
	}

	/**
	 * 複数値選択可能な入力補助画面が起動する GUI 部品に設定するボーダを作成します。
	 *
	 * @return 複数値選択可能な入力補助画面が起動する GUI 部品に設定するボーダ
	 */
	public Border createPluralValueISBorder() {
		return new mcframe.clientCore.beans.border.MCPluralValueISFieldBorder();
	}

	/**
	 * 画面を表示する前に実行されます。
	 * 画面を表示する場合は true を返します。
	 * <br>
	 * <p>
	 * xAppsでは、各画面でこのメソッドを直接オーバーライドすることは推奨
	 * しません。このメソッド内で呼び出される各種メソッドをオーバーライド
	 * して使用してください。
	 * </p>
	 *
	 * @deprecated 基本的に共通親クラスのみでオーバーライドすることを想定。
	 * 各画面では、このメソッドから呼び出される適切なメソッドを
	 * オーバーライドすることを検討してください。
	 */
	@Deprecated
	@Override
	public boolean beforeOpen() {
		initTrace(this, "beforeOpen");
		if (!checkReqCo()) {
			return false;
		}
		boolean ans = super.beforeOpen();

		ans = beforeOpenSub(ans);
		if (ans) {
			if (this == this.getBaseRootPanel()) {
				tableInit();
				setDefaultScreenPosition();
			}
			// initByScreenParamで入力補助画面の連携処理を使いたい場合があるので
			// initByScreenParam より linkBeansToISPanelMain の方が前
			clearDoBehindList();
			linkBeansToISPanelMain();
			setLinkedISPanelColor();
			beansAttrInit();
			customTabOrder();
			if (this == this.getBaseRootPanel()) {
				initByScreenParam();
			}
			screenOpenStatusClear();
			setPopupMenuVisible();
		}
		return ans;
	}

	/**
	 * ログインユーザが画面を開けるかどうか返します。
	 *
	 * @return 画面を開ける場合true
	 */
	protected boolean checkReqCo() {
		if (isReqCo() && isNull(MCSys.user.coCD())) {
			dialog(FXBAP0104);
			return false;
		}
		return true;
	}

	/**
	 * ログインユーザが会社にログインしていないと利用できない画面かどうかを返します。
	 *
	 * @return 会社が必須の場合true
	 */
	protected boolean isReqCo() {
		return false;
	}

	/**
	 * タブオーダを変更する。<br>
	 * 継承開発時に使用することを想定。（継承開発ではない場合は実装仕様書で対応
	 * することを想定）。
	 * <P>
	 * デフォルト実装：何もしない。
	 * </P>
	 */
	protected void customTabOrder() {
		initTrace(this, "setTabOrder");
		// 何もしない。
	}

	/**
	 * {@link #customSetSortColumn()}を下層に展開していくためのメソッド
	 *
	 * @deprecated 処理の実装は {@link #customSetSortColumn()} をオーバーライドして実装してください。
	 */
	@Deprecated
	protected void _customSetSortColumn() {
		for (MCRootPanel p : getPartsColumnRootPanels()) {
			if (p instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase app = (FXBAP_PanelBase) p;
				app._customSetSortColumn();
			}
		}
		customSetSortColumn();
	}

	/**
	 * {@link #setSortColumn()}の設定内容を調整するためのメソッドです。
	 * このメソッドは、埋込カラムの {@link MCRootPanel} のみ呼び出されます。
	 * <P>
	 * このメソッドは主に継承開発の時に使用することを想定しています。<br>
	 * 例：<br>
	 * 埋込カラムとして Ａカラム Ｂカラム Ｃカラム を提供していて、
	 * 埋込カラム利用側が、Ａカラム Ｂカラム Ｃカラムをソートキーとして採用した。
	 * これを継承して開発したプロジェクトでは Ａカラムのみ画面に表示し、 Ｂカラム及び
	 * Ｃカラムは一切画面に出さないカスタマイズをした。<br>
	 * この場合、埋込カラム利用側を修正する方法も考えられるが、埋込側で一括して
	 * 対応したい場合にこのメソッドを利用する。
	 * <pre>
	 * protected void customSetSortColumn() {
	 * 	MyTable.getBaseTable().removeSortColumn(columnCol_B,columnCol_C);
	 * }
	 * </pre>
	 * </P>
	 * <P>
	 * デフォルト実装：何もしません。
	 * </P>
	 */
	protected void customSetSortColumn() {
		initTrace(this, "customSetSortColumn");
	}

	/**
	 * {@link #customSetAdjustWidth()}を下層に展開していくためのメソッド
	 *
	 * @deprecated 処理の実装は {@link #customSetAdjustWidth()} をオーバーライドして実装してください。
	 */
	@Deprecated
	protected void _customSetAdjustWidth() {
		initTrace(this, "_customSetAdjustWidth");
		for (MCRootPanel p : getPartsColumnRootPanels()) {
			if (p instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase app = (FXBAP_PanelBase) p;
				app._customSetAdjustWidth();
			}
		}
		customSetAdjustWidth();
	}

	/**
	 * {@link #setAdjustWidth()}の設定内容を調整するためのメソッドです。
	 * このメソッドは、埋込カラムの {@link MCRootPanel} のみ呼び出されます。
	 * <P>
	 * このメソッドは主に継承開発の時に使用することを想定しています。<br>
	 * 例：<br>
	 * 埋込カラムとして Ａカラム Ｂカラム Ｃカラム を提供していて、
	 * 埋込カラム利用側が、Ａカラム Ｂカラム Ｃカラム の列幅自動調整の設定を行った。
	 * これを継承して開発したプロジェクトでは Ｃカラムに設定される値の、特性から
	 * 判断して一律、列幅自動調整を行わない方針にした。<br>
	 * これに対応する方法として、埋込カラム利用側の実装を修正する方法もあるが、
	 * 埋込側で一括で対応したいときは、このメソッドを利用する。
	 * </P>
	 * <P>
	 * デフォルト実装：何もしません。
	 * </P>
	 */
	protected void customSetAdjustWidth() {
		initTrace(this, "customSetAdjustWidth");
	}

	/**
	 * 自分自身の画面位置を設定します。画面位置サイズのパーソナライズ情報がある場合は
	 * そちらが優先されます。
	 * <P>
	 * このメソッドは、土台画面しか呼び出されません。
	 * デフォルトでは何もしません。
	 * </P>
	 */
	protected void setDefaultScreenPosition() {
		// 主に setArrangementCenter(); を実装するためのメソッド
		initTrace(this, "setDefaultScreenPosition");
	}

	/**
	 * 画面起動時の初期値設定後に行ステータスを
	 * クリアする処理です。
	 */
	protected void screenOpenStatusClear() {
		initTrace(this, "screenOpenStatusClear");
		statusClear();
	}

	/**
	 * ポップアップメニューの表示可否を設定する処理です。
	 * <P>
	 * デフォルト実装：何もしない。
	 * </P>
	 */
	protected void setPopupMenuVisible() {
		initTrace(this, "setPopupMenuVisible");
		// 何もしない
	}

	/**
	 * 実装仕様書には記述できない画面部品の属性設定を行うメソッドです。
	 * <P>
	 * 以下のような処理を実装したい場合に、本メソッドをオーバーライドして、
	 * 実装します。
	 * <ul>
	 * <li>値を設定したときに Row コンテナのステータスを変更しない場合の設定。（
	 * {@link MCRowBeans#setIgnoreStatus(boolean)} ,
	 * {@link MCColumnConfig#setIgnoreStatus(boolean)}）</li>
	 * <li>フィールドのトリムの指定をリソースの設定とは異なるものにする場合。（
	 * {@link MCTextField#setTrimPattern(String)} ,
	 * {@link MCTextComboBox#setTrimPattern(String)} ,
	 * {@link MCPasswordField#setTrimPattern(String)} ,
	 * {@link MCColumnConfig#setTrimPattern(String)}）</li>
	 * <li>テキストエリア内のタブ文字数を変更する（{@link MCTextArea#setTabSize(int)}）</li>
	 * </ul>
	 * </P>
	 * <P>
	 * 但し、上記の例やメソッド名から類推して、本メソッドに実装しても問題なさそうな処理でも、
	 * より適切なメソッドがある場合には、そちらを利用してください。代表的な例は以下の通りです。
	 * <ul>
	 * <li>ポップアップを設定する（{@link #setPopupConfig()}）</li>
	 * <li>入力補助画面を起動する（{@link #linkBeansToISPanel()}）</li>
	 * <li>コンボリストなどのリスト設定（{@link #listInit()}）</li>
	 * <li>テーブル内のカラム順を変更、ステータスカラム、行番号の列を非表示にする、
	 * 非表示だけどパーソナライズ対象の列の設定、
	 * 「ソートしないカラム」の設定。（{@link #customVisibleColumnConfigs(MCTable, String, Set)()}）</li>
	 * </ul>
	 * </P>
	 */
	protected void beansAttrInit() {
		initTrace(this, "beansAttributesInit");
		// 何もしない

	}

	/**
	 * 画面の表示可否を判断するメソッドです。
	 * 画面を表示する場合は true を返します。
	 * <P>
	 * {@link MCRootPanel#beforeOpen()} では、
	 * <ul>
	 * <li>画面の表示可否を判断する</li>
	 * <li>画面を表示するときの初期値を設定する</li>
	 * <li>その他画面を表示するときの処理を実行する</li>
	 * </ul>
	 * を行う仕様になっていますが、上位クラスの
	 * <ul>
	 * <li>画面を表示するときの初期値を設定する</li>
	 * <li>その他画面を表示するときの処理を実行する</li>
	 * </ul>
	 * の処理を行う前の段階で、「画面の表示可否を判断する」を
	 * 行いたい場合はこのメソッドをオーバーライドします。
	 * </P>
	 * <P>
	 * この処理で、falseを返すと
	 * <ul>
	 * <li>画面を表示するときの初期値を設定する</li>
	 * <li>その他画面を表示するときの処理を実行する</li>
	 * </ul>
	 * の処理を行わずに画面起動を中止します。
	 * </P>
	 * @param b インフラの beforeOpen メソッドの戻り値
	 * @return 画面を表示しない場合は false
	 */
	protected boolean beforeOpenSub(boolean b) {
		// メモ：通常、画面を起動したくない場合（＝起動できない場合）
		// は、beforeOpenの処理中に例外をthrowすれば、
		// 画面が起動しないので、beforeOpenでfalseを返すケースは
		// ほとんどないというのが基本である。
		// しかしながら、インフラの画面で、情報を表示するだけの画面を
		// 作りたい場合に、メッセージダイアログを表示して
		// 通常の画面は一切表示はしない。カスタマイズで、もっと
		// 豪華な画面にしたい場合は、この画面を継承して
		// メッセージダイアログを出さずに、通常画面起動するような
		// ことをしたいので、本メソッドを作った
		return b;
	}

	/**
	 * 実装する内容
	 * <li>カラム順変更</li>
	 * <li>ステータスカラム、行番号の列を非表示にする</li>
	 * <li>「ソートしないカラム」の設定（setSortable）</li>
	 */
	protected void tableInit() {
		initTrace(this, "tableInit");
		// 何もしない
	}

	/**
	 * カラムのソート順のデフォルト値を設定します。
	 * <P>
	 * 埋込カラムのMCRootPanelは呼び出されません
	 * </P>
	 */
	protected void setSortColumn() {
		initTrace(this, "setSortColumn");
		// 何もしない
	}

	/**
	 * カラムの列幅自動調整のデフォルト値を設定します。
	 * <P>
	 * 埋込カラムのMCRootPanelは呼び出されません
	 * </P>
	 */
	protected void setAdjustWidth() {
		initTrace(this, "setAdjustWidth");
	}

	/**
	 * 画面の起動パラメータ（getParam(int)）を使用した 画面の初期化を実装します。
	 *
	 * @deprecated 共通親クラスのみ継承および使用可能。各画面での実装は
	 *             {@link #initByScreenParam(String, MCRow, Object...)} を使ってください。
	 */
	@Deprecated
	protected void initByScreenParam() {
		initTrace(this, "initByScreenParam()");
		Object[] objs = getAllParams();
		if (objs == null || objs.length == 0) {
			valueInit();
			return;
		}
		String openTyp = null;
		MCRow bind = null;
		Object[] args = null;
		if (objs.length > 2) {
			args = MCCollectionUtil.subArray(objs, 2, objs.length, Object.class);
		}
		else {
			args = null;
		}
		if (objs.length > 1) {
			if (objs[1] == null || objs[1] instanceof MCRow) {
				bind = (MCRow) objs[1];
			}
			else {
				throw new MCAppException(msgUnknownOpenParam());
			}
		}
		else {
			bind = null;
		}
		if (objs[0] instanceof String) {
			openTyp = (String) objs[0];
			initByScreenParamCustom(openTyp, bind, args);
		}
		else {
			if (objs[0] != null) {
				throw new MCAppException(msgUnknownOpenParam());
			}
			else {
				// nullの場合は、起動引数なしと同じとみなす
				valueInit();
			}
		}
	}

	/**
	 * 起動モードが指定されている際に{@link #initByScreenParam()}から呼び出されます。
	 * @param openTyp 起動モード
	 * @param bind 値のバインド
	 * @param args その他引数
	 */
	protected void initByScreenParamCustom(String openTyp, MCRow bind, Object... args) {

		if (MCScreenOpener.SCREEN_OPEN_BY_SCREEN_OPENER.equals(openTyp)) {
			valueInit();
		}
		else {
			// バーコード対応
			if (openTyp != null && openTyp.startsWith("barcode_id=")) {
				valueInit();
			}
			initByScreenParam(openTyp, bind, args);
		}
	}

	/**
	 * 他画面から呼び出された場合の初期化を実装します。<br>
	 * 以下、各画面で本メソッドをオーバーライドするときのテンプレ（ここから）
	 * <P>
	 * <P>
	 * <li>起動タイプ：T1 （補足があるならここに書く）<br>
	 * バインド値 ＜必須＞<br>
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>itm_cd</td>
	 * <td>String</td>
	 * <td>必須</td>
	 * </tr>
	 * <tr>
	 * <td>qty</td>
	 * <td>MCNumber</td>
	 * <td></td>
	 * </tr>
	 * </table><br>
	 * その他の引数：なし</li>
	 * <li>起動タイプ：T2<br>
	 * バインド値 ...以下繰り返し </li>
	 * </P>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @pram args その他の引数
	 *       </P>
	 *       テンプレ（ここまで）
	 */
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		initTrace(this, "initByScreenParam");
	}

	/**
	 * 画面のデフォルト値のセットはここで行います。
	 * <P>
	 * デフォルト実装；埋込画面のvalueInitを呼び出す。
	 */
	protected void valueInit() {
		initTrace(this, "valueInit");
		partsValueInit();
	}

	/**
	 * 埋込画面のvalueInitを呼び出す。
	 */
	protected void partsValueInit() {
		initTrace(this, "partsValueInit");
		for (MCRootPanel parts : getPartsPanels()) {
			if (parts instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase appParts = (FXBAP_PanelBase) parts;
				appParts.valueInit();
			}
		}
	}

	/**
	 * 画面に配置されているテーブルの中で、
	 * 埋め込みカラムを使用している場合、
	 * 埋め込みカラムの {@link MCRootPanel} の
	 * 配列を返します。
	 * @return 埋め込みカラムの {@link MCRootPanel} の配列
	 */
	public MCRootPanel[] getPartsColumnRootPanels() {
		List<MCTable<?>> baseTbls = new ArrayList<>();
		for (MCContainer cont : getContainers()) {
			if (cont instanceof MCList) {
				MCList<?> list = (MCList<?>) cont;
				Component comp = getComponent(list);
				if (comp instanceof MCTable) {
					baseTbls.add((MCTable<?>) comp);
				}
			}
		}

		List<MCRootPanel> panels = new ArrayList<>();

		for (MCTable<?> tbl : baseTbls) {
			MCTable<?>[] array = tbl.getPartsTables();
			for (MCTable<?> parts : array) {
				MCRootPanel p = parts.getRootPanel();
				if (!panels.contains(p)) {
					panels.add(p);
				}
			}
		}
		return panels.toArray(new MCRootPanel[0]);
	}

	/**
	 * CellConfigをセットする場合はこのメソッドをオーバーライドします。
	 * <P>
	 * デフォルト実装：<br>
	 * 全てのテーブルにアプリデフォルトcellConfigをセットする
	 * </p>
	 */
	protected void setCellConfig() {
		initTrace(this, "setCellConfig");
		FXBAP_CellConfig cellConfig = null;
		for (MCContainer cont : getContainers()) {
			if (cont instanceof MCList) {
				MCList<?> list = (MCList<?>) cont;
				JComponent comp = getComponent(list);
				if (comp instanceof MCTable) {
					MCTable<?> tbl = (MCTable<?>) comp;
					if (cellConfig == null) {
						cellConfig = createDefaultAppCellConfig();
					}
					tbl.setCellConfig(cellConfig);
				}
			}
		}
	}

	/**
	 * アプリケーションが使用するデフォルトのセルコンフィグ
	 * @deprecated 共通親クラスのみがオーバーライド呼び出し可能
	 */
	@Deprecated
	protected FXBAP_CellConfig createDefaultAppCellConfig() {
		return new FXBAP_CellConfig();
	}

	/**
	 * PopupConfigをセットする場合はこのメソッドをオーバーライドします。
	 * <P>
	 * デフォルト実装：<br>
	 * 全てのテーブルにアプリデフォルトpopupConfigをセットする
	 * </p>
	 */
	protected void setPopupConfig() {
		initTrace(this, "setPopupConfig");
		for (MCContainer cont : getContainers()) {
			if (cont instanceof MCList) {
				MCList<?> list = (MCList<?>) cont;
				JComponent comp = getComponent(list);
				if (comp instanceof MCTable) {
					MCTable<?> tbl = (MCTable<?>) comp;
					if (isSetDefaultPopupConfig(tbl)) {
						setPopupConfig(tbl);
					}
				}
			}
		}
		if (this == this.getBaseRootPanel()) {
			if (isSetDefaultPopupConfig(this)) {
				setPopupConfig(this);
			}
		}
		setPopupConfigButton(getComponents());
	}

	/**
	 * ボタンにPopupConfigを設定します。
	 *
	 * @param cs コンポーネント
	 */
	protected void setPopupConfigButton(Component[] cs) {
		for (Component c : cs) {
			if (c instanceof MCButton && isSetDefaultPopupConfig((MCButton) c)) {
				setPopupConfig((MCButton) c);
			}
			if (c instanceof Container) {
				setPopupConfigButton(((Container) c).getComponents());
			}
		}
	}

	/**
	 * デフォルトポップアップコンフィグを設定する場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return デフォルトポップアップコンフィグを設定しない場合は false
	 */
	protected boolean isSetDefaultPopupConfig(MCPopupBeans compo) {
		if (compo instanceof MCRootPanel) {
			MCRootPanel p = (MCRootPanel) compo;
			if (p.isPartsFlag() || p.isPartsPanel()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * ポップアップコンフィグを設定します。
	 * 指定されたポップアップコンフィグを、この画面と、
	 * この画面に配置されている全ての埋込画面に設定します。
	 *
	 * @param config ポップアップコンフィグ
	 */
	protected void setPopupConfigAllPanel(FXBAP_PopupConfig config) {
		setPopupConfigAllPanel(this, config);
	}

	/**
	 * @deprecated {@link #setPopupConfigAllPanel(FXBAP_PopupConfig)} を利用してください。
	 * 共通親クラスでオーバーライドすることを想定しています。
	 *
	 * @param panel 画面
	 * @param config ポップアップコンフィグ
	 */
	@Deprecated
	protected void setPopupConfigAllPanel(MCRootPanel panel, FXBAP_PopupConfig config) {
		panel.setPopupConfig(config);
		for (MCRootPanel p : panel.getPartsPanels()) {
			p.setPopupConfig(config);
			setPopupConfigAllPanel(p, config);
		}
	}

	/**
	 * PopupConfigを設定する。
	 * <P>
	 * 独自のPopupConfigをセットする場合はこのメソッドをオーバーライドして設定する。
	 * </P>
	 * <P>
	 * アプリデフォルトのPopupConfigを使用して、設定のみを変更する場合は
	 * {@link #createFXBAP_PopupConfig(MCTable)}をオーバーライドするのをお勧めします。
	 * </P>
	 * @param tbl
	 */
	// MCTableのジェネリクス
	protected void setPopupConfig(MCPopupBeans beans) {
		beans.setPopupConfig(createFXBAP_PopupConfig(beans));
	}

	/**
	 * アプリデフォルトのPopupConfigを作成します。<br>
	 * オーバーライドして特定のテーブルの場合のみ、 PopupConfig の設定を変更することができます。
	 *
	 * <pre>
	 * &#064;Override
	 * protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
	 * 	FXBAP_PopupConfig conf = super.createFXBAP_PopupConfig(beans);
	 * 	if (beans == RsltTable) {
	 * 		conf.ignoreSortOrder(true);
	 * 	}
	 * 	return conf;
	 * }
	 * </pre>
	 *
	 * @param tbl
	 * @return
	 */
	// MCTableのジェネリクス
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		return new FXBAP_PopupConfig();
	}

	/**
	 * 検索枠展開の設定を切り替え、パーソナライズ情報として保存します。
	 * @since     7.0.1.2
	 * @param b true 「自動で閉じない」に切り替える、 false 「デフォルト」に切り替える
	 */
	public void setExpandMode(boolean b) {
		// FXBAP_PopupConfigで使うためにpublic
		MCConst.beans.setBoolean(_expandunitKey, b);
		MCConst.saveUser();
		_expandunitMode = b;
	}

	/**
	 * 検索枠展開のモードを返します。
	 * @since     7.0.1.2
	 * @return true 検索枠を自動で閉じない<br>
	 * 			false 画面実装のとおり動く
	 * @see mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit#expand(boolean)
	 */
	public boolean getExpandMode() {
		return _expandunitMode;
	}

	// 画面の初期化関連( END )
	// 画面連携用(START)
	/**
	 * 画面起動タイプ：タイプ１
	 */
	public static final String T1 = "T1";

	/**
	 * 画面起動タイプ：タイプ２
	 */
	public static final String T2 = "T2";

	/**
	 * 画面起動タイプ：タイプ３
	 */
	public static final String T3 = "T3";

	/**
	 * 画面起動タイプ：タイプ４
	 */
	public static final String T4 = "T4";

	/**
	 * 画面起動タイプ：タイプ５
	 */
	public static final String T5 = "T5";

	/**
	 * 画面起動タイプ：タイプ６
	 */
	public static final String T6 = "T6";

	/**
	 * 画面起動タイプ：タイプ７
	 */
	public static final String T7 = "T7";

	/**
	 * 画面起動タイプ：タイプ８
	 */
	public static final String T8 = "T8";

	/**
	 * 画面起動タイプ：タイプ９
	 */
	public static final String T9 = "T9";

	// メモ：
	// 画面起動は色々な起動方法があるが、結局は下記の４通り
	// ぐらいしか使わないという見解になった。
	// ・モーダレスで画面を起動
	// ・モーダレスで子画面
	// ・モーダルで起動
	// ・システムモーダルで起動

	/**
	 * 画面の表示方法を返します。<p>
	 * MCScreen リソースの設定値を返します。
	 * 未設定の場合は {@link MCPanelType#SINGLE} を返します。
	 *
	 * @param moduleId モジュールID
	 * @param screenId 画面ID
	 * @return 画面の表示方法
	 */
	public MCPanelType getPanelType(String moduleId, String screenId) {
		String attr = MCConst.screen.getPanelType(moduleId, screenId);
		return (attr != null && attr.equalsIgnoreCase("MULTI")) ? MCPanelType.MULTI
				: MCPanelType.SINGLE;
	}

	/**
	 * モーダレスで画面を起動します
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @param bind 画面起動時のバインド値
	 * @param args その他の起動引数
	 * @return 起動した画面のシリアル番号
	 */
	public int openPanel(String moduleId, String screenId, String openTyp, MCRow bind,
			Object... args) {

		MCRootPanel panel = null;

		Object[] objs = {
				openTyp, bind
		};
		objs = MCCollectionUtil.concat(objs, args);
		MCPanelType paneTyp = getPanelType(moduleId, screenId);

		if (MCPanelType.SINGLE == paneTyp || MCPanelType.SCREEN_SINGLE == paneTyp) {
			while (true) {
				panel = MCBeansUtil.getRootPanel(moduleId, screenId, null);
				if (panel == null) {
					break;
				}
				panel.moveToFront();

				// 7013-0086 通信中の場合は再利用しない
				if (panel.getFrame().isCalling()) {
					return panel.getSerial();
				}
				
				if (!panel.getFrame().canActive()) {
					return panel.getSerial();
				}

				// #7022-1838 修正前の動作にする場合（既存画面再利用）
				if (!OPEN_PANEL_RECREATE_SCREEN) {
					if (panel instanceof FXBAP_PanelBase) {
						FXBAP_PanelBase appPanel = (FXBAP_PanelBase) panel;
						appPanel.setParam(objs);
						appPanel.reshowInit();
						appPanel.afterOpenByInitParam();
					}
					return showPanel(panel, paneTyp, objs);
				}
				// #7022-1838 開いている画面を閉じて画面を再作成する
				if (!closeScreen(panel)) {
					return panel.getSerial();
				}
			}
		}
		
		panel = createPanel(moduleId, screenId, MCFrameType.MODELESS, objs);
		return showPanel(panel, paneTyp, objs);
	}

	/**
	 * モーダレスで画面を起動します。画面起動引数なしで起動
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @return 起動した画面のシリアル番号
	 */
	public int openPanel(String moduleId, String screenId) {
		return openPanel(moduleId, screenId, (String) null, null);
	}

	/**
	 * モーダレスで画面を起動します。（バインド値が不要な場合）
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @return 起動した画面のシリアル番号
	 */
	public int openPanel(String moduleId, String screenId, String openTyp) {
		return openPanel(moduleId, screenId, openTyp, null);
	}

	/**
	 * モーダレスで子画面を起動します
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param paneTyp 画面の表示方法
	 * @param openTyp 起動タイプ
	 * @param bind 画面起動時のバインド値
	 * @param args その他の起動引数
	 * @deprecated {@link #openChildPanel(String, String, String, MCRow, Object...)}を使うことを推奨
	 * @return 起動した画面のシリアル番号
	 */
	@Deprecated
	public int openChildPanel(String moduleId, String screenId, MCPanelType paneTyp,
			String openTyp, MCRow bind, Object... args) {

		MCRootPanel panel = null;

		Object[] objs = {
				openTyp, bind
		};
		objs = MCCollectionUtil.concat(objs, args);

		if (MCPanelType.SINGLE == paneTyp || MCPanelType.SCREEN_SINGLE == paneTyp) {
			// 親画面が異なる画面は再利用できない
			panel = MCBeansUtil.getRootPanel(moduleId, screenId, this);
		}

		// 再利用できる画面がある場合
		if (panel != null) {
			panel.moveToFront();

			// 7013-0086 通信中の場合は再利用しない
			if (panel.getFrame().isCalling()) {
				return panel.getSerial();
			}

			if (!panel.getFrame().canActive()) {
				return panel.getSerial();
			}
			
			// #7022-1838 修正前の動作にする場合（既存画面再利用）
			if (!OPEN_PANEL_RECREATE_SCREEN) {
					if (panel instanceof FXBAP_PanelBase) {
						FXBAP_PanelBase appPanel = (FXBAP_PanelBase) panel;
						appPanel.setParam(objs);
						appPanel.reshowInit();
						appPanel.afterOpenByInitParam();
					}
					return showChildPanel(panel, paneTyp, objs);
				}

			// #7022-1838 開いている画面を閉じて画面を再作成する
			if (!closeScreen(panel)) {
				return panel.getSerial();
			}
		}
		
		panel = createPanel(moduleId, screenId, MCFrameType.MODELESS, objs);
		return showChildPanel(panel, paneTyp, objs);
	}

	/**
	 * 指定された画面を閉じます。
	 *
	 * @param rp 画面
	 * @return 閉じた場合 true
	 */
	protected boolean closeScreen(MCRootPanel rp) {
		rp.requestCloseWindow();
		// 閉じたか確認
		MCRootPanel[] rps2 = MCBeansUtil.getAllRootPanels();
		for (MCRootPanel rp2 : rps2) {
			if (rp2 == rp) {
				return false;
			}
		}
		return true;
	}

	/**
	 * モーダレスで子画面を起動します
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @param bind 画面起動時のバインド値
	 * @param args その他の起動引数
	 * @return 起動した画面のシリアル番号
	 */
	public int openChildPanel(String moduleId, String screenId, String openTyp,
			MCRow bind, Object... args) {
		MCPanelType paneTyp = getPanelType(moduleId, screenId);
		return openChildPanel(moduleId, screenId, paneTyp, openTyp, bind, args);
	}

	/**
	 * モーダレスで子画面を起動します。画面起動引数なしで起動。
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @return 起動した画面のシリアル番号
	 */
	public int openChildPanel(String moduleId, String screenId) {
		return openChildPanel(moduleId, screenId, (String) null, null);
	}

	/**
	 * モーダレスで子画面を起動します。（バインド値が不要な場合）
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @return 起動した画面のシリアル番号
	 */
	public int openChildPanel(String moduleId, String screenId, String openTyp) {
		return openChildPanel(moduleId, screenId, openTyp, null);
	}

	/**
	 * モーダルで子画面を起動します
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @param bind 画面起動時のバインド値
	 * @param args その他の起動引数
	 * @return 起動した画面のシリアル番号
	 */
	public int openModalPanel(String moduleId, String screenId, String openTyp,
			MCRow bind, Object... args) {
		Object[] objs = {
				openTyp, bind
		};
		objs = MCCollectionUtil.concat(objs, args);
		MCRootPanel panel = createPanel(moduleId, screenId, MCFrameType.SCREEN_MODAL,
				objs);
		return showChildPanel(panel, MCPanelType.MULTI, objs);
	}

	/**
	 * モーダルで子画面を起動します。画面起動引数なしで起動。
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @return 起動した画面のシリアル番号
	 */
	public int openModalPanel(String moduleId, String screenId) {
		return openModalPanel(moduleId, screenId, (String) null, null);
	}

	/**
	 * モーダルで子画面を起動します（バインド値が不要な場合）
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @return 起動した画面のシリアル番号
	 */
	public int openModalPanel(String moduleId, String screenId, String openTyp) {
		return openModalPanel(moduleId, screenId, openTyp, null);
	}

	/**
	 * システムモーダルで子画面を起動します
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @param bind 画面起動時のバインド値
	 * @param args その他の起動引数
	 * @return 起動した画面のシリアル番号
	 */
	protected int openSystemModalPanel(String moduleId, String screenId, String openTyp,
			MCRow bind, Object... args) {
		Object[] objs = {
				openTyp, bind
		};
		objs = MCCollectionUtil.concat(objs, args);
		MCRootPanel panel = createPanel(moduleId, screenId, MCFrameType.SYSTEM_MODAL,
				objs);
		return showChildPanel(panel, MCPanelType.SINGLE, objs);
	}

	/**
	 * システムモーダルで子画面を起動します。画面起動引数なしで起動。
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @return 起動した画面のシリアル番号
	 */
	public int openSystemModalPanel(String moduleId, String screenId) {
		return openSystemModalPanel(moduleId, screenId, (String) null, null);
	}

	/**
	 * システムモーダルで子画面を起動します（バインド値が不要な場合）
	 *
	 * @param moduleId 起動する画面のモジュールＩＤ
	 * @param screenId 起動する画面の画面ＩＤ
	 * @param openTyp 起動タイプ
	 * @return 起動した画面のシリアル番号
	 */
	public int openSystemModalPanel(String moduleId, String screenId, String openTyp) {
		return openSystemModalPanel(moduleId, screenId, openTyp, null);
	}

	/**
	 * 画面連携用のメソッドです。呼び出しもとの画面がopenPanel または openChildPanel を 呼びだした際に、既に呼び出し先の画面が表示されている場合に
	 * このメソッドが呼び出されます。
	 * <P>
	 * デフォルト実装：screenClear相当の処理＋initByScreenParam
	 * </P>
	 */
	public void reshowInit() {
		if (screenClearConfirm()) {
			screenClearBody();
			screenClearSetMode();
			// screenClearと違う（ここから）
			statusClear(); // 新規の画面起動は、ここまで値設定がされていない状況なので、ステータスは全部NONE
			clearDoBehindList();
			initByScreenParam();
			statusClear(); // 新規の画面起動は、初期値設定の後にステータスをクリアしている。
			// メモ：画面再表示時にはデフォルト値設定呼ばない。
			// 画面起動引数がない場合は（initByScreenParam内で呼び出されるはず。
			// 面起動引数がある場合は画面起動引数の初期値設定処理を呼ぶのが仕様。
			// screenClearSetDefault();
			// screenClearと違う（ここまで）
			screenClearSetFocus();
		}
	}

	// 画面連携用(END)
	// 入力補助画面関連のメソッド (START) ======================

	public class ISPanelLinker {
		/**
		 * 入力補助画面のモジュールＩＤ
		 */
		private String _moduleId;

		/**
		 * 入力補助画面のモジュールＩＤ
		 */
		public String moduleId() {
			return _moduleId;
		}

		/**
		 * 入力補助画面の画面ＩＤ
		 */
		private String _screenId;

		/**
		 * 入力補助画面の画面ＩＤ
		 */
		public String screenId() {
			return _screenId;
		}

		/**
		 * リストプッター
		 */
		private MCListPutter _putter;

		/**
		 * リストプッター
		 */
		public MCListPutter putter() {
			return _putter;
		}

		/**
		 * 手入力の際に使用するかどうか？
		 */
		private boolean _isUsingForInput;

		/**
		 * 手入力の際に使用するかどうか？
		 */
		protected boolean isUsingForInput() {
			return _isUsingForInput;
		}

		/**
		 * 手入力の際に使用するかどうか？
		 */
		protected void isUsingForInput(boolean flag) {
			_isUsingForInput = flag;
		}

		/**
		 *
		 */
		public void set(MCLinkBeans linkBeans, MCListPutter putter, String moduleId,
				String screenId, boolean isUsingForInput) {
			_linkBeans = linkBeans;
			_putter = putter;
			_moduleId = moduleId;
			_screenId = screenId;
			_isUsingForInput = isUsingForInput;
		}

		/**
		 * 入力補助画面を起動するMCLinkBeans
		 */
		private MCLinkBeans _linkBeans;

		/**
		 * 入力補助画面を起動するMCLinkBeans
		 */
		public MCLinkBeans linkBeans() {
			return _linkBeans;
		}

		/**
		 * この設定が有効かどうか？
		 */
		private boolean _isEnable = true;

		/**
		 * この設定が有効かどうか？
		 */
		public boolean isEnable() {
			return _isEnable;
		}

		/**
		 * この設定が有効かどうかをセットする
		 */
		public void isEnable(boolean flg) {
			_isEnable = flg;
		}

		/**
		 * この入力補助は複数値入力用かどうか？
		 */
		private boolean _isPluralValue = false;

		/**
		 * この入力補助は複数値入力用かどうか？
		 */
		public boolean isPluralValue() {
			return _isPluralValue;
		}

		/**
		 * この入力補助は複数値入力用かどうかをセットする
		 */
		public void isPluralValue(boolean flg) {
			_isPluralValue = flg;
		}

	}

	/**
	 * 画面部品に紐づいている入力補助画面の設定の有効／無効をセットします。
	 *
	 * @param b
	 * @param enable
	 */
	protected void setISEnable(MCLinkBeans bean, boolean enable) {
		ISPanelLinker linker;
		linker = getISPanelLinkerNE(bean);
		if (linker != null) {
			if (!enable) {
				if (!isPluralValueField(bean)) {
					linker.isEnable(enable);
				}
			}
			else {
				linker.isEnable(enable);
			}
		}
		if (linker != null && enable) {
			bean.setBorder(createISBorder());
		}
		else {
			if (bean instanceof MCTextField) {
				MCTextField f = (MCTextField) bean;
				adjustFieldBorder(f);
			}
			else if (bean instanceof MCField) {
				MCField f = (MCField) bean;
				f.setBorder(f.getDefaultBorder());
			}
			else if (bean instanceof MCTextComboBox) {
				MCTextComboBox cb = (MCTextComboBox) bean;
				adjustFieldBorder(cb);
			}
			else if (bean instanceof AbsMCComboBox<?>) {
				AbsMCComboBox<?> cb = (AbsMCComboBox<?>) bean;
				cb.setBorder(cb.getDefaultBorder());
			}
		}
	}

	/**
	 * ISPanelLinkerの集合
	 */
	protected Map<MCRowBeans, ISPanelLinker> _ISPanelRowBeansMap;

	/**
	 * ISPanelLinkerの集合
	 */
	public Map<MCRowBeans, ISPanelLinker> getISPanelRowBeansMap() {

		//画面起動時（利用画面が出来上がっていない場合）も考慮した実装をする必要がある。
		FXBAP_PanelBase base = getBaseXPanel();
		if (base._ISPanelRowBeansMap == null) {
			base._ISPanelRowBeansMap = new HashMap<>();
		}
		else if (_ISPanelRowBeansMap != null) {
			if (base._ISPanelRowBeansMap != _ISPanelRowBeansMap) {
				for (Map.Entry<MCRowBeans, ISPanelLinker> b : _ISPanelRowBeansMap
						.entrySet()) {
					if (!base._ISPanelRowBeansMap.containsKey(b.getKey())) {
						base._ISPanelRowBeansMap.put(b.getKey(), b.getValue());
					}
				}
				//部品のmapは不要なためクリアする
				_ISPanelRowBeansMap = null;
			}
		}
		return base._ISPanelRowBeansMap;
	}

	/**
	 * ISPanelLinkerのファクトリメソッド
	 */
	protected ISPanelLinker createISPanelLinker() {
		return new ISPanelLinker();
	}

	/**
	 * ISPanelLinkerの集合
	 */
	protected Map<MCColumnConfig, ISPanelLinker> _ISPanelColumnConfigMap;

	/**
	 * ISPanelLinkerの集合
	 */
	public Map<MCColumnConfig, ISPanelLinker> getISPanelColumnConfigMap() {

		//画面起動時（利用画面が出来上がっていない場合）も考慮した実装をする必要がある。
		FXBAP_PanelBase base = getBaseXPanel();
		if (base._ISPanelColumnConfigMap == null) {
			base._ISPanelColumnConfigMap = new HashMap<>();
		}
		else if (_ISPanelColumnConfigMap != null) {
			if (base._ISPanelColumnConfigMap != _ISPanelColumnConfigMap) {
				for (Map.Entry<MCColumnConfig, ISPanelLinker> b : _ISPanelColumnConfigMap
						.entrySet()) {
					if (!base._ISPanelColumnConfigMap.containsKey(b.getKey())) {
						base._ISPanelColumnConfigMap.put(b.getKey(), b.getValue());
					}
				}
				//部品のmapは不要なためクリアする
				_ISPanelColumnConfigMap = null;
			}
		}
		return base._ISPanelColumnConfigMap;
	}

	protected final FXBAP_PanelBase getBaseXPanel() {
		FXBAP_PanelBase result = (FXBAP_PanelBase) this;
		MCRootPanel temp;
		while (true) {
			temp = result.getUnderPanel();
			if (temp == null || !(temp instanceof FXBAP_PanelBase)) {
				return result;
			}
			result = (FXBAP_PanelBase) temp;
		}
	}

	/**
	 * 画面部品に対応する入力補助画面の情報を取得します
	 *
	 * @exception FXBAP0023 入力補助画面情報が取得できない場合
	 * @param bean 画面部品
	 * @return 入力補助画面情報 紐づく入力補助画面がない場合はnull
	 */
	protected ISPanelLinker getISPanelLinkerNE(MCLinkBeans bean) {
		ISPanelLinker ans = null;
		if (bean instanceof MCRowBeans) {
			Map<MCRowBeans, ISPanelLinker> m = getISPanelRowBeansMap();
			ans = m.get(bean);
		}
		else if (bean instanceof MCColumnConfig) {
			Map<MCColumnConfig, ISPanelLinker> m = getISPanelColumnConfigMap();
			ans = m.get(bean);
		}
		return ans;
	}

	/**
	 * 画面部品に対応する入力補助画面の情報を取得します
	 *
	 * @exception FXBAP0023 入力補助画面情報が取得できない場合
	 * @param bean 画面部品
	 * @return 入力補助画面情報
	 */
	protected ISPanelLinker getISPanelLinker(MCLinkBeans bean) {
		ISPanelLinker ret = getISPanelLinkerNE(bean);
		if (ret == null) {
			throw new MCAppException(FXBAP0023);
		}
		return ret;
	}

	/**
	 * 入力補助画面とカラムを紐付けます。<br>
	 * またusingForInputがtrueの場合は、linkBeansのinputPuttterに引数のputterをセットします。
	 *
	 * @param linkBeans 入力補助画面を起動するMCLinkBeans
	 * @param putter 入力補助画面が使用するMCListPutter
	 * @param moduleId 起動する入力補助画面のモジュールＩＤ
	 * @param screenId 起動する入力補助画面のスクリーンＩＤ
	 * @param usingForInput beansに手入力した場合に入力補助画面を使って連携項目を取得する場合true
	 */
	protected ISPanelLinker linkBeansToISPanel(MCLinkBeans linkBeans, MCListPutter putter,
			String moduleId, String screenId, boolean usingForInput) {
		return linkBeansToISPanelImpl(linkBeans, putter, moduleId, screenId,
				usingForInput);
	}

	protected ISPanelLinker linkBeansToISPanelImpl(MCLinkBeans linkBeans,
			MCListPutter putter, String moduleId, String screenId,
			boolean usingForInput) {
		ISPanelLinker rbisp = createISPanelLinker();
		rbisp.set(linkBeans, putter, moduleId, screenId, usingForInput);
		if (usingForInput) {
			MCListConfig lsConf = linkBeans.getListConfig();
			if (lsConf != null) {
				lsConf.setInputPutter(putter);
			}
		}

		if (linkBeans instanceof MCColumnConfig) {
			Map<MCColumnConfig, ISPanelLinker> m = getISPanelColumnConfigMap();
			m.put((MCColumnConfig) linkBeans, rbisp);
			setISDCListener((MCDCBeans) linkBeans);

		}
		else if (linkBeans instanceof MCRowBeans) {
			Map<MCRowBeans, ISPanelLinker> m = getISPanelRowBeansMap();
			m.put((MCRowBeans) linkBeans, rbisp);
			setISDCListener((MCDCBeans) linkBeans);

		}
		else {
			throw new MCAppException(msgUnknownClass(linkBeans));
		}
		return rbisp;
	}

	protected void setISDCListener(MCDCBeans db) {

		for (MCDCListener l : db.getDCListeners()) {
			if (l instanceof ISDCListener) {
				db.removeDCListener(l);
				break;
			}
		}
		db.addDCListener(createISDCListener());
	}

	protected MCDCListener createISDCListener() {
		if (_isDCListener == null) {
			_isDCListener = new ISDCListener();
		}
		return _isDCListener;
	}

	protected ISDCListener _isDCListener = null;

	protected class ISDCListener implements MCDCListener {
		@Override
		public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
			doDCEventForIS(compo, info);
		}
	}

	/**
	 * 入力補助画面とbeansを紐付けます。MCListPutterは、beansにセットされているものを使います。
	 *
	 * @param beans 入力補助画面を起動するbeans
	 * @param moduleId 起動する入力補助画面のモジュールＩＤ
	 * @param screenId 起動する入力補助画面のスクリーンＩＤ
	 * @param usingForInput beansに手入力した場合に入力補助画面を使って連携項目を取得する場合true
	 */
	protected ISPanelLinker linkBeansToISPanel(MCLinkBeans beans, String moduleId,
			String screenId, boolean usingForInput) {
		return linkBeansToISPanel(beans, beans.getListConfig().getInputPutter(), moduleId,
				screenId, usingForInput);
	}

	/**
	 * 入力補助画面を生成します。<br>
	 * 対応するISPanelLinkerがない場合、及びEnableではない場合はnullを返します。
	 * <P>
	 * beansに紐づく入力補助画面を動的に変更する際はこのメソッドをオーバーライドしてください。
	 * </P>
	 * @param beans 対象のbeans
	 * @param eventIndex テーブルの場合の対象行のリストインデックス。見出し部品の場合は負の数。
	 */
	protected FXBAP_ISPanel getISPanel(MCLinkBeans beans, int eventIndex) {
		ISPanelLinker ir = getISPanelLinker(beans);
		if (ir == null || !ir.isEnable()) {
			return null;
		}
		return getISPanel(ir.moduleId(), ir.screenId());
	}

	/**
	 * 入力補助画面を生成します。
	 * <P>
	 * 入力補助画面からリスト取得を行う場合は、検索処理に必要最低限の画面インスタンスを
	 * 生成します。それ以外の場合は、通常の画面起動に必要な画面インスタンスを生成します。
	 * </P>
	 * @param moduleId
	 * @param screenId
	 * @return
	 */
	protected FXBAP_ISPanel getISPanel(String moduleId, String screenId) {
		if (_inputSupportType == INPUT_SUPPORT_GET_LIST) {
			// クラスを作成する
			Class<? extends MCRootPanel> c = MCConst.screen.getClass(moduleId, screenId,
					MCRootPanel.class);
			// 画面インスタンスを作成する
			return (FXBAP_ISPanel) MCFactory.create(c, null, null);
		}

		FXBAP_ISPanel ret = (FXBAP_ISPanel) createPanel(moduleId, screenId,
				MCRootPanel.SCREEN_MODAL);
		MCLog.write(FXBAP0090, ret.getClass().getSimpleName());

		return ret;
	}

	/**
	 * 入力補助画面を表示します
	 *
	 * @param inputSupportPanel 入力補助画面のパネルインスタンス
	 * @param bind 入力補助画面に渡すバインド値
	 * @param putter 入力補助画面が使用するListPutter
	 * @param idx ListPutterに使用するindex。（割付箇所がリストならば、決定値をセットする行index。見出しの場合-1）
	 */
	protected void openISPanelSub(MCRootPanel inputSupportPanel, MCRow bind,
			MCListPutter putter, int idx) {
		showChildPanel(inputSupportPanel, MCRootPanel.MULTI, T1, bind, putter, idx);
	}

	/**
	 * 入力補助画面をどのように使用するかを判断するための定数を保持する。
	 * @see #INPUT_SUPPORT_OPEN
	 * @see #INPUT_SUPPORT_GET_LIST
	 */
	protected int _inputSupportType;

	/**
	 * 入力補助画面を画面として使用する場合を表す定数
	 */
	protected static final int INPUT_SUPPORT_OPEN = 1;

	/**
	 * 入力補助画面をリスト取得ロジックとしてのみ使用する場合を表す定数<p>
	 */
	protected static final int INPUT_SUPPORT_GET_LIST = 2;

	/**
	 * コンポーネントに紐づく入力補助画面があるかどうか検索し、 ある場合は、入力補助画面を起動します。
	 * <P>
	 * 入力補助画面を動的に切り替えるなどのカスタマイズはこのメソッドをオーバーライドしてください。
	 * </P>
	 *
	 * @param compo
	 * @param eventIndex テーブルの場合の対象行のリストインデックス。見出し部品の場合は負の数。
	 */
	public void openISPanel(MCLinkBeans compo, int eventIndex) {

		ISPanelLinker ret = getISPanelLinkerNE(compo);

		if (ret != null) {
			String module = ret.moduleId();
			String screen = ret.screenId();

			for (MCRootPanel p : getChildPanels()) {
				if (screen.equals(p.getScreenID()) && module.equals(p.getModuleID())) {
					return;
				}
			}

			if (ret.isEnable()) {
				_inputSupportType = INPUT_SUPPORT_OPEN;
				FXBAP_ISPanel p = getISPanel(compo, eventIndex);

				MCRow bind = getISBind(compo, eventIndex, true);
				if (compo instanceof MCRowBeans) {
					MCRowBeans rowBeans = (MCRowBeans) compo;
					bind.setValueNE($INPUT_VAL, rowBeans.getViewValue());
				}
				else if (compo instanceof MCColumnConfig) {
					MCColumnConfig config = (MCColumnConfig) compo;
					MCTable<?> tbl = config.getTable();
					if (tbl != null) {
						bind.setValueNE($INPUT_VAL, config.getViewValue(eventIndex));
					}
				}
				MCListPutter putter = getPutter(compo, eventIndex);
				if (isPluralValueField(compo)) {
					openPluralValuePanel(p.getImplPanel(), compo, bind, putter,
							eventIndex);
				}
				else {
					openISPanelSub(p.getImplPanel(), bind, putter, eventIndex);
				}
			}
		}
	}

	/**
	 * 複数値を入力する画面を起動します。
	 *
	 * @param inputSupportPanel 起動する画面
	 * @param compo 起動元となったフィールド
	 * @param bind バインド値
	 * @param putter プッター
	 * @param idx 行
	 */
	protected void openPluralValuePanel(MCRootPanel inputSupportPanel, MCLinkBeans compo,
			MCRow bind, MCListPutter putter, int idx) {
		showChildPanel(inputSupportPanel, MCRootPanel.MULTI, T1, bind, putter, idx,
				compo);
	}

//	/**
//	 * ダブルクリック時のイベント処理です。
//	 * <p>
//	 * デフォルト実装：コンポーネントに紐付く入力補助画面を起動する
//	 * </p>
//	 */
//	@Override
//	public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
//		super.doDCEvent(compo, info);
//		doDCEventForIS(compo, info);
//	}

	/**
	 * ダブルクリック時のイベント処理です。
	 * <p>
	 * デフォルト実装：コンポーネントに紐付く入力補助画面を起動する
	 * </p>
	 */
	protected void doDCEventForIS(MCDCBeans compo, MCEventInfo info) {
		// ここでは、入力可能なコンポーネントかどうかのみを判断し
		// 残りの処理は openISPanel(MCLinkBeans)で処理を行う。
		if (compo instanceof MCLinkBeans) {
			MCLinkBeans linkbeans = (MCLinkBeans) compo;
			if (compo instanceof MCRowBeans) {
				MCRowBeans rowBeans = (MCRowBeans) compo;
				if (isEditable(rowBeans)) {
					openISPanel(linkbeans, -1);
				}
			}
			else if (compo instanceof MCColumnConfig) {
				MCColumnConfig config = (MCColumnConfig) compo;
				MCTable<?> tbl = config.getTable();
				if (tbl != null) {
					if (isEditable(config, info.getEventIndex())) {
						openISPanel(config, info.getEventIndex());
					}
				}
			}
		}
	}

	/**
	 * 値が入力可能なbeansかどうかを判断します。
	 *
	 * @param beans
	 * @return
	 */
	public boolean isEditable(MCRowBeans beans) {
		if (beans == null) {
			return false;
		}

		if (beans instanceof MCModeBeans) {
			int modeStatus = ((MCModeBeans) beans).getModeInfo().getStatus();
			if (MCMode.ENABLE_STATUS == modeStatus) {
				if (beans instanceof MCField || beans instanceof MCPasswordField
						|| beans instanceof MCRadioButton || beans instanceof MCCheckBox
						|| beans instanceof AbsMCComboBox<?>) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 値が入力可能かどうかを判断します。
	 *
	 * @param beans
	 * @return
	 */
	public boolean isEditable(MCColumnConfig config, int rowIdx) {
		if (config == null) {
			return false;
		}
		MCTable<?> tbl = config.getBaseTable();
		MCMode mode = tbl.isCellEditable(rowIdx, config);
		if (MCMode.REQUIRED.equals(mode) || MCMode.ENABLE.equals(mode)) {
			return true;
		}
		return false;
	}

	/**
	 * リスト取得メソッド
	 * <P>
	 * デフォルト実装：compoがMCLinkBeansで手入力の場合は入力補助画面から リストの取得を試みる
	 * </P>
	 */
	@Override
	public MCList<?> getList(MCEventBeans compo, MCRow row, MCEventInfo info) {
		MCList<?> list = super.getList(compo, row, info);
		if (list != null && list.size() > 0) {
			return list;
		}
		if (compo instanceof MCLinkBeans) {
			MCLinkBeans lb = (MCLinkBeans) compo;
			if (MCListConfig.INPUT.equals(lb.getListConfig().getOpeType())) {
				list = getListForIS(compo, row, info);
			}
		}
		return list;
	}

	/**
	 * 手入力時に入力補助画面から値を取得するための処理
	 *
	 * @param compo
	 * @param row
	 * @param info
	 * @return
	 */
	public MCList<?> getListForIS(MCEventBeans compo, MCRow row, MCEventInfo info) {
		MCList<?> ans = null;
		_inputSupportType = INPUT_SUPPORT_GET_LIST;
		if (compo instanceof MCLinkBeans) {
			MCLinkBeans linkbeans = (MCLinkBeans) compo;
			ISPanelLinker ir = getISPanelLinkerNE(linkbeans);
			if (ir != null && ir.isEnable()) {
				if (ir.isUsingForInput()) {
					int eventIndex = info.getEventIndex();
					MCRow bind = getISBind(linkbeans, eventIndex, true);
					bind.setValueNE($INPUT_VAL, info.getNewValue());

					// 以下のように実装してもパネルを取得できるが動的に
					// 入力補助画面を切り替えることを想定して、MCLinkBeansから取得する
					// FXBAP_ISPanel p = getISPanel(ir.moduleId(), ir.screenId());
					FXBAP_ISPanel p = getISPanel(linkbeans, eventIndex);
					FXBAP_ISPanelInfo pi = new FXBAP_ISPanelInfo();
					pi.setListPutter(getPutter(linkbeans, eventIndex));
					pi.setPutIndex(eventIndex);
					return p.getList(bind, this, pi);
				}
			}
		}

		return ans;
	}

	private MCListPutter getPutter(MCLinkBeans compo, int eventIndex) {

		MCListPutter putter = getListPutterForIS(compo, eventIndex);
		putter = callGetListPutterForISCustom(putter, compo, eventIndex);
		return putter;
	}

	/**
	 * 入力補助画面から値を取得します。
	 *
	 * @param compo コンポーネント
	 * @param isInputMode 手入力条件で取得するかどうか
	 */
	public MCList<?> getListForIS(MCRowBeans compo, boolean isInputMode) {
		_inputSupportType = INPUT_SUPPORT_GET_LIST;
		ISCond cnd = getISCond(compo, -1);
		if (cnd == null) {
			return null;
		}

		MCRow bind = cnd.bind();
		if (isInputMode) {
			bind.setValueNE($INPUT_VAL, compo.getRowValue());
		}
		return getListForISImpl(cnd.beans(), bind, -1, isInputMode);
	}

	/**
	 * 入力補助画面から値を取得します。
	 *
	 * @param compo コンポーネント
	 * @param index 行index
	 * @param isInputMode 手入力条件で取得するかどうか
	 */
	public MCList<?> getListForIS(MCColumnConfig compo, int index, boolean isInputMode) {
		_inputSupportType = INPUT_SUPPORT_GET_LIST;
		ISCond cnd = getISCond(compo, index);
		if (cnd == null) {
			return null;
		}

		MCRow bind = cnd.bind();
		if (isInputMode) {
			bind.setValueNE($INPUT_VAL, compo.getValue(index));
		}
		return getListForISImpl(cnd.beans(), bind, index, isInputMode);

	}

	protected ISCond getISCond(MCEventBeans compo, int index) {

		if (!(compo instanceof MCLinkBeans)) {
			return null;
		}
		MCLinkBeans linkbeans = (MCLinkBeans) compo;

		ISPanelLinker ir = getISPanelLinkerNE(linkbeans);
		if (ir == null || !ir.isEnable()) {
			return null;
		}
		MCRow bind = getISBind(linkbeans, index, false);
		return new ISCond(linkbeans, bind);
	}

	private MCRow getISBind(MCLinkBeans linkbeans, int eventIndex, boolean isvv) {
		MCListPutter putter = getPutter(linkbeans, eventIndex);
		MCRow bind = putter.getBindRow(eventIndex);
		bind = callGetBindRowForISCustom(bind, linkbeans, eventIndex);
		return bind;
	}

	protected MCList<?> getListForISImpl(MCLinkBeans linkbeans, MCRow bind, int index,
			boolean isInputMode) {

		// 以下のように実装してもパネルを取得できるが動的に
		// 入力補助画面を切り替えることを想定して、MCLinkBeansから取得する
		// FXBAP_ISPanel p = getISPanel(ir.moduleId(), ir.screenId());
		FXBAP_ISPanel p = getISPanel(linkbeans, index);
		if (p == null) {
			return null;
		}
		return p.getList(bind, this, isInputMode);
	}

	protected class ISCond {

		private final MCLinkBeans _lb;

		private final MCRow _bind;

		/**
		 * コンストラクタです。
		 * @param beans LinkBeans 必須
		 * @param bind 条件格納用コンテナ 必須
		 */
		public ISCond(MCLinkBeans beans, MCRow bind) {
			super();
			_lb = beans;
			_bind = bind;
		}

		protected MCLinkBeans beans() {
			return _lb;
		}

		protected MCRow bind() {
			return _bind;
		}
	}

	/**
	 * beansに紐づいた入力補助画面を起動する際に使用するMCListPutterを返します。
	 * <P>
	 * カスタマイズする場合は{@link #getListPutterForISCustom(MCRow, MCLinkBeans, int)}をOverrideしてください。<br><br>
	 * 戻り値は起動する入力補助画面に合致するMCListPutterである必要があります。
	 * </P>
	 *
	 * @param beans
	 * @param eventIndex テーブルの場合の対象行のリストインデックス。見出し部品の場合は負の数。
	 * @return
	 */
	protected final MCListPutter getListPutterForIS(MCLinkBeans beans, int eventIndex) {
		return getISPanelLinker(beans).putter();
	}

	/**
	 * 入力補助画面に設定するバインド値をカスタマイズするためのメソッドです。
	 * </P>
	 * @param bind 子画面で作成されたバインド値
	 * @param beans GUI部品
	 * @param eventIndex テーブルの場合の対象行のリストインデックス。見出し部品の場合は負の数。
	 * @return バインド値
	 * @see #callGetBindRowForISCustom(MCRow, MCLinkBeans, int)
	 */
	protected MCRow getBindRowForISCustom(MCRow bind, MCLinkBeans beans, int eventIndex) {
		return bind;
	}

	/**
	 * {@link #getBindRowForISCustom(MCRow, MCLinkBeans, int, boolean)}の呼び出しを行います。<p>
	 * getBindRowForISCustomは引数　compo　の配置されている画面から順番に親画面まで実行されます。
	 *
	 * @param bind バインド値
	 * @param compo ＧＵＩ部品
	 * @param index イベントindex
	 * @return　バインド値
	 */
	protected final MCRow callGetBindRowForISCustom(MCRow bind, MCLinkBeans compo,
			int index) {
		MCRootPanel p = compo.getRootPanel();
		MCRow rtn = bind;
		while (p != null) {
			if (p instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase xp = (FXBAP_PanelBase) p;
				rtn = xp.getBindRowForISCustom(rtn, compo, index);
			}
			p = p.getUnderPanel();
		}
		return rtn;
	}

	/**
	 * 入力補助画面に設定するバインド値をカスタマイズするためのメソッドです。
	 * </P>
	 * 引数　ptr のインスタンスは再利用される可能性があります。
	 * 初期設定のリストプッターを変更したくない場合は、リストプッターを新規作成して戻り値として使用してください。
	 * @parma ptr 子画面で作成されたリストプッター
	 * @param beans GUI部品
	 * @param eventIndex テーブルの場合の対象行のリストインデックス。見出し部品の場合は負の数。
	 * @return　リストプッター
	 * @see #callGetListPutterForISCustom(MCListPutter, MCLinkBeans, int)
	 */
	protected MCListPutter getListPutterForISCustom(MCListPutter ptr, MCLinkBeans beans,
			int eventIndex) {
		return ptr;
	}

	/**
	 * {@link #getListPutterForISCustom(MCRow, MCLinkBeans, int, boolean)}の呼び出しを行います。<p>
	 * getListPutterForISCustomは引数　compo　の配置されている画面から順番に親画面まで実行されます。
	 *
	 * @param ptr リストプッター
	 * @param compo ＧＵＩ部品
	 * @param index イベントindex
	 * @return　リストプッター
	 */
	protected final MCListPutter callGetListPutterForISCustom(MCListPutter ptr,
			MCLinkBeans compo, int index) {
		MCRootPanel p = compo.getRootPanel();
		MCListPutter rtn = ptr;
		while (p != null) {
			if (p instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase xp = (FXBAP_PanelBase) p;
				rtn = xp.getListPutterForISCustom(rtn, compo, index);
			}
			p = p.getUnderPanel();
		}
		return rtn;
	}

	// 入力補助画面関連のメソッド ( END ) ======================
	// 画面クリア関連(START)===================================
	/**
	 * 画面内の全ての入力内容の破棄及び、デフォルト値の設定をします。<br>
	 * thisが埋め込み画面の場合は、その利用画面をさかのぼってscreenClearを呼び出します。結果、他の埋め込み画面の内容もクリアされます。
	 * <p>
	 * 実際には以下の処理を実行します。screenClearの動きをカスタマイズする 場合は、各処理の役割を理解して適切なメソッドをオーバーライドして ください。
	 * <ol type=1>
	 * <li>screenClearConfirm：ユーザに対して画面クリアをして良いかの確認を行います</li>
	 * <li>screenClearSetMode：画面クリア後のモード設定</li>
	 * <li>screenClearBody：データのクリアを行います</li>
	 * <li>screenClearSetDefault：デフォルト値をセットします</li>
	 * <li>（statusClear：変更履歴のクリア（カスタマイズ対象外））</li>
	 * <li>screenClearSetFocus：画面クリア後のフォーカス設定</li>
	 * </ol>
	 * </p>
	 * <p>
	 * 埋め込み画面の場合は、埋め込み画面の利用画面のscreenClearを呼び出します。 埋め込み画面の場合は、埋め込み画面の利用画面から、埋め込み画面の
	 * screenClearBody と screenClearSetDefault
	 * を呼び出します。埋め込み画面側でカスタマイズが必要な場合は、それぞれのメソッドに処理を実装してください。
	 * </p>
	 *
	 * @return 画面クリアを実行した場合true キャンセルされた場合false
	 */
	@Override
	public boolean screenClear() {
		boolean ret = false;
		if (getUnderPanel() instanceof FXBAP_PanelBase) {
			return ((FXBAP_PanelBase) getUnderPanel()).screenClear();
		}
		if (screenClearConfirm()) {
			screenClearBody();
			screenClearSetMode();
			screenClearSetDefault();
			statusClear();
			screenClearSetFocus();

			SrchCndInfo si = getSrchCndInfo();
			if (si != null && si.getClearFlg()) {
				setUserSrchCnd();
			}
			else {
				List<Object[]> l = FXUCP_SrchCndUtil.getSrchCndBeans(this, true);
				for (Object[] o : l) {
					MCRowBeans c = (MCRowBeans) o[1];
					c.setRequiredFlg(false);
				}
			}
			
			ret = true;
		}
		return ret;
	}

	/**
	 *  シナリオテストで画面クリアするためのメソッド
	 * @return
	 */
	@Override
	public boolean screenClearForScenarioTest() {
		boolean ret = false;
		if (getUnderPanel() instanceof FXBAP_PanelBase) {
			return ((FXBAP_PanelBase) getUnderPanel()).screenClearForScenarioTest();
		}
//		if (screenClearConfirm()) {
		screenClearBody();
		screenClearSetMode();
		screenClearSetDefault();

		SrchCndInfo si = getSrchCndInfo();
		if (si != null && si.getClearFlg()) {
			setUserSrchCnd();
		}
		else {
			List<Object[]> l = FXUCP_SrchCndUtil.getSrchCndBeans(this, true);
			for (Object[] o : l) {
				MCRowBeans c = (MCRowBeans) o[1];
				c.setRequiredFlg(false);
			}
		}

		statusClear();
		screenClearSetFocus();
		ret = true;
//		}
		return ret;
	}

	public boolean screenClearConfirm() {
		if (isChanged()) {
			return confirmScreenClear();
		}
		return true;
	}

	/**
	 * 画面クリア処理の中で画面の値を削除する処理です。
	 */
	public void screenClearBody() {
		List<MCRow> innerRows = new ArrayList<>();
		for (MCContainer cont : getContainers()) {
			if (cont instanceof MCList) {
				MCList<?> ls = (MCList<?>) cont;
				ls.clear();
				JComponent compo = getComponent(ls);
				if (compo instanceof MCTable) {
					MCTable<?> tbl = (MCTable<?>) compo;
					Rectangle rect = new Rectangle(0, 0, 0, 0);
					tbl.scrollRectToVisible(rect);
				}
			}
			else if (cont instanceof MCRow) {
				MCRow row = (MCRow) cont;
				for (String colName : row.getNameArray()) {
					MCMeta meta = row.getMeta(colName);
					if (MCDataType.ROW != meta.type()) {
						if (MCDataType.BOOLEAN == meta.type()) {
							// colName は、NameArray から取得しているので
							// setValueEx を使う必要がない
							row.setValue(colName, false);
						}
						else {
							// colName は、NameArray から取得しているので
							// setValueEx を使う必要がない
							row.setValue(colName, null);
						}
					}
					else {
						innerRows.add(row.getInnerRow(colName));
					}
				}
			}
		}
		List<MCRow> partsRows = new ArrayList<>();
		for (MCRootPanel rootPanel : getPartsPanels()) {
			for (MCContainer cont : rootPanel.getContainers()) {
				if (cont instanceof MCRow) {
					partsRows.add((MCRow) cont);
				}
			}
			if (rootPanel instanceof FXBAP_PanelBase) {
				FXBAP_PanelBase cpp = (FXBAP_PanelBase) rootPanel;
				cpp.screenClearBody();
			}
			else {
				for (MCContainer cont : rootPanel.getContainers()) {
					cont.clear();
				}
			}
		}

		// 埋め込み画面ではないinnerRowのクリア
		for (MCRow row : innerRows) {
			int idx = -1;
			for (int i = 0; i < partsRows.size(); i++) {
				if (partsRows.get(i) == row) {
					idx = i;
					break;
				}
			}
			if (idx < 0) {
				// 埋め込み画面のInnerRowではなかった場合
				row.clear();
			}
			else {
				// 埋め込み画面のInnerRowの場合
				partsRows.remove(idx);
			}
		}
		//ページングエージェントを削除する
		getPagingAgentContainer().clear();

		removeCachedSysInfo();
	}

	/**
	 * 画面クリア時のデフォルト値をセットします。
	 * <P>
	 * デフォルト実装：valueInit()を呼び出す。
	 * </p>
	 */
	public void screenClearSetDefault() {
		valueInit();
		fillSpaceForOpen();
	}

	/**
	 * 画面クリアをした時のモード設定をします。
	 * <P>
	 * デフォルト実装： 実装仕様書で指定した画面ステータスにする
	 * </p>
	 */
	public void screenClearSetMode() {
		mcInitStatus();
	}

	/**
	 * 画面クリア時のフォーカス設定を行います。
	 * <P>
	 * デフォルト実装：setOpenFocus()
	 * </p>
	 */
	public void screenClearSetFocus() {
		setOpenFocus();
	}

	/**
	 * 画面起動時のfillSpaceを実装します。
	 * <p>
	 * デフォルト実装：何もしない
	 * </p>
	 */
	protected void fillSpaceForOpen() {
		initTrace(this, "fillSpaceForOpen");
	}

	/**
	 * ページング用埋込画面の描画を更新します。
	 * @param p 画面
	 */
	protected void updatePagingParts(MCRootPanel p) {
		MCRootPanel[] ps = p.getPartsPanels();
		for (MCRootPanel pp : ps) {
			if (pp instanceof FXUCP_Paging) {
				((FXUCP_Paging) pp).dispUpdate();
			}
			else {
				updatePagingParts(pp);
			}
		}
	}


	// 画面クリア関連( END )===================================
	// ツールバー（ここから）

	/**
	 * @deprecated 共通親クラスのみオーバーライド可能。画面ごとの設定変更はリソースでやることを想定
	 */
	@Override
	@Deprecated
	public List<IfToolbarBeansHolder> toolBarItems() {
		List<IfToolbarBeansHolder> ans = new ArrayList<>();

		toolbarItemsPreset(ans);
		toolbarItemsCommand(ans);
		toolbarItemsPersonalLink(ans);

		return ans;
	}

	/**
	 * リソース取得時に使用する
	 */
	protected static final String TOOLBAR = "toolbar";

	/**
	 * リソース取得時に使用する
	 */
	protected static final String ORDER = "order";

	/**
	 * リソース取得時に使用する
	 */
	protected static final String IGNORE = "ignore";

	/**
	 * リソース取得時に使用する
	 */
	protected static final String TYPE = "type";

	/**
	 * ツールバーのボタン（preset）
	 * @deprecated 共通親クラスのみオーバーライド可能。画面ごとの設定変更はリソースでやることを想定
	 */
	@Deprecated
	protected void toolbarItemsPreset(List<IfToolbarBeansHolder> list) {

		/**
		 * リソース取得時に使用する
		 */
		final String PRESET_ALL = "preset_all";

		/**
		 * リソース取得時に使用する
		 */
		final String PRESET_SCREEN = "preset_screen";

		Map<String, IfToolbarBeansHolder> map = new HashMap<>();

		String[][] msa = getModuleAndScreenIDs();
		String[] pka = new String[msa.length + 1];
		pka[0] = MCConst.createKey(FXBAP_PanelBase_MODULE_ID, TOOLBAR, PRESET_ALL);
		MCCollectionUtil.reverse(msa);
		for (int i = 0; i < msa.length; i++) {
			String[] ms = msa[i];
			pka[i + 1] = MCConst.createKey(FXBAP_PanelBase_MODULE_ID, TOOLBAR,
					PRESET_SCREEN, ms[0], ms[1]);
		}

		Map<String, Map<String, Object>> vl = new HashMap<>();
		for (String pk : pka) {
			String[] ka = MCConst.app.findPattern(MCConst.createKey(pk, "*"));
			for (String k : ka) {
				String sk = k.substring(pk.length());

				Map<String, Object> vm = vl.get(sk);
				if (vm == null) {
					vm = new HashMap<>();
					vl.put(sk, vm);
				}

				String tk;
				tk = MCConst.createKey(k, TYPE);
				if (MCConst.app.containsKey(tk)) {
					vm.put(TYPE, MCConst.app.getString(tk));
				}
				tk = MCConst.createKey(k, ORDER);
				if (MCConst.app.containsKey(tk)) {
					vm.put(ORDER, MCConst.app.getInteger(tk));
				}
				tk = MCConst.createKey(k, IGNORE);
				if (MCConst.app.containsKey(tk)) {
					vm.put(IGNORE, MCConst.app.getBoolean(tk));
				}
			}
		}

		for (Map.Entry<String, Map<String, Object>> e : vl.entrySet()) {
			IfToolbarBeansHolder h = FXUCP_ToolBarUtil.createBeansHolder();
			Map<String, Object> m = e.getValue();
			if (setCompBypresetToolbarTypeToComp(h, (String) m.get(TYPE))) {
				if (m.containsKey(ORDER)) {
					h.order((Integer) m.get(ORDER));
				}
				if (m.containsKey(IGNORE)) {
					h.isIgnore((Boolean) m.get(IGNORE));
				}
				map.put(e.getKey(), h);
			}
		}

		for (Map.Entry<String, IfToolbarBeansHolder> e : map.entrySet()) {
			list.add(e.getValue());
		}
	}

	/**
	 * ツールバーのボタン（command）
	 * @deprecated 共通親クラスのみオーバーライド可能。画面ごとの設定変更はリソースでやることを想定
	 */
	@Deprecated
	protected void toolbarItemsCommand(List<IfToolbarBeansHolder> list) {

		/**
		 * リソース取得時に使用する
		 */
		final String COMMAND_ALL = "command_all";

		/**
		 * リソース取得時に使用する
		 */
		final String COMMAND_SCREEN = "command_screen";

		final String COMMAND = "command";
		final String ICON = "icon";
		final String LABEL = "label";
		final String MESSAGE = "message";
		final String TRUE_STRING = "T";

		Map<String, Map<String, Object>> map = new HashMap<>();

		String[][] msa = getModuleAndScreenIDs();
		String[] pka = new String[msa.length + 1];
		pka[0] = MCConst.createKey(FXBAP_PanelBase_MODULE_ID, TOOLBAR, COMMAND_ALL);
		MCCollectionUtil.reverse(msa);
		for (int i = 0; i < msa.length; i++) {
			String[] ms = msa[i];
			pka[i + 1] = MCConst.createKey(FXBAP_PanelBase_MODULE_ID, TOOLBAR,
					COMMAND_SCREEN, ms[0], ms[1]);
		}

		for (String pk : pka) {
			String[] ka = MCConst.app.findPattern(MCConst.createKey(pk, "*"));
			for (String k : ka) {
				String sk = k.substring(pk.length());
				Map<String, Object> m = map.get(sk);
				if (m == null) {
					m = new HashMap<>();
					map.put(sk, m);
				}

				String tk;
				tk = MCConst.createKey(k, COMMAND);
				if (MCConst.app.containsKey(tk)) {
					m.put(COMMAND, MCConst.app.getString(tk));
				}
				tk = MCConst.createKey(k, ICON);
				if (MCConst.app.containsKey(tk)) {
					m.put(ICON, MCConst.app.getString(tk));
				}
				tk = MCConst.createKey(k, LABEL);
				if (MCConst.app.containsKey(tk)) {
					m.put(LABEL, MCConst.app.getString(tk));
				}
				tk = MCConst.createKey(k, MESSAGE);
				if (MCConst.app.containsKey(tk)) {
					m.put(MESSAGE, MCConst.app.getString(tk));
				}
				tk = MCConst.createKey(k, IGNORE);
				if (MCConst.app.containsKey(tk)) {
					m.put(IGNORE, MCConst.app.getBoolean(tk) ? TRUE_STRING : null);
				}
				tk = MCConst.createKey(k, ORDER);
				if (MCConst.app.containsKey(tk)) {
					m.put(ORDER, MCConst.app.getInteger(tk));
				}
				map.put(sk, m);

			}
		}

		for (Map.Entry<String, Map<String, Object>> e : map.entrySet()) {
			Map<String, Object> data = e.getValue();
			String objName = e.getKey();
			if (e.getKey() == null) {
				continue;
			}
			String cmd = (String) data.get(COMMAND);
			if (cmd == null) {
				continue;
			}
			String icn = (String) data.get(ICON);
			String msg = (String) data.get(MESSAGE);
			String lbl = (String) data.get(LABEL);
			MCButton btn = FXUCP_ToolBarUtil.createCommandBtn((FXBAP_PanelBase) this,
					objName, cmd, icn, msg, lbl);
			int odr = -1;
			if (data.containsKey(ORDER)) {
				odr = (Integer) data.get(ORDER);
			}
			boolean ign = false;
			if (data.containsKey(IGNORE)) {
				ign = TRUE_STRING.equals(data.get(IGNORE));
			}
			IfToolbarBeansHolder holder = FXUCP_ToolBarUtil.createBeansHolder(btn, odr,
					ign);
			list.add(holder);
		}
	}

	protected boolean setCompBypresetToolbarTypeToComp(IfToolbarBeansHolder holder,
			String type) {
		final String TB_SCLEAR = "SCREEN_CLEAR";
		final String TB_EXCEL_OUT = "EXCEL_OUT";
		final String TB_TBL_ZOOM = "TBL_ZOOM";
		final String TB_MEMO = "MEMO";
		final String TB_NULL = "NULL";
		final String TB_SCREEN_BOOKMARK = "SCREEN_BOOKMARK";
		final String TB_B_FLOW = "B_FLOW";
		final String TB_BARCODE = "BARCODE";
		final String TB_MOVE_XY = "MOVE_XY";
		final String TB_GRAPH = "GRAPH";
		final String TB_S_SWITCH = "S_SWITCH";
		final String TB_ROBOT = "ROBOT";
		final String TB_SENARIO = "SENARIO";
		final String TB_DEV = "DEV";

		boolean isSet = false;
		if (TB_SCLEAR.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createSClearBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_EXCEL_OUT.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createExcelBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_TBL_ZOOM.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createTblSizeChangeBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_MEMO.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createMemoBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_SCREEN_BOOKMARK.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil
					.createScreenBookmarkSettingPanel((FXBAP_PanelBase) this));
			isSet = true;
		}
		//640begin
		else if (TB_B_FLOW.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createFlowBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_BARCODE.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createBarcodeBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_MOVE_XY.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createMoveXYBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_GRAPH.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createGraphBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_S_SWITCH.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createPgBtn((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_ROBOT.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createRobotPanel((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_SENARIO.equals(type)) {
			holder.comp(FXUCP_ToolBarUtil.createScenarioPanel((FXBAP_PanelBase) this));
			isSet = true;
		}
		else if (TB_DEV.equals(type) && MCConfig.common.getBoolean("log.devlog")) {
			holder.comp(FXUCP_ToolBarUtil.createDevPanel((FXBAP_PanelBase) this));
			isSet = true;
		}
		//640end
		else if (TB_NULL.equals(type)) {
			holder.comp(null);
			isSet = true;
		}
		return isSet;
	}

	/**
	 * 画面毎で設定するのツールバーのボタン
	 */
	protected void toolBarItemsByScreen(List<Component> list) {
	}

	/**
	 * 個人で設定する画面起動設定ボタン
	 */
	protected void toolBarItemsPersonalLinkSetting(List<Component> list) {
		list.add(FXUCP_ToolBarUtil
				.createScreenBookmarkSettingPanel((FXBAP_PanelBase) this));
	}

	/**
	 * 個人で設定する画面起動のツールバーのボタン
	 */
	protected void toolbarItemsPersonalLink(List<IfToolbarBeansHolder> list) {
		_toolbarItem = new FXBAP_ToolbarItem(this);
		_toolbarItem.toolbarItemsPersonalLink(list);
	}

	// 一応正常に動くがニーズがないのでコメントアウト（ここから）
	// @Override
	// public void doNEEvent(MCNEBeans compo, MCEventInfo info) {
	// Component orgCompo = containerMapForToolBar().get(compo);
	// if (orgCompo != null) {
	// doNEEvent((MCNEBeans) orgCompo, info);
	// }
	// else {
	// super.doNEEvent(compo, info);
	// }
	// }
	//
	// @Override
	// public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
	// Component orgCompo = containerMapForToolBar().get(compo);
	// if (orgCompo != null) {
	// doAPEvent((MCAPBeans) orgCompo, info);
	// }
	// else {
	// super.doAPEvent(compo, info);
	// }
	// }
	//
	// protected Map<Container, Container> _containerMapForToolBar;
	//
	// protected Map<Container, Container> containerMapForToolBar() {
	// if (_containerMapForToolBar == null) {
	// _containerMapForToolBar = new HashMap<Container, Container>();
	// }
	// return _containerMapForToolBar;
	// }
	//
	// protected MCButton cloneForToolBar(MCButton srcBtn) {
	// MCButton ret = beansFactory.createButton(srcBtn.getName() + ".toolBar");
	// ret.setText(srcBtn.getText());
	// ret.setIcon(srcBtn.getIcon());
	// ret.setMaximumSize(srcBtn.getMaximumSize());
	// for (MCAPListener lstn : srcBtn.getAPListeners()) {
	// ret.addAPListener(lstn);
	// }
	// for (MCNEListener lstn : srcBtn.getNEListeners()) {
	// ret.addNEListener(lstn);
	// }
	// containerMapForToolBar().put(ret, srcBtn);
	// return ret;
	// }
	// 一応正常に動くがニーズがないのでコメントアウト（ここから）

	// パーソナライズとロボットで使用
	@Override
	public boolean beforeClose() {
		boolean ans = super.beforeClose();
		if (ans == true) {
			// 閉じる前処理
			if (_toolbarItem != null) {
				_toolbarItem.beforeClose();
			}
		}
		return ans;
	}

	@Override
	public void panelClosed() {
		super.panelClosed();
		FXUCP_ToolBarUtil.removeBarInst(this);
	}

	public void resetToolBar() {
		MCLayout layout = getMCLayout();
		if (layout instanceof FXUCP_GeneralLayout) {
			FXUCP_GeneralLayout gLayout = (FXUCP_GeneralLayout) layout;
			gLayout.resetToolBarPanel();
		}
	}

	// ツールバー（ここまで）

	// ヘッダーバー（ここから）
	@SuppressWarnings("unchecked")
	@Override
	public List<MCButton> westHeaderBarItems() {
		// コードがきたない！
		// リソースキー：ヘッダーバー
		final String HEADERBAR = "headerbar";
		// リソースキー：ヘッダーバーボタンの表示順序
		final String ORDER = "order";
		// リソースキー：ヘッダーバーボタン設定の無視
		final String IGNORE = "ignore";
		// リソースキー：全画面共通設定
		final String COMMAND_ALL = "command_all";
		// リソースキー：画面ごとの設定
		final String COMMAND_SCREEN = "command_screen";
		// ボタンの名前
		final String NAME = "name";
		// リソースキー：ボタン押下時処理のクラス名
		final String CLASS = "class";
		// リソースキー：ボタン押下時処理のメソッド名
		final String METHOD = "method";
		// リソースキー：ボタン押下時処理のメソッドの実行時引数
		final String ARGS = "args";
		// リソースキー：ボタンアイコン
		final String ICON = "icon";
		// リソースキー：ボタンのツールチップ
		final String MESSAGE = "message";

		// ボタン設定を格納するmap
		HashMap<String, Map<String, Object>> map = new HashMap<>();
		// 設定IDまでの全リソースキーを取得
		String[][] moduleScreenIds = getModuleAndScreenIDs();
		String[] commandKeys = new String[moduleScreenIds.length + 1];
		commandKeys[0] = MCConst.createKey(FXBAP_PanelBase_MODULE_ID, HEADERBAR, COMMAND_ALL);
		MCCollectionUtil.reverse(moduleScreenIds);
		for (int i = 0; i < moduleScreenIds.length; i++) {
			String[] ms = moduleScreenIds[i];
			commandKeys[i + 1] = MCConst.createKey(FXBAP_PanelBase_MODULE_ID, HEADERBAR, COMMAND_SCREEN,
					ms[0], ms[1]);
		}

		// COMMAND_ALLと画面ごとの各設定をmapに格納
		for (String commandKey : commandKeys) {
			String[] settingKeys = MCConst.app.findPattern(MCConst.createKey(commandKey, "*"));
			for (String settingKey : settingKeys) {
				String id = settingKey.substring(commandKey.indexOf(HEADERBAR) + HEADERBAR.length());
				Map<String, Object> m = map.computeIfAbsent(id, k -> new HashMap<>());

				// ボタンの名前＝設定単位+設定ID
				m.put(NAME, "headerbar_" + id);
				String tk;
				// アイコン
				tk = MCConst.createKey(settingKey, ICON);
				if (MCConst.app.containsKey(tk)) {
					m.put(ICON, MCConst.app.getString(tk));
				}
				// ツールチップ用メッセージ
				tk = MCConst.createKey(settingKey, MESSAGE);
				if (MCConst.app.containsKey(tk)) {
					m.put(MESSAGE, MCConst.app.getString(tk));
				}
				// 設定無視フラグ
				tk = MCConst.createKey(settingKey, IGNORE);
				if (MCConst.app.containsKey(tk)) {
					m.put(IGNORE, MCConst.app.getBoolean(tk));
				}
				// 表示順
				tk = MCConst.createKey(settingKey, ORDER);
				if (MCConst.app.containsKey(tk)) {
					m.put(ORDER, MCConst.app.getInteger(tk));
				}
				// クラス
				tk = MCConst.createKey(settingKey, CLASS);
				if (MCConst.app.containsKey(tk)) {
					m.put(CLASS, MCConst.app.getString(tk));
				}
				// メソッド
				tk = MCConst.createKey(settingKey, METHOD);
				if (MCConst.app.containsKey(tk)) {
					m.put(METHOD, MCConst.app.getString(tk));
				}
				// メソッド実行時引数
				tk = MCConst.createKey(settingKey, ARGS, "*");
				String[] argKeys = MCConst.app.findPattern(tk);
				if (argKeys.length > 0) {
					Map<String, String> argMap = new LinkedHashMap<>();
					for (String argKey : argKeys) {
						String[] keyElements = argKey.split("\\.");
						// キーの最終要素とリソース値を引数Mapに格納
						argMap.put(keyElements[keyElements.length - 1], MCConst.app.getString(argKey, ""));
					}
					m.put(ARGS, argMap);
				}

				map.put(id, m);
			}
		}

		// リソースの表示順設定に従う順序のMCButtonリストを作成
		return map.values().stream()
				.filter(e -> !(boolean) e.getOrDefault(IGNORE, false))
				.sorted((e1, e2) -> (int) e1.getOrDefault(ORDER, 0) - (int) e2.getOrDefault(ORDER, 0))
				.map(e -> {
					String btnName = (String) e.get(NAME);
					String icn = (String) e.get(ICON);
					String msg = FXUCP_ToolBarUtil.convStr(
							(String) e.getOrDefault(MESSAGE, ""), (FXBAP_PanelBase) this);
					String clazz = (String) e.get(CLASS);
					String method = (String) e.get(METHOD);
					Map<String, String> args = (Map<String, String>) e.get(ARGS);

					return createHeaderButton(btnName, icn, msg, clazz, method, args);
				})
				.collect(Collectors.toList());
	}

	/**
	 * 
	 * ヘッダーバーに表示するボタンを作成します。
	 *
	 * @author    h-kawada
	 * @since     7.0.2
	 * @param btnName ボタンの名前
	 * @param icon ボタンのアイコン
	 * @param message ボタンのツールチップメッセージ
	 * @param className ボタン押下で実行されるメソッドが属するクラス
	 * @param methodName ボタン押下で実行されるメソッド名
	 * @param args ボタン押下で実行されるメソッドの実行時引数。Map<引数キー, 引数値>の形式
	 * @return 引数のメソッドを実行するようAPイベントに設定したボタン
	 * @throws MCException [FXUCP0026] メソッドの実行時にエラーが発生した場合
	 */
	private MCButton createHeaderButton(String btnName, String icon, String message, String className, String methodName, Map<String, String> args) {
		MCButton button = FXUCP_GeneralLayout.createHeaderButton(btnName);
		button.setIcon(icon);
		button.setToolTipText(message);
		button.setMode(MCMode.ENABLE);

		// 引数型。MCRootPanelとMapで決め打ち
		Class<?>[] paramTypes = args == null
				? new Class[]{MCRootPanel.class}
				: new Class[]{MCRootPanel.class, Map.class};

		// メソッド実行を仕込む
		button.addAPListener((c, i) -> {
			try {
				Object target = MCFactory.create(Object.class, className);
				// 引数値。第1引数は常にこの画面のインスタンス
				Object[] argValues = args == null
						? new Object[]{this}
						: new Object[]{this, args};

				MCFactory.invoke(target, methodName, paramTypes, argValues);
			}
			catch (Exception e) {
				MCLog.write(e);
				throw new MCAppException(e, FXUCP0026);
			}
		});

		return button;
	}

	// ヘッダーバー（ここまで）

	// 部品関連のメソッド（ここから）
	/**
	 * <P>
	 * getLinkPartsPanelNE()で画面を取得します。
	 * 取得できなかった場合は例外をthrowします。
	 * </P>
	 * @param 取得したい部品画面のクラスまたはインターフェース
	 * @exception FXBAP0062 パネルが見つからない場合
	 * @see #getLinkPartsPanelNE(Class)
	 */
	// (T)へのキャスト。mapにセットする時点で保障すること
	public <T> T getLinkPartsPanel(Class<T> clazz) {
		T p = getLinkPartsPanelNE(clazz);
		if (p != null) {
			return p;
		}
		String n = MCStringUtil.join(">", getNameFromBasePanel(this));
		throw new MCAppException(FXBAP0062, clazz.getName(),
				n + " : " + getClass().getName());
	}

	/**
	 * 画面の名前を返します。<p>
	 * 土台の画面から指定された画面までの名前を配列にして返します。
	 *
	 * @param panel 画面
	 * @return 画面の名前の配列
	 */
	protected String[] getNameFromBasePanel(MCRootPanel panel) {
		MCRootPanel[] pa = MCBeansUtil.getRootPanelLayer(panel);
		MCCollectionUtil.reverse(pa);
		String[] na = new String[pa.length];
		for (int i = 0; i < pa.length; i++) {
			na[i] = pa[i].getName();
		}
		return na;
	}

	/**
	 * この画面（あるいは部品画面）に紐づく部品画面の中から
	 * 指定されたクラスまたはインターフェースを実装しているクラス
	 * 取得する。
	 * <P>
	 * 優先度は以下の通り
	 * <li>{@link #putLinkPartsPanel(MCRootPanel)}にセットされているもの</li>
	 * <li>{@link #getUnderPanel()}で自分以外の{@link #getPartsPanels()}で
	 * 取得できるパネルから検索（複数見つかったら例外）。</li>
	 * {@link #getUnderPanel()}及び{@link #getPartsPanels()}が {@link FXBAP_PanelBase} ではない
	 * 場合は、それより先（＝部品側）の検索は行わない。
	 * </P>
	 * @param 取得したい部品画面のクラスまたはインターフェース
	 */
	@SuppressWarnings("unchecked")
	// (T)へのキャスト。mapにセットする時点で保障すること
	public <T> T getLinkPartsPanelNE(Class<T> clazz) {
		// 検索結果がある場合
		Map<Class<?>, Object> cache = linkPartsPanelCache();
		if (cache.containsKey(clazz)) {
			return (T) cache.get(clazz);
		}

		// linkPartsPanels の中を探す
		Map<Class<?>, MCRootPanel> map = linkPartsPanels();
		Object obj = map.get(clazz);
		if (obj != null) {
			T ret = (T) obj;
			linkPartsPanelCache().put(clazz, ret);
			return ret;
		}

		// 全てのRootPanelを検索
		List<T> ans = new ArrayList<>();
		getLinkPartsPanel(clazz, this, ans);

		if (ans.size() > 1) {
			StringBuilder sb = new StringBuilder();
			for (T a : ans) {
				if (a instanceof MCRootPanel) {
					MCRootPanel p = (MCRootPanel) a;
					if (sb.length() > 0) {
						sb.append("\n");
					}
					String n = MCStringUtil.join(">", getNameFromBasePanel(p));
					sb.append(n + " : " + p.getClass().getName());
				}
				else {
					if (a == null) {
						throw new MCAppException(msgUnknownClass(a));
					}
					if (sb.length() > 0) {
						sb.append("\n");
					}
					sb.append(a.getClass().getName());
				}
			}
			String n = MCStringUtil.join(">", getNameFromBasePanel(this));
			throw new MCAppException(FXBAP0064, sb.toString(),
					n + " : " + getClass().getName());
		}
		T ret = null;
		if (ans.size() == 1) {
			ret = ans.get(0);
		}
		linkPartsPanelCache().put(clazz, ret);
		return ret;
	}

	/**
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	private Map<Class<?>, Object> _linkPartsPanelCache;

	/**
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	protected Map<Class<?>, Object> linkPartsPanelCache() {
		if (_linkPartsPanelCache == null) {
			_linkPartsPanelCache = new HashMap<>();
		}
		return _linkPartsPanelCache;
	}

	/**
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	@SuppressWarnings("unchecked")
	// (T)へのキャスト。
	public <T> void getLinkPartsPanel(Class<T> clazz, MCRootPanel except, List<T> ans) {
		// 自分自身をチェック
		if (clazz.isInstance(this)) {
			ans.add((T) this);
		}
		// 自分の部品画面を探す
		MCRootPanel[] parts = getPartsPanels();
		for (MCRootPanel p : parts) {
			if (p == except) {
				continue;
			}
			if (p instanceof FXBAP_PanelBase) {
				((FXBAP_PanelBase) p).getLinkPartsPanel(clazz, this, ans);
			}
		}
		// １つ上（部品画面の利用画面）で同様のことをする
		MCRootPanel under = getUnderPanel();
		if (under != null && under instanceof FXBAP_PanelBase) {
			if (under != except) {
				((FXBAP_PanelBase) under).getLinkPartsPanel(clazz, this, ans);
			}
		}
	}

	/**
	 * 条件：valueはkeyのクラスへキャスト可能であること
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	private Map<Class<?>, MCRootPanel> _linkPartsPanels;

	/**
	 * 条件：valueはkeyのクラスへキャスト可能であること
	 * @deprecated 共通親クラスのみで使用することを想定
	 */
	@Deprecated
	protected Map<Class<?>, MCRootPanel> linkPartsPanels() {
		if (_linkPartsPanels == null) {
			_linkPartsPanels = new HashMap<>();
		}
		return _linkPartsPanels;
	}

	/**
	 * @deprecated {@link #putLinkPartsPanel(Class,MCRootPanel)} を使用してください。
	 *
	 * クラス（含むインターフェース）から、
	 * この画面（あるいは部品画面）に紐づく部品画面を
	 * 取得する際に、明示的にその戻り値をセットするための
	 * メソッドです。
	 * @param 取得したい部品画面のクラス
	 */
	@Deprecated
	public void putLinkPartsPanel(MCRootPanel p) {
		Map<Class<?>, MCRootPanel> map = linkPartsPanels();
		Class<?> c = p.getClass();
		while (true) {
			map.put(c, p);
			if (c == null || c == MCRootPanel.class) {
				break;
			}
			Class<?>[] is = c.getInterfaces();
			for (Class<?> i : is) {
				map.put(i, p);
				putLinkPartsPanelSub(c, map, p);
			}
			c = c.getSuperclass();
		}
	}

	/**
	 * {@link #getLinkPartsPanel(Class)} 及び {@link #getLinkPartsPanel(Class)}
	 * 使用時の戻り値のクラスを明示的に指定したい場合に使用します。
	 * @param clazz {@link #getLinkPartsPanel(Class)} 及び
	 * {@link #getLinkPartsPanel(Class)}で引数に指定するクラスまたはインターフェース
	 * @param panel {@link #getLinkPartsPanel(Class)} 及び
	 * {@link #getLinkPartsPanel(Class)}で c を指定された場合の戻り値に使用するクラス
	 * @deprecated 利用画面からの関連部品の設定は、各部品のputReqLinkPartsメソッドを使用すること
	 */
	@Deprecated
	public void putLinkPartsPanel(Class<?> clazz, MCRootPanel panel) {
		Map<Class<?>, MCRootPanel> map = linkPartsPanels();
		map.put(clazz, panel);
	}

	/**
	 * @deprecated {@link #putLinkPartsPanel(MCRootPanel)} のみ使用。
	 */
	@Deprecated
	protected void putLinkPartsPanelSub(Class<?> ifClass, Map<Class<?>, MCRootPanel> map,
			MCRootPanel p) {
		for (Class<?> subIf : ifClass.getInterfaces()) {
			map.put(subIf, p);
			putLinkPartsPanelSub(subIf, map, p);
		}
	}

	/**
	 * 入力値設定機能を無効にする場合は true を返します。<p>
	 * デフォルトでは、入力値設定対象枠のリストが null または 0 件の場合に true を返します。
	 *
	 * @return 入力値設定機能を有効にする場合は false
	 * @see #getSrchPanels()
	 */
	@Override
	public boolean ignoreSrchCnd() {
		List<Object[]> l = FXUCP_SrchCndUtil.getSrchCndBeans(this, false);
		return l.isEmpty();
	}

	@Override
	public boolean isPanelNameVisibleInSrchCnd() {
		String k = "FX.srch_cnd_panel.panel_name_visible";
		if (MCConst.app.containsKey(k)) {
			return MCConst.app.getBoolean(k, true);
		}
		return true;
	}

	@Override
	public void doSrchAction() {
		doButtonAction(getSrchButtons());
	}

	/**
	 * パーソナライズによる検索条件を設定します。<p>
	 * 初期検索を実行するように設定されている場合は、初期検索を実行します。<p>
	 * この画面が埋込画面の場合は何もしません。
	 * 入力値設定機能が無効になっている場合は何もしません。
	 *
	 * @see #ignoreSrchCnd()
	 */
	public void setUserSrchCnd() {
		if (isPartsPanel() || ignoreSrchCnd()) {
			return;
		}
		try {
			// 入力値設定のリスト
			List<SrchCndInfo> siL = new ArrayList<>();

			boolean init_search = false;
			
			// 画面に適用されている入力値設定
			SrchCndInfo si = getSrchCndInfo();
			if (si != null) {
				siL.add(si);
				init_search = si.getInitSrchFlg();
			}
			else {
				// 以下の順番で入力値設定を重ね掛けする
				// １．メニューに登録されている入力値設定
				// ２．初期設定の入力値設定

				// メニューに登録されている入力値設定
				si = getMenuSrchCndInfo();
				if (si != null) {
					siL.add(si);
					init_search = si.getInitSrchFlg();
				}
				// 初期設定の入力値設定
				si = getInitSrchCndInfo();
				if (si != null) {
					siL.add(si);
					
					// １．メニューに登録されている入力値設定⇒初期検索する
					// ２．初期設定の入力値設定⇒初期検索しない
					// 上記の場合は初期検索しない（２．の設定が採用される）
					init_search = si.getInitSrchFlg();
				}
			}

			if (isEventNeedToBehind()) {
				for (SrchCndInfo i : siL) {
					final SrchCndInfo cnd = i;
					final IfSrchCndBase base = this;
					MCBehindEventInfo info = new MCBehindEventInfo() {
						@Override
						protected void doBehindEvent() {
							_setSrchCndInfo(cnd);
							FXUCP_SrchCndUtil.setInitCnd(base, cnd);
							FXUCP_SrchCndUtil.setInitFocus(base, cnd);
						}
					};
					addBehindEventInfo(info);
				}
				if (init_search) {
					MCBehindEventInfo info = new MCBehindEventInfo() {
						@Override
						protected void doBehindEvent() {
							doSrchAction();
						}
					};
					addBehindEventInfo(info);
				}
			}
			else {
				for (SrchCndInfo i : siL) {
					_setSrchCndInfo(i);
					FXUCP_SrchCndUtil.setInitCnd(this, i);
					FXUCP_SrchCndUtil.setInitFocus(this, i);
				}
				if (init_search) {
					doSrchAction();
				}
			}
		}
		catch (Exception e) {
			MCBeansUtil.handle(this, e);
		}
	}

	/**
	 * 検索ボタンのリストを返します。<p>
	 * この画面に配置されているボタンの中から、検索ボタンを探します。
	 * デフォルトでは {@link #isSrchButton(MCButton)}
	 * が true を返したボタンを検索ボタンであると見なします。
	 *
	 * @return 検索ボタンのリスト
	 */
	protected List<MCButton> getSrchButtons() {
		List<MCButton> l = new ArrayList<>();
		MCButton[] a = MCBeansUtil.getAllComponents(MCButton.class, this);
		for (MCButton c : a) {
			if (isSrchButton(c)) {
				l.add(c);
			}
		}
		return l;
	}

	/**
	 * 指定されたボタンをチェックします。
	 * 指定されたボタンが検索ボタンであると見なされる場合は true を返します。<p>
	 * デフォルトでは F1 キーが設定されているボタンを検索ボタンと見なします。
	 *
	 * @param compo ボタン
	 * @return 検索ボタンではないと見なされる場合は false
	 */
	protected boolean isSrchButton(MCButton compo) {
		if (compo == null) {
			return false;
		}
		return MCFunctionKey.F1.equals(compo.getFunctionKey());
	}

	/**
	 * ボタンアクションを実行します。<br>
	 * ボタンアクションが実行された場合は true を返します。<br>
	 * <br>
	 * 指定されたボタンを順番にチェックします。<br>
	 * ボタンのモードが {@link MCMode#INVISIBLE} の場合は、次のボタンをチェックします。<br>
	 * それ以外の場合は、ボタンアクションを実行し、処理を終了します。
	 *
	 * @param compos ボタン
	 * @return ボタンアクションが実行されなかった場合は false
	 */
	protected boolean doButtonAction(MCButton... compos) {
		if (compos == null) {
			return false;
		}
		for (MCButton compo : compos) {
			if (doButtonAction(compo)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ボタンアクションを実行します。<br>
	 * ボタンアクションが実行された場合は true を返します。<br>
	 * <br>
	 * 指定されたボタンを順番にチェックします。<br>
	 * ボタンのモードが {@link MCMode#INVISIBLE} の場合は、次のボタンをチェックします。<br>
	 * それ以外の場合は、ボタンアクションを実行し、処理を終了します。
	 *
	 * @param list ボタンのリスト
	 * @return ボタンアクションが実行されなかった場合は false
	 */
	protected boolean doButtonAction(List<MCButton> list) {
		if (list == null) {
			return false;
		}
		return doButtonAction(list.toArray(new MCButton[list.size()]));
	}

	/**
	 * ボタンアクションを実行します。<br>
	 * ボタンアクションが実行された場合は true を返します。
	 *
	 * @param compo ボタン
	 * @return ボタンアクションが実行されなかった場合は false
	 */
	protected boolean doButtonAction(MCButton compo) {
		return compo != null ? compo.doButtonAction() : false;
	}

	/**
	 * MCListを保持しておくことの出来るマップです。
	 */
	private Map<String, MCList<MCConstRow>> _stockMap = null;

	/**
	 * MCListを保持します。
	 * <p>
	 * キーにブロックＩＤは使用できません。xAppsで使用されています。
	 *
	 * @param key キー
	 * @param list 保存するリスト
	 */
	public void setStock(String key, MCList<MCConstRow> list) {

		if (_stockMap == null) {
			_stockMap = new HashMap<>();
		}
		_stockMap.put(key, list);
	}

	/**
	 * MCListを取得します。
	 * @param key キー
	 * @return リスト
	 */
	public MCList<MCConstRow> getStock(String key) {
		if (_stockMap == null) {
			return null;
		}
		return _stockMap.get(key);
	}

	/**
	 * 入力値設定に関する情報です。
	 */
	protected SrchCndInfo _srch_cnd_info = null;

	@Override
	public void _setSrchCndInfo(SrchCndInfo info) {
		_srch_cnd_info = info;
	}

	@Override
	public void _setSrchCndInfoId(MCResourceLayerType type, String id) {
		for (SrchCndInfo i : getSrchCndInfoList()) {
			if (isSame(type.name(), i.getSettingUnitType())
					&& isSame(i.getSettingInfoID(), id)) {
				_setSrchCndInfo(i);
				break;
			}
		}
	}

	@Override
	public SrchCndInfo getSrchCndInfo() {
		return _srch_cnd_info;
	}

	@Override
	public SrchCndInfo getInitSrchCndInfo() {
		return FXUCP_SrchCndUtil.getInitSrchCndInfo(getSrchCndInfoList());
	}
	
	@Override
	public SrchCndInfo getMenuSrchCndInfo() {
		MCPersonalizeGroupInfo info = getInitPersonalizeGroupInfo();
		if (info == null) {
			return null;
		}
		
		String id = info.getSearchSettingID();
		if (id == null) {
			return null;
		}
		
		for (SrchCndInfo i : getSrchCndInfoList()) {
			if (id.equals(i.getSettingInfoID())) {
				return i;
			}
		}
		
		return null;
	}

	/**
	 * 入力値設定に関する情報のリストです。
	 */
	protected List<SrchCndInfo> _srch_cnd_info_list = null;

	@Override
	public void _setSrchCndInfoList(List<SrchCndInfo> list) {
		_srch_cnd_info_list = list;
	}

	@Override
	public List<SrchCndInfo> getSrchCndInfoListWithoutBarcode() {

		List<SrchCndInfo> list = getSrchCndInfoList();
		List<SrchCndInfo> list2 = new ArrayList<>();
		for (SrchCndInfo i : list) {
			String y = i.getSettingUnitType();
			if (FXC_RESOURCE_SETTING_UNIT.isTYPE_BARCODE(y) == false) {
				list2.add(i);
			}
		}

		return list2;
	}

	@Override
	public List<SrchCndInfo> getSrchCndInfoList() {
		if (_srch_cnd_info_list != null) {
			return _srch_cnd_info_list;
		}
		_srch_cnd_info_list = FXUCP_SrchCndUtil.getSrchCndInfoList(this);
		return _srch_cnd_info_list;

	}

	@Override
	public MCMessage _applySrchCndInfo(SrchCndInfo info) {
		MCMessage m = null;
		if (info != null) {
			FXUCP_SrchCndUtil.updateCnd(this, info.getSrchCndList(),
					FXUCP_SrchCndUtil.getSrchCndBeans(this, true));
			FXUCP_SrchCndUtil.doInitSrch(this, info);
			FXUCP_SrchCndUtil.setInitFocus(this, info);

			_setSrchCndInfo(info);
		}
		else {
			_setSrchCndInfo(null);
			_setSrchCndInfoList(null);

			if (!screenClear()) {
				m = new MCMessage(FXBAP0098);
			}

			List<Object[]> l = FXUCP_SrchCndUtil.getSrchCndBeans(this, true);
			for (Object[] o : l) {
				MCRowBeans c = (MCRowBeans) o[1];
				c.setRequiredFlg(false);
			}
		}
		return m;
	}

	/**
	 * GUI 部品の必須フラグを返します。<p>
	 * 入力値設定で GUI 部品を必須項目に設定している場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return 必須フラグ
	 */
	@Override
	protected boolean _getRequiredFlg(MCRowBeans compo) {

		// 7013-2610(FXUCP_AppScreenOpenerで入力値設定の必須にするが反映されてしまう)
		boolean isUseScreenOpener = isScreenOpenerStart();
		if (isUseScreenOpener) {
			String key1 = MCConst.createKey("screenopener", "useRequired");
			String key2 = MCConst.createKey(getModuleID(), "screenopener", "useRequired");
			boolean useRequired = MCConst.app.getBoolean(key2,
					MCConst.app.getBoolean(key1, true));
			if (useRequired == false) {
				return false;
			}
		}

		List<SrchCndInfo> siL = new ArrayList<>();
		{
			SrchCndInfo i = getSrchCndInfo();
			if (i != null) {
				siL.add(i);
			}
			else {
				// 以下の順番で必須フラグを探し、見つかったものを採用する
				// １．初期設定の入力値設定
				// ２．メニューに登録されている入力値設定
				i = getInitSrchCndInfo();
				if (i != null) {
					siL.add(i);
				}
				i = getMenuSrchCndInfo();
				if (i != null) {
					siL.add(i);
				}
			}
		}

		if (siL.isEmpty()) {
			return false;
		}

		List<SrchCndR> sl = new ArrayList<>();
		for (SrchCndInfo i : siL) {
			for (SrchCndR o : i.getSrchCndList()) {
				if (o.set_flg()) {
					sl.add(o);
				}
			}
		}

		List<Object[]> ol = FXUCP_SrchCndUtil.getSrchCndBeans(this, true);

		List<Object[]> kl = FXUCP_SrchCndUtil.createGUIKeyList(ol);

		for (Object[] o : ol) {
			if (compo.equals(o[1])) {
				String k = null;
				for (Object[] ka : kl) {
					if (compo.equals(ka[0])) {
						k = (String) ka[1];
						break;
					}
				}

				for (SrchCndR s : sl) {
					if (isSame(s.field_key(), k)) {
						return s.required_flg();
					}
				}
				return false;
			}
		}

		return false;
	}

	@Override
	protected void adjustFieldBorder(MCTextField compo) {
		ISPanelLinker pl = getISPanelLinkerNE(compo);
		if (pl != null && pl.isEnable() && !pl.isPluralValue()) {
			if (!compo.isPluralValueEnable()) {
				compo.setBorder(createISBorder());
			}
			else {
				compo.setBorder(createPluralValueISBorder());
			}
		}
		else if (compo.isEnabled() && compo.isPluralValueEnable()) {
			compo.setBorder(getPluralValueEnableFieldBorder(compo));
		}
		else {
			compo.setBorder(compo.getDefaultBorder());
		}
	}

	@Override
	protected void adjustFieldBorder(MCTextComboBox compo) {
		ISPanelLinker pl = getISPanelLinkerNE(compo);
		if (pl != null && pl.isEnable() && !pl.isPluralValue()) {
			if (!compo.isPluralValueEnable()) {
				compo.setBorder(createISBorder());
			}
			else {
				compo.setBorder(createPluralValueISBorder());
			}
		}
		else if (compo.isEnabled() && compo.isPluralValueEnable()) {
			compo.setBorder(getPluralValueEnableFieldBorder(compo));
		}
		else {
			compo.setBorder(compo.getDefaultBorder());
		}
	}

	//複数条件関連
	Map<MCLinkBeans, Boolean> _pluralValueEnable = null;

	@Override
	public void setPluralValueEnable(MCTextField compo, boolean enable) {
		super.setPluralValueEnable(compo, enable);
		//画面起動時の場合、linkBeansToIsPanelで設定しないといけないため保存しておく。
		if (_pluralValueEnable == null) {
			_pluralValueEnable = new HashMap<>();
		}
		_pluralValueEnable.put(compo, Boolean.valueOf(compo.isPluralValueEnable()));

		setPluralValueEnableAfter(compo, compo.isPluralValueEnable(), null);
	}

	@Override
	public void setPluralValueEnable(MCTextComboBox compo, boolean enable) {
		super.setPluralValueEnable(compo, enable);
		//画面起動時の場合、linkBeansToIsPanelで設定しないといけないため保存しておく。
		if (_pluralValueEnable == null) {
			_pluralValueEnable = new HashMap<>();
		}
		_pluralValueEnable.put(compo, Boolean.valueOf(compo.isPluralValueEnable()));

		//コンボボックスのListPutterを優先して使用する。
		setPluralValueEnableAfter(compo, compo.isPluralValueEnable(),
				compo.getListConfig().getListPutter());
	}

	void setPluralValueEnableAfter(MCLinkBeans compo, boolean enable,
			MCListPutter putter) {
		Map<MCRowBeans, ISPanelLinker> m = getISPanelRowBeansMap();
		ISPanelLinker linker = null;
		if (!m.containsKey(compo)) {
			String[] sid = getPluralValueScreenID();
			MCListPutter p = null;
			//コンボボックスのListPutterを優先して使用したいが
			//自動生成の関連で、コンボボックスのListPutterは
			//この処理の後で、設定されるため、仮のListPutterを設定する。
			if (putter != null) {
				p = putter;
			}
			else {
				p = new MCListPutter(compo, "in_value");
			}
			linker = linkBeansToISPanelImpl(compo, p, sid[0], sid[1], false);
			linker.isPluralValue(true);
		}
		else {
			linker = getISPanelLinkerNE(compo);
		}
		if (linker != null && linker.isPluralValue()) {
			linker.isEnable(enable);
		}
	}

	/**
	 * 入力補助画面の場合、確定時に呼び出されます。<BR>
	 * 該当する値が含まれるリストを返す実装をしてください。<BR>
	 *
	 * @param target 起動元項目のGUI部品
	 * @param isDCEvent ＤＣイベントかどうか
	 * @return 決定行リスト
	 */
	@SuppressWarnings("rawtypes")
	public MCList getAcceptList(MCLinkBeans target, boolean isDCEvent) {
		return null;
	}

	/**
	 * 複数値を選択する画面のモジュールＩＤと画面ＩＤ
	 */
	static String[] _plural_value_sid = null;

	/**
	 * 複数値を選択する画面のモジュールＩＤと画面ＩＤを返します。
	 *
	 * @return モジュールＩＤと画面ＩＤ
	 */
	public static String[] getPluralValueScreenID() {
		if (_plural_value_sid == null) {
			_plural_value_sid = MCConst.app.getStringArray(
					MCConst.createKey("PluralValue", "ScreenID"), new String[] {
							"FX", "FXUCP0100"
					});
		}
		return _plural_value_sid;
	}

	@Override
	protected void setValueByScreenOpener() {
		MCScreenOpener so = getScreenOpener();
		if (so != null) {
			SrchCndInfo si = null;

			Comparable<?> v = so.getParamValue("$srch_cnd$");
			if (v != null) {
				List<SrchCndInfo> l = getSrchCndInfoList();
				for (SrchCndInfo i : l) {
					if (isSame(MCConst.createKey("p_srch_cnd", i.getSettingUnitType(),
							i.getSettingInfoID()), v)) {
						si = i;
						break;
					}
					if (isSame(MCConst.createKey("p_srch_cnd", i.getSettingInfoID()),
							v)) {
						si = i;
						break;
					}
				}
			}

			so.removeParam("$srch_cnd$");

			if (si != null) {
				if (isEventNeedToBehind()) {
					final SrchCndInfo cnd = si;
					final IfSrchCndBase base = this;
					MCBehindEventInfo info = new MCBehindEventInfo() {
						@Override
						protected void doBehindEvent() {
							FXUCP_SrchCndUtil.updateCnd(base, cnd.getSrchCndList(),
									FXUCP_SrchCndUtil.getSrchCndBeans(base, true));
						}
					};
					addBehindEventInfo(info);

					super.setValueByScreenOpener();

					MCBehindEventInfo info2 = new MCBehindEventInfo() {
						@Override
						protected void doBehindEvent() {
							FXUCP_SrchCndUtil.doInitSrch(base, cnd);
							FXUCP_SrchCndUtil.setInitFocus(base, cnd);
							_setSrchCndInfo(cnd);
						}
					};
					addBehindEventInfo(info2);
				}
				else {
					FXUCP_SrchCndUtil.updateCnd(this, si.getSrchCndList(),
							FXUCP_SrchCndUtil.getSrchCndBeans(this, true));

					super.setValueByScreenOpener();

					FXUCP_SrchCndUtil.doInitSrch(this, si);
					FXUCP_SrchCndUtil.setInitFocus(this, si);

					_setSrchCndInfo(si);
				}
			}
			else {
				super.setValueByScreenOpener();
			}
		}
		else {
			super.setValueByScreenOpener();
		}
	}

	/**
	 * カスタマイズ用に作成されたMCConst.dblbl.getLabelのラッパーです。
	 *
	 * データベーステーブルまたは項目のユーザロケールラベル文字列を返します。
	 *
	 * テーブル名のみ指定した場合、テーブル名のラベル文字列を検索します。<br>
	 * テーブル名と項目名とを指定した場合、項目名のラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 * <p>
	 * このメソッドを使用する場合、pluginリソースの設定が必要です。<br>
	 * 詳しくは、フレームワークのクラスmcframe.commonCore.resource.MCDBLabelConstのjavaDocを参照してください。
	 *
	 * @param tblName テーブル名
	 * @param colName 項目名
	 * @return テーブル名または項目名のラベル文字列。テーブル名未指定の場合はnull。キーがない場合は null
	 */
	public String getDBLabel(String tblName, String colName) {
		return FXUCC_ResourceUtil.getDBLabel(tblName, colName);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.dblbl.getLabelのラッパーです。
	 *
	 * データベーステーブルまたは項目のラベル文字列を返します。
	 *
	 * テーブル名のみ指定した場合、テーブル名のラベル文字列を検索します。<br>
	 * テーブル名と項目名とを指定した場合、項目名のラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param tblName テーブル名
	 * @param colName 項目名
	 * @param locale ロケール
	 * @return テーブル名または項目名のラベル文字列。テーブル名未指定の場合はnull。キーがない場合は null
	 */
	public String getDBLabel(String tblName, String colName, Locale locale) {
		return FXUCC_ResourceUtil.getDBLabel(tblName, colName, locale);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.lgclbl.getLabelのラッパーです。
	 *
	 * ロジックＩＤまたはオペレーションＩＤのユーザロケールラベル文字列を返します。
	 *
	 * ロジックＩＤのみ指定した場合、ロジックＩＤのラベル文字列を検索します。<br>
	 * ロジックＩＤとオペレーションＩＤとを指定した場合、オペレーションＩＤのラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * <p>
	 * このメソッドを使用する場合、pluginリソースの設定が必要です。<br>
	 * 詳しくは、フレームワークのクラスmcframe.commonCore.resource.MCLogicLabelConstのjavaDocを参照してください。
	 * @param mod モジュールＩＤ
	 * @param lgc ロジックＩＤ
	 * @param ope オペレーションＩＤ
	 * @return ロジックＩＤまたはオペレーションＩＤのラベル文字列。モジュールＩＤとロジックＩＤが未指定の場合はnull。キーがない場合は null
	 */
	public String getLogicLabel(String mod, String lgc, String ope) {
		return FXUCC_ResourceUtil.getLogicLabel(mod, lgc, ope);
	}

	/**
	 * カスタマイズ用に作成されたMCConst.lgclbl.getLabelのラッパーです。
	 *
	 * ロジックＩＤまたはオペレーションＩＤのラベル文字列を返します。
	 *
	 * ロジックＩＤのみ指定した場合、ロジックＩＤのラベル文字列を検索します。<br>
	 * ロジックＩＤとオペレーションＩＤとを指定した場合、オペレーションＩＤのラベル文字列を検索します。<br>
	 * ラベル文字列中にバインド書式（{～}）が含まれていてもバインド変数展開は
	 * 行われません。<br>
	 * 他のリソースと異なり、キーに設定されている値がない場合は空文字列("")を
	 * 返します。キーがない場合は null を返します。
	 *
	 * @param mod モジュールＩＤ
	 * @param lgc ロジックＩＤ
	 * @param ope オペレーションＩＤ
	 * @param locale ロケール
	 * @return ロジックＩＤまたはオペレーションＩＤのラベル文字列。モジュールＩＤとロジックＩＤが未指定の場合はnull。キーがない場合は null
	 */
	public String getLogicLabel(String mod, String lgc, String ope, Locale locale) {
		return FXUCC_ResourceUtil.getLogicLabel(mod, lgc, ope, locale);
	}

	//-- ページング関係（入力補助専用ページング以外）メソッド

	@SuppressWarnings("rawtypes")
	final Map<Class, MCPagingAgent> _callerClsToPagingAgent = new HashMap<>();

	@Override
	public boolean isPagingAgentHolder() {
		return false;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map<Class, MCPagingAgent> getPagingAgentContainer() {
		return _callerClsToPagingAgent;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public MCPagingAgent getPagingAgent(Class clr) {
		FXBAP_Searcher.PagingCallTyp typ = getPagingCallTyp();
		if (typ == FXBAP_Searcher.PagingCallTyp.NEW) {
			MCPagingAgent p = new MCPagingAgent();
			getPagingAgentContainer().put(clr, p);
			return p;
		}
		else {
			MCPagingAgent p = getPagingAgentContainer().get(clr);
			return p;
		}
	}

	private FXBAP_Searcher.PagingCallTyp _pagingCallTyp = FXBAP_Searcher.PagingCallTyp.NEW;

	@Override
	public void setPagingCallTyp(FXBAP_Searcher.PagingCallTyp p) {
		_pagingCallTyp = p;
	}

	@Override
	public FXBAP_Searcher.PagingCallTyp getPagingCallTyp() {
		return _pagingCallTyp;
	}

	@Override
	public void callPagingSearcher(FXBAP_PanelBase eventPanel) {

	}

	final ArrayList<FXBAP_PagingParam> _pagingParams = new ArrayList<>();

	/**
	 * {@inheritDoc}<p>
	 * リストは複製されますが、要素は複製されません。
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FXBAP_PagingParam> getPagingParam() {
		return (List<FXBAP_PagingParam>) _pagingParams.clone();
	}

	@Override
	public void clearPagingParam() {
		_pagingParams.clear();
	}

	@Override
	public void setPagingParam(FXBAP_PagingParam... ps) {
		clearPagingParam();
		addPagingParam(ps);
	}

	@Override
	public void addPagingParam(FXBAP_PagingParam... ps) {
		_modPagingParam(true, ps);
	}

	@Override
	public void removePagingParam(FXBAP_PagingParam... ps) {
		_modPagingParam(false, ps);
	}

	protected void _modPagingParam(boolean add, FXBAP_PagingParam... ps) {
		if (ps == null) {
			return;
		}
		for (FXBAP_PagingParam p : ps) {
			if (p == null) {
				continue;
			}
			for (int i = 0; i < _pagingParams.size(); i++) {
				FXBAP_PagingParam cp = _pagingParams.get(i);
				if (cp.getTargetCaller() == p.getTargetCaller()
						&& isSame(cp.getTargetBlockId(), p.getTargetBlockId())) {
					if (add) {
						_pagingParams.set(i, p);
					}
					else {
						_pagingParams.remove(cp);
					}
					return;
				}
			}
			if (add) {
				_pagingParams.add(p);
			}
		}
	}

	/**
	 * 対象のコンテナに関連する埋込画面を取得します。
	 * <P>
	 * 対象はベースに直接addされている埋込画面のみです。
	 * @param cont 対象のコンテナ
	 * @return 埋込画面
	 */
	public MCRootPanel[] getPartsPanels(MCContainer cont) {
		Set<MCRootPanel> panels = new HashSet<>();
		if (cont instanceof MCList) {
			return getPartsPanels((MCList<?>) cont);
		}
		else if (cont instanceof MCRow) {
			return getPartsPanels((MCRow) cont);
		}
		return panels.toArray(new MCRootPanel[0]);
	}

	/**
	 * 対象のコンテナに関連する埋込画面を取得します。
	 * <P>
	 * 対象はベースに直接addされている部品画面のみです。
	 * @param list 対象のコンテナ
	 * @return 埋込画面
	 */
	@SuppressWarnings("rawtypes")
	public MCRootPanel[] getPartsPanels(MCList list) {
		Set<MCRootPanel> panels = new HashSet<>();
		JComponent listComp = getComponent(list);
		if (listComp instanceof MCTable) {
			MCTable tbl = (MCTable) listComp;
			for (MCColumnConfig colConf : tbl.getColumnConfigs()) {
				MCTable colTbl = colConf.getTable();
				if (tbl != colTbl) {
					if (tbl == colTbl.getUnderTable()) {
						panels.add(colTbl.getRootPanel());
					}
				}
			}
		}
		else {
			// GUIを持たないコンテナの場合、listComp == null
			if (listComp != null) {
				throw new MCAppException(msgUnknownClass(listComp));
			}
		}
		return panels.toArray(new MCRootPanel[0]);
	}

	/**
	 * 対象のコンテナに関連する埋込画面を取得します。
	 * <P>
	 * 対象はベースに直接addされている部品画面のみです。
	 * @param row 対象のコンテナ
	 * @return 埋込画面
	 */
	public MCRootPanel[] getPartsPanels(MCRow r) {
		Set<MCRootPanel> panels = new HashSet<>();
		for (MCMeta meta : r.getMetaArray()) {
			if (MCDataType.ROW == meta.type()) {
				boolean flg = false;
				MCRow inner = r.getInnerRow(meta.name());
				for (MCRootPanel p : getPartsPanels()) {
					for (MCContainer pCont : p.getContainers()) {
						if (inner == pCont) {
							flg = true;
							panels.add(p);
							break;
						}
					}
					if (flg) break;
				}
			}
		}
		return panels.toArray(new MCRootPanel[0]);
	}

	// RowMatcher 関連（ここから）

	private MCRowMatcher<?> _exceptDeleteAndEmpty;

	/**
	 * Rowに値が設定されていない行とRowStatusが Deleteの行を除いたリストを取得するためのMatcher
	 *
	 */
	@SuppressWarnings("rawtypes")
	public MCRowMatcher getExceptDeleteAndEmptyMatcher() {
		if (_exceptDeleteAndEmpty == null) {
			_exceptDeleteAndEmpty = new MatchExceptDeleteAndEmpty();
		}
		return _exceptDeleteAndEmpty;
	}

	/**
	 * Rowに値が設定されていない行とRowStatusが Deleteの行を除いた
	 * リストを取得するためのMatcher
	 */
	public class MatchExceptDeleteAndEmpty<T extends MCRow> implements MCRowMatcher<T> {
		@Override
		public boolean match(T row) {
			if (row.isStatusDelete()) {
				return false;
			}
			if (row.isEmpty()) {
				return false;
			}
			return true;
		}
	}

	private MCRowMatcher<?> _exceptRootDeleteAndEmpty;

	/**
	 * RootRowに値が設定されていない行とRowStatusが Deleteの行を除いたリストを取得するためのMatcher
	 *
	 */
	@SuppressWarnings("rawtypes")
	public MCRowMatcher getExceptRootDeleteAndEmptyMatcher() {
		if (_exceptRootDeleteAndEmpty == null) {
			_exceptRootDeleteAndEmpty = new MatchRootExceptDeleteAndEmpty();
		}
		return _exceptRootDeleteAndEmpty;
	}

	/**
	 * RootRowに値が設定されていない行とRowStatusが Deleteの行を除いた
	 * リストを取得するためのMatcher
	 */
	public class MatchRootExceptDeleteAndEmpty<T extends MCRow>
			implements MCRowMatcher<T> {
		@Override
		public boolean match(T row) {
			if (row.getRootRow().isStatusDelete()) {
				return false;
			}
			if (row.getRootRow().isEmpty()) {
				return false;
			}
			return true;
		}
	}

	/**
	 *
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	protected MCRowMatcher getDefCheckMatcher() {
		return getExceptRootDeleteAndEmptyMatcher();
	}

	@SuppressWarnings("rawtypes")
	private MCRowMatcher _exceptEmpty;

	/**
	 * Rowに値が設定されていない行を除いたリストを取得するためのMatcher
	 *
	 */
	@SuppressWarnings("rawtypes")
	public MCRowMatcher getExceptEmptyMatcher() {
		if (_exceptEmpty == null) {
			_exceptEmpty = new MatchExceptEmpty();
		}
		return _exceptEmpty;
	}

	/**
	 * Rowに値が設定されていない行を除いた
	 * リストを取得するためのMatcher
	 */
	public class MatchExceptEmpty<T extends MCRow> implements MCRowMatcher<T> {
		@Override
		public boolean match(T row) {
			if (row.isEmpty()) {
				return false;
			}
			return true;
		}
	}

	@SuppressWarnings("rawtypes")
	private MCRowMatcher _exceptRootEmpty;

	/**
	 * RootRowに値が設定されていない行を除いたリストを取得するためのMatcher
	 *
	 */
	@SuppressWarnings("rawtypes")
	public MCRowMatcher getExceptRootEmptyMatcher() {
		if (_exceptRootEmpty == null) {
			_exceptRootEmpty = new MatchExceptRootEmpty();
		}
		return _exceptRootEmpty;
	}

	/**
	 * RootRowに値が設定されていない行を除いた
	 * リストを取得するためのMatcher
	 */
	public class MatchExceptRootEmpty<T extends MCRow> implements MCRowMatcher<T> {
		@Override
		public boolean match(T row) {
			if (row.getRootRow().isEmpty()) {
				return false;
			}
			return true;
		}
	}

	@SuppressWarnings("rawtypes")
	protected MCRowMatcher getSameRowMatcher(MCList list) {
		MatchSameRow m = new MatchSameRow();
		m.set(list);
		return m;
	}

	@SuppressWarnings("rawtypes")
	public class MatchSameRow<T extends MCRow> implements MCRowMatcher<T> {
		protected Set _rootRowSet;

		@SuppressWarnings("unchecked")
		public void set(MCList list) {
			_rootRowSet = new HashSet();
			for (int i = 0; i < list.size(); i++) {
				_rootRowSet.add(list.get(i).getRootRow());
			}
		}

		@Override
		public boolean match(T row) {
			if (_rootRowSet.contains(row.getRootRow())) {
				return true;
			}
			return false;
		}
	}

	// RowMatcher 関連（ここまで）

	// 埋込画面用ユーティリティ（ここから）
	/**
	 * 部品と部品を明示的に関連付けるために使用するためのメソッド<br>
	 * 一つの画面に同一インターフェースを実装した部品が複数存在するケースで使用する。<br>
	 * （同じMCRootPanel上にIfItmを実装したA部品とB部品があり、X部品からA部品のIfItmを取得するようなケースにX部品のputLinkPartsにA部品を設定する）<br>
	 * 各部品が必要に応じて外部に公開すること。
	 * @param parts 本部品と関連付けたい部品
	 */
	protected void putLinkParts(IfParts parts) {

		if (parts == null) {
			return;
		}

		putLinkPartsPanel((MCRootPanel) parts);

	}

	/**
	 * 部品と部品を明示的に関連付けるために使用するためのメソッド<br>
	 * 通常は設定する必要は無いが、一つの画面に同一インターフェースを実装した部品が複数存在するケースで使用する。<br>
	 * （同じMCRootPanel上にIfItmを実装したA部品とB部品があり、X部品からA部品のIfItmを取得するようなケースにX部品のputLinkPartsにA部品を設定する）<br>
	 *
	 * @param clazz 関連付けたい部品を取得する際に使用するクラス
	 * @param parts 本部品と関連付けたい部品
	 */
	protected void putLinkParts(Class<?> clazz, IfParts parts) {
		Map<Class<?>, MCRootPanel> map = linkPartsPanels();
		MCRootPanel p = (MCRootPanel) parts;
		map.put(clazz, p);
	}

	/**
	 * 関連する部品をクラス（インターフェース）指定で取得する<br>
	 * 部品が存在しない場合はエラーになる
	 *
	 * @param <T> IfPartsを継承したクラス
	 * @param clazz クラスまたはインターフェース
	 * @return 指定したクラスまたはインターフェースを実装した部品
	 */
	protected <T extends IfParts> T getLinkParts(Class<T> clazz) {

		return getLinkPartsPanel(clazz);

	}

	/**
	 * 関連する部品をクラス（インターフェース）指定で取得する<br>
	 * 部品が存在しない場合にもエラーにならない
	 *
	 * @param <T> IfPartsを継承したクラス
	 * @param clazz クラスまたはインターフェース
	 * @return 指定したクラスまたはインターフェースを実装した部品
	 */
	protected <T extends IfParts> T getLinkPartsNE(Class<T> clazz) {

		return getLinkPartsPanelNE(clazz);

	}

	/**
	 * ベースパネルを取得する<br>
	 * 存在しない場合はエラー
	 *
	 * @param clazz 取得するベースパネルがimplementsしているインターフェースを指定する
	 * @return ベースパネル
	 */
	protected <T extends IfPartsBase> T getBase(Class<T> clazz) {

		return getLinkPartsPanel(clazz);

	}

	/**
	 * ベースパネルを取得する<br>
	 * 存在しない場合でもエラーにしない
	 *
	 * @param clazz 取得するベースパネルがimplementsしているインターフェースを指定する
	 * @return ベースパネル
	 */
	protected <T extends IfPartsBase> T getBaseNE(Class<T> clazz) {

		return getLinkPartsPanelNE(clazz);

	}

	/**
	 * 下り電文のcauseRowを、そのguiIndexと一致する引数のリストのrowで置き換える
	 *
	 * @param p 下り電文
	 * @param l 置き換える元となるリスト
	 * @return 下り電文に再設定された、結果のメッセージリスト
	 */
	protected MCMessageList mapRetParamCauseRow(MCParam p, MCList<?> l) {

		MCMessageList retmesL = p.getMessageParam().getMessage();
		sortMessageList(retmesL);

		// 結果のcauseRowを引数のリストのrowに設定しなおす
		if (retmesL != null) {
			for (MCMessage retmes : retmesL) {
				MCRow causeR = retmes.getCauseRow();
				if (causeR != null && causeR.getGUIIndex() >= 0) {
					retmes.setCauseRow(l.get(causeR.getGUIIndex()).getRootRow(), null);
				}
			}
		}

		p.getMessageParam().setMessage(retmesL);

		return retmesL;

	}

	/**
	 * 値設定時の例外かどうかを判定する
	 *
	 * @param ex 例外
	 * @return 値設定時の例外の場合にtrue
	 */
	protected boolean isSetValueEx(MCException ex) {
		return FXBAP0059.equals(ex.getID()) || FCBAC0058.equals(ex.getID());
	}

	/**
	 * リストロジックの検索条件を設定する。
	 *
	 * @param cnd 検索条件
	 * @param typs 定数
	 */
	protected void addListLogicCnd(MCRow cnd, FX_Const[] typs) {
		if (typs == null || typs.length == 0) {
			return;
		}
		for (FX_Const typ : typs) {
			cnd.addBooleanColumn(typ.key(), true);
		}
	}

	// 埋込画面用ユーティリティ（ここまで）
	// テーブル管理のユーティリティメソッド（ここから）
	/**
	 * InnerRow のカラム名を取得する。<br>
	 * 指定された埋込テーブルと連携する Row コンテナについて InnerRow のカラム名を取得する。<br>
	 * <br>
	 * テーブルに null や埋込テーブルではないテーブルを指定した場合は null を返す。<br>
	 * テーブルにテーブルカラムが配置されていない場合は null を返す。
	 *
	 * @param table テーブル
	 * @return InnerRow のカラム名または null
	 */
	protected String getInnerRowColumnName(MCTable<?> table) {
		if (table == null || !table.isPartsTable()) {
			return null;
		}
		MCColumnConfig[] a = table.getColumnConfigs();
		if (a.length == 0) {
			return null;
		}
		MCColumnConfig column = a[0];
		String[] base = MCRow.splitColumnPath(column.getBaseRowColumnName());
		String[] name = MCRow.splitColumnPath(column.getRowColumnName());
		int cnt = base.length - name.length;
		String[] rslt = new String[cnt];
		for (int i = 0; i < cnt; i++) {
			rslt[i] = base[i];
		}
		return MCRow.createColumnPath(rslt);
	}

	/**
	 * 土台テーブルが異なるテーブル部品と連動させる場合は true を返す。
	 *
	 * @return 土台テーブルが異なるテーブル部品と連動させない場合は false
	 */
	protected boolean isLinkOtherBaseTableParts() {
		return false;
	}

	/**
	 * テーブル部品に配置されているテーブルカラムの配列を取得する。<br>
	 * 行番号カラム、ステータスカラムは除外される。
	 *
	 * @return テーブルカラムの配列
	 * @see #getPartsViewColumnConfigs()
	 * @see #getPartsVisibleColumnConfigs()
	 */
	@SuppressWarnings("rawtypes")
	public MCColumnConfig[] getPartsColumnConfigs() {
		MCTable[] a = MCBeansUtil.getAllComponents(MCTable.class, this);
		MCTable tbl = null;
		for (MCTable t : a) {
			if (!(t instanceof MCFixedColumnTable)) {
				tbl = t;
				break;
			}
		}
		return tbl != null ? tbl.getColumnConfigs() : null;
	}

	/**
	 * テーブル部品に配置されているテーブルカラムの配列を取得する。<br>
	 * 行番号カラム、ステータスカラムは除外される。<br>
	 * モードで非表示にしているカラムは除外される。<br>
	 * カラム幅が 0 のカラムは除外される。
	 *
	 * @return テーブルカラムの配列
	 * @see #getPartsColumnConfigs()
	 * @see #getPartsVisibleColumnConfigs()
	 */
	@SuppressWarnings("rawtypes")
	public MCColumnConfig[] getPartsViewColumnConfigs() {
		MCTable[] a = MCBeansUtil.getAllComponents(MCTable.class, this);
		MCTable tbl = null;
		for (MCTable t : a) {
			if (!(t instanceof MCFixedColumnTable)) {
				tbl = t;
				break;
			}
		}
		return tbl != null ? tbl.getViewColumnConfigs() : null;
	}

	/**
	 * テーブル部品に配置されているテーブルカラムの配列を取得する。<br>
	 * 行番号カラム、ステータスカラムは除外される。<br>
	 * モードで非表示にしているカラムは除外される。
	 *
	 * @return テーブルカラムの配列
	 * @see #getPartsColumnConfigs()
	 * @see #getPartsViewColumnConfigs()
	 */
	@SuppressWarnings("rawtypes")
	public MCColumnConfig[] getPartsVisibleColumnConfigs() {
		MCTable[] a = MCBeansUtil.getAllComponents(MCTable.class, this);
		MCTable tbl = null;
		for (MCTable t : a) {
			if (!(t instanceof MCFixedColumnTable)) {
				tbl = t;
				break;
			}
		}
		return tbl != null ? tbl.getVisibleColumnConfigs() : null;
	}

	// テーブル管理のユーティリティメソッド（ここまで）
	// ファイル入力関連（ここから）
	/**
	 * ファイル入力におけるエラーメッセージのcauseRow、causeColumnを
	 * 取込用コンテナから表示用コンテナのものに変更したエラーメッセージを取得する。<br>
	 * 取込用コンテナと表示用コンテナの行番号は対応していなければならない。
	 * @param fileTable 取込用テーブル
	 * @param list 表示用テーブルのコンテナ
	 */
	protected <T extends MCTable<?>> MCMessageList getFileMsgList(T fileTable,
			MCList<? extends MCConstRow> list) {
		MCMessageList msgList = fileTable.getBeansReader().getMsgList();
		if (list.isEmpty()) return msgList;
		MCRow proto = list.createRow();
		for (MCMessage msg : msgList) {
			MCRow row = list.get(msg.getCauseRow().getGUIIndex());
			String msgCol = msg.getCauseColumn();
			String causeCol = proto.getRealColumnPath(msgCol);
			msg.setCauseRow(row, causeCol);
		}
		return msgList;
	}

	// ファイル入力関連（ここまで）
	// ＧＵＩ部品関連（ここから）
	/**
	 * タブペインの中のコンポーネント（タブ）の活性／非活性を設定します。
	 * <P>
	 * タブペインの中のコンポーネントの活性／非活性とは、
	 * タブの見出し部分の選択 可／不可 を制御することです。
	 * コンポーネントの中のオブジェクトの状態変更は行いません。
	 * </P>
	 * <P>
	 * タブペインの中のコンポーネントの中で、引数の活性状態にする
	 * コンポーネントに該当するコンポーネントは、活性状態になり、
	 * それ以外のコンポーネントは非活性状態になります。
	 * <br>
	 * タブペインの選択中のコンポーネントが、非活性になる場合は、
	 * タブの中の最も先頭の活性状態のタブを活性状態にします。
	 * 尚、全てのタブが非活性の場合は、選択中のコンポーネントは
	 * 変更されません。
	 * </P>
	 *
	 * @param tabPane 対象のタブペイン
	 * @param comps 活性状態にするコンポーネント
	 */
	public void setTabComponentEnable(MCTabbedPane tabPane,
			Component... enableComponents) {
		Component selectedComp = tabPane.getSelectedComponent();
		Component firstEnableComp = null;
		boolean isSelectedCompEnable = true;
		Component[] enableComps = enableComponents;
		if (enableComps == null) {
			enableComps = new Component[0];
		}

		for (int index = 0; index < tabPane.getTabCount(); index++) {
			Component currentComp = tabPane.getComponentAt(index);
			// 判定＆設定
			boolean isEnable = false;
			for (Component c : enableComps) {
				if (currentComp == c) {
					isEnable = true;
					break;
				}
			}
			tabPane.setEnabledAt(index, isEnable);

			// 選択タブが非活性になる場合の処置用の値を保存
			if (isEnable && firstEnableComp == null) {
				firstEnableComp = currentComp;
			}
			if (currentComp == selectedComp) {
				isSelectedCompEnable = isEnable;
			}
		}

		// 選択タブが非活性になる場合の処置
		if (!isSelectedCompEnable && firstEnableComp != null) {
			tabPane.setSelectedComponent(firstEnableComp);
		}
	}

	// ＧＵＩ部品関連（ここまで）
	// 見出しの表示桁（ここから）
	/**
	 * Rowに定義されている属性情報を取得します。
	 * <p>
	 * 対象のカラムが InnerRow の場合で、取得対象の
	 * Rowに属性が定義されていない、あるいは属性値が
	 * 定義されていない場合は、そのInnerRowに対して、
	 * 再帰的に属性値取得処理を行います。
	 * </p>
	 *
	 * @param row 属性情報を取得対象のRow
	 * @param extKey 属性のキー値
	 * @param columnPath 属性情報を所得するカラム
	 * @return 属性値
	 */
	protected String getExt(MCRow row, String extKey, String columnPath) {
		String[] splited = MCRow.splitColumnPath(columnPath);
		MCRow tar = row;
		for (int i = 0; i < splited.length; i++) {
			MCConstRow constTar = null;
			if (tar instanceof MCConstRow) {
				constTar = (MCConstRow) tar;
				Map<String, String> m = constTar.getExtMap(extKey);
				if (m != null) {
					String[] cPath = MCCollectionUtil.subArray(splited, i, splited.length,
							String.class);
					String ret = m.get(MCRow.createColumnPath(cPath));
					if (ret != null) {
						return ret;
					}
				}
			}
			if (i < splited.length - 1) {
				String[] rPath = MCCollectionUtil.subArray(splited, 0, i + 1,
						String.class);
				tar = row.getInnerRow(MCRow.createColumnPath(rPath));
			}
		}
		return null;
	}

	// 見出しの表示桁（ここまで）
	// その他（ここから）
	/**
	 * setValueして発生したエラーをエラーとしてそのままthrowするか、
	 * {@link MCMessageList}として返すかの判断を行う。
	 * <p>
	 * NE(NoError)系の処理で使用する。
	 */
	public MCMessageList handleExceptionForSetValueNE(Exception ex) {
		MCMessageList msgList = new MCMessageList();
		if (ex instanceof MCException) {
			MCException mcEx = (MCException) ex;
			MCMessage msg = mcEx.getMCMessage();
			MCMessageLevel msgLvl = msg.getLevel();
			if (MCMessageLevel.WARN.compareTo(msgLvl) >= 0) {
				msgList.add(msg);
				msgList.addAll(mcEx.getCauseMessageList());
			}
			else {
				throw mcEx;
			}
		}
		else {
			throw new MCAppException(ex);
		}
		return msgList;
	}

	/**
	 * 条件に応じてカラムのモードをデフォルトまたは非表示にする。
	 * @param tbl モードを変更するテーブルのインスタンス。
	 * @param column モードを変更するカラムコンフィグ。
	 * モードを変更するカラムの項目属性文字列に、cndのカラム名を設定する。
	 * 設定するカラムは、boolean型であること。
	 * @param cnd  モードを変更する条件。trueの場合、デフォルト。falseの場合、非表示。
	 * @param atrr モードを変更するカラムの項目属性ＩＤ。
	 */
	protected void changeColumnMode(MCTable<?> tbl, MCRow cnd, String atrr) {
		MCConstRow r = tbl.getList().createRow();
		for (MCColumnConfig column : tbl.getColumnConfigs()) {
			changeColumnMode(r, column, cnd, atrr);
		}
	}

	/**
	 * 条件に応じてカラムのモードをデフォルトまたは非表示にする。
	 * @param proto モードを変更するテーブルのＲＯＷインスタンス。
	 * @param column モードを変更するカラムコンフィグ。
	 * 項目属性文字列に、cndのカラム名を設定する。
	 * 設定するカラムは、boolean型であること。
	 * @param cnd  モードを変更する条件。trueの場合、デフォルト。falseの場合、非表示。
	 * @param atrr モードを変更するカラムの項目属性ＩＤ。
	 */
	protected void changeColumnMode(MCConstRow proto, MCColumnConfig column, MCRow cnd,
			String atrr) {
		String fullColName = column.getBaseRowColumnName();
		String[] splitedColName = MCRow.splitColumnPath(fullColName);
		Map<String, String> map = proto.getExtMap(atrr);

		MCTable<?> parts = null;
		String checkBoxColumnName = null;
		for (int i = splitedColName.length; i > 0; i--) {
			String[] path = MCCollectionUtil.subArray(splitedColName, 0, i, String.class);
			String val = map.get(MCRow.createColumnPath(path));
			if (!isNull(val)) {
				checkBoxColumnName = val;
				break;
			}
			if (parts == null) {
				parts = column.getTable();
			}
			else {
				parts = parts.getUnderTable();
			}
		}
		if (checkBoxColumnName == null) {
			return;
		}

		boolean isDefault = cnd.getBooleanNE(checkBoxColumnName);

		if (isDefault) {
			if (parts != null) {
				for (MCColumnConfig c : parts.getColumnConfigs()) {
					setDefaultMode(c);
				}
			}
			else {
				setDefaultMode(column);
			}
		}
		else {
			if (parts != null) {
				for (MCColumnConfig c : parts.getColumnConfigs()) {
					c.setMode(MCMode.INVISIBLE);
				}
			}
			else {
				column.setMode(MCMode.INVISIBLE);
			}
		}
	}

	/**
	 * 指定したグループのカラムコンフィグを返す。
	 * @param aTable 対象テーブルのインスタンス。
	 * @param aGroup 対象グループ（項目属性ＩＤ）。
	 * グループに含むのは実装仕様書で項目属性ＩＤに対し、
	 * 何かの文字列を設定しているカラム。
	 */
	protected ArrayList<MCColumnConfig> getGroupColumnConfigs(MCTable<?> aTable,
			String aGroup) {
		ArrayList<MCColumnConfig> confs = new ArrayList<>();
		MCConstRow row = aTable.getList().createRow();
		Map<String, String> map = row.getExtMap(aGroup);

		for (MCColumnConfig column : aTable.getColumnConfigs()) {
			String fullColName = column.getBaseRowColumnName();
			String[] splitedColName = MCRow.splitColumnPath(fullColName);
			MCTable<?> parts = null;

			for (int i = splitedColName.length; i > 0; i--) {
				String[] path = MCCollectionUtil.subArray(splitedColName, 0, i,
						String.class);
				String val = map.get(MCRow.createColumnPath(path));
				if (!isNull(val)) {
					confs.add(column);
					break;
				}
				if (parts == null) {
					parts = column.getTable();
				}
				else {
					parts = parts.getUnderTable();
				}
			}
		}
		return confs;
	}

	/**
	 * 指定した行を除いてソートします。
	 *
	 * @param table ソート対象のテーブル
	 * @param policy ソートの優先順位
	 * @param row ソートから除外する行
	 */
	@SuppressWarnings({
			"unchecked", "rawtypes"
	})
	protected boolean sortWithoutRow(MCTable<?> table, MCSortPolicy policy, MCRow row) {
		MCRow selectedRow = null;
		MCColumnConfig selectedCol = null;
		int index = -1;

		MCList list = table.getList();

		if (!isNull(list) && list.size() > 0) {
			selectedRow = table.getSelectedMCRow();
			selectedCol = table.getSelectedColumnConfig();
			index = list.lastIndexOf(row);
		}

		if (index < 0) {
			return super.sort(table, policy);
		}

		list.remove(index);
		boolean boo = super.sort(table, policy);
		list.add(row);

		if (!isNull(selectedRow) && row.equals(selectedRow)) {
			table.focusCellAt(index, selectedCol);
		}

		return boo;
	}

	/**
	 * 最下行を除いてソートします。
	 * 最下行に合計行がある場合などに使用します。
	 *
	 * @param table ソート対象のテーブル
	 * @param policy ソートの優先順位
	 */
	@SuppressWarnings("rawtypes")
	protected boolean sortWithoutBottom(MCTable<?> table, MCSortPolicy policy) {
		MCList list = table.getList();
		if (!isNull(list)) {
			return sortWithoutRow(table, policy, list.get(list.size() - 1));
		}
		return super.sort(table, policy);
	}

	// その他（ここまで）

	// 色取得（ここから）
	/**
	 * MCAppConst から設定値（色）を取得します。
	 * 指定した画面、または親画面の設定がない場合は、画面ＩＤ
	 * なしの設定を探します。
	 * 例えば、次の手順でリソースを探します。<br/>
	 * U.UAP0010.color.cell.sample.bg<br/>
	 * ⇒U.color.cell.sample.bg<br/>
	 * ⇒C.color.cell.sample.bg<br/>
	 *
	 * @param panel リソース取得対象のパネル
	 * @param keys moduleId , screenId 以降のタグの配列
	 * @return 色
	 */
	public Color getPgmSettingColorDef(FXBAP_PanelBase panel, String... keys) {
		try {
			return getPgmSettingColor(panel, keys);
		}
		catch (MCException e) {
			if (e.getID().equals(FXBAP0036)) {
				String[][] ids = {
						{
								panel.getModuleID()
						}, {
								FXBAP_PanelBase.MODULE_ID
						}
				};
				for (String[] s : ids) {
					String[] keyArray = MCCollectionUtil.concat(s, keys);
					String key = MCConst.createKey(keyArray);
					if (MCConst.app.containsKey(key)) {
						return MCConst.app.getColor(key);
					}
				}
				throw e;
			}
			else {
				throw e;
			}
		}
	}

	// 色取得（ここまで）

	// 画面遷移連携と実装が似てる ここから
	/**
	 * 現在のシステムでのこの画面の連携用のURLを返します。
	 *
	 * @return URL文字列。多重起動防止がポートモード以外の場合は null
	 */
	public String getScreenURL() {
		List<MCRowBeans> list = new ArrayList<>();
		if (this instanceof IfSrchCndBase) {
			// 検索条件枠にのみ連携可能
			MCRowBeans[] rbs = getSrchCndBeans(this);
			for (MCRowBeans rb : rbs) {
				if (rb instanceof MCModeBeans
						&& !(isVisibleInBaseAllStatuses((MCModeBeans) rb))) {
					// 活性化しないカラムには連携できない
					// この判定はxAppsじゃないとできない・・・
					continue;
				}
				list.add(rb);
			}
		}
		MCRowBeans[] conds = list.toArray(new MCRowBeans[list.size()]);
		return MCSingleStartup.openURL(this, true, conds);
	}

	/**
	 * 入力値設定対象枠の GUI 部品のリストを返します。
	 *
	 * @param rp 入力値設定機能を利用する画面
	 * @return  GUI 部品のリスト
	 */
	protected MCRowBeans[] getSrchCndBeans(IfSrchCndBase rp) {
		List<Object[]> list = FXUCP_SrchCndUtil.getSrchCndBeans(rp, true);
		MCRowBeans[] rbs = new MCRowBeans[list.size()];
		for (int i = 0; i < rbs.length; i++) {
			Object[] objs = list.get(i);
			rbs[i] = (MCRowBeans) objs[1];
		}
		return rbs;
	}
	// 画面遷移連携と実装が似てる ここまで

	/**
	 * 運用日付を返します。
	 *
	 * @return 運用日付
	 */
	public MCDate getToday() {
		return today(MCDataType.DATE);
	}

	/**
	 * @deprecated 基本的に {@link #getToday()} を利用してください。
	 */
	@Override
	@Deprecated
	public <E extends MCCalendarDate<E>> E today(MCDataType type) {
		return super.today(type);
	}

	/**
	 * パーソナライズの画面部品非表示用メソッド
	 * この戻り値に非表示にする画面部品を設定することで画面部品がinvisibleされる。
	 * @return  List<MCLayoutLocationR>
	 */
	@Override
	public List<MCLayoutLocationR> getSystemLocationComponent() {
		List<MCLayoutLocationR> list = new ArrayList<>();

		MCAutoLayout autoLayout = new MCAutoLayout();
		autoLayout.setupTargetPanel(this);
		autoLayout.setupPanelList();

		MCModeBeans[] modeBeans;
		modeBeans = MCBeansUtil.getAllComponents(MCModeBeans.class, this);
		if (modeBeans != null) {
			for (MCModeBeans bean : modeBeans) {
				boolean b = isVisibleInBaseAllStatuses2(bean);
				if (b == false) {
					if (bean instanceof Component) {

						MCLayoutLocationR r = new MCLayoutLocationR();
						r.isVisible(false);
						r.componentID(bean.getName());
						MCRootPanel rp = autoLayout.getRootPanel((Component) bean);
						r.rootPanelID(rp.getName());
						Container p = autoLayout.getParentPanel((Component) bean);
						r.panelID(p.getName());
						r.rootPanelID(rp.getName());
						list.add(r);

						MCLayoutLocationR r2 = new MCLayoutLocationR();
						r2.isVisible(false);
						r2.componentID(bean.getName() + "_Label");
						r2.rootPanelID(rp.getName());
						r2.panelID(p.getName());
						r2.rootPanelID(rp.getName());
						list.add(r2);
					}
				}
			}
		}

		return list;
	}

	/**
	 * 複数値が入力できるフィールドである場合は、trueを返します。
	 *
	 * @param compo 対象フィールド
	 * @return 複数値が入力できるフィールドである場合は、true
	 */
	protected boolean isPluralValueField(MCLinkBeans compo) {
		if (compo instanceof MCPluralValueField) {
			return ((MCPluralValueField) compo).isPluralValueEnable();
		}
		return false;
	}

	@Override
	protected MCErrorHandler createErrorHandler() {
		return new FXBAP_ErrorHandler(this);
	}

	// 7012-2037 (メインメニューがメモリーリークする
	// メモリーリークのの発生を抑制するためFXUCP_ToolBarUtil_FWでstatic変数を廃止
	private FXUCP_ToolBarUtil _toolbarUtil;
	@Deprecated
	public FXUCP_ToolBarUtil _getToolBarUtil() {
		return _toolbarUtil;
	}
	@Deprecated
	public void _setToolBarUtil(FXUCP_ToolBarUtil toolbarUtil) {
		_toolbarUtil = toolbarUtil;
	}
	// 7012-2037 ここまで

	/**
	 * 画面遷移連携設定に追加で表示するバインド行を返します。
	 * @param m 対象の項目と値のマップまたはnull
	 * @return バインド行
	 */
	public MCList<OpenScreenParamR> getOpnScrBinds(Map<String, Comparable<?>> m) {
		return null;
	}
	
	/**
	 * 画面遷移連携設定に追加で表示するバインド行を決定するためのGUI部品を取得します。
	 * 画面遷移連携設定起動時にのみ使用されます。
	 *　MCTextFieldまたはMCTextComboBoxのみ有効です。
	 *　「連携元（固定値）」の「テキスト」に、GUI部品のリストロジックのリストが入力補助として表示できるようになります。
	 *　リストには表示用カラム「_view」が必要です。
	 * @return GUI部品
	 */
	public ArrayList<MCRowBeans> getOpnScrBindsChangeTriggers() {
		return null;
	}

	/**
	 * ツールバーの画面遷移ボタン使用時の画面起動区分を返します。
	 * @return 画面起動区分
	 */
	public String getOpnScrOpenTyp() {
		return null;
	}
}

class FXBAP_PanelBaseUtil {

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public String getPgmSettingString(Class<? extends Object> clazz, String... keys) {
		return getPgmSettingString(MCBeansUtil.getModuleAndScreenIDs(clazz), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected String getPgmSettingString(String[][] ids, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getString(k);
			}
		}
		String[] ms = new String[] {
				ids[0][0], ids[0][1]
		};
		String[] a = MCCollectionUtil.concat(ms, keys);
		String k = MCConst.createKey(a);
		throw new MCAppException(FXBAP0036, k);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	protected String getPgmSettingStringNE(String[][] ids, String def, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getString(k, def);
			}
		}
		return def;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public MCNumber getPgmSettingNumber(Class<?> clazz, String... keys) {
		return getPgmSettingNumber(MCBeansUtil.getModuleAndScreenIDs(clazz), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected MCNumber getPgmSettingNumber(String[][] ids, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getNumber(k);
			}
		}
		String[] ms = new String[] {
				ids[0][0], ids[0][1]
		};
		String[] a = MCCollectionUtil.concat(ms, keys);
		String k = MCConst.createKey(a);
		throw new MCAppException(FXBAP0036, k);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	protected MCNumber getPgmSettingNumberNE(String[][] ids, MCNumber def,
			String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getNumber(k, def);
			}
		}
		return def;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected Color getPgmSettingColor(Class<?> clazz, String... keys) {
		return getPgmSettingColor(MCBeansUtil.getModuleAndScreenIDs(clazz), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected Color getPgmSettingColor(String[][] ids, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getColor(k);
			}
		}
		String[] ms = new String[] {
				ids[0][0], ids[0][1]
		};
		String[] a = MCCollectionUtil.concat(ms, keys);
		String k = MCConst.createKey(a);
		throw new MCAppException(FXBAP0036, k);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	protected Color getPgmSettingColorNE(String[][] ids, Color def, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getColor(k, def);
			}
		}
		return def;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public int getPgmSettingInt(Class<?> clazz, String... keys) {
		return getPgmSettingInt(MCBeansUtil.getModuleAndScreenIDs(clazz), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected int getPgmSettingInt(String[][] ids, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				MCNumber n = MCConst.app.getNumber(k);
				return n != null ? n.intValue() : null;
			}
		}
		String[] ms = new String[] {
				ids[0][0], ids[0][1]
		};
		String[] a = MCCollectionUtil.concat(ms, keys);
		String k = MCConst.createKey(a);
		throw new MCAppException(FXBAP0036, k);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	protected int getPgmSettingIntNE(String[][] ids, int def, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				MCNumber n = MCConst.app.getNumber(k);
				return n != null ? n.intValue() : def;
			}
		}
		return def;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public boolean getPgmSettingBoolean(Class<?> clazz, String... keys) {
		return getPgmSettingBoolean(MCBeansUtil.getModuleAndScreenIDs(clazz), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected boolean getPgmSettingBoolean(String[][] ids, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getBoolean(k);
			}
		}
		String[] ms = new String[] {
				ids[0][0], ids[0][1]
		};
		String[] a = MCCollectionUtil.concat(ms, keys);
		String k = MCConst.createKey(a);
		throw new MCAppException(FXBAP0036, k);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	protected boolean getPgmSettingBooleanNE(String[][] ids, boolean def,
			String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getBoolean(k, def);
			}
		}
		return def;
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param clazz リソース取得対象のクラス
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	public char getPgmSettingChar(Class<?> clazz, String... keys) {
		return getPgmSettingChar(MCBeansUtil.getModuleAndScreenIDs(clazz), keys);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 * @throws MCAppException [FXBAP0036] リソース値が見つからなかった場合
	 */
	protected char getPgmSettingChar(String[][] ids, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getCharacter(k);
			}
		}
		String[] ms = new String[] {
				ids[0][0], ids[0][1]
		};
		String[] a = MCCollectionUtil.concat(ms, keys);
		String k = MCConst.createKey(a);
		throw new MCAppException(FXBAP0036, k);
	}

	/**
	 * {@link mcframe.clientCore.resource.MCAppConst} からリソース値を取得します。<p>
	 * リソース値が見つからなかった場合は、デフォルト値を返します。
	 *
	 * @param ids モジュールＩＤ、画面ＩＤの配列
	 * @param def デフォルト値
	 * @param keys リソースキーのタグの配列（モジュールＩＤ、画面ＩＤより後）
	 * @return リソース値
	 */
	protected char getPgmSettingCharNE(String[][] ids, char def, String... keys) {
		for (String[] id : ids) {
			String[] a = MCCollectionUtil.concat(id, keys);
			String k = MCConst.createKey(a);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getCharacter(k, def);
			}
		}
		return def;
	}
	
	
	
}