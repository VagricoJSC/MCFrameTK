package mcframe.clientFXBA.FXBAP0010;

import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientCore.requester.MCCaller;
import mcframe.clientCore.requester.paging.MCPagingParam;
import mcframe.commonCore.util.MCUtil;

/**
 * ページングエージェントの実行時の条件を格納するクラスです。
 * FXBAP_Searcherを使用したページング機能を実装する場合に使用します。
 */
public class FXBAP_PagingParam_FW extends MCPagingParam {
	/**
	 * 表示上のブロックID
	 */
	final String[] _dispBlkIds;
	/**
	 * ページングを実行するCallerのruntimeクラス。
	 */
	final Class _clr;
	
	/**
	 * コンストラクタです。
	 * @param blkId ページング対象のブロック
	 * @param clr runtimeのCallerクラス
	 * @param tbls 表示テーブル（ページング対象と異なるブロックのテーブルがデータ表示対象の場合に設定する）
	 */
	public FXBAP_PagingParam_FW(String blkId, Class<? extends FXBAP_Searcher> clr, MCTable... tbls) {
		super(blkId);
		_clr = MCUtil.requireNonNull(clr, "clr");
		_dispBlkIds = getDispBlockIds(MCUtil.requireNonNull(tbls, "tbls"));
	}
	/**
	 * コンストラクタです。<p>
	 * ページング対象のブロックと表示対象のブロックが異なる場合は引数にMCTableを受けとるコンストラクタを使用してください。
	 * @param blkId ページング対象のブロック
	 * @param clr runtimeのCallerクラス
	 */
	public FXBAP_PagingParam_FW(String blkId, Class<? extends FXBAP_Searcher> clr) {
		super(blkId);
		_clr = MCUtil.requireNonNull(clr, "clr");
		_dispBlkIds = new String[]{blkId};
	}
	/**
	 * コンストラクタです。
	 * XUP9020を使用している場合はsizeは無効です。
	 * @param blkId ページング対象のブロック
	 * @param size ページングサイズ（XUP9020を使用している場合は無効）
	 * @param clr runtimeのCallerクラス
	 * @param tbls 表示テーブル（ページング対象と異なるブロックのテーブルがデータ表示対象の場合に設定する）
	 */
	public FXBAP_PagingParam_FW(String blkId, int size, Class<? extends FXBAP_Searcher> clr,
			MCTable... tbls) {
		super(blkId, size);
		_clr = MCUtil.requireNonNull(clr, "clr");
		_dispBlkIds = getDispBlockIds(MCUtil.requireNonNull(tbls, "tbls"));
	}
	/**
	 * コンストラクタです。<p>
	 * ページング対象のブロックと表示対象のブロックが異なる場合は引数にMCTableを受けとるコンストラクタを使用してください。<p>
	 * XUP9020を使用している場合はsizeは無効です。
	 * @param blkId ページング対象のブロック
	 * @param size ページングサイズ
	 * @param clr runtimeのCallerクラス
	 */
	public FXBAP_PagingParam_FW(String blkId, int size, Class<? extends FXBAP_Searcher> clr) {
		super(blkId, size);
		_clr = MCUtil.requireNonNull(clr, "clr");
		_dispBlkIds = new String[]{blkId};
	}

	protected static String[] getDispBlockIds(MCTable... tbls) {
		String[] d = new String[tbls.length];
		for(int i = 0; i < tbls.length ; i++){
			MCTable t = tbls[i];
			d[i] = t.getRootPanel().getBlockId(t.getList());
		}
		return d;
	}
	
	/**
	 * ページング対象のruntimeのCallerクラスを返します。
	 * @return Callerクラス
	 */
	public Class<MCCaller> getTargetCaller() {
		return _clr;
	}

	/**
	 * 表示上のブロックIDを返します。
	 * ページング対象のブロックと、表示するテーブルのブロックが異なる場合、表示するテーブルのブロックを返します。
	 * @return　表示上のブロックIDまたはnull
	 */
	public String[] getDispBlockIds() {
		return _dispBlkIds;
	}
}
