package mcframe.clientFXBA.FXBAP0010;

import static mcframe.commonFX.notice.FX_Msg.*;

import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageLevel;
import mcframe.commonCore.notice.MCMessageList;

public class FXBAP_Deleter_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_RootUpdater<P, O> {
	/**
	 * コンストラクタです。
	 *
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_Deleter_FW(P panel, O operation) {
		super(panel, operation);
	}
	
	@Override
	protected MCCallBackType callPanelUpdateAction() {
		unlockScreen();
		show();
		statusClear();
		setMode();
		moveFocus();
		showMsg();
		print();
		resultSuccess();
		return MCCallBackType.SUCCESS;
	}
	
	/**
	 * 下り電文上限数の設定をします。
	 * <p>
	 * デフォルト実装：リミットなしにする
	 * </p>
	 */
	@Override
	protected void setLimitDLSize() {
		param().setLimitDLSize(MCNumber.valueOf(-1));
	}

	/**
	 * ステータスをクリアします。
	 * <p>
	 * デフォルト実装：何もしない
	 * </p>
	 */
	protected void statusClear() {
		// 何もしない
	}

	/**
	 * 登録対象の明細が存在しない場合のメッセージを表示します。
	 */
	@Override
	protected void showNoUpListDataMsg() {
		panel.dialog(FXBAP0016);
	}

	/** クラス名 */
	// メモ：リソースをとるのに必要
	protected static final String FXBAP_Deleter = "FXBAP_Deleter";

	/**
	 * [YES]/[NO] ダイアログを表示します。
	 *
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 */
	public int confirm(String id, Object... binds) {
		return confirm(new MCMessage(id, binds));
	}

	/**
	 * [YES]/[NO] ダイアログを表示します。
	 *
	 * @param msg メッセージ
	 * @return 選択されたボタン
	 */
	@SuppressWarnings("deprecation")
	public int confirm(MCMessage msg) {
		MCDialogButton btn = panel.getConfirmFocus(msg);
		if (btn == null) {
			btn = panel.getConfirmFocus(FXBAP_Deleter);
		}
		return panel.confirm(btn, msg);
	}

	/**
	 * 削除処理の実行を確認するメッセージを返す。
	 */
	@Override
	protected MCMessage msgExecConfirm() {
		return panel.msgDeleteConfirm();
	}

	/**
	 * Callerの初期化をします。非表示ブロックへのデータのコピーなど
	 */
	@Override
	protected void initCaller() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.initCaller();

	}

	/**
	 * 通信を行うためのチェックを行います。
	 * <p>
	 * デフォルト実装：{@link #checkForCallStack(MCMessageList)}を呼び出し、戻り値のリストが
	 * １件以上ある場合はメッセージダイアログを出し、falseを返す。それ以外はtrue
	 * </p>
	 *
	 * @return 通信可能な場合 true 通信を行わない場合 false
	 */
	@Override
	protected boolean checkForCall() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		return super.checkForCall();
	}

	/**
	 * 複数のチェックを行い、エラーがあった場合のメッセージを msgList に格納します。
	 * <P>
	 * デフォルト実装：{@link #checkReq(MCMessageList) checkReq(MCMessageList)}を呼び出す。
	 * </P>
	 *
	 * @param msgList
	 */
	@Override
	protected void checkForCallStack(MCMessageList msgList) {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.checkForCallStack(msgList);
	}

	@Override
	protected void checkForCallStackParts(MCMessageList list) {
		// メモ：削除処理ではデフォルトでは checkForCallStackParts(list)
		// を呼ばない。
	}

	/**
	 * 必須チェックを行い、必須の箇所が空白だった場合は、そのメッセージを msgListに 格納します。
	 * <P>
	 * デフォルト実装：何もしない（必須チェックしない）
	 * </P>
	 *
	 * @param msgList
	 */
	@Override
	protected void checkReq(MCMessageList msgList) {
		// 何もしない
	}

	/**
	 * 電文の初期化
	 */
	@Override
	protected void setupParam() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.setupParam();
	}

	/**
	 * 削除前処理。上り電文の作成直前の処理。
	 */
	@Override
	protected void beforeCall() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.beforeCall();
	}

	/**
	 * 削除後処理。下り電文を画面表示する前に加工する
	 */
	@Override
	protected void afterCall() {
		// 実装は空だがEclipseでオーバーライドしやすいようにわざと実装しておく
		super.afterCall();
	}

	/**
	 * 削除結果を画面用のコンテナにのせかえる
	 */
	@Override
	protected void show() {
		showMerge();
	}

	/**
	 * 削除処理が終了した時のメッセージ
	 */
	public MCMessage msgDeleted() {
		return panel.msgDeleted();
	}

	/**
	 * 登録処理が終了したが、サーバーからメッセージがあった場合に、その先頭に使用するメッセージ。
	 */
	public MCMessage msgDeletedWithMessages() {
		MCMessage m = msgDeleted();
		if (m != null) {
			return new MCMessage(FXBAP0031, m.toString());
		}
		return new MCMessage(FXBAP0032);
	}

	/**
	 * メッセージリストの先頭に処理終了を伝えるメッセージを追加する
	 */
	@Override
	protected void showDownMsg() {
		MCMessageList msgList = getMessages();
		panel.sortMessageList(msgList);
		MCMessage msg = msgDeletedWithMessages();
		if (msg != null) {
			msgList.add(0, msg);
		}
		panel.messageNoSort(msgList);
	}

	/**
	 * 削除ロジックが終了したときのメッセージを表示します。
	 */
	@Override
	protected void showEndMsg() {
		panel.dialog(msgDeleted());
	}

	/**
	 * 削除対象が存在しない場合のメッセージ
	 */
	public MCMessage msgNoDeleteData() {
		return panel.msgNoDeleteData();
	}

	/**
	 * 上り電文情報が存在しないときの処理を行います。<br>
	 * メッセージを表示します。
	 */
	@Override
	protected void showNoUpDataMsg() {
		panel.dialog(msgNoDeleteData());
	}

	/**
	 * サーバ処理で例外が発生したときの処理を実行します。
	 * 特に理由がない限り、例外を throw します。
	 *
	 * @param ex MCException
	 */
	@Override
	protected void handleMCEx(MCException ex) {
		if (isOperationMightBeSuccess(ex)) {
			handleOperationMightBeSuccessMCEx(ex);
		}
		if (isAddFailedMsg(ex)) {
			throw addFailedMsg(ex);
		}
		throw ex;
	}

	/**
	 * サーバ処理で例外が発生したときの処理を実行します。
	 * オペレーションが正常終了したかもしれない場合に実行されます。
	 *
	 * @param ex MCException
	 */
	protected void handleOperationMightBeSuccessMCEx(MCException ex) {
		setMode();
		moveFocus();
	}

	/**
	 * 通信後のフォーカス設定を行います。
	 * <p>
	 * デフォルト実装：何もしない。（setModeで画面ステータスを変更することで）
	 * </p>
	 * <p>
	 * setModeで設定されるフォーカス位置では困る場合のみ実装する。
	 * </p>
	 */
	@Override
	protected void moveFocus() {
	}

	/**
	 * 削除できなかったときのメッセージ
	 */
	public MCMessage msgFailed() {
		return panel.msgDeleteFailed();
	}

	/**
	 * メッセージの先頭に削除失敗メッセージ（ {@link #msgFailed()} ）を追加するかどうかを判断する。
	 * メッセージを追加する場合は true を返す。
	 *
	 * @param ex 例外
	 * @return メッセージを追加しない場合は false
	 */
	protected boolean isAddFailedMsg(MCException ex) {
		if (MCMessageLevel.WARN != ex.getLevel()) {
			return false;
		}
		if (isOperationMightBeSuccess(ex)) {
			return false;
		}

		MCMessageList l = ex.getCauseMessageList();
		if (l != null && l.size() > 0) {
			return false;
		}
		return true;
	}

	/**
	 * メッセージの先頭に削除失敗メッセージ（ {@link #msgFailed()} ）を追加する。<p>
	 * 削除失敗メッセージの例外を新たに作成し、指定された例外のメッセージを
	 * {@link MCException#addCauseMessage(MCMessage)} で追加する。<p>
	 * <font color="red">
	 * このメソッドを利用した場合は、指定された例外が保持している、
	 * メッセージ（ {@link MCException#getMCMessage()} ）
	 * 以外の情報は破棄されるため、注意してください。
	 * </font>
	 *
	 * @param ex 例外
	 * @return 例外（引数の例外とは異なるインスタンス）
	 */
	protected MCException addFailedMsg(MCException ex) {
		MCException e;
		if (ex instanceof MCAppException) {
			e = new MCAppException(ex, msgFailed());
		}
		else {
			e = new MCException(ex, msgFailed());
		}
		e.addCauseMessage(ex.getMCMessage());
		return e;
	}
}