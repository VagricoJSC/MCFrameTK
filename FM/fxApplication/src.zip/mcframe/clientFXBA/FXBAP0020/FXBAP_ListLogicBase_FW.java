package mcframe.clientFXBA.FXBAP0020;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.beans.list.*;
import static mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase.*;
import static mcframe.commonFX.notice.FX_Msg.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_ListLogicBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_ListLogicBase_FW extends FXBAP_ListLogicBase_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_ListLogicBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	protected final MCCacheType _cache = getListCacheTyp();

	protected static final String $CACHE_TYP = MCListCacher2.$CACHE_TYP;

	protected static final String FXBAP_LIST_LOGIC_MODULE_ID = "FX";

	protected static final String FXBAP_LIST_LOGIC_SCREEN_ID = "FXBAP0020";

	/**
	 * リストロジッククラスの検索結果のキャッシュタイプを返します。<p>
	 */
	protected MCCacheType getListCacheTyp() {
		
		
		// メモ：リストロジッククラスメソッドのキャッシュタイプは、
		// AppClientリソース にて
		// X.XPP0030.cache_typ に設定するのがリストロジッククラス全体のキャッシュタイプ
		// [moduleID].[ScreenID].cache_typ に設定するのがそのリストロジッククラスのキャッシュタイプ
		// どちらかが設定されていないと例外が発生する
		// （基本的には全体が設定されているので例外は発生しませんが）。
		//
		// ツールListLogicSheetで自動生成した場合は、モジュールID,画面IDは作成されないため、常に本クラスのリソースが取得されます。

		String key = MCConst.createKey(getModuleID(), getScreenID(), $CACHE_TYP);
		if (MCConst.app.containsKey(key)) {
			String s = MCConst.app.getString(key);
			try {
				return MCCacheType.valueOf(s);
			}
			catch(Exception e) {
				throw new MCException(Core_Msg.FCUCC0020, 
						MCConst.app.getFileBase(), key, s);
			}
		}

		key = MCConst.createKey(FXBAP_LIST_LOGIC_MODULE_ID, FXBAP_LIST_LOGIC_SCREEN_ID,
				$CACHE_TYP);
		if (MCConst.app.containsKey(key)) {
			String s = MCConst.app.getString(key);
			try {
				return MCCacheType.valueOf(s);
			}
			catch(Exception e) {
				throw new MCException(Core_Msg.FCUCC0020, 
						MCConst.app.getFileBase(), key, s);
			}
		}

		throw new MCAppException(FXBAP0036, key);
	}
	
	/** 
	 * リストロジッククラスの検索結果のキャッシュタイプを返します。
	 * 
	 */
	protected MCCacheType getListCacheTyp(MCRow row, MCEventInfo info) {

		if (info != null && _cache == MCCacheType.NONE) {
			MCRootPanel p = info.getComponent().getRootPanel();
			
			//jbInitとかで呼ばれるとRootPanelにaddする前にここに来る可能性があるためnullチェックをしている
			if(p != null){	
				MCCacheType c = p.getCacheType(info);
				if(c != null){
					return c;
				}
			}
		}
		
		return _cache;
	}
	/**
	 * サーバ側からリストを取得し、表示用カラムを追加したリストを返します。
	 * <p>
	 * 
	 * @param keyCol 入力値を持つカラム
	 * @param viewCols
	 * @param logicMethod
	 * @param bind
	 * @param info
	 * @param ct
	 * @return
	 */
	protected MCList<MCRow> getList(String[] viewCols, String logicMethod, MCRow bind,
			MCEventInfo info, MCCacheType ct) {

		/* リスト取得 */
		MCList<MCRow> down = getList(logicMethod, bind, info, ct);

		/* 初期表示カラムデータ作成 */
		addDefDispColumn(viewCols, down, info);

		return down;
	}

	/**
	 * サーバ側からリストを取得します。<p>
	 * MCListConfig.INPUT時にはinfoのnewValueと一致したRowに限定して返します。
	 * @param logicMethod
	 * @param bind
	 * @param info
	 * @param ct
	 * @return
	 */
	protected MCList<MCRow> getList(String logicMethod, MCRow bind, MCEventInfo info,
			MCCacheType ct) {
		
		String opeTyp = null;
		if (info != null && info.getComponent() instanceof MCLinkBeans) {
			MCLinkBeans b = (MCLinkBeans) info.getComponent();
			MCListConfig c = b.getListConfig();

			setInputValue(bind, c, info.getNewValue());
			opeTyp = c.getOpeType();
		}
		else {
			opeTyp = MCListConfig.LIST;
		}
		return getList(ct, bind, logicMethod, opeTyp);
	}

	/**
	 * MCListConfig.INPUT時に呼び出されたEventの場合、<br>
	 * Rowに入力値カラムを追加し、入力値を格納します。
	 */
	protected void setInputValue(MCRow row, MCListConfig c, Comparable<?> newValue) {

		if (MCListConfig.INPUT.equals(c.getOpeType())) {
			row.setValueNE($INPUT_VAL, newValue);
		}

	}

}