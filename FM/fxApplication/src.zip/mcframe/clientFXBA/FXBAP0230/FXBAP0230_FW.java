package mcframe.clientFXBA.FXBAP0230;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFXBA.FXBAP0190.*;


//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.MCValueSupply;

import javax.swing.Box;
import javax.swing.BoxLayout;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0230"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0230_FW extends FXBAP0230_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0230_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		super.layoutInit();

		Value_from_PPanel.layoutInit();
		Value_to_PPanel.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BoxLayout(ValuePanel, BoxLayout.X_AXIS));

		// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)

		// 7013-2313(MF_C01_214_高解像度のテストNGまとめ)
		// Value_from_PPanelの中身だけをaddする。
		// 分割してしまうとfromとtoのサイズがかわってしまう。0110
		for (Component c : MCBeansUtil.getAllComponents(Component.class, (MCRootPanel) Value_from_PPanel)) {
			if (c instanceof MCLabel || c instanceof MCDateField) {
				if (c instanceof  MCDateField) {
					_putMaxMap(c, c.getPreferredSize());
				}
				ValuePanel.add(c);
			}
		}
		// ValuePanel.add(Value_from_PPanel);

		ValuePanel.add(_createRigidArea(LAYOUT_MARGIN, LAYOUT_MARGIN, 100, null));
//		ValuePanel.add(Box.createRigidArea(new Dimension(5, 5)));
		ValuePanel.add(Value_between);

		for (Component c : MCBeansUtil.getAllComponents(Component.class, (MCRootPanel) Value_to_PPanel)) {
			if (c instanceof MCLabel || c instanceof MCDateField) {
				if (c instanceof  MCDateField) {
					_putMaxMap(c, c.getPreferredSize());
				}
				ValuePanel.add(c);
			}
		}
		// ValuePanel.add(Value_to_PPanel);
		// 7013-2313 ここまで

		_putMaxMap(Value_between, Value_between.getPreferredSize());
		_putMaxMap(Value_to_PPanel, Value_to_PPanel.getPreferredSize());
		// 7013-0007 ここまで

		Value_to_PPanel.Value_value.setName("to");
		Value_from_PPanel.Value_value.setName("from");
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		// モードは入力状態で動的に変更する
		return null;
	}

	@Override
	public String getStatusFor(MCValueSupply...param) {
		// 開始日で判定
		return super.getStatusFor(param);
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] {
				Value_from_PPanel.getParam()[0],
				Value_to_PPanel.getParam()[0]
		};
	}

	/**
	 * パラメータを設定します。
	 *
	 * @param param パラメータの配列（0:開始日、1:終了日）
	 */
	@Override
	public void setParam(MCValueSupply...param) {
		Value_from_PPanel.setParam(param[0]);
		Value_to_PPanel.setParam(param[1]);
		Value_to_PPanel.Value_value_Label.setText("");// TOのラベルは使用しない

		// 最大サイズ調整
		FXBAP0190[] parts = { Value_from_PPanel, Value_to_PPanel };
		for (FXBAP0190 part : parts) {
			Dimension d = part.Value_value.getMaximumSize();
			d.width += part.Value_value_Label.getPreferredSize().width;
			d.width += LAYOUT_MARGIN;
			part.setMaximumSize(d);
		}
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		MCRowBeans bean = null;
		if ((bean = Value_from_PPanel.checkRequiredValue()) != null) {
			return bean;
		}
		if ((bean = Value_to_PPanel.checkRequiredValue()) != null) {
			return bean;
		}
		return bean;
	}

	@Override
	public void updateParam() {
		Value_from_PPanel.updateParam();
		Value_to_PPanel.updateParam();
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

}