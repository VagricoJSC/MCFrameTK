package mcframe.clientFXBA.FXBAP0090;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0130.FXBAP_ExpandUnit;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_KeyAction"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_KeyAction_FW extends FXBAP_KeyAction_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_KeyAction_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * テーブル内検索画面を起動します。
	 */
	protected void findCell(MCEditorBeans b) {
		// 現在入力中の値を確定できない場合

		if (b != null && b.getTable() != null) {
			MCTable<?> tbl = b.getTable();
			if (!MCBeansUtil.requestCommit(tbl)) {
				// 現在入力中の値を確定できない場合
				// rowの値に戻すことによってフォーカス移動できる状況にする。
				// （rowと同じ値の場合、確定チェックが走らないので必ず確定できる）
				b.setRowToView();
			}
			findCell(b.getTable());
		}
	}

	/**
	 * テーブル内検索画面を起動します。
	 */
	public void findCell(MCTable<?> tbl) {
		MCRootPanel p = tbl.getBaseRootPanel();
		if (p instanceof FXBAP_PanelBase) {
			/** findCell のモジュールＩＤ */
			final String sitModID = "FX";
			/** findCell の画面ＩＤ */
			final String sitScreenID = "FXUCP0050";

			if (sitModID.equals(p.getModuleID()) && sitScreenID.equals(p.getScreenID())) {
				return;
			}
			MCTable<?> baseTable = tbl.getBaseTable();
			FXBAP_PanelBase appPanel = (FXBAP_PanelBase) p;

			MCRootPanel findCell = MCBeansUtil.getRootPanel(sitModID, sitScreenID,
					appPanel);
			if (findCell != null) {
				findCell.moveToFront();
			}
			else {
				appPanel.openModalPanel(sitModID, sitScreenID, FXBAP_PanelBase.T1, null,
						baseTable);
			}
		}
//		if (tbl != null) {
//			MCRootPanel p = tbl.getBaseRootPanel();
//			if (p instanceof FXBAP_PanelBase) {
//				/** findCell のモジュールＩＤ */
//				final String sitModID = "FX";
//				/** findCell の画面ＩＤ */
//				final String sitScreenID = "FXUCP0050";
//
//				if (sitModID.equals(p.getModuleID())
//						&& sitScreenID.equals(p.getScreenID())) {
//					// 何もしない
//				}
//				else {
//					MCTable<?> baseTable = tbl.getBaseTable();
//					FXBAP_PanelBase appPanel = (FXBAP_PanelBase) p;
//					appPanel.openChildPanel(sitModID, sitScreenID, MCPanelType.SINGLE,
//							FXBAP_PanelBase.T1, null, baseTable);
//				}
//			}
//		}
	}

	/**
	 * 入力補助画面を開く
	 */
	protected void openIS(MCField compo) {
		compo.doDC();
	}
	
	/**
	 * 入力補助画面を開く
	 */
	protected void openIS(MCFieldComboBox<?> compo) {
		compo.setPopupVisible(false);
		compo.doDC();
	}

	/**
	 * すべてのテーブルカラム幅の調整をします。
	 */
	protected void adjustAllWidth(MCEditorBeans b) {
		adjustWidthMain(b, true/*all*/);
	}
	/**
	 * すべてのテーブルカラム幅の調整をします。
	 */
	public void adjustAllWidth(MCTable<?> tbl) {
		adjustWidthMain(tbl, true/*all*/ );
	}
	/**
	 * パーソナライズで許可されたテーブルカラム幅の調整をします。
	 */
	protected void adjustWidth(MCEditorBeans b) {
		adjustWidthMain(b, false/*not all*/);
	}
	/**
	 * パーソナライズで許可されたテーブルカラム幅の調整をします。
	 */
	public void adjustWidth(MCTable<?> tbl) {
		adjustWidthMain(tbl, false/*not all*/ );
	}
	
	protected void adjustWidthMain(MCEditorBeans b, boolean all){
		if (b != null && b.getTable() != null) {
			MCTable<?> tbl = b.getTable();
			adjustWidthMain(tbl, all);
		}
	}
	
	protected void adjustWidthMain(MCTable<?> tbl, boolean all){
		if (tbl != null) {
			tbl.toggleColumnWidth(all);
		}
	}
	
	/**
	 * 検索枠を展開します。
	 * 指定された画面が検索枠展開部品を利用していない場合は何もしません。、
	 * 
	 * @param panel 画面
	 */
	public void expandSrchPanel(MCRootPanel panel) {
		expandSrchPanel(panel, true);
	}
	
	/**
	 * 検索枠を収納します。
	 * 指定された画面が検索枠展開部品を利用していない場合は何もしません。、
	 *
	 * @param panel 画面
	 */
	public void contractSrchPanel(MCRootPanel panel) {
		expandSrchPanel(panel, false);
	}
	
	/**
	 * 検索枠を展開または収納します。
	 * 指定された画面が検索枠展開部品を利用していない場合は何もしません。、
	 *
	 * @param panel 画面
	 * @param expand 展開する場合はtrue、収納する場合はfalse
	 */
	protected void expandSrchPanel(MCRootPanel panel, boolean expand) {
		FXBAP_ExpandUnit[] pa = MCBeansUtil.getAllComponents(FXBAP_ExpandUnit.class, panel);
		for (FXBAP_ExpandUnit p : pa) {
			MCButton o = expand ? p.Ope_open : p.Ope_close;
			if (o.doButtonAction()) {
				return;
			}
		}
	}

}