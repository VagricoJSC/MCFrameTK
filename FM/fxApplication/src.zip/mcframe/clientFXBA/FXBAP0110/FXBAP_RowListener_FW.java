package mcframe.clientFXBA.FXBAP0110;

import mcframe.clientCore.container.MCRowEvent;
import mcframe.clientCore.container.MCRowListener;
import mcframe.clientCore.container.MCRowStatusEvent;
import mcframe.clientCore.container.MCRowStatusListener;

public class FXBAP_RowListener_FW implements MCRowListener, MCRowStatusListener {

	@Override
	public void valueChanged(MCRowEvent event) {
		
	}

	@Override
	public void statusChanged(MCRowStatusEvent event) {
		
	}	
}
