package mcframe.clientFXBA.FXBAP0110;

import mcframe.commonCore.annotation.EI;

@EI
public class FXBAP_RowListener extends FXBAP_RowListener_FW {
	
}