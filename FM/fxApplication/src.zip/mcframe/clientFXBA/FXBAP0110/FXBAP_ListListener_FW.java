package mcframe.clientFXBA.FXBAP0110;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Arrays;
import mcframe.clientCore.container.MCRowListener;
import mcframe.clientCore.container.MCRowStatusListener;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_ListListener"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_ListListener_FW extends FXBAP_ListListener_FW_A implements MCListListener {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_ListListener_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// インターフェースの実装（ここから）

	public void listCleared(MCListEvent event) {
		clearSum(event);
	}

	public void listSorted(MCListEvent event) {
		// no action
	}

	public void rowAdded(MCListEvent event) {
		addRowListenerToAddedRows(event);
		addRowStatusListenerToAddedRows(event);
		setDefaultRowValues(event);
		setSum(event);
	}

	public void rowRemoved(MCListEvent event) {
		removeRowListenerFromRemovedRows(event);
		removeRowStatusListenerFromRemovedRows(event);
		setSum(event);
	}

	public void rowRemoved(MCListEvent[] events) {
		for (MCListEvent event : events) {
			removeRowListenerFromRemovedRows(event);
			removeRowStatusListenerFromRemovedRows(event);
			setSum(event);
		}
	}

	public void rowSet(MCListEvent event) {
		// no action
	}

	// インターフェースの実装（ここまで）
	// 合計値関連（ここから）
	/**
	 * 空メソッド<br>
	 * 明細の合計などを計算するメソッドを下位クラスで実装する<br>
	 * 合計を取得する必要があると想定される rowAdded/rowRemoved で呼び出される
	 * 
	 * @param event イベント情報
	 */
	protected void setSum(MCListEvent event) {
	}

	/**
	 * 空メソッド<br>
	 * 明細の合計などをクリアするメソッドを下位クラスで実装する<br>
	 * 合計をクリアする必要があると想定される listCleared で呼び出される
	 * 
	 * @param event イベント情報
	 */
	protected void clearSum(MCListEvent event) {
	}

	/**
	 * 各行のデフォルト値を設定するメソッド(setDefaultRowValue(MCRow))を呼び出す<br>
	 * デフォルト値を設定する必要があると想定される rowAdded で呼び出される<br>
	 * 実装は setDefaultRowValue(MCRow) にすること
	 * 
	 * @param event イベント情報
	 * @deprecated
	 */
	protected void setDefaultRowValues(MCListEvent event) {

		MCList<?> l = event.getSourceList();
		int fr = event.getIndex();
		int to = fr + event.getCount();
		for (int i = fr; i < to; i++) {
			setDefaultRowValues(l.get(i));
		}

	}

	/**
	 * 空メソッド<br>
	 * 各行のデフォルト値を設定するメソッドを下位クラスで実装する<br>
	 * デフォルト値を設定する必要があると想定される rowAdded で呼び出される
	 * 
	 * @param row 初期値を設定する行
	 */
	protected void setDefaultRowValues(MCRow row) {
	}
	// 合計値関連（ここまで）

	// RowにListenerをセットする（ここから）
	/**
	 * リストイベント情報を元に追加されたMCRowに{@link MCRowListener}を設定する
	 * 
	 * @param event リストイベント
	 */
	protected void addRowListenerToAddedRows(MCListEvent event) {

		MCList<?> l = event.getSourceList();
		int fr = event.getIndex();
		int to = fr + event.getCount();
		for (int i = fr; i < to; i++) {
			MCConstRow row = (MCConstRow) l.get(i);
			for (MCRowListener listener : rowListener()) {
				row.removeRowListener(listener);
				row.addRowListener(listener);
			}
		}
	}
	
	/**
	 * リストイベント情報を元に追加されたMCRowに {@link MCRowStatusListener} を設定する
	 * 
	 * @param event リストイベント
	 */
	protected void addRowStatusListenerToAddedRows(MCListEvent event) {
		MCList<?> l = event.getSourceList();
		int fr = event.getIndex();
		int to = fr + event.getCount();
		for (int i = fr; i < to; i++) {
			MCConstRow row = (MCConstRow) l.get(i);
			for (MCRowStatusListener listener : statusListener()) {
				row.removeRowStatusListener(listener);
				row.addRowStatusListener(listener);
			}
		}
	}

	// RowにListenerをセットする（ここまで）
	
	// RowからListenerを削除する（ここから）
	
	/**
	 * リストイベントの情報を元に、削除された MCRow から MCRowListener を削除する。
	 *
	 * @param event リストイベント
	 */
	protected void removeRowListenerFromRemovedRows(MCListEvent event) {
		for (MCRow o : event.getRemoveRows()) {
			MCConstRow c = (MCConstRow) o;
			for (MCRowListener n : rowListener()) {
				c.removeRowListener(n);
			}
		}
	}
	
	/**
	 * リストイベントの情報を元に、削除された MCRow から MCRowStatusListener を削除する。
	 *
	 * @param event リストイベント
	 */
	protected void removeRowStatusListenerFromRemovedRows(MCListEvent event) {
		for (MCRow o : event.getRemoveRows()) {
			MCConstRow c = (MCConstRow) o;
			for (MCRowStatusListener n : statusListener()) {
				c.removeRowStatusListener(n);
			}
		}
	}

	// RowからListenerを削除する（ここまで）
	
	// listenerの受け取り（ここから）
	private List<MCRowStatusListener> _statusListener;

	protected List<MCRowStatusListener> statusListener() {
		if (_statusListener == null) {
			_statusListener = new ArrayList<MCRowStatusListener>();
		}
		return _statusListener;
	}

	/**
	 * listに所属するRowにセットする {@link MCRowStatusListener} を追加します。
	 * @param listeners
	 */
	public void addRowStatusListener(MCRowStatusListener... listeners) {
		if (listeners == null || listeners.length == 0) {
			return;
		}
		List<MCRowStatusListener> list = statusListener();
		list.addAll(Arrays.asList(listeners));
	}

	private List<MCRowListener> _rowListener;

	protected List<MCRowListener> rowListener() {
		if (_rowListener == null) {
			_rowListener = new ArrayList<MCRowListener>();
		}
		return _rowListener;
	}

	/**
	 * listに所属するRowにセットする {@link MCRowListener} を追加します。
	 * @param listeners
	 */
	public void addRowListener(MCRowListener... listeners) {
		if (listeners == null || listeners.length == 0) {
			return;
		}
		List<MCRowListener> list = rowListener();
		list.addAll(Arrays.asList(listeners));
	}
	// listenerの受け取り（ここまで）

}