package mcframe.clientFXBA.FXBAP0200;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.commonCore.sys.MCFactory;

import java.util.Arrays;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0200"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0200_FW extends FXBAP0200_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * ラベル
	 */
	protected MCLabel Value_value_Label = null;

	/**
	 * 値用パネル
	 */
	protected MCPanel Value_value_Panel = null;
	/**
	 * パラメータ
	 */
	protected MCValueSupply.StringVS _param = null;

	/**
	 * Paramから渡されたコンボ用List
	 */
	protected MCList<ListR> _listL;
	/**
	 * リストロジック
	 */
	protected MCListLogic listLogic = null;
	/**
	 * リストメソッド
	 */
	protected String listMethod = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0200_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FXBAP0200_FW(mcframe.clientFXBA.FXBAP0200.ValueR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Value END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		super.layoutInit();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BorderLayout(LAYOUT_MARGIN, 0));

		Value_value_Label = beansFactory.createLabel("Value.value_Label");
		Value_value.setLabel(Value_value_Label);

		Value_value_Panel = beansFactory.createPanel("Value.value_Panel");
		Value_value_Panel.setOpaque(false);
		Value_value_Panel.setLayout(new BorderLayout(LAYOUT_MARGIN, 0));
		Value_value_Panel.add(Value_value, BorderLayout.WEST);
		Value_value_Panel.add(Value_name, BorderLayout.CENTER);

		ValuePanel.add(Value_value_Label, BorderLayout.WEST);
		ValuePanel.add(Value_value_Panel, BorderLayout.CENTER);
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return new MCModeBeans[] { Value_value };
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param };
	}

	@Override
	public void setValueList(MCList<ListR> listL) {
		_listL = listL;
		if (_listL != null) {
			// Paramのコンボ使用 > 表示カラム設定
			Value_value.setListVisibleColumn(ListR.$value, ListR.$name);
		}
	}

	@Override
	public void setParam(MCValueSupply...param) {
		_param = (MCValueSupply.StringVS) param[0];
		Value_value_Label.setText(_param.name());	// 表示名称の設定
		Value_value.setMessageName(_param.name());	// メッセージ用表示名称の設定

		// 初期値 -> コンボ連携を動作させる
		String value = (String) _param.value();
		Value_value.setValue(value);
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		return (_param.required() && getValueR().value() == null)
				? Value_value : null;
	}

	@Override
	public void updateParam() {
		_param.value(getValueR().value());
	}

	@Override
	public MCList getValue_value(MCRow row, MCEventInfo info){
		if (_listL != null) {
			// Paramからのリスト使用時
			// indexを使うまでもない？
			return _listL.subList(ListR.$item, _param.column());
		}
		// リストロジック使用時
		return (MCList) MCFactory.invoke(listLogic, listMethod,
				new Class<?>[] { MCRow.class, MCEventInfo.class },
				new Object[] { row, info }
		);
	}


	/**
	 * リストロジックを設定します。
	 *
	 * @param method リスト取得メソッド（[リストロジッククラス].[メソッド]）
	 * @param cols リストロジックカラム名（[コードカラム],[名称カラム]）
	 */
	public void setListLogic(String method, String cols) {
		// リストロジック
		int ext = method.lastIndexOf('.');
		String logic = method.substring(0, ext);
		listMethod = method.substring(ext + 1);
		listLogic = (MCListLogic) MCFactory.invokeStatic(MCListLogic.class, "create",
				new Class<?>[] { String.class, MCRootPanel.class },
				new Object[] { logic, this }
		);

		// 連携カラム（名称カラム以降は無視）
		String[] colarray = cols.split(",");
		colarray = Arrays.copyOf(colarray, 2);
		getValue_value_ListPutter().setColumns(colarray);
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

}