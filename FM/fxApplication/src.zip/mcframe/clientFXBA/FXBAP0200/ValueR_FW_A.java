package mcframe.clientFXBA.FXBAP0200;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Value"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ValueR_FW_A extends MCConstRow {

	/**
	 * 文字列 文字列.<p>
	 *
	 */
	public static final String $value = "value";
	/**
	 * 名称 名称.<p>
	 *
	 */
	public static final String $name = "name";


	public static final MCMeta value_META = createStringMeta($value, 10);
	public static final MCMeta name_META = createStringMeta($name);

	protected static final ConstMetaList<ValueR> constMetas = new ConstMetaList<ValueR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			value_META,
			name_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ValueR_FW_A(ConstMetaList<? extends ValueR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ValueR clone() {
		return (ValueR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ValueR createInstance() {
		return (ValueR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ValueR getValues(String... names) {
		return (ValueR) super.getValues(names);
	}



	/**
	 * 文字列 文字列.<p>
	 *
	 */
	public String value() {
		return getConstString(offset + 0, $value);
	}

	/**
	 * 文字列 文字列.<p>
	 *
	 */
	public void value(String value) {
		setConstString(offset + 0, $value, value);
	}


	/**
	 * 名称 名称.<p>
	 *
	 */
	public String name() {
		return getConstString(offset + 1, $name);
	}

	/**
	 * 名称 名称.<p>
	 *
	 */
	public void name(String value) {
		setConstString(offset + 1, $name, value);
	}


	public String getString(String name) {
		if ($value.equalsIgnoreCase(name)) {
			return value();
		}
		if ($name.equalsIgnoreCase(name)) {
			return name();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($value.equalsIgnoreCase(name)) {
			return value();
		}
		if ($name.equalsIgnoreCase(name)) {
			return name();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($value.equalsIgnoreCase(name)) {
			value(value);
			return;
		}
		if ($name.equalsIgnoreCase(name)) {
			name(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($value.equalsIgnoreCase(name)) {
			value(value);
			return;
		}
		if ($name.equalsIgnoreCase(name)) {
			name(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

