package mcframe.clientFXBA.FXBAP0070;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.border.Border;

import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0050.IfRLBase;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import static mcframe.commonFX.notice.FX_Msg.*;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_RLCellConfig"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_RLCellConfig_FW extends FXBAP_RLCellConfig_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_RLCellConfig_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	protected IfRLBase _implRLBasePanel;

	protected IfRLBase implRLBasePanel() {
		if (_implRLBasePanel == null) {
			throw new MCAppException(FXBAP0074);
		}
		return _implRLBasePanel;
	}

	protected FXBAP_PanelBase _panel;

	protected FXBAP_PanelBase panel() {
		if (_panel == null) {
			throw new MCAppException(FXBAP0074);
		}
		return _panel;
	}

	/**
	 * @param panel {@link IfRLBase}を実装していること
	 */
	public void setPanel(FXBAP_PanelBase panel) {
		_panel = panel;
		if (panel instanceof IfRLBase) {
			_implRLBasePanel = (IfRLBase) panel;
		}
		else {
			throw new MCAppException(FXBAP0075);
		}
	}

	/**
	 * デフォルトのモードを取得する<br>
	 * CPP_RLBaseを親に持つベース画面がFIXの場合にREAD_ONLYをデフォルトとする
	 * 
	 * @param index テーブルの行
	 * @param column テーブルのカラムコンフィグ
	 * @param table テーブル
	 * @return デフォルトのモード
	 */
	@Override
	protected MCMode getDefaultMode(int index, MCColumnConfig column, MCTable table) {
		if (panel().getStatus() == implRLBasePanel().getFIXStatus()) {
			return MCMode.READ_ONLY;
		}

		return null;
	}

	public Color getPriorBG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode) {
		return null;
	}

	public Color getPriorBG(int index, MCColumnConfig column, MCTable table, MCMode mode) {
		return null;
	}

	public Border getPriorEditorBorder(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	public Color getPriorFG(int index, MCColumnConfig column, MCTable table,
			boolean selected, MCMode mode) {
		return null;
	}

	public Color getPriorFG(int index, MCColumnConfig column, MCTable table, MCMode mode) {
		return null;
	}

	public int getPriorLength(int index, MCColumnConfig column, MCTable table) {
		return -1;
	}

	public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {
		return null;
	}

	public int getPriorScale(int index, MCColumnConfig column, MCTable table) {
		return -1;
	}

}