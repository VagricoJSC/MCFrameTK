package mcframe.clientFXBA.FXBAP0130;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.layout.MCBorderLayout;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.JSplitPane;

import mcframe.clientCore.beans.MCBeansUtil;
import mcframe.clientCore.beans.MCFrame;
import mcframe.clientCore.beans.MCPanel;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.MCScrollPane;
import mcframe.clientCore.beans.MCSplitPane;
import mcframe.clientCore.event.MCEventInfo;

//FMCB CUSTOM_IMPORT END


/**
 * 画面"FXBAP_ExpandUnit"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_ExpandUnit_FW extends FXBAP_ExpandUnit_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 開閉するSplitPane
	 */
	protected MCSplitPane ExpandSplit;
	/**
	 * ディバイダサイズ
	 */
	private int dividerSize = 2;
	/**
	 * 下部最小値計算用補正値（見た目から調整）
	 */
	private int reviseSize = 2;

	// MCSplitPaneに移動
	// private Boolean bothend = null;

	private boolean _initResizeMinimum2 = false;
	private PropertyChangeListener propertyChangeListener = null;

	/**
	 * 伸縮用のSplitPaneの初期のディバイダ位置です。
	 */
	private int _initDividerLocation = -1;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_ExpandUnit_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected void _layoutInit() {
		layoutNorth();
		super._layoutInit();
	}

	// ダウンロードボタンとY位置を合わせるためSouthからNorthに変更
	protected void layoutNorth() {
		// SOUTHでダウンロードボタンとの縦位置がずれる場合に対応
		MCPanel p = (MCPanel)this.getParent();
		if(p != null) {
			LayoutManager lmgr = p.getLayout();
			if(lmgr instanceof BorderLayout) {

				int vgap = 0;
				Component c[] = getParent().getParent().getComponents();
				for(Component p3 : c) {
					if(p3 instanceof MCPanel && p3.getName().equals("Ctrl")) {
						if(((MCPanel)p3).getLayoutPosition().equals("SC") == true) {
							// ダウンロードボタンがない場合はマージン5必要
							vgap = 5;
							break;
						}
					}
				}

				// MCExpandBorderLayoutに変更
				BorderLayout b1 = new MCExpandBorderLayout(0,vgap);
				p.setLayout(b1);

				BorderLayout b = (BorderLayout)lmgr;
				// SOUTHからNORTHに変更
				// 上部にダミーパネルを付与。
				Component c2 = b.getLayoutComponent(BorderLayout.SOUTH);
				if(c2 != null) {
					b1.addLayoutComponent(c2,BorderLayout.CENTER);
					b1.setVgap(5);
				}
				Component c3 = b.getLayoutComponent(BorderLayout.NORTH);
				if(c3 != null) {
					b1.addLayoutComponent(c2,BorderLayout.CENTER);
					b1.setVgap(5);
				}
			}
		}
	}

	@Override
	public boolean beforeOpen() {
		boolean b = super. beforeOpen();
		getExpandSplitPane().setExpandSplitPane(true); // 7.0.1
		setDividerSize();

		// 7012-0850 noda【多言語】多言語対応の調査・対応（画面レイアウト、ガントチャート、グラフ、業務フロー）
		// 多言語化で検索枠の高さが変化した場合に隙間ができすぎるため再調整する。
		for (MCPanel p : MCBeansUtil.getAllComponents(MCPanel.class, getBaseRootPanel())) {
			if ("Fold.base".equals(p.getName())) {
				if (p.getLayout() instanceof MCBorderLayout) {
					MCBorderLayout la = (MCBorderLayout) p.getLayout();
					Component c = la.getLayoutComponent(MCBorderLayout.SOUTH);
					if (c != null) {
						// Sパネルが邪魔なため高さをなくす。
						Dimension d = new Dimension(c.getSize().width, 0);
						c.setSize(d);
						c.setPreferredSize(d);
					}
				}
				break;
			}
		}
		// 7012-0850 noda ここまで

		// 検索枠に縦スクロールバーが現れる場合に画面サイズを変更する。
		for (MCScrollPane sp : MCBeansUtil.getAllComponents(MCScrollPane.class, getBaseRootPanel())) {
			if ("Fold.scroll".equals(sp.getName())) {
				Component c = sp.getViewport().getComponents()[0];
				// バッチIF系画面に対応
				if(((MCPanel) c).getComponents().length == 0) {
					// frameサイズ調整不要
					break;
				}
				Component tp = ((MCPanel) c).getComponents()[0];
				int h1 = sp.getHeight(); // ScrollPaneの高さ
				int h2 = tp.getHeight(); // タブPaneの高さ
				if (h1 < h2) {
					// frameサイズを広げて調整
					MCRootPanel rp = getBaseRootPanel();
					MCFrame frame = rp.getFrame();
					Dimension d = frame.getSize();
					int w = sp.getVerticalScrollBar().getPreferredSize().width;
					frame.setSize((int) frame.getSize().getWidth() + w, (int) frame.getSize().getHeight());
				}
				break;
			}
		}
		return b;
	}

	private void setDividerSize() {
		// ディバイダ設定
		getExpandSplitPane().setDividerSize(dividerSize);
		getExpandSplitPane().setOneTouchExpandable(false);
	}

	@Override
	public void panelClosed() {
		// 不要になったListenerを削除
		if(ExpandSplit != null) {
			if(propertyChangeListener != null) {
				ExpandSplit.removePropertyChangeListener(propertyChangeListener);
				propertyChangeListener = null;
			}
		}

		super.panelClosed();
	}

	/**
	 * 伸縮用のSplitPaneを返します。
	 *
	 * @return SplitPane。SplitPaneに追加されていない場合は null
	 */
	public MCSplitPane getExpandSplitPane() {
		if (ExpandSplit == null) {
			ExpandSplit = getSplitPane(this);
		}
		MCRootPanel rp = ExpandSplit.getBaseRootPanel();
		if(rp == null) {
			// 再自動レイアウトでnullになってしまう場合がある。
			if(propertyChangeListener != null) {
				ExpandSplit.removePropertyChangeListener(propertyChangeListener);
				propertyChangeListener = null;
			}

			ExpandSplit = getSplitPane(this);
			expandInit();
		}
		return ExpandSplit;
	}

	/**
	 * 伸縮枠を開閉します。
	 * <p>
	 * 土台画面のパーソナライズ設定（検索枠自動開閉）で「自動で開閉しない」と
	 * している場合は開閉しません。
	 *
	 * @param open 検索枠を開く場合 true、閉じる場合 false
	 */
	public void expand(boolean open) {
		MCRootPanel rp = getBaseRootPanel();

		// BARCODE対応
		if(rp.isBarcodeMode() == true) {
			return;
		}

		expand(open, false);
	}

	/**
	 * 伸縮枠を開閉します。
	 * <p>
	 * 開閉をアニメーションにした場合、アニメーションは非同期で動作するため、
	 * メソッドはアニメーションが終了する前に戻ります。
	 * <p>
	 * 土台画面のパーソナライズ設定（検索枠自動開閉）で「自動で開閉しない」と
	 * している場合は開閉しません。
	 *
	 * @param open 検索枠を開く場合 true、閉じる場合 false
	 * @param anime アニメーションさせる場合 true
	 */
	// アニメーションはfillSpaceと相性が悪いため使用不可 > private 化
	private void expand(boolean open, boolean anime) {
		// 7013-1574 念のためアニメ版の公開に備え、自動開閉はこのメソッドで調整
		if (!getBasePanelExpandMode()) {
			expandImpl(open, anime);
		}
	}

	/**
	 * この埋め込み画面を利用している土台画面の検索枠自動開閉モードを返します。
	 * @since     7.0.1.2
	 * @return 土台画面の検索枠自動開閉モード。自動開閉しない場合 true
	 */
	private boolean getBasePanelExpandMode() {
		MCRootPanel bp = this.getBaseRootPanel();
		if (bp instanceof mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase) {
			mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase pane =
					(mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase)bp;
			return pane.getExpandMode();
		}
		return false;
	}

	/**
	 * 伸縮枠を開閉します。
	 * <p>
	 * 開閉をアニメーションにした場合、アニメーションは非同期で動作するため、
	 * メソッドはアニメーションが終了する前に戻ります。
	 *
	 * @param open 検索枠を開く場合 true、閉じる場合 false
	 * @param anime アニメーションさせる場合 true
	 */
	// 7013-1574 メソッド名変更
	private void expandImpl(boolean open, boolean anime) {
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		getExpandSplitPane().setBothEnd(open);
		if (open) {
			int pos = getExpandSplitPane().getMaximumDividerLocation();
			getExpandSplitPane().setDividerLocationWithoutRatio(pos);
		} else {
			int pos = getExpandSplitPane().getMinimumDividerLocation();
			getExpandSplitPane().setDividerLocationWithoutRatio(pos);
		}
	}

	/**
	 * 伸縮用に初期化します。
	 *
	 * この部品がSplitPane上部に含まれている必要があります。
	 *
	 */
	public void expandInit() {
		getExpandSplitPane();// ExpandSplit 未取得の場合は取得する
		if (ExpandSplit == null) {
			return;
		}

		getExpandSplitPane().setExpandSplitPane(true);
		getExpandSplitPane().setResizeWeight(0.0);

		if (propertyChangeListener != null) {
			getExpandSplitPane().removePropertyChangeListener(propertyChangeListener);
			propertyChangeListener = null;
		}
		propertyChangeListener = new PropertyChangeListener() {
			@Override
			public void propertyChange(PropertyChangeEvent evt) {
				if (MCSplitPane.DIVIDER_LOCATION_PROPERTY.equals(evt.getPropertyName())
						|| MCSplitPane.LAST_DIVIDER_LOCATION_PROPERTY.equals(evt.getPropertyName())) {
					// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
					int pos = getExpandSplitPane().getDividerLocationWithRatio();
					int min = getExpandSplitPane().getMinimumDividerLocation();
					int max = getExpandSplitPane().getMaximumDividerLocation();

					if (pos != min && pos != max) {
						// 手動操作
						getExpandSplitPane().setBothEnd(null);
					} else if (pos == min) {
						// 最小化
						getExpandSplitPane().setBothEnd(false);
					} else if (pos == max) {
						// 最大化
						getExpandSplitPane().setBothEnd(true);
					}
				}
			}
		};
		getExpandSplitPane().addPropertyChangeListener(propertyChangeListener);

		// ディバイダ設定 beforeOpenに移動
		getExpandSplitPane().setDividerSize(dividerSize);
		getExpandSplitPane().setOneTouchExpandable(false);

		if (_initResizeMinimum2 == false) { // パネルの最大値計算が狂うため多重初期化しないようにする
			_initResizeMinimum2 = true;
			// 最小サイズ調整
			resizeMinimum(getExpandSplitPane(), true, false);
		}
	}

	// 検索枠内部の部品とスクロールバーが被る場合があるため補正するかどうかを計算する。
	private void _resizeFrame() {
		// ユーザでサイズが設定されている場合はなにもしない。
		if (getBaseRootPanel().useUserResourceBounds()) {
			return;
		}

		MCScrollPane sp = null;
		for (MCScrollPane s : MCBeansUtil.getAllComponents(MCScrollPane.class, getBaseRootPanel())) {
			if ("Fold.scroll".equals(s.getName())) {
				sp = s;
				break;
			}
		}
		// 横スクロールバーが表示されている場合は自動拡大する。
		if(sp != null) {
			boolean b = sp.getHorizontalScrollBar().isVisible();

			// 簡易バグ票No.212の対応（ここから）
			if (b == true) {
				// 縦クロールバーが現れると13ドット横幅が狭くなるため横スクロールバーも現れる。
				// 画面の拡大が必要になる。

				MCRootPanel bp = getBaseRootPanel();
				Dimension ps = bp.getPreferredSize();

				int w = sp.getVerticalScrollBar().getPreferredSize().width;
				bp.setPreferredSize(new Dimension(ps.width + w, ps.height));

				Dimension fs = getFrame().getSize();
				getFrame().setSize(fs.width + w, fs.height);
			}

		}
	}

	private int _minHeight = -1;

	/**
	 * 上下の最小サイズを再設定します。
	 *
	 */
	// 自動レイアウト用に対応させる
	// init 初期化時に呼ばれたときtrue
	// resize リサイズ時に呼ばれたときtrue
	@Override
	public void resizeMinimum(MCSplitPane splitPane, boolean init, boolean resize) {
		if (splitPane == null) {
			return;
		}

		Container top = (Container) splitPane.getTopComponent();
		Container bottom = (Container) splitPane.getBottomComponent();
		Dimension min;

		// 上部最小サイズ
		// この部品が配置されているContainerの高さを優先
		Container parent = getParent();
		min = top.getMinimumSize();
		min.height = (parent == null) ? getHeight() : parent.getHeight();
		top.setMinimumSize(min);

		// 下部最小サイズ
		min = bottom.getMinimumSize();
		Dimension topSize = top.getPreferredSize();// top.getSize();
		min.height = getMinimumHeight(bottom);
		if (_minHeight == -1) {
			_minHeight = min.height;
		}
		int root_h = splitPane.getSize().height;
		if (topSize.height < (root_h - (min.height + dividerSize + reviseSize))) {
			min.height = root_h - (topSize.height + dividerSize + reviseSize);
		}

		// 下部の最小値を変更しdividerが下がれるようにする。
		if (init == true) {
			splitPane.resetSaveHeight();
//			double h = splitPane.getToptPanelHeight(true);
//			double h2 = Math.max(splitPane.getHeight() - h - dividerSize, 0.0);
//			min.height = (int) h2;
//			bottom.setMinimumSize(min);

			min.height = 0;
			bottom.setMinimumSize(min);
		}
		// 上部パネルの最大値を設定
		double h3 = splitPane.getToptPanelHeight(true) + dividerSize;
		top.setMaximumSize(new Dimension(0, (int) h3));
	}


	/**
	 * ディバイダ位置をデフォルト位置に移動します
	 */
	public void setDefaultDividerLocation() {
		getExpandSplitPane().resetSaveHeight();

		resetDividerLocation(false);

		// スクロールバーが表示されてしまう場合はframeを拡大する。
		_resizeFrame();
	}

	private boolean _resetFlag = false;

	private HashMap<MCSplitPane, Container>_dividerPanelMap1;
	private HashMap<MCSplitPane, Container>_dividerPanelMap2;

	@Override
	public void resetDividerLocation(boolean needsUpdate) {
		if (needsUpdate == false) {
			// １回だけ実行する
			if (_resetFlag) {
				return;
			}
		}

		_resetFlag = true;

		HashMap<MCSplitPane, Integer> map = new HashMap<>();
		List<MCPanel> list = new ArrayList<>();

		// ExpandSplitを無制限移動にはしない。
		if (ExpandSplit != null) {

			MCRootPanel rp = getExpandSplitPane().getBaseRootPanel();

			// MCRootPanel側で divider調整不要
			rp.setNeedResetDividerLocation(false); // 7.0.1

			if (_initResizeMinimum2 == false || needsUpdate == true) {
				_initResizeMinimum2 = true;
				resizeMinimum(getExpandSplitPane(), true, false);
			}

			// 上部パネルの最大高さを算出する。
			Component c1 = getExpandSplitPane().getTopComponent();
			int maxTop = ((MCPanel) c1).getMaxHeightForSplitPane(true);

			// SplitPaneが多数存在する場合は初期サイズを均等サイズにする。
			boolean hasSplitPane = hasSplitPane();
			if (hasSplitPane) {
				int maxTop1 = (int) getExpandSplitPane().getTopComponent().getPreferredSize().getHeight();
				if (maxTop > maxTop1) {
					maxTop = maxTop1;
				}
			}

			int maxTop2 = maxTop;

			// 初期値が下部のパネルの最小サイズ以下にならないようにする。
			int minBottom = _minHeight; // 下部最小サイズ
			int h = getExpandSplitPane().getHeight() - dividerSize; // SplitPaneの高さ

			if (h < maxTop + minBottom) { // 下部パネルのmin分は確保する。
				maxTop = h - minBottom; // 高さが足りず入りきらない場合は上部パネルを削る。
			}

			// 検索枠が拡大されると下部のSplitPaneが隠れてしまうため再計算する。
			// 複数のSplitPaneが存在する場合は均等配分にする。
			if (hasSplitPane) {
				MCSplitPane splitPanes[] = MCBeansUtil.getAllComponents(MCSplitPane.class,
						getExpandSplitPane().getRootPane());

				List<MCSplitPane> splitPaneList = new ArrayList<>();
				for (MCSplitPane sp : splitPanes) {
					if (sp.getOrientation() == JSplitPane.VERTICAL_SPLIT) {
						splitPaneList.add(sp);
					}
				}

				if (splitPaneList.size() == 0) {
					return;
				}

				// 7012-1828 (【画面レイアウト】レイアウトに関する不具合まとめタスク)
				// 7012-0934 (【ＷＧ間依頼調整】画面を開いたときに回答枠が横に広がり在庫推移枠が見えなくなってしまっている)
				_dividerPanelMap1 = new HashMap<>();
				_dividerPanelMap2 = new HashMap<>();

				int h2 = 0;
				for (MCSplitPane sp : splitPaneList) {
					Component ct = sp.getTopComponent();
					if (ct instanceof MCPanel) {
						MCPanel p1 = (MCPanel) ct;
						MCPanel p2 = (MCPanel) p1.getComponents()[0];
						if (p2.layoutDepth == 1) {
							list.add(p2);
							h2 += p1.getPreferredSize().getHeight();
							_dividerPanelMap1.put(sp, p2);
						}
					}
					Component cb = sp.getBottomComponent();
					if (cb instanceof MCPanel) {
						MCPanel p1 = (MCPanel) cb;
						MCPanel p2 = (MCPanel) p1.getComponents()[0];
						if (p2.layoutDepth == 1) {
							list.add(p2);
							h2 += p1.getPreferredSize().getHeight();
							_dividerPanelMap2.put(sp, p2);
						}
					}
				}

				for (MCSplitPane sp1 : splitPaneList) {
					if(_dividerPanelMap1.containsKey(sp1) == false) {
						if (_hasSubSplitPane(sp1) == false) {
							Component ct = sp1.getTopComponent();
							if (ct instanceof MCPanel) {
								MCPanel p1 = (MCPanel) ct;
								MCPanel p2 = (MCPanel) p1.getComponents()[0];
								list.add(p2);
								h2 += p1.getPreferredSize().getHeight();
							}
						}
					}
					if(_dividerPanelMap2.containsKey(sp1) == false) {
						if (_hasSubSplitPane(sp1) == false) {
							Component cb = sp1.getBottomComponent();
							if (cb instanceof MCPanel) {
								MCPanel p1 = (MCPanel) cb;
								MCPanel p2 = (MCPanel) p1.getComponents()[0];
								list.add(p2);
								h2 += p1.getPreferredSize().getHeight();
							}
						}
					}
				}
				// 7012-0934 ここまで
				// 7012-1828 ここまで

				// SplitPaneの数が多く画面に入りきれない場合は最小高さを0にする。
				for (MCPanel p1 : list) {
					MCSplitPane sp = getSplitPane(p1);
					if (sp != null) {
						MCPanel p = (MCPanel) sp.getBottomComponent();
						p.setMinimumSize(new Dimension((int) p.getMinimumSize().getWidth(), 0));
						sp.resetSaveHeight(); // 内部パネルの高さを再計算
					}
				}

				if (h2 > h || isIgnoreScreen(rp)) {
					int h1 = (maxTop + minBottom) / list.size();
					// SplitPaneのdivider位置を調整。
					for (MCPanel p1 : list) {
						MCSplitPane sp = getSplitPane(p1);
						if (sp != null) {
							int n = sp.getSaveHeight2();
							if (n >= h1) {
								map.put(sp, h1);
								if (sp == getExpandSplitPane()) {
									maxTop = h1;
								}
							} else {
								map.put(sp, h1);
								if (sp == getExpandSplitPane()) {
									maxTop = h1;
								}
							}
						}
					}
				}
			}

			// SplitPaneの移動範囲の制限をなくす。
			resetMaxSaveHeight(getExpandSplitPane());

			// 高さがあふれる場合はdividier位置を再設定する。
			setDividerLocation(getExpandSplitPane(), map, list, maxTop, maxTop2);
		}
	}

	// 互換性を維持するため暫定コードを入れる。
	// あとで消してもよい？
	// 強制3段にする。
	protected boolean isIgnoreScreen(MCRootPanel p) {

		String m = p.getModuleID();
		String s = p.getScreenID();

//		if(p.getFontRatio() == 100) {
//			if(m.equals("MS") && s.equals("MSBEP2620")) {
//				return true;
//			}
//		}
		return false;
	}

	// 7012-1828 (【画面レイアウト】レイアウトに関する不具合まとめタスク)
	// 7012-0934 (【ＷＧ間依頼調整】画面を開いたときに回答枠が横に広がり在庫推移枠が見えなくなってしまっている)
	protected boolean _hasSubSplitPane(MCSplitPane sp1) {

		MCSplitPane spList[] = MCBeansUtil.getAllComponents(MCSplitPane.class, sp1);
		for(MCSplitPane sp : spList) {
			if(sp.getOrientation() == MCSplitPane.VERTICAL_SPLIT) {
				return true;
			}
		}
		return false;
	}
	// 7012-0934 ここまで
	// 7012-1828 ここまで

	@Override
	public void setDividerLocation(MCSplitPane splitPane, HashMap<MCSplitPane,Integer> map, List<MCPanel>list
			, int maxTop, int maxTop2) {
		// 高さがあふれる場合はdividier位置を再設定する。
		if (map.size() > 0) {

			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
			// リソースにかかれてある場合は元に戻す。
			if (getBaseRootPanel().initSplitPane() == false) {
				HashSet<MCSplitPane> set = new HashSet<>();

				set = new HashSet<>();
				for (MCPanel p1 : list) {
					MCSplitPane sp3 = getSplitPane(p1);
					int n3 = map.get(sp3);
					if (sp3 == splitPane) {
						if (sp3.getBothEnd() == null) {
							int pos = splitPane.getDividerLocationFromUser();
							if (pos == -1) {
								pos = _initDividerLocation != -1 ? _initDividerLocation : n3;
							}
							if (pos != Integer.MAX_VALUE) {
								splitPane.setDividerLocationWithoutRatio(pos);
								// フォント比率変更の場合にもとの位置に戻るため２回必要
								splitPane.setDividerLocationWithoutRatio(pos);

								// 前回の位置を記憶
								setDividerLocationMap(splitPane, pos);
							}
						} else if (sp3.getBothEnd() == true) {
							int pos = splitPane.getMaximumDividerLocation();
							splitPane.setDividerLocationWithoutRatio(pos);
						} else if (sp3.getBothEnd() == false) {
							int pos = splitPane.getMinimumDividerLocation();
							splitPane.setDividerLocationWithoutRatio(pos);
						}
					} else if (sp3 != null && set.contains(sp3) == false) {
						set.add(sp3);
						sp3.setDividerLocationWithoutRatio(n3);
						// フォント比率変更の場合にもとの位置に戻るため２回必要
						sp3.setDividerLocationWithoutRatio(n3);

						// 前回の位置を記憶
						setDividerLocationMap(splitPane, n3);

						sp3.validate();
					}
				}
			}
		} else {
			int pos = splitPane.getDividerLocationFromUser();
			if (pos == -1) {
				pos = _initDividerLocation != -1 ? _initDividerLocation : maxTop;
			}
			if (pos != Integer.MAX_VALUE) {
				// 7013-2275(SP3高解像度対応不具合まとめ)
				// MSBCP1150でホイールを回すとdivider検索パネルが全開になってしまう。
				boolean changePos = true;
				// フォント比率が設定値をdivider位置にも反映する。 6.4.0
				if (getExpandSplitPane().getBothEnd() == null) {
//					MCRootPanel rp = getExpandSplitPane().getRootPanel();
//					if (rp.isGeneralTable()) {
//						// 汎用テーブル画面の場合は特殊扱い
//						// 初期のdividerの全開が必要なためchangePosをfalseにしない。
//					} else {
//						if (pos == -1) {
//							changePos = false;
//						}
//					}
				} else if (getExpandSplitPane().getBothEnd() == true) {
					pos = splitPane.getMaximumDividerLocation();
				} else if (getExpandSplitPane().getBothEnd() == false) {
					pos = splitPane.getMinimumDividerLocation();
				}

				// リソースにかかれてある場合は元に戻す。
				if (changePos == true) {
					if (getBaseRootPanel().initSplitPane() == false) {
						splitPane.setDividerLocationWithoutRatio(pos);
						// フォント比率変更の場合にもとの位置に戻るため２回必要
						splitPane.setDividerLocationWithoutRatio(pos);
					}
				}

				// 前回の位置を記憶
				setDividerLocationMap(splitPane, pos);
			}
		}
	}

	// 前回の位置を記憶
	// 7.0.1.3で廃止
	@Deprecated
	private void setDividerLocationMap(MCSplitPane splitPane, int pos) {
		MCRootPanel rp = splitPane.getRootPanel();
		String moduleID = rp.getModuleID();
		String screenID = rp.getScreenID();
		String key = moduleID + "." + screenID + "." + splitPane.getName();
		MCSplitPane.setDividerLocationMap(splitPane, key, pos);
	}


	/**
	 * 伸縮用のSplitPaneの初期のディバイダ位置を設定します。
	 *
	 * @param location 伸縮用のSplitPaneの初期のディバイダ位置
	 */
	public void setInitDividerLocation(int location) {
		_initDividerLocation = location;
	}

	// 複数のSplitPaneが存在する場合は最大サイズを無制限にする。
	@Override
	protected void resetMaxSaveHeight(MCSplitPane splitPane) {
		if (splitPane != null) {
			MCPanel panels[] = MCBeansUtil.getAllComponents(MCPanel.class, splitPane.getRootPane());
			List<MCPanel> list = new ArrayList<>();
			for (MCPanel p1 : panels) {
				String layoutPosition = p1.getLayoutPosition();
				if (layoutPosition != null && layoutPosition.contains("CT")) {
					list.add(p1);
				} else if (layoutPosition != null && layoutPosition.contains("CB")) {
					list.add(p1);
				}
			}

			for (MCPanel p1 : list) {
				MCSplitPane sp = getSplitPane(p1);
				if (sp != null) {
					if (splitPane != sp) { // 検索パネルのみ上限を用意する。
						MCPanel p = (MCPanel) sp.getBottomComponent();
						if (splitPane.getTopComponent() != p) {
							sp.setMaxSaveHeight();
						}
					} else {
						sp.setMaxSaveHeight2();
					}
				}
			}
		}
	}

	// 複数のSPlitPaneが存在するかどうか
	protected boolean hasSplitPane() {
		MCRootPanel p = getExpandSplitPane().getBaseRootPanel();

		if(isIgnoreScreen(p)) {
			return true;
		}

		MCSplitPane cont[] = MCBeansUtil.getAllComponents(MCSplitPane.class, p);
		if (cont.length == 0) {
			return false;
		}

		int h = 0;
		int size = 0;
		MCPanel panels[] = MCBeansUtil.getAllComponents(MCPanel.class, p);

		// 多重加算を防止
		boolean ct = false;
		boolean cb = false;

		for (MCPanel p1 : panels) {
			if (p1.layoutDepth == 1) {
				String layoutPosition = p1.getLayoutPosition();
				if (ct == false && layoutPosition != null && layoutPosition.contains("CT")) {
					h += p1.panelHeightForSplitPane;
					size++;
//					ct = true;
					continue;
				}
				if (cb == false && layoutPosition != null && layoutPosition.contains("CB")) {
					h += p1.panelHeightForSplitPane;
					size++;
//					cb = true;
					continue;
				}
				if (layoutPosition != null && layoutPosition.contains("X")) {
					continue;
				}
				h += p1.panelHeightForSplitPane;
			}
		}

		// ２つ以上のSplitPaneが存在し画面からはみ出す場合はtrue。
		if (size > 2) {
			if (getExpandSplitPane().getRootPanel().getHeight() < h) {
				return true;
			}
//			if (getExpandSplitPane().getBaseRootPanel().getDefaultBounds().height < h) {
//				return true;
//			}
		}
		return false;
	}


	// 複数のSplitPaneが存在する場合の高さ
	protected int getSplitPaneHeight() {
		MCRootPanel p = getExpandSplitPane().getBaseRootPanel();

		MCSplitPane cont[] = MCBeansUtil.getAllComponents(MCSplitPane.class, p);
		if (cont.length == 0) {
			return 0;
		}

		int h = 0;
		// int size = 0;
		MCPanel panels[] = MCBeansUtil.getAllComponents(MCPanel.class, p);

		for (MCPanel p1 : panels) {
			if (p1.layoutDepth == 1) {
				String layoutPosition = p1.getLayoutPosition();
				if (layoutPosition != null && layoutPosition.contains("CT")) {
					h += p1.panelHeightForSplitPane;
					// size++;
					continue;
				}
				if (layoutPosition != null && layoutPosition.contains("CB")) {
					h += p1.panelHeightForSplitPane;
					// size++;
					continue;
				}
				if (layoutPosition != null && layoutPosition.contains("X")) {
					continue;
				}
				h += p1.panelHeightForSplitPane;
			}
		}

		return h;
	}

	/**
	 * Panel[Ope]のボタン[open]の押下時の処理
	 */
	@Override
	public void doOpe_open(MCEventInfo info) {
		// 7013-1574 開閉とも制御する
		expandImpl(true, false);
	}
	/**
	 * Panel[Ope]のボタン[close]の押下時の処理
	 */
	@Override
	public void doOpe_close(MCEventInfo info) {
		// 7013-1574 API変更
		expandImpl(false, false);
	}
	/**
	 * Panel[Ope]のボタン[srch]の押下時の処理
	 */
	@Override
	public void doOpe_srch(MCEventInfo info) {
	}

//	/**
//	 * 開閉用タイマークラス
//	 *
//	 */
//	class ExpandTimer extends Timer {
//		/**
//		 * 操作対象のSplitPane
//		 */
//		private MCSplitPane sp = null;
//		/**
//		 * 動作モード trueの場合開く
//		 */
//		private boolean open = true;
//		/**
//		 * 変動ピクセル数
//		 */
//		private int speed = 0;
//		/**
//		 * 完了位置
//		 */
//		private int last = 0;
//		/**
//		 * 現在位置
//		 */
//		private int current = 0;
//
//		/**
//		 * コンストラクタです。
//		 *
//		 * @param delay
//		 *            動作間隔
//		 * @param speed
//		 *            開閉速度（動作ピクセル数）
//		 */
//		ExpandTimer(int delay, int speed, MCSplitPane sp) {
//			super(delay, null);
//			this.speed = speed;
//			this.sp = sp;
//			if (this.sp == null) {
//				return;
//			}
//
//			addActionListener(new ActionListener() {
//				@Override
//				public void actionPerformed(ActionEvent e) {
//					if (open) {
//						// 開く
//						current += ExpandTimer.this.speed;
//						if (last <= current) {
//							current = last;
//							getExpandSplitPane().setBothEnd(true);
//							ExpandTimer.this.stop();
//						}
//					} else {
//						// 閉じる
//						current -= ExpandTimer.this.speed;
//						if (last >= current) {
//							current = last;
//							getExpandSplitPane().setBothEnd(false);
//							ExpandTimer.this.stop();
//						}
//					}
//					int max = sp.getMaximumDividerLocation();
//					if (max < current) {
//						current = max;
//					}
//					ExpandTimer.this.sp.setDividerLocation(current);
//					// ExpandTimer.this.sp.setResizeWeight(current/max);
//				}
//			});
//		}
//
//		/**
//		 * 動作モードを設定します。
//		 *
//		 * @param open
//		 *            開く場合 true、閉じる場合 false
//		 */
//		void setMode(boolean open) {
//			this.open = open;
//		}
//
//		/**
//		 * 開閉速度を設定します。
//		 *
//		 * @param speed
//		 *            開閉速度（動作ピクセル数）
//		 */
//		void setSpeed(int speed) {
//			this.speed = speed;
//		}
//
//		@Override
//		public void start() {
//			current = sp.getDividerLocation();
//			last = (getExpandSplitPane().getBothEnd() == null) ? current
//					: (getExpandSplitPane().getBothEnd().booleanValue()) ? sp.getMaximumDividerLocation()
//							: sp.getMinimumDividerLocation();
//			super.start();
//		}
//	}

	protected class MCExpandBorderLayout extends BorderLayout {
		private int hgap = 0;
		private int vgap = 0;

		public MCExpandBorderLayout() {
			super();
		}

		public MCExpandBorderLayout(int h, int v) {
			super(h, v);
			hgap = h;
			vgap = v;
		}

		public void layoutContainer(Container target) {

			synchronized (target.getTreeLock()) {
				Insets insets = target.getInsets();
				int top = insets.top;
				int bottom = target.getHeight() - insets.bottom;
				int left = insets.left;
				int right = target.getWidth() - insets.right;

				boolean ltr = target.getComponentOrientation().isLeftToRight();
				Component c = null;

				double ratio = getBaseRootPanel().getLayoutRatio() / 100.0;

				if ((c = getChild(NORTH, ltr)) != null) {
					c.setSize(right - left, c.getHeight());
					Dimension d = c.getPreferredSize();
					c.setBounds(left, top, right - left, d.height);
					top += d.height + vgap * ratio;
				}
				if ((c = getChild(SOUTH, ltr)) != null) {
					c.setSize(right - left, c.getHeight());
					Dimension d = c.getPreferredSize();
					c.setBounds(left, bottom - d.height, right - left, d.height);
					bottom -= d.height + vgap * ratio;
				}
				if ((c = getChild(EAST, ltr)) != null) {
					c.setSize(c.getWidth(), bottom - top);
					Dimension d = c.getPreferredSize();
					c.setBounds(right - d.width, top, d.width, bottom - top);
					right -= d.width + hgap * ratio;
				}
				if ((c = getChild(WEST, ltr)) != null) {
					c.setSize(c.getWidth(), bottom - top);
					Dimension d = c.getPreferredSize();
					c.setBounds(left, top, d.width, bottom - top);
					left += d.width + hgap * ratio;
				}
				if ((c = getChild(CENTER, ltr)) != null) {
					c.setBounds((int) (left + hgap * ratio), (int) (top + vgap * ratio), right - left, bottom - top);
				}
			}
		}

		private Component getChild(String key, boolean ltr) {
			Component result = getLayoutComponent(key);
			return result;
		}
	}

}