package mcframe.clientFXBA.FXBAP0130;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FXBAP_ExpandUnit"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FXBAP_ExpandUnit_FW_A extends mcframe.clientFXUB.FXUBP0010.FXUBP_HPartsBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FX";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FXBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FXBAP0130";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Ctrl]ブロック関連のField定義
	public MCPanel CtrlPanel = null;
	// [Ctrl]ブロックの項目のField定義
	// [Ope]ブロック関連のField定義
	public MCPanel OpePanel = null;
	// [Ope]ブロックの項目のField定義
	/**
	 *  開く.<p>
	 *
	 */
	public MCButton Ope_open = null;
	/**
	 *  閉じる.<p>
	 *
	 */
	public MCButton Ope_close = null;
	/**
	 *  検索する.<p>
	 *
	 */
	public MCButton Ope_srch = null;
	// [Info]ブロック関連のField定義
	public MCPanel InfoPanel = null;
	// [Info]ブロックの項目のField定義
	/**
	 *  検索条件.<p>
	 *
	 */
	public MCLabel Info_conds = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";
	/** [INVISIBLE]モードを表す定数 */
	public static final String INVISIBLE = "INVISIBLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, DISABLE, INVISIBLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CtrlPanel);
		ret.add(OpePanel);
		ret.add(InfoPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_ExpandUnit_FW_A() {

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FXBAP_ExpandUnit_FW.jbCreateCtrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbCreateOpe((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbCreateInfo((FXBAP_ExpandUnit)this);
	}

	/**
	 * [Ctrl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCtrl(FXBAP_ExpandUnit p) {
	}

	/**
	 * [Ope]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateOpe(FXBAP_ExpandUnit p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FXBAP_ExpandUnit p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FXBAP_ExpandUnit create(){
		FXBAP_ExpandUnit p = new FXBAP_ExpandUnit();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FXBAP_ExpandUnit_FW.jbfInitCtrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbfInitOpe((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbfInitInfo((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbInitCtrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbInitOpe((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.jbInitInfo((FXBAP_ExpandUnit)this);
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCtrl(FXBAP_ExpandUnit p) {
		// ブロック関連の初期化
		p.CtrlPanel = p.beansFactory.createPanel("Ctrl");
		// ブロックの項目の初期化
	}

	/**
	 * [Ope]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitOpe(FXBAP_ExpandUnit p) {
		// ブロック関連の初期化
		p.OpePanel = p.beansFactory.createPanel("Ope");
		// ブロックの項目の初期化
		p.Ope_open = p.beansFactory.createButton("Ope.open", "no_border");
		p.Ope_close = p.beansFactory.createButton("Ope.close", "no_border");
		p.Ope_srch = p.beansFactory.createButton("Ope.srch", "srch");
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FXBAP_ExpandUnit p) {
		// ブロック関連の初期化
		p.InfoPanel = p.beansFactory.createPanel("Info");
		// ブロックの項目の初期化
		p.Info_conds = p.beansFactory.createLabel("Info.conds");
	}

	/**
	 * [Ctrl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCtrl(FXBAP_ExpandUnit p) {
		// ブロック関連の初期化
		p.add(p.CtrlPanel);
		p.setLastBeans(p.CtrlPanel);
		p.CtrlPanel.setValueCheck(false);
		p.CtrlPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.CtrlPanel.add(p.OpePanel, null);
		p.CtrlPanel.setLastBeans(p.OpePanel);
		p.OpePanel.setNextBeans(p.InfoPanel);
		p.CtrlPanel.add(p.InfoPanel, null);
	}

	/**
	 * [Ope]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitOpe(FXBAP_ExpandUnit p) {
		// ブロック関連の初期化
		p.OpePanel.setValueCheck(false);
		p.OpePanel.setLayoutPosition("E");
		// ブロックの項目の初期化
		p.Ope_open.setIcon("DIV_DOWN");
		p.OpePanel.add(p.Ope_open);
		p.OpePanel.setLastBeans(p.Ope_open);
		p.Ope_open.setNextBeans(p.Ope_close);
		p.Ope_close.setIcon("DIV_UP");
		p.OpePanel.add(p.Ope_close);
		p.Ope_close.setNextBeans(p.Ope_srch);
		p.Ope_srch.setIcon("SEARCH");
		p.Ope_srch.setFunctionKey(MCFunctionKey.F1);
		p.OpePanel.add(p.Ope_srch);
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FXBAP_ExpandUnit p) {
		// ブロック関連の初期化
		p.InfoPanel.setValueCheck(false);
		p.InfoPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.InfoPanel.add(p.Info_conds);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FXBAP_ExpandUnit_FW.mcInitCtrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.mcInitOpe((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.mcInitInfo((FXBAP_ExpandUnit)this);

		// [ENABLE]ステータスのモードの設定
		FXBAP_ExpandUnit_FW.statusInitENABLE_Ctrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.statusInitENABLE_Ope((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.statusInitENABLE_Info((FXBAP_ExpandUnit)this);

		// [DISABLE]ステータスのモードの設定
		FXBAP_ExpandUnit_FW.statusInitDISABLE_Ctrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.statusInitDISABLE_Ope((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.statusInitDISABLE_Info((FXBAP_ExpandUnit)this);

		// [INVISIBLE]ステータスのモードの設定
		FXBAP_ExpandUnit_FW.statusInitINVISIBLE_Ctrl((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.statusInitINVISIBLE_Ope((FXBAP_ExpandUnit)this);
		FXBAP_ExpandUnit_FW.statusInitINVISIBLE_Info((FXBAP_ExpandUnit)this);

	}

	/**
	 *  [Ctrl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCtrl(FXBAP_ExpandUnit p) {
	}

	/**
	 *  [Ope]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitOpe(FXBAP_ExpandUnit p) {
		p.Ope_open.addAllListener(p);
		p.Ope_open.setAPMethodName("doOpe_open");
		p.Ope_close.addAllListener(p);
		p.Ope_close.setAPMethodName("doOpe_close");
		p.Ope_srch.addAllListener(p);
		p.Ope_srch.setAPMethodName("doOpe_srch");
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FXBAP_ExpandUnit p) {
	}

	/**
	 * [ENABLE]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Ctrl(FXBAP_ExpandUnit p){

	}

	/**
	 * [ENABLE]ステータスの[Ope]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Ope(FXBAP_ExpandUnit p){
		p.Ope_open.putMode(p, ENABLE, MCMode.ENABLE);
		p.Ope_close.putMode(p, ENABLE, MCMode.ENABLE);
		p.Ope_srch.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [ENABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Info(FXBAP_ExpandUnit p){

	}

	/**
	 * [DISABLE]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Ctrl(FXBAP_ExpandUnit p){

	}

	/**
	 * [DISABLE]ステータスの[Ope]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Ope(FXBAP_ExpandUnit p){
		p.Ope_open.putMode(p, DISABLE, MCMode.DISABLE);
		p.Ope_close.putMode(p, DISABLE, MCMode.DISABLE);
		p.Ope_srch.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * [DISABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Info(FXBAP_ExpandUnit p){

	}

	/**
	 * [INVISIBLE]ステータスの[Ctrl]ブロックのモードの設定
	 */
	protected static void statusInitINVISIBLE_Ctrl(FXBAP_ExpandUnit p){

	}

	/**
	 * [INVISIBLE]ステータスの[Ope]ブロックのモードの設定
	 */
	protected static void statusInitINVISIBLE_Ope(FXBAP_ExpandUnit p){
		p.Ope_open.putMode(p, INVISIBLE, MCMode.INVISIBLE);
		p.Ope_close.putMode(p, INVISIBLE, MCMode.INVISIBLE);
		p.Ope_srch.putMode(p, INVISIBLE, MCMode.INVISIBLE);

	}

	/**
	 * [INVISIBLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINVISIBLE_Info(FXBAP_ExpandUnit p){

	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[INVISIBLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINVISIBLEStatus() {
		status = INVISIBLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
		else if (INVISIBLE.equals(status)) {
			setINVISIBLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Ope_open) doOpe_open(info);
		else if (ap == Ope_close) doOpe_close(info);
		else if (ap == Ope_srch) doOpe_srch(info);
	}

	/**
	 * [Ope]パネルの[open]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doOpe_open(MCEventInfo info);

	/**
	 * [Ope]パネルの[close]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doOpe_close(MCEventInfo info);

	/**
	 * [Ope]パネルの[srch]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doOpe_srch(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}