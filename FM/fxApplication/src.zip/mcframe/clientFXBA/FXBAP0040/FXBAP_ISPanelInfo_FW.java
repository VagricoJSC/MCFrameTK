package mcframe.clientFXBA.FXBAP0040;

import mcframe.clientCore.beans.list.MCListPutter;

public abstract class FXBAP_ISPanelInfo_FW {
	
	protected MCListPutter _putter;
	
	protected int _putIndex;
	
	public FXBAP_ISPanelInfo_FW() {
		
	}
	
	public void setListPutter(MCListPutter putter) {
		_putter = putter;
	}
	
	public MCListPutter getListPutter() {
		return _putter;
	}
	
	public void setPutIndex(int putIndex) {
		_putIndex = putIndex;
	}
	
	public int getPutIndex() {
		return _putIndex;
	}
	
}
