package mcframe.clientFXBA.FXBAP0040;

import mcframe.commonCore.annotation.EI;

@EI
public class FXBAP_ISPanelInfo extends FXBAP_ISPanelInfo_FW {
	
	public FXBAP_ISPanelInfo() {
		
	}
	
}
