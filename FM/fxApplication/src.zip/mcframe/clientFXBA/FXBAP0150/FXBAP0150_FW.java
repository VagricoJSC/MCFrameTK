package mcframe.clientFXBA.FXBAP0150;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.dashboard.MCValueSupply;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP0150"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP0150_FW extends FXBAP0150_FW_A implements ConditionEditor {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * コンポーネント配置間隔
	 */
	public static final int LAYOUT_MARGIN = 5;

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP0150_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void setEDITABLEStatus() {
		super.setEDITABLEStatus();
		setRequiredMode();
	}

	@Override
	public void setREAD_ONLYStatus() {
		super.setREAD_ONLYStatus();
		setRequiredMode();
	}

	/**
	 * 必須項目のモードを設定します。
	 *
	 */
	protected void setRequiredMode() {
		MCValueSupply params[] = getParam();
		if (params == null || params.length <= 0) {
			return;
		}
		MCModeBeans[] beans = getModeCtrlBeans();
		if (beans == null || beans.length <= 0) {
			return;
		}
		int len = Math.max(params.length, beans.length);

		for (int i = 0; i < len; i++) {
			MCValueSupply param = params[i];
			MCModeBeans bean = beans[i];
			if (bean != null && param != null && param.required()) {
				bean.setMode(MCMode.REQUIRED);
			}
		}
	}

	/**
	 * 必須項目制御対象の画面部品を返します。
	 *
	 * 配列の並び順はsetParamで受けるParamの並び順と同じにする必要があります。
	 * Paramに対応する画面部品がない場合は null を設定してください。
	 *
	 * @return 画面部品の配列
	 */
	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		return null;
	}

	/**
	 * ガジェットパラメータに応じた画面ステータスを返します。
	 *
	 * @param param ガジェットパラメータ
	 * @return ステータス
	 */
	@Override
	public String getStatusFor(MCValueSupply...param) {
		return (param == null || param.length == 0 || param[0].editable())
				? EDITABLE : READ_ONLY;
	}

	/**
	 * ガジェットパラメータを返します。
	 *
	 * @return ガジェットパラメータ
	 */
	@Override
	public MCValueSupply[] getParam() {
		return null;
	}

	/**
	 * ガジェットパラメータを設定します。
	 *
	 * @param param ガジェットパラメータ
	 * @param listL コンボリスト。使用しない場合はnull
	 */
	@Override
	public void setParam(MCValueSupply...param) {
	}

	/**
	 * 編集した値をガジェットパラメータに反映します。
	 *
	 */
	@Override
	public void updateParam() {
	}

	/**
	 * 入力チェックを行います。
	 *
	 * @return 未入力必須項目の画面部品。未入力必須項目がない場合 null
	 */
	@Override
	public MCRowBeans checkRequiredValue() {
		return null;
	}

	@Override
	public String getAutoLayoutType() {
		return getLayoutKey();
	}

	// 7013-1838(FXBAP0140の画面：フォント比率変更後にフレームサイズを変更すると崩れる)
	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	public Dimension getMaximumSize() {
		// 幅は左詰めにするため最大値にする。
		return new Dimension(Short.MAX_VALUE,(int)getSize().getHeight());
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// 初期化時にフォント比率100固定で計算必須
	// 共通のデフォルト値があるとその分掛け合わされてしまうため。
	@Override
	public boolean useDefaultFontRatio() {
		return false;
	}


	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	//汎用テーブルの部品かどうか
	@Override
	public boolean isConditionEditor() {
		// レイアウトで汎用テーブルの部品であることを表す
		return true;
	}
}