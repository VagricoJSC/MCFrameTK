package mcframe.clientFXBA.FXBAP0150;

import java.awt.Dimension;

import mcframe.clientCore.beans.MCModeBeans;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.MCRowBeans;
import mcframe.clientCore.beans.MCTabOrderBeans;
import mcframe.clientCore.dashboard.ListR;
import mcframe.clientCore.dashboard.MCValueSupply;
import mcframe.commonCore.container.MCList;


/**
 * 動的検索条件編集用の部品です。
 * 
 */
public interface ConditionEditor extends MCTabOrderBeans {

	/**
	 * エディタを初期化します。
	 *
	 * @param baseINITStatus 基盤の画面の初期ステータス
	 * @param param ガジェットパラメータ
	 */
	public default void initEditor(String baseINITStatus, MCValueSupply...param) {
		MCRootPanel root = (MCRootPanel) this;

		// 初期ステータス登録
		root.putStatus(baseINITStatus, getStatusFor(param));

		// エディタ初期化
		layoutInit();

		// サイズ調整
		Dimension max = getMaximumSize();
		max.height = getSize().height;
		setMaximumSize(max);

		// 初期化完了処理
		root.initialized();

		// パラメータ設定
		setParam(param);
	}

	/**
	 * ガジェットパラメータに応じた画面ステータスを返します。
	 *
	 * @param param ガジェットパラメータ
	 * @return ステータス
	 */
	public String getStatusFor(MCValueSupply...param) ;

	/**
	 * ガジェットパラメータを設定します。
	 *
	 * @param param ガジェットパラメータ
	 */
	public void setParam(MCValueSupply...param);
	/**
	 * ガジェットパラメータを返します。
	 *
	 * @return ガジェットパラメータ
	 */
	public MCValueSupply[] getParam();

	/**
	 * コンボリストを設定します。
	 *
	 * @param listL コンボリストデータ
	 */
	public default void setValueList(MCList<ListR> listL) {};


	/**
	 * 編集した値をガジェットパラメータに反映します。
	 *
	 */
	public void updateParam();

	/**
	 * 必須項目制御対象の画面部品を返します。
	 *
	 * @return 画面部品の配列
	 */
	public MCModeBeans[] getModeCtrlBeans();

	/**
	 * 必須項目の入力チェックを行います。
	 *
	 * <p>
	 * 最初に見つかった未入力必須項目の画面部品を返します。
	 * 未入力の必須項目がない場合は null を返します。
	 * <p>
	 * 必須項目以外はチェックの対象外です。
	 * したがって、必須項目を持たない場合、常に null を返します。
	 *
	 * @return 未入力必須項目の画面部品。未入力必須項目がない場合 null
	 */
	public MCRowBeans checkRequiredValue() ;


	// レイアウト
	/**
	 * MCRootPanelのメソッドと同じです。
	 *
	 */
	public void layoutInit() ;
	/**
	 * MCRootPanelのメソッドと同じです。
	 *
	 */
	public Dimension getSize() ;
	/**
	 * MCRootPanelのメソッドと同じです。
	 *
	 */
	public Dimension getMaximumSize() ;
	/**
	 * MCRootPanelのメソッドと同じです。
	 *
	 */
	public void setMaximumSize(Dimension max);

}
