package mcframe.clientFXBA.FXBAP0030;

import javax.swing.JComponent;

import mcframe.clientFXBA.FXBAP0010.*;
import mcframe.clientFXUC.FXUCP0110.FXUCP_Paging;
import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.clientCore.beans.MCPagingAgent;
import mcframe.commonCore.container.*;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCException;
import mcframe.commonCore.notice.MCMessageList;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * @param
 * <P>
 * @param <O>
 */
public class FXBAP_ISSearcher_FW<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge>
		extends FXBAP_Searcher<P, O> {
	protected IfISPanelWithPaging _implISPanelWithPaging;

	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面 {@link IfISPanelWithPaging}を実装していること
	 * @param operation オペレーション
	 */
	public FXBAP_ISSearcher_FW(P panel, O operation) {
		super(panel, operation);
		if (panel instanceof IfISPanelWithPaging) {
			_implISPanelWithPaging = (IfISPanelWithPaging) panel;
		}
		else {
			throw new MCAppException(FXBAP0068);
		}
	}

	@Override
	protected void call() {
		if (_isSilentMode) {
			super.call();
			if (checkCap()) {
				callDLConfirmAction();
			}
		}
		else {
			MCPagingAgent p = _implISPanelWithPaging.getPagingAgent();
			p.setCaller(this);
			p.callPaging(param(),
					_implISPanelWithPaging.getPagingSize(),
					_implISPanelWithPaging.pagingSortItems());
		}
	}

	@Override
	protected void afterCall() {
		MCContainer cont = param().getContainerParam().down().get(0);
		if (cont instanceof MCList) {
			_implISPanelWithPaging.afterCall((MCList) cont);
		}
		else {
			throw new MCAppException(FXBAP0069);
		}
	}

	/**
	 * デフォルト実装：setSort() の呼び出し
	 */
	@Override
	protected void beforeCall() {
		super.beforeCall();
		FXUCP_Paging p = _implISPanelWithPaging.getPagingPanel();
		if (p != null) {
			p.setPagingSize();
		}
	}

	@Override
	protected void checkReq(MCMessageList msgList) {
		super.checkReq(msgList);

		FXUCP_Paging p = _implISPanelWithPaging.getPagingPanel();
		if (p != null) {
			msgList.addAll(p.checkReq(p.getBtnR()));
		}
	}

	@Override
	protected void show() {
		MCContainer cont = param().getContainerParam().down().get(0);
		if (cont instanceof MCList) {
			_implISPanelWithPaging.show((MCList) cont);
		}
		else {
			throw new MCAppException(FXBAP0069);
		}
	}

	@Override
	protected void clear() {
		_implISPanelWithPaging.rsltLClear();
	}

	@Override
	protected void moveFocus() {
		if(panel.isCreated()){
			_implISPanelWithPaging.moveFocus();
		}
	}

	@Override
	protected void resultNoDataFound() {
		_implISPanelWithPaging.moveFocusNoDataFound();
	}

	@Override
	protected void showNoDownDataMsg() {
		mcframe.clientFXUC.FXUCP0110.FXUCP_Paging p = _implISPanelWithPaging.getPagingPanel();
		if (p != null) {
			p.dispUpdate();
		}

		super.showNoDownDataMsg();
	}

	// サイレントモード関連（ここから）
	protected boolean _isSilentMode = false;

	@Override
	protected boolean beforeExecMain() {
		_isSilentMode = _implISPanelWithPaging.isSilentMode();
		setScreenAsync(!_isSilentMode);
		if (_isSilentMode) {
			return true;
		}
		else {
			return super.beforeExecMain();
		}
	}
	
	@Override
	protected void execMain() {
		if (_isSilentMode) {
			try{
				lockScreen();
				setupParam();
				try {
					call();
				}
				catch (MCException e) {
					handleMCEx(e);
				}
				afterCall();
				show();
			}
			finally{
				unlockScreen();
			}
		}
		else {
			super.execMain();
		}
	}

	// サイレントモード関連（ここまで）
}
