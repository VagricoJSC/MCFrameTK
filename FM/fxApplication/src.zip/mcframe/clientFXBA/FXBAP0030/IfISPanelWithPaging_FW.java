package mcframe.clientFXBA.FXBAP0030;

import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientCore.event.MCEventInfo;
import mcframe.clientCore.requester.paging.SortItemR;
import mcframe.clientFXBA.FXBAP0010.FXBAP_ISPanel;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXUC.FXUCP0110.IfPagingAgentHolder;
import mcframe.clientFXUC.FXUCP0110.FXUCP_Paging;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;

public interface IfISPanelWithPaging_FW extends FXBAP_ISPanel, IfPagingAgentHolder {
	/**
	 * getListで起動したとき
	 */
	public static final String GET_LIST = "GET_LIST";

	/**
	 * 画面起動で起動したとき
	 */
	public static final String OPEN = "OPEN";

	/**
	 * 決定ボタン押下時の処理
	 */
	public void doAccept();

	/**
	 * テーブルダブルクリック時の処理。決定ボタン押下時と同じ 動きをする
	 * 
	 * @param info
	 */
	public void doDCAccept(MCEventInfo info);

	public MCList getRsltL();

	public MCRow getCndR();

	public void doCnd_srch(MCEventInfo info);

	/**
	 * 起動引数からデフォルト値をセットする
	 * <p>
	 * 実装例
	 * <p>
	 * 
	 * <pre>
	 * public void setCondition(MCRow row, String mode) {
	 * 	if (GET_LIST == mode) {
	 * 		getCndR().itm_cd_input(row.getStringNE($INPUT_VAL));
	 * 	}
	 * 	else {
	 * 		getCndR().itm_cd(row.getStringNE($INPUT_VAL));
	 * 	}
	 * 	getCndR().dpt_cd(row.getStringNE($dpt_cd));
	 * }
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param row
	 * @param mode 次のいずれか {@link #GET_LIST}{@link #OPEN}
	 */
	public void setCondition(MCRow row, String mode);

	public MCTable<?> getRsltTable();

	/**
	 * ページングする際のソート順を指定します。
	 * <P>
	 * 
	 * <pre>
	 * MCList&lt;SortItemR&gt; list = MCList.create(SortItemR.class);
	 * SortItemR row = SortItemR.create();
	 * row.nm(HogeR.$itm_cd);
	 * row.sort_typ(ASC);
	 * list.add(row);
	 * </pre>
	 * 
	 * </P>
	 * 
	 * @return
	 */
	public MCList<SortItemR> pagingSortItems();

	/**
	 * ページングのサイズ
	 */
	public int getPagingSize();

	/**
	 * 検索処理（含むページングのnext / prev）の後処理を行います。 検索結果 list に対して必要な情報を付加します。<br>
	 * 想定している実装：区分の名称をつける
	 * @param 検索
	 */
	public void afterCall(MCList<? extends MCRow> list);

	/**
	 * 検索結果を画面に表示します
	 * 
	 * @param list
	 */
	@SuppressWarnings("unchecked")
	// getRsltLへのaddAll
	public void show(MCList<? extends MCRow> list);

	/**
	 * 検索結果をクリアします。
	 */
	public void rsltLClear();

	/**
	 * ページングを行うPanelを返す。（ページング機能を使わない場合は、nullが返る）
	 */
	public FXUCP_Paging getPagingPanel();

	/**
	 * サイレントモードかどうか？
	 */
	public boolean isSilentMode();

	/**
	 * 画面のデフォルト値のセットを行う。
	 */
	public void valueInit();
	
	/**
	 * 他画面から呼び出された場合の初期化を実装します。<br>
	 * <P>
	 * <li>起動タイプ：T1 （入力補助画面のデフォルト）<br>
	 * バインド値 ＜必須＞<br>
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>各画面による</td>
	 * <td>各画面による</td>
	 * <td></td>
	 * </tr>
	 * </table><br>
	 * その他の引数０：MCListPutter ＜必須＞<br>
	 * その他の引数１：putterに使うインデックス ＜必須＞<br>
	 * </li>
	 * </P>
	 * 
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @pram args その他の引数
	 */
	public void initByScreenParam(String openTyp, MCRow bind, Object... args);

	/**
	 * 検索結果があった場合のフォーカス移動を行う。
	 */
	public void moveFocus();
	
	/**
	 * 検索結果がなかった場合のフォーカス移動を行う。
	 */
	public void moveFocusNoDataFound();
	/**
	 * 選択チェックボックスのカラムを返します。
	 *
	 * @return　カラム
	 */
	public MCColumnConfig getCheckColumn();
}