package mcframe.clientFXBA.FXBAP0030;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;



//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase.*;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import java.util.stream.Stream;

import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.list.MCListCacher2;
import mcframe.clientCore.beans.list.MCListConfig;
import mcframe.clientCore.beans.list.MCListPutter;
import mcframe.clientCore.listLogic.MCLLCallerSupplier;
import mcframe.clientCore.listLogic.MCListLogicBase2;
import mcframe.clientCore.requester.MCCaller;
import mcframe.clientCore.requester.paging.SortItemR;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher;
import mcframe.clientFXBA.FXBAP0010.IfDPartsForCaller;
import mcframe.clientFXUC.FXUCP0110.FXUCP_Paging;
import mcframe.clientFXBA.FXBAP0040.FXBAP_ISPanelInfo;
import mcframe.commonCore.param.MCParam;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FXBAP_ISPanelBase"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FXBAP_ISPanelBase_FW extends FXBAP_ISPanelBase_FW_A implements IfISPanelWithPaging, MCLLCallerSupplier {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	private MCCacheType _cache;
	
	private boolean _isDCEvent = false;
	
	private MCPagingAgent _pagingAgent;
	
	/**
	 * ページングのサイズです。
	 */
	private Integer _pagingSize = null;

	// ページング関連（ここから）
	private FXUCP_Paging _pagingPanel; // PAgingPanel

	/** 結果を返す先のrowIndex */
	private int _putIndex;

	/** 結果を返す先（putter) */
	private MCListPutter _putter;

	// 手入力用の処理（ここから）
	private boolean _silentMode = false;

	private MCTable<?> _rsltTable;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FXBAP_ISPanelBase_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START
	// IfISPanelUtil対応（ここから）
	/**
	 * 他画面から呼び出された場合の初期化を実装します。<br>
	 * <P>
	 * <li>起動タイプ：T1 （入力補助画面のデフォルト）<br>
	 * バインド値 ＜必須＞<br>
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>各画面による</td>
	 * <td>各画面による</td>
	 * <td></td>
	 * </tr>
	 * </table><br>
	 * その他の引数０：MCListPutter ＜必須＞<br>
	 * その他の引数１：putterに使うインデックス ＜必須＞<br>
	 * </li>
	 * </P>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他の引数
	 */
	@Override
	public void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		reshowInit();
		if (FXBAP_PanelBase.T1 == openTyp) {
			if (args == null || args.length < 2) {
				throw new MCAppException(msgUnknownOpenParam());
			}
			// BIND
			setCondition(bind, OPEN);

			// PUTTER
			_putter = null;
			if (args[0] instanceof MCListPutter) {
				_putter = (MCListPutter) args[0];
			}
			else if (args[0] != null) {
				throw new MCAppException(FXBAP0040);
			}

			// putIndex
			_putIndex = 0;
			if (args[1] instanceof Integer) {
				_putIndex = ((Integer) args[1]).intValue();
			}
			else if (args[1] != null) {
				throw new MCAppException(FXBAP0041);
			}

			//１行のみチェック可能にするためのリスナーを設定
			MCLinkBeans c = _putter.getLinkBeans();
			if (c == null) {
				return;
			}
			MCColumnConfig n = getCheckColumn();
			if (n == null) {
				return;
			}
			MCNCListener[] nls = n.getNCListeners();
			Stream.of(nls).forEach(nl -> {
				if (nl instanceof CheckNCListener) {
					n.removeNCListener(nl);
				}
			});

			if (!isPluralValueField(c)) {
				n.addNCListener(new CheckNCListener());
			}
		}
	}

	private class CheckNCListener implements MCNCListener {
		//前回ONだった行Index
		MCRow _trueIdx = null;

		//このリスナによって実行されたイベントではない場合true
		boolean _rootEvent = true;

		@Override
		public void doNCEvent(MCNCBeans compo, MCEventInfo info) {
			if ((Boolean) info.getNewValue()) {
				MCColumnConfig c = (MCColumnConfig) compo;
				//ひとつ前に選択した行のチェックをOFFにする
				if (_trueIdx != null && _trueIdx.getGUIIndex() > -1) {
					SwingUtilities.invokeLater(() -> {
						//このsetValueイベントによる_trueIdxの更新はしない
						_rootEvent = false;
						//再検索された場合などで_trueIdxが不正の場合があるため、
						//同一行の場合は何もしない
						int rootEIdx = info.getEventIndex();
						if (_trueIdx.getGUIIndex() != rootEIdx) {
							c.setValue(_trueIdx.getGUIIndex(), false);
							_trueIdx = c.getBaseTable().getRow(rootEIdx);
						}
						_rootEvent = true;
					});
				}
				else {
					_trueIdx = c.getBaseTable().getRow(info.getEventIndex());
				}
			}
			else {
				if (_rootEvent) {
					_trueIdx = null;
				}
			}
		}
	}

	@Override
	protected void afterOpenByInitParam(String openTyp, MCRow bind, Object... args) {
		super.afterOpenByInitParam(openTyp, bind, args);

		if (FXBAP_PanelBase.T1 == openTyp) {
			setUserSrchCnd();
		}
	}

	@Override
	public void valueInit() {
		super.valueInit();

		resetPagingAgent();
		FXUCP_Paging p = getPagingPanel();
		if (p != null) {
			p.dispUpdate();
		}
	}

	protected void resetPagingAgent() {
		_pagingAgent = null;
		FXUCP_Paging p = getPagingPanel();
		if (p != null) {
			p.dispUpdate();
		}
	}

	@Override
	public void reshowInit() {
		// メモ：superを呼んではいけない（initByScreenParamで無限ループが起きる）

		if (screenClearConfirm()) {
			screenClearSetMode();
			screenClearBody();
			statusClear();
			// initByScreenParam(); // ここがsuperと違う
			screenClearSetDefault();
			screenClearSetFocus();
		}
	}

	// IfISPanelUtil対応（ここから）
	@Override
	@SuppressWarnings("rawtypes")
	// MCListのジェネリクス
	public abstract MCList getRsltL();

	@Override
	public MCList<SortItemR> pagingSortItems() {
		MCList<SortItemR> ls = MCList.create(SortItemR.class);
		MCSortPolicy policy = getRsltTable().getSortPolicy();
		for (int i = 0; i < policy.size(); i++) {
			SortItemR row = ls.createRow();
			row.nm(policy.name(i));
			row.sort_typ(policy.type(i).name());
			ls.add(row);
		}
		return ls;
	}

	@Override
	public void setOpenFocus() {
		super.setOpenFocus();
		
		focusFirstComponent();
	}
	
	// //////////////////////////////////////////////

	/**
	 * 決定ボタン押下時の処理
	 */
	@Override
	public void doAccept() {
		//戻り値
		MCList down = getAcceptTarget(_isDCEvent);
		if (down == null || down.isEmpty()) {
			if (!_isDCEvent) {
				messageTemp(msgNoSelectedRow());
			}
			return;
		}

		if (_putter != null) {
			JComponent c = getComponent(getRsltL());
			if (c instanceof MCTable) {
				MCListConfig config = _putter.getLinkBeans().getListConfig();
				String ope = config.getOpeType();
				try {
					config.setOpeType(MCListConfig.LIST);

					MCLinkBeans tar = _putter.getLinkBeans();
					Comparable<?> oldValue = getValue(tar, _putIndex);
					MCMessageList ret = null;
					try {
						if (isPluralValueField(tar)) {
							ret = _putter.setValuesByList(_putIndex, down);
						}
						else {
							// 例外処理をしているので setValueEx を使わない
							ret = _putter.setValues(_putIndex, down.get(0));
						}
					}
					catch (MCException ex) {
						if (isSame(FXBAP0059, ex.getID())) {
							if (ret == null) {
								ret = new MCMessageList();
							}
							ret.addAll(ex.getCauseMessageList());
						}
						else {
							throw ex;
						}
					}

					if (ret != null && !ret.isEmpty()) {
						sortMessageList(ret);
						MCMessage msg = new MCMessage(FXBAP0059);
						ret.add(0, msg);

						MCLog.write(ret);

						MCRootPanel p = getParentPanel();
						// メモ：この画面を親画面にして、マルチメッセージダイアログを
						// 起動すると、直後の処理でこの画面を閉じるような実装をしているので、
						// その時に、一緒にマルチメッセージダイアログが消えてしまうので
						// 違うパネルを親パネルとして起動する
						if (p != null && p instanceof FXBAP_PanelBase) {
							FXBAP_PanelBase app = (FXBAP_PanelBase) p;
							app.messageNoSort(ret);
						}
						else {
							MCMessageBox.message(null, ret);
						}
						// 元に入っていた値なので基本的に例外は発生しないハズ
						setValue(tar, _putIndex, oldValue);
					}
				}
				finally {
					config.setOpeType(ope);
				}
			}
		}
		requestCloseWindow();

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (_putter == null) {
					return;
				}
				MCLinkBeans c = _putter.getLinkBeans();
				if (c == null) {
					return;
				}
				MCRootPanel p = c.getBaseRootPanel();
				if (p == null) {
					return;
				}
				MCFrame f = p.getFrame();
				if (f != null) {
					return;
				}
				Component o = p.getFocusOwner();
				if (c instanceof MCColumnConfig) {
					MCTable<?> t = ((MCColumnConfig) c).getBaseTable();
					if (t != null && t.equalsIgnoreCase(o)) {
						o.requestFocus();
					}
				}
				else if (c == o) {
					o.requestFocus();
				}
			}
		});
	}

	/**
	 * 決定行を返す。
	 *
	 * @param isDCEvent ダブルクリックかどうか
	 * @return 決定行
	 */
	private MCList<?> getAcceptTarget(boolean isDCEvent) {
		return getAcceptList(_putter.getLinkBeans(), isDCEvent);
	}

	protected Comparable<?> getValue(MCLinkBeans beans, int idx) {
		if (beans instanceof MCColumnConfig) {
			MCColumnConfig conf = (MCColumnConfig) beans;
			return conf.getTable().getRow(idx).getValue(conf.getRowColumnName());
		}
		else if (beans instanceof MCRowBeans) {
			return ((MCRowBeans) beans).getRowValue();
		}
		return null;
	}

	/**
	 * 値がセットできなかった場合はインフラの例外をthrowする
	 * @param beans
	 * @param idx
	 * @param val
	 */
	protected void setValue(MCLinkBeans beans, int idx, Comparable<?> val) {
		// 例外をthrowする仕様なのでsetValueExを使わない
		if (beans instanceof MCColumnConfig) {
			((MCColumnConfig) beans).setValue(idx, val);
		}
		else if (beans instanceof MCTextField) {
			((MCTextField) beans).setValue((String) val);
		}
		else if (beans instanceof AbsMCComboBox) {
			((AbsMCComboBox) beans).setValue(val);
		}
		else if (beans instanceof MCPasswordField) {
			((MCPasswordField) beans).setValue((String) val);
		}
		else if (beans instanceof MCNumberField) {
			((MCNumberField) beans).setValue((MCNumber) val);
		}
		else if (beans instanceof MCDateField) {
			((MCDateField) beans).setValue((MCDate) val);
		}
		else if (beans instanceof MCTimestampField) {
			((MCTimestampField) beans).setValue((MCTimestamp) val);
		}
		else {
			throw new MCAppException(msgUnknownClass(beans.getClass()));
		}
	}

	/**
	 * テーブルダブルクリック時の処理。決定ボタン押下時と同じ 動きをする
	 *
	 * @param info
	 */
	@Override
	public void doDCAccept(MCEventInfo info) {
		try {
			_isDCEvent = true;
			doAccept();
		}
		finally {
			_isDCEvent = false;
		}
	}

	/**
	 * ダブルクリック時のイベント
	 */
	@Override
	public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
		super.doDCEvent(compo, info);
		if (compo == getRsltTable()) {
			doDCAccept(info);
		}
	}

	@Override
	public void setPagingSize(int size) {
		_pagingSize = size;
	}

	/**
	 * ページングのサイズ
	 */
	@Override
	public int getPagingSize() {
		return _pagingSize != null ? _pagingSize : (_pagingSize = getDefaultPagingSize());
	}

	@Override
	public int getDefaultPagingSize() {
		return 100;
	}

	/**
	 * 検索処理（含むページングのnext / prev）の後処理を行います。 検索結果 list に対して必要な情報を付加します。<br>
	 * 想定している実装：区分の名称をつける
	 * @param 検索
	 */
	@Override
	public void afterCall(MCList<? extends MCRow> list) {

	}

	@Override
	public MCTable<?> getRsltTable() {
		if (_rsltTable == null) {
			JComponent comp = getComponent(getRsltL());
			if (comp instanceof MCTable) {
				_rsltTable = (MCTable<?>) comp;
			}
		}
		return _rsltTable;
	}

	/**
	 * ページングを行うPanelを返す。（ページング機能を使わない場合は、nullが返る）
	 */
	@Override
	public FXUCP_Paging getPagingPanel() {
		if (_pagingPanel == null) {
			for (MCRootPanel p : getPartsPanels()) {
				if (p instanceof FXUCP_Paging) {
					_pagingPanel = (FXUCP_Paging) p;
					break;
				}
			}
		}
		return _pagingPanel;
	}

	/**
	 * 検索結果を画面に表示します
	 *
	 * @param list
	 */
	@Override
	// getRsltLへのaddAll
	public void show(MCList<? extends MCRow> list) {
		// メモ：通常の画面のshow は setRsltL メソッドを使うが、
		// 共通親クラスでabstract作ってもオーバーライドに
		// ならないため、それ相当（clearしてaddAll）をやっている。
		getRsltL().clear();
		getRsltL().addAll(list);
		FXUCP_Paging p = getPagingPanel();
		if (p != null) {
			p.dispUpdate();
		}

		afterCallParts(getRsltL());
	}

	/**
	 * afterCallPartsを実行します
	 * @param list
	 */
	protected void afterCallParts(MCList<?> list) {
		for (MCRootPanel parts : getPartsPanels(list)) {
			if (parts instanceof IfDPartsForCaller) {
				IfDPartsForCaller dParts = (IfDPartsForCaller) parts;
				dParts.afterCallParts(getExceptRootEmptyMatcher(), null);
			}
		}
	}

	protected void setSilentMode(boolean silentMode) {
		_silentMode = silentMode;
	}

	/**
	 * サイレントモードかどうか？
	 */
	@Override
	public boolean isSilentMode() {
		return _silentMode;
	}

	// IfISPanelUtil対応（ここまで）
	// FXBAP_ISPanel対応（ここから）
	@Override
	public FXBAP_PanelBase getImplPanel() {
		return this;
	}

	@Override
	@SuppressWarnings("rawtypes")
	public MCList getList(MCRow bind, MCRootPanel parentPanel, boolean isInputMode) {
		if (bind == null) {
			return null;
		}
		if (isInputMode && bind.getValueNE($INPUT_VAL) == null) {
			return null;
		}

		siilentScreenClear();

		parentPanel = parentPanel.getBaseRootPanel();

		MCCacheType cacheType = getListCacheTyp(parentPanel);
		String moduleId = parentPanel.getModuleID();
		String screenId = parentPanel.getScreenID();
		int serial = parentPanel.getSerial();
		String method = getModuleID() + "." + getScreenID();
		String opeTyp = isInputMode ? GET_LIST : OPEN;

		MCList<MCRow> result = MCListCacher2.getList(cacheType, moduleId, screenId,
				serial, method, bind, opeTyp);

		if (result == null || result.isEmpty()) {
			MCLog.write(FXBAP0092);
			setSilentMode(true);
			setCondition(bind, opeTyp);
			doCnd_srch(null);
			setSilentMode(false);
			result = getRsltL();
			if (result != null && !result.isEmpty()) {
				MCListCacher2.cache(cacheType, moduleId, screenId, serial, method, bind,
						result, opeTyp);
			}
		}
		else {
			MCLog.write(FXBAP0093);
		}
		return result;
	}

	// 入力補助画面用処理（ここから）
	protected void siilentScreenClear() {
		screenClearBody();
		screenClearSetDefault();
		statusClear();
		if (isCreated()) {
			screenClearSetMode();
			screenClearSetFocus();
		}
	}

	/**
	 * 紐付けられているMCListPutterを返します。
	 *
	 * @return MCListPutter
	 */
	protected MCListPutter getISListPutter() {
		return _putter;
	}

	/**
	 * 入力補助画面の検索結果のキャッシュタイプを返す
	 * 
	 * @return
	 */
	protected MCCacheType getListCacheTyp(MCRootPanel parent) {
		if (_cache == null) {
			//入力補助画面ごとキャッシュ設定（最優先）
			String val = getPgmSettingStringNE(this, null, MCListCacher2.$CACHE_TYP);
			if (!isNull(val)) {
				try {
					_cache = MCCacheType.valueOf(val);
				}
				catch (Exception e) {
					throw e;
				}
			}
			//ISPanelUtilごとキャッシュ設定
			else {
				val = getPgmSettingStringNE(getClass(), null, MCListCacher2.$CACHE_TYP);
				if (!isNull(val)) {
					try {
						_cache = MCCacheType.valueOf(val);
					}
					catch (Exception e) {
						throw e;
					}
				}
			}
		}
		//ファイル入力処理中のキャッシュ設定
		if (MCCacheType.NONE == _cache) {
			return parent.getCacheType(null);
		}
		return _cache;
	}

	@Override
	public MCList getList(MCRow bind, MCRootPanel parentPanel,
			FXBAP_ISPanelInfo info) {
		_putter = info.getListPutter();
		_putIndex = info.getPutIndex();
		return getList(bind, parentPanel);
	}

	/**
	 * 検索結果をクリアします。
	 */
	@Override
	public void rsltLClear() {
		getRsltL().clear();
		// スクロールを左上に戻す
		Rectangle rect;
		rect = new Rectangle(0, 0, 0, 0);
		getRsltTable().scrollRectToVisible(rect);
	}

	// FXBAP_ISPanel対応（ここまで）
	// IfPagingAgentHolder対応（ここから）

	@Override
	public void doPageJump(int idxFrom, int idxTo) {
		rsltLClear();
		MCList<?> ls = getRsltL().createInstance();
		getPagingAgent().jump(idxFrom, idxTo, ls);
		afterCall(ls);
		show(ls);
	}

	@Override
	public void doPageNext() {
		rsltLClear();
		MCList<?> ls = getRsltL().createInstance();
		getPagingAgent().doNext(ls);
		afterCall(ls);
		show(ls);

		MCTable<?> t = getRsltTable();
		t.selectRowNoFocus(0);

		// 「前」「次」ボタンは連打したい可能性があるので
		// フォーカス移動は行わない
	}

	@Override
	public void doPagePrev() {
		rsltLClear();
		MCList<?> ls = getRsltL().createInstance();
		getPagingAgent().doPrevious(ls);
		afterCall(ls);
		show(ls);

		MCTable<?> t = getRsltTable();
		t.selectRowNoFocus(t.getList().size() - 1);

		// 「前」「次」ボタンは連打したい可能性があるので
		// フォーカス移動は行わない
	}

	/**
	 * ページングエージェントを返す。
	 */
	@Override
	public MCPagingAgent getPagingAgent() {
		return _pagingAgent != null ? _pagingAgent : (_pagingAgent = new MCPagingAgent());
	}

	// IfPagingAgentHolder対応（ここまで）
	@Override
	public void moveFocus() {
		if (!getRsltL().isEmpty()) {
			getRsltTable().selectLeftmostColumn(0);
		}
	}

	@Override
	public void moveFocusNoDataFound() {
		focusFirstComponent();
	}

	@Override
	public void panelClosed() {
		super.panelClosed();

		panelClosedSub();
	}

	/**
	 * 画面を閉じたときの処理を実行します。
	 */
	protected void panelClosedSub() {
		for (MCContainer c : getContainers()) {
			if (c instanceof MCRow) {
				((MCRow) c).clearAll();
			}
			else if (c instanceof MCList) {
				((MCList<?>) c).clear();
			}
		}
	}

	/**
	 * 選択チェックボックスのカラム名を返します。
	 *
	 * @return カラム名
	 */
	protected String getCheckColumnName() {
		return "check";
	}

	/**
	 * 選択チェックボックスカラムコンフィグを返します。
	 *
	 * @return カラムコンフィグ またはnull
	 */
	@Override
	public MCColumnConfig getCheckColumn() {
		String col = getCheckColumnName();
		if (isNull(col)) {
			return null;
		}
		for (MCColumnConfig c : getRsltTable().getColumnConfigs()) {
			if (col.equals(c.getRowColumnName())) {
				return c;
			}
		}
		return null;
	}

	@Override
	public MCList getAcceptList(MCLinkBeans target, boolean isDCEvent) {
		MCColumnConfig c = getCheckColumn();

		if (c == null) {
			if (isPluralValueField(target)) {
				return getRsltTable().getSelectedMCRows();
			}

			MCList l = getRsltL().createInstance();
			l.add(getRsltTable().getSelectedMCRow());
			return l;
		}

		MCList l = getRsltL().subList(c.getBaseRowColumnName(), true);
		if (isDCEvent) {
			//ＤＣの場合
			//チェックがＯＦＦの場合ダブルクリック行を返す
			//チェックがＯＮのものがある場合は決定できない
			if (l.isEmpty()) {
				l.add(getRsltTable().getSelectedMCRow());
				return l;
			}
			return getRsltL().createInstance();
		}
		//決定ボタンの場合
		//チェックがＯＮの行を返す
		//チェックが複数件ＯＮにできるかどうかはチェックカラムのイベント実装に依存する
		return l;
	}

	/**
	 * {@inheritDoc}<br>
	 *　リストロジックを検索処理に使用するための通信処理クラスを作成します。
	 *
	 * @param p パラメータ
	 * @param bind バインド
	 * @return　通信処理クラス
	 */
	@Override
	public MCCaller createListLogicCaller(MCParam p, MCRow bind) {
		return createLLCaller(this, p, bind);
	}

	protected MCCaller createLLCaller(FXBAP_PanelBase panel, MCParam p, MCRow bind) {
		FXBAP_ISLLCallerPanelBridge b = createLLCallerBridge(p, bind);
		return new FXBAP_ISLLSearcher<FXBAP_PanelBase, FXBAP_ISLLCallerPanelBridge>(panel,
				b);
	}

	/**
	 * リストロジック用通信処理クラスのためのブリッジを作成します。
	 *
	 * @param p パラメータ
	 * @param bind　バインド
	 * @return　ブリッジ
	 */
	protected FXBAP_ISLLCallerPanelBridge createLLCallerBridge(MCParam p, MCRow bind) {
		return new FXBAP_ISLLCallerPanelBridge(p, bind);
	}

	public class FXBAP_ISLLCallerPanelBridge extends MCCallerPanelBridge {
		final MCParam _p;

		final MCRow _bind;

		public FXBAP_ISLLCallerPanelBridge(MCParam p, MCRow bind) {
			super();
			_p = p;
			_bind = bind;
		}

		@Override
		protected MCParam param() {
			return _p;
		}

		@Override
		protected void setupParam() {
			MCListLogicBase2.setupCondition(param(), _bind);
		}

		@Override
		protected void show() {
			getRsltL().setAll((MCList) param().getContainerParam().getDownBlock(0));
		}

		@Override
		protected void clear() {
			//FXBAP_Callerはこのメソッドを実行しないため実装不要。
		}

		@Override
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> c = new ArrayList<>();
			c.add(_bind);
			return c;
		}

		@Override
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> c = new ArrayList<>();
			c.add(getRsltL());
			return c;
		}
	}

	/**
	 * リストロジックを検索処理に使用するための通信処理クラスです。
	 */
	public class FXBAP_ISLLSearcher<P extends FXBAP_PanelBase, O extends FXBAP_ISLLCallerPanelBridge>
			extends FXBAP_Searcher<P, O> {

		protected FXBAP_ISLLSearcher(P panel, O b) {
			super(panel, b);
		}

		@Override
		protected boolean beforeExecMain() {
			if (!isCreated()) {
				setScreenAsync(false);
				return true;
			}
			return super.beforeExecMain();
		}

		@Override
		protected void execMain() {
			if (!isCreated()) {
				try{
					lockScreen();
					setupParam();
					try {
						call();
					}
					catch (MCException e) {
						handleMCEx(e);
					}
					afterCall();
					show();
				}
				finally{
					unlockScreen();
				}
			}
			else {
				super.execMain();
			}
		}
		
		@Override
		protected void setupUpParam(MCContainer cont) {
			bridge.setupParam();
		}

		@Override
		protected void moveFocus() {
			super.moveFocus();

			getRsltTable().selectLeftmostColumn(0);
		}

		@Override
		protected void moveFocusNoDown() {
			super.moveFocusNoDown();

			panel.focusFirstComponent();
		}
		
	}

}