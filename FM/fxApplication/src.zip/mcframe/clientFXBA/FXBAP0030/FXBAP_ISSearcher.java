package mcframe.clientFXBA.FXBAP0030;


import mcframe.clientFXBA.FXBAP0010.*;
import mcframe.clientCore.beans.MCCallerPanelBridge;
import mcframe.commonCore.annotation.EI;


/**
 */
@EI
public class FXBAP_ISSearcher<P extends FXBAP_PanelBase, O extends MCCallerPanelBridge> extends
		FXBAP_ISSearcher_FW<P, O> {
	/**
	 * コンストラクタです。
	 * 
	 * @param panel 画面
	 * @param operation オペレーション
	 */
	public FXBAP_ISSearcher(P panel, O operation) {
		super(panel, operation);
	}

}
