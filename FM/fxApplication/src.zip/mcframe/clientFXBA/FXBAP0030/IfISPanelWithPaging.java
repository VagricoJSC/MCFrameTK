package mcframe.clientFXBA.FXBAP0030;
import mcframe.commonCore.annotation.EI;

@EI
public interface IfISPanelWithPaging extends IfISPanelWithPaging_FW {
}
