package mcframe.serverFXUC.FXUCL0010;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.logic.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

//手修正によるカスタマイズで必要なimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.serverCore.requester.MCRequestObject.*;

import java.util.Locale;

import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.resource.MCFormatConst;
import mcframe.commonCore.resource.MCLocaleConst;
import mcframe.serverCore.sys.MCSys;
//FMCB CUSTOM_IMPORT END

/**
 * "FXUCL_DataUtil"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
abstract public class FXUCL_DataUtil_FW extends FXUCL_DataUtil_FW_A{
	//FMCB CUSTOM START
	// サーバーオリジナルの実装（ここから）
	protected static final Class<FXUCL_DataUtil> CLAZZ = FXUCL_DataUtil.class;
	
	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toYMString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toYMString(dt);
	}

	/** クライアントロケールを返します */
	public Locale getClientLocale() {
		return MCSys.user.locale();
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toYMString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YM"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toYMDString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toYMDString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toYMDString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YMD"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toY2MString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toY2MString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toY2MString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2M"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toY2MDString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toY2MDString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toY2MDString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2MD"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（月日）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toMDString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toMDString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（月日）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toMDString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("MD"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toYMDHMSString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toYMDHMSString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toYMDHMSString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YMDHMS"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toY2MDHMSString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toY2MDHMSString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分秒）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toY2MDHMSString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2MDHMS"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toYMDHMString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toYMDHMString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toYMDHMString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("YMDHM"));
		}
		return ans;
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public static String toY2MDHMString(MCCalendarDate<?> dt) {
		return object(CLAZZ)._toY2MDHMString(dt);
	}

	/**
	 * 日付データをクライアントロケールに合わせた書式で文字列化します（年月日時分）
	 * 
	 * @param dt 日付データ
	 * @return 日付データの文字列表現
	 */
	public String _toY2MDHMString(MCCalendarDate<?> dt) {
		String ans;
		if (dt == null) {
			ans = null;
		}
		else {
			ans = dt.toString(getDateFormat("Y2MDHM"));
		}
		return ans;
	}
	
	/**
	 * 
	 * 日付のフォーマッタを返します。<p>
	 * FXの設定がない場合は標準のフォーマットを返します。
	 *
	 * @param id フォーマット ID
	 * @return フォーマッタ
	 */
	protected MCDateFormat getDateFormat(String id) {
		MCFormatConst formatConst = MCLocaleConst.format(getClientLocale());
		String format = formatConst.getString(getDateOutputPatternKey(id), formatConst.getDateOutputPattern(id));
		return MCDateFormat.create(format, getClientLocale());
	}

	// サーバーオリジナルの実装（ここまで）
	// 以下 クライアント・共通と同じ
	// コピペ -> object(CLAZZ) を me() に置換

	// ////////////////////////////////////
	// ////////////////////////////////////
	// ////////////////////////////////////
	// ////////////////////////////////////
	// 共通 String（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(String)}
	 */
	public static boolean isNull(String value) {
		return object(CLAZZ)._isNull(value);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(String, String)}
	 */
	public static String nvl(String val, String defVal) {
		return object(CLAZZ)._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(String, String)}
	 */
	public static boolean isSame(String val1, String val2) {
		return object(CLAZZ)._isSame(val1, val2);
	}

	// 共通 String（ここまで）
	// String オリジナル（ここから）
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isGTINCd(String)}
	 */
	public static boolean isGTINCd(String str) {
		return object(CLAZZ)._isGTINCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isITFCd(String)}
	 */
	public static boolean isITFCd(String str) {
		return object(CLAZZ)._isITFCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isJANCd(String)}
	 */
	public static boolean isJANCd(String str) {
		return object(CLAZZ)._isJANCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isHSCd(String)}
	 */
	public static boolean isHSCd(String str) {
		return object(CLAZZ)._isHSCd(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isZipCdStr(String)}
	 */
	public static boolean isZipCdStr(String str) {
		return object(CLAZZ)._isZipCdStr(str);
	}
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isZipCdStr(String, Locale)}
	 */
	public static boolean isZipCdStr(String str, Locale locale) {
		return object(CLAZZ)._isZipCdStr(str, locale);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isTelStr(String)}
	 */
	public static boolean isTelStr(String str) {
		return object(CLAZZ)._isTelStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isFaxStr(String)}
	 */
	public static boolean isFaxStr(String str) {
		return object(CLAZZ)._isFaxStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isUrlStr(String)}
	 */
	public static boolean isUrlStr(String str) {
		return object(CLAZZ)._isUrlStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isEmailStr(String)}
	 */
	public static boolean isEmailStr(String str) {
		return object(CLAZZ)._isEmailStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNumberStr(String)}
	 */
	public static boolean isNumberStr(String str) {
		return object(CLAZZ)._isNumberStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isPositiveNumberStr(String)}
	 */
	public static boolean isPositiveNumberStr(String str) {
		return object(CLAZZ)._isPositiveNumberStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNegativeNumberStr(String)}
	 */
	public static boolean isNegativeNumberStr(String str) {
		return object(CLAZZ)._isNegativeNumberStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isDigitsAlphabetStr(String)}
	 */
	public static boolean isDigitsAlphabetStr(String str) {
		return object(CLAZZ)._isDigitsAlphabetStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isAlphabetStr(String)}
	 */
	public static boolean isAlphabetStr(String str) {
		return object(CLAZZ)._isAlphabetStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isDigitsStr(String)}
	 */
	public static boolean isDigitsStr(String str) {
		return object(CLAZZ)._isDigitsStr(str);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(int, int, String)}
	 */
	public static String lpad(int num, int len, String addStr) {
		return object(CLAZZ)._lpad(num, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(String, int, String)}
	 */
	public static String lpad(String str, int len, String addStr) {
		return object(CLAZZ)._lpad(str, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(int, MCMeta, String)}
	 */
	public static String lpad(int num, MCMeta meta, String addStr) {
		return object(CLAZZ)._lpad(num, meta, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#lpad(String, MCMeta, String)}
	 */
	public static String lpad(String str, MCMeta meta, String addStr) {
		return object(CLAZZ)._lpad(str, meta, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(int, int, String)}
	 */
	public static String rpad(int num, int len, String addStr) {
		return object(CLAZZ)._rpad(num, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(String, int, String)}
	 */
	public static String rpad(String str, int len, String addStr) {
		return object(CLAZZ)._rpad(str, len, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(int, MCMeta, String)}
	 */
	public static String rpad(int num, MCMeta meta, String addStr) {
		return object(CLAZZ)._rpad(num, meta, addStr);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#rpad(String, MCMeta, String)}
	 */
	public static String rpad(String str, MCMeta meta, String addStr) {
		return object(CLAZZ)._rpad(str, meta, addStr);
	}

	// String オリジナル（ここまで）
	// 共通 Number（ここから）
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCNumber)}
	 */
	public static boolean isNull(MCNumber val) {
		return object(CLAZZ)._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(MCNumber, MCNumber)}
	 */
	public static MCNumber nvl(MCNumber val, MCNumber defVal) {
		return object(CLAZZ)._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(MCNumber, MCNumber)}
	 */
	public static boolean isSame(MCNumber val1, MCNumber val2) {
		return object(CLAZZ)._isSame((Number) val1, (Number) val2);
	}

	// 共通 Number（ここまで）
	// Numberオリジナル（ここから）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#negate(MCNumber)}
	 */
	public static MCNumber negate(MCNumber n) {
		return object(CLAZZ)._negate(n);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#sum(Comparable...)}
	 */
	public static MCNumber sum(Comparable<?>... args) {
		return object(CLAZZ)._sum(args);
	}

	// Numberオリジナル（ここまで）
	// 共通 MCDate（ここから）
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCDate)}
	 */
	public static boolean isNull(MCDate val) {
		return object(CLAZZ)._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(MCDate, MCDate)}
	 */
	public static MCDate nvl(MCDate val, MCDate defVal) {
		return object(CLAZZ)._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(MCDate, MCDate)}
	 */
	public static boolean isSame(MCDate val1, MCDate val2) {
		return object(CLAZZ)._isSame(val1, val2);
	}

	// 共通 MCDate（ここまで）
	// MCDateオリジナル（ここから）
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#toYM(MCDate)}
	 */	
	public static MCDate toYM(MCDate date) {
		return object(CLAZZ)._toYM(date);
	}

	// MCDateオリジナル（ここまで）

	// 共通 boolean（ここから）
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(Boolean)}
	 */	
	public static boolean isNull(Boolean val) {
		return object(CLAZZ)._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(Boolean, Boolean)}
	 */	
	public static Boolean nvl(Boolean val, Boolean defVal) {
		return object(CLAZZ)._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(Boolean, Boolean)}
	 */	
	public static boolean isSame(Boolean val1, Boolean val2) {
		return object(CLAZZ)._isSame(val1, val2);
	}

	// 共通 boolean（ここまで）
	// 共通 MCRow（ここから）
	
	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(MCRow, MCRow)}
	 */	
	public static MCRow nvl(MCRow val, MCRow defVal) {
		return object(CLAZZ)._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(MCRow, MCRow)}
	 */	
	public static boolean isSame(MCRow val1, MCRow val2) {
		return object(CLAZZ)._isSame(val1, val2);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCRow)}
	 */	
	public static boolean isNull(MCRow val) {
		return object(CLAZZ)._isNull(val);
	}

	// 共通 MCRow（ここまで）

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isColSame(MCRow, MCRow, String...)}
	 */	
	public static boolean isColSame(MCRow row1, MCRow row2, String... cols) {
		return object(CLAZZ)._isColSame(row1, row2, cols);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isColSame(MCRow, String[], MCRow, String[])}
	 */	
	public static boolean isColSame(MCRow row1, String[] cols1, MCRow row2,
			String[] cols2) {
		return object(CLAZZ)._isColSame(row1, cols1, row2, cols2);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(MCList)}
	 */		
	public static boolean isNull(MCList list) {
		return object(CLAZZ)._isNull(list);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNull(Comparable)}
	 */		
	public static boolean isNull(Comparable val) {
		return object(CLAZZ)._isNull(val);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#nvl(Comparable, Comparable)}
	 */		
	public static Comparable nvl(Comparable val, Comparable defVal) {
		return object(CLAZZ)._nvl(val, defVal);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isSame(Comparable, Comparable)}
	 */		
	public static boolean isSame(Comparable val1, Comparable val2) {
		return object(CLAZZ)._isSame(val1, val2);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNullAnd(Comparable...)}
	 */		
	public static boolean isNullAnd(Comparable<?>... vals) {
		return object(CLAZZ)._isNullAnd(vals);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isNullOr(Comparable...)}
	 */		
	public static boolean isNullOr(Comparable<?>... vals) {
		return object(CLAZZ)._isNullOr(vals);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isLike(String, String)}
	 */		
	public static boolean isLike(String arg0, String arg1) {
		return object(CLAZZ)._isLike(arg0, arg1, true);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#isLikeNoArray(String, String)}
	 */		
	public static boolean isLikeNoArray(String arg0, String arg1) {
		return object(CLAZZ)._isLike(arg0, arg1, false);
	}

	/**
	 * {@link mcframe.commonFXUC.FXUCC0010.FXUCC_DataUtil#toRegexForOracleLike(String)}
	 */		
	public static String toRegexForOracleLike(String str) {
		return object(CLAZZ)._toRegexForOracleLike(str);
	}
	//FMCB CUSTOM END
}