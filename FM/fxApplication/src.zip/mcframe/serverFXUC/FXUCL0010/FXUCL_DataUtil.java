package mcframe.serverFXUC.FXUCL0010;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.annotation.Rev;
import mcframe.commonCore.annotation.Rev.Pj;
import mcframe.commonCore.annotation.Rev.Cl;

/**
 * "FXUCL_DataUtil"ロジッククラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class FXUCL_DataUtil extends FXUCL_DataUtil_FW {

}