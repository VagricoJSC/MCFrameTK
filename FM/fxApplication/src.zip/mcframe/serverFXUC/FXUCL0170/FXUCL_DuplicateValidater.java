package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 重複チェック用クラスです。
 * <p>
 * 指定されたリストに重複行が存在する場合にメッセージを返します。
 * DBに重複するデータが存在するかをチェックするクラスではありません。
 */
@EI
public class FXUCL_DuplicateValidater extends FXUCL_DuplicateValidater_FW {

	public FXUCL_DuplicateValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_DuplicateValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_DuplicateValidater(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param nullable チェック対象の項目の値がnullまたは空の場合に重複チェックの対象とする場合true
	 */
	public FXUCL_DuplicateValidater(boolean nullable) {
		super(nullable);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_DuplicateValidater(r -> r.getBoolean("check"), true)
	 *
	 * @param filter フィルタ
	 * @param nullable チェック対象の項目の値がnullまたは空の場合に重複チェックの対象とする場合true
	 */
	public FXUCL_DuplicateValidater(Predicate<MCRow> filter, boolean nullable) {
		super(filter, nullable);
	}

}
