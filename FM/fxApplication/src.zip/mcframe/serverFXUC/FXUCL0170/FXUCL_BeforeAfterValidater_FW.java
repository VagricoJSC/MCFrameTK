package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.isNullOr;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.notice.MCMessage;

/**
 * 日付の前後チェック用クラスです。
 */
public abstract class FXUCL_BeforeAfterValidater_FW extends FXUCL_Validater {

	/**
	 * 同値を許容する場合true
	 */
	protected boolean equals = true;

	/**
	 * 前の日付のRow
	 */
	protected MCRow beforeRow;

	/**
	 * 前の日付の項目名
	 */
	protected String beforeCol;

	/**
	 * 後の日付のRow
	 */
	protected MCRow afterRow;

	/**
	 * 後の日付の項目名
	 */
	protected String afterCol;

	public FXUCL_BeforeAfterValidater_FW() {
		super();
	}

	public FXUCL_BeforeAfterValidater_FW(boolean equals) {
		super();
		this.equals = equals;
	}

	public FXUCL_BeforeAfterValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	public FXUCL_BeforeAfterValidater_FW(Predicate<MCRow> filter, boolean equals) {
		super(filter);
		this.equals = equals;
	}

	/**
	 * 前の日付を設定します。
	 * ヘッダの日付と明細の日付を比較する、かつ、前の日付がヘッダの場合に利用します。
	 *
	 * @param row 前の日付のRow
	 * @param col 前の日付の項目名
	 */
	public void setBefore(MCRow row, String col) {
		checkDataType(MCDataType.DATE, row, col);
		beforeRow = row;
		beforeCol = col;
	}

	/**
	 * 後の日付を設定します。
	 * ヘッダの日付と明細の日付を比較する、かつ、後の日付がヘッダの場合に利用します。
	 *
	 * @param row 後の日付のRow
	 * @param col 後の日付の項目名
	 */
	public void setAfter(MCRow row, String col) {
		checkDataType(MCDataType.DATE, row, col);
		afterRow = row;
		afterCol = col;
	}

	@Override
	protected int getColMax() {
		return getColCount(3);
	}

	@Override
	protected int getColMin() {
		return getColCount(2);
	}

	protected int getColCount(int count) {
		int result = count;
		if (isSetBefore()) {
			result--;
		}
		if (isSetAfter()) {
			result--;
		}
		return result;
	}

	protected boolean isSetBefore() {
		return !isNullOr(beforeRow, beforeCol);
	}

	protected boolean isSetAfter() {
		return !isNullOr(afterRow, afterCol);
	}

	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return createSkipNullAtLeastOneFilter(colName);
	}

	/**
	 * 日付の前後関係が不正な場合trueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return 前後関係が不正な場合true
	 * @throws [FXUCC0001] チェック対象の項目が日付型ではない場合
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		checkDataType(MCDataType.DATE, row, colName);

		int count = colName.length;
		if (isSetBefore()) {
			count++;
		}
		if (isSetAfter()) {
			count++;
		}
		Comparable<?>[] vals = new Comparable<?>[count];
		int pos = 0;
		if (isSetBefore()) {
			vals[pos++] = beforeRow.getDate(beforeCol);
		}
		System.arraycopy(row.toArray(colName), 0, vals, pos, colName.length);
		pos += colName.length;
		if (isSetAfter()) {
			vals[pos] = afterRow.getDate(afterCol);
		}
		return !isBeforeAfter(vals);
	}

	/**
	 * 日付の前後関係を比較します。
	 *
	 * @param vals 日付の配列
	 * @return 前後関係が問題ない場合true
	 */
	protected boolean isBeforeAfter(Comparable<?>[] vals) {
		for (int i = 0; i < vals.length - 1; i++) {
			if (!isBeforeAfter((MCDate) vals[i], (MCDate) vals[i + 1])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 日付の前後関係を比較します。
	 *
	 * @param d1 前の日付
	 * @param d2 後の日付
	 * @return 前後関係が問題ない場合true
	 */
	protected boolean isBeforeAfter(MCDate d1, MCDate d2) {
		return equals ? d1.lte(d2) : d1.lt(d2);
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		boolean before = isSetBefore();
		boolean after = isSetAfter();
		if (!before && !after) {
			if (colName.length == 2) {
				return FXUCL_ValidaterUtil.msgNotBefore(row, colName[0], colName[1],
						equals);
			}
			return FXUCL_ValidaterUtil.msgNot3DtBeforeAfter(row, colName[0], colName[1],
					colName[2], equals);
		}
		if (before && after) {
			return FXUCL_ValidaterUtil.msgNot3DtBeforeAfter(row, colName[0], beforeRow,
					beforeCol, row, colName[0], afterRow, afterCol, equals);
		}
		if (colName.length == 1) {
			if (!before) {
				return FXUCL_ValidaterUtil.msgNotBefore(row, colName[0], row, colName[0],
						afterRow, afterCol, equals);
			}
			return FXUCL_ValidaterUtil.msgNotBefore(row, colName[0], beforeRow, beforeCol,
					row, colName[0], equals);
		}
		if (!before) {
			return FXUCL_ValidaterUtil.msgNot3DtBeforeAfter(row, colName[0], row,
					colName[0], row, colName[1], afterRow, afterCol, equals);
		}
		return FXUCL_ValidaterUtil.msgNot3DtBeforeAfter(row, colName[0], beforeRow,
				beforeCol, row, colName[0], row, colName[1], equals);
	}

}
