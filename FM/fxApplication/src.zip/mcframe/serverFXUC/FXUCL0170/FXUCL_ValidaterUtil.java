package mcframe.serverFXUC.FXUCL0170;

import mcframe.commonCore.annotation.EI;

@EI
public class FXUCL_ValidaterUtil extends FXUCL_ValidaterUtil_FW {
}
