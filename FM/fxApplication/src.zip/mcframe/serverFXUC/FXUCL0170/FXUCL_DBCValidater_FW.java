package mcframe.serverFXUC.FXUCL0170;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.queryapi.IFMCSQL.*;
import static mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;

/**
 * マスタの存在チェック用クラスです。
 */
public class FXUCL_DBCValidater_FW<R extends MCDBContainer>
		extends FXUCL_ExistValidater<R,MCList<R>> {

	/**
	 * クエリAPIビルダー
	 */
	protected MCQueryApiBuilder builder;

	/**
	 * コンストラクタです。
	 *
	 * @param builder クエリAPIビルダー
	 * @param dbColName ＤＢコンテナのカラム名
	 */
	public FXUCL_DBCValidater_FW(MCQueryApiBuilder builder, String... dbColName) {
		super(MCList.create((R)builder.getBaseDbc()), getDBColName((R)builder.getBaseDbc(), dbColName));
		this.builder = builder;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param dbc ＤＢコンテナ
	 * @param dbColName ＤＢコンテナのカラム名
	 */
	public FXUCL_DBCValidater_FW(R dbc, String... dbColName) {
		super(MCList.create(dbc), getDBColName(dbc, dbColName));
		this.builder = MCQueryApiBuilder.create(dbc);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 * @param builder クエリAPIビルダー
	 * @param dbColName ＤＢコンテナのカラム名
	 */
	public FXUCL_DBCValidater_FW(Predicate<MCRow> filter, MCQueryApiBuilder builder, String... dbColName) {
		super(filter, MCList.create((R)builder.getBaseDbc()), getDBColName((R)builder.getBaseDbc(), dbColName));
		this.builder = builder;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 * @param dbc ＤＢコンテナ
	 * @param dbColName ＤＢコンテナのカラム名
	 */
	public FXUCL_DBCValidater_FW(Predicate<MCRow> filter, R dbc, String... dbColName) {
		super(filter, MCList.create(dbc), getDBColName(dbc, dbColName));
		this.builder = MCQueryApiBuilder.create(dbc);
	}

	/**
	 * ＤＢコンテナのカラム名を返します。
	 * カラム名が指定されていない場合はＤＢコンテナのキー項目を返します。
	 *
	 * @param dbc ＤＢコンテナ
	 * @param dbColName コンストラクタで指定されたＤＢコンテナのカラム名
	 * @return ＤＢコンテナのカラム名
	 * @throws MCAppException [FXUCL0015] コンストラクタでＤＢコンテナのカラム名を指定していない且つＤＢコンテナにキー項目が設定されていない場合
	 */
	protected static <R extends MCDBContainer> String[] getDBColName(
			R dbc, String... dbColName) {
		if (dbColName == null || dbColName.length == 0
				|| dbColName.length == 1 && MCStringUtil.isNull(dbColName[0])) {
			dbColName = dbc.getKeyColumn();
			if (dbColName.length == 0) {
				throw new MCAppException(FXUCL0015, dbc.tableName());
			}
		}
		return dbColName;
	}

	/**
	 * コンストラクタで指定されたＤＢコンテナを使用して検索を実行します。
	 * その際、ＤＢコンテナに以下の検索条件が設定されます。<br>
	 *    T.[コンストラクタで指定したＤＢ項目名] = :[チェック対象のカラム名]<br>
	 * コンストラクタで指定されたＤＢコンテナにデータが格納されている場合は何もしません。
	 *
	 * @param con チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_ExistValidater_FW#setupList(mcframe.commonCore.container.MCContainer, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void setupList(MCContainer con, String... colName) {
		super.setupList(con, colName);
		if (list.isEmpty()) {
			for (int i = 0; i < listColName.length; i++) {
				MCPermColumn col = builder.getBaseDbc().getColumn$(listColName[i]);
				if (col == null) {
					//TODO カラムが見つからなかった
				}
				builder.addWhereWithAnd(MCQueryApiBuilder.makeEq(col, bind(colName[i])));
			}
			if (con instanceof MCRow) {
				dbSelect(createSqlId("FXUCL0170", builder.getBaseDbc().tableName(), "S01"), list, builder, (MCRow)con);
			}
			else if (con instanceof MCList) {
				dbSelect(createSqlId("FXUCL0170", builder.getBaseDbc().tableName(), "S02"), list, builder, (MCList<MCRow>)con);
			}
		}
	}
	
	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return createSkipNullFilter(colName);
	}

	/**
	 * マスタの存在チェックのメッセージを返します。
	 *
	 * @param row Row
	 * @param v 値
	 * @param colName カラム名
	 * @return メッセージ
	 */
	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgNotExistInTable(builder.getBaseDbc(), row, colName);
	}
}
