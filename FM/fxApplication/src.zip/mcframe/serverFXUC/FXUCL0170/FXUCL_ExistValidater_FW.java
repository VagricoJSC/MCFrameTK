package mcframe.serverFXUC.FXUCL0170;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverFXUC.FXUCL0170.FXUCL_ValidaterUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCIndexKey;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCMessage;

/**
 * リストの存在チェック用クラスです。
 */
public class FXUCL_ExistValidater_FW<R extends MCRow, L extends MCList<R>> extends
		FXUCL_Validater {

	/**
	 * リスト
	 */
	protected L list;

	/**
	 * 項目名
	 */
	protected String[] listColName;

	/**
	 * リストのインデックスキーです。
	 */
	protected MCIndexKey idxKey;

	/**
	 * コンストラクタです。
	 *
	 * @param list リスト
	 * @param colName 項目名
	 */
	public FXUCL_ExistValidater_FW(L list, String... colName) {
		super();
		this.list = list;
		this.listColName = colName;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 * @param list リスト
	 * @param colName 項目名
	 */
	public FXUCL_ExistValidater_FW(Predicate<MCRow> filter, L list, String... colName) {
		super(filter);
		this.list = list;
		this.listColName = colName;
	}

	@Override
	protected boolean init(MCContainer con, String... colName) {
		if (super.init(con, colName) && list != null) {
			initCheck(con, colName);
			setupList(con, colName);
			idxKey = list.createIndex(listColName);
			return true;
		}
		return false;
	}

	/**
	 * 初期化処理のチェック処理を実行します。
	 *
	 * @param con チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @throws MCAppException [FXUCL0014] コンストラクタで指定した項目名がnullの場合。
	 * @throws MCAppException [FXUCL0016] コンストラクタで指定した項目名とチェック対象の項目名の数が異なる場合。
	 */
	protected void initCheck(MCContainer con, String... colName) {
		if (listColName == null || listColName.length == 0) {
			throw new MCAppException(FXUCL0014);
		}
		if (listColName.length != colName.length) {
			throw new MCAppException(FXUCL0016, MCStringUtil.join(" ", listColName),
					MCStringUtil.join(" ", colName));
		}
	}

	/**
	 * リストの初期化処理を実行します。
	 *
	 * @param con チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 */
	protected void setupList(MCContainer con, String... colName) {
		// 何もしない
	}

	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return createSkipNullFilter(colName);
	}

	/**
	 * チェック対象の値がリストに存在しない場合にtrueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return リストに存在しない場合true
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		MCRow r;
		if (idxKey != null) {
			r = list.getFirst(idxKey, row.toArray(colName));
		}
		else {
			r = list.getFirst(listColName, row.toArray(colName));
		}
		return r == null;
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgNotExistInList(row, colName);
	}
}
