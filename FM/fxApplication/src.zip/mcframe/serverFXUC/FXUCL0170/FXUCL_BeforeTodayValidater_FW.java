package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0160.FXUCL_DateUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;

/**
 * 日付と運用日付の前後チェック用クラスです。
 */
public abstract class FXUCL_BeforeTodayValidater_FW extends FXUCL_BeforeAfterValidater {

	public FXUCL_BeforeTodayValidater_FW() {
		super();
	}

	public FXUCL_BeforeTodayValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	public FXUCL_BeforeTodayValidater_FW(boolean equals) {
		super(equals);
	}

	public FXUCL_BeforeTodayValidater_FW(Predicate<MCRow> filter, boolean equals) {
		super(filter, equals);
	}

	@Override
	protected int getColMax() {
		return 2;
	}

	@Override
	protected int getColMin() {
		return 1;
	}

	@Override
	protected boolean isBeforeAfter(Comparable<?>[] vals) {
		// チェック対象の値の配列の末尾に運用日付を追加
		Comparable<?>[] newVals = new Comparable<?>[vals.length + 1];
		for (int i = 0; i < vals.length; i++) {
			newVals[i] = vals[i];
		}
		newVals[newVals.length - 1] = getToday();
		return super.isBeforeAfter(newVals);
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		if (colName.length == 1) {
			return FXUCL_ValidaterUtil.msgNotBeforeToday(row, colName[0], equals);
		}
		else if (colName.length == 2) {
			return FXUCL_ValidaterUtil.msgNot2DtBeforeToday(row, colName[0], colName[1],
					equals);
		}
		return null;
	}
}
