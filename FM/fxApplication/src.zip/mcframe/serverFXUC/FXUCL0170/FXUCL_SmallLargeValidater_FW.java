package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCMessage;

/**
 * 数値の大小チェック用クラスです。
 */
public abstract class FXUCL_SmallLargeValidater_FW extends FXUCL_Validater {

	/**
	 * 最小値
	 */
	protected MCNumber min = null;

	/**
	 * 最大値
	 */
	protected MCNumber max = null;

	/**
	 * 同値を許容する場合true
	 */
	protected boolean equals = true;

	public FXUCL_SmallLargeValidater_FW() {
		super();
	}

	public FXUCL_SmallLargeValidater_FW(boolean equals) {
		super();
		this.equals = equals;
	}

	public FXUCL_SmallLargeValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	public FXUCL_SmallLargeValidater_FW(Predicate<MCRow> filter, boolean equals) {
		super(filter);
		this.equals = equals;
	}

	public FXUCL_SmallLargeValidater_FW(MCNumber min, MCNumber max) {
		super();
		this.min = min;
		this.max = max;
	}

	public FXUCL_SmallLargeValidater_FW(MCNumber min, MCNumber max, boolean equals) {
		super();
		this.min = min;
		this.max = max;
		this.equals = equals;
	}

	public FXUCL_SmallLargeValidater_FW(Predicate<MCRow> filter, MCNumber min,
			MCNumber max) {
		super(filter);
		this.min = min;
		this.max = max;
	}

	public FXUCL_SmallLargeValidater_FW(Predicate<MCRow> filter, MCNumber min,
			MCNumber max, boolean equals) {
		super(filter);
		this.min = min;
		this.max = max;
		this.equals = equals;
	}

	@Override
	protected int getColMax() {
		if (min == null && max == null) {
			return 3;
		}
		if (min != null && max != null) {
			return 1;
		}
		return 2;
	}

	@Override
	protected int getColMin() {
		if (min == null && max == null) {
			return 2;
		}
		return 1;
	}

	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return createSkipNullAtLeastOneFilter(colName);
	}

	/**
	 * 数値の大小関係が不正な場合trueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return 大小関係が不正な場合true
	 * @throws [FXUCC0001] チェック対象の項目が数値型ではない場合
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		checkDataType(MCDataType.NUMBER, row, colName);
		return !isSmallLarge(row.toArray(colName));
	}

	/**
	 * 数値の大小関係を比較します。
	 *
	 * @param vals 数値の配列
	 * @return 大小関係が問題ない場合true
	 */
	protected boolean isSmallLarge(Comparable<?>[] vals) {
		if (min != null) {
			if (isSmallLarge(min, (MCNumber) vals[0])) {
				return false;
			}
		}
		for (int i = 0; i < vals.length - 1; i++) {
			if (isSmallLarge((MCNumber) vals[i], (MCNumber) vals[i + 1])) {
				return false;
			}
		}
		if (max != null) {
			if (isSmallLarge((MCNumber) vals[vals.length - 1], max)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 数値の大小関係を比較します。
	 *
	 * @param n1 小さい数値
	 * @param n2 大きい数値
	 * @return 大小関係が問題ない場合true
	 */
	protected boolean isSmallLarge(MCNumber n1, MCNumber n2) {
		return equals ? n1.gt(n2) : n1.gte(n2);
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		if (min == null && max == null) {
			if (colName.length == 2) {
				return FXUCL_ValidaterUtil.msgNotSmall(row, colName[0], colName[1],
						equals);
			}
			else {
				return FXUCL_ValidaterUtil.msgNot3NumSmallLarge(row, colName[0],
						colName[1], colName[2], equals);
			}
		}
		if (min != null && max != null) {
			return FXUCL_ValidaterUtil.msgNot3NumSmallLarge(row, min, colName[0], max,
					equals);
		}
		if (colName.length == 1) {
			if (min == null) {
				return FXUCL_ValidaterUtil.msgNotSmall(row, colName[0], max, equals);
			}
			else {
				return FXUCL_ValidaterUtil.msgNotLarge(row, min, colName[0], equals);
			}
		}
		else {
			if (min == null) {
				return FXUCL_ValidaterUtil.msgNot3NumSmallLarge(row, colName[0],
						colName[1], max, equals);
			}
			else {
				return FXUCL_ValidaterUtil.msgNot3NumSmallLarge(row, min, colName[0],
						colName[1], equals);
			}
		}
	}
}
