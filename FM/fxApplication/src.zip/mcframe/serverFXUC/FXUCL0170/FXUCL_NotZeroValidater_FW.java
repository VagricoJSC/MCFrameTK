package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.notice.MCMessage;

/**
 * 数値がゼロの場合にメッセージを返すチェック用クラスです。
 */
public abstract class FXUCL_NotZeroValidater_FW extends FXUCL_Validater {

	public FXUCL_NotZeroValidater_FW() {
		super();
	}

	public FXUCL_NotZeroValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	@Override
	protected int getColMax() {
		return 1;
	}

	/**
	 * 以下の場合はチェック対象外とします。<br>
	 * ・チェック対象のカラムが数値型ではない場合<br>
	 * ・チェック対象の値がnullの場合
	 *
	 * @param colName チェック対象のカラム名
	 * @return フィルタ
	 */
	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return r -> r.getDataType(colName[0]) == MCDataType.NUMBER
				&& r.getNumber(colName[0]) != null;
	}

	/**
	 * 数値がゼロの場合にtrueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return 数値がゼロの場合true
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		return row.getNumber(colName[0]).isZero();
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgZero(row, colName[0]);
	}
}
