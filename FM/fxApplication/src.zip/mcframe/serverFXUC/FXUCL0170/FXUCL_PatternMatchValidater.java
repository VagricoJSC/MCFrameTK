package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 正規表現による文字列チェック用クラスです。
 * <p>
 *正規表現に合致しない場合にメッセージを返します。
 */
@EI
public class FXUCL_PatternMatchValidater extends FXUCL_PatternMatchValidater_FW {

	/**
	 * コンストラクタです。
	 * 引数に指定した正規表現に合致しない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_PatternMatchValidater(r -> r.getBoolean("check"), "[0-9]+", label)
	 *
	 * @param filter フィルタ
	 * @param regex 正規表現
	 * @param name パターンの名称。メッセージに使用される
	 */
	public FXUCL_PatternMatchValidater(Predicate<MCRow> filter, String regex, String name) {
		super(filter, regex, name);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定した正規表現に合致しない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_PatternMatchValidater("[0-9]+", label)
	 *
	 * @param regex 正規表現
	 * @param name パターンの名称。メッセージに使用される
	 */
	public FXUCL_PatternMatchValidater(String regex, String name) {
		super(regex, name);
	}
}
