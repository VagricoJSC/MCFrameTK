package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;

/**
 * 指定された項目が全て未入力の場合にメッセージを返すチェック用クラスです。
 */
public abstract class FXUCL_AtLeastOneValidater_FW extends FXUCL_Validater {

	public FXUCL_AtLeastOneValidater_FW() {
		super();
	}

	public FXUCL_AtLeastOneValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * 指定された項目が全て未入力の場合にtrueを返します。
	 *
	 * @param row チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @return 全て未入力の場合true
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		for (String col : colName) {
			if (isInput(row.getValueNE(col))) {
				return false;
			}
		}
		return true;
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgAtLeastOneInput(row, colName);
	}
}
