package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 必須チェック用クラスです。
 * <p>
 * チェック対象の項目は１つだけ指定できます。
 */
@EI
public class FXUCL_RequiredValidater extends FXUCL_RequiredValidater_FW {

	public FXUCL_RequiredValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_RequiredValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_RequiredValidater(Predicate<MCRow> filter) {
		super(filter);
	}
}
