package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * メタ情報の桁チェック用クラスです。
 * <p>
 * 指定された項目が文字列型または数値型の場合に、メタ情報の桁数に違反している場合にメッセージを返します。
 * 数値型の場合、負の値を許容するかどうかはチェックしません。
 */
@EI
public class FXUCL_ScaleAndLengthValidater extends FXUCL_ScaleAndLengthValidater_FW {

	public FXUCL_ScaleAndLengthValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_ScaleAndLengthValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_ScaleAndLengthValidater(Predicate<MCRow> filter) {
		super(filter);
	}

}
