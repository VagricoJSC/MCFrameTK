package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCDateFieldType;

/**
 * 時分秒を切り捨てた日付と運用日付の前後チェック用クラスです。
 */
public abstract class FXUCL_TmBeforeTodayValidater_FW extends FXUCL_BeforeTodayValidater {

	public FXUCL_TmBeforeTodayValidater_FW() {
		super();
	}

	public FXUCL_TmBeforeTodayValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	@Override
	protected boolean isBeforeAfter(Comparable<?>[] vals) {
		// 時分秒を切り捨てる
		for (int i = 0; i < vals.length; i++) {
			vals[i] = ((MCDate) vals[i]).trunc(MCDateFieldType.DAY);
		}
		return super.isBeforeAfter(vals);
	}
}
