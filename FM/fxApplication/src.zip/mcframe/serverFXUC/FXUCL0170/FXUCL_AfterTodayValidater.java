package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 運用日付と日付の前後チェック用クラスです。
 * <p>
 * 運用日付≦指定された日付　ではない場合にメッセージを返します。<br>
 * チェック対象の日付は１つだけ指定可能です。<br>
 * 大小比較で同値を許容しない場合（日付＜日付のチェックをしたい場合）は引数にbooleanをもつコンストラクタを使用してください。
 */
@EI
public class FXUCL_AfterTodayValidater extends FXUCL_AfterTodayValidater_FW {

	public FXUCL_AfterTodayValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_AfterTodayValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_AfterTodayValidater(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_AfterTodayValidater(boolean equals) {
		super(equals);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_AfterTodayValidater(r -> r.getBoolean("check"), false)
	 *
	 * @param filter フィルタ
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_AfterTodayValidater(Predicate<MCRow> filter, boolean equals) {
		super(filter, equals);
	}

}
