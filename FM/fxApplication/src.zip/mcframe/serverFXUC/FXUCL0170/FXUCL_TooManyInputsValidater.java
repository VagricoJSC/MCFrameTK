package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 指定された項目のうち、値が入力されている項目が２個以上ある場合にエラーメッセージを返すチェック用クラスです。
 * <p>
 * 指定された項目の型がBoolean型の場合、trueの場合に値が入力されているとみなします。
 * その他の型は{@link mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil#isNull(Comparable)}に依存します。
 */
@EI
public class FXUCL_TooManyInputsValidater extends FXUCL_TooManyInputsValidater_FW {

	public FXUCL_TooManyInputsValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_TooManyInputsValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_TooManyInputsValidater(Predicate<MCRow> filter) {
		super(filter);
	}

}
