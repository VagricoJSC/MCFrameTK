package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCRowComparator;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

/**
 * 重複チェック用クラスです。
 */
public abstract class FXUCL_DuplicateValidater_FW extends FXUCL_Validater {

	/**
	 * trueの場合、値がnullの項目も重複チェックの対象とする（デフォルトfalse）
	 */
	protected boolean nullable = false;

	public FXUCL_DuplicateValidater_FW() {
		super();
	}

	public FXUCL_DuplicateValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param nullable nullを重複チェックの対象とする場合true
	 */
	public FXUCL_DuplicateValidater_FW(boolean nullable) {
		super();
		this.nullable = nullable;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 * @param nullable nullを重複チェックの対象とする場合true
	 */
	public FXUCL_DuplicateValidater_FW(Predicate<MCRow> filter, boolean nullable) {
		super(filter);
		this.nullable = nullable;
	}

	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		if (nullable) {
			return null;
		}
		return createSkipNullAtLeastOneFilter(colName);
	}

	@Override
	public MCMessageList validate(MCRow row, String... colName) {
		// 何もしない
		return new MCMessageList();
	}

	@Override
	public MCMessageList validate(MCList<? extends MCRow> list, String... colName) {
		MCMessageList msgList = new MCMessageList();
		Stream<? extends MCRow> stream = createStream(list, colName);

		// チェック対象のカラムでソート
		stream = stream.sorted(new MCRowComparator.ASC<MCRow>(colName));

		// フィルタとソートの結果を取得
		List<MCRow> newList = stream.collect(Collectors.toList());
		MCRow preRow = null;
		for (MCRow r : newList) {
			if (preRow != null) {
				if (isInvalid(preRow, r, colName)) {
					msgList.add(getMessage(preRow, r, colName));
				}
			}
			preRow = r;
		}
		return msgList;
	}

	/**
	 * 引数のRowのカラムの値が重複している場合にtrueを返します。
	 *
	 * @param row1
	 * @param row2
	 * @param colName　カラム名
	 * @return 重複している場合true
	 */
	protected boolean isInvalid(MCRow row1, MCRow row2, String... colName) {
		return isColSame(row1, row2, colName);
	}

	/**
	 * 重複チェックではこのメソッドは実行されません。
	 * @see #isInvalid(MCRow, MCRow, String...)
	 */
	@Override
	@Deprecated
	protected boolean isInvalid(MCRow row, String... colName) {
		return false;
	}

	/**
	 * 重複チェック処理のメッセージを返します。
	 *
	 * @param row1 チェック対象のRow
	 * @param row2 チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return メッセージ
	 */
	protected MCMessage getMessage(MCRow row1, MCRow row2, String... colName) {
		return FXUCL_ValidaterUtil.msgDuplicate(row1, row2, colName);
	}

	/**
	 * 重複チェックではこのメソッドは実行されません。
	 * @see #getMessage(MCRow, MCRow, String...)
	 */
	@Override
	@Deprecated
	protected MCMessage getMessage(MCRow row, String... colName) {
		return null;
	}
}
