package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;

/**
 * 必須チェック用クラスです。
 */
public class FXUCL_RequiredValidater_FW extends FXUCL_Validater {

	/**
	 * コンストラクタです。
	 */
	public FXUCL_RequiredValidater_FW() {
		super();
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_RequiredValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	@Override
	protected int getColMax() {
		return 1;
	}

	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		return isNull(row.getValueNE(colName[0]));
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgNoDataAtReq(row, colName[0]);
	}
}
