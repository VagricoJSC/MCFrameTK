package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 数値がゼロの場合にメッセージを返すチェック用クラスです。
 * <p>
 * チェック対象の数値は１つだけ指定できます。<br>
 * 指定された項目が以下に該当する場合はチェック対象外となります。<br>
 * <li>チェック対象の項目が数値型ではない場合</li>
 * <li>チェック対象の値がnullの場合</li>
 */
@EI
public class FXUCL_NotZeroValidater extends FXUCL_NotZeroValidater_FW {

	public FXUCL_NotZeroValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_NotZeroValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_NotZeroValidater(Predicate<MCRow> filter) {
		super(filter);
	}

}
