package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 時分秒を切り捨てた日付と運用日付の前後チェック用クラスです。
 * <p>
 * 時分秒を切り捨てた日付≦運用日付　ではない場合にメッセージを返します。<br>
 * チェック対象の日付は２つまで指定できます。チェック対象の日付を２つ指定した場合は、指定した日付の前後関係もチェックします。
 * 時分秒を切り捨てた１つ目の日付≦時分秒を切り捨てた２つ目の日付≦運用日付　ではない場合にメッセージを返します。
 */
@EI
public class FXUCL_TmBeforeTodayValidater extends FXUCL_TmBeforeTodayValidater_FW {

	public FXUCL_TmBeforeTodayValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_TmBeforeTodayValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter
	 */
	public FXUCL_TmBeforeTodayValidater(Predicate<MCRow> filter) {
		super(filter);
	}

}
