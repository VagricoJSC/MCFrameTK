package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 日付と運用日付の前後チェック用クラスです。
 * <p>
 * 指定された日付≦運用日付　ではない場合にメッセージを返します。<br>
 * チェック対象の日付は２つまで指定できます。チェック対象の日付を２つ指定した場合は、指定した日付の前後関係もチェックします。
 * １つ目の日付≦２つ目の日付≦運用日付　ではない場合にメッセージを返します。<br>
 * 大小比較で同値を許容しない場合（日付＜日付のチェックをしたい場合）は引数にbooleanをもつコンストラクタを使用してください。
 */
@EI
public class FXUCL_BeforeTodayValidater extends FXUCL_BeforeTodayValidater_FW {

	public FXUCL_BeforeTodayValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_BeforeTodayValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter
	 */
	public FXUCL_BeforeTodayValidater(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_BeforeTodayValidater(boolean equals) {
		super(equals);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_BeforeTodayValidater(r -> r.getBoolean("check"), false)
	 *
	 * @param filter
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_BeforeTodayValidater(Predicate<MCRow> filter, boolean equals) {
		super(filter, equals);
	}

}
