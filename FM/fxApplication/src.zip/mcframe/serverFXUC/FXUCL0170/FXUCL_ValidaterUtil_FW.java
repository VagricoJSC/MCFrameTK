package mcframe.serverFXUC.FXUCL0170;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.requester.MCRequestObject.object;
import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;
import static mcframe.serverFXUC.FXUCL0160.FXUCL_DateUtil.*;

import java.util.ArrayList;
import java.util.List;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonCore.resource.MCLocaleConst;
import mcframe.commonFXUC.FXUCC0170.FXUCC_ValidaterUtil;
import mcframe.serverCore.acl.MCACLManager;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.requester.MCLogicLabelUtil;
import mcframe.serverCore.resource.MCConst;
import mcframe.serverCore.sys.MCSys;

/**
 * 項目チェックのユーティリティクラスです。
 */
public abstract class FXUCL_ValidaterUtil_FW extends FXUCC_ValidaterUtil {

	/**
	 * 自身のインスタンス
	 * スレッド単位でインスタンスを保持する。（キャッシュの範囲もスレッド単位にする。）
	 */
	protected static final Class<FXUCL_ValidaterUtil> CLAZZ = FXUCL_ValidaterUtil.class;

	/**
	 * コンストラクタです。
	 */
	public FXUCL_ValidaterUtil_FW() {
		super();
	}

	@Override
	protected String toString(MCMessage msg) {
		return msg.toString(MCLocaleConst.message(MCSys.user.locale()));
	}

	/**
	 * 指定された項目の文字列表現を返します。
	 * <p>
	 * 項目ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 * カラム名が複数指定された場合は改行コード（LF）で区切ります。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return 文字列
	 */
	public static String toStringWithMsgLabel(MCRow row, String... colName) {
		return object(CLAZZ)._toStringWithMsgLabel(row, colName);
	}

	/**
	 * 指定された項目の文字列表現を返します。
	 * <p>
	 * 項目ラベルと値の並び順やデリミタはメッセージ  FXUCC0022 を使用します。
	 * カラム名が複数指定された場合は改行コード（LF）で区切ります。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return 文字列
	 */
	protected String _toStringWithMsgLabel(MCRow row, String... colName) {
		String[] label = new String[colName.length];
		Comparable<?>[] value = new Comparable<?>[colName.length];
		for (int i = 0; i < colName.length; i++) {
			label[i] = _getLabel(row, colName[i]);
			value[i] = row.getValueNE(colName[i]);
		}
		return _toStringWithMsgLabel(label, value);
	}

	/**
	 * 上り電文の項目ラベルを返します。
	 * ラベルが取得できない場合はカラム名を返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return ラベル
	 */
	public static String getLabel(MCRow row, String colName) {
		return object(CLAZZ)._getLabel(row, colName, true);
	}

	/**
	 * 電文の項目ラベルを返します。
	 * ラベルが取得できない場合はカラム名を返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @param isUp 上り電文の項目ラベルを取得する場合true
	 * @return ラベル
	 */
	public static String getLabel(MCRow row, String colName, boolean isUp) {
		return object(CLAZZ)._getLabel(row, colName, isUp);
	}
	
	/**
	 * 電文の項目ラベルをリストにして返します。
	 * ラベルが取得できない場合はカラム名を返します。
	 * 
	 * @param row ロウ
	 * @param colL カラム名のリスト
	 * @param isUp 上り電文のラベルを取得する場合は true
	 * @return ラベルのリスト
	 */
	public static List<String> getLabelList(MCRow row, List<String> colL, boolean isUp) {
		return object(CLAZZ)._getLabelList(row, colL, isUp);
	}

	/**
	 * 項目ラベルを返します。
	 * ラベルが取得できない場合はカラム名を返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @param isUp 上り電文の場合true
	 * @return ラベル
	 */
	protected String _getLabel(MCRow row, String colName, boolean isUp) {
		String lbl = MCLogicLabelUtil.getLabel(MCSys.user.locale(), row, colName, isUp);
		if (isNull(lbl)) {
			return colName;
		}
		return lbl;
	}
	
	/**
	 * 項目ラベルをリストにして返します。
	 * ラベルが取得できない場合はカラム名を返します。
	 * 
	 * @param row ロウ
	 * @param colL カラム名のリスト
	 * @param isUp 上り電文のラベルを取得する場合は true
	 * @return ラベルのリスト
	 */
	protected List<String> _getLabelList(MCRow row, List<String> colL, boolean isUp) {
		List<String> result = new ArrayList<>();

		List<String> labels = MCLogicLabelUtil.getLabelList(MCSys.user.locale(), row,
				colL, isUp);
		for (int i = 0; i < colL.size(); i++) {
			String label = labels.get(i);
			if (isNull(label)) {
				label = colL.get(i);
			}
			result.add(label);
		}
		return result;
	}

	/**
	 * 指定された項目のラベルを指定された区切り文字列で区切った文字列を返します。
	 *
	 * @param sep 区切り文字列
	 * @param row Row
	 * @param colName カラム名
	 * @return 文字列
	 */
	public static String getLabel(String sep, MCRow row, String... colName) {
		return object(CLAZZ)._getLabel(sep, row, colName);
	}

	/**
	 * 指定された項目のラベルを指定された区切り文字列で区切った文字列を返します。
	 *
	 * @param sep 区切り文字列
	 * @param row Row
	 * @param colName カラム名
	 * @return 文字列
	 */
	protected String _getLabel(String sep, MCRow row, String... colName) {
		String[] lbl = new String[colName.length];
		for (int i = 0; i < colName.length; i++) {
			lbl[i] = _getLabel(row, colName[i], true);
		}
		return MCStringUtil.join(sep, lbl);
	}

	/**
	 * 指定された項目のラベルを{@link #labelSeparator()}で区切った文字列を返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return 文字列
	 */
	public static String getLabel(MCRow row, String... colName) {
		return object(CLAZZ)._getLabel(row, colName);
	}

	/**
	 * 指定された項目のラベルを{@link #labelSeparator()}で区切った文字列を返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return 文字列
	 */
	protected String _getLabel(MCRow row, String... colName) {
		return _getLabel(labelSeparator(), row, colName);
	}

	/**
	 * テーブル名のラベルを返します。
	 * ラベルが取得できない場合はテーブル名を返します。
	 *
	 * @param dbc DBコンテナ
	 * @return ラベル
	 */
	public static String getTableLabel(MCDBContainer dbc) {
		return object(CLAZZ)._getTableLabel(dbc);
	}

	/**
	 * テーブル名のラベルを返します。
	 * ラベルが取得できない場合はテーブル名を返します。
	 *
	 * @param dbc DBコンテナ
	 * @return ラベル
	 */
	protected String _getTableLabel(MCDBContainer dbc) {
		String lbl = MCConst.dblbl.getLabel(dbc.tableName(), null, MCSys.user.locale());
		return isNull(lbl) ? dbc.tableName() : lbl;
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCList<? extends MCRow> list, String colName,
			IfValidater... validater) {
		return object(CLAZZ)._check(list, colName, validater);
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCList<? extends MCRow> list, String colName,
			IfValidater... validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(list, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCList<? extends MCRow> list, String colName,
			List<IfValidater> validater) {
		return object(CLAZZ)._check(list, colName, validater);
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCList<? extends MCRow> list, String colName,
			List<IfValidater> validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(list, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCRow row, String colName,
			IfValidater... validater) {
		return object(CLAZZ)._check(row, colName, validater);
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCRow row, String colName, IfValidater... validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(row, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCRow row, String colName,
			List<IfValidater> validater) {
		return object(CLAZZ)._check(row, colName, validater);
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCRow row, String colName,
			List<IfValidater> validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(row, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * カラム名を複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCList<? extends MCRow> list, String[] colName,
			IfValidater... validater) {
		return object(CLAZZ)._check(list, colName, validater);
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * カラム名を複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCList<? extends MCRow> list, String[] colName,
			IfValidater... validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(list, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * 複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCList<? extends MCRow> list, String[] colName,
			List<IfValidater> validater) {
		return object(CLAZZ)._check(list, colName, validater);
	}

	/**
	 * 指定されたListのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * 複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list List
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCList<? extends MCRow> list, String[] colName,
			List<IfValidater> validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(list, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * 複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCRow row, String[] colName,
			IfValidater... validater) {
		return object(CLAZZ)._check(row, colName, validater);
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * 複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCRow row, String[] colName,
			IfValidater... validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(row, colName));
		}
		return msgList;
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * 複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	public static MCMessageList check(MCRow row, String[] colName,
			List<IfValidater> validater) {
		return object(CLAZZ)._check(row, colName, validater);
	}

	/**
	 * 指定されたRowのカラムの値に対してチェック処理を実行します。
	 * 全てのチェック処理を実行し、チェック結果をメッセージリストにして返します。
	 * <p>
	 * 複数指定可能なチェック処理は以下の通りです。<br>
	 * <table border = 1>
	 * <tr><th>チェック処理</th><th>カラム名指定の注意点</th><th>カラム数の上限</th></tr>
	 * <tr><td>{@link FXUCL_DBValidater}</td><td>ＤＢ項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_ExistValidater}</td><td>チェック対象の項目名の個数と順番を合わせてください</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_BeforeAfterValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>3</td></tr>
	 * <tr><td>{@link FXUCL_BeforeTodayValidater}</td><td>日付が小さい順にカラム名を指定してください</td><td>2</td></tr>
	 * <tr><td>{@link FXUCL_SmallLargeValidater}</td><td>数値が小さい順にカラム名を指定してください</td><td>3(*1)</td></tr>
	 * <tr><td>{@link FXUCL_TooManyInputsValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_AtLeastOneValidater}</td><td>なし</td><td>なし</td></tr>
	 * <tr><td>{@link FXUCL_DuplicateValidater}</td><td>なし</td><td>なし</td></tr>
	 * </table>
	 * (*1) 最大値または最小値を指定した場合はカラム数の上限はその分少なくなります。両方指定した場合はカラム数の上限は1です。
	 *
	 * @param list Row
	 * @param colName カラム名
	 * @param validater チェック処理クラス
	 * @return メッセージリスト
	 */
	protected MCMessageList _check(MCRow row, String[] colName,
			List<IfValidater> validater) {
		MCMessageList msgList = new MCMessageList();
		for (IfValidater v : validater) {
			msgList.addAll(v.validate(row, colName));
		}
		return msgList;
	}

	// ----- 各種メッセージ START ---------------

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0023またはFXUCC0024
	 */
	public static MCMessage msgInvalidNumberPrecision(MCRow row, String colName) {
		return object(CLAZZ)._msgInvalidNumberPrecision(row, colName);
	}

	/**
	 * Number型がメタで定義された桁数（整数部の桁数、小数点以下の桁数）に違反している場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0023またはFXUCC0024
	 */
	protected MCMessage _msgInvalidNumberPrecision(MCRow row, String colName) {
		MCNumber v = row.getNumber(colName);
		MCMeta meta = row.getMeta(colName);
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgInvalidNumberPrecision(_getLabel(row, colName), row.getGUIIndex(),
					v, meta.length(), meta.scale());
		}
		else {
			msg = _msgInvalidNumberPrecision(_getLabel(row, colName), v, meta.length(),
					meta.scale());
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * String型がメタで定義された桁数に違反している場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0025またはFXUCC0026
	 */
	public static MCMessage msgTooLongString(MCRow row, String colName) {
		return object(CLAZZ)._msgTooLongString(row, colName);
	}

	/**
	 * String型がメタで定義された桁数に違反している場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0025またはFXUCC0026
	 */
	protected MCMessage _msgTooLongString(MCRow row, String colName) {
		MCMessage msg;
		String v = row.getString(colName);
		MCMeta meta = row.getMeta(colName);
		if (row.getGUIIndex() > -1) {
			msg = _msgTooLongString(_getLabel(row, colName), row.getGUIIndex(), v,
					v.length(), meta.length());
		}
		else {
			msg = _msgTooLongString(_getLabel(row, colName), v, v.length(),
					meta.length());
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * ０より大きい値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0027またはFXUCC0028
	 */
	public static MCMessage msgNotPositive(MCRow row, String colName) {
		return object(CLAZZ)._msgNotPositive(row, colName);
	}

	/**
	 * ０より大きい値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0027またはFXUCC0028
	 */
	protected MCMessage _msgNotPositive(MCRow row, String colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNotPositive(_getLabel(row, colName), row.getGUIIndex());
		}
		else {
			msg = _msgNotPositive(_getLabel(row, colName));
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * ０以外の値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0029またはFXUCC0030
	 */
	public static MCMessage msgZero(MCRow row, String colName) {
		return object(CLAZZ)._msgZero(row, colName);
	}

	/**
	 * ０以外の値を入れるべき所に０以下の値が入っていた場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0029またはFXUCC0030
	 */
	protected MCMessage _msgZero(MCRow row, String colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgZero(_getLabel(row, colName), row.getGUIIndex());
		}
		else {
			msg = _msgZero(_getLabel(row, colName));
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合のメッセージ
	 *
	 * @param row1 Row1
	 * @param row2 Row2
	 * @param colName カラム名
	 * @return FXUCC0031
	 */
	public static MCMessage msgDuplicate(MCRow row1, MCRow row2, String... colName) {
		return object(CLAZZ)._msgDuplicate(row1, row2, colName);
	}

	/**
	 * 指定されたカラムの値がすべて同値の行が複数ある場合のメッセージ
	 *
	 * @param row1 Row1
	 * @param row2 Row2
	 * @param colName カラム名
	 * @return FXUCC0031
	 */
	protected MCMessage _msgDuplicate(MCRow row1, MCRow row2, String... colName) {
		int idx1;
		int idx2;
		MCRow causeRow;
		if (row1.getGUIIndex() < row2.getGUIIndex()) {
			idx1 = row1.getGUIIndex();
			idx2 = row2.getGUIIndex();
			causeRow = row1;
		}
		else {
			idx1 = row2.getGUIIndex();
			idx2 = row1.getGUIIndex();
			causeRow = row2;
		}
		MCMessage msg = _msgDuplicate(_getLabel(causeRow, colName), idx1, idx2);
		msg.setCauseRow(causeRow, colName[0]);
		return msg;
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0032またはFXUCC0033
	 */
	public static MCMessage msgAtLeastOneInput(MCRow row, String... colName) {
		return object(CLAZZ)._msgAtLeastOneInput(row, colName);
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0032またはFXUCC0033
	 */
	protected MCMessage _msgAtLeastOneInput(MCRow row, String... colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgAtLeastOneInput(_getLabel(MCStringUtil.LF_CODE, row, colName),
					row.getGUIIndex());
		}
		else {
			msg = _msgAtLeastOneInput(_getLabel(MCStringUtil.LF_CODE, row, colName));
		}
		msg.setCauseRow(row, colName[0]);
		return msg;
	}

	/**
	 * チェック対象の日付が運用日付以前の場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNotAfterToday(MCRow row, String col1, boolean equals) {
		return object(CLAZZ)._msgNotAfterToday(row, col1, equals);
	}

	/**
	 * チェック対象の日付が運用日付以前の場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNotAfterToday(MCRow row, String col1, boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNotAfterToday(_getLabel(row, col1), toYMDString(row.getDate(col1)),
					toYMDString(getToday()), row.getGUIIndex(), equals);
		}
		else {
			msg = _msgNotAfterToday(_getLabel(row, col1), toYMDString(row.getDate(col1)),
					toYMDString(getToday()), equals);
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付の条件を満たさない場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNot2DtBeforeToday(MCRow row, String col1, String col2,
			boolean equals) {
		return object(CLAZZ)._msgNot2DtBeforeToday(row, col1, col2, equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ 運用日付の条件を満たさない場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNot2DtBeforeToday(MCRow row, String col1, String col2,
			boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNot2DtBeforeToday(_getLabel(row, col1), _getLabel(row, col2),
					toYMDString(row.getDate(col1)), toYMDString(row.getDate(col2)),
					toYMDString(getToday()), row.getGUIIndex(), equals);
		}
		else {
			msg = _msgNot2DtBeforeToday(_getLabel(row, col1), _getLabel(row, col2),
					toYMDString(row.getDate(col1)), toYMDString(row.getDate(col2)),
					toYMDString(getToday()), equals);
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * チェック対象の日付が運用日付以降の場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNotBeforeToday(MCRow row, String col1, boolean equals) {
		return object(CLAZZ)._msgNotBeforeToday(row, col1, equals);
	}

	/**
	 * チェック対象の日付が運用日付以降の場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNotBeforeToday(MCRow row, String col1, boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNotBeforeToday(_getLabel(row, col1), toYMDString(row.getDate(col1)),
					toYMDString(getToday()), row.getGUIIndex(), equals);
		}
		else {
			msg = _msgNotBeforeToday(_getLabel(row, col1), toYMDString(row.getDate(col1)),
					toYMDString(getToday()), equals);
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param col3
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNot3DtBeforeAfter(MCRow row, String col1, String col2,
			String col3, boolean equals) {
		return object(CLAZZ)._msgNot3DtBeforeAfter(row, col1, col2, col3, equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param col3
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNot3DtBeforeAfter(MCRow row, String col1, String col2,
			String col3, boolean equals) {
		return _msgNot3DtBeforeAfter(row, col1, row, col1, row, col2, row, col3, equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param causeRow メッセージのCauseRow
	 * @param causeCol メッセージのCauseColumn
	 * @param row1 dt1のRow
	 * @param col1 dt1のカラム名
	 * @param row2 dt2のRow
	 * @param col2 dt2のカラム名
	 * @param row3 dt3のRow
	 * @param col3 dt3のカラム名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNot3DtBeforeAfter(MCRow causeRow, String causeCol,
			MCRow row1, String col1, MCRow row2, String col2, MCRow row3, String col3,
			boolean equals) {
		return object(CLAZZ)._msgNot3DtBeforeAfter(causeRow, causeCol, row1, col1, row2,
				col2, row3, col3, equals);
	}

	/**
	 * dt1 ≦ dt2 ≦ dt3の条件を満たさない場合のメッセージ
	 *
	 * @param causeRow メッセージのCauseRow
	 * @param causeCol メッセージのCauseColumn
	 * @param row1 dt1のRow
	 * @param col1 dt1のカラム名
	 * @param row2 dt2のRow
	 * @param col2 dt2のカラム名
	 * @param row3 dt3のRow
	 * @param col3 dt3のカラム名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNot3DtBeforeAfter(MCRow causeRow, String causeCol,
			MCRow row1, String col1, MCRow row2, String col2, MCRow row3, String col3,
			boolean equals) {
		MCMessage msg;
		if (causeRow.getGUIIndex() > -1) {
			msg = _msgNot3DtBeforeAfter(_getLabel(row1, col1), _getLabel(row2, col2),
					_getLabel(row3, col3), toYMDString(row1.getDate(col1)),
					toYMDString(row2.getDate(col2)), toYMDString(row3.getDate(col3)),
					causeRow.getGUIIndex(), equals);
		}
		else {
			msg = _msgNot3DtBeforeAfter(_getLabel(row1, col1), _getLabel(row2, col2),
					_getLabel(row3, col3), toYMDString(row1.getDate(col1)),
					toYMDString(row2.getDate(col2)), toYMDString(row3.getDate(col3)),
					equals);
		}
		msg.setCauseRow(causeRow, causeCol);
		return msg;
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNotBefore(MCRow row, String col1, String col2,
			boolean equals) {
		return object(CLAZZ)._msgNotBefore(row, col1, col2, equals);
	}

	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNotBefore(MCRow row, String col1, String col2,
			boolean equals) {
		return _msgNotBefore(row, col1, row, col1, row, col2, equals);
	}
	
	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param causeRow メッセージのCauseRow
	 * @param causeCol メッセージのCauseColumn
	 * @param row1 dt1のRow
	 * @param col1 dt1のカラム名
	 * @param row2 dt2のRow
	 * @param col2 dt2のカラム名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 */
	public static MCMessage msgNotBefore(MCRow causeRow, String causeCol, MCRow row1,
			String col1, MCRow row2, String col2, boolean equals) {
		return object(CLAZZ)._msgNotBefore(causeRow, causeCol, row1, col1, row2, col2, equals);
	}
	
	/**
	 * 日付の大小関係が間違っている場合のメッセージ
	 *
	 * @param causeRow メッセージのCauseRow
	 * @param causeCol メッセージのCauseColumn
	 * @param row1 dt1のRow
	 * @param col1 dt1のカラム名
	 * @param row2 dt2のRow
	 * @param col2 dt2のカラム名
	 * @param equals 大小関係に同値を含む（≦）場合true
	 */
	protected MCMessage _msgNotBefore(MCRow causeRow, String causeCol, MCRow row1,
			String col1, MCRow row2, String col2, boolean equals) {
		MCMessage msg;
		if (causeRow.getGUIIndex() > -1) {
			msg = _msgNotBefore(_getLabel(row1, col1), _getLabel(row2, col2),
					causeRow.getGUIIndex(), equals);
		}
		else {
			msg = _msgNotBefore(_getLabel(row1, col1), _getLabel(row2, col2), equals);
		}
		msg.setCauseRow(causeRow, causeCol);
		return msg;
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0046またはFXUCC0047
	 */
	public static MCMessage msgNoDataAtReq(MCRow row, String colName) {
		return object(CLAZZ)._msgNoDataAtReq(row, colName);
	}

	/**
	 * 必須項目が未入力であった場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0046またはFXUCC0047
	 */
	protected MCMessage _msgNoDataAtReq(MCRow row, String colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNoDataAtReq(_getLabel(row, colName), row.getGUIIndex());
		}
		else {
			msg = _msgNoDataAtReq(_getLabel(row, colName));
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * 定数に値が存在しない場合のメッセージ
	 *
	 * @param row Row
	 * @param v 値
	 * @param colName カラム名
	 * @return FXUCL0012またはFXUCL0013
	 */
	public static MCMessage msgNotExistInConst(MCRow row, String colName) {
		return object(CLAZZ)._msgNotExistInConst(row, colName);
	}

	/**
	 * 定数に値が存在しない場合のメッセージ
	 *
	 * @param row Row
	 * @param v 値
	 * @param colName カラム名
	 * @return FXUCL0012またはFXUCL0013
	 */
	protected MCMessage _msgNotExistInConst(MCRow row, String colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(FXUCL0013, _getLabel(row, colName),
					row.getValueNE(colName), row.getGUIIndex() + 1);
		}
		else {
			msg = new MCMessage(FXUCL0012, _getLabel(row, colName),
					row.getValueNE(colName));
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * マスタに値が存在しない場合のメッセージ
	 *
	 * @param dbc DBコンテナ
	 * @param row Row
	 * @param v 値
	 * @param colName カラム名
	 * @return FXUCL0010またはFXUCL0011
	 */
	public static MCMessage msgNotExistInTable(MCDBContainer dbc, MCRow row,
			String... colName) {
		return object(CLAZZ)._msgNotExistInTable(dbc, row, colName);
	}

	/**
	 * マスタに値が存在しない場合のメッセージ
	 *
	 * @param dbc DBコンテナ
	 * @param row Row
	 * @param v 値
	 * @param colName カラム名
	 * @return FXUCL0010またはFXUCL0011
	 */
	protected MCMessage _msgNotExistInTable(MCDBContainer dbc, MCRow row,
			String... colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(FXUCL0011, _getTableLabel(dbc), row.getGUIIndex() + 1,
					toStringWithMsgLabel(row, colName));
		}
		else {
			msg = new MCMessage(FXUCL0010, _getTableLabel(dbc),
					_toStringWithMsgLabel(row, colName));
		}
		msg.setCauseRow(row, colName[0]);
		return msg;
	}

	/**
	 * リストに値が存在しない場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCL0018またはFXUCL0019
	 */
	public static MCMessage msgNotExistInList(MCRow row, String... colName) {
		return object(CLAZZ)._msgNotExistInList(row, colName);
	}

	/**
	 * リストに値が存在しない場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCL0018またはFXUCL0019
	 */
	protected MCMessage _msgNotExistInList(MCRow row, String... colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(FXUCL0019, row.getGUIIndex() + 1,
					_toStringWithMsgLabel(row, colName));
		}
		else {
			msg = new MCMessage(FXUCL0018, _toStringWithMsgLabel(row, colName));
		}
		msg.setCauseRow(row, colName[0]);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNotSmall(MCRow row, String col1, String col2,
			boolean equals) {
		return object(CLAZZ)._msgNotSmall(row, col1, col2, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNotSmall(MCRow row, String col1, String col2,
			boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNotSmall(_getLabel(row, col1), _getLabel(row, col2),
					row.getGUIIndex(), equals);
		}
		else {
			msg = _msgNotSmall(_getLabel(row, col1), _getLabel(row, col2), equals);
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param colName
	 * @param max 最大値
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNotSmall(MCRow row, String colName, MCNumber max,
			boolean equals) {
		return object(CLAZZ)._msgNotSmall(row, colName, max, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param colName
	 * @param max 最大値
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNotSmall(MCRow row, String colName, MCNumber max,
			boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNotSmall(_getLabel(row, colName), max.toSimpleString(),
					row.getGUIIndex(), equals);
		}
		else {
			msg = _msgNotSmall(_getLabel(row, colName), max.toSimpleString(), equals);
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param min 最小値
	 * @param colName
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNotLarge(MCRow row, MCNumber min, String colName,
			boolean equals) {
		return object(CLAZZ)._msgNotLarge(row, min, colName, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param min 最小値
	 * @param colName
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNotLarge(MCRow row, MCNumber min, String colName,
			boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgNotSmall(min.toSimpleString(), _getLabel(row, colName),
					row.getGUIIndex(), equals);
		}
		else {
			msg = _msgNotSmall(min.toSimpleString(), _getLabel(row, colName), equals);
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param col3
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCL0023またはFXUCL0024
	 */
	public static MCMessage msgNot3NumSmallLarge(MCRow row, String col1, String col2,
			String col3, boolean equals) {
		return object(CLAZZ)._msgNot3NumSmallLarge(row, col1, col2, col3, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param col3
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCL0023またはFXUCL0024
	 */
	protected MCMessage _msgNot3NumSmallLarge(MCRow row, String col1, String col2,
			String col3, boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(idNot3NumSmallLarge(true, equals), _getLabel(row, col1),
					_getLabel(row, col2), _getLabel(row, col3), row.getGUIIndex() + 1);
		}
		else {
			msg = new MCMessage(idNot3NumSmallLarge(false, equals), _getLabel(row, col1),
					_getLabel(row, col2), _getLabel(row, col3));
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージID
	 *
	 * @param index メッセージに行番号を含む場合true
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected String idNot3NumSmallLarge(boolean index, boolean equals) {
		return index ? equals ? FXUCL0024 : FXUCL0026 : equals ? FXUCL0023 : FXUCL0025;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param max 最大値
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNot3NumSmallLarge(MCRow row, String col1, String col2,
			MCNumber max, boolean equals) {
		return object(CLAZZ)._msgNot3NumSmallLarge(row, col1, col2, max, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param col1
	 * @param col2
	 * @param max 最大値
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNot3NumSmallLarge(MCRow row, String col1, String col2,
			MCNumber max, boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(idNot3NumSmallLarge(true, equals), _getLabel(row, col1),
					_getLabel(row, col2), max, row.getGUIIndex() + 1);
		}
		else {
			msg = new MCMessage(idNot3NumSmallLarge(false, equals), _getLabel(row, col1),
					_getLabel(row, col2), max);
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param min 最小値
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	public static MCMessage msgNot3NumSmallLarge(MCRow row, MCNumber min, String col1,
			String col2, boolean equals) {
		return object(CLAZZ)._msgNot3NumSmallLarge(row, min, col1, col2, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param min 最小値
	 * @param col1
	 * @param col2
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return メッセージ
	 */
	protected MCMessage _msgNot3NumSmallLarge(MCRow row, MCNumber min, String col1,
			String col2, boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(idNot3NumSmallLarge(true, equals), min,
					_getLabel(row, col1), _getLabel(row, col2), row.getGUIIndex() + 1);
		}
		else {
			msg = new MCMessage(idNot3NumSmallLarge(false, equals), min,
					_getLabel(row, col1), _getLabel(row, col2));
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param min 最小値
	 * @param col1
	 * @param max 最大値
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCL0023またはFXUCL0024
	 */
	public static MCMessage msgNot3NumSmallLarge(MCRow row, MCNumber min, String col1,
			MCNumber max, boolean equals) {
		return object(CLAZZ)._msgNot3NumSmallLarge(row, min, col1, max, equals);
	}

	/**
	 * 数値の大小関係が間違っている場合のメッセージ
	 *
	 * @param row Row
	 * @param min 最小値
	 * @param col1
	 * @param max 最大値
	 * @param equals 大小関係に同値を含む（≦）場合true
	 * @return FXUCL0023またはFXUCL0024
	 */
	protected MCMessage _msgNot3NumSmallLarge(MCRow row, MCNumber min, String col1,
			MCNumber max, boolean equals) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(idNot3NumSmallLarge(true, equals), min,
					_getLabel(row, col1), max, row.getGUIIndex() + 1);
		}
		else {
			msg = new MCMessage(idNot3NumSmallLarge(false, equals), min,
					_getLabel(row, col1), max);
		}
		msg.setCauseRow(row, col1);
		return msg;
	}

	/**
	 * 正規表現に合致しない場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @param name パターン名
	 * @return FXUCL0020またはFXUCL0021
	 */
	public static MCMessage msgNotMatch(MCRow row, String colName, String name) {
		return object(CLAZZ)._msgNotMatch(row, colName, name);
	}

	/**
	 * 正規表現に合致しない場合のメッセージ
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @param name パターン名
	 * @return FXUCL0020またはFXUCL0021
	 */
	protected MCMessage _msgNotMatch(MCRow row, String colName, String name) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = new MCMessage(FXUCL0021, row.getGUIIndex() + 1, _getLabel(row, colName),
					name);
		}
		else {
			msg = new MCMessage(FXUCL0020, _getLabel(row, colName), name);
		}
		msg.setCauseRow(row, colName);
		return msg;
	}

	/**
	 * 指定された項目のうち、値が入力されている項目が２個以上ある場合のメッセージを生成します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0050またはFXUCC0051
	 */
	public static MCMessage msgTooManyInputs(MCRow row, String... colName) {
		return object(CLAZZ)._msgTooManyInputs(row, colName);
	}

	/**
	 * 指定された項目のうち、値が入力されている項目が２個以上ある場合のメッセージを生成します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return FXUCC0050またはFXUCC0051
	 */
	protected MCMessage _msgTooManyInputs(MCRow row, String... colName) {
		MCMessage msg;
		if (row.getGUIIndex() > -1) {
			msg = _msgTooManyInputs(row, colName[0],
					_getLabel(MCStringUtil.LF_CODE, row, colName), row.getGUIIndex());
		}
		else {
			msg = _msgTooManyInputs(row, colName[0],
					_getLabel(MCStringUtil.LF_CODE, row, colName));
		}
		return msg;
	}

	/**
	 * 指定された項目から、機能制限パタンによってダウンロードが制限されている項目を除外した項目をリストにして返します。
	 * 
	 * @param moduleid モジュールＩＤ
	 * @param logicid ロジックＩＤ
	 * @param opeid オペレーションＩＤ
	 * @param colL 項目のリスト
	 * @return 機能制限パタンによってダウンロードが制限されている項目を除外した項目のリスト
	 */
	public static List<String> getDownloadItemList(String moduleid, String logicid,
			String opeid, List<String> colL) {
		return object(CLAZZ)._getDownloadItemList(moduleid, logicid, opeid, colL);
	}

	protected List<String> _getDownloadItemList(String moduleid, String logicid,
			String opeid, List<String> colL) {
		List<String> list = new ArrayList<>();

		colL.forEach(col -> {
			if (MCACLManager.createServerFuncPtnManager().authorize(moduleid, logicid,
					opeid, col)) {
				list.add(col);
			}
		});

		return list;
	}

	// ----- 各種メッセージ END ---------------
}
