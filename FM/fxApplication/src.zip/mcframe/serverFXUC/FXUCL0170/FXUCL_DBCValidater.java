package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCAppException;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;

/**
 * マスタの存在チェック用クラスです。
 * <p>
 * コンストラクタで指定されたＤＢコンテナを使用して検索を実行します。
 * その際、ＤＢコンテナに以下の検索条件が設定されます。<br>
 *    T.[コンストラクタで指定したＤＢ項目名] = :[チェック対象のカラム名]<br>
 * コンストラクタで指定されたＤＢコンテナにデータが格納されている場合は何もしません。
 */
@EI
public class FXUCL_DBCValidater<R extends MCDBContainer> extends
		FXUCL_DBCValidater_FW<R> {

	/**
	 * コンストラクタです。
	 * 引数に指定したクエリAPIビルダーを使用して検索を実行し、検索結果に合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * <p>
	 * 使用例：<br>
	 * MCQueryApiBuilder builder = MCQueryApiBuilder.create(FCM_SAMPLE_R.create("M"));<br>
	 * new FXUCL_DBCValidater(builder, FCM_SAMPLE_R.$id);
	 *
	 * @param builder クエリAPIビルダー
	 * @param dbColName チェック対象のＤＢ項目名。指定しない場合はＤＢコンテナのキー項目が使用される。
	 * @throws MCAppException [FXUCL0015] チェック対象のＤＢ項目名を指定していない且つＤＢコンテナにキー項目が設定されていない場合
	 */
	public FXUCL_DBCValidater(MCQueryApiBuilder builder, String... dbColName) {
		super(builder, dbColName);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したＤＢコンテナを使用して検索を実行し、検索結果に合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_DBCValidater(FCM_SAMPLE_R.create("M"), FCM_SAMPLE_R.$id);
	 *
	 * @param dbc ＤＢコンテナ
	 * @param dbColName チェック対象のＤＢ項目名。指定しない場合はＤＢコンテナのキー項目が使用される。
	 * @throws MCAppException [FXUCL0015] チェック対象のＤＢ項目名を指定していない且つＤＢコンテナにキー項目が設定されていない場合
	 */
	public FXUCL_DBCValidater(R dbc, String... dbColName) {
		super(dbc, dbColName);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したクエリAPIビルダーを使用して検索を実行し、検索結果に合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * MCQueryApiBuilder builder = MCQueryApiBuilder.create(FCM_SAMPLE_R.create("M"));<br>
	 * new FXUCL_DBValidater(r -> r.getBoolean("check"), builder, FCM_SAMPLE_R.$id);
	 *
	 * @param filter フィルタ
	 * @param builder クエリAPIビルダー
	 * @param dbColName チェック対象のＤＢ項目名。指定しない場合はＤＢコンテナのキー項目が使用される。
	 * @throws MCAppException [FXUCL0015] チェック対象のＤＢ項目名を指定していない且つＤＢコンテナにキー項目が設定されていない場合
	 */
	public FXUCL_DBCValidater(Predicate<MCRow> filter, MCQueryApiBuilder builder, String... dbColName) {
		super(filter, builder, dbColName);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したＤＢコンテナを使用して検索を実行し、検索結果に合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_DBCValidater(r -> r.getBoolean("check"), FCM_SAMPLE_R.create("M"), FCM_SAMPLE_R.$id);
	 *
	 * @param filter フィルタ
	 * @param dbc ＤＢコンテナ
	 * @param dbColName チェック対象のＤＢ項目名。指定しない場合はＤＢコンテナのキー項目が使用される。
	 * @throws MCAppException [FXUCL0015] チェック対象のＤＢ項目名を指定していない且つＤＢコンテナにキー項目が設定されていない場合
	 */
	public FXUCL_DBCValidater(Predicate<MCRow> filter, R dbc, String... dbColName) {
		super(filter, dbc, dbColName);
	}
}
