package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0160.FXUCL_DateUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;

/**
 * 運用日付と日付の前後チェック用クラスです。
 */
public abstract class FXUCL_AfterTodayValidater_FW extends FXUCL_BeforeAfterValidater {

	public FXUCL_AfterTodayValidater_FW() {
		super();
	}

	public FXUCL_AfterTodayValidater_FW(boolean equals) {
		super(equals);
	}

	public FXUCL_AfterTodayValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	public FXUCL_AfterTodayValidater_FW(Predicate<MCRow> filter, boolean equals) {
		super(filter, equals);
	}

	@Override
	protected int getColMax() {
		return 1;
	}

	@Override
	protected int getColMin() {
		return 1;
	}

	@Override
	protected boolean isBeforeAfter(Comparable<?>[] vals) {
		// チェック対象の値の配列の先頭に運用日付を追加
		Comparable<?>[] newVals = new Comparable<?>[vals.length + 1];
		newVals[0] = getToday();
		for (int i = 0; i < vals.length; i++) {
			newVals[i + 1] = vals[i];
		}
		return super.isBeforeAfter(newVals);
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		if (colName.length == 1) {
			return FXUCL_ValidaterUtil.msgNotAfterToday(row, colName[0], equals);
		}
		return null;
	}
}
