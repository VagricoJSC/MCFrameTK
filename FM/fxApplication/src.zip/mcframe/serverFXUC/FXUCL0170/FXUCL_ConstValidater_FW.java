package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.constant.MCRootConst;
import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;

/**
 * 定数の存在チェック用クラスです。
 */
public class FXUCL_ConstValidater_FW extends FXUCL_Validater {

	/**
	 * 定数
	 */
	private MCRootConst[] cnst;

	/**
	 * コンストラクタです。
	 *
	 * @param cnst 定数
	 */
	public FXUCL_ConstValidater_FW(MCRootConst... cnst) {
		super();
		this.cnst = cnst;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 * @param cnst 定数
	 */
	public FXUCL_ConstValidater_FW(Predicate<MCRow> filter, MCRootConst... cnst) {
		super(filter);
		this.cnst = cnst;
	}

	@Override
	protected boolean init(MCContainer con, String... colName) {
		return super.init(con, colName) && cnst != null;
	}

	@Override
	protected int getColMax() {
		return 1;
	}

	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return createSkipNullFilter(colName);
	}

	/**
	 * 定数に値が存在しない場合にtrueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return 値が存在しない場合にtrue
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		Comparable<?> v = row.getValue(colName[0]);
		for (MCRootConst c : cnst) {
			if (c != null) {
				if (isSame(v, c.value())) {
					return false;
				}
			}
		}
		return true;
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgNotExistInConst(row, colName[0]);
	}
}
