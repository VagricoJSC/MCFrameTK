package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCNumber;

/**
 * 数値の大小チェック用クラスです。
 * <p>
 * 指定された１つ目の数値≦２つ目の数値　ではない場合にメッセージを返します。<br>
 * チェック対象の数値は３つまで指定できます。
 * １つ目の数値≦２つ目の数値≦３つ目の数値　ではない場合にメッセージを返します。<br>
 * 最小値または最大値を固定値で指定することができます。
 * 最小値≦指定された数値≦最大値　ではない場合にメッセージを返します。<br>
 * 大小比較で同値を許容しない場合（数値＜数値のチェックをしたい場合）は引数にbooleanをもつコンストラクタを使用してください。
 */
@EI
public class FXUCL_SmallLargeValidater extends FXUCL_SmallLargeValidater_FW {

	public FXUCL_SmallLargeValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_SmallLargeValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_SmallLargeValidater(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param min 最小値。nullを指定した場合は最小値はチェックされない
	 * @param max 最大値。nullを指定した場合は最大値はチェックされない
	 */
	public FXUCL_SmallLargeValidater(MCNumber min, MCNumber max) {
		super(min, max);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_SmallLargeValidater(r -> r.getBoolean("check"), MCNumber.ONE, MCNumber.TEN)
	 *
	 * @param filter フィルタ
	 * @param min 最小値。nullを指定した場合は最小値はチェックされない
	 * @param max 最大値。nullを指定した場合は最大値はチェックされない
	 */
	public FXUCL_SmallLargeValidater(Predicate<MCRow> filter, MCNumber min, MCNumber max) {
		super(filter, min, max);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_SmallLargeValidater(boolean equals) {
		super(equals);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param min 最小値。nullを指定した場合は最小値はチェックされない
	 * @param max 最大値。nullを指定した場合は最大値はチェックされない
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_SmallLargeValidater(MCNumber min, MCNumber max, boolean equals) {
		super(min, max, equals);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_SmallLargeValidater(r -> r.getBoolean("check"), false)
	 *
	 * @param filter フィルタ
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_SmallLargeValidater(Predicate<MCRow> filter, boolean equals) {
		super(filter, equals);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_SmallLargeValidater(r -> r.getBoolean("check"), MCNumber.ONE, MCNumber.TEN, false)
	 *
	 * @param filter フィルタ
	 * @param min 最小値。nullを指定した場合は最小値はチェックされない
	 * @param max 最大値。nullを指定した場合は最大値はチェックされない
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_SmallLargeValidater(Predicate<MCRow> filter, MCNumber min, MCNumber max,
			boolean equals) {
		super(filter, min, max, equals);
	}
}
