package mcframe.serverFXUC.FXUCL0170;

import static mcframe.commonCore.notice.Core_Msg.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

/**
 * メタ情報の桁チェック用クラスです。
 */
public abstract class FXUCL_ScaleAndLengthValidater_FW extends FXUCL_Validater {

	public FXUCL_ScaleAndLengthValidater_FW() {
		super();
	}

	public FXUCL_ScaleAndLengthValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	@Override
	protected void validateSub(MCMessageList msgList, MCRow row, String... colName) {
		MCMessageList vL = row.validate(colName);
		for (MCMessage msg : vL) {
			String c = msg.getCauseColumn();
			if (FCBBC0063.equals(msg.getID())) {
				// FCBBC0063
				// String型が文字数に違反している場合
				// サーバ側は複数値の考慮はしない
				msgList.add(getMessage(row, c));
			}
			else if (FCBBC0064.equals(msg.getID())) {
				// FCBBC0064
				// Number型が桁数に違反している場合
				msgList.add(getMessage(row, c));
			}
			else if (FCBBC0062.equals(msg.getID())) {
				// FCBBC0062
				// カラムがRowにない場合
				// メモ：実装エラーなので例外とする
				throw new MCAppException(msg);
			}
			else {
				// FCBBC0065
				// 負値を許容しないNumber型が負値の場合
				// 他
				// メモ：その他の例外はチェック対象外なので無視
			}
		}
	}

	/**
	 * 桁チェックではこのメソッドは実行されません。
	 * @see #validateSub(MCMessageList, MCRow, String...)
	 */
	@Override
	@Deprecated
	protected boolean isInvalid(MCRow row, String... colName) {
		return false;
	}

	/**
	 * 最大文字数より多い文字を設定された場合のメッセージを返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return メッセージ
	 */
	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		switch (row.getDataType(colName[0])) {
			case STRING:
				return FXUCL_ValidaterUtil.msgTooLongString(row, colName[0]);
			case NUMBER:
				return FXUCL_ValidaterUtil.msgInvalidNumberPrecision(row, colName[0]);
			default:
				return null;
		}
	}
}
