package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.constant.MCRootConst;
import mcframe.commonCore.container.MCRow;

/**
 * 定数の存在チェック用クラスです。
 * <p>
 * 定数に値が存在しない場合にメッセージを返します。
 */
@EI
public class FXUCL_ConstValidater extends FXUCL_ConstValidater_FW {

	/**
	 * コンストラクタです。
	 * 引数に指定した定数クラスの値に合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_ConstValidater(r -> r.getBoolean("check"), FSC_SAMPLE_TYP.values())
	 *
	 * @param filter フィルタ
	 * @param consts 定数クラスの配列
	 */
	public FXUCL_ConstValidater(Predicate<MCRow> filter, MCRootConst... cnst) {
		super(filter, cnst);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定した定数クラスの値に合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_ConstValidater(FSC_SAMPLE_TYP.values())
	 *
	 * @param consts 定数クラスの配列
	 */
	public FXUCL_ConstValidater(MCRootConst... cnst) {
		super(cnst);
	}

}
