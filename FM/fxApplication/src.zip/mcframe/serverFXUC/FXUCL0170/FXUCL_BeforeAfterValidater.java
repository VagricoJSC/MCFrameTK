package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 日付の前後チェック用クラスです。
 * <p>
 * 指定された１つ目の日付≦２つ目の日付　ではない場合にメッセージを返します。<br>
 * チェック対象の日付は３つまで指定できます。
 * １つ目の日付≦２つ目の日付≦３つ目の日付　ではない場合にメッセージを返します。<br>
 * 大小比較で同値を許容しない場合（日付＜日付のチェックをしたい場合）は引数にbooleanをもつコンストラクタを使用してください。
 */
@EI
public class FXUCL_BeforeAfterValidater extends FXUCL_BeforeAfterValidater_FW {

	public FXUCL_BeforeAfterValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_BeforeAfterValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_BeforeAfterValidater(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * コンストラクタです。
	 *
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_BeforeAfterValidater(boolean equals) {
		super(equals);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_BeforeAfterValidater(r -> r.getBoolean("check"), false)
	 *
	 * @param filter フィルタ
	 * @param equals 同値を許容しない場合はfalseを設定する（デフォルトtrue）
	 */
	public FXUCL_BeforeAfterValidater(Predicate<MCRow> filter, boolean equals) {
		super(filter, equals);
	}
}
