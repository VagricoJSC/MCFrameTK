package mcframe.serverFXUC.FXUCL0170;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessageList;

/**
 * 項目チェック用のインターフェースです。
 */
public interface IfValidater {

	/**
	 * Rowに対して項目チェックを行います。
	 * チェック結果をメッセージリストにして返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return メッセージリスト
	 */
	public MCMessageList validate(MCRow row, String... colName);

	/**
	 * Listに対して項目チェックを行います。
	 * チェック結果をメッセージリストにして返します。
	 *
	 * @param list チェック対象のList
	 * @param colName チェック対象のカラム名
	 * @return メッセージリスト
	 */
	public MCMessageList validate(MCList<? extends MCRow> list, String... colName);
}
