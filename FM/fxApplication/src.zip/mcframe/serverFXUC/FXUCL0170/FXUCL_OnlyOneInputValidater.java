package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

/**
 * 指定された項目が全て未入力または複数入力されている場合にメッセージを返すチェック用クラスです。
 * <p>
 * 指定された項目の型がBoolean型の場合、trueの場合に入力されているとみなします。
 * その他の型は{@link mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil#isNull(Comparable)}に依存します。
 */
@EI
public class FXUCL_OnlyOneInputValidater extends FXUCL_OnlyOneInputValidater_FW {

	public FXUCL_OnlyOneInputValidater() {
		super();
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_AtLeastOneValidater(r -> r.getBoolean("check"))
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_OnlyOneInputValidater(Predicate<MCRow> filter) {
		super(filter);
	}

}
