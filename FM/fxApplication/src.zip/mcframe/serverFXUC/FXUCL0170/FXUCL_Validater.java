package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCRow;

@EI
public abstract class FXUCL_Validater extends FXUCL_Validater_FW {

	public FXUCL_Validater() {
		super();
	}

	public FXUCL_Validater(Predicate<MCRow> filter) {
		super(filter);
	}

}
