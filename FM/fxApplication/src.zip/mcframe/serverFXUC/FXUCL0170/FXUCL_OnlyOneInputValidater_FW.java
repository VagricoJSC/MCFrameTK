package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;

/**
 * 指定された項目が全て未入力または複数入力されている場合にメッセージを返すチェック用クラスです。
 */
public abstract class FXUCL_OnlyOneInputValidater_FW extends FXUCL_Validater {

	public FXUCL_OnlyOneInputValidater_FW() {
		super();
	}

	public FXUCL_OnlyOneInputValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	@Override
	protected void validateSub(MCMessageList msgList, MCRow row, String... colName) {
		int input = getInputCount(row, colName);
		switch (input) {
			case 0:
				msgList.add(getAtLeastOneInputMessage(row, colName));
				break;
			case 1:
				break;
			default:
				msgList.add(getTooManyInputsMessage(row, colName));
				break;
		}
	}

	/**
	 * 入力されている項目の数を返します。
	 *
	 * @param row チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @return 入力されている項目の数
	 */
	protected int getInputCount(MCRow row, String... colName) {
		int ret = 0;
		for (String col : colName) {
			if (isInput(row.getValueNE(col))) {
				ret++;
			}
		}
		return ret;
	}

	/**
	 * 指定された項目が全て未入力の場合のメッセージを返します。
	 *
	 * @param row チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @return メッセージ
	 */
	protected MCMessage getAtLeastOneInputMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgAtLeastOneInput(row, colName);
	}

	/**
	 * 指定された項目のうち、値が入力されている項目が２個以上ある場合のメッセージを返します。
	 *
	 * @param row チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @return メッセージ
	 */
	protected MCMessage getTooManyInputsMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgTooManyInputs(row, colName);
	}

	@Override
	@Deprecated
	protected boolean isInvalid(MCRow row, String... colName) {
		// この機能では実行されない
		return false;
	}

	@Override
	@Deprecated
	protected MCMessage getMessage(MCRow row, String... colName) {
		// この機能では実行されない
		return null;
	}
}
