package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;
import java.util.stream.Stream;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCStringUtil;
import mcframe.commonCore.notice.MCAppException;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonCore.resource.MCLocaleConst;
import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.serverCore.resource.MCConst;
import mcframe.serverCore.sys.MCSys;
import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

/**
 * 項目チェック用の親クラスです。
 */
public abstract class FXUCL_Validater_FW implements IfValidater {

	/**
	 * チェック対象のコンテナを絞り込むためのフィルタ
	 */
	private Predicate<MCRow> cutomFilter;

	/**
	 * コンストラクタです。
	 */
	public FXUCL_Validater_FW() {
		super();
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 */
	public FXUCL_Validater_FW(Predicate<MCRow> filter) {
		super();
		this.cutomFilter = filter;
	}

	/**
	 * Rowに対して項目チェックを行います。
	 * チェック結果をメッセージリストにして返します。
	 * <p>
	 * コンストラクタでフィルタが設定された場合には、フィルタリングされたコンテナに対してチェックを行います。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return メッセージリスト
	 */
	@Override
	public MCMessageList validate(MCRow row, String... colName) {
		MCMessageList msgList = new MCMessageList();
		if (!init(row, colName)) {
			return msgList;
		}
		Predicate<MCRow> defFilter = createDefaultFilter(colName);
		// チェック処理固有のフィルタでフィルタリング
		if (defFilter == null || defFilter.test(row)) {
			// アプリ指定のフィルタでフィルタリング
			if (cutomFilter == null || cutomFilter.test(row)) {
				validateSub(msgList, row, colName);
			}
		}
		return msgList;
	}

	/**
	 * Listに対して単項目チェックを行います。
	 * チェック結果をメッセージリストにして返します。
	 * <p>
	 * コンストラクタでフィルタが設定された場合には、フィルタリングされたコンテナに対してチェックを行います。
	 *
	 * @param list チェック対象のList
	 * @param colName チェック対象のカラム名
	 * @return メッセージリスト
	 */
	@Override
	public MCMessageList validate(MCList<? extends MCRow> list, String... colName) {
		MCMessageList msgList = new MCMessageList();
		if (!init(list, colName)) {
			return msgList;
		}
		Stream<? extends MCRow> stream = createStream(list, colName);
		stream.forEachOrdered(r -> validateSub(msgList, r, colName));
		return msgList;
	}

	/**
	 * リストのストリームを生成します。
	 *
	 * @param list チェック対象のList
	 * @param colName チェック対象のカラム名
	 * @return ストリーム
	 */
	protected Stream<? extends MCRow> createStream(MCList<? extends MCRow> list,
			String... colName) {
		Stream<? extends MCRow> stream = list.stream();
		Predicate<MCRow> defFilter = createDefaultFilter(colName);
		if (defFilter != null) {
			// チェック処理固有のフィルタでフィルタリング
			stream = stream.filter(defFilter);
		}
		if (cutomFilter != null) {
			// アプリ指定のフィルタでフィルタリング
			stream = stream.filter(cutomFilter);
		}
		return stream;
	}

	/**
	 * チェック処理の初期化メソッドです。
	 * チェック処理が実行される前に呼び出されます。
	 *
	 * @param con コンテナ
	 * @param colName チェック対象のカラム名
	 * @return チェック処理を継続する場合true
	 * @throws [FXUCL0022] カラム数が上限を超えている場合
	 * @see #validate(MCRow, String)
	 * @see #validate(MCList, String)
	 */
	protected boolean init(MCContainer con, String... colName) {
		if (colName != null && colName.length >= getColMin()) {
			checkColCount(colName);
			return true;
		}
		return false;
	}

	/**
	 * チェック対象の項目数が上限を超えている場合エラーをスローします。
	 *
	 * @param colName チェック対象のカラム名
	 * @throws FXUCL0022
	 */
	protected void checkColCount(String... colName) {
		if (getColMax() != -1 && colName.length > getColMax()) {
			throw new MCAppException(FXUCL0022, colName.length, getColMax());
		}
	}

	/**
	 * チェック対象のカラム数の上限を返します。
	 * デフォルトでは-1を返します。
	 * カラム数に上限を設定したい場合にはこのメソッドをオーバライドしてください。
	 *
	 * @return 上限
	 */
	protected int getColMax() {
		return -1;
	}

	/**
	 * チェック対象のカラム数の最小値を返します。
	 * デフォルトでは1を返します。
	 * カラム数の最小値を変更したい場合にはこのメソッドをオーバライドしてください。
	 *
	 * @return 最小値
	 */
	protected int getColMin() {
		return -1;
	}

	/**
	 * チェック対象の項目の型をチェックします。
	 *
	 * @param type データ型
	 * @param row チェック対象のコンテナ
	 * @param colName チェック対象のカラム名
	 * @throws [FXUCC0001] 予期しないデータ型の場合
	 */
	protected void checkDataType(MCDataType type, MCRow row, String... colName) {
		for (String col : colName) {
			if (row.getDataType(col) != type) {
				Comparable<?> v = row.getValueNE(col);
				String t = v == null ? row.getDataType(col).toString() : v.getClass()
						.getSimpleName();
				throw new MCAppException(FXUCC0001, t);
			}
		}
	}

	/**
	 * チェック処理固有のフィルタを生成します。
	 * デフォルトではnullを返します。
	 *
	 * @param colName チェック対象のカラム名
	 * @return フィルタ
	 */
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return null;
	}

	/**
	 * チェック対象の値が全てnullまたは空文字の場合はチェック処理を実行しないフィルタを返します。
	 *
	 * @param colName チェック対象のカラム名
	 * @return フィルタ
	 */
	protected Predicate<MCRow> createSkipNullFilter(String... colName) {
		return r -> {
			for (String col : colName) {
				if (!isNull(r.getValueNE(col))) {
					return true;
				}
			}
			return false;
		};
	}

	/**
	 * チェック対象の値が１つでもnullまたは空文字の場合はチェック処理を実行しないフィルタを返します。
	 *
	 * @param colName チェック対象のカラム名
	 * @return フィルタ
	 */
	protected Predicate<MCRow> createSkipNullAtLeastOneFilter(String... colName) {
		return r -> {
			for (String col : colName) {
				if (isNull(r.getValueNE(col))) {
					return false;
				}
			}
			return true;
		};
	}

	/**
	 * チェック処理を実行します。
	 * フィルタリングされたコンテナに対してはこのメソッドは実行されません。
	 * <p>
	 * デフォルトの処理：<br>
	 * {@link #isInvalid(MCRow, String...)}の戻り値がtrueの場合に
	 * {@link #getMessage(MCRow, String...)}で取得したメッセージをメッセージリストに追加します。
	 *
	 * @param msgList メッセージリスト
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @see #validate(MCRow, String)
	 * @see #validate(MCList, String)
	 */
	protected void validateSub(MCMessageList msgList, MCRow row, String... colName) {
		if (isInvalid(row, colName)) {
			msgList.add(getMessage(row, colName));
		}
	}

	/**
	 * チェック対象の値が不正な場合にtrueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return チェック対象の値が不正な場合true
	 */
	abstract protected boolean isInvalid(MCRow row, String... colName);

	/**
	 * チェック処理のメッセージを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return メッセージ
	 */
	abstract protected MCMessage getMessage(MCRow row, String... colName);

	/**
	 * 値が入力されている場合trueを返します。
	 * <p>
	 * 値がBoolean型の場合、trueの場合に入力されているとみなします。
	 * その他の型は{@link mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil#isNull(Comparable)}に依存します。
	 *
	 * @param v 値
	 * @return 入力されている場合true
	 */
	protected boolean isInput(Comparable<?> v) {
		if (v == null) {
			return false;
		}
		else if (v instanceof Boolean) {
			return (Boolean) v;
		}
		return !isNull(v);
	}
}
