package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;

/**
 * リストの存在チェック用クラスです。
 * <p>
 * チェック対象の値がリストに存在しない場合にメッセージを返します。
 */
@EI
public class FXUCL_ExistValidater<R extends MCRow, L extends MCList<R>> extends
		FXUCL_ExistValidater_FW<R, L> {

	/**
	 * コンストラクタです。
	 * 引数に指定したリストに合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_ExistValidater(FSUAL_List.getSample(row), SampleCols.$o_id);
	 *
	 * @param list リスト
	 * @param listColName チェック対象の項目名
	 */
	public FXUCL_ExistValidater(L list, String... colName) {
		super(list, colName);
	}

	/**
	 * コンストラクタです。
	 * 引数に指定したリストに合致するものがない場合にエラーとみなします。
	 * チェック対象の値がnullまたは空文字の場合は何もしません。
	 * 引数に指定したフィルタに合致する場合にチェック処理が実行されます。
	 * <p>
	 * 使用例：<br>
	 * new FXUCL_ExistValidater(r -> r.getBoolean("check"), FSUAL_List.getSample(row), SampleCols.$o_id);
	 *
	 * @param filter フィルタ
	 * @param list リスト
	 * @param listColName チェック対象の項目名
	 */
	public FXUCL_ExistValidater(Predicate<MCRow> filter, L list, String... colName) {
		super(filter, list, colName);
	}
}
