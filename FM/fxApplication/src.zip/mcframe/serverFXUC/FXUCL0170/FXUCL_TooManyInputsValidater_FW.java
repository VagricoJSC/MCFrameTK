package mcframe.serverFXUC.FXUCL0170;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;

/**
 * 指定された項目のうち、値が入力されている項目が２個以上ある場合にメッセージを返すチェック用クラスです。
 */
public abstract class FXUCL_TooManyInputsValidater_FW extends FXUCL_Validater {

	public FXUCL_TooManyInputsValidater_FW() {
		super();
	}

	public FXUCL_TooManyInputsValidater_FW(Predicate<MCRow> filter) {
		super(filter);
	}

	/**
	 * 指定された項目のうち、値が入力されている項目が２個以上ある場合にtrueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return 値が入力されている項目が２個以上ある場合true
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		int cnt = 0;
		for (String col : colName) {
			if (isInput(row.getValueNE(col))) {
				if (cnt > 0) {
					return true;
				}
				cnt++;
			}
		}
		return false;
	}

	/**
	 * 指定された項目のうち、値が入力されている項目が２個以上ある場合のメッセージを返します。
	 *
	 * @param row Row
	 * @param colName カラム名
	 * @return メッセージ
	 */
	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgTooManyInputs(row, colName);
	}
}
