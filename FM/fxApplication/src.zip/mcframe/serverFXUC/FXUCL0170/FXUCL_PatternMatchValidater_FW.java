package mcframe.serverFXUC.FXUCL0170;

import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

import java.util.function.Predicate;

import mcframe.commonCore.container.MCContainer;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.notice.MCMessage;

/**
 * 正規表現による文字列チェック用クラスです。
 */
public class FXUCL_PatternMatchValidater_FW extends FXUCL_Validater {

	/**
	 * 正規表現
	 */
	private String regex;

	/**
	 * パターン名
	 */
	private String name;

	/**
	 * コンストラクタです。
	 *
	 * @param regex 正規表現
	 * @param name パターン名
	 */
	public FXUCL_PatternMatchValidater_FW(String regex, String name) {
		super();
		this.regex = regex;
		this.name = name;
	}

	/**
	 * コンストラクタです。
	 *
	 * @param filter フィルタ
	 * @param regex 正規表現
	 * @param name パターン名
	 */
	public FXUCL_PatternMatchValidater_FW(Predicate<MCRow> filter, String regex,
			String name) {
		super(filter);
		this.regex = regex;
		this.name = name;
	}

	@Override
	protected boolean init(MCContainer con, String... colName) {
		return super.init(con, colName) && !isNull(regex);
	}

	@Override
	protected int getColMax() {
		return 1;
	}

	@Override
	protected Predicate<MCRow> createDefaultFilter(String... colName) {
		return createSkipNullFilter(colName);
	}

	/**
	 * 正規表現に合致しない場合にtrueを返します。
	 *
	 * @param row チェック対象のRow
	 * @param colName チェック対象のカラム名
	 * @return 正規表現に合致しない場合にtrue
	 * @see mcframe.serverFXUC.FXUCL0170.FXUCL_Validater_FW#isInvalid(mcframe.commonCore.container.MCRow, java.lang.String[])
	 */
	@Override
	protected boolean isInvalid(MCRow row, String... colName) {
		checkDataType(MCDataType.STRING, row, colName);
		return !row.getString(colName[0]).matches(regex);
	}

	@Override
	protected MCMessage getMessage(MCRow row, String... colName) {
		return FXUCL_ValidaterUtil.msgNotMatch(row, colName[0], name);
	}
}
