package mcframe.serverFXUC.FXUCL0020;

public class FXUCL_MCDbUtil extends FXUCL_MCDbUtil_FW {

}