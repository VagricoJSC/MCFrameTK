package mcframe.serverFXUC.FXUCL0020;

import mcframe.commonCore.lang.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import mcframe.serverCore.queryapi.MCQueryExecution.*;

import static mcframe.serverCore.queryapi.IFMCSQL.*;

import mcframe.serverCore.database.MCSQLClause;
import mcframe.serverCore.logic.MCOperation;
import mcframe.serverCore.mcjdbc.*;
import mcframe.serverCore.notice.MCMessagePool;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.util.MCCollectionUtil;

import static mcframe.serverCore.database.MCSQLClause.UPD_CNTR_NAME;
import mcframe.serverCore.queryapi.IFMCFMSQL.MCFMAGExpr;
import mcframe.serverCore.queryapi.IFMCSQL.MCColumn;
import mcframe.serverCore.util.MCDBUtil;

import static mcframe.serverCore.requester.MCRequestObject.*;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

abstract public class FXUCL_MCDbUtil_FW extends MCDBUtil {
	//FMCB CUSTOM START
	// スレッドセーフ対応（ここから）
	/**
	 * このクラス（スレッドセーフ対応用）
	 */
	protected static final Class<FXUCL_MCDbUtil> CLAZZ = FXUCL_MCDbUtil.class;

	// スレッドセーフ対応（ここまで）

	// ユーティリティ(START) ====================================
	/**
	 * 引数が一つでもnullだったらfalse
	 */
	private static boolean isNoNull(Object... objects) {
		boolean ans = true;
		for (Object obj : objects) {
			if (obj == null) {
				return false;
			}
		}
		return ans;
	}

	/**
	 * 引数がnullの場合は「null」という文字列を返す。それ以外は「not null」という文字列を返す。<br>
	 * 例外処理のバインド値で使うことを想定
	 */
	private static String nullNotNull(Object obj) {
		return obj == null ? "null" : "not null";
	}

	protected static String sqlID(String... ids) {
		return String.join("_", ids);
	}

	/**
	 * SQL_IDを作成します。
	 * @param prefix 接頭辞
	 * @param tbl テーブル名
	 * @param crud CRUD文字列（Insert / Select / Update / Deleteの頭文字）+連番
	 * @return SQL_ID {ロジックID}_{テーブル名}_{CRUD文字列+連番}
	 */
	public static String createSqlId(String prefix, String tbl, String crud) {
		return FXUCL_MCDbUtil.sqlID(prefix, tbl, crud);
	}

	/**
	 * SQL_IDを作成します。
	 * @param prefix 接頭辞
	 * @param tbl DBコンテナ
	 * @param crud CRUD文字列（Insert / Select / Update / Deleteの頭文字）+連番
	 * @return SQL_ID {ロジックID}_{テーブル名}_{CRUD文字列+連番}
	 */
	public static String createSqlId(String prefix, MCDBContainer tbl, String crud) {
		return FXUCL_MCDbUtil.sqlID(prefix, tbl.tableName(), crud);
	}

	/**
	 * SQL_IDを作成します。
	 * @param ope オペレーション
	 * @param tbl テーブル名
	 * @param crud CRUD文字列（Insert / Select / Update / Deleteの頭文字）+連番
	 * @return SQL_ID {ロジックID}_{テーブル名}_{CRUD文字列+連番}
	 */
	public static String createSqlId(MCOperation ope, String tbl, String crud) {
		return FXUCL_MCDbUtil.sqlID(ope.getOperationInfo().logicId, tbl, crud);
	}

	/**
	 * SQL_IDを作成します。
	 * @param ope オペレーション
	 * @param tbl DBコンテナ
	 * @param crud CRUD文字列（Insert / Select / Update / Deleteの頭文字）+連番
	 * @return SQL_ID {ロジックID}_{テーブル名}_{CRUD文字列+連番}
	 */
	public static String createSqlId(MCOperation ope, MCDBContainer tbl, String crud) {
		return FXUCL_MCDbUtil.sqlID(ope.getOperationInfo().logicId, tbl.tableName(),
				crud);
	}

	// ユーティリティ(END) ====================================
	// メッセージ(START)
	/**
	 * ＤＢ上の排他対象の行が他の処理によって更新されているために、 排他チェックエラーにするときのメッセージ<BR>
	 * （「更新対象が、他の処理によって更新されています。再検索してください。 」）
	 */
	public static MCMessage msgExclusionErrUpd(MCRow causeRow) {
		return object(CLAZZ)._msgExclusionErrUpd(causeRow);
	}

	/**
	 * ＤＢ上の排他対象の行が他の処理によって更新されているために、 排他チェックエラーにするときのメッセージ<BR>
	 * （「更新対象が、他の処理によって更新されています。再検索してください。 」）
	 */
	public static MCMessage msgExclusionErrUpd() {
		return object(CLAZZ)._msgExclusionErrUpd(null);
	}

	/**
	 * ＤＢ上の排他対象の行が他の処理によって更新されているために、 排他チェックエラーにするときのメッセージ<BR>
	 * （「更新対象が、他の処理によって更新されています。再検索してください。 」）
	 */
	protected MCMessage _msgExclusionErrUpd(MCRow causeRow) {
		return new MCMessage(causeRow, null, FXBAL0003);
	}

	/**
	 * ＤＢ上の排他対象の行が他の処理によって削除されているために、 排他チェックエラーにするときのメッセージ<BR>
	 * （「更新対象が、他の処理によって削除されています。再検索してください。 」）
	 */
	public static MCMessage msgExclusionErrDel(MCRow causeRow) {
		return object(CLAZZ)._msgExclusionErrDel(causeRow);
	}

	/**
	 * ＤＢ上の排他対象の行が他の処理によって削除されているために、 排他チェックエラーにするときのメッセージ<BR>
	 * （「更新対象が、他の処理によって削除されています。再検索してください。 」）
	 */
	public static MCMessage msgExclusionErrDel() {
		return object(CLAZZ)._msgExclusionErrDel(null);
	}

	/**
	 * ＤＢ上の排他対象の行が他の処理によって削除されているために、 排他チェックエラーにするときのメッセージ<BR>
	 * （「更新対象が、他の処理によって削除されています。再検索してください。 」）
	 */
	protected MCMessage _msgExclusionErrDel(MCRow causeRow) {
		return new MCMessage(causeRow, null, FXBAL0009);
	}

	/**
	 * 「ORA-00001 UNIQUE索引によって制約されている列に重複値を挿入しようとした。」による例外かどうかを判別する
	 */
	public static boolean isDupValOnIndex(MCException ex) {
		return object(CLAZZ)._isDupValOnIndex(ex);
	}
	
	/**
	 * 「ORA-00001 UNIQUE索引によって制約されている列に重複値を挿入しようとした。」による例外かどうかを判別する
	 */
	public boolean _isDupValOnIndex(MCException ex) {
		if (ex == null) return false;
		return FCBCC0136.equals(ex.getID());
	}

	// メッセージ(END)
	// バインドの補助(START)
	/**
	 * バインド値を保持するロウの指定されたカラムを後方一致用のバインド値に変換したロウを返します。 <br>
	 * インスタンスは複製（clone）したものが返ります。
	 * 例：ST-ANT -> %ST-ANT
	 * <p>
	 * 以下、詳細な仕様
	 * <li>ロウの指定されたカラムのデータ型がSTRING以外の場合は、変換を行わない</li>
	 * <li>ロウの指定されたカラムのデータがnull状態の場合、変換を行わない</li>
	 * </p>
	 *
	 * @param row バインド値を保持するロウ
	 * @param columns 変換を行うカラム
	 * @return バインド値に変換したロウ
	 */
	public static MCRow bindForSuffixSearch(MCRow row, String... columns) {
		if (row == null) return null;
		MCRow r = row.clone();
		for (String col : columns) {
			MCMeta meta = r.getMeta(col);
			if (MCDataType.STRING == meta.type()) {
				String data = r.getString(col);
				if (!isNull(data)) {
					r.setString(col, "%" + data);
				}
			}
		}
		return r;
	}

	/**
	 * バインド値を保持するロウの指定されたカラムを前方一致用のバインド値に変換したロウを返します。 <br>
	 * インスタンスは複製（clone）したものが返ります。
	 * 例：ST-ANT -> ST-ANT%
	 * <p>
	 * 以下、詳細な仕様
	 * <li>ロウの指定されたカラムのデータ型がSTRING以外の場合は、変換を行わない</li>
	 * <li>ロウの指定されたカラムのデータがnull状態の場合、変換を行わない</li>
	 * </p>
	 *
	 * @param row バインド値を保持するロウ
	 * @param columns 変換を行うカラム
	 * @return バインド値に変換したロウ
	 */
	public static MCRow bindForPrefixSearch(MCRow row, String... columns) {
		if (row == null) return null;
		MCRow r = row.clone();
		for (String col : columns) {
			MCMeta meta = r.getMeta(col);
			if (MCDataType.STRING == meta.type()) {
				String data = r.getString(col);
				if (!isNull(data)) {
					r.setString(col, data + "%");
				}
			}
		}
		return r;
	}

	/**
	 * バインド値を保持するロウの指定されたカラムを部分一致用のバインド値に変換したロウを返します。 <br>
	 * インスタンスは複製（clone）したものが返ります。
	 * 例：ST-ANT -> %ST-ANT%
	 * <p>
	 * 以下、詳細な仕様
	 * <li>ロウの指定されたカラムのデータ型がSTRING以外の場合は、変換を行わない</li>
	 * <li>ロウの指定されたカラムのデータがnull状態の場合、変換を行わない</li>
	 * </p>
	 *
	 * @param row バインド値を保持するロウ
	 * @param columns 変換を行うカラム
	 * @return バインド値に変換したロウ
	 */
	public static MCRow bindForSubStringSearch(MCRow row, String... columns) {
		if (row == null) return null;
		MCRow r = row.clone();
		for (String col : columns) {
			MCMeta meta = r.getMeta(col);
			if (MCDataType.STRING == meta.type()) {
				String data = r.getString(col);
				if (!isNull(data)) {
					r.setString(col, "%" + data + "%");
				}
			}
		}
		return r;
	}

	// バインドの補助(END)

	// ＤＢ関連(START) ====================================
	// MCRowの比較
	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は「"UPD_CNTR"」を使用します。<br>
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, MCRow lockedRow) {
		_checkUpdCntr(updRow, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, lockedRow, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, (String) null, (Object) null);
	}

	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は「"UPD_CNTR"」を使用します。<br>
	 * <P>
	 * msgid に値をセットした場合は、引数のmsgidとvaluesで例外を発生させます。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, MCRow lockedRow, String msgid,
			Object... values) {
		_checkUpdCntr(updRow, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, lockedRow, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, msgid, values);
	}

	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は、updCntrColとlockedCntrColで指定します。
	 * <P>
	 * msgid に値をセットした場合は、引数のmsgidとvaluesで例外を発生させます。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param updCntrCol 更新レコードの更新カウンタカラム名。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @param lockedCntrCol　ロック対象レコードの更新カウンタカラム名。
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, String updCntrCol, MCRow lockedRow,
			String lockedCntrCol) {
		_checkUpdCntr(updRow, new String[] {
			updCntrCol
		}, lockedRow, new String[] {
			lockedCntrCol
		}, (String) null, (Object) null);

	}

	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は、updCntrColとlockedCntrColで指定します。
	 * <P>
	 * msgid に値をセットした場合は、引数のmsgidとvaluesで例外を発生させます。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param updCntrCol 更新レコードの更新カウンタカラム名。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, String updCntrCol, MCRow lockedRow) {
		_checkUpdCntr(updRow, new String[] {
			updCntrCol
		}, lockedRow, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, (String) null, (Object) null);
	}
	

	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は、updCntrColとlockedCntrColで指定します。
	 * <P>
	 * msgid に値をセットした場合は、引数のmsgidとvaluesで例外を発生させます。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param updCntrCol 更新レコードの更新カウンタカラム名。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @param lockedCntrCol　ロック対象レコードの更新カウンタカラム名。
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, String updCntrCol, MCRow lockedRow,
			String lockedCntrCol, String msgid, Object... values) {
		_checkUpdCntr(updRow, new String[] {
			updCntrCol
		}, lockedRow, new String[] {
			lockedCntrCol
		}, msgid, values);

	}
	
	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param updCntrCols 更新レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @param lockedCntrCols　ロック対象レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, String[] updCntrCols, MCRow lockedRow,
			String[] lockedCntrCols) {
		_checkUpdCntr(updRow, updCntrCols, lockedRow, lockedCntrCols, (String) null,
				(Object) null);
	}

	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * <P>
	 * msgid に値をセットした場合は、引数のmsgidとvaluesで例外を発生させます。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param updCntrCols 更新レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @param lockedCntrCols　ロック対象レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCRow updRow, String[] updCntrCols, MCRow lockedRow,
			String[] lockedCntrCols, String msgid, Object... values) {
		_checkUpdCntr(updRow, updCntrCols, lockedRow, lockedCntrCols, msgid, values);
	}

	/**
	 * 更新レコードとロック対象レコードの更新カウンタを比較し、値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * <P>
	 * msgid に値をセットした場合は、引数のmsgidとvaluesで例外を発生させます。
	 *
	 * @param updRow 更新レコード。ロック対象レコードを参照した時の更新カウンタを保持するレコード。
	 * @param updCntrCols 更新レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param lockedRow ロック対象レコード。データ更新するためにロックしたレコード。
	 * @param lockedCntrCols　ロック対象レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	private static void _checkUpdCntr(MCRow updRow, String[] updCntrCols,
			MCRow lockedRow, String[] lockedCntrCols, String msgid, Object... values) {
		if (updRow == null || updCntrCols == null || updCntrCols.length == 0) {
			throw new MCAppException(FXBAL0001, null, null);
		}

		if (lockedRow == null || lockedCntrCols == null || lockedCntrCols.length == 0) {
			MCLog.write(FXBAL0010, null, null);
			throw new MCAppException(updRow, null, FXBAL0009);
		}

		if (updCntrCols.length != lockedCntrCols.length) {
			throw new MCAppException(updRow, null, FXBAL0005, updCntrCols.length, lockedCntrCols.length);
		}

		if (lockedRow instanceof MCDBContainer) {
			if (!((MCDBContainer) lockedRow).isExCtrl()) {
				throw new MCAppException(lockedRow, null, FXBAL0027, ((MCDBContainer) lockedRow).tableName());
			}
		}

		for (int i = 0; i < updCntrCols.length; i++) {
			String updCntrCol = updCntrCols[i];
			String lockedCntrCol = lockedCntrCols[i];
			MCNumber updateCntr = updRow.getNumberNE(updCntrCol);
			if (updateCntr == null) {
				continue;
			}

			MCNumber lockedCntr = lockedRow.getNumberNE(lockedCntrCol);
			if (lockedCntr == null) {
				MCLog.write(FXBAL0002, updRow, lockedRow, updCntrCol);
				throw new MCAppException(lockedRow, null, FXBAL0009);
			}

			if (updateCntr.neq(lockedCntr)) {
				if (!isSameOperation(lockedRow.getStringNE(MCSQLClause.UPD_SRV_REQ_NO_NAME))) {
					MCLog.write(FXBAL0004, updRow, updateCntr.toPlainString(), lockedRow,
							lockedCntr.toPlainString(), updCntrCol);
					if (!isNull(msgid)) {
						throw new MCAppException(updRow, null, msgid, values);
					}
					throw new MCAppException(updRow, null, FXBAL0003);
				}
			}
		}
	}

	// MCListの比較
	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は「"UPD_CNTR"」を使用します。<br>
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList,
			String[] updListKeys, MCList<? extends MCRow> lockedList,
			String[] lockedListKeys) {
		_checkUpdCntr(updList, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, updListKeys, lockedList, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, lockedListKeys, (String) null, (Object) null);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は「"UPD_CNTR"」を使用します。<br>
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList,
			String[] updListKeys, MCList<? extends MCRow> lockedList,
			String[] lockedListKeys, String msgid, Object... values) {
		_checkUpdCntr(updList, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, updListKeys, lockedList, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, lockedListKeys, msgid, values);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updCntrCol 更新レコードの更新カウンタカラム名。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedCntrCol ロック対象レコードの更新カウンタカラム名。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList, String updCntrCol,
			String[] updListKeys, MCList<? extends MCRow> lockedList,
			String lockedCntrCol, String[] lockedListKeys) {

		_checkUpdCntr(updList, new String[] {
			updCntrCol
		}, updListKeys, lockedList, new String[] {
			lockedCntrCol
		}, lockedListKeys, (String) null, (Object) null);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updCntrCol 更新レコードの更新カウンタカラム名。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList, String updCntrCol,
			String[] updListKeys, MCList<? extends MCRow> lockedList,
			String[] lockedListKeys) {

		_checkUpdCntr(updList, new String[] {
			updCntrCol
		}, updListKeys, lockedList, new String[] {
			MCSQLClause.UPD_CNTR_NAME
		}, lockedListKeys, (String) null, (Object) null);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updCntrCol 更新レコードの更新カウンタカラム名。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedCntrCol ロック対象レコードの更新カウンタカラム名。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList, String updCntrCol,
			String[] updListKeys, MCList<? extends MCRow> lockedList,
			String lockedCntrCol, String[] lockedListKeys, String msgid, Object... values) {

		_checkUpdCntr(updList, new String[] {
			updCntrCol
		}, updListKeys, lockedList, new String[] {
			lockedCntrCol
		}, lockedListKeys, msgid, values);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updCntrCols 更新レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedCntrCols　ロック対象レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList,
			String[] updCntrCols, String[] updListKeys,
			MCList<? extends MCRow> lockedList, String[] lockedCntrCols,
			String[] lockedListKeys) {
		_checkUpdCntr(updList, updCntrCols, updListKeys, lockedList, lockedCntrCols,
				lockedListKeys, (String) null, (Object) null);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updCntrCols 更新レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedCntrCols　ロック対象レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	public static void checkUpdCntr(MCList<? extends MCRow> updList,
			String[] updCntrCols, String[] updListKeys,
			MCList<? extends MCRow> lockedList, String[] lockedCntrCols,
			String[] lockedListKeys, String msgid, Object... values) {
		_checkUpdCntr(updList, updCntrCols, updListKeys, lockedList, lockedCntrCols,
				lockedListKeys, msgid, values);
	}

	/**
	 * 更新レコードのリストとロック対象レコードのリストのそれぞれの対応するRowの更新カウンタを比較します。
	 * 更新カウンタの値が異なる場合は例外を発生させます。
	 * <P>
	 * 更新レコードのリストとロック対象レコードのリストは、それぞれupdListKeysとlockedListKeysの値が等しいRowを比較対象とします。
	 * <p>
	 * 更新カウンタを保持するカラム名は、updCntrColsとlockedCntrColsで指定します。1つのMCRowの中に複数テーブルの情報が格納されていて、
	 * 更新カウンタが複数存在する場合は、updCntrColsとlockedCntrColsにも複数の値を指定します。
	 * @param updList 更新レコードのリスト。ロック対象レコードを参照した時の更新カウンタを保持するレコードのリスト。
	 * @param updCntrCols 更新レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param updListKeys updListとlockedListとを結合する際に使用するupdListのカラム名の配列
	 * @param lockedList ロック対象レコードのリスト。データ更新するためにロックしたレコードのリスト。
	 * @param lockedCntrCols ロック対象レコードの更新カウンタカラム名の配列。更新カウンタが格納されている項目数分、指定する。
	 * @param lockedListKeys updListとlockedListとを結合する際に使用するlockedListのカラム名の配列
	 * @param msgid 更新カウンタの値が異なる場合の例外で使用するメッセージＩＤ
	 * @param values msgidの例外を使用する際に使用する、例外のバインド値
	 * @throws MCAppException [FXBAL0001] 更新レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0005] 更新レコードとロック対象レコードの更新カウンタ名に指定した項目数が一致しない場合
	 * @throws MCAppException [FXBAL0006] updList / updListKeys / lockedList / lockedListKeys がnullの場合
	 * @throws MCAppException [FXBAL0009] ロック対象レコードの更新カウンタが取得できない場合。
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対して悲観ロックを行いlockedListを取得した場合
	 * @throws MCAppException [FXUCL0007] リストを結合する項目数が一致しない場合
	 * @throws MCAppException [msgid。msgidがnull状態の場合は FXBAL0003] 更新レコードとロック対象レコードの更新カウンタの値が異なる場合
	 */
	private static void _checkUpdCntr(MCList<? extends MCRow> updList,
			String[] updCntrCols, String[] updListKeys,
			MCList<? extends MCRow> lockedList, String[] lockedCntrCols,
			String[] lockedListKeys, String msgid, Object... values) {

		if (!isNoNull(updList, updListKeys, lockedList, lockedListKeys)) {
			throw new MCAppException(FXBAL0006, nullNotNull(updList),
					nullNotNull(updListKeys), nullNotNull(lockedList),
					nullNotNull(lockedListKeys));
		}

		if (updCntrCols.length != lockedCntrCols.length) {
			throw new MCAppException(FXBAL0005, updCntrCols.length, lockedCntrCols.length);
		}

		if (updListKeys.length != lockedListKeys.length) {
			throw new MCAppException(FXUCL0007, updListKeys.length, lockedListKeys.length);
		}

		if (!lockedList.isEmpty() && lockedList.get(0) instanceof MCDBContainer) {
			MCDBContainer dbc = (MCDBContainer)lockedList.get(0);
			if (!dbc.isExCtrl()) {
				throw new MCAppException(FXBAL0027, dbc.tableName());
			}
		}

		MCIndexKey idx = lockedList.createIndex(lockedListKeys);
		for (MCRow myRow : updList) {
			Comparable<?>[] v = new Comparable<?>[updListKeys.length];
			for (int i = 0; i < v.length; i++) {
				v[i] = myRow.getValueNE(updListKeys[i]);
			}
			MCList<? extends MCRow> lockedSub = lockedList.subList(idx, v);
			if (lockedSub.size() > 0) {
				for (MCRow lockedRow : lockedSub) {
					_checkUpdCntr(myRow, updCntrCols, lockedRow, lockedCntrCols, msgid,
							values);
				}
			}
			else {
				throw new MCAppException(myRow, null, FXBAL0009);
			}
		}
	}

	/**
	 * 引数で指定したサーバリクエストNoと現在のリクエストNoが等しいか評価します。
	 * @param srvReqNo サーバリクエストNo
	 * @return true：srvReqNoと実行中のリクエストNoが等しい、false：srvReqNoと実行中のリクエストNoが異なる
	 */
	static boolean isSameOperation(String srvReqNo) {
		boolean ret = false;
		String sys = mcframe.serverCore.sys.MCSys.request.serverRequestNo();
		if (sys == null && srvReqNo == null) {
			ret = true;
		}
		else if (sys != null && sys.equals(srvReqNo)) {
			ret = true;
		}

		return ret;
	}

	// -----------------function一括実行ここから---------------------

	/**
	 * PL/SQLファンクションを、引数listの行数分、一括で実行します。<br>
	 * ファンクションの戻り値は、引数resultColに指定されたカラムに格納されます。<br>
	 * 引数bindColsで指定されたカラムの値を、バインド変数に設定することができます。<br>
	 * ※PL/SQLファンクションの引数と同じ順番で設定する必要があります。<br>
	 * 以下の場合は何も処理を実行しません。<br>
	 * ・ listがnull又は空の場合<br>
	 * ・ functionがnullの場合<br>
	 * ・ resultColがnullの場合<br><br>
	 * 
	 * <b>＜使用例＞</b><br>
	 * execDbFuncBatch("CPA_DT.F_CAL_DATE_LOC", "end_dt", list, "st_dt", "lt", "adjst_typ", "loc_cd", "wk_dt_cnt_typ");<br><br>
	 * <b>＜実行されるSQL（listが3行の場合）＞</b><br>
	 * SELECT <br>
	 * CPA_DT.F_CAL_DATE_LOC(:0_st_dt, :0_lt, :0_adjst_typ, :0_loc_cd, :0_wk_dt_cnt_typ) AS col0<br>
	 * ,CPA_DT.F_CAL_DATE_LOC(:1_st_dt, :1_lt, :1_adjst_typ, :1_loc_cd, :1_wk_dt_cnt_typ) AS col1<br>
	 * ,CPA_DT.F_CAL_DATE_LOC(:2_st_dt, :2_lt, :2_adjst_typ, :2_loc_cd, :2_wk_dt_cnt_typ) AS col2<br>
	 * FROM DUAL<br><br>
	 * col0のファンクションのバインド変数にはlistの1行目の値が設定され、
	 * 実行結果はlistの1行目のresultColに設定されます（2行目以降も同様）<br>
	 * listの件数が、MCAppServerのFX.FXUCL0020.func_batch_sizeで指定した件数を超えた場合は、分割して実行されます（デフォルト値：100）<br>
	 *
	 * @param funcName ファンクション名
	 * @param resultCol ファンクションの結果を格納するリストのカラム名（listに存在するカラムであること）
	 * @param list ファンクションの結果を格納するリスト及び、バインド変数が設定されたリスト
	 * @param bindCols バインド変数のカラム名（listに存在するカラムであること）。
	 *
	 */
	public static <R extends MCRow, L extends MCList<R>> void execDbFuncBatch(
			String sqlId, Function<String[], MCExprValue> function, String resultCol, L list, String... bindCols) {
		object(CLAZZ)._execDbFuncBatch(sqlId, function, resultCol, list, bindCols);
	}

	protected <R extends MCRow, L extends MCList<R>> void _execDbFuncBatch(
			String sqlId, Function<String[], MCExprValue> function, String resultCol, L list, String... bindCols) {
		if (function == null || list == null || resultCol == null) {
			return;
		}
		if (list.isEmpty()) {
			return;
		}
		// bindがnullの場合とresultColがnullの場合

		int batchSize = getBatchSize();
		int currSize = 0;
		int fromIdx = 0;

		int bindSize = bindCols == null ? 0 : bindCols.length;
		String[] tempBindNames = new String[bindSize];
		List<MCAliasedColumn> functions = new ArrayList<>();
		MCRow bindRow = MCRow.create();
		MCRow resultR = MCRow.create();
		boolean isRetBoolean = isBooleanCol(resultCol, list);
		
		MCList<R> groupbyList = list.groupByNE(bindCols);
		
		for (int i = 0; i < groupbyList.size(); i++) {
			if (bindCols != null) {
				// 引数部分の編集
				for (int j = 0; j < bindCols.length; j++) {
					tempBindNames[j] = makeTempColName(i, bindCols[j]);
					bindRow.setValueNE(tempBindNames[j], groupbyList.get(i).getValue(bindCols[j]));
				}
			}
			
			// ファンクションを作る
			MCExprValue func = function.apply(tempBindNames);
			// 別名を付ける
			String colAlias = getColAlias(i);
			MCAliasedColumn retCol = MCQueryApiBuilder.castToAliasedColumn(func, colAlias);
			functions.add(retCol);
			
			if (isRetBoolean) {
				resultR.addBooleanColumn(colAlias);
			}

			currSize = currSize + 1;
			
			if (batchSize <= currSize || i == groupbyList.size() - 1) {
				// 最大回数に達した場合 or ループの最後
				// SQL実行
				MCQueryApiBuilder builder = MCQueryApiBuilder.createDual();
				functions.stream().forEach(col -> builder.addSelectNEActiveForeign(col));
				builder.buildSelect(sqlId).executeQuery(bindRow, resultR);

				// 結果を設定
				for (int k = 0; k < resultR.size(); k++) {
					int idx = k + fromIdx;
					groupbyList.get(idx).setValue(resultCol, resultR.getValue(getColAlias(idx)));
				}

				// リセット
				functions.clear();
				bindRow = MCRow.create();
				resultR = MCRow.create();
				currSize = 0;
				fromIdx = i + 1;
			}
		}
		
		MCIndexKey idxKey = groupbyList.createIndex(bindCols);
		for(MCList<R> tmp : list.groupList(bindCols)) {
			Comparable<?>[] c = new Comparable[bindCols.length];
			for(int i = 0; i < bindCols.length; i++) {
				c[i] = tmp.get(0).getValue(bindCols[i]);
			}
			R r = groupbyList.getFirst(idxKey, c);
			tmp.setValue(resultCol, r.getValue(resultCol));
		}
	}
	
	protected String makeTempColName(int listNumber, String orgName) {
		return listNumber + "_" + orgName.replaceAll("\\.", "#");
	}

	protected <R extends MCRow, L extends MCList<R>> boolean isBooleanCol(
			String resultCol, L list) {
		return MCDataType.BOOLEAN.equals(list.getMeta(resultCol).type());
	}

	protected String getColAlias(int i) {
		return "col" + i;
	}

	protected int getBatchSize() {
		return mcframe.serverCore.resource.MCConst.app.getInteger(
				"FX.FXUCL0020.func_batch_size", 100);
	}
	// -----------------function一括実行ここまで---------------------
	// -----------------旧DBコンテナからの移植ここから---------------------

	/**
	 * ロックを行い、ロックできた場合と、できなかった場合（ロック対象行が存在しない）で 処理を振り分けます。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>更新用のソートを実行します</li>
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行い、lockedListに追加します</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、notLockedListに追加します</li>
	 * </p>
	 * <p>
	 * 引数 lockedList / notLockedList のいずれかがnullの場合は、その引数には結果をセットしません。 <br>
	 * また、lockedList が null の場合は戻り値もnullになります。
	 * </p>
	 * <p>
	 * 使用サンプル１
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCList&lt;M_HINMO_R&gt; insL = list.createInstance();
	 * 	dbSortLockDivide(sqlid, builder, bindList, updL, insL);
	 * 	dbInsert(sqlid, insL, insBuilder);
	 * 	updBuilder.setSet(&quot;...&quot;);
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * <p>
	 * 使用サンプル２
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCJoinKey&lt;MCList&lt;M_HINMO_R&gt;&gt; jk = dbSortLockDivide(updL, null);
	 * 	for (M_HINMO_R row : updL) {
	 * 		M_HINMO_R lockedRow = row.getJoinedRow(jk);
	 * 		// row と lockedRow を使った処理（チェックなど）
	 * 	}
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param sqlid SQLID
	 * @param builder クエリAPIビルダー
	 * @param bindList 検索条件のリスト
	 * @param lockedList ロックができたRowを格納するリストインスタンス
	 * @param notLockedList ロックができなかったRowを格納するリストインスタンス
	 * @return lockedListとkey項目が同じＤＢ上のRowを取得するためのjoinKey
	 * @throws MCAppException [FXUDL0011] 引数lockedList/notLockedList両方がnullの場合
	 */
	public static <R extends MCRow, A extends MCList<R>> MCJoinKey<A> dbSortLockDivide(String sqlid, MCQueryApiBuilder builder, A bindList, A lockedList, A notLockedList) {
		sortForUpdate(builder, bindList);
		return dbLockDivide(sqlid, bindList, builder, lockedList, notLockedList);
	}

	/**
	 * ロックを行い、ロックできた場合と、できなかった場合（ロック対象行が存在しない）で 処理を振り分けます。
	 * 但し、更新カウンタのチェックを行いません。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>更新用のソートを実行します</li>
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、lockedListに追加します</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、notLockedListに追加します</li>
	 * </p>
	 * <p>
	 * 引数 lockedList / notLockedList のいずれかがnullの場合は、その引数には結果をセットしません。 <br>
	 * また、lockedList が null の場合は戻り値もnullになります。
	 * </p>
	 * <p>
	 * 使用サンプル１
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCList&lt;M_HINMO_R&gt; insL = list.createInstance();
	 * 	dbSortLockDivideNoCheck(sqlid, builder, bindList, updL, insL);
	 * 	dbInsert(sqlid, insL, insBuilder);
	 * 	updBuilder.setSet(&quot;...&quot;);
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * <p>
	 * 使用サンプル２
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCJoinKey&lt;MCList&lt;M_HINMO_R&gt;&gt; jk = dbSortLockDivideNoCheck(updL, null);
	 * 	for (M_HINMO_R row : updL) {
	 * 		M_HINMO_R lockedRow = row.getJoinedRow(jk);
	 * 		// row と lockedRow を使った処理（チェックなど）
	 * 	}
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param sqlid SQLID
	 * @param builder クエリAPIビルダー
	 * @param bindList 検索条件のリスト
	 * @param lockedList ロックができたRowを格納するリストインスタンス
	 * @param notLockedList ロックができなかったRowを格納するリストインスタンス
	 * @return lockedListとkey項目が同じＤＢ上のRowを取得するためのjoinKey
	 * @throws MCAppException [FXUDL0011] 引数lockedList/notLockedList両方がnullの場合
	 */
	public static <R extends MCRow, A extends MCList<R>> MCJoinKey<A> dbSortLockDivideNoCheck(String sqlid, MCQueryApiBuilder builder, A bindList, A lockedList, A notLockedList) {
		sortForUpdate(builder, bindList);
		return dbLockDivideNoCheck(sqlid, bindList, builder, lockedList, notLockedList);
	}

	/**
	 * ロックを行い、ロックできた場合と、できなかった場合（ロック対象行が存在しない）で 処理を振り分けます。
	 * 但し、更新カウンタのチェックを行いません。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、lockedListに追加します</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、notLockedListに追加します</li>
	 * </p>
	 * <p>
	 * 引数 lockedList / notLockedList のいずれかがnullの場合は、その引数には結果をセットしません。 <br>
	 * また、lockedList が null の場合は戻り値もnullになります。
	 * </p>
	 * <p>
	 * 使用サンプル１
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCList&lt;M_HINMO_R&gt; insL = list.createInstance();
	 * 	dbLockDivideNoCheck(sqlid, builder, bindList, updL, insL);
	 * 	dbInsert(sqlid, insL, insBuilder);
	 * 	updBuilder.setSet(&quot;...&quot;);
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * <p>
	 * 使用サンプル２
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCJoinKey&lt;MCList&lt;M_HINMO_R&gt;&gt; jk = dbLockDivideNoCheck(updL, null);
	 * 	for (M_HINMO_R row : updL) {
	 * 		M_HINMO_R lockedRow = row.getJoinedRow(jk);
	 * 		// row と lockedRow を使った処理（チェックなど）
	 * 	}
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param sqlid SQLID
	 * @param bindList 検索条件のリスト
	 * @param builder クエリAPIビルダー
	 * @param lockedList ロックができたRowを格納するリストインスタンス
	 * @param notLockedList ロックができなかったRowを格納するリストインスタンス
	 * @return lockedListとkey項目が同じＤＢ上のRowを取得するためのjoinKey
	 * @throws MCAppException [FXUDL0011] 引数lockedList/notLockedList両方がnullの場合
	 */
	protected static <R extends MCRow, A extends MCList<R>> MCJoinKey<A> dbLockDivideNoCheck(String sqlid, A bindList, MCQueryApiBuilder builder, A lockedList, A notLockedList) {
		return dbLockDivideCheck(builder, sqlid, bindList, lockedList, notLockedList, false);
	}

	/**
	 * ロックを行い、ロックできた場合と、できなかった場合（ロック対象行が存在しない）で 処理を振り分けます。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行い、lockedListに追加します</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、notLockedListに追加します</li>
	 * </p>
	 * <p>
	 * 引数 lockedList / notLockedList のいずれかがnullの場合は、その引数には結果をセットしません。 <br>
	 * また、lockedList が null の場合は戻り値もnullになります。
	 * </p>
	 * <p>
	 * 使用サンプル１
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCList&lt;M_HINMO_R&gt; insL = list.createInstance();
	 * 	dbLockDivide(sqlid, builder, bindList, updL, insL);
	 * 	dbInsert(sqlid, insL, insBuilder);
	 * 	updBuilder.setSet(&quot;...&quot;);
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * <p>
	 * 使用サンプル２
	 * 
	 * <pre>
	 * void update(MCList&lt;M_HINMO_R&gt; list) {
	 * 	MCList&lt;M_HINMO_R&gt; updL = list.createInstance();
	 * 	MCJoinKey&lt;MCList&lt;M_HINMO_R&gt;&gt; jk = dbLockDivide(updL, null);
	 * 	for (M_HINMO_R row : updL) {
	 * 		M_HINMO_R lockedRow = row.getJoinedRow(jk);
	 * 		// row と lockedRow を使った処理（チェックなど）
	 * 	}
	 * 	dbUpdateKey(sqlid, updL, updBuilder);
	 * }
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param sqlid SQLID
	 * @param bindList 検索条件のリスト
	 * @param builder クエリAPIビルダー
	 * @param lockedList ロックができたRowを格納するリストインスタンス
	 * @param notLockedList ロックができなかったRowを格納するリストインスタンス
	 * @return lockedListとkey項目が同じＤＢ上のRowを取得するためのjoinKey
	 * @throws MCAppException [FXUDL0011] 引数lockedList/notLockedList両方がnullの場合
	 */
	public static <R extends MCRow, A extends MCList<R>> MCJoinKey<A> dbLockDivide(String sqlid, A bindList, MCQueryApiBuilder builder, 
			A lockedList,
			A notLockedList) {
		return dbLockDivideCheck(builder, sqlid, bindList, lockedList, notLockedList, true);
	}

	/**
	 * ロックを行い、ロックできた場合と、できなかった場合（ロック対象行が存在しない）で 処理を振り分けます。
	 * 引数updChkにtrueが指定された場合は、SELECT FOR UPDATE NOWAITでロックし
	 * 更新カウンタのチェックを行います。
	 * <p>
	 * 以下の順に処理を行います。<P>
	 * 引数updChkにtrueが指定された場合<BR>
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行い、lockedListに追加します</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、notLockedListに追加します</li>
	 * </p>
	 * 引数updChkにfalseが指定された場合<BR>
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、lockedListに追加します</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、notLockedListに追加します</li>
	 * <p>
	 * 引数 lockedList / notLockedList のいずれかがnullの場合は、その引数には結果をセットしません。 <br>
	 * また、lockedList が null の場合は戻り値もnullになります。
	 * </p>
	 * <p>
	 * 
	 * @param builder クエリAPIビルダー
	 * @param sqlid SQLID
	 * @param bindList 検索条件のリスト
	 * @param lockedList ロックができたRowを格納するリストインスタンス
	 * @param notLockedList ロックができなかったRowを格納するリストインスタンス
	 * @param updChk 更新カウンタのチェックを行う場合はtrue
	 * @return lockedListとkey項目が同じＤＢ上のRowを取得するためのjoinKey
	 * @throws MCAppException [FXUDL0011] 引数lockedList/notLockedList両方がnullの場合
	 */
	@SuppressWarnings("unchecked")
	protected static <R extends MCRow, A extends MCList<R>> MCJoinKey<A> dbLockDivideCheck(MCQueryApiBuilder builder, String sqlid,
			A bindList,
			A lockedList,
			A notLockedList, boolean updChk) {
		/*
		 * lockedList あるいは notLockedList に bindList をセットされる可能性があるので、
		 * 一時変数（locked/notLocked）に値を入れてから最後にセットしている （そうしないとfor文などで都合が悪い）
		 */

		A locked = (lockedList == null) ? null : (A) lockedList.createInstance();
		A notLocked = (notLockedList == null) ? null : (A) notLockedList.createInstance();
		A sel;
		if (locked != null) {
			sel = (A) locked.createInstance();
		}
		else if (notLocked != null) {
			sel = (A) notLocked.createInstance();
		}
		else {
			throw new MCAppException(FXUDL0011);
		}
		MCDBContainer dbc = builder.getBaseDbc();
		String[] keys = dbc.getKeyColumn();
		
		Map<String, MCColumn> select = builder.getSelect();
		builder.setSelect(dbc.getKeyColumn$());
		builder.addSelect(dbc.getColumn$("upd_cntr"));

		if (updChk) {
			dbSelectKeyForUpdateNoWait(sqlid, sel, builder, bindList);
		}
		else{
			dbSelectKeyForUpdate(sqlid, sel, builder, bindList);
		}
		
		builder.clearSelect();
		for (Entry<String, MCColumn> s : select.entrySet()) {
			builder.addSelect(s.getKey(), s.getValue());
		}
		
		MCJoinKey<A> jk = bindList.join(keys, sel, sel.createIndex(keys));
		for (R row : bindList) {
			R lockedRow = row.getJoinedRow(jk);
			if (lockedRow != null) {
				// ロックできた場合
				if (updChk) {
					checkUpdCntr(row, lockedRow);
				}
				locked.add(row);
			}
			else {
				// ロックができなかった場合
				notLocked.add(row);
			}
		}
		if (lockedList != null) {
			lockedList.init();
			lockedList.addAll(locked);
		}
		if (notLockedList != null) {
			notLockedList.init();
			notLockedList.addAll(notLocked);
		}
		return (lockedList == null) ? null : jk;
	}

	/**
	 * ロック(SELECT FOR UPDATE NOWAIT)を行いロック行を更新します。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>更新用のソートを実行します</li>
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行います</li>
	 * <li>key項目でロックした行を更新します</li>
	 * <br>
	 * </p>
	 *
	 * @param sqlid SQLID
	 * @param list 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対してロックを行った場合
	 * @throws MCAppException [FXBAL0009] 更新対象のレコードがロックできなかった（=削除済み）場合
	 */
	public static void dbSortLockUpd(String sqlid, MCList<? extends MCRow> list, MCQueryApiBuilder builder) {
		sortForUpdate(builder, list);
		dbLockUpd(sqlid, list, builder);
	}
	
	/**
	 * ロック(SELECT FOR UPDATE)を行いロック行を更新します。<br>
	 * 但し、更新カウンタのチェックを行いません。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>更新用のソートを実行します</li>
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>key項目でロックした行を更新します</li>
	 * <br>
	 * </p>
	 *
	 * @param sqlid SQLID
	 * @param list 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対してロックを行った場合。
	 * @throws MCAppException [FXBAL0009] 更新対象のレコードがロックできなかった（=削除済み）場合。
	 */
	public static void dbSortLockUpdNoCheck(String sqlid, MCList<? extends MCRow> list, MCQueryApiBuilder builder) {
		sortForUpdate(builder, list);
		dbLockUpdNoCheck(sqlid, list, builder);
	}

	/**
	 * ロック(SELECT FOR UPDATE)を行いロック行を更新します。<br>
	 * 但し、更新カウンタのチェックを行いません。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>key項目でロックした行を更新します</li>
	 * <br>
	 * </p>
	 *
	 * @param sqlid SQLID
	 * @param list 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対してロックを行った場合。
	 * @throws MCAppException [FXBAL0009] 更新対象のレコードがロックできなかった（=削除済み）場合。
	 */
	public static void dbLockUpdNoCheck(String sqlid, MCList<? extends MCRow> list, MCQueryApiBuilder builder) {
		dbLockUpdCheck(builder, sqlid, list, false);
	}

	/**
	 * ロック(SELECT FOR UPDATE)を行いロック行を更新します。<br>
	 * 但し、更新カウンタのチェックを行いません。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATEを実行します（ロックできない場合は例外）</li>
	 * <li>key項目でロックした行を更新します</li>
	 * <br>
	 * </p>
	 *
	 * @param sqlid SQLID
	 * @param row 更新対象のMCRow
	 * @param builder クエリAPIビルダー
	 */
	public static void dbLockUpdNoCheck(String sqlid, MCRow row, MCQueryApiBuilder builder) {
		// SelectKeyの結果は使わないが、nullだと検索結果0件と見なされエラーになる
		dbSelectKeyForUpdateEx(sqlid, MCRow.create(), builder, row);
		dbUpdateKey(sqlid, row, builder);
	}

	/**
	 * ロック(SELECT FOR UPDATE NOWAIT)を行いロック行を更新します。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行います</li>
	 * <li>key項目でロックした行を更新します</li>
	 * <br>
	 * </p>
	 *
	 * @param sqlid SQLID
	 * @param list 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対してロックを行った場合。
	 * @throws MCAppException [FXBAL0009] 更新対象のレコードがロックできなかった（=削除済み）場合。
	 */
	public static void dbLockUpd(String sqlid, MCList<? extends MCRow> list, MCQueryApiBuilder builder) {
		dbLockUpdCheck(builder, sqlid, list, true);
	}

	/**
	 * ロックを行いロック行を更新します。 <br>
	 * 引数updChkにtrueが指定された場合は、SELECT FOR UPDATE NOWAITでロックし
	 * 更新カウンタのチェックを行います。
	 * <p>
	 * 以下の順に処理を行います。<P>
	 * 引数updChkにtrueが指定された場合<BR>
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します（ロックできない場合は例外）</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行います</li>
	 * <li>key項目でロックした行を更新します</li>
	 * <BR>
	 * <BR>
	 * 引数updChkにfalseが指定された場合<BR>
	 * <li>key項目でSELECT FOR UPDATEを実行します（ロックできない場合は例外）</li>
	 * <li>key項目でロックした行を更新します</li>
	 *
	 * @param builder クエリAPIビルダー
	 * @param sqlid SQLID
	 * @param bindList 更新対象のリスト
	 * @param updChk 更新カウンタのチェックを行う場合は、true
	 * @throws MCAppException [FXBAL0027] 排他制御対象外のテーブルに対してロックを行った場合。
	 * @throws MCAppException [FXBAL0009] 更新対象のレコードがロックできなかった（=削除済み）場合。
	 */
	protected static <R extends MCRow> void dbLockUpdCheck(MCQueryApiBuilder builder, String sqlid, MCList<R> bindList, boolean updChk) {
		MCDBContainer dbc = builder.getBaseDbc();
		if (!dbc.isExCtrl() && updChk) {
			throw new MCAppException(FXBAL0027, dbc.tableName());
		}
		
		MCList<R> lockedList = bindList.createInstance();
		
		Map<String, MCColumn> select = builder.getSelect();
		builder.setSelect(dbc.getKeyColumn$());
		builder.addSelect(dbc.getColumn$("upd_cntr"));
		
		if (updChk) {
			dbSelectKeyForUpdateNoWait(sqlid, lockedList, builder, bindList);
		}
		else{
			dbSelectKeyForUpdate(sqlid, lockedList, builder, bindList);
		}
		
		builder.clearSelect();
		for (Entry<String, MCColumn> s : select.entrySet()) {
			builder.addSelect(s.getKey(), s.getValue());
		}

		String[] keys = dbc.getKeyColumn();
		MCJoinKey<MCList<R>> jk = bindList.join(keys, lockedList, lockedList
				.createIndex(keys));
		for (MCRow row : bindList) {
			MCRow lockedRow = row.getJoinedRow(jk);
			if (lockedRow != null) {
				if (updChk) {
					checkUpdCntr(row, lockedRow);
				}
			}
			else {
				if (updChk) {
					// ロック行対象が消えていた場合は、updChk=trueの場合のみ
					// 呼び出す（結果、例外になる）
					checkUpdCntr(row, lockedRow);
				}
				else {
					throw new MCAppException(row, null, FXBAL0009);
				}
			}
		}
		dbUpdateKey(sqlid, bindList, builder);
	}

	/**
	 * キー項目を使って更新日時のみを更新します。
	 * <P>
	 * <B>メソッドの意義・使い方</B><BR>
	 * ヘッダ－明細タイプのテーブルの更新や赤黒データでデータを更新するようなテーブルの場合、そのレコードのデータそのものは更新しないupdate文を発行することにより、更新日時を更新し、排他を行えるようにするテクニックがあります。<br>
	 * 本メソッドは、上記の「レコードのデータそのものは更新しない」で、「更新日時を更新」 します。 <br>
	 * </p>
	 * 
	 * @param sqlid SQLID
	 * @param bind バインド値を格納したMCRow
	 * @param dbc DBコンテナ
	 */
	public static void dbTsUpdateKey(String sqlid, MCRow bind, MCDBContainer dbc) {
		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
// TODO MA対応 クエリAPIビルダーを受けると、条件が設定されてしまっている可能性があるが、、、
//		dbTsUpdateKey(sqlid, bind, builder);
//	}
//
//	/**
//	 * キー項目を使って更新日時のみを更新します。
//	 * <P>
//	 * <B>メソッドの意義・使い方</B><BR>
//	 * ヘッダ－明細タイプのテーブルの更新や赤黒データでデータを更新するようなテーブルの場合、そのレコードのデータそのものは更新しないupdate文を発行することにより、更新日時を更新し、排他を行えるようにするテクニックがあります。<br>
//	 * 本メソッドは、上記の「レコードのデータそのものは更新しない」で、「更新日時を更新」 します。 <br>
//	 * </p>
//	 * 
//	 * @param sqlid SQLID
//	 * @param bind バインド値を格納したMCRow
//	 * @param builder クエリAPIビルダー
//	 */
//	public static void dbTsUpdateKey(String sqlid, MCRow bind, MCQueryApiBuilder builder) {
		builder.clearSet();
		builder.addSet(builder.getBaseDbc().getKeyColumn$());
		MCLog.write(FXUDL0003);
		dbUpdateKey(sqlid, bind, builder);
	}

	/**
	 * キー項目を使って更新日時のみを更新します。
	 * <P>
	 * <B>メソッドの意義・使い方</B><BR>
	 * ヘッダ－明細タイプのテーブルの更新や赤黒データでデータを更新するようなテーブルの場合、そのレコードのデータそのものは更新しないupdate文を発行することにより、更新日時を更新し、排他を行えるようにするテクニックがあります。<br>
	 * 本メソッドは、上記の「レコードのデータそのものは更新しない」で、「更新日時を更新」 します。 <br>
	 * </p>
	 * 
	 * @param sqlid SQLID
	 * @param bindList バインド値を格納したMCList
	 * @param dbc DBコンテナ
	 */
	public static void dbTsUpdateKey(String sqlid, MCList<? extends MCRow> bindList, MCDBContainer dbc) {
		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
// TODO MA対応 クエリAPIビルダーを受けると、条件が設定されてしまっている可能性があるが、、、
//		dbTsUpdateKey(sqlid, bindList, builder);
//	}
//
//	/**
//	 * キー項目を使って更新日時のみを更新します。
//	 * <P>
//	 * <B>メソッドの意義・使い方</B><BR>
//	 * ヘッダ－明細タイプのテーブルの更新や赤黒データでデータを更新するようなテーブルの場合、そのレコードのデータそのものは更新しないupdate文を発行することにより、更新日時を更新し、排他を行えるようにするテクニックがあります。<br>
//	 * 本メソッドは、上記の「レコードのデータそのものは更新しない」で、「更新日時を更新」 します。 <br>
//	 * </p>
//	 * 
//	 * @param sqlid SQLID
//	 * @param bindList バインド値を格納したMCList
//	 * @param builder クエリAPIビルダー
//	 */
//	public static void dbTsUpdateKey(String sqlid, MCList<? extends MCRow> bindList, MCQueryApiBuilder builder) {
		builder.clearSet();
		builder.addSet(builder.getBaseDbc().getKeyColumn$());
		MCLog.write(FXUDL0003);
		dbUpdateKey(sqlid, bindList, builder);
	}
	
	/**
	 * oldKeyCols で指定されたカラム名の値と同値なＤＢレコードを コンテナの固定カラムの値に更新します。
	 * 
	 * @param sqlid SQLID
	 * @param list 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @param oldKeyCols
	 * @exception MCAppException [FXUDL0008] oldKeyCols.length != keyColumn().length の場合
	 */
	public static void dbUpdateKeyAt(String sqlid, MCList<? extends MCRow> list, MCQueryApiBuilder builder, String... oldKeyCols) {
		MCDBContainer dbc = builder.getBaseDbc();
		String[] keys = dbc.getKeyColumn();
		if (oldKeyCols == null || oldKeyCols.length != keys.length) {
			throw new MCAppException(FXUDL0008);
		}
		String[] atCols = new String[oldKeyCols.length];
		for (int i = 0; i < oldKeyCols.length; i++) {
			atCols[i] = oldKeyCols[i];
		}
		builder.addWhereWithAnd(createWhere(dbc, keys, atCols, true));
		builder.buildUpdate(sqlid).executeBatchUpdate(null, list);
	}

	/**
	 * Insertを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、メッセージＩＤ FXUDL0010 が採用されます。<br>
	 * 
	 * @param insert クエリAPI
	 * @param bind 挿入するロウ
	 * @throws MCAppException [FXUDL0010] 結果が 1 件ではない場合
	 */
	public static void dbInsertEx(MCInsert insert, MCRow bind) {
		dbInsertEx(bind, insert, FXUDL0010, (Object) null);
	}

	/**
	 * Insertを実行し、結果が bindList.size() 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、メッセージＩＤ FXUDL0010 が採用されます。<br>
	 * 
	 * @param bindList 挿入するリスト
	 * @param insert クエリAPI
	 * @throws MCAppException [FXUDL0010] 結果が bindList.size() 件ではない場合
	 */
	public static void dbInsertEx(MCList<? extends MCRow> bindList, MCInsert insert) {
		dbInsertEx(bindList, insert, FXUDL0010, (Object) null);
	}

	/**
	 * Insertを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、メッセージＩＤ FXUDL0010 が採用されます。<br>
	 * 
	 * @param sqlid SQLID
	 * @param bind 挿入するロウ
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXUDL0010] 結果が 1 件ではない場合
	 */
	public static void dbInsertEx(String sqlid, MCRow bind, MCQueryApiBuilder builder) {
		dbInsertEx(sqlid, bind, builder, FXUDL0010, (Object) null);
	}

	/**
	 * Insertを実行し、結果が bindList.size() 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、メッセージＩＤ FXUDL0010 が採用されます。<br>
	 * 
	 * @param sqlid SQLID
	 * @param bindList 挿入するリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXUDL0010] 結果が bindList.size() 件ではない場合
	 */
	public static void dbInsertEx(String sqlid, MCList<? extends MCRow> bindList, MCQueryApiBuilder builder) {
		dbInsertEx(sqlid, bindList, builder, FXUDL0010, (Object) null);
	}

	/**
	 * Insertを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{3}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQLID
	 * @param bind 挿入するロウ
	 * @param builder クエリAPIビルダー
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が 1 件ではない場合
	 */
	public static void dbInsertEx(String sqlid, MCRow bind, MCQueryApiBuilder builder, String msgid, Object... values) {
		dbInsertEx(bind, builder.buildInsert(sqlid), msgid, values);
	}

	/**
	 * Insertを実行し、結果が bindList.size() 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{3}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQLID
	 * @param bindList 挿入するリスト
	 * @param builder クエリAPIビルダー
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が bindList.size() 件ではない場合
	 */
	public static void dbInsertEx(String sqlid, MCList<? extends MCRow> bindList, MCQueryApiBuilder builder, String msgid, Object... values) {
		dbInsertEx(bindList, builder.buildInsert(sqlid), msgid, values);
	}

	/**
	 * Insertを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{3}からはじめる。など） <BR>
	 * 
	 * @param bind 挿入するロウ
	 * @param insert クエリAPI
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が 1 件ではない場合
	 */
	public static void dbInsertEx(MCRow bind, MCInsert insert, String msgid, Object... values) {
		int estimateRet = 1;
		int ret = 0;
		try {
			insert.executeUpdate(bind);
		}
		catch (MCException ex) {
			if (isDupValOnIndex(ex)) {
				MCLog.write(ex);
				Object[] bindData = MCCollectionUtil.concat(new Object[] {
						estimateRet, ret
				}, values);
				throw createExceptionForKeyEx(bind, msgid, bindData);
			}
			else {
				throw ex;
			}
		}
	}

	/**
	 * Insertを実行し、結果が bindList.size() 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{3}からはじめる。など） <BR>
	 * 
	 * @param bindList 挿入するリスト
	 * @param insert クエリAPI
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が bindList.size() 件ではない場合
	 */
	public static void dbInsertEx(MCList<? extends MCRow> bindList, MCInsert insert, String msgid, Object... values) {
		int estimateRet = bindList.size();
		int ret = 0;
		try {
			insert.executeBatchUpdate(bindList);
		}
		catch (MCException ex) {
			if (isDupValOnIndex(ex)) {
				MCLog.write(ex);
				Object[] bindData = MCCollectionUtil.concat(new Object[] {
						estimateRet, ret
				}, values);
				throw createExceptionForKeyEx(null, msgid, bindData);
			}
			else {
				throw ex;
			}
		}
	}

	protected static MCAppException createExceptionForKeyEx(MCRow bind, String msgid, Object... values) {
		return new MCAppException(bind, null, nvl(msgid, defMsgIdForResultNeqEstimate()),
				values);
	}
	/**
	 * 結果が１件ではない場合のデフォルトメッセージＩＤ
	 */
	protected static String defMsgIdForResultNeqEstimate() {
		return FXUDL0001;
	}
	
	/**
	 * dbSelectKeyを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、defMsgIdForResultNeqEstimate メソッドで指定されているメッセージＩＤが採用されます。<br>
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果を格納するRow
	 * @param builder クエリAPIビルダー
	 * @param bind バインド変数の値が格納されたRow
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(String, Object...)
	 * @see #dbSelectKey(MCQueryApiBuilder, MCRow, MCList)
	 */
	public static void dbSelectKeyEx(String sqlid, MCRow result, MCQueryApiBuilder builder, MCRow bind) {
		dbSelectKeyEx(sqlid, result, builder, bind, null, (Object) null);
	}
	
	/**
	 * dbSelectKeyを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、defMsgIdForResultNeqEstimate メソッドで指定されているメッセージＩＤが採用されます。<br>
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果を格納するRow
	 * @param dbc DBコンテナ
	 * @param bind バインド変数の値が格納されたRow
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(String, Object...)
	 * @see #dbSelectKey(MCDBContainer, MCRow, MCList)
	 */
	public static void dbSelectKeyEx(String sqlid, MCRow result, MCDBContainer dbc, MCRow bind) {
		dbSelectKeyEx(sqlid, result, dbc, bind, null, (Object) null);
	}

	/**
	 * dbSelectKeyを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」、「テーブル名」、「項目名と値の文字列」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{5}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果を格納するRow
	 * @param builder クエリAPIビルダー
	 * @param bind バインド変数の値が格納されたRow
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(String, Object...)
	 * @see #dbSelectKey(MCQueryApiBuilder, MCRow, MCList)
	 */
	public static void dbSelectKeyEx(String sqlid, MCRow result, MCQueryApiBuilder builder, MCRow bind, String msgid, Object... values) {
		int ret = dbSelectKey(sqlid, result, builder, bind);
		int estimateRet = 1;
		if (ret != estimateRet) {
			Object[] bindData = MCCollectionUtil.concat(new Object[] {
					estimateRet, ret, builder.getBaseDbc().tableName(), createKeyAndValue(builder.getBaseDbc(), bind)
			}, values);
			throw createExceptionForKeyExWithTable(bind, msgid, bindData);
		}
	}

	/**
	 * dbSelectKeyを実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」、「テーブル名」、「項目名と値の文字列」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{5}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果を格納するRow
	 * @param dbc DBコンテナ
	 * @param bind バインド変数の値が格納されたRow
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(String, Object...)
	 * @see #dbSelectKey(MCDBContainer, MCRow, MCList)
	 */
	public static void dbSelectKeyEx(String sqlid, MCRow result, MCDBContainer dbc, MCRow bind, String msgid, Object... values) {
		int ret = dbSelectKey(sqlid, result, dbc, bind);
		int estimateRet = 1;
		if (ret != estimateRet) {
			Object[] bindData = MCCollectionUtil.concat(new Object[] {
					estimateRet, ret, dbc.tableName(), createKeyAndValue(dbc, result)
			}, values);
			throw createExceptionForKeyExWithTable(result, msgid, bindData);
		}
	}

	/**
	 * 結果が１件ではない場合の例外を返します。<P>
	 * 
	 * デフォルトのバインド変数の値は、以下の通りです。<br>
	 * 1 = 期待した件数<BR>
	 * 2 = 実際の結果件数<BR>
	 * 3 = テーブル名<BR>
	 * 4 = 項目名と値の文字列
	 * 
	 * @param causerow 関連するRow
	 * @param msgid メッセージID
	 * @param values バインド変数 
	 * @return 結果が１件ではない場合の例外
	 */
	protected static MCAppException createExceptionForKeyExWithTable(MCRow causerow,
			String msgid, Object... values) {
		return new MCAppException(causerow, null, 
				nvl(msgid, defMsgIdForResultNeqEstimateWithTable()),
				values);
	}

	/**
	 * 結果が１件ではない場合のデフォルトメッセージＩＤ(テーブル名称付き）
	 * 
	 */
	protected static String defMsgIdForResultNeqEstimateWithTable() {
		return FXUDL0012;
	}
	
	/**
	 * キー項目と値を結合した文字列を返します。<P>
	 * 
	 * 例)
	 * ITM_CD:AAAA
	 * DEPT_CD:BBB
	 *
	 * @param dbc DBコンテナ
	 * @param row 値が格納されたRow
	 * @return キー項目と値を結合した文字列
	 */
	public static String createKeyAndValue(MCDBContainer dbc, MCRow row) {
		StringBuilder sb = new StringBuilder();
		String[] keycol = dbc.getKeyColumn();
		for (String key : keycol) {
			sb.append(key);
			sb.append(":");
			if (row == null || row.isEmpty(key)) {
				sb.append("null");
			}
			else{
				sb.append(row.getValueNE(key));
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	/**
	 * 主キーワークテーブルを使用してテーブルのロックを行います。<p>
	 * 前提条件：テーブルに対して主キーワークテーブルが定義されていること<p>
	 * 
	 * @param sqlid 検索のSQLID
	 * @param result 検索結果
	 * @param dbc DBコンテナ
	 * @param bindL バインドリスト
	 * @param cols 追加で検索する項目（キー項目と更新カウンタは設定済み）
	 */
	public static void selectForUpdateNoWaitPkWk(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, MCList<? extends MCRow> bindL, String... cols) {
		selectPkWk(sqlid, result, dbc, bindL, true, cols);
	}

	/**
	 * 主キーワークテーブルを使用してテーブルのロックを行います。<p>
	 * 前提条件：テーブルに対して主キーワークテーブルが定義されていること<p>
	 * 
	 * @param sqlid 検索のSQLID
	 * @param result 検索結果
	 * @param dbc DBコンテナ
	 * @param bindL バインドリスト
	 * @param cols 追加で検索する項目（キー項目と更新カウンタは設定済み）
	 */
	public static void selectForUpdatePkWk(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, MCList<? extends MCRow> bindL, String... cols) {
		selectPkWk(sqlid, result, dbc, bindL, false, cols);
	}
	
	/**
	 * 主キーワークテーブルを使用してテーブルの検索を行います。<p>
	 * 前提条件：テーブルに対して主キーワークテーブルが定義されていること<p>
	 * 
	 * @param sqlid 検索のSQLID
	 * @param result 検索結果
	 * @param dbc DBコンテナ
	 * @param bindL バインドリスト
	 * @param forUpdateNoWaitFlg 「FOR UPDATE NO WAIT」を付けるときtrue
	 * @param cols 追加で検索する項目（キー項目と更新カウンタは設定済み）
	 */
	public static void selectPkWk(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, MCList<? extends MCRow> bindL, boolean forUpdateNoWaitFlg, String... cols) {
		MCDBContainer wkDbc = dbc.getPkWorkDbc("W1");
		insPkWk(null, wkDbc, bindL);
		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
		builder.setOrderByAsc(dbc.getKeyColumn$());
		builder.setSelect(dbc.getKeyColumn$());
		builder.addSelect(dbc.getColumn$(UPD_CNTR_NAME));
		for (String col : cols) {
			builder.addSelect(dbc.getColumn$(col));
		}
		setSelPkWk(builder, wkDbc, true);
		if (forUpdateNoWaitFlg) {
			builder.buildSelect(sqlid).forUpdateNoWait().executeQuery(result);
		}
		else {
			builder.buildSelect(sqlid).executeQuery(result);
		}
	}
	
	/**
	 * 主キーワークテーブルにデータを格納します。
	 */
	public static <R extends MCDBContainer> void insPkWk(String sqlid, R dbc, MCList<? extends MCRow> bindL) {
		execDbWkDelete(sqlid, dbc);
		
		List<MCFMAGExpr> values = new ArrayList<>();
		for (String col : dbc.getKeyColumn()) {
			values.add(bind(col));
		}
		sql(sqlid)
			.insert(dbc)
			.columns(dbc.getKeyColumn$())
			.values(values.toArray(new MCFMAGExpr[values.size()]))
			.executeBatchUpdate(bindL);
	}
	/**
	 * 主キーワークテーブルと結合して検索するように設定します。（パフォーマンス対応）
	 */
	public static void setSelPkWk(MCQueryApiBuilder builder, MCDBContainer wkDbc, boolean lock, String... cols) {
		if (builder == null) {
			return ;
		}
		MCDBContainer mainDbc = builder.getBaseDbc();
		String[] joinCols = (cols == null || cols.length == 0 ? mainDbc.getKeyColumn() : cols);
		if (joinCols.length == 0) {
			return ;
		}
		MCPredicate condithion =  null;
		for (String col : joinCols) {
			MCPermColumn mainCol = mainDbc.getColumn$(col);
			MCPermColumn wkCol = wkDbc.getColumn$(col);
			MCPredicate c = MCQueryApiBuilder.makeEq(mainCol, wkCol);
			if (mainDbc.isNullableColumn(col)) {
				c = c.or(MCQueryApiBuilder.makeIsNull(mainCol).and(MCQueryApiBuilder.makeIsNull(wkCol)));
			}
			condithion = condithion == null ? c : condithion.and(c);
		}
		builder.addInnerJoin(wkDbc, condithion);
		if (lock) {
			builder.setOrderByAsc(builder.getBaseDbc().getKeyColumn$());
			builder.addLockTable(builder.getBaseDbc().getColumn$(joinCols[0]));
		}
	}

	public static void sortForUpdate(MCQueryApiBuilder builder, MCList<? extends MCRow> list) {
		list.sort(sortForUpdColumn(builder));
	}

	public static String[] sortForUpdColumn(MCQueryApiBuilder builder) {
		return builder.getBaseDbc().getKeyColumn();
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * 以下の条件で、{@link #dbSelectColumn(MCDBContainer, String[], MCList, String[], MCList)}と同等の処理を行います。
	 * <li>検索条件のカラムをテーブルの項目名として使用
	 * <br><br>
	 * 上記仕様のため、検索条件のカラムは、ＤＢコンテナのカラムとして存在する必要があります。
	 * <br>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumn(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, MCList<? extends MCRow> bindList, String...cols) {
		dbSelectColumn(sqlid, result, dbc, cols, bindList, cols);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * 以下の条件で、{@link #dbSelectColumn(MCDBContainer, String[], MCList, String[], MCList)}と同等の処理を行います。
	 * <li>検索条件のカラムをテーブルの項目名として使用
	 * <br><br>
	 * 上記仕様のため、検索条件のカラムは、ＤＢコンテナのカラムとして存在する必要があります。
	 * <br>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdate(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, MCList<? extends MCRow> bindList, String... cols) {
		dbSelectColumnForUpdate(sqlid, result, dbc, cols, bindList, cols);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * 以下の条件で、{@link #dbSelectColumn(MCDBContainer, String[], MCList, String[], MCList)}と同等の処理を行います。
	 * <li>検索条件のカラムをテーブルの項目名として使用
	 * <br><br>
	 * 上記仕様のため、検索条件のカラムは、ＤＢコンテナのカラムとして存在する必要があります。
	 * <br>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdateNoWait(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, MCList<? extends MCRow> bindList, String... cols) {
		dbSelectColumnForUpdateNoWait(sqlid, result, dbc, cols, bindList, cols);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param tableColumn テーブル項目
	 * @param bindList 検索条件のList
	 * @param col 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumn(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, String tableColumn, MCList<? extends MCRow> bindList, String col) {
		dbSelectColumn(sqlid, result, dbc, new String[] {tableColumn}, bindList, new String[] {col});
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String, MCList, String, MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param tableColumn テーブル項目
	 * @param bindList 検索条件のList
	 * @param col 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdate(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, String tableColumn, MCList<? extends MCRow> bindList,
			String bindCol) {
		dbSelectColumn(dbc, sqlid, new String[] {tableColumn}, bindList, new String[] {bindCol}, result, true, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String, MCList, String, MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param tableColumn テーブル項目
	 * @param bindList 検索条件のList
	 * @param col 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdateNoWait(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, String tableColumn, MCList<? extends MCRow> bindList,
			String bindCol) {
		dbSelectColumn(dbc, sqlid, new String[] {tableColumn}, bindList, new String[] {bindCol}, result, true, true, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param tableColumns テーブル項目
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumn(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, String[] tableColumns, MCList<? extends MCRow> bindList,
			String[] bindCols) {
		dbSelectColumn(dbc, sqlid, tableColumns, bindList, bindCols, result, false, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param tableColumns テーブル項目
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdate(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, String[] tableColumns, MCList<? extends MCRow> bindList,
			String[] bindCols) {
		dbSelectColumn(dbc, sqlid, tableColumns, bindList, bindCols, result, true, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param dbc DBコンテナ
	 * @param tableColumns テーブル項目
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdateNoWait(String sqlid, MCList<? extends MCRow> result, MCDBContainer dbc, String[] tableColumns, MCList<? extends MCRow> bindList,
			String[] bindCols) {
		dbSelectColumn(dbc, sqlid, tableColumns, bindList, bindCols, result, true, true, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCDBContainer, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * Listに格納されている検索条件カラムの値がテーブル項目の値と同じデータを検索します。<br>
	 * 引数の検索条件カラムの配列要素と対応するテーブル項目の配列要素との関係はindexで関連付けられ、
	 * WHERE句で使用されます。<br>
	 * <pre>例）
	 * WHERE 0=0
	 * ...
	 * AND (
	 *     [テーブル項目配列][0] = １行目の[検索条件カラム配列][0]の値
	 * AND [テーブル項目配列][1] = １行目の[検索条件カラム配列][1]の値
	 * AND [テーブル項目配列][2] = １行目の[検索条件カラム配列][2]の値
	 * )
	 * OR (
	 *     [テーブル項目配列][0] = ２行目の[検索条件カラム配列][0]の値
	 * AND [テーブル項目配列][1] IS NULL //２行目の[検索条件カラム配列][1]の値がnullの場合
	 * AND [テーブル項目配列][2] = ２行目の[検索条件カラム配列][2]の値
	 * )
	 * ...
	 * </pre>
	 * 
	 * <b>Listについて</b><br>
	 * List内に検索条件の値が同値のRowが複数存在していても、内部でListに対して{@link MCList#groupBy(String...)}が実行されるため、
	 * 同一の条件のWHERE句が複数追加されることはありません。
	 * <p>
	 * 
	 * <b>項目名の配列要素数が0の場合</b><br>
	 * テーブル項目配列の要素数が0の場合、Listの条件は使用されずに検索処理が実行されます。
	 * <p>
	 * 
	 * <font color=red><b>注意</b></font><br>
	 * 本メソッドを使用した検索はパフォーマンスが非常に悪い場合があります。<br>
	 * 実装を見直し、他の検索条件で取得できないかを考えて、この検索を行うことが正しいと判断した場合のみ 使用して下さい。
	 * <br>
	 *
	 * @param dbc DBコンテナ
	 * @param sqlid SQLID
	 * @param tableColumns テーブル項目
	 * @param bindList 検索条件のList
	 * @param bindCols 検索条件のカラム名又はカラムパス
	 * @param result 検索結果格納先のMCList
	 * @param forupdate
	 * @param nowait
	 * @param selectAgainSize
	 */
	protected static void dbSelectColumn(MCDBContainer dbc, String sqlid, String[] tableColumns, MCList<? extends MCRow> bindList,
			String[] bindCols, MCList<? extends MCRow> result, boolean forupdate, boolean nowait, int selectAgainSize) {
		dbSelectColumn(MCQueryApiBuilder.create(dbc), sqlid, tableColumns, bindList, bindCols, result, forupdate, nowait, selectAgainSize);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * 以下の条件で、{@link #dbSelectColumn(MCQueryApiBuilder, String[], MCList, String[], MCList)}と同等の処理を行います。
	 * <li>検索条件のカラムをテーブルの項目名として使用
	 * <br><br>
	 * 上記仕様のため、検索条件のカラムは、ＤＢコンテナのカラムとして存在する必要があります。
	 * <br>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumn(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, MCList<? extends MCRow> bindList, String...cols) {
		dbSelectColumn(sqlid, result, builder, cols, bindList, cols);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * 以下の条件で、{@link #dbSelectColumn(MCQueryApiBuilder, String[], MCList, String[], MCList)}と同等の処理を行います。
	 * <li>検索条件のカラムをテーブルの項目名として使用
	 * <br><br>
	 * 上記仕様のため、検索条件のカラムは、ＤＢコンテナのカラムとして存在する必要があります。
	 * <br>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdate(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, MCList<? extends MCRow> bindList, String... cols) {
		dbSelectColumnForUpdate(sqlid, result, builder, cols, bindList, cols);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * 以下の条件で、{@link #dbSelectColumn(MCQueryApiBuilder, String[], MCList, String[], MCList)}と同等の処理を行います。
	 * <li>検索条件のカラムをテーブルの項目名として使用
	 * <br><br>
	 * 上記仕様のため、検索条件のカラムは、ＤＢコンテナのカラムとして存在する必要があります。
	 * <br>
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdateNoWait(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, MCList<? extends MCRow> bindList, String... cols) {
		dbSelectColumnForUpdateNoWait(sqlid, result, builder, cols, bindList, cols);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。
	 * <p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid			SQLID
	 * @param result       検索結果格納先のMCList
	 * @param builder      クエリAPIビルダー
	 * @param tableColumn テーブル項目
	 * @param bindList     検索条件のList
	 * @param bindCol         検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumn(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, String tableColumn,
			MCList<? extends MCRow> bindList, String bindCol) {
		dbSelectColumn(builder, sqlid, new String[] {tableColumn}, bindList, new String[] {bindCol}, result, false, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String, MCList, String, MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param tableColumn テーブル項目
	 * @param bindList 検索条件のList
	 * @param col 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdate(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, String tableColumn, MCList<? extends MCRow> bindList,
			String bindCol) {
		dbSelectColumn(builder, sqlid, new String[] {tableColumn}, bindList, new String[] {bindCol}, result, true, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String, MCList, String, MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param tableColumn テーブル項目
	 * @param bindList 検索条件のList
	 * @param col 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdateNoWait(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, String tableColumn, MCList<? extends MCRow> bindList,
			String bindCol) {
		dbSelectColumn(builder, sqlid, new String[] {tableColumn}, bindList, new String[] {bindCol}, result, true, true, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。
	 * <p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid			SQLID
	 * @param result       検索結果格納先のMCList
	 * @param builder      クエリAPIビルダー
	 * @param tableColumns テーブル項目
	 * @param bindList     検索条件のList
	 * @param cols         検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumn(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, String[] tableColumns,
			MCList<? extends MCRow> bindList, String[] bindCols) {
		dbSelectColumn(builder, sqlid, tableColumns, bindList, bindCols, result, false, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param tableColumns テーブル項目
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdate(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, String[] tableColumns, MCList<? extends MCRow> bindList,
			String[] bindCols) {
		dbSelectColumn(builder, sqlid, tableColumns, bindList, bindCols, result, true, false, -1);
	}

	/**
	 * 検索条件をListで受け取り、検索処理を行います（{@link #dbSelectKey(MCQueryApiBuilder, MCList, MCList)}のカラム名指定版）。<p>
	 * 
	 * <br>
	 * <font color=red><b>注意</b></font><br>
	 * 基本仕様および注意については{@link #dbSelectColumn(MCMainQuery, MCDBContainer, String[], MCList, String[], MCList, boolean, boolean, int)}を参照してください。
	 * 
	 * @param sqlid SQLID
	 * @param result 検索結果格納先のMCList
	 * @param builder クエリAPIビルダー
	 * @param tableColumns テーブル項目
	 * @param bindList 検索条件のList
	 * @param cols 検索条件のカラム名又はカラムパス
	 */
	public static void dbSelectColumnForUpdateNoWait(String sqlid, MCList<? extends MCRow> result, MCQueryApiBuilder builder, String[] tableColumns, MCList<? extends MCRow> bindList,
			String[] bindCols) {
		dbSelectColumn(builder, sqlid, tableColumns, bindList, bindCols, result, true, true, -1);
	}

	protected static void dbSelectColumn(MCQueryApiBuilder builder, String sqlid, String[] tableColumns,
			MCList<? extends MCRow> bindList, String[] bindCols, MCList<? extends MCRow> result, boolean forupdate,
			boolean nowait, int selectAgainSize) {
		String[] tmpTableCols = tableColumns == null ? new String[0]
				: tableColumns;
		String[] tmpBindCols = bindCols == null ? new String[0] : bindCols;

		if (tmpTableCols.length != tmpBindCols.length) {
			throw new MCAppException(FXUDL0009);
		}
		if (tmpTableCols.length == 0) {
			builder.buildSelect(sqlid).executeQuery(result);
			return;
		}

		builder.addWhereWithAnd(createWhere(builder.getBaseDbc(), tableColumns, bindCols));
		dbSelect(builder, sqlid, bindList, null, result, forupdate, nowait, -1, selectAgainSize);
	}
	


	/**
	 * bindListの行の編集ステータスに応じてinsert / update / delete を行います。 <br>
	 * 但し、更新カウンタのチェックを行いません。
	 * 
	 * @param sqlid SQL ID
	 * @param bindList 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXUDL0004] 行の編集ステータスがCREATE / MODIFY / DELETE
	 *             以外の場合（＝NONEの場合）
	 * @throws MCAppException [FXUDL0005] 新規追加行が既に登録されている場合（＝追加できない場合）
	 */
	public static void dbLockInsUpdDelByStatusNoCheck(String sqlid, MCList<? extends MCRow> bindList, MCQueryApiBuilder builder) {
		dbLockInsUpdDelByStatusCheck(sqlid, bindList, builder, false);
	}

	@SuppressWarnings("unchecked")
	protected static void dbLockInsUpdDelByStatusCheck(String sqlid, MCList<? extends MCRow> bindList, MCQueryApiBuilder builder, boolean updChk) {
		MCList<MCRow> ins = (MCList<MCRow>) bindList.subList(Status.CREATE);
		MCList<MCRow> upd = (MCList<MCRow>) bindList.subList(Status.MODIFY);
		MCList<MCRow> del = (MCList<MCRow>) bindList.subList(Status.DELETE);

		if (!isSame(bindList.size(), sum(ins.size(), upd.size(), del.size()))) {
			// try-catchされることを考慮するとインスタンスそのものを操作してはいけない
			MCList<? extends MCRow> c = bindList.clone();
			c.removeAll(ins);
			c.removeAll(upd);
			c.removeAll(del);
			throw new MCAppException(c.get(0), null, FXUDL0004, c.get(0));
		}

		// Delete
		MCList<MCRow> delLocked = (MCList<MCRow>) del.createInstance();
		MCList<MCRow> delNotLocked = (MCList<MCRow>) del.createInstance();
		if (updChk) {
			dbSortLockDivide(sqlid, builder, del, delLocked, delNotLocked);
		}
		else {
			dbSortLockDivideNoCheck(sqlid, builder, del, delLocked, delNotLocked);
		}
		for (MCRow row : delNotLocked) {
			MCMessagePool.add(new MCMessage(row, null, FXUDL0006, row));
		}
		dbDeleteKey(sqlid, delLocked, builder);

		// Update
		if (updChk) {
			dbSortLockUpd(sqlid, upd, builder);
		}
		else {
			dbSortLockUpdNoCheck(sqlid, upd, builder);
		}

		// Insert
		sortForUpdate(builder, ins);
		dbInsertEx(sqlid, ins, builder, FXUDL0005);
	}

	/**
	 * レコードのロック(SELECT FOR UPDATE NOWAIT)を行い、
	 * ロックできたらupdate、ロックできなかったらinsertします。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行い、更新(update)処理を行います</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、追加(insert)処理を行います</li>
	 * </p>
	 * 
	 * @param sqlid SQL ID
	 * @param bindList 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXUDL0010] insert処理で重複が発生した場合
	 */
	public static <R extends MCRow> void dbLockUpdIns(String sqlid, MCList<R> bindList, MCQueryApiBuilder builder) {
		dbLockUpdInsCheck(sqlid, bindList, builder, true);
	}

	/**
	 * レコードのロック(SELECT FOR UPDATE)を行い、
	 * ロックできたらupdate、ロックできなかったらinsertします。 <br>
	 * 但し、更新カウンタのチェックを行いません。
	 * <p>
	 * 以下の順に処理を行います。
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新(update)処理を行います</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、追加(insert)処理を行います</li>
	 * </p>
	 * 
	 * @param sqlid SQL ID
	 * @param bindList 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @throws MCAppException [FXUDL0010] insert処理で重複が発生した場合
	 */
	public static <R extends MCRow> void dbLockUpdInsNoCheck(String sqlid, MCList<R> bindList, MCQueryApiBuilder builder) {
		dbLockUpdInsCheck(sqlid, bindList, builder, false);
	}

	/**
	 * レコードのロックを行い、
	 * ロックできたらupdate、ロックできなかったらinsertします。 <br>
	 * 引数updChkにtrueが指定された場合は、SELECT FOR UPDATE NOWAITでロックし
	 * 更新カウンタのチェックを行います。
	 * <p>
	 * 以下の順に処理を行います。<P>
	 * 引数updChkにtrueが指定された場合<BR>
	 * <li>key項目でSELECT FOR UPDATE NOWAITを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新カウンタのチェックを行い、更新(update)処理を行います</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、追加(insert)処理を行います。</li>
	 * </p>
	 * 引数updChkにfalseが指定された場合<BR>
	 * <li>key項目でSELECT FOR UPDATEを実行します</li>
	 * <li>検索結果があった場合（ロックできた場合）、更新(update)処理を行います</li>
	 * <li>検索結果がなかった場合（ロックできなかった場合）、追加(insert)処理を行います。</li>
	 * <p>
	 * 
	 * @param sqlid SQL ID
	 * @param bindList 更新対象のリスト
	 * @param builder クエリAPIビルダー
	 * @param updChk 更新カウンタのチェックを行う場合は、true
	 * @throws MCAppException [FXUDL0010] insert処理で重複が発生した場合
	 */
	protected static <R extends MCRow> void dbLockUpdInsCheck(String sqlid, MCList<R> bindList, MCQueryApiBuilder builder, boolean updChk) {
		MCList<R> ins = bindList.createInstance();
		MCList<R> upd = bindList.createInstance();
		if (updChk) {
			dbLockDivide(sqlid, bindList, builder, upd, ins);
		}
		else {
			dbLockDivideNoCheck(sqlid, bindList, builder, upd, ins);
		}
		dbInsertEx(sqlid, ins, builder);
		dbUpdateKey(sqlid, upd, builder);
	}

	/**
	 * dbSelectKeyForUpdate(MCRow row)を実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、defMsgIdForResultNeqEstimate メソッドで指定されているメッセージＩＤが採用されます。<br>
	 * 
	 * @param sqlid SQL ID
	 * @param row 更新対象のロウ
	 * @param builder クエリAPIビルダー
	 * @param bind バインド変数の値が格納されたRow
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(MCRow, String, Object...)
	 * @see #dbSelectKeyForUpdate(String, MCRow, MCQueryApiBuilder, MCRow)
	 */
	public static void dbSelectKeyForUpdateEx(String sqlid, MCRow row, MCQueryApiBuilder builder, MCRow bind) {
		dbSelectKeyForUpdateEx(sqlid, row, builder, bind, null, (Object) null);
	}

	/**
	 * dbSelectKeyForUpdate(MCRow row)を実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」、「テーブル名」、「項目名と値の文字列」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{5}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQL ID
	 * @param row 更新対象のロウ
	 * @param builder クエリAPIビルダー
	 * @param bind バインド変数の値が格納されたRow
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(MCRow, String, Object...)
	 * @see #dbSelectKeyForUpdate(String, MCRow, MCQueryApiBuilder, MCRow)
	 */
	public static void dbSelectKeyForUpdateEx(String sqlid, MCRow row, MCQueryApiBuilder builder, MCRow bind, String msgid, Object... values) {
		dbSelectKeyForUpdateEx(sqlid, row, builder, false, bind, msgid, values); 
	}

	/**
	 * dbSelectKeyForUpdateNoWait(MCRow row)を実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、defMsgIdForResultNeqEstimate メソッドで指定されているメッセージＩＤが採用されます。<br>
	 * 
	 * @param sqlid SQL ID
	 * @param row 更新対象のロウ
	 * @param builder クエリAPIビルダー
	 * @param bind バインド変数の値が格納されたRow
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(MCRow, String, Object...)
	 * @see #dbSelectKeyForUpdateNoWait(MCQueryApiBuilder, MCRow, MCRow)
	 */
	public static void dbSelectKeyForUpdateNoWaitEx(String sqlid, MCRow row, MCQueryApiBuilder builder, MCRow bind) {
		dbSelectKeyForUpdateNoWaitEx(sqlid, row, builder, bind, null, (Object) null);
	}

	/**
	 * dbSelectKeyForUpdateNoWait(MCRow row)を実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」、「テーブル名」、「項目名と値の文字列」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{5}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQL ID
	 * @param row 更新対象のロウ
	 * @param builder クエリAPIビルダー
	 * @param bind バインド変数の値が格納されたRow
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 * @throws MCAppException 結果が 1 件ではない場合
	 * @see #createExceptionForKeyEx(MCRow, String, Object...)
	 * @see #dbSelectKeyForUpdateNoWait(MCQueryApiBuilder, MCRow, MCRow)
	 */
	public static void dbSelectKeyForUpdateNoWaitEx(String sqlid, MCRow row, MCQueryApiBuilder builder,
			MCRow bind, String msgid, Object... values) {
		dbSelectKeyForUpdateEx(sqlid, row, builder, true, bind, msgid, values);
	}
	
	/**
	 * dbSelectKeyForUpdate(MCRow row)を実行し、結果が 1 件ではない場合には、例外にします。
	 * <P>
	 * 引数isNoWaitにtrueを指定するとdbSelectKeyForUpdateNoWait(MCRow row)が実行されます。<br>
	 * 本メソッドは、前後の処理の流れから確実に結果の件数が把握できている場合のみ使用します。<br>
	 * 本メソッドを使用することにより、確実に結果の件数が把握できているにも関わらず、 期待していない結果になった場合の例外処理の記述量を減らすことができます。
	 * <P>
	 * 例外の場合は、指定されたmsgid , values を元にした例外をthrowします
	 * <P>
	 * 例外メッセージを作る際には、valuesで指定されたバインド値の先頭に、「期待した処理結果件数」と「SQLを実行した結果の件数」、「テーブル名」、「項目名と値の文字列」 を追加（割り込み）します。
	 * メッセージを作成する際にはこれを加味して作成してください。 （期待した件数、結果件数が不要ならばメッセージのバインドを{5}からはじめる。など） <BR>
	 * 
	 * @param sqlid SQL ID
	 * @param row 更新対象のロウ
	 * @param builder クエリAPIビルダー
	 * @param isNoWait NoWaitオプションを付加する場合はtrueを指定
	 * @param bind バインド変数の値が格納されたRow
	 * @param msgid 例外時に使用するメッセージID
	 * @param values 例外時に使用するバインド変数
	 */
	protected static void dbSelectKeyForUpdateEx(String sqlid, MCRow row, MCQueryApiBuilder builder, boolean isNoWait,
			MCRow bind, String msgid, Object... values) {
		int ret = 0;
		if (!isNoWait) {
			ret = dbSelectKeyForUpdate(sqlid, row, builder, bind);
		}
		else {
			ret = dbSelectKeyForUpdateNoWait(sqlid, row, builder, bind);
		}
		int estimateRet = 1;
		if (ret != estimateRet) {
			Object[] bindData = MCCollectionUtil.concat(new Object[] {
					estimateRet, ret, builder.getBaseDbc().tableName(),
					createKeyAndValue(builder.getBaseDbc(), bind)
			}, values);
			throw new MCAppException(nvl(msgid, FXUDL0012), bindData);
		}
	}

	// -----------------旧DBコンテナからの移植ここまで---------------------
	// -----------------MCQueryPlan関連ここから---------------------

	public static int executeQuery(MCRow result, MCQueryPlan plan) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), null, null);
	}

	public static int executeQuery(MCRow result, MCQueryPlan plan, MCRow bind) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bind, null);
	}

	public static int executeQuery(MCRow result, MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> mergeBinds) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bind, mergeBinds);
	}

	public static int executeQuery(MCRow result, MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> mergeBinds) {
		return MCQueryExecutorRef._executeQuery(plan, tran, bind, mergeBinds, result);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), null, null, -1);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCRow bind) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bind, null, -1);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> mergeBinds) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bind, mergeBinds, -1);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> mergeBinds, int fetchSize) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bind, mergeBinds, fetchSize);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> mergeBinds) {
		return executeQuery(result, plan, tran, bind, mergeBinds, -1);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> mergeBinds, int fetchSize) {
		return MCQueryExecutorRef._executeQuery(plan, tran, bind, mergeBinds, result, fetchSize);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCList<? extends MCRow> bindList) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bindList, null, -1, -1);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCList<? extends MCRow> bindList, MCRow otherBind) {
		return executeQuery(result, plan, MCTransactionManager.dbTran(), bindList, otherBind, -1, -1);
	}

	public static int executeQuery(MCList<? extends MCRow> result, MCQueryPlan plan, MCDBTransaction tran, MCList<? extends MCRow> bindList, MCRow otherBind, int fetchSize, int selectAgainSize) {
		return MCQueryExecutorRef._executeQuery(plan, tran, bindList, otherBind, result, fetchSize, selectAgainSize);
	}

	public static <T extends MCRow> MCCursor<T> openCursor(Class<T> rc, MCQueryPlan plan) {
		return openCursor(rc, plan, MCTransactionManager.dbTran(), null, null, -1);
	}

	public static <T extends MCRow> MCCursor<T> openCursor(Class<T> rc, MCQueryPlan plan, MCRow bind) {
		return openCursor(rc, plan, MCTransactionManager.dbTran(), bind, null, -1);
	}

	public static <T extends MCRow> MCCursor<T> openCursor(Class<T> rc, MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> mergeBinds) {
		return openCursor(rc, plan, MCTransactionManager.dbTran(), bind, mergeBinds, -1);
	}

	public static <T extends MCRow> MCCursor<T> openCursor(Class<T> rc, MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> mergeBinds, int fetchSize) {
		return openCursor(rc, plan, MCTransactionManager.dbTran(), bind, mergeBinds, fetchSize);
	}

	public static <T extends MCRow> MCCursor<T> openCursor(Class<T> rc, MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> mergeBinds) {
		return openCursor(rc, plan, tran, bind, mergeBinds, -1);
	}

	public static <T extends MCRow> MCCursor<T> openCursor(Class<T> rc, MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> mergeBinds, int fetchSize) {
		return MCQueryExecutorRef._openCursor(plan, tran, bind, mergeBinds, rc, fetchSize);
	}

	public static void executeUpdate(MCQueryPlan plan) {
		executeUpdate(plan, MCTransactionManager.dbTran(), null, null, null);
	}

	public static void executeUpdate(MCQueryPlan plan, MCRow bind) {
		executeUpdate(plan, MCTransactionManager.dbTran(), bind, null, null);
	}

	public static void executeUpdate(MCQueryPlan plan, MCRow bind, MCRow exBind) {
		executeUpdate(plan, MCTransactionManager.dbTran(), bind, exBind, null);
	}

	public static void executeUpdate(MCQueryPlan plan, MCRow bind, MCRow exBind, MCList<? extends MCRow> mergeBinds) {
		executeUpdate(plan, MCTransactionManager.dbTran(), bind, exBind, mergeBinds);
	}

	public static void executeUpdate(MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCRow exBind) {
		executeUpdate(plan, tran, bind, exBind, null);
	}

	public static void executeUpdate(MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCRow exBind, MCList<? extends MCRow> mergeBinds) {
		MCQueryExecutorRef._executeUpdate(plan, tran, bind, exBind, mergeBinds);
	}

	public static void executeBatchUpdate(MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> binds) {
		executeBatchUpdate(plan, MCTransactionManager.dbTran(), bind, binds, null);
	}

	public static void executeBatchUpdate(MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> binds, MCList<? extends MCRow> exBinds) {
		executeBatchUpdate(plan, MCTransactionManager.dbTran(), bind, binds, exBinds, null);
	}

	public static void executeBatchUpdate(MCQueryPlan plan, MCRow bind, MCList<? extends MCRow> binds, MCList<? extends MCRow> exBinds, MCList<? extends MCRow> mergeBinds) {
		executeBatchUpdate(plan, MCTransactionManager.dbTran(), bind, binds, exBinds, mergeBinds);
	}

	public static void executeBatchUpdate(MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> binds, MCList<? extends MCRow> exBinds) {
		executeBatchUpdate(plan, tran, bind, binds, exBinds, null);
	}

	public static void executeBatchUpdate(MCQueryPlan plan, MCDBTransaction tran, MCRow bind, MCList<? extends MCRow> binds, MCList<? extends MCRow> exBinds, MCList<? extends MCRow> mergeBinds) {
		MCQueryExecutorRef._executeBatchUpdate(plan, tran, bind, binds, exBinds, mergeBinds);
	}

	private static class MCQueryExecutorRef extends MCQueryExecutor {

		private static int _executeQuery(MCQueryPlan plan, MCDBTransaction tran, MCRow bind,
				MCList<? extends MCRow> mergeBinds, MCRow result) {
			return executeQuery(plan, tran, bind, mergeBinds, result);
		}

		private static int _executeQuery(MCQueryPlan plan, MCDBTransaction tran, MCRow bind,
				MCList<? extends MCRow> mergeBinds, MCList<? extends MCRow> result, int fetchSize) {
			return executeQuery(plan, tran, bind, mergeBinds, result, fetchSize);
		}

		private static int _executeQuery(MCQueryPlan plan, MCDBTransaction tran, MCList<? extends MCRow> bindList,
				MCRow bind, MCList<? extends MCRow> result, int fetchSize, int selectAgainSize) {
			return executeQuery(plan, tran, bindList, bind, result, fetchSize, selectAgainSize);
		}

		private static <T extends MCRow> MCCursor<T> _openCursor(MCQueryPlan plan, MCDBTransaction tran, MCRow bind,
				MCList<? extends MCRow> mergeBinds, Class<T> rc, int fetchSize) {
			return openCursor(plan, tran, bind, mergeBinds, rc, fetchSize);
		}

		private static void _executeUpdate(MCQueryPlan plan, MCDBTransaction tran, MCRow bind,
				MCRow exBind, MCList<? extends MCRow> mergeBinds) {
			executeUpdate(plan, tran, bind, exBind, mergeBinds);
		}

		private static void _executeBatchUpdate(MCQueryPlan plan, MCDBTransaction tran, MCRow bind,
				MCList<? extends MCRow> binds, MCList<? extends MCRow> exBinds, MCList<? extends MCRow> mergeBinds) {
			executeBatchUpdate(plan, tran, bind, binds, exBinds, mergeBinds);
		}

	}

	// -----------------MCQueryPlan関連ここまで---------------------
	//FMCB CUSTOM END
}