package mcframe.serverFXUC.FXUCL0030;

import java.util.function.Function;

import mcframe.commonCore.annotation.EI;
import mcframe.serverCore.queryapi.IFMCSQL.MCExprValue;

/**
 * "FXUCL_MCFuncCache"ロジッククラスです。
 */
@EI
public class FXUCL_MCFuncCache<T> extends FXUCL_MCFuncCache_FW<T> {
	/**
	 * @deprecated
	 */
	public FXUCL_MCFuncCache() {
	}

	/**
	 * @param function ストアドファンクション表すFunctionインタフェース。<br>
	 * 引数の実装方法は{@link FXUCL_MCFuncCache_FW#get(Comparable...)}を参照してください。
	 */
	public FXUCL_MCFuncCache(Function<Comparable<?>[], MCExprValue> func) {
		super(func);
	}
}