package mcframe.serverFXUC.FXUCL0030;

import java.util.*;

import mcframe.commonCore.notice.MCLog;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.serverCore.resource.MCConst;
import mcframe.serverCore.sys.MCSys;
import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * "FXUCL_Cache"ロジッククラスです。
 */
// Mapのジェネリクス指定が不可能なので。逆に注意深く実装すること
public class FXUCL_Cache_FW<T> {

	/**
	 * プログラムで設定されたキャッシュサイズの最大値を保持する
	 */
	protected int _pgmMaxCacheSize = -1;

	/**
	 * プログラムで設定された固定キャッシュサイズの最大値を保持する
	 */
	protected int _pgmFixMaxCacheSize = -1;

	/**
	 * 固定キャッシュサイズが設定されたかどうかを保持する
	 */
	protected boolean _hasPgmFixMaxCacheSize = false;
	
	/**
	 * キャッシュサイズの最大値を保持する
	 */
	protected int _maxCacheSize = -1;
	
	/**
	 * キャッシュサイズの最大値が初期化されたかどうかを保持する
	 */
	protected boolean _initMaxCacheSize = false;

	public static final String LOGIC_ID = "FXUCL0030";

	/**
	 * キャッシュサイズの最大値を設定する。
	 * <p>
	 * 但し、リソース設定がある場合にはそちらが優先される。
	 * 0以下の整数を指定した場合はキャッシュサイズとしてはデフォルトのキャッシュサイズになる。
	 * </p>
	 * @param size
	 */
	public void setMaxCacheSize(int size) {
		_pgmMaxCacheSize = size;
	}

	/**
	 * キャッシュサイズの最大値を設定する。
	 * <p>
	 * リソース設定がある場合でも、このメソッドで設定したキャッシュサイズが優先される。
	 * 1以上の整数で設定する。
	 * 負の整数を指定した場合は、キャッシュサイズは無制限になる。
	 * 0を指定した場合は何もしない（設定前の状態のまま）。
	 * </p>
	 * @param size
	 */
	public void setFixMaxCacheSize(int size) {
		if (size < 0) {
			_pgmFixMaxCacheSize = -1;
			_hasPgmFixMaxCacheSize = true;
		}
		else if (size > 0) {
			_pgmFixMaxCacheSize = size;
			_hasPgmFixMaxCacheSize = true;
		}
	}

	/**
	 * キャッシュサイズの最大値を取得する。
	 * <P>
	 * 0未満の値を返す場合、無制限にキャッシュする仕様（{@link #setFixMaxCacheSize(int size)}でのみ設定可）。</br>
	 * {@link #setFixMaxCacheSize(int size)}および本メソッドの仕様上、0は返さない。</br>
	 * {@link #setFixMaxCacheSize(int size)}でキャッシュサイズが設定されている場合、{@link #setFixMaxCacheSize(int size)}で設定した値を返す。</br>
	 * {@link #setMaxCacheSize(int size)}でキャッシュサイズが設定されている場合、{@link #setMaxCacheSize(int size)}で設定した値、またはリソースで指定されたキャッシュサイズを返す（リソースが優先）。</br>
	 * いずれの方法でもキャッシュサイズが設定されていない場合はデフォルト値（100）を返す。
	 * </P>
	 */
	protected int getMaxCacheSize() {
		if (!_initMaxCacheSize) {
			if (_hasPgmFixMaxCacheSize) {
				_maxCacheSize = _pgmFixMaxCacheSize;
			}
			else {
				String[] keys = getMaxCacheSizeKey();
				int xmlMaxCacheSize = -1;
				for(int i = keys.length ; i > 0 ; i-- ){
					String[] k  = MCCollectionUtil.subArray(keys, 0, i, String.class);
					xmlMaxCacheSize = MCConst.app.getInteger(MCConst.createKey(k), -1);
					if(xmlMaxCacheSize > 0 ){
						break;
					}
				}
				if (xmlMaxCacheSize > 0) {
					_maxCacheSize = xmlMaxCacheSize;
				}
				else {
					_maxCacheSize = _pgmMaxCacheSize;
					if(_maxCacheSize <= 0 ){
						// デフォルト値
						_maxCacheSize = 100;
					}
				}
			}
			_initMaxCacheSize = true;
		}
		return _maxCacheSize;
	}
	
	/**
	 * 最大のキャッシュサイズを取得するためのリソースキーの配列
	 * <p>
	 * {@link #getMaxCacheSize}では、
	 * 戻り値の０番目からＮ番目の要素で構成されたリソースキーが
	 * 存在しない場合は、戻り値の０番目からＮ－１番目の要素で
	 * 構成されたリソースキーを探すことを繰り返します。
	 * </p>
	 * 
	 * @return 最大のキャッシュサイズを取得するためのリソースキーの配列
	 */
	protected String[] getMaxCacheSizeKey() {
		String keyWd = "cache_size";
		String mid = MCSys.request.moduleId();
		String lid = MCSys.request.logicId();
		String oid = MCSys.request.operationId();
		return new String[] {
				keyWd, mid, lid, oid
		};
	}

	/**
	 * キャッシュを引数で指定されたキャッシュサイズ<B>以下</B>にします。
	 * 
	 * @param limitSize 
	 * @return 処理後のキャッシュサイズ
	 */
	protected int removeCache(int limitSize) {
		LinkedHashMap<List<Comparable<?>>, T> m = getMap();
		// 処理後のキャッシュサイズが0未満の場合は処理しない
		if (limitSize < 0) {
			return m.size();
		}

		Set<List<Comparable<?>>> keySet = m.keySet();
		Iterator<List<Comparable<?>>> iter = keySet.iterator();
		int delCnt = keySet.size() - limitSize;

		List<List<Comparable<?>>> keyForDel = new ArrayList<List<Comparable<?>>>();

		for (int i = 0; i < delCnt; i++) {
			if (!iter.hasNext()) {
				break;
			}
			keyForDel.add(iter.next());
		}

		for (List<Comparable<?>> k : keyForDel) {
			m.remove(k);
			MCLog.write(FXUCC0019, limitSize, k, m.size());
		}
		return m.size();
	}

	/**
	 * キャッシュを作成します。
	 * 
	 * @param in 条件
	 * @param tar キャッシュする値
	 */
	public void putCache(Comparable<?>[] in, T tar) {
		List<Comparable<?>> key = toKey(in);
		LinkedHashMap<List<Comparable<?>>, T> m = getMap();
		
		if (m.containsKey(key)) {
			// アクセスがあったらLinkedHashMapの iterator の
			// 一番最後になるようにするために、一度削除して再設定する。
			// (LinkedHashMap の removeしないと最後にならないため）。
			// 件数は同じなのでキャッシュサイズのチェックはしない
			m.remove(key);
		}
		int s = m.size();
		if (s + 1 >= getMaxCacheSize()) {
			removeCache(getMaxCacheSize() - 1);
		}
		m.put(key, tar);
	}

	/**
	 * キャッシュを取得します。キャッシュがない場合はnullを返します。
	 * 
	 * @param in 条件
	 * @return キャッシュされた値
	 */
	public T getCache(Comparable<?>... in) {
		List<Comparable<?>> key = toKey(in);
		LinkedHashMap<List<Comparable<?>>, T> m = getMap();
		T ret = null;
		// キーがあってnullの場合とキーがなくてnullの場合があるので条件分岐必要
		if (m.containsKey(key)) {
			// アクセスがあったらLinkedHashMapの iterator の
			// 一番最後になるようにするために、一度削除して再設定する。
			// (LinkedHashMap の removeしないと最後にならないため）。
			// 件数は同じなのでキャッシュサイズのチェックはしない
			ret = m.remove(key);
			m.put(key, ret);
		}
		return m.get(key);
	}

	/**
	 * 外部からの引数を、本クラスのキー項目用のオブジェクトに変換します。
	 * @param in
	 * @return
	 */
	protected List<Comparable<?>> toKey(Comparable<?>[] in) {
		// 配列は HashMap のキー項目に適さないので
		// List を採用する。
		List<Comparable<?>> ret = new ArrayList<Comparable<?>>();
		if (in == null) {
			return ret;
		}
		for (Comparable<?> c : in) {
			ret.add(c);
		}
		return ret;
	}

	/**
	 * キャッシュ管理を行うマップオブジェクト
	 */
	protected LinkedHashMap<List<Comparable<?>>, T> _map;

	/**
	 * キャッシュ管理を行うマップオブジェクトを返します
	 * 
	 * @return キャッシュ管理を行うマップオブジェクト
	 */
	protected LinkedHashMap<List<Comparable<?>>, T> getMap() {
		if (_map == null) {
			_map = new LinkedHashMap<List<Comparable<?>>, T>();
		}
		return _map;
	}
	// メモ
	// キャッシュ削除の基本方針：古い物から捨てる
	// 「古い物」の定義：
	// 	キャッシュに配置された順番に判定する。
	// 	但し、既に登録済みのキー値に対しての値取得
	// 	又は設定が発生した場合は
	// 	キャッシュに再配置する（結果、順番が新しくなる）。

	/**
	 * SQLID（"ロジックID:テーブル名:オペレーション名"）を返します。</p>
	 * 
	 * 子クラス（DBコンテナキャッシュ）において、DBコンテナを検索する際に利用します。<br>
	 * @param builder builder
	 * @param op オペレーション名
	 * @return SQLID
	 */
	protected String getSqlId(mcframe.serverCore.queryapi.MCQueryApiBuilder builder, String op) {
		StringBuilder sb = new StringBuilder();
		sb.append(LOGIC_ID).append(":")
				.append(builder.getBaseDbc().tableName()).append(":").append(op);
		return sb.toString();
	}
}
