package mcframe.serverFXUC.FXUCL0030;

import mcframe.commonCore.annotation.EI;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil.*;

/**
 * "FXUCL_Cache"ロジッククラスです。<p>
 *
 */
@EI
public class FXUCL_Cache<T> extends FXUCL_Cache_FW<T> {
	
	public static class MCDbcCache<T extends MCDBContainer> extends FXUCL_Cache<T> {
		protected T _dbc;

		protected MCQueryApiBuilder _builder;

		protected String _logic_id = "MCDbcCache";

		/**
		 * 「検索結果の列を絞りたい」「where句をセットしたい」などの場合は、コンストラクタにMCQueryApiBuilderをセットする前に
		 * setSelect等しておいてください。
		 * 
		 * @param dbc
		 */
		@SuppressWarnings("unchecked")
		public MCDbcCache(MCQueryApiBuilder builder) {
			T proto = (T) builder.getBaseDbc();
			_dbc = (T) proto.clone();
			_dbc.clear();
			_builder = MCQueryApiBuilder.create(_dbc);
		}

		/**
		 * inはコンストラクタで指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
		 * 
		 * @param in 検索条件及びキャッシュのキー
		 * @return
		 */
		@SuppressWarnings("unchecked")
		public T get(Comparable<?>... in) {
			T ans = super.getCache(in);
			if (ans == null) {
				T r = (T) _dbc.clone();
				r.clear();
				for (int i = 0; i < r.getKeyColumn().length; i++) {
					r.setValue(r.getKeyColumn()[i], in[i]);
				}
				dbSelectKey(_logic_id, r, _builder, r);
				putCache(in, r);
				ans = r;
			}
			return ans;
		}
	}
}