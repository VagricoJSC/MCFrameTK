package mcframe.serverFXUC.FXUCL0030;

import java.util.Arrays;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.notice.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import mcframe.commonCore.container.MCIndexKey;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.serverCore.queryapi.IFMCSQL.MCAliasedColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCBinaryPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCBooleanPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCDatePermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCNumberPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCPredicate;
import mcframe.serverCore.queryapi.IFMCSQL.MCStringPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCTimestampPermColumn;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil.*;

import static mcframe.serverFXUC.FXUCL0010.FXUCL_DataUtil.*;

/**
 * 適用開始日、適用終了日を持つマスタ専用のDBコンテナキャッシュクラスです。<br>
 * 適用開始日、適用終了日はテーブル上で、
 * 「ST_DT」「END_DT」という列名で定義されている必要があります。
 */
public class FXUCL_MCDbcCacheStEnd_FW<E extends MCDBContainer>
		extends FXUCL_Cache<MCList<E>> {
	protected E _dbc;

	/** 適用開始日、終了日保存用の一時カラムを追加したリスト */
	protected MCList<E> _listWithTmpCol;

	protected MCQueryApiBuilder _builder;

	protected String[] _KeyColsExceptStDt;

	protected MCPermColumn[] _KeyColsExceptStDt$;

	/**
	* @deprecated
	*/
	public FXUCL_MCDbcCacheStEnd_FW() {
	}

	/**
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * @param builder クエリAPIビルダ
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCQueryApiBuilder builder) {
		E proto = (E) builder.getBaseDbc();
		MCList<E> list = MCList.create(proto);
		addStEndDtSelect(builder, proto, list);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = proto;
		_builder = builder;
		_listWithTmpCol = list;
	}

	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCList<E> result, MCQueryApiBuilder builder) {
		E proto = (E) builder.getBaseDbc();
		addStEndDtSelect(builder, proto, result);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		_listWithTmpCol = result;
		_listWithTmpCol.clear(_listWithTmpCol.getNameArray());
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。<br>
	 * ※適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * <P>
	 * ・bindColsは引数で指定したDBContainerのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * ・bindColsには、適用開始日を含めないでください。<br>
	 * （キーが「品目ＣＤ」「発注先ＣＤ」「適用開始日」のマスタの場合、
	 * 「品目ＣＤ」と「発注先ＣＤ」のカラム名のみを指定してください。）
	 * </P>
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * </P>
	 * <P>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * このときのサイズはリソースで指定したサイズかデフォルトのサイズになります。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCQueryApiBuilder builder, MCList<?> bindList,
			String... bindCols) {
		E proto = (E) builder.getBaseDbc();
		MCList<E> list = MCList.create(proto);
		addStEndDtSelect(builder, proto, list);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = proto;
		_builder = builder;
		_listWithTmpCol = list;
		putCache(MCList.create(_dbc), _builder, bindList, bindCols);
	}

	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCList<E> result, MCQueryApiBuilder builder,
			MCList<?> bindList, String... bindCols) {
		E proto = (E) builder.getBaseDbc();
		addStEndDtSelect(builder, proto, result);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		_listWithTmpCol = result;
		putCache(result, _builder, bindList, bindCols);
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。<br>
	 * ※適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * <P>
	 * ・bindColsは引数で指定したDBContainerのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * ・bindColsには、適用開始日を含めないでください。<br>
	 * （キーが「品目ＣＤ」「発注先ＣＤ」「適用開始日」のマスタの場合、
	 * 「品目ＣＤ」と「発注先ＣＤ」のカラム名のみを指定してください。）
	 * </P>
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * </P>
	 * <P>
	 * 内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCQueryApiBuilder builder, int cacheSize,
			MCList<?> bindList, String... bindCols) {
		setMaxCacheSize(cacheSize);
		E proto = (E) builder.getBaseDbc();
		MCList<E> list = MCList.create(proto);
		addStEndDtSelect(builder, proto, list);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = proto;
		_builder = builder;
		_listWithTmpCol = list;
		putCache(MCList.create(_dbc), _builder, bindList, bindCols);
	}

	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCList<E> result, MCQueryApiBuilder builder,
			int cacheSize, MCList<?> bindList, String... bindCols) {
		setMaxCacheSize(cacheSize);
		E proto = (E) builder.getBaseDbc();
		addStEndDtSelect(builder, proto, result);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		_listWithTmpCol = result;
		putCache(result, _builder, bindList, bindCols);
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。<br>
	 * ※適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * <P>
	 * ・bindColsは引数で指定したDBContainerのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * ・bindColsには、適用開始日を含めないでください。<br>
	 * （キーが「品目ＣＤ」「発注先ＣＤ」「適用開始日」のマスタの場合、
	 * 「品目ＣＤ」と「発注先ＣＤ」のカラム名のみを指定してください。）
	 * </P>
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * </P>
	 * <P>
	 * 引数fixCacheSizeがtrueの場合、内部の処理で{@link #setFixMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します。<br>
	 * 引数fixCacheSizeがfalseの場合、内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param fixCacheSize キャッシュサイズをプログラムで固定するかどうか
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCQueryApiBuilder builder, boolean fixCacheSize,
			int cacheSize, MCList<?> bindList, String... bindCols) {
		setMaxCacheSize(fixCacheSize, cacheSize);
		E proto = (E) builder.getBaseDbc();
		MCList<E> list = MCList.create(proto);
		addStEndDtSelect(builder, proto, list);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = proto;
		_builder = builder;
		_listWithTmpCol = list;
		putCache(MCList.create(_dbc), _builder, bindList, bindCols);
	}

	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheStEnd_FW(MCList<E> result, MCQueryApiBuilder builder,
			boolean fixCacheSize, int cacheSize, MCList<?> bindList, String... bindCols) {
		setMaxCacheSize(fixCacheSize, cacheSize);
		E proto = (E) builder.getBaseDbc();
		addStEndDtSelect(builder, proto, result);
		setDbcWhere(builder, getKeyColsExceptStDt(proto));
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		_listWithTmpCol = result;
		putCache(result, _builder, bindList, bindCols);
	}

	protected void setMaxCacheSize(boolean fixCacheSize, int cacheSize) {
		if (fixCacheSize) {
			setFixMaxCacheSize(cacheSize);
		}
		else {
			setMaxCacheSize(cacheSize);
		}
	}

	/**
	 * 適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	protected void putCache(MCList<E> list, MCQueryApiBuilder builder, MCList<?> bindList,
			String... bindCols) {
		if (bindList.isEmpty()) {
			return;
		}
		MCList<?> distincted = bindList.groupBy(bindCols);
		int upperIndex = getMaxCacheSize();

		// 最大キャッシュ件数が0以上の場合、間引く
		if (upperIndex >= 0) {
			if (distincted.size() > upperIndex) {
				distincted = distincted.subList(0, upperIndex);
			}
		}
		list.clear();// このリストにカラムを追加して、バインド値をセットする
		String[] exceptStDtCols = getKeyColsExceptStDt(_dbc);
		MCPermColumn[] exceptStDtCols$ = getKeyCols$ExceptStDt(_dbc);
		String[] tmpKeyCols = new String[exceptStDtCols.length];

		for (int i = 0; i < exceptStDtCols.length; i++) {
			MCDataType dType = list.getDataType(exceptStDtCols[i]);
			String tempKeyColumnName = getTempKeyColumnName(exceptStDtCols[i]);
			tmpKeyCols[i] = tempKeyColumnName;
			MCAliasedColumn aCol = null;
			if (dType == MCDataType.BINARY) {
				list.addBinaryColumn(tempKeyColumnName);
				MCBinaryPermColumn c = (MCBinaryPermColumn) exceptStDtCols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.BOOLEAN) {
				list.addBooleanColumn(tempKeyColumnName);
				MCBooleanPermColumn c = (MCBooleanPermColumn) exceptStDtCols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.DATE) {
				list.addDateColumn(tempKeyColumnName);
				MCDatePermColumn c = (MCDatePermColumn) exceptStDtCols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.NUMBER) {
				list.addNumberColumn(tempKeyColumnName);
				MCNumberPermColumn c = (MCNumberPermColumn) exceptStDtCols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.STRING) {
				list.addStringColumn(tempKeyColumnName);
				MCStringPermColumn c = (MCStringPermColumn) exceptStDtCols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.TIMESTAMP) {
				list.addTimestampColumn(tempKeyColumnName);
				MCTimestampPermColumn c = (MCTimestampPermColumn) exceptStDtCols$[i];
				aCol = c.as(tempKeyColumnName);
			}

			if (aCol != null) {
				builder.addSelect(aCol);
			}
		}

		for (int index = 0; index < distincted.size(); index++) {
			MCRow r = distincted.get(index);
			E dbcRow = list.createRow();
			dbcRow.setValues(exceptStDtCols, r, bindCols);
			list.add(dbcRow);
		}
		addStEndDtSelect(builder, _dbc, list);
		setDbcWhere(builder, exceptStDtCols);
		dbSelect(getSqlId(builder, "select"), list, builder, list);

		MCIndexKey tmpKeyIdx = list.createIndex(tmpKeyCols);
		for (MCRow bindRow : distincted) {
			Comparable<?>[] bindVals = new Comparable[bindCols.length];
			for (int i = 0; i < bindCols.length; i++) {
				bindVals[i] = bindRow.getValue(bindCols[i]);
			}
			putCache(bindVals, (MCList<E>) list.subList(tmpKeyIdx, bindVals));
		}
	}

	/**
	 * @return ST_DTを除いたキー項目名の配列
	 */
	protected String[] getKeyColsExceptStDt(E dbc) {
		if (_KeyColsExceptStDt == null) {
			String[] keyColumn = dbc.getKeyColumn();
			String[] upperCaseKeyColumn = new String[keyColumn.length];
			for (int i = 0; i < keyColumn.length; i++) {
				upperCaseKeyColumn[i] = keyColumn[i].toUpperCase();
			}
			_KeyColsExceptStDt = MCCollectionUtil.remove(upperCaseKeyColumn,
					new String[0], getStDtColumnName().toUpperCase());
		}
		return _KeyColsExceptStDt;
	}

	/**
	 * @return ST_DTを除いたキー項目の配列
	 */
	protected MCPermColumn[] getKeyCols$ExceptStDt(E dbc) {
		if (_KeyColsExceptStDt$ == null) {
			MCPermColumn st_dt = dbc.getColumn$(getStDtColumnName());
			MCPermColumn[] keyColumn$ = dbc.getKeyColumn$();
			_KeyColsExceptStDt$ = MCCollectionUtil.remove(keyColumn$, new MCPermColumn[0],
					st_dt);
		}
		return _KeyColsExceptStDt$;
	}

	/**
	 * 適用開始日を除いたキー項目に対するwhere句を設定する。<br>
	 * (元のwhere句は破棄される)
	 */
	protected void setDbcWhere(MCQueryApiBuilder builder, String[] exceptStDtCols) {
		MCPredicate whereClause = createWhere(builder.getBaseDbc(), exceptStDtCols,
				exceptStDtCols);
		builder.setWhere(whereClause);
	}

	/**
	 * 適用開始日、終了日保存用のselect句と一時カラムを追加する。
	 * @param dbc
	 */
	protected void addStEndDtSelect(MCQueryApiBuilder builder, E dbc, MCList<E> list) {
		MCDatePermColumn st_dt = (MCDatePermColumn) dbc.getColumn$(getStDtColumnName());
		MCDatePermColumn end_dt = (MCDatePermColumn) dbc.getColumn$(getEndDtColumnName());
		String tmpst_dt = getTempKeyColumnName(getStDtColumnName());
		String tmpend_dt = getTempKeyColumnName(getEndDtColumnName());
		builder.addSelect(st_dt.as(tmpst_dt)).addSelect(end_dt.as(tmpend_dt));
		list.addDateColumn(tmpst_dt);
		list.addDateColumn(tmpend_dt);
	}

	/**
	 * ＤＢＣのキー項目から、キー値及び適用終了日の保存用の一時カラム名を作成するために使用する接頭辞
	 * @see #getTempKeyColumnName(String)
	 */
	protected String _keyColumnPrefix = "tmp0";

	/**
	 * ＤＢＣのキー項目から、キー値及び適用終了日の保存用の一時カラム名を作成するために使用する接頭辞
	 * @see #getTempKeyColumnName(String)
	 */
	protected String getKeyColumnPrefix() {
		return _keyColumnPrefix;
	}

	/**
	 * ＤＢＣのキー項目から、キー値及び適用終了日の保存用の一時カラム名を作成するために使用する接頭辞
	 * を設定する。
	 * @see #getTempKeyColumnName(String)
	 */
	public void setKeyColumnPrefix(String columnName) {
		_keyColumnPrefix = columnName;
	}

	/**
	 * キー値及び適用終了日の保存用の一時カラム名を作成する。
	 * <P>
	 * ここで作成するカラムは、すでに存在するカラムと異なる
	 * カラム名である必要があります。デフォルトのカラム名で
	 * すでに存在するカラムと重複する場合は {@link #setKeyColumnPrefix(String)}
	 * で作成するカラム名を調整することができます。
	 * </P>
	 * @param keyColumnName ＤＢＣのキー項目名
	 * @return キー値保存用の一時カラム名
	 */
	protected String getTempKeyColumnName(String keyColumnName) {
		return getKeyColumnPrefix() + keyColumnName;
	}

	/**
	 * 適用開始日のカラム名
	 */
	protected String _stDtColumnName = "ST_DT";

	/**
	 * 適用開始日のカラム名を取得する。
	 * @return
	 */
	protected String getStDtColumnName() {
		return _stDtColumnName;
	}

	/**
	 * 適用開始日のカラム名を設定する。
	 * @param stDtColumnName
	 */
	protected void setStDtColumnName(String stDtColumnName) {
		_stDtColumnName = stDtColumnName;
	}

	/**
	 * 適用終了日のカラム名
	 */
	protected String _endDtColumnName = "END_DT";

	/**
	 * 適用終了日のカラム名を取得する。
	 * @return
	 */
	protected String getEndDtColumnName() {
		return _endDtColumnName;
	}

	/**
	 * 適用開始日のカラム名を設定する。
	 * @param endDtColumnName
	 */
	protected void setEndDtColumnName(String endDtColumnName) {
		_endDtColumnName = endDtColumnName;
	}

	/**
	 * masterDt, inに対応するキャッシュがあればそれを返します。ない場合は、コンストラクタで設定されたMCQueryApiBuilderを使い、 対応する値を検索します。<br>
	 * inはコンストラクタで指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * マスタ適用日はmasterDtに指定し、inには含めないでください。
	 * <P>
	 * サンプル
	 * 
	 * <pre>
	 * protected FXUCL_MCDbcCacheStEnd&lt;CM_ITM_INSP_R&gt; _itmInspCache;
	 * protected FXUCL_MCDbcCacheStEnd&lt;CM_ITM_INSP_R&gt; getItmInspCache() {
	 *	if( _itmInspCache == null ){
	 *		CM_ITM_INSP_R dbc = CM_ITM_INSP_R.create();
	 * 		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
	 *		dbc.setSelect(dbc.lmt_ctl_flg);
	 *		_itmInspCache = new FXUCL_MCDbcCacheStEnd&lt;CM_ITM_INSP_R&gt;(
	 *			builder, up0(), Lot_Upd01_CndR.$itm_cd, Lot_Upd01_CndR.$rev_no,
	 *			Lot_Upd01_CndR.$ppln_grp_cd);
	 * 	}
	 * 	return _itmInspCache;
	 * }
	 * protected String hoge2(HogeR r) {
	 * 	....
	 * 	fooR.lmt_ctl_flg(getItmInspCache().get(r.master_dt(), r.itm_cd(), r.rev_no() r.ppln_grp_cd()).lmt_ctl_flg());
	 * 	....
	 * }
	 * </pre>
	 * 
	 * @param masterDt マスタ適用日
	 * @param in マスタ適用日を除いたキー項目の値（MCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。）
	 * @return
	 */
	public E get(MCDate masterDt, Comparable<?>... in) {
		MCList<E> ans = super.getCache(in);
		if (ans == null) {
			MCList<E> list = _listWithTmpCol.clone();
			E bindRow = list.createRow();
			list.clear();
			String[] exceptStDtCols = getKeyColsExceptStDt(_dbc);
			for (int i = 0; i < exceptStDtCols.length; i++) {
				bindRow.setValue(exceptStDtCols[i], in[i]);
			}
			MCLog.write(FXUCC0020, Arrays.toString(in), this.getClass().getSimpleName());
			_builder.buildSelect(getSqlId(_builder, "select")).executeQuery(bindRow, list);
			putCache(in, list);
			ans = list;
		}
		else {
			MCLog.write(FXUCC0021, Arrays.toString(in), this.getClass().getSimpleName());
		}
		return getValidRec(masterDt, ans);
	}

	/**
	 * 適用開始日、終了日の範囲内にあるレコードを取得する。
	 * @param masterDt
	 * @param list
	 * @return
	 */
	protected E getValidRec(MCDate masterDt, MCList<E> list) {
		if (!isNull(masterDt) && !list.isEmpty()) {
			for (E r : list) {
				MCDate stDt = r.getDateNE(getTempKeyColumnName(getStDtColumnName()));
				MCDate endDt = r.getDateNE(getTempKeyColumnName(getEndDtColumnName()));
				//マスタメンテナンス画面で、期間の重複は排除しているので、
				//期間の重複があることは考慮していない。
				//※仮に複数マッチするレコードが合った場合、
				//採用されるレコードは不定
				if (masterDt.gte(stDt) && masterDt.lte(endDt)) {
					return r;
				}
			}
		}
		return list.createRow();
	}

	/**
	 * masterDt, inに対応するキャッシュがあればそれを返します。ない場合は、コンストラクタで設定されたMCQueryApiBuilderを使い、 対応する値を検索します。<br>
	 * レコードが取得できなかった場合は、例外がthrowされます。(FXUDL0001)<br>
	 * inはコンストラクタで指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * マスタ適用日はmasterDtに指定し、inには含めないでください。
	 * <P>
	 * サンプル
	 * 
	 * <pre>
	 * protected FXUCL_MCDbcCacheStEnd&lt;CM_ITM_INSP_R&gt; _itmInspCache;
	 * protected FXUCL_MCDbcCacheStEnd&lt;CM_ITM_INSP_R&gt; getItmInspCache() {
	 *	if( _itmInspCache == null ){
	 *		CM_ITM_INSP_R dbc = CM_ITM_INSP_R.create();
	 * 		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
	 *		dbc.setSelect(dbc.lmt_ctl_flg);
	 *		_itmInspCache = new FXUCL_MCDbcCacheStEnd&lt;CM_ITM_INSP_R&gt;(
	 *			builder, up0(), Lot_Upd01_CndR.$itm_cd, Lot_Upd01_CndR.$rev_no,
	 *			Lot_Upd01_CndR.$ppln_grp_cd);
	 * 	}
	 * 	return _itmInspCache;
	 * }
	 * protected String hoge2(HogeR r) {
	 * 	....
	 * 	fooR.lmt_ctl_flg(getItmInspCache().getEx(r.master_dt(), r.itm_cd(), r.rev_no() r.ppln_grp_cd()).lmt_ctl_flg());
	 * 	....
	 * }
	 * </pre>
	 * 
	 * @param masterDt マスタ適用日
	 * @param in マスタ適用日を除いたキー項目の値（DBContainerのgetKeyColumnに対応した順番でセットされている必要があります。）
	 * @return
	 * @throws [FXUDL0001] レコードが取得できなかった場合
	 */
	public E getEx(MCDate masterDt, Comparable<?>... in) {
		MCList<E> ans = super.getCache(in);
		if (ans == null) {
			MCList<E> list = _listWithTmpCol.clone();
			E bindRow = list.createRow();
			list.clear();
			String[] exceptStDtCols = getKeyColsExceptStDt(_dbc);
			for (int i = 0; i < exceptStDtCols.length; i++) {
				bindRow.setValue(exceptStDtCols[i], in[i]);
			}
			_builder.buildSelect(getSqlId(_builder, "select")).executeQuery(bindRow, list);

			putCache(in, list);
			ans = list;
		}

		E ret = getValidRec(masterDt, ans);
		if (ret.isEmpty()) {
			throw new MCAppException(ret, null, FXUDL0001, 1, 0);
		}
		return ret;
	}

	@Override
	protected String[] getMaxCacheSizeKey() {
		String[] keys = super.getMaxCacheSizeKey();
		String tbl = _dbc.tableName();
		String[] ret = new String[keys.length + 1];
		for (int i = 0; i < keys.length; i++) {
			ret[i] = keys[i];
		}
		ret[ret.length - 1] = tbl;
		return ret;
	}

}
