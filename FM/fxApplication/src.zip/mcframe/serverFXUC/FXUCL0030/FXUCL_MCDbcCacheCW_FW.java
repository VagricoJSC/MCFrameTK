package mcframe.serverFXUC.FXUCL0030;

import java.util.Arrays;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * "FXUCL_MCDbcCacheCW"ロジッククラスです。
 */
public class FXUCL_MCDbcCacheCW_FW<T extends MCDBContainer> extends FXUCL_Cache<T> {
	protected T _dbc;

	protected MCQueryApiBuilder _builder;

	/**
	 * @deprecated
	 */
	public FXUCL_MCDbcCacheCW_FW() {
	}

	/**
	 * 「検索結果の列を絞りたい」「where句をセットしたい」などにの場合は、
	 * コンストラクタにMCQueryApiBuilderをセットする前に setSelect等しておいてください。
	 *
	 * @param builder クエリAPIビルダ
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCacheCW_FW(MCQueryApiBuilder builder) {
		T proto = (T) builder.getBaseDbc();
		_dbc = (T) proto.clone();
		_dbc.clear();
		_builder = builder;
	}

	/**
	 * inに対応する検索結果があればそれを返します。ない場合は、コンストラクタで
	 * 設定されたMCQueryApiBuilderを使い、 対応する値を検索します。<br>
	 * 引数の in は、以下の２つの用途で使用します。
	 * <ul>
	 * <li>キャッシュのキーとして使用する</li>
	 * <li>検索のバインド値として使用する</li>
	 * </ul>
	 * <P>
	 * キャッシュのN番目のキー値をバインド値にセットする場合は、where句を追加する
	 * 際に、バインド値を指定する際に「:b(N+1)」と指定してください（サンプル参照）
	 * </P>
	 * <P>
	 * サンプル
	 * <pre>
	 * private FXUCL_MCDbcCacheCW&lt;CM_ITM_OPER_R&gt; _itmOperCache;
	 * protected FXUCL_MCDbcCacheCW&lt;CM_ITM_OPER_R&gt; itmOperCache() {
	 * 	if( _itmOperCache == null ){
	 * 		CM_ITM_OPER_R dbc = CM_ITM_OPER_R.create();
	 * 		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.itm_cd.eq(bind(b1)));
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.rev_no.eq(bind(b2)));
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.itm_ptn.eq(bind(b3)));
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.oper_ctl_no.eq(bind(b4)));
	 * 		builder.addWhereWithAnd(dbc.oper_lt.gte(value(0)));
	 * 		builder.setSelect(dbc.oper_lt);
	 * 		_itmOperCache = new FXUCL_MCDbcCacheCW&lt;CM_ITM_OPER_R&gt;(dbc);
	 * 	}
	 * 	return _itmOperCache;
	 * }
	 * protected String hoge2(HogeR r) {
	 * 	....
	 *  CM_ITM_OPER_R d = itmOperCache().get(r.itm_cd(),r.rev_no(),r.itm_ptn(),r.oper_ctl_no());
	 * 	fooR.oper_lt(d.oper_lt());
	 * 	....
	 * }
	 * </pre>
	 * </P>
	 *
	 * @param in 検索条件及びキャッシュのキー
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public T get(Comparable<?>... in) {
		T ans = super.getCache(in);
		if (ans == null) {
			T r = (T) _dbc.clone();
			r.clear();
			MCRow bind = MCRow.create();

			for (int i = 0; i < in.length; i++) {
				bind.setValueNE("b" + String.valueOf(i + 1), in[i]);
			}

			MCLog.write(FXUCC0020, Arrays.toString(in), this.getClass().getSimpleName());
			_builder.buildSelect(getSqlId(_builder, "select")).executeQuery(bind, r);
			putCache(in, r);
			ans = r;
		}
		else {
			MCLog.write(FXUCC0021, Arrays.toString(in), this.getClass().getSimpleName());
		}
		return ans;
	}

	/**
	 * inに対応する検索結果があればそれを返します。ない場合は、
	 * コンストラクタで設定されたMCQueryApiBuilderを使い、 対応する値を検索します。
	 * 検索結果が１件ではない場合は例外が発生します。<br>
	 * 引数の in は、以下の２つの用途で使用します。
	 * <ul>
	 * <li>キャッシュのキーとして使用する</li>
	 * <li>検索のバインド値として使用する</li>
	 * </ul>
	 * <P>
	 * キャッシュのN番目のキー値をバインド値にセットする場合は、where句を追加する
	 * 際に、バインド値を指定する際に「:b(N+1)」と指定してください（サンプル参照）
	 * </P>
	 * <P>
	 * サンプル
	 * <pre>
	 * private FXUCL_MCDbcCacheCW&lt;CM_ITM_OPER_R&gt; _itmOperCache;
	 * protected FXUCL_MCDbcCacheCW&lt;CM_ITM_OPER_R&gt; itmOperCache() {
	 * 	if( _itmOperCache == null ){
	 * 		CM_ITM_OPER_R dbc = CM_ITM_OPER_R.create();
	 * 		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.itm_cd.eq(bind(b1)));
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.rev_no.eq(bind(b2)));
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.itm_ptn.eq(bind(b3)));
	 * 		builder.addWhereWithAnd(CM_ITM_OPER_R.oper_ctl_no.eq(bind(b4)));
	 * 		builder.addWhereWithAnd(dbc.oper_lt.gte(value(0)));
	 * 		builder.setSelect(dbc.oper_lt);
	 * 		_itmOperCache = new FXUCL_DbcCacheCW&lt;CM_ITM_OPER_R&gt;(dbc);
	 * 	}
	 * 	return _itmOperCache;
	 * }
	 * protected String hoge2(HogeR r) {
	 * 	....
	 *  CM_ITM_OPER_R d = itmOperCache().get(r.itm_cd(),r.rev_no(),r.itm_ptn(),r.oper_ctl_no());
	 * 	fooR.oper_lt(d.oper_lt());
	 * 	....
	 * }
	 * </pre>
	 * </P>
	 *
	 * @param in 検索条件及びキャッシュのキー
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public T getEx(Comparable<?>... in) {
		T ans = super.getCache(in);
		if (ans == null) {
			T r = (T) _dbc.clone();
			r.clear();
			MCRow bind = MCRow.create();
			for (int i = 0; i < in.length; i++) {
				bind.setValueNE("b" + String.valueOf(i + 1), in[i]);
			}
			int ret = _builder.buildSelect(getSqlId(_builder, "select")).executeQuery(bind, r);
			if (ret != 1) {
				throw new MCAppException(FXUDL0001, 1, ret);
			}
			putCache(in, r);
			ans = r;
		}
		return ans;
	}

	@Override
	protected String[] getMaxCacheSizeKey() {
		String[] keys = super.getMaxCacheSizeKey();
		String tbl = _dbc.tableName();
		String[] ret = new String[keys.length + 1];
		for (int i = 0; i < keys.length; i++) {
			ret[i] = keys[i];
		}
		ret[ret.length - 1] = tbl;
		return ret;
	}
}
