package mcframe.serverFXUC.FXUCL0030;

import java.util.*;
import java.util.function.Function;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;

import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.serverCore.queryapi.IFMCSQL.*;

/**
 * "FXUCL_MCFuncCache"ロジッククラスです。
 * <p>
 * 実装仕様書から自動生成されるクラスです。
 */
public class FXUCL_MCFuncCache_FW<T> extends FXUCL_Cache<T> {

	private static final String sqlid = "FXUCL0030:FXUCL_MCFuncCache:select";

	private static final String funcCol = "rtn";

	protected Function<Comparable<?>[], MCExprValue> _function;

	/**
	 * @deprecated
	 */
	public FXUCL_MCFuncCache_FW() {
	}

	/**
	 * @param function ストアドファンクション表すFunctionインタフェース。<br>
	 * 引数の実装方法は{@link #get(Comparable...)}を参照してください。
	 */
	public FXUCL_MCFuncCache_FW(Function<Comparable<?>[], MCExprValue> function) {
		_function = function;
	}

	/**
	 * inに対応するファンクションの実行結果があればそれを返します。ない場合は、コンストラクタで設定された ファンクションを使い、 対応する値を取得します。
	 * inはコンストラクタで指定したファンクションの引数に対応した順番でセットされている必要があります。
	 * <P>
	 * 
	 * <PRE>
	 * protected void getDptcdNE() {
	 * 	FXUCL_MCFuncCache&lt;String&gt; _funcCache = new FXUCL_MCFuncCache&lt;&gt;(in -> {
	 *  	return MAPA_DPT$F_GET_DPT_CD_NE(
	 *  		value((String)in[0]),// ファンクションの引数の型にキャストする
	 *  		value((MCDate)in[1]),// ファンクションの引数の型にキャストする
	 *   		); 
	 *  	});
	 * 	MCLog.developDebug(&quot;cache : &quot; + _funcCache.get(&quot;dpt1&quot;, MCDate.now())); // ファンクションが実行される
	 * 	MCLog.developDebug(&quot;cache : &quot; + _funcCache.get(&quot;dpt2&quot;, MCDate.now())); // ファンクションが実行される
	 * 	MCLog.developDebug(&quot;cache : &quot; + _funcCache.get(&quot;dpt1&quot;, MCDate.now())); // キャッシュが使われる
	 * }
	 * </PRE>
	 * 
	 * @param in ファンクションを実行するときの引数 兼 キャッシュのキー
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public T get(Comparable<?>... in) {
		boolean isContainsKey = getMap().containsKey(toKey(in));
		T tar;
		if (!isContainsKey) {
			MCLog.write(FXUCC0020, Arrays.toString(in), this.getClass().getSimpleName());
			MCAliasedColumn col = MCQueryApiBuilder
					.castToAliasedColumn(_function.apply(in), funcCol);
			MCRow result = MCRow.create();
			sql(sqlid).mainQuery().select(col).executeQuery(result);
			tar = (T) result.getValueNE(funcCol);
			putCache(in, tar);
		}
		else {
			MCLog.write(FXUCC0021, Arrays.toString(in), this.getClass().getSimpleName());
			tar = getCache(in);
		}
		return tar;
	}
}
