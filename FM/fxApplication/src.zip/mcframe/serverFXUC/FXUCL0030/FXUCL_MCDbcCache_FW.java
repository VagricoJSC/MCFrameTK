package mcframe.serverFXUC.FXUCL0030;

import java.util.*;

import mcframe.commonCore.container.MCIndexKey;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.notice.*;
import mcframe.serverCore.queryapi.IFMCSQL.MCAliasedColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCBinaryPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCBooleanPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCDatePermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCNumberPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCStringPermColumn;
import mcframe.serverCore.queryapi.IFMCSQL.MCTimestampPermColumn;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;
import static mcframe.serverFXUC.FXUCL0020.FXUCL_MCDbUtil.*;

import static mcframe.commonFX.notice.FX_Msg.*;

/**
 * "FXUCL_MCDbcCache"ロジッククラスです。
 */
public class FXUCL_MCDbcCache_FW<T extends MCDBContainer> extends FXUCL_Cache<T> {
	protected T _dbc;

	protected MCQueryApiBuilder _builder;
	
	protected boolean _isZeroCache;
	
	protected T emptyRow;
	
	//Junitテスト用。select文を実行した回数。
	int testSelectCount = 0;

	/**
	 * @deprecated
	 */
	public FXUCL_MCDbcCache_FW() {
	}

	/**
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。 
	 * @param builder クエリAPIビルダ
	 */
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder) {
		this(builder, true);
	}
	
	/**
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。 
	 * @param builder クエリAPIビルダ
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, boolean isZeroCache) {
		_isZeroCache = isZeroCache;
		T proto = (T) builder.getBaseDbc();
		_dbc = (T) proto.clone();
		_dbc.clear();
		_builder = builder;
		emptyRow = (T) _dbc.clone();
	}
	
	/**
	 * ＤＢコンテナをキャッシュするオブジェクトを作成し、
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCache_FW(MCList, MCQueryApiBuilder, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * <P>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * このときのサイズはリソースで指定したサイズかデフォルトのサイズになります。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, MCList<?> bindList,
			String... bindCols) {
		this(builder, bindList, true, bindCols);
	}

	/**
	 * ＤＢコンテナをキャッシュするオブジェクトを作成し、
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCache_FW(MCList, MCQueryApiBuilder, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * <P>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * このときのサイズはリソースで指定したサイズかデフォルトのサイズになります。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, MCList<?> bindList, boolean isZeroCache,
			String... bindCols) {
		_isZeroCache = isZeroCache;
		T proto = (T) builder.getBaseDbc();
		_dbc = (T) proto.clone();
		_dbc.clear();
		_builder = builder;
		emptyRow = (T) _dbc.clone();
		putCache(MCList.create(_dbc), builder, bindList, bindCols);
	}

	/**
	 * @see #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, MCList, String...)
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	public FXUCL_MCDbcCache_FW(MCList<T> result, MCQueryApiBuilder builder, MCList<?> bindList,
			String... bindCols) {
		this(result, builder, bindList, true, bindCols);
	}
	
	/**
	 * @see #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, MCList, String...)
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCList<T> result, MCQueryApiBuilder builder, MCList<?> bindList,
			boolean isZeroCache, String... bindCols) {
		_isZeroCache = isZeroCache;
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		emptyRow = (T) _dbc.clone();
		putCache(result, builder, bindList, bindCols);
	}

	/**
	 * ＤＢコンテナをキャッシュするオブジェクトを作成し、
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCache_FW(MCList, MCQueryApiBuilder, int, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * <P>
	 * 内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, int cacheSize,
			MCList<?> bindList, String... bindCols) {
		this(builder, cacheSize, bindList, true, bindCols);
	}
	
	/**
	 * ＤＢコンテナをキャッシュするオブジェクトを作成し、
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCache_FW(MCList, MCQueryApiBuilder, int, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * <P>
	 * 内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, int cacheSize,
			MCList<?> bindList, boolean isZeroCache, String... bindCols) {
		_isZeroCache = isZeroCache;
		setMaxCacheSize(cacheSize);
		T proto = (T) builder.getBaseDbc();
		_dbc = (T) proto.clone();
		_dbc.clear();
		_builder = builder;
		emptyRow = (T) _dbc.clone();
		putCache(MCList.create(_dbc), builder, bindList, bindCols);
	}

	/**
	 * @see #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, int, MCList, String...)
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	public FXUCL_MCDbcCache_FW(MCList<T> result, MCQueryApiBuilder builder, int cacheSize,
			MCList<?> bindList, String... bindCols) {
		this(result, builder, cacheSize, bindList, true, bindCols);
	}
	
	/**
	 * @see #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, int, MCList, String...)
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCList<T> result, MCQueryApiBuilder builder, int cacheSize,
			MCList<?> bindList, boolean isZeroCache, String... bindCols) {
		_isZeroCache = isZeroCache;
		setMaxCacheSize(cacheSize);
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		emptyRow = (T) _dbc.clone();
		putCache(result, builder, bindList, bindCols);
	}

	/**
	 * ＤＢコンテナをキャッシュするオブジェクトを作成し、
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などに場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCache_FW(MCList, MCQueryApiBuilder, boolean, int, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * <P>
	 * 引数fixCacheSizeがtrueの場合、内部の処理で{@link #setFixMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します。<br>
	 * 引数fixCacheSizeがfalseの場合、内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param fixCacheSize キャッシュサイズをプログラムで固定するかどうか
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, boolean fixCacheSize,
			int cacheSize, MCList<?> bindList, String... bindCols) {
		this(builder, fixCacheSize, cacheSize, bindList, true, bindCols);
	}
	
	/**
	 * ＤＢコンテナをキャッシュするオブジェクトを作成し、
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などに場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCache_FW(MCList, MCQueryApiBuilder, boolean, int, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * <P>
	 * 引数fixCacheSizeがtrueの場合、内部の処理で{@link #setFixMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します。<br>
	 * 引数fixCacheSizeがfalseの場合、内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param fixCacheSize キャッシュサイズをプログラムで固定するかどうか
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCQueryApiBuilder builder, boolean fixCacheSize,
			int cacheSize, MCList<?> bindList, boolean isZeroCache, String... bindCols) {
		_isZeroCache = isZeroCache;
		setMaxCacheSize(fixCacheSize, cacheSize);
		T proto = (T) builder.getBaseDbc();
		_dbc = (T) proto.clone();
		_dbc.clear();
		_builder = builder;
		emptyRow = (T) _dbc.clone();
		putCache(MCList.create(_dbc), builder, bindList, bindCols);
	}

	/**
	 * @see #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, boolean, int, MCList, String...)
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param fixCacheSize キャッシュサイズをプログラムで固定するかどうか
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	public FXUCL_MCDbcCache_FW(MCList<T> result, MCQueryApiBuilder builder, boolean fixCacheSize,
			int cacheSize, MCList<?> bindList, String... bindCols) {
		this(result, builder, fixCacheSize, cacheSize, bindList, true, bindCols);
	}
	
	/**
	 * @see #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, boolean, int, MCList, String...)
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param fixCacheSize キャッシュサイズをプログラムで固定するかどうか
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param isZeroCache 検索結果が0件の場合に、この結果をキャッシュするかどうか
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	@SuppressWarnings("unchecked")
	public FXUCL_MCDbcCache_FW(MCList<T> result, MCQueryApiBuilder builder, boolean fixCacheSize,
			int cacheSize, MCList<?> bindList, boolean isZeroCache, String... bindCols) {
		_isZeroCache = isZeroCache;
		setMaxCacheSize(fixCacheSize, cacheSize);
		_dbc = result.createRow();
		_dbc.setAlias(builder.getBaseDbcAlias());// 一時カラムとテーブル情報をコピーする
		_builder = builder;
		emptyRow = (T) _dbc.clone();
		putCache(result, builder, bindList, bindCols);
	}
	
	protected void setMaxCacheSize(boolean fixCacheSize, int cacheSize) {
		if (fixCacheSize) {
			setFixMaxCacheSize(cacheSize);
		}
		else {
			setMaxCacheSize(cacheSize);
		}
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。
	 * <P>
	 * 「検索結果の列を絞りたい」などに場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。
	 * </P>
	 * <P>
	 * bindCols は引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * </P>
	 * @param result 結果を取得するコンテナ
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名（項目はＤＢＣのキー順と同じ順序であること）
	 */
	protected void putCache(MCList<T> result, MCQueryApiBuilder builder, MCList<?> bindList, String... bindCols) {
		if (bindList.isEmpty()) {
			return;
		}
		MCList<?> distincted = bindList.groupBy(bindCols);
		int upperIndex = getMaxCacheSize();

		// 最大キャッシュ件数が0以上の場合、間引く
		if (upperIndex >= 0) {
			if (distincted.size() > upperIndex) {
				distincted = distincted.subList(0, upperIndex);
			}
		}
		result.clear();
		String[] dbcKeyCols = _dbc.getKeyColumn();
		String[] tmpKeyCols = new String[dbcKeyCols.length];

		MCPermColumn[] keycols$ = _dbc.getKeyColumn$();
		for (int i = 0; i < dbcKeyCols.length; i++) {
			MCDataType dType = _dbc.getDataType(dbcKeyCols[i]);
			String tempKeyColumnName = getTempKeyColumnName(dbcKeyCols[i]);
			tmpKeyCols[i] = tempKeyColumnName;
			MCAliasedColumn aCol = null;
			if (dType == MCDataType.BINARY) {
				result.addBinaryColumn(tempKeyColumnName);
				MCBinaryPermColumn c = (MCBinaryPermColumn) keycols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.BOOLEAN) {
				result.addBooleanColumn(tempKeyColumnName);
				MCBooleanPermColumn c = (MCBooleanPermColumn) keycols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.DATE) {
				result.addDateColumn(tempKeyColumnName);
				MCDatePermColumn c = (MCDatePermColumn) keycols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.NUMBER) {
				result.addNumberColumn(tempKeyColumnName);
				MCNumberPermColumn c = (MCNumberPermColumn) keycols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.STRING) {
				result.addStringColumn(tempKeyColumnName);
				MCStringPermColumn c = (MCStringPermColumn) keycols$[i];
				aCol = c.as(tempKeyColumnName);
			}
			else if (dType == MCDataType.TIMESTAMP) {
				result.addTimestampColumn(tempKeyColumnName);
				MCTimestampPermColumn c = (MCTimestampPermColumn) keycols$[i];
				aCol = c.as(tempKeyColumnName);
			}

			if (aCol != null) {
				builder.addSelect(aCol);
			}
		}

		// バインド値をセットして検索
		MCList<T> tmpBindL = result.clone();
		for (int index = 0; index < distincted.size(); index++) {
			MCRow r = distincted.get(index);
			T dbcRow = result.createRow();
			dbcRow.setValues(dbcKeyCols, r, bindCols);
			tmpBindL.add(dbcRow);
		}
		// DBコンテナの検索結果がコンストラクタの引数result→dbcに入っていることを
		// アプリ実装でアテにしているかもしれないが...本来なら、こうした副作用を利用した実装はNG
		dbSelectKeyNotSetCause(getSqlId(_builder, "selectKey"), result, builder, tmpBindL);
		testSelectCount++;
		MCIndexKey tmpKeyIdx = result.createIndex(tmpKeyCols);
		for (MCRow bindRow : tmpBindL) {
			Comparable<?>[] keyVals = new Comparable<?>[bindCols.length];
			for (int i = 0; i < bindCols.length; i++) {
				keyVals[i] = bindRow.getValue(dbcKeyCols[i]);
			}
			MCList<T> resultSubList = result.subList(tmpKeyIdx, keyVals);
			T resultRow = resultSubList.size() > 0 ? resultSubList.get(0) : emptyRow;
			if(resultSubList.size() == 0 && !_isZeroCache) { continue; }
			putCache(keyVals, resultRow);
		}
	}

	@Override
	protected String[] getMaxCacheSizeKey() {
		String[] keys = super.getMaxCacheSizeKey();
		String tbl = _dbc.tableName();
		String[] ret = new String[keys.length + 1];
		for (int i = 0; i < keys.length; i++) {
			ret[i] = keys[i];
		}
		ret[ret.length - 1] = tbl;
		return ret;
	}

	/**
	 * ＤＢＣのキー項目から、キー値保存用の一時カラム名を作成するために使用する接頭辞
	 * @see #getTempKeyColumnName(String)
	 */
	protected String _keyColumnPrefix = "tmp0";

	/**
	 * ＤＢＣのキー項目から、キー値保存用の一時カラム名を作成するために使用する接頭辞
	 * @see #getTempKeyColumnName(String)
	 */
	protected String getKeyColumnPrefix() {
		return _keyColumnPrefix;
	}

	/**
	 * ＤＢＣのキー項目から、キー値保存用の一時カラム名を作成するために使用する接頭辞
	 * を設定する。
	 * @see #getTempKeyColumnName(String)
	 */
	public void setKeyColumnPrefix(String columnName) {
		_keyColumnPrefix = columnName;
	}

	/**
	 * ＤＢＣのキー項目から、キー値保存用の一時カラム名を作成する。
	 * <P>
	 * {@link #FXUCL_MCDbcCache_FW(MCQueryApiBuilder, MCList, String...)}及び
	 * {@link #putCache(MCQueryApiBuilder, MCList, String...)}で使用する。
	 * </P>
	 * <P>
	 * ここで作成するカラムは、すでに存在するカラムと異なる
	 * カラム名である必要があります。デフォルトのカラム名で
	 * すでに存在するカラムと重複する場合は {@link #setKeyColumnPrefix(String)}
	 * で作成するカラム名を調整することができます。
	 * </P>
	 * @param keyColumnName ＤＢＣのキー項目名
	 * @return キー値保存用の一時カラム名
	 */
	protected String getTempKeyColumnName(String keyColumnName) {
		return getKeyColumnPrefix() + keyColumnName;
	}

	/**
	 * inに対応する検索結果があればそれを返します。ない場合は、コンストラクタで設定されたMCQueryApiBuilderを使い、 対応する値を検索します。
	 * inはコンストラクタで指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * <P>
	 * サンプル
	 * 
	 * <pre>
	 * private FXUCL_MCDbcCache&lt;HVM_ITM_R&gt; _itmCache;
	 * protected FXUCL_MCDbcCache&lt;HVM_ITM_R&gt; itmCache() {
	 * 	if( _itmCache == null ){
	 * 		HVM_ITM_R dbc = HVM_ITM_R.create();
	 * 		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
	 * 		builder.setSelect(dbc.itm_nm);
	 * 		FXUCL_MCDbcCache&lt;HVM_ITM_R&gt; _itmCache = new FXUCL_MCDbcCache&lt;&gt;(builder);
	 * 	}
	 * 	return _itmCache;
	 * }
	 * protected String hoge2(HogeR r) {
	 * 	....
	 * 	fooR.itm_nm(_itmCache.get(r.itm_cd()).itm_nm());
	 * 	....
	 * }
	 * </pre>
	 * 
	 * @param in 検索条件及びキャッシュのキー
	 * @return
	 */
	@SuppressWarnings({
			"unchecked"
	})
	public T get(Comparable<?>... in) {
		T ans = super.getCache(in);
		if (ans == null) {
			T r = (T) _dbc.clone();
			r.clear();
			for (int i = 0; i < r.getKeyColumn().length; i++) {
				r.setValue(r.getKeyColumn()[i], in[i]);
			}
			MCLog.write(FXUCC0020, Arrays.toString(in), this.getClass().getSimpleName());
			dbSelectKey(getSqlId(_builder, "selectKey"), r, _builder, r);
			testSelectCount++;
			boolean isEmpty = compareRowValues(emptyRow, r);
			if(!isEmpty || _isZeroCache) {
				putCache(in, r);
			}
			ans = r;
		}
		else {
			MCLog.write(FXUCC0021, Arrays.toString(in), this.getClass().getSimpleName());
		}
		return ans;
	}

	/**
	 * inに対応する検索結果があればそれを返します。ない場合は、コンストラクタで設定されたMCQueryApiBuilderを使い、 対応する値を検索します。
	 * inはコンストラクタで指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。
	 * <P>
	 * サンプル
	 * 
	 * <pre>
	 * private FXUCL_MCDbcCache&lt;HVM_ITM_R&gt; _itmCache;
	 * protected FXUCL_MCDbcCache&lt;HVM_ITM_R&gt; itmCache() {
	 * 	if( _itmCache == null ){
	 * 		HVM_ITM_R dbc = HVM_ITM_R.create();
	 * 		MCQueryApiBuilder builder = MCQueryApiBuilder.create(dbc);
	 * 		builder.setSelect(dbc.itm_nm);
	 * 		FXUCL_MCDbcCache&lt;HVM_ITM_R&gt; _itmCache = new FXUCL_MCDbcCache&lt;&gt;(builder);
	 * 	}
	 * 	return _itmCache;
	 * }
	 * protected String hoge2(HogeR r) {
	 * 	....
	 * 	fooR.itm_nm(_itmCache.getEx(r.itm_cd()).itm_nm());
	 * 	....
	 * }
	 * </pre>
	 * 
	 * @param in 検索条件及びキャッシュのキー
	 * @return
	 */
	@SuppressWarnings({
			"unchecked"
	})
	public T getEx(Comparable<?>... in) {
		T ans = super.getCache(in);
		boolean isEmpty = compareRowValues(emptyRow, ans);
		if (ans == null || isEmpty) {
			T r = (T) _dbc.clone();
			r.clear();
			for (int i = 0; i < r.getKeyColumn().length; i++) {
				r.setValue(r.getKeyColumn()[i], in[i]);
			}
			dbSelectKeyEx(getSqlId(_builder, "selectKey"), r, _builder, r.clone());
			testSelectCount++;
			putCache(in, r);
			ans = r;
		}
		return ans;
	}
	
	/**
	 * 
	 * baseを基準としてtargetに同じ値が設定されているか比較します。
	 *
	 * @author    ikezkai
	 * @since     7.0.2.1
	 * @param base 比較の元になるMCRow
	 * @param target baseと等しいか比較されるMCRow
	 * @return 等しい場合：true、等しくない場合：false
	 */
	private static boolean compareRowValues(MCRow base, MCRow target) {
		if(base == null && target == null) {
			return true;
		}
		if(base == null && target != null) {
			return false;
		}
		if(base != null && target == null) {
			return false;
		}
		
		String[] columns = base.getColumnPathArray();
		for(String c : columns) {
			Comparable<?> b = base.getValue(c);
			Comparable<?> t = target.getValue(c);
			if(b == null && t == null) {
				continue;
			}
			if(b == null && t != null) {
				return false;
			}
			if(!b.equals(t)) {
				return false;
			}
		}
		return true;
	}
}
