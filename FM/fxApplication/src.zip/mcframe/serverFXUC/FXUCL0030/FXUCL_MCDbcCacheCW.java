package mcframe.serverFXUC.FXUCL0030;

import mcframe.commonCore.annotation.EI;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;

/**
 * "FXUCL_MCDbcCacheCW"ロジッククラスです。
 * <P>
 * DbcCache Custom Where
 */
@EI
public class FXUCL_MCDbcCacheCW<T extends MCDBContainer> extends FXUCL_MCDbcCacheCW_FW<T> {
	/**
	 * @deprecated
	 */
	public FXUCL_MCDbcCacheCW() {

	}

	public FXUCL_MCDbcCacheCW(MCQueryApiBuilder builder) {
		super(builder);
	}

}