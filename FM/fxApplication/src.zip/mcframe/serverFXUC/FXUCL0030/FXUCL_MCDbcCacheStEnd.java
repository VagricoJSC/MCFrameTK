package mcframe.serverFXUC.FXUCL0030;

import mcframe.commonCore.annotation.EI;
import mcframe.commonCore.container.MCList;
import mcframe.serverCore.queryapi.MCDBContainer;
import mcframe.serverCore.queryapi.MCQueryApiBuilder;

/**
 * 適用開始日、適用終了日を持つマスタ専用のDBコンテナキャッシュクラスです。<br>
 * 適用開始日、適用終了日はテーブル上で、
 * 「ST_DT」「END_DT」という列名で定義されている必要があります。
 */
@EI
public class FXUCL_MCDbcCacheStEnd<E extends MCDBContainer>
		extends FXUCL_MCDbcCacheStEnd_FW<E> {
	/**
	 * @deprecated
	 */
	public FXUCL_MCDbcCacheStEnd() {

	}

	/**
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。<br>
	 * また、結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCacheStEnd(MCList, MCQueryApiBuilder)}
	 * を利用してください。
	 * @param builder クエリAPIビルダ
	 */
	public FXUCL_MCDbcCacheStEnd(MCQueryApiBuilder builder) {
		super(builder);
	}

	public FXUCL_MCDbcCacheStEnd(MCList<E> result, MCQueryApiBuilder builder) {
		super(result, builder);
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。<br>
	 * ※適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * <P>
	 * ・bindColsは引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * ・bindColsには、適用開始日を含めないでください。<br>
	 * （キーが「品目ＣＤ」「発注先ＣＤ」「適用開始日」のマスタの場合、
	 * 「品目ＣＤ」と「発注先ＣＤ」のカラム名のみを指定してください。）
	 * </P>
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCacheStEnd(MCList, MCQueryApiBuilder, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * このときのサイズはリソースで指定したサイズかデフォルトのサイズになります。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	public FXUCL_MCDbcCacheStEnd(MCQueryApiBuilder builder, MCList<?> bindList,
			String... bindCols) {
		super(builder, bindList, bindCols);
	}

	public FXUCL_MCDbcCacheStEnd(MCList<E> result, MCQueryApiBuilder builder,
			MCList<?> bindList, String... bindCols) {
		super(result, builder, bindList, bindCols);
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。<br>
	 * ※適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * <P>
	 * ・bindColsは引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * ・bindColsには、適用開始日を含めないでください。<br>
	 * （キーが「品目ＣＤ」「発注先ＣＤ」「適用開始日」のマスタの場合、
	 * 「品目ＣＤ」と「発注先ＣＤ」のカラム名のみを指定してください。）
	 * </P>
	 * <P>
	 * 「検索結果の列を絞りたい」などに場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * 結果を取得するコンテナに一時カラムを追加したい場合は、
	 * {@linkplain #FXUCL_MCDbcCacheStEnd(MCList, MCQueryApiBuilder, int, MCList, String...)}
	 * を利用してください。
	 * </P>
	 * <P>
	 * 内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	public FXUCL_MCDbcCacheStEnd(MCQueryApiBuilder builder, int cacheSize,
			MCList<?> bindList, String... bindCols) {
		super(builder, cacheSize, bindList, bindCols);
	}

	public FXUCL_MCDbcCacheStEnd(MCList<E> result, MCQueryApiBuilder builder,
			int cacheSize, MCList<?> bindList, String... bindCols) {
		super(result, builder, cacheSize, bindList, bindCols);
	}

	/**
	 * 引数で指定したリストに対応するＤＢレコードを検索し、キャッシュとして保持します。<br>
	 * ※適用日を無視して検索し、取得されたリスト(複数件の可能性がある)をキャッシュとして保持します。<br>
	 * 適用日の考慮はget(getEx)メソッドで行います。
	 * <P>
	 * ・bindColsは引数で指定したMCQueryApiBuilderのgetKeyColumnに対応した順番でセットされている必要があります。<br>
	 * ・bindColsには、適用開始日を含めないでください。<br>
	 * （キーが「品目ＣＤ」「発注先ＣＤ」「適用開始日」のマスタの場合、
	 * 「品目ＣＤ」と「発注先ＣＤ」のカラム名のみを指定してください。）
	 * </P>
	 * <P>
	 * 「検索結果の列を絞りたい」などの場合は、コンストラクタにMCQueryApiBuilderを
	 * セットする前に setSelect等しておいてください。<br>
	 * ただし、setWhere,addWhere等で追加したwhere句は破棄されますので注意してください。
	 * </P>
	 * <P>
	 * 引数fixCacheSizeがtrueの場合、内部の処理で{@link #setFixMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します。<br>
	 * 引数fixCacheSizeがfalseの場合、内部の処理で{@link #setMaxCacheSize(int size)}を呼び出し、引数cacheSizeでキャッシュの最大件数を設定します（リソースにキャッシュの最大件数の設定がある場合は、リソースが優先されます）。<br>
	 * バインド値のリストは、内部の処理で、重複を除去します。<br>
	 * 重複を除去したリストのサイズが{@link #getMaxCacheSize()}を超えている場合は、
	 * {@link #getMaxCacheSize()} の件数になるようにリスト内の行を間引きます。<br>
	 * 尚、この間引き処理で、引数のリストの順序は考慮されません。<br>
	 * 重複を除去しリストのサイズが{@link #getMaxCacheSize()}以下になった、
	 * バインド値のリストを使用して、ＤＢからデータを取得します。
	 * </P>
	 * @param builder クエリAPIビルダ
	 * @param fixCacheSize キャッシュサイズをプログラムで固定するかどうか
	 * @param cacheSize キャッシュサイズ
	 * @param bindList バインド値のリスト
	 * @param bindCols バインド値のリストにおけるキー値が保存されているカラム名<br>
	 * ※項目はＤＢＣのキー順と同じ順序であること<br>
	 * ※適用開始日を含めないこと
	 */
	public FXUCL_MCDbcCacheStEnd(MCQueryApiBuilder builder, boolean fixCacheSize,
			int cacheSize, MCList<?> bindList, String... bindCols) {
		super(builder, fixCacheSize, cacheSize, bindList, bindCols);
	}

	public FXUCL_MCDbcCacheStEnd(MCList<E> result, MCQueryApiBuilder builder,
			boolean fixCacheSize, int cacheSize, MCList<?> bindList, String... bindCols) {
		super(result, builder, fixCacheSize, cacheSize, bindList, bindCols);
	}

}