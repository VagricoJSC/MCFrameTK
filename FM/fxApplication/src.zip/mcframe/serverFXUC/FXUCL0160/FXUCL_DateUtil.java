package mcframe.serverFXUC.FXUCL0160;

import mcframe.commonCore.annotation.EI;

/**
 * "FXUCL_DateUtil"ロジッククラスです。<p>
 *
 */
@EI
public class FXUCL_DateUtil extends FXUCL_DateUtil_FW {
}
