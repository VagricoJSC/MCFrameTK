package mcframe.serverFXUC.FXUCL0160;

import mcframe.commonCore.lang.MCDate;
import mcframe.serverCore.mcjdbc.FWDBUtil;
import static mcframe.serverCore.requester.MCRequestObject.object;

/**
 * "FXUCL_DateUtil"ロジッククラスです。
 */
public class FXUCL_DateUtil_FW {

	/**
	 * 自身のインスタンス
	 * スレッド単位でインスタンスを保持する。（キャッシュの範囲もスレッド単位にする。）
	 */
	protected static final Class<FXUCL_DateUtil> CLAZZ = FXUCL_DateUtil.class;

	/**
	 * スレッド単位にキャッシュする運用日付
	 */
	protected MCDate _today;

	/**
	 * 運用日付を取得します。
	 */
	public static MCDate getToday() {
		return object(CLAZZ)._getToday();
	}

	MCDate _getToday() {
		if (_today == null) {
			_today = FWDBUtil.coToday();
		}
		return _today;
	}

}
