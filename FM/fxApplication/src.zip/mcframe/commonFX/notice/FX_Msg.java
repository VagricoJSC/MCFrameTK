package mcframe.commonFX.notice;
import mcframe.commonCore.annotation.EI;
@EI
public class FX_Msg extends FX_Msg_FW_A {

}
