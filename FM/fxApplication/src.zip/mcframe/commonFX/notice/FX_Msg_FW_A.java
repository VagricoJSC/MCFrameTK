package mcframe.commonFX.notice;

public class FX_Msg_FW_A {
	/** LEVEL[E]<br>更新レコードの更新カウンタが取得できません。<br>更新レコード：{1}<br>更新カウンタ：{2}<p>
	 */
	public static String FXBAL0001 = "FXBAL0001";

	/** LEVEL[D]<br>更新カウンタが取得できません。<br>更新レコード：{1}<br>ロック対象レコード：{2}<br>更新カウンタカラム名：{3}<p>
	 */
	public static String FXBAL0002 = "FXBAL0002";

	/** LEVEL[W]<br>更新対象が、他の処理によって更新されています。再検索してください。<p>
	 */
	public static String FXBAL0003 = "FXBAL0003";

	/** LEVEL[D]<br>更新カウンタの値が異なります。<br>更新レコード：{1}<br>更新レコードの更新カウンタ：{2}<br>ロック対象レコード：{3}<br>ロック対象レコードの更新カウンタ：{4}<br>更新カウンタカラム名：{5}<p>
	 */
	public static String FXBAL0004 = "FXBAL0004";

	/** LEVEL[E]<br>更新カウンタに指定した項目数が一致しません。<br>更新レコードの更新カウンタ項目数：{1}<br>ロック対象レコードの更新カウンタ項目数：{2}<p>
	 */
	public static String FXBAL0005 = "FXBAL0005";

	/** LEVEL[E]<br>引数にnullがセットされました。<br>更新レコードのリスト：{1}<br>更新レコードのリストのキー：{2}<br>ロック対象レコードのリスト：{3}<br>ロック対象レコードのリストのキー：{4}<p>
	 */
	public static String FXBAL0006 = "FXBAL0006";

	/** LEVEL[E]<br>更新レコードのリストにnullがセットされました。<p>
	 */
	public static String FXBAL0007 = "FXBAL0007";

	/** LEVEL[E]<br>ロック対象レコードのリストにnullがセットされました。<p>
	 */
	public static String FXBAL0008 = "FXBAL0008";

	/** LEVEL[W]<br>更新対象が、他の処理によって削除されています。再検索してください。<p>
	 */
	public static String FXBAL0009 = "FXBAL0009";

	/** LEVEL[D]<br>ロック対象レコードが取得できませんでした。<br>ロック対象レコード：{1}<br>ロック対象レコードの更新カウンタ：{2}<p>
	 */
	public static String FXBAL0010 = "FXBAL0010";

	/** LEVEL[T]<br>setCanceled()メソッドで{1}が設定されました。<p>
	 */
	public static String FXBAL0011 = "FXBAL0011";

	/** LEVEL[W]<br>登録できませんでした。<p>
	 */
	public static String FXBAL0012 = "FXBAL0012";

	/** LEVEL[W]<br>登録対象の行は既に存在します。<p>
	 */
	public static String FXBAL0013 = "FXBAL0013";

	/** LEVEL[W]<br>利用されているため更新できません。<p>
	 */
	public static String FXBAL0014 = "FXBAL0014";

	/** LEVEL[E]<br>リソースに存在しないキーで値の取得を試みました。<br>リソースキー：{1}<p>
	 */
	public static String FXBAL0015 = "FXBAL0015";

	/** LEVEL[E]<br>UPDATE サブオペレーションにＤＢコンテナを指定してください。<p>
	 */
	public static String FXBAL0016 = "FXBAL0016";

	/** LEVEL[D]<br>getCanceled()メソッドでtrueが取得されたため、検索処理を行いませんでした。<br>setCanceled()メソッドでtrueが設定された可能性があります。<p>
	 */
	public static String FXBAL0017 = "FXBAL0017";

	/** LEVEL[D]<br>MAINサブオペレーションを使用したチェックを行います。<p>
	 */
	public static String FXBAL0018 = "FXBAL0018";

	/** LEVEL[D]<br>OTHERサブオペレーションを使用したチェックを行います。<p>
	 */
	public static String FXBAL0019 = "FXBAL0019";

	/** LEVEL[D]<br>CPA_MASTERパッケージを使用したチェックを行います。<p>
	 */
	public static String FXBAL0020 = "FXBAL0020";

	/** LEVEL[W]<br>登録対象の行は既に存在します。<p>
	 */
	public static String FXBAL0021 = "FXBAL0021";

	/** LEVEL[E]<br>変換対象の数値は、指定された小数部有効桁数以上の数値を持ち、小数部有効桁数の丸め処理が必要ですが、丸め方法が指定されていません。<br>数値：{1}<br>有効桁数：{2}<p>
	 */
	public static String FXBAL0022 = "FXBAL0022";

	/** LEVEL[E]<br>リソースに存在しないキーで値の取得を試みました。<br>リソースキー：{1}<p>
	 */
	public static String FXBAL0023 = "FXBAL0023";

	/** LEVEL[W]<br>参照先が存在しないため更新できません。<p>
	 */
	public static String FXBAL0024 = "FXBAL0024";

	/** LEVEL[E]<br>指定した項目名は、DBコンテナの外部参照項目として存在しません。<br>指定した項目名：{1}<p>
	 */
	public static String FXBAL0025 = "FXBAL0025";

	/** LEVEL[E]<br>マッピングの定義が不正です。<br>リソースキー：{1}<br>不正な値：{2}<p>
	 */
	public static String FXBAL0026 = "FXBAL0026";

	/** LEVEL[E]<br>排他制御対象外のテーブルに対し、排他チェックを実施しました。<br>テーブル名：{1}<p>
	 */
	public static String FXBAL0027 = "FXBAL0027";

	/** LEVEL[E]<br>Logger インスタンスが作成されていません。<p>
	 */
	public static String FXBAL0028 = "FXBAL0028";

	/** LEVEL[E]<br>バッチログの備考の数が多すぎます。<br>備考の最大数：{1}<br>指定された備考の数：{2}<p>
	 */
	public static String FXBAL0029 = "FXBAL0029";

	/** LEVEL[E]<br>バッチログのバインド値の数が多すぎます。<br>バインド値の最大数：{1}<br>指定されたバインド値の数：{2}<br>使用しようとしたメッセージＩＤ；{3}<p>
	 */
	public static String FXBAL0030 = "FXBAL0030";

	/** LEVEL[E]<br>Batch Loggerは既にクローズされています。<p>
	 */
	public static String FXBAL0031 = "FXBAL0031";

	/** LEVEL[E]<br>汎用テーブル編集用下り電文ファイルの書き込みに失敗しました。<p>
	 */
	public static String FXBAL0032 = "FXBAL0032";

	/** LEVEL[W]<br>マイナスの値は指定できません。項目名：{1}<p>
	 */
	public static String FXBAP0003 = "FXBAP0003";

	/** LEVEL[W]<br>マイナスの値は指定できません。行：{1}  列名：{2}<p>
	 */
	public static String FXBAP0004 = "FXBAP0004";

	/** LEVEL[I]<br>削除処理を実行します。よろしいですか？<p>
	 */
	public static String FXBAP0005 = "FXBAP0005";

	/** LEVEL[I]<br>登録処理を実行します。よろしいですか？<p>
	 */
	public static String FXBAP0006 = "FXBAP0006";

	/** LEVEL[I]<br>検索処理を実行します。よろしいですか？<p>
	 */
	public static String FXBAP0007 = "FXBAP0007";

	/** LEVEL[I]<br>取消処理を実行します。よろしいですか？<p>
	 */
	public static String FXBAP0008 = "FXBAP0008";

	/** LEVEL[I]<br>画面をクリアします。よろしいですか？<p>
	 */
	public static String FXBAP0009 = "FXBAP0009";

	/** LEVEL[E]<br>移動元のパネルに移動対象のオブジェクトが見つかりません。<br>移動元パネル：{1}<br>移動対象：{2}<p>
	 */
	public static String FXBAP0010 = "FXBAP0010";

	/** LEVEL[W]<br>値の変更されている箇所がありません。<p>
	 */
	public static String FXBAP0011 = "FXBAP0011";

	/** LEVEL[W]<br>登録できませんでした。<p>
	 */
	public static String FXBAP0012 = "FXBAP0012";

	/** LEVEL[W]<br>次のデータは既に存在します。<br>{1}<p>
	 */
	public static String FXBAP0013 = "FXBAP0013";

	/** LEVEL[W]<br>次のデータは「{1}」で使用されています。<br>{2}<p>
	 */
	public static String FXBAP0014 = "FXBAP0014";

	/** LEVEL[W]<br>登録対象がありません。<p>
	 */
	public static String FXBAP0015 = "FXBAP0015";

	/** LEVEL[W]<br>登録対象の明細がありません。<p>
	 */
	public static String FXBAP0016 = "FXBAP0016";

	/** LEVEL[W]<br>削除対象がありません。<p>
	 */
	public static String FXBAP0017 = "FXBAP0017";

	/** LEVEL[I]<br>編集したキー項目の値は元に戻されます。よろしいですか？<p>
	 */
	public static String FXBAP0018 = "FXBAP0018";

	/** LEVEL[I]<br>一覧をクリアします。よろしいですか？<p>
	 */
	public static String FXBAP0019 = "FXBAP0019";

	/** LEVEL[I]<br>登録しました。<p>
	 */
	public static String FXBAP0021 = "FXBAP0021";

	/** LEVEL[I]<br>削除しました。<p>
	 */
	public static String FXBAP0022 = "FXBAP0022";

	/** LEVEL[E]<br>入力補助画面に紐付けられていないBeanが指定されました。<p>
	 */
	public static String FXBAP0023 = "FXBAP0023";

	/** LEVEL[E]<br>予期せぬ型がセットされました。{1}<p>
	 */
	public static String FXBAP0024 = "FXBAP0024";

	/** LEVEL[D]<br>ラベルリソースにアクセスしましたが、対応する値を取得できませんでした。<br>リソースキー：{1}<p>
	 */
	public static String FXBAP0026 = "FXBAP0026";

	/** LEVEL[D]<br>対応するラベルキーが見つかりません。<br>{1},{2},{3},{4}<p>
	 */
	public static String FXBAP0027 = "FXBAP0027";

	/** LEVEL[I]<br>処理を中止しました。<p>
	 */
	public static String FXBAP0028 = "FXBAP0028";

	/** LEVEL[E]<br>画面起動引数が不正です。<br>{1}<p>
	 */
	public static String FXBAP0029 = "FXBAP0029";

	/** LEVEL[I]<br>{1}以下のメッセージがあります。<p>
	 */
	public static String FXBAP0031 = "FXBAP0031";

	/** LEVEL[I]<br>終了しました。以下のメッセージがあります。<p>
	 */
	public static String FXBAP0032 = "FXBAP0032";

	/** LEVEL[I]<br>検索結果がありませんでした。<p>
	 */
	public static String FXBAP0033 = "FXBAP0033";

	/** LEVEL[I]<br>入力中のデータがクリアされます。よろしいですか？<p>
	 */
	public static String FXBAP0034 = "FXBAP0034";

	/** LEVEL[W]<br>対象の行を選択してください。<p>
	 */
	public static String FXBAP0035 = "FXBAP0035";

	/** LEVEL[E]<br>リソースに存在しないキーで値の取得を試みました。<br>リソースキー：{1}<p>
	 */
	public static String FXBAP0036 = "FXBAP0036";

	/** LEVEL[E]<br>リストに対応するMCTableが存在しませんでした。<p>
	 */
	public static String FXBAP0037 = "FXBAP0037";

	/** LEVEL[W]<br>対象のデータを選択してください。<p>
	 */
	public static String FXBAP0038 = "FXBAP0038";

	/** LEVEL[E]<br>型変換エラー。<br>引数は、getCheckedRowListBlock()で指定したリストのRowクラス<br>の代入互換できるクラスを指定する必要があります。<br>getCheckedRowListBlock()で指定したリストのRowクラス：{1}<br>引数で指定されたクラス：{2}<p>
	 */
	public static String FXBAP0039 = "FXBAP0039";

	/** LEVEL[E]<br>入力補助画面起動時にputterがわたされていません。<p>
	 */
	public static String FXBAP0040 = "FXBAP0040";

	/** LEVEL[E]<br>入力補助画面起動時にputterに使用するputIndexがわたされていません。<p>
	 */
	public static String FXBAP0041 = "FXBAP0041";

	/** LEVEL[T]<br>リストの特定カラムの重複チェック処理のメッセージ用ラベル取得処理において、<br>rowのカラム名に対応するMCColumnConfigが見つかりません。無視します。<br>カラム名：{1}<p>
	 */
	public static String FXBAP0042 = "FXBAP0042";

	/** LEVEL[W]<br>次のいずれかを選択してください。(行：{1})<br>{2}<p>
	 */
	public static String FXBAP0043 = "FXBAP0043";

	/** LEVEL[W]<br>文字列が長すぎます。<br>値：{1}<br>指定した文字の長さ：{2}<br>指定可能な文字の長さ：{3}<p>
	 */
	public static String FXBAP0050 = "FXBAP0050";

	/** LEVEL[W]<br>数字の桁数が大きすぎます。<br>値：{1}<br>指定可能な数字の整数部の最大桁数：{2}<br>指定可能な数字の小数部の最大桁数：{3}<p>
	 */
	public static String FXBAP0051 = "FXBAP0051";

	/** LEVEL[T]<br>画面オブジェクトを取得できませんでした。<br>RowClass : {1}<br>RowData : {2}<br>ColumnName : {3}<p>
	 */
	public static String FXBAP0054 = "FXBAP0054";

	/** LEVEL[E]<br>テーブル内の必須チェックの処理で、テーブルに存在しないRowがチェック対象のリストに含まれています。<br>tableName : {1}<br>rowClass : {2}<br>rowData : {3}<p>
	 */
	public static String FXBAP0056 = "FXBAP0056";

	/** LEVEL[E]<br>取得対象のリストが設定されていません。setDtlLForCall()で設定してください。<p>
	 */
	public static String FXBAP0057 = "FXBAP0057";

	/** LEVEL[W]<br>{1}の中のいずれかの値を指定してください。<p>
	 */
	public static String FXBAP0058 = "FXBAP0058";

	/** LEVEL[W]<br>値のセットに失敗しました。<p>
	 */
	public static String FXBAP0059 = "FXBAP0059";

	/** LEVEL[W]<br>次のいずれかを選択してください。<br>{1}<p>
	 */
	public static String FXBAP0060 = "FXBAP0060";

	/** LEVEL[W]<br>{1}の中のいずれかを選択してください。<p>
	 */
	public static String FXBAP0061 = "FXBAP0061";

	/** LEVEL[E]<br>次のインタフェースを実装したパネルクラスが見つかりませんでした。<br>インタフェース：{1}<br>探索元画面：{2}<p>
	 */
	public static String FXBAP0062 = "FXBAP0062";

	/** LEVEL[E]<br>引数は、MCRowListerあるいはMCRowStatusListenerを実装したクラスでなければいけません<p>
	 */
	public static String FXBAP0063 = "FXBAP0063";

	/** LEVEL[E]<br>検索条件に合致するパネルが複数見つかりました。<br>探索先画面：<br>{1}<br>探索元画面：<br>{2}<p>
	 */
	public static String FXBAP0064 = "FXBAP0064";

	/** LEVEL[E]<br>入力補助用の検索定型処理クラスのコンストラクタ引数のパネルインスタンスは、IfISPanelWithPaging 実装する必要があります。<p>
	 */
	public static String FXBAP0068 = "FXBAP0068";

	/** LEVEL[E]<br>入力補助用の検索定型処理クラスの１番目の下り電文はリストである必要があります。<p>
	 */
	public static String FXBAP0069 = "FXBAP0069";

	/** LEVEL[E]<br>引数は IfISPanelWithPaging を実装したインスタンスをセットする必要があります。<p>
	 */
	public static String FXBAP0070 = "FXBAP0070";

	/** LEVEL[E]<br>FXBAP_ISPanelUtilを使用する場合は、はじめにsetPanelメソッドで呼び出しもとのpanelを設定する必要があります。<p>
	 */
	public static String FXBAP0071 = "FXBAP0071";

	/** LEVEL[E]<br>引数は IfRLBase を実装したインスタンスをセットする必要があります。<p>
	 */
	public static String FXBAP0072 = "FXBAP0072";

	/** LEVEL[E]<br>FXBAP_RLUtilを使用する場合は、はじめにsetPanelメソッドで呼び出しもとのpanelを設定する必要があります。<p>
	 */
	public static String FXBAP0073 = "FXBAP0073";

	/** LEVEL[E]<br>FXBAP_RLCellConfigを使用する場合は、はじめにsetPanelメソッドで呼び出しもとのpanelを設定する必要があります。<p>
	 */
	public static String FXBAP0074 = "FXBAP0074";

	/** LEVEL[E]<br>FXBAP_RLCellConfig#setPanelの引数は IfRLBase を実装したインスタンスをセットする必要があります。<p>
	 */
	public static String FXBAP0075 = "FXBAP0075";

	/** LEVEL[E]<br>引数は IfRLBase を実装したインスタンスをセットする必要があります。<p>
	 */
	public static String FXBAP0076 = "FXBAP0076";

	/** LEVEL[E]<br>引数は IfRLBase を実装したインスタンスをセットする必要があります。<p>
	 */
	public static String FXBAP0077 = "FXBAP0077";

	/** LEVEL[I]<br>印刷をします。よろしいですか？<p>
	 */
	public static String FXBAP0078 = "FXBAP0078";

	/** LEVEL[W]<br>出力対象のデータがありませんでした。<p>
	 */
	public static String FXBAP0079 = "FXBAP0079";

	/** LEVEL[W]<br>取込不正のデータがあります。取込結果を確認してください。<p>
	 */
	public static String FXBAP0080 = "FXBAP0080";

	/** LEVEL[W]<br>取込対象のデータがありませんでした。<p>
	 */
	public static String FXBAP0081 = "FXBAP0081";

	/** LEVEL[I]<br>終了しました。以下のメッセージがあります。<p>
	 */
	public static String FXBAP0082 = "FXBAP0082";

	/** LEVEL[W]<br>印刷対象がありません。<p>
	 */
	public static String FXBAP0083 = "FXBAP0083";

	/** LEVEL[E]<br>テーブルが指定されていません。<p>
	 */
	public static String FXBAP0084 = "FXBAP0084";

	/** LEVEL[W]<br>指定されたモジュールＩＤ、スクリーンＩＤの画面が見つかりませんでした。<br>設定を確認してください。<br>モジュールＩＤ：{1}<br>スクリーンＩＤ：{2}<br><p>
	 */
	public static String FXBAP0085 = "FXBAP0085";

	/** LEVEL[W]<br>印刷データが存在しませんでした。<p>
	 */
	public static String FXBAP0086 = "FXBAP0086";

	/** LEVEL[T]<br>画面初期化処理のトレース メソッド[{1}] @ {2}<p>
	 */
	public static String FXBAP0088 = "FXBAP0088";

	/** LEVEL[T]<br>画面変更チェックのトレース ID : {1}  Object：{2}  値：{3}<p>
	 */
	public static String FXBAP0089 = "FXBAP0089";

	/** LEVEL[T]<br>画面キャッシュがありません。画面を作成します。画面クラス：{1}<p>
	 */
	public static String FXBAP0090 = "FXBAP0090";

	/** LEVEL[T]<br>画面キャッシュがありました。キャッシュを使います。画面クラス：{1}<p>
	 */
	public static String FXBAP0091 = "FXBAP0091";

	/** LEVEL[T]<br>入力補助画面でキャッシュされている検索結果がありません。検索します。<p>
	 */
	public static String FXBAP0092 = "FXBAP0092";

	/** LEVEL[T]<br>入力補助画面でキャッシュされている検索結果が見つかりました。<p>
	 */
	public static String FXBAP0093 = "FXBAP0093";

	/** LEVEL[E]<br>このメソッドは、MCRowBeansと連携するコンテナにのみ使用可能です。<p>
	 */
	public static String FXBAP0094 = "FXBAP0094";

	/** LEVEL[I]<br>処理を実行します。よろしいですか？<p>
	 */
	public static String FXBAP0096 = "FXBAP0096";

	/** LEVEL[W]<br>削除できませんでした。<p>
	 */
	public static String FXBAP0097 = "FXBAP0097";

	/** LEVEL[W]<br>検索条件を初期状態に戻せませんでした。<p>
	 */
	public static String FXBAP0098 = "FXBAP0098";

	/** LEVEL[W]<br>プログレスダイアログを表示できなかったため、検索処理を行いませんでした。<p>
	 */
	public static String FXBAP0099 = "FXBAP0099";

	/** LEVEL[I]<br>バックグラウンドで印刷処理を実行しています。<p>
	 */
	public static String FXBAP0100 = "FXBAP0100";

	/** LEVEL[W]<br>テーブル情報を取得するための設定がありません。<br>モジュールＩＤ：{1}<br>スクリーンＩＤ：{2}<br>テーブル：{3}<p>
	 */
	public static String FXBAP0103 = "FXBAP0103";

	/** LEVEL[I]<br>この画面は会社にログインしているユーザのみ利用可能です。<p>
	 */
	public static String FXBAP0104 = "FXBAP0104";

	/** LEVEL[E]<br>汎用テーブル編集用下り電文ファイルの読み込みに失敗しました。<p>
	 */
	public static String FXBAP0105 = "FXBAP0105";

	/** LEVEL[W]<br>MCPluginリソースに定義されているツールバーアイテムのクラスを作成できませんでした。<br>クラス：{1}<p>
	 */
	public static String FXBAP0106 = "FXBAP0106";

	/** LEVEL[E]<br>要求数の合計と割当可能総数の符号が異なっています。<br>要求数合計：{1}<br>割当可能総数：{2}<p>
	 */
	public static String FXUCL0001 = "FXUCL0001";

	/** LEVEL[E]<br>割当比率の合計は０以外の数である必要があります。<br>割当比率合計：{1}<p>
	 */
	public static String FXUCL0002 = "FXUCL0002";

	/** LEVEL[T]<br>振り分け処理で残数が発生しました。残数：{1}<p>
	 */
	public static String FXUCL0003 = "FXUCL0003";

	/** LEVEL[W]<br>自社情報が取得できませんでした。<p>
	 */
	public static String FXUCL0004 = "FXUCL0004";

	/** LEVEL[W]<br>基準通貨情報が取得できませんでした。<p>
	 */
	public static String FXUCL0005 = "FXUCL0005";

	/** LEVEL[W]<br>ユーザ情報が取得できませんでした。<p>
	 */
	public static String FXUCL0006 = "FXUCL0006";

	/** LEVEL[E]<br>結合するための項目数が一致しません。<br>参照日時のリストの項目数：{1}<br>更新日時のリストの項目数：{2}<p>
	 */
	public static String FXUCL0007 = "FXUCL0007";

	/** LEVEL[W]<br>{1}に存在しない値を指定しています。<br>{2}<p>
	 */
	public static String FXUCL0010 = "FXUCL0010";

	/** LEVEL[W]<br>{1}に存在しない値を指定しています。（行 : {2}）<br>{3}<p>
	 */
	public static String FXUCL0011 = "FXUCL0011";

	/** LEVEL[W]<br>{1}に存在しない値を指定しています。<br>値：{2}<p>
	 */
	public static String FXUCL0012 = "FXUCL0012";

	/** LEVEL[W]<br>{1}に存在しない値を指定しています。<br>値：{2}<br>行：{3}<p>
	 */
	public static String FXUCL0013 = "FXUCL0013";

	/** LEVEL[E]<br>存在チェックの項目名にはnullは指定できません。<p>
	 */
	public static String FXUCL0014 = "FXUCL0014";

	/** LEVEL[E]<br>マスタの存在チェック対象のＤＢコンテナにキー項目を設定していません。<br>テーブル : {1}<p>
	 */
	public static String FXUCL0015 = "FXUCL0015";

	/** LEVEL[E]<br>存在チェックの項目とチェック対象の項目の数が異なります。<br>存在チェックの項目 : {1}<br>チェック対象の項目 : {2}<p>
	 */
	public static String FXUCL0016 = "FXUCL0016";

	/** LEVEL[W]<br>登録できない値を指定しています。<br>{1}<p>
	 */
	public static String FXUCL0018 = "FXUCL0018";

	/** LEVEL[W]<br>登録できない値を指定しています。（行 : {1}）<br>{2}<p>
	 */
	public static String FXUCL0019 = "FXUCL0019";

	/** LEVEL[W]<br>文字列がパターンに一致しません。<br>項目名 : {1}<br>パターン : {2}<p>
	 */
	public static String FXUCL0020 = "FXUCL0020";

	/** LEVEL[W]<br>文字列がパターンに一致しません。<br>行 : {1}<br>項目名 : {2}<br>パターン : {3}<p>
	 */
	public static String FXUCL0021 = "FXUCL0021";

	/** LEVEL[E]<br>チェック対象の項目の数が多すぎます。<br>項目数 : {1}<br>上限 : {2}<p>
	 */
	public static String FXUCL0022 = "FXUCL0022";

	/** LEVEL[W]<br>{1}≦{2}≦{3}の関係で指定してください。<p>
	 */
	public static String FXUCL0023 = "FXUCL0023";

	/** LEVEL[W]<br>{1}≦{2}≦{3}の関係で指定してください。<br>行 : {4}<p>
	 */
	public static String FXUCL0024 = "FXUCL0024";

	/** LEVEL[W]<br>{1}＜{2}＜{3}の関係で指定してください。<p>
	 */
	public static String FXUCL0025 = "FXUCL0025";

	/** LEVEL[W]<br>{1}＜{2}＜{3}の関係で指定してください。<br>行 : {4}<p>
	 */
	public static String FXUCL0026 = "FXUCL0026";

	/** LEVEL[E]<br>予期せぬデータ型がセットされました。{1}<p>
	 */
	public static String FXUCC0001 = "FXUCC0001";

	/** LEVEL[I]<br>{1}/{2}/{3}<p>
	 */
	public static String FXUCC0002 = "FXUCC0002";

	/** LEVEL[I]<br>{1}/{2}<p>
	 */
	public static String FXUCC0003 = "FXUCC0003";

	/** LEVEL[I]<br>{1}/{2}/{3}<p>
	 */
	public static String FXUCC0004 = "FXUCC0004";

	/** LEVEL[I]<br>{1}/{2}<p>
	 */
	public static String FXUCC0005 = "FXUCC0005";

	/** LEVEL[I]<br>{1}%<p>
	 */
	public static String FXUCC0006 = "FXUCC0006";

	/** LEVEL[I]<br>{1}/{2}<p>
	 */
	public static String FXUCC0007 = "FXUCC0007";

	/** LEVEL[I]<br>{1}/{2}/{3} {4}:{5}:{6}<p>
	 */
	public static String FXUCC0008 = "FXUCC0008";

	/** LEVEL[I]<br>{1}/{2}/{3} {4}:{5}<p>
	 */
	public static String FXUCC0009 = "FXUCC0009";

	/** LEVEL[I]<br>{1}/{2}/{3} {4}:{5}:{6}<p>
	 */
	public static String FXUCC0010 = "FXUCC0010";

	/** LEVEL[I]<br>{1}/{2}/{3} {4}:{5}<p>
	 */
	public static String FXUCC0011 = "FXUCC0011";

	/** LEVEL[I]<br>{1}:{2}:{3}<p>
	 */
	public static String FXUCC0012 = "FXUCC0012";

	/** LEVEL[W]<br>要求数の合計と割当可能総数の符号が異なっています。<br>要求数合計：{1}<br>割当可能総数：{2}<p>
	 */
	public static String FXUCC0013 = "FXUCC0013";

	/** LEVEL[W]<br>割当比率の合計は０以外の数である必要があります。<br>割当比率合計：{1}<p>
	 */
	public static String FXUCC0014 = "FXUCC0014";

	/** LEVEL[T]<br>振り分け処理で残数が発生しました。残数：{1}<p>
	 */
	public static String FXUCC0015 = "FXUCC0015";

	/** LEVEL[E]<br>案分対象のリストが存在しないか0件です。<p>
	 */
	public static String FXUCC0016 = "FXUCC0016";

	/** LEVEL[E]<br>案分対象のリストの、割当比率が格納されている列のデータがありません。<br>割当比率が格納されている列名：{1}<p>
	 */
	public static String FXUCC0017 = "FXUCC0017";

	/** LEVEL[W]<br>振り分け処理で残数が発生しました。残数：{1}<p>
	 */
	public static String FXUCC0018 = "FXUCC0018";

	/** LEVEL[D]<br>キャッシュの上限値を超えたのでキャッシュを破棄します。<br>キャッシュ上限値：{1}<br>破棄したキー：{2}<br>破棄後のサイズ：{3}<p>
	 */
	public static String FXUCC0019 = "FXUCC0019";

	/** LEVEL[T]<br>キャッシュがありません。<br>キー値：{1}<br>キャッシュクラス：{2}<p>
	 */
	public static String FXUCC0020 = "FXUCC0020";

	/** LEVEL[T]<br>キャッシュを使いました。<br>キー値：{1}<br>キャッシュクラス：{2}<p>
	 */
	public static String FXUCC0021 = "FXUCC0021";

	/** LEVEL[I]<br>{1} : {2}<p>
	 */
	public static String FXUCC0022 = "FXUCC0022";

	/** LEVEL[W]<br>数字の桁数が大きすぎます。<br>項目名：{1}<br>値：{2}<br>指定可能な数字の整数部の最大桁数：{3}<br>指定可能な数字の小数部の最大桁数：{4}<p>
	 */
	public static String FXUCC0023 = "FXUCC0023";

	/** LEVEL[W]<br>数字の桁数が大きすぎます。<br>列名：{1}<br>行：{2}<br>値：{3}<br>指定可能な数字の整数部の最大桁数：{4}<br>指定可能な数字の小数部の最大桁数：{5}<p>
	 */
	public static String FXUCC0024 = "FXUCC0024";

	/** LEVEL[W]<br>文字列が長すぎます。<br>項目名：{1}<br>値：{2}<br>値の文字の長さ：{3}<br>指定可能な文字の長さ：{4}<p>
	 */
	public static String FXUCC0025 = "FXUCC0025";

	/** LEVEL[W]<br>文字列が長すぎます。<br>列名：{1}<br>行：{2}<br>値：{3}<br>値の文字の長さ：{4}<br>指定可能な文字の長さ：{5}<p>
	 */
	public static String FXUCC0026 = "FXUCC0026";

	/** LEVEL[W]<br>０より大きい数字を指定してください。<br>項目名：{1}<p>
	 */
	public static String FXUCC0027 = "FXUCC0027";

	/** LEVEL[W]<br>０より大きい数字を指定してください。<br>列名：{1}<br>行：{2}<p>
	 */
	public static String FXUCC0028 = "FXUCC0028";

	/** LEVEL[W]<br>０以外の数字を指定してください。<br>項目名：{1}<p>
	 */
	public static String FXUCC0029 = "FXUCC0029";

	/** LEVEL[W]<br>０以外の数字を指定してください。<br>列名：{1}<br>行：{2}<p>
	 */
	public static String FXUCC0030 = "FXUCC0030";

	/** LEVEL[W]<br>値の重複が発生しています。<br>項目：{1}<br>行：{2}<br>行：{3}<p>
	 */
	public static String FXUCC0031 = "FXUCC0031";

	/** LEVEL[W]<br>次のいずれかの値を指定してください。<br>{1}<p>
	 */
	public static String FXUCC0032 = "FXUCC0032";

	/** LEVEL[W]<br>次のいずれかの値を指定してください。（行：{1}）<br>{2}<p>
	 */
	public static String FXUCC0033 = "FXUCC0033";

	/** LEVEL[W]<br>{1}には運用日付以降を指定してください。<br>{1}：{2}<br>運用日付：{3}<p>
	 */
	public static String FXUCC0036 = "FXUCC0036";

	/** LEVEL[W]<br>{2}には運用日付以降を指定してください。<br>行：{1}<br>{2}：{3}<br>運用日付：{4}<p>
	 */
	public static String FXUCC0037 = "FXUCC0037";

	/** LEVEL[W]<br>{1}≦{2}≦運用日付の関係で指定してください。<br>{1}：{3}<br>{2}：{4}<br>運用日付：{5}<p>
	 */
	public static String FXUCC0038 = "FXUCC0038";

	/** LEVEL[W]<br>{2}≦{3}≦運用日付の関係で指定してください。<br>行：{1}<br>{2}：{4}<br>{3}：{5}<br>運用日付：{6}<p>
	 */
	public static String FXUCC0039 = "FXUCC0039";

	/** LEVEL[W]<br>{1}には運用日付以前を指定してください。<br>{1}：{2}<br>運用日付：{3}<p>
	 */
	public static String FXUCC0040 = "FXUCC0040";

	/** LEVEL[W]<br>{2}には運用日付以前を指定してください。<br>行：{1}<br>{2}：{3}<br>運用日付：{4}<p>
	 */
	public static String FXUCC0041 = "FXUCC0041";

	/** LEVEL[W]<br>{1}≦{2}≦{3}の関係で指定してください。<br>{1}：{4}<br>{2}：{5}<br>{3}：{6}<p>
	 */
	public static String FXUCC0042 = "FXUCC0042";

	/** LEVEL[W]<br>{2}≦{3}≦{4}の関係で指定してください。<br>行 : {1}<br>{2}：{5}<br>{3}：{6}<br>{4}：{7}<p>
	 */
	public static String FXUCC0043 = "FXUCC0043";

	/** LEVEL[W]<br>{1}≦{2}の関係で指定してください。<p>
	 */
	public static String FXUCC0044 = "FXUCC0044";

	/** LEVEL[W]<br>{1}≦{2}の関係で指定してください。<br>行 : {3}<p>
	 */
	public static String FXUCC0045 = "FXUCC0045";

	/** LEVEL[W]<br>必須項目に値が指定されていません。項目名：{1}<p>
	 */
	public static String FXUCC0046 = "FXUCC0046";

	/** LEVEL[W]<br>必須項目に値が指定されていません。行：{1}  列名：{2}<p>
	 */
	public static String FXUCC0047 = "FXUCC0047";

	/** LEVEL[W]<br>{1}≦{2}の関係で指定してください。<p>
	 */
	public static String FXUCC0048 = "FXUCC0048";

	/** LEVEL[W]<br>{1}≦{2}の関係で指定してください。<br>行 : {3}<p>
	 */
	public static String FXUCC0049 = "FXUCC0049";

	/** LEVEL[W]<br>次の項目はどれか１つしか指定できません。<br>{1}<p>
	 */
	public static String FXUCC0050 = "FXUCC0050";

	/** LEVEL[W]<br>次の項目はどれか１つしか指定できません。（行：{1}）<br>{2}<p>
	 */
	public static String FXUCC0051 = "FXUCC0051";

	/** LEVEL[W]<br>{1}＜{2}の関係で指定してください。<p>
	 */
	public static String FXUCC0052 = "FXUCC0052";

	/** LEVEL[W]<br>{1}＜{2}の関係で指定してください。<br>行 : {3}<p>
	 */
	public static String FXUCC0053 = "FXUCC0053";

	/** LEVEL[W]<br>{1}＜{2}の関係で指定してください。<p>
	 */
	public static String FXUCC0054 = "FXUCC0054";

	/** LEVEL[W]<br>{1}＜{2}の関係で指定してください。<br>行 : {3}<p>
	 */
	public static String FXUCC0055 = "FXUCC0055";

	/** LEVEL[W]<br>{1}＜{2}＜{3}の関係で指定してください。<br>{1}：{4}<br>{2}：{5}<br>{3}：{6}<p>
	 */
	public static String FXUCC0056 = "FXUCC0056";

	/** LEVEL[W]<br>{2}＜{3}＜{4}の関係で指定してください。<br>行 : {1}<br>{2}：{5}<br>{3}：{6}<br>{4}：{7}<p>
	 */
	public static String FXUCC0057 = "FXUCC0057";

	/** LEVEL[W]<br>{1}には運用日付より後の日付を指定してください。<br>{1}：{2}<br>運用日付：{3}<p>
	 */
	public static String FXUCC0058 = "FXUCC0058";

	/** LEVEL[W]<br>{2}には運用日付より後の日付を指定してください。<br>行：{1}<br>{2}：{3}<br>運用日付：{4}<p>
	 */
	public static String FXUCC0059 = "FXUCC0059";

	/** LEVEL[W]<br>{1}には運用日付より前の日付を指定してください。<br>{1}：{2}<br>運用日付：{3}<p>
	 */
	public static String FXUCC0060 = "FXUCC0060";

	/** LEVEL[W]<br>{2}には運用日付より前の日付を指定してください。<br>行：{1}<br>{2}：{3}<br>運用日付：{4}<p>
	 */
	public static String FXUCC0061 = "FXUCC0061";

	/** LEVEL[W]<br>{1}＜{2}＜運用日付の関係で指定してください。<br>{1}：{3}<br>{2}：{4}<br>運用日付：{5}<p>
	 */
	public static String FXUCC0062 = "FXUCC0062";

	/** LEVEL[W]<br>{2}＜{3}＜運用日付の関係で指定してください。<br>行：{1}<br>{2}：{4}<br>{3}：{5}<br>運用日付：{6}<p>
	 */
	public static String FXUCC0063 = "FXUCC0063";

	/** LEVEL[E]<br>日付に変換不可能な値がセットされました。年月：{1}  日付：{2}<p>
	 */
	public static String FXUCD0001 = "FXUCD0001";

	/** LEVEL[E]<br>端数処理区分が不正なため、端数処理に失敗しました。<br>端数処理区分：{1}<p>
	 */
	public static String FXUCD0003 = "FXUCD0003";

	/** LEVEL[E]<br>振り分け処理で残数が発生しました。残数：{1}<p>
	 */
	public static String FXUCD0004 = "FXUCD0004";

	/** LEVEL[E]<br>割当比率の合計は０以外の数である必要があります。<br>割当比率合計：{1}<p>
	 */
	public static String FXUCD0005 = "FXUCD0005";

	/** LEVEL[I]<br>全{1}件中 {2}件 ～ {3}件を表示<p>
	 */
	public static String FXUCP0001 = "FXUCP0001";

	/** LEVEL[E]<br>PrintScreenを行うためのユーティリティクラス（java.awt.Robot）の作成に失敗しました。<br>{1}<p>
	 */
	public static String FXUCP0002 = "FXUCP0002";

	/** LEVEL[E]<br>画像データをデータ転送可能なオブジェクトに変換する処理に失敗しました。<br>flavor : {1}<br>_flvs[0] : {2}<p>
	 */
	public static String FXUCP0003 = "FXUCP0003";

	/** LEVEL[W]<br>出力ファイル名にファイル名に使用できない文字が含まれています。<br>出力ファイル名：{1}<br>使用できない文字<br>{2}<p>
	 */
	public static String FXUCP0004 = "FXUCP0004";

	/** LEVEL[W]<br>指定された出力先には、既に読み取り専用のファイルが存在します。ファイル出力できません。<br>出力ファイル名：{1}<p>
	 */
	public static String FXUCP0005 = "FXUCP0005";

	/** LEVEL[W]<br>指定されたファイルを開けませんでした。<br>別のアプリケーションから使用されている可能性があります。<br>ファイル名：{1}<p>
	 */
	public static String FXUCP0006 = "FXUCP0006";

	/** LEVEL[E]<br>ファイル出力に失敗しました。<br>ファイル名：{1}<br>{2}<p>
	 */
	public static String FXUCP0007 = "FXUCP0007";

	/** LEVEL[E]<br>未対応の出力画像フォーマットです。<br>出力しようとしたフォーマット：{1}<br>出力可能なフォーマット：{2}<p>
	 */
	public static String FXUCP0008 = "FXUCP0008";

	/** LEVEL[W]<br>出力先フォルダが作成できませんでした。<br>出力先フォルダ：{1}<p>
	 */
	public static String FXUCP0009 = "FXUCP0009";

	/** LEVEL[W]<br>出力先フォルダ内にファイル作成ができませんでした。<br>出力先フォルダ：{1}<p>
	 */
	public static String FXUCP0010 = "FXUCP0010";

	/** LEVEL[D]<br>画像ファイルを出力しました。<br>ファイル名：{1}<p>
	 */
	public static String FXUCP0011 = "FXUCP0011";

	/** LEVEL[D]<br>クリップボードに画像ファイルを出力しました。<p>
	 */
	public static String FXUCP0012 = "FXUCP0012";

	/** LEVEL[E]<br>リソースキーが存在しません。<br>キー：{1}<p>
	 */
	public static String FXUCP0013 = "FXUCP0013";

	/** LEVEL[E]<br>リソース値にnullが設定されています。<br>キー：{1}<p>
	 */
	public static String FXUCP0014 = "FXUCP0014";

	/** LEVEL[D]<br>リソースから値を取得しました。<br>キー：{1}<br>値：{2}<p>
	 */
	public static String FXUCP0015 = "FXUCP0015";

	/** LEVEL[D]<br>PrintScreen処理開始<br>対象のクラス：{1}<br>対象の名前：{2}<br>対象の画面上での位置：{3}<br>対象のサイズ：{4}<p>
	 */
	public static String FXUCP0016 = "FXUCP0016";

	/** LEVEL[W]<br>クリップボードに画像をセットできませんでした。<p>
	 */
	public static String FXUCP0017 = "FXUCP0017";

	/** LEVEL[I]<br>画面遷移設定を保存します。よろしいですか？<p>
	 */
	public static String FXUCP0018 = "FXUCP0018";

	/** LEVEL[I]<br>画面遷移設定を保存しました。<p>
	 */
	public static String FXUCP0019 = "FXUCP0019";

	/** LEVEL[I]<br>見つかりませんでした。<p>
	 */
	public static String FXUCP0020 = "FXUCP0020";

	/** LEVEL[W]<br>検索対象がありません。<p>
	 */
	public static String FXUCP0021 = "FXUCP0021";

	/** LEVEL[W]<br>処理が異常終了しました。<br>終了コード：{1}<br>{2}<p>
	 */
	public static String FXUCP0022 = "FXUCP0022";

	/** LEVEL[D]<br>外部プロセスを実行します。<br>実行コマンド：{1}<p>
	 */
	public static String FXUCP0023 = "FXUCP0023";

	/** LEVEL[T]<br>外部プロセスが正常終了しました。<p>
	 */
	public static String FXUCP0024 = "FXUCP0024";

	/** LEVEL[T]<br>外部プロセスの標準出力です。<br>{1}<p>
	 */
	public static String FXUCP0025 = "FXUCP0025";

	/** LEVEL[W]<br>処理の実行に失敗しました。<p>
	 */
	public static String FXUCP0026 = "FXUCP0026";

	/** LEVEL[E]<br>実行するコマンドが指定されていません。<p>
	 */
	public static String FXUCP0027 = "FXUCP0027";

	/** LEVEL[W]<br>Excel出力を行う権限がありません。<p>
	 */
	public static String FXUCP0028 = "FXUCP0028";

	/** LEVEL[I]<br>ツールバーを隠す<p>
	 */
	public static String FXUCP0029 = "FXUCP0029";

	/** LEVEL[I]<br>ツールバーを表示<p>
	 */
	public static String FXUCP0030 = "FXUCP0030";

	/** LEVEL[I]<br>画面遷移連携設定を保存します。よろしいですか？<p>
	 */
	public static String FXUCP0031 = "FXUCP0031";

	/** LEVEL[E]<br>画面の表示に失敗しました。<br>この画面は埋込画面として利用するための画面です。<br>モジュールID：{1}<br>スクリーンID：{2}<p>
	 */
	public static String FXUCP0032 = "FXUCP0032";

	/** LEVEL[E]<br>画面の表示に失敗しました。<br>この画面を埋込画面として利用する場合は、IfPagingAgentHolderインターフェースを実装する必要があります。<br>モジュールID：{1}<br>スクリーンID：{2}<p>
	 */
	public static String FXUCP0033 = "FXUCP0033";

	/** LEVEL[W]<br>印刷処理中にエラーが発生しました。<br>{1}<p>
	 */
	public static String FXUCP0034 = "FXUCP0034";

	/** LEVEL[D]<br>プリンタで画像を印刷しました。<p>
	 */
	public static String FXUCP0035 = "FXUCP0035";

	/** LEVEL[E]<br>バイトカウント処理でエラーが発生しました。<p>
	 */
	public static String FXUCP0036 = "FXUCP0036";

	/** LEVEL[W]<br>ファイルが見つかりません。<br>ファイル：{1}<p>
	 */
	public static String FXUCP0037 = "FXUCP0037";

	/** LEVEL[W]<br>開始年月終了年月に重複期間があります。<br>行：{1}<br>行：{2}<p>
	 */
	public static String FXUCP0038 = "FXUCP0038";

	/** LEVEL[W]<br>開始年月終了年月に重複期間があったため、自動調整しました。<br>行：{1}<br>行：{2}<p>
	 */
	public static String FXUCP0039 = "FXUCP0039";

	/** LEVEL[W]<br>開始年月終了年月に重複期間があります。開始年月が同じため自動調整できませんでした。<br>行：{1}<br>行：{2}<p>
	 */
	public static String FXUCP0040 = "FXUCP0040";

	/** LEVEL[E]<br>処理結果件数が期待した件数と異なりました。<br>期待した件数：{1}<br>実際の結果件数：{2}<p>
	 */
	public static String FXUDL0001 = "FXUDL0001";

	/** LEVEL[E]<br>定数に存在しない値が設定されました。<br>存在しない値：{1}<p>
	 */
	public static String FXUDL0002 = "FXUDL0002";

	/** LEVEL[T]<br>更新日時を更新するためのupdateを実行します。（実際のデータ更新は、update文では無くトリガによって更新されます。）<p>
	 */
	public static String FXUDL0003 = "FXUDL0003";

	/** LEVEL[E]<br>予期せぬステータスを検出しました。<br>{1}<p>
	 */
	public static String FXUDL0004 = "FXUDL0004";

	/** LEVEL[W]<br>新規追加行は、既に登録されています。<p>
	 */
	public static String FXUDL0005 = "FXUDL0005";

	/** LEVEL[I]<br>削除対象行は、既に削除されています。削除処理を行いませんでした。<p>
	 */
	public static String FXUDL0006 = "FXUDL0006";

	/** LEVEL[W]<br>アプリケーションコンテキストから会社コードを取得できませんでした。<p>
	 */
	public static String FXUDL0007 = "FXUDL0007";

	/** LEVEL[E]<br>定義されているキー項目の数と引数のキー項目の数は同一でなければなりません。<p>
	 */
	public static String FXUDL0008 = "FXUDL0008";

	/** LEVEL[E]<br>検索条件に使用するカラム名の配列とバインド値を取得するカラム名の配列の長さは同じでなければなりません。<p>
	 */
	public static String FXUDL0009 = "FXUDL0009";

	/** LEVEL[W]<br>データの追加に失敗しました。登録対象のデータは既に追加されています。<p>
	 */
	public static String FXUDL0010 = "FXUDL0010";

	/** LEVEL[E]<br>ロックできたリストとロックできなかったリスト、両方nullの場合は処理できません。<p>
	 */
	public static String FXUDL0011 = "FXUDL0011";

	/** LEVEL[E]<br>処理結果件数が期待した件数と異なりました。<br>期待した件数：{1}<br>実際の結果件数：{2}<br>テーブル名：{3}<br>{4}<p>
	 */
	public static String FXUDL0012 = "FXUDL0012";

	/** LEVEL[E]<br>定数に存在しない値が設定されました。<br>存在しない値：{1}<p>
	 */
	public static String FXUDD0002 = "FXUDD0002";

	/** LEVEL[I]<br>{1}処理を開始しました。バージョン {2}<p>
	 */
	public static String FXUDD9001 = "FXUDD9001";

	/** LEVEL[I]<br>正常終了しました。<p>
	 */
	public static String FXUDD9002 = "FXUDD9002";

	/** LEVEL[I]<br>{1}処理を開始しました。{2}<p>
	 */
	public static String FXUDD9003 = "FXUDD9003";

	/** LEVEL[I]<br>バッチ処理が終了しました。<p>
	 */
	public static String FXUDD9004 = "FXUDD9004";

	/** LEVEL[I]<br>{1}処理を終了しました。{2}<p>
	 */
	public static String FXUDD9005 = "FXUDD9005";

	/** LEVEL[I]<br>実行可否確認処理を通過しました。サーバロジック実行を開始します。<p>
	 */
	public static String FXUDD9010 = "FXUDD9010";

	/** LEVEL[I]<br>サーバ停止中です。<p>
	 */
	public static String FXUDD9011 = "FXUDD9011";

	/** LEVEL[I]<br>バッチ処理専用時間帯です。<p>
	 */
	public static String FXUDD9012 = "FXUDD9012";

	/** LEVEL[I]<br>オンライン開始準備中です。<p>
	 */
	public static String FXUDD9013 = "FXUDD9013";

	/** LEVEL[I]<br>オンライン稼動中です。<p>
	 */
	public static String FXUDD9014 = "FXUDD9014";

	/** LEVEL[I]<br>オンライン終了準備中です。<p>
	 */
	public static String FXUDD9015 = "FXUDD9015";

	/** LEVEL[I]<br>サーバメンテナンス中です。<p>
	 */
	public static String FXUDD9016 = "FXUDD9016";

	/** LEVEL[I]<br>トラブル発生のため、只今利用できません。<p>
	 */
	public static String FXUDD9017 = "FXUDD9017";

	/** LEVEL[I]<br>バックアップ中のため更新処理を制限しています。<p>
	 */
	public static String FXUDD9018 = "FXUDD9018";

	/** LEVEL[I]<br>テスト中です。アクセスは制限されます。<p>
	 */
	public static String FXUDD9019 = "FXUDD9019";

	/** LEVEL[I]<br>タイムアウトしています。再ログインしてください。<p>
	 */
	public static String FXUDD9020 = "FXUDD9020";

	/** LEVEL[W]<br>処理中に警告が発生しています。サーバログを確認ください。<p>
	 */
	public static String FXUDD9200 = "FXUDD9200";

	/** LEVEL[W]<br>サーバ処理が混雑しています。しばらくお待ちください。<p>
	 */
	public static String FXUDD9201 = "FXUDD9201";

	/** LEVEL[W]<br>所定の試行回数内にサーバ処理を開始できませんでした。<p>
	 */
	public static String FXUDD9202 = "FXUDD9202";

	/** LEVEL[W]<br>異常終了しました。{1}<p>
	 */
	public static String FXUDD9400 = "FXUDD9400";

	/** LEVEL[W]<br>引数が正しく与えられていません。{1}<p>
	 */
	public static String FXUDD9401 = "FXUDD9401";

	/** LEVEL[W]<br>エラーが発生しました。{1}<p>
	 */
	public static String FXUDD9402 = "FXUDD9402";

	/** LEVEL[W]<br>オラクルエラーが発生しました。プロシージャ:{1} . ORACLE ErrorCode :{2}<p>
	 */
	public static String FXUDD9403 = "FXUDD9403";

	/** LEVEL[W]<br>実行可否確認処理で停止しました。 ORACLE ErrorCode : {1}<p>
	 */
	public static String FXUDD9420 = "FXUDD9420";

	/** LEVEL[W]<br>実行可否確認処理が停止しました。 処理IDが正しく与えられていません。<p>
	 */
	public static String FXUDD9421 = "FXUDD9421";

	/** LEVEL[W]<br>サーバ稼動状態が変更されています。再ログインしてください。<p>
	 */
	public static String FXUDD9422 = "FXUDD9422";
}
