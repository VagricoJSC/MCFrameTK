package mcframe.commonFX.constant;

import mcframe.commonCore.annotation.EI;
/** バッチログ区分 */
@EI
public class FXC_BATCH_LOG_TYP extends FXC_BATCH_LOG_TYP_FW {

	/**
	 * コンストラクタ
	 */
	protected FXC_BATCH_LOG_TYP() {
		super();
	}
}
