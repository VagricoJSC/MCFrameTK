package mcframe.commonFX.constant;

public abstract class FX_Const_FW extends mcframe.commonCore.constant.MCRootConst{


}
