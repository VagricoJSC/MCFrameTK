package mcframe.commonFX.constant;

abstract class FXC_RESOURCE_SETTING_UNIT_FW extends FXC_RESOURCE_SETTING_UNIT_FW_A {

}
