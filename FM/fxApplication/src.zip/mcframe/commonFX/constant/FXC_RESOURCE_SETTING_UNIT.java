package mcframe.commonFX.constant;

import mcframe.commonCore.annotation.EI;
/** リソース設定単位 */
@EI
public class FXC_RESOURCE_SETTING_UNIT extends FXC_RESOURCE_SETTING_UNIT_FW {

	/**
	 * コンストラクタ
	 */
	protected FXC_RESOURCE_SETTING_UNIT() {
		super();
	}
}
