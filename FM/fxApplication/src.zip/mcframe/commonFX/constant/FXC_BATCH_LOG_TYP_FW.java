package mcframe.commonFX.constant;

abstract class FXC_BATCH_LOG_TYP_FW extends FXC_BATCH_LOG_TYP_FW_A {

}
