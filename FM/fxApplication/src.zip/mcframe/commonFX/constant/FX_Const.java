package mcframe.commonFX.constant;

public abstract class FX_Const extends FX_Const_FW{

}
