@echo off
@setlocal

set LOG_DIR=%~dp0\log
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

call %~dp0\load_config.cmd

if "%DB_PRODUCT%" == "Oracle" (
    set CONN_STR=%DB_USER%/%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_ORA_SVC%
    set NLS_LANG=American_america.AL32UTF8
) else if "%DB_PRODUCT%" == "PostgreSQL" (
    set CONN_STR=-d postgresql://%DB_USER%:%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_POS_DBNAME%
)

if "%DB_PRODUCT%" == "Oracle" (
    pushd %~dp0\sql\oracle
    sqlplus %CONN_STR% @create_worktables.sql > %LOG_DIR%\setup.log
    popd
) else if "%DB_PRODUCT%" == "PostgreSQL" (
    pushd %~dp0\sql\postgresql
    psql %CONN_STR% -f create_worktables.sql -v db_schema=%DB_POS_SCHEMA% > %LOG_DIR%\setup.log 2>&1
    popd
)

@endlocal
@echo on
