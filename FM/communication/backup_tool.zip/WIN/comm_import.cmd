@echo off
@setlocal enabledelayedexpansion

set LOG_DIR=%~dp0\log
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

call %~dp0\load_config.cmd

set IMP_TABLES=AWT_BINARY,AWT_ARTICLE,AWT_KN_ATTACHMENTS,AWT_KN_COMMENTS,AWT_KN_COMMENT_FILES,AWT_KN_POSTDATE,AWT_KN_TAGS,AWT_ACTIVITIES,AWT_TL_ATTACHMENTS,AWT_TL_COMMENTS,AWT_TL_COMMENT_FILES,AWT_TL_POSTDATE,AWT_TL_TAGS

if "%DB_PRODUCT%" == "Oracle" (
    set CONN_STR=%DB_USER%/%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_ORA_SVC%
    set PAR_DIR=%~dp0\parfile\imp
    set NLS_LANG=American_america.AL32UTF8
    set SQL_DIR=%~dp0\sql\oracle
) else if "%DB_PRODUCT%" == "PostgreSQL" (
    set CONN_STR=-d postgresql://%DB_USER%:%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_POS_DBNAME%
    set SQL_DIR=%~dp0\sql\postgresql
)


pushd %SQL_DIR%
if "%DB_PRODUCT%" == "Oracle" (
    @echo ========== Executing importation in %DB_USER% %DB_PASS% %DB_HOST% %DB_PORT% %DB_ORA_SVC% ========== > %LOG_DIR%\comm_import.log

    for %%i in (%IMP_TABLES%) do (
        @echo ========== Importing data to table %%i ========== >> %LOG_DIR%\comm_import.log
        impdp %CONN_STR% DIRECTORY=%EXP_DIR% PARFILE=%PAR_DIR%\%%i.par >> %LOG_DIR%\comm_import.log 2>&1

        if not !errorlevel! == 0 (
            goto imp_error
        )
    )

) else if "%DB_PRODUCT%" == "PostgreSQL" (
    @echo ========== Executing importation in %DB_USER% %DB_PASS% %DB_HOST% %DB_PORT% %DB_POS_DBNAME% %DB_POS_SCHEMA% ========== > %LOG_DIR%\comm_import.log

    @echo ========== Importing data to tables ========== >> %LOG_DIR%\comm_import.log
    pushd %EXP_DIR%
    psql %CONN_STR% -f %SQL_DIR%\import_data.sql -v db_schema=%DB_POS_SCHEMA% >> %LOG_DIR%\comm_import.log 2>&1
    popd

    if not !errorlevel! == 0 (
        goto imp_error
    )

)
popd

@echo ========== Command finished. ========== >> %LOG_DIR%\comm_import.log
set ret=0
goto fin

:imp_error
@echo Error(s) occurd while importing. >> %LOG_DIR%\comm_import.log
set ret=-1
goto fin

:fin
@echo on
@exit /b %ret%
