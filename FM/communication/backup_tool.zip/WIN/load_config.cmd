
pushd %~dp0

set CONFIGINI=config.ini

if not "%~1".=="". set INIFILE=%1

if not "%INIFILE%".=="". goto readIni

if exist %CONFIGINI% (
	set INIFILE=%CONFIGINI%
)

:readIni

FOR /F "eol=# tokens=1,2 delims==" %%a in (%INIFILE%) do (
	call set %%a=%%b
)

POPD

:end
