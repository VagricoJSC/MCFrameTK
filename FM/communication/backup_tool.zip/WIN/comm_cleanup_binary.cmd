@echo off
@setlocal

set LOG_DIR=%~dp0\log
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

call %~dp0\load_config.cmd

if "%DB_PRODUCT%" == "Oracle" (
    set CONN_STR=%DB_USER%/%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_ORA_SVC%
    set NLS_LANG=American_america.AL32UTF8
    set SQL_DIR=%~dp0\sql\oracle
) else if "%DB_PRODUCT%" == "PostgreSQL" (
    set CONN_STR=-d postgresql://%DB_USER%:%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_POS_DBNAME%
    set SQL_DIR=%~dp0\sql\postgresql
)

pushd %SQL_DIR%

if "%DB_PRODUCT%" == "Oracle" (
    @echo ========== Deleting unused binary data in %DB_USER% %DB_PASS% %DB_HOST% %DB_PORT% %DB_ORA_SVC% ========== > %LOG_DIR%\comm_cleanup_binary.log
    sqlplus %CONN_STR% @delete_binary.sql >> %LOG_DIR%\comm_cleanup_binary.log 2>&1
) else if "%DB_PRODUCT%" == "PostgreSQL" (
    @echo ========== Deleting unused binary data in %DB_USER% %DB_PASS% %DB_HOST% %DB_PORT% %DB_POS_DBNAME% %DB_POS_SCHEMA% ========== > %LOG_DIR%\comm_cleanup_binary.log
    psql %CONN_STR% -f delete_binary.sql -v db_schema=%DB_POS_SCHEMA% >> %LOG_DIR%\comm_cleanup_binary.log 2>&1
)

if not %errorlevel% == 0 (
    popd
    goto del_error
)

@echo ========== Command finished. ========== >> %LOG_DIR%\comm_cleanup_binary.log
popd
set ret=0
goto fin

:del_error
@echo An error occurrd while deleting data. >> %LOG_DIR%\comm_cleanup_binary.log
set ret=-1
goto fin

:fin
@echo on
@exit /b %ret%
