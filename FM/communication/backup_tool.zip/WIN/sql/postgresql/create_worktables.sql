\encoding UTF-8

set search_path to :db_schema;

CREATE TABLE aww_kn_export
(id varchar (24)  NOT NULL
);

CREATE TABLE aww_tl_export
(id varchar (24)  NOT NULL
);
