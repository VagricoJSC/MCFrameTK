\encoding UTF-8

set search_path to :db_schema;

copy (
    select
        *
    from awt_tl_postdate
    where activity_id in (select id from aww_tl_export))
to
    stdout
with (
    format text,
    encoding UTF8);

\g awt_tl_postdate.txt
