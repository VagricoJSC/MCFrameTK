\encoding UTF-8

set search_path to :db_schema;

copy (
    select
        *
    from
        awt_binary
    where
        bid in (
            select
                bid
            from
                aww_kn_export ex
                inner join awt_kn_attachments t on ex.id = t.article_id
            union
            select
                bid
            from
                aww_kn_export ex
                inner join awt_kn_comment_files t on ex.id = t.article_id
            union
            select
                bid
            from
                aww_tl_export ex
                inner join awt_tl_attachments t on ex.id = t.activity_id
            union
            select
                bid
            from
                aww_tl_export ex
                inner join awt_tl_comment_files t on ex.id = t.activity_id
        )
)
to
    stdout
with (
    format text,
    encoding UTF8);

\g awt_binary.txt
