\encoding UTF-8

set search_path to :db_schema;

copy (
    select
        *
    from awt_activities
    where id in (select id from aww_tl_export))
to
    stdout
with (
    format text,
    encoding UTF8);

\g awt_activities.txt
