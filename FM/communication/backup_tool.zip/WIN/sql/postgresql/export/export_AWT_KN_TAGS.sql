\encoding UTF-8

set search_path to :db_schema;

copy (
    select
        *
    from awt_kn_tags
    where article_id in (select id from aww_kn_export))
to
    stdout
with (
    format text,
    encoding UTF8);

\g awt_kn_tags.txt
