\encoding UTF-8

set search_path to :db_schema;

show search_path;

delete from
    awt_binary bin
where
    bin.bid not in (
        select
            bid
        from
            awt_kn_attachments
        union
        select
            bid
        from
            awt_kn_comment_files
        union
        select
            bid
        from
            awt_tl_attachments
        union
        select
            bid
        from
            awt_tl_comment_files
    );

commit;

\quit