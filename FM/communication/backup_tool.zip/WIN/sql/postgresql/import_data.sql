\encoding UTF-8

set search_path to :db_schema;

\copy awt_binary from 'AWT_BINARY.txt' with (format text, encoding UTF8)

\copy awt_article from 'AWT_ARTICLE.txt' with (format text, encoding UTF8)

\copy awt_kn_attachments from 'AWT_KN_ATTACHMENTS.txt' with (format text, encoding UTF8)

\copy awt_kn_comments from 'AWT_KN_COMMENTS.txt' with (format text, encoding UTF8)

\copy awt_kn_comment_files from 'AWT_KN_COMMENT_FILES.txt' with (format text, encoding UTF8)

\copy awt_kn_postdate from 'AWT_KN_POSTDATE.txt' with (format text, encoding UTF8)

\copy awt_kn_tags from 'AWT_KN_TAGS.txt' with (format text, encoding UTF8)

\copy awt_activities from 'AWT_ACTIVITIES.txt' with (format text, encoding UTF8)

\copy awt_tl_attachments from 'AWT_TL_ATTACHMENTS.txt' with (format text, encoding UTF8)

\copy awt_tl_comments from 'AWT_TL_COMMENTS.txt' with (format text, encoding UTF8)

\copy awt_tl_comment_files from 'AWT_TL_COMMENT_FILES.txt' with (format text, encoding UTF8)

\copy awt_tl_postdate from 'AWT_TL_POSTDATE.txt' with (format text, encoding UTF8)

\copy awt_tl_tags from 'AWT_TL_TAGS.txt' with (format text, encoding UTF8)
