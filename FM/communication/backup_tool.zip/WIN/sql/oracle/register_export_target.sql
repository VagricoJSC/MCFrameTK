delete from aww_kn_export;
delete from aww_tl_export;

-- Khowledges
insert into
    aww_kn_export (id)
with T1 as (
    select distinct
        article_id,
        max(post_date) max_pdate
    from
        awt_kn_postdate
    group by
        article_id
),
T2 as (
    select
        article_id
    from
        awt_kn_tags
    where
        &3
)
select
    T1.article_id id
from
    T1
    inner join T2
        on T1.article_id = T2.article_id
        and T1.max_pdate between to_date('&1', 'YYYYMMDD') and to_date('&2', 'YYYYMMDD')
;

-- Timeline activities
insert into
    aww_tl_export (id)
with T1 as (
    select distinct
        activity_id,
        max(post_date) max_pdate
    from
        awt_tl_postdate
    group by
        activity_id
),
T2 as (
    select
        activity_id
    from
        awt_tl_tags
    where
        &3
)
select
    T1.activity_id id
from
    T1
    inner join T2
        on T1.activity_id = T2.activity_id
        and T1.max_pdate between to_date('&1', 'YYYYMMDD') and to_date('&2', 'YYYYMMDD')
;

commit;
quit;
