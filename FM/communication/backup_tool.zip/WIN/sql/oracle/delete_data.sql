delete from
    awt_article T1
where exists (
    select
        1
    from
        aww_kn_export T2
    where
        T1.id = T2.id
);


delete from
    awt_kn_attachments T1
where exists (
    select
        1
    from
        aww_kn_export T2
    where
        T1.article_id = T2.id
);

delete from
    awt_kn_comments T1
where exists (
    select
        1
    from
        aww_kn_export T2
    where
        T1.article_id = T2.id
);

delete from
    awt_kn_comment_files T1
where exists (
    select
        1
    from
        aww_kn_export T2
    where
        T1.article_id = T2.id
);

delete from
    awt_kn_postdate T1
where exists (
    select
        1
    from
        aww_kn_export T2
    where
        T1.article_id = T2.id
);

delete from
    awt_kn_tags T1
where exists (
    select
        1
    from
        aww_kn_export T2
    where
        T1.article_id = T2.id
);

delete from
    awt_activities T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.id = T2.id
);

delete from
    awt_tl_attachments T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.activity_id = T2.id
);

delete from
    awt_tl_comments T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.activity_id = T2.id
);

delete from
    awt_tl_comment_files T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.activity_id = T2.id
);

delete from
    awt_tl_postdate T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.activity_id = T2.id
);

delete from
    awt_tl_tags T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.activity_id = T2.id
);

delete from
    awt_timeline T1
where exists (
    select
        1
    from
        aww_tl_export T2
    where
        T1.activity_id = T2.id
);

delete from
    awt_binary bin
where
    bin.bid not in (
        select
            bid
        from
            awt_kn_attachments
        union
        select
            bid
        from
            awt_kn_comment_files
        union
        select
            bid
        from
            awt_tl_attachments
        union
        select
            bid
        from
            awt_tl_comment_files
    );

commit;

quit;