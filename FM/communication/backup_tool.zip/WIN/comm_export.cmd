@echo off
@setlocal enabledelayedexpansion

call %~dp0\load_config.cmd

set LOG_DIR=%~dp0\log
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

set TAG_COND=
for %%i in (%EXP_TAGS%) do (
    if not "!TAG_COND!" == "" (
        set TAG_COND=!TAG_COND! or 
    )

    for /f "tokens=1,2 delims=:" %%x in ("%%i") do (
        set TAG_COND=!TAG_COND!^(tag_name = '%%x'
        if not "%%y" == "" (
            set TAG_COND=!TAG_COND! and tag_value = '%%y'
        )
        set TAG_COND=!TAG_COND!^)
    )
)
if "!TAG_COND!" == "" (
    set TAG_COND=0=0
)

if "%EXP_DATE_FROM%" == "" (
    set EXP_DATE_FROM=19700101
)
if "%EXP_DATE_TO%" == "" (
    rem set EXP_DATE_TO=%date:~-10,4%%date:~-5,2%%date:~-2,2%
    for /f "usebackq" %%A in (`powershell -NoProfile -command "Get-Date -Format 'yyyyMMdd'"`) do set "EXP_DATE_TO=%%A"
)

set EXP_TABLES=AWT_BINARY,AWT_ARTICLE,AWT_KN_ATTACHMENTS,AWT_KN_COMMENTS,AWT_KN_COMMENT_FILES,AWT_KN_POSTDATE,AWT_KN_TAGS,AWT_ACTIVITIES,AWT_TL_ATTACHMENTS,AWT_TL_COMMENTS,AWT_TL_COMMENT_FILES,AWT_TL_POSTDATE,AWT_TL_TAGS

if "%DB_PRODUCT%" == "Oracle" (
    set CONN_STR=%DB_USER%/%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_ORA_SVC%
    set PAR_DIR=%~dp0\parfile\exp
    set NLS_LANG=American_america.AL32UTF8
    set SQL_DIR=%~dp0\sql\oracle
) else if "%DB_PRODUCT%" == "PostgreSQL" (
    set CONN_STR=-d postgresql://%DB_USER%:%DB_PASS%@%DB_HOST%:%DB_PORT%/%DB_POS_DBNAME%
    set SQL_DIR=%~dp0\sql\postgresql
)

pushd %SQL_DIR%

if "%DB_PRODUCT%" == "Oracle" (

    @echo ========== Searching export targets in %DB_USER% %DB_PASS% %DB_HOST% %DB_PORT% %DB_ORA_SVC% ========== > %LOG_DIR%\comm_export.log

    sqlplus %CONN_STR% @register_export_target.sql "%EXP_DATE_FROM%" "%EXP_DATE_TO%" "%TAG_COND%" >> %LOG_DIR%\comm_export.log

    if not !errorlevel! == 0 (
        goto exp_error
    )

    for %%i in (%EXP_TABLES%) do (
        @echo ========== Exporting data from table %%i ========== >> %LOG_DIR%\comm_export.log
        expdp %CONN_STR% DIRECTORY=%EXP_DIR% PARFILE=%PAR_DIR%\%%i.par >> %LOG_DIR%\comm_export.log 2>&1

        if not !errorlevel! == 0 (
            goto exp_error
        )
    )

    if "%EXP_DELETE_DATA%" == "true" (
        @echo ========== Deleting exported data from tables ========== >> %LOG_DIR%\comm_export.log
        sqlplus %CONN_STR% @delete_data.sql >> %LOG_DIR%\comm_export.log 2>&1

        if not !errorlevel! == 0 (
            goto del_error
        )
    )
) else if "%DB_PRODUCT%" == "PostgreSQL" (

    @echo ========== Searching export targets in %DB_USER% %DB_PASS% %DB_HOST% %DB_PORT% %DB_POS_DBNAME% %DB_POS_SCHEMA% ========== > %LOG_DIR%\comm_export.log
    psql %CONN_STR% -f register_export_target.sql -v db_schema=%DB_POS_SCHEMA% -v date_from=%EXP_DATE_FROM% -v date_to=%EXP_DATE_TO% -v tag_cond="!TAG_COND!" >> %LOG_DIR%\comm_export.log 2>&1

    if not !errorlevel! == 0 (
        goto exp_error
    )

    if not exist "%EXP_DIR%" mkdir "%EXP_DIR%"
    pushd %EXP_DIR%
    for %%i in (%EXP_TABLES%) do (
        @echo ========== Exporting data from table %%i ========== >> %LOG_DIR%\comm_export.log
        psql %CONN_STR% -f %SQL_DIR%\export\export_%%i.sql -v db_schema=%DB_POS_SCHEMA% >> %LOG_DIR%\comm_export.log 2>&1

        if not !errorlevel! == 0 (
            goto exp_error
        )
    )
    popd

    if "%EXP_DELETE_DATA%" == "true" (
        @echo ========== Deleting exported data from tables ========== >> %LOG_DIR%\comm_export.log
        psql %CONN_STR% -f delete_data.sql -v db_schema=%DB_POS_SCHEMA% >> %LOG_DIR%\comm_export.log 2>&1

        if not !errorlevel! == 0 (
            goto del_error
        )
    )
)
popd

@echo ========== Command finished. ========== >> %LOG_DIR%\comm_export.log
set ret=0
goto fin

:exp_error
@echo Error(s) occurrd while exporting data.  >> %LOG_DIR%\comm_export.log
set ret=-1
goto fin

:del_error
@echo An error occurrd while deleting data. >> %LOG_DIR%\comm_export.log
set ret=-1
goto fin

:fin
@echo on
@exit /b %ret%
